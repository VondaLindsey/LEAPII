package oracle.retail.reim.utils;

import org.apache.struts.action.ActionServlet;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
import org.springframework.context.ApplicationContextException;
import org.springframework.util.StringUtils;
import org.springframework.web.context.ConfigurableWebApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.ServletContextAwareProcessor;

import org.springframework.web.struts.ContextLoaderPlugIn;

public class ReimContextLoaderPlugIn extends ContextLoaderPlugIn{
	
	protected WebApplicationContext createWebApplicationContext(
			WebApplicationContext parent) throws BeansException {

		if (logger.isDebugEnabled()) {
			logger.debug("ContextLoaderPlugIn for Struts ActionServlet '"
					+ getServletName() + "', module '" + getModulePrefix()
					+ "' will try to create custom WebApplicationContext "
					+ "context of class '" + getContextClass().getName()
					+ "', using parent context [" + parent + "]");
		}
		if (!ConfigurableWebApplicationContext.class
				.isAssignableFrom(getContextClass())) {
			throw new ApplicationContextException(
					"Fatal initialization error in ContextLoaderPlugIn for Struts ActionServlet '"
							+ getServletName()
							+ "', module '"
							+ getModulePrefix()
							+ "': custom WebApplicationContext class ["
							+ getContextClass().getName()
							+ "] is not of type ConfigurableWebApplicationContext");
		}

		ConfigurableWebApplicationContext wac = (ConfigurableWebApplicationContext) BeanUtils
				.instantiateClass(getContextClass());
		wac.setParent(parent);
		wac.setServletContext(getServletContext());
		wac.setNamespace(getNamespace());
		if (getContextConfigLocation() != null) {
			wac
					.setConfigLocations(StringUtils
							.tokenizeToStringArray(
									getContextConfigLocation(),
									ConfigurableWebApplicationContext.CONFIG_LOCATION_DELIMITERS));
		}
		wac.addBeanFactoryPostProcessor(new BeanFactoryPostProcessor() {
			public void postProcessBeanFactory(
					ConfigurableListableBeanFactory beanFactory) {
				beanFactory.addBeanPostProcessor(new ServletContextAwareProcessor(getActionServlet()));
				beanFactory.ignoreDependencyType(ActionServlet.class);
				((AbstractAutowireCapableBeanFactory) beanFactory).setAllowRawInjectionDespiteWrapping(true);

			}
		});

		wac.refresh();
		return wac;
	}
	


}
