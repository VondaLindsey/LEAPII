package oracle.retail.reim.services.matching.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.document.HoldStatus;
import oracle.retail.reim.data.dao.IInvoiceDetailDao;
import oracle.retail.reim.data.dao.ISummaryMatchDao;
import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.services.IVarianceService;
import oracle.retail.reim.services.matching.IMatchService;
import oracle.retail.reim.services.matching.IMatchStatusService;
import oracle.retail.reim.services.matching.ISummaryMatchService;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.merch.utils.ToleranceContainer;
import com.retek.reim.RMSInterface.AShipmentAPI;
import com.retek.reim.business.Location;
import com.retek.reim.business.ManualMatchGroup;
import com.retek.reim.business.Order;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.SummaryMatchResult;
import com.retek.reim.business.SupplierGroup;
import com.retek.reim.business.Tolerance;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.match.InvoiceLevel;
import com.retek.reim.business.match.InvoiceSummaryGroupLevel;
import com.retek.reim.business.match.Match;
import com.retek.reim.business.match.OnlineReceiptLevel;
import com.retek.reim.business.match.OnlineReceiptSummaryGroupLevel;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.db.ImInvoiceDetailAccessExt;
import com.retek.reim.db.ImPartiallyMatchedReceiptsAccessExt;
import com.retek.reim.db.ImPartiallyMatchedReceiptsRow;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.foundation.AShipmentBean;
import com.retek.reim.foundation.ASupplierBean;
import com.retek.reim.locking.LockingData;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ISummaryMatch;
import com.retek.reim.services.ManualGroupService;
import com.retek.reim.services.ReceiptService;
import com.retek.reim.services.ReceiptTrackingService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.matching.MatchHistoryService;
import com.retek.reim.ui.invoiceMatch.InvoiceSummaryView;
import com.retek.reim.ui.invoiceMatch.LockedRecord;
import com.retek.reim.ui.invoiceMatch.ReceiptSummaryView;
import com.retek.reim.ui.invoiceMatch.SummaryMatchListForm;
import com.retek.reim.ui.invoiceMatch.UnmatchedAutoGroupView;
import com.retek.reim.ui.invoiceMatch.UnmatchedManualGroupView;

/**
 * // BRN OLR An error occurred while loading Detail Match List page. Please contact your system administrator
 * Modification History
 * Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		22-Mar-2013	BNaik		An error occurred while loading Detail Match List page. Please contact your system administrator.
 *	   1.5    20-June-2013   BNaik 	If the receipt item is quantity matched, then the receipt total should not include matched quantity in Summary Matching List screen.
 * 										
 */
 
@Service
public class SummaryMatchService extends com.retek.reim.services.SummaryMatchService implements
        ISummaryMatchService {

    private ISummaryMatchDao summaryMatchDao;
    private IMatchStatusService matchStatusService;
    private IMatchService matchService;
    private IVarianceService varianceService;
    private IInvoiceDetailDao invoiceDetailDao;
    private IInvoiceDetailService invoiceDetailService;

    public List<MerchandiseDocument> readAdditionalInvoicesMatched(final long invoiceId,
            final boolean noRowsFoundIsError) {
        return getSummaryMatchDao().readAdditionalInvoicesMatched(invoiceId, noRowsFoundIsError);
    }

    /**
     * Method: initializeSummaryMatchList
     * 
     * Initializes the invoice id and receipt id lists which drive every other method. Must be
     * called after getSummaryMatchList and before all other methods.
     * 
     * @param resultArray
     * @param selectedSupplierId
     * @param summaryMatch
     * 
     */
    public void initializeSummaryMatchList(final SummaryMatchResult[] resultArray,
            final String selectedSupplierId, final ISummaryMatch summaryMatch) throws ReIMException {

        // try {
        // TransactionManagerFactory.getInstance().start();

        if (StringUtils.isEmpty(selectedSupplierId)) {
            throw new ReIMException(
                    "error.summaryMatchService.initializeSummaryMatchList.improperUse",
                    Severity.DEBUG, SummaryMatchService.class);
        } else {

            final List sumInvResultList = summaryMatch.getInvoiceResultList();
            final List sumRecResultList = summaryMatch.getReceiptResultList();

            if (sumInvResultList == null || sumRecResultList == null || sumInvResultList.isEmpty()
                    || sumRecResultList.isEmpty()) {

                ArrayList invoiceResultList = null;
                ArrayList receiptResultList = null;

                for (int i = 0; i < resultArray.length; i++) {

                    SummaryMatchResult summaryMatchResult = resultArray[i];

                    if (summaryMatchResult.getSupplier().equals(selectedSupplierId)) {

                        invoiceResultList = new ArrayList(Arrays.asList(summaryMatchResult
                                .getInvoiceList()));
                        receiptResultList = new ArrayList(Arrays.asList(summaryMatchResult
                                .getReceiptList()));
                        break;
                    }
                }
                summaryMatch.setInvoiceResultList(invoiceResultList);
                summaryMatch.setReceiptResultList(receiptResultList);
            }
            populateTotalIdLists(summaryMatch);
            // Populate each underlying Map
            populateSummaryAutoGroupMap(summaryMatch);
            populateSummaryManualGroupMap(summaryMatch);
            populateUnmatchedInvoiceMap(summaryMatch);
            populateUnmatchedReceiptMap(summaryMatch);
        }
        /*
         * } finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    private void populateSummaryManualGroupMap(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            // clear out global map
            summaryMatch.setSummaryManualGroupMap(null);

            List totalInvoiceIdList = summaryMatch.getTotalInvoiceIdList();
            List totalReceiptIdList = summaryMatch.getTotalReceiptIdList();
            if (totalInvoiceIdList.size() > 0 || totalReceiptIdList.size() > 0) {
                ManualMatchGroup[] manualMatchGroups = ManualGroupService.getManualGroups(
                        (String[]) totalInvoiceIdList
                                .toArray(new String[totalInvoiceIdList.size()]),
                        (String[]) totalReceiptIdList
                                .toArray(new String[totalReceiptIdList.size()]));

                List currentInvoiceIdList = null;
                List currentReceiptIdList = null;
                ReIMDate earliestDueDate = null;
                UnmatchedManualGroupView unmatchedManualGroupView = null;
                ManualMatchGroup manualMatchGroup = null;
                // Clear out manual group invoice and receipt id lists
                summaryMatch.setManualGroupInvoiceIdList(null);
                summaryMatch.setManualGroupReceiptIdList(null);
                if (manualMatchGroups != null) {
                    Map summaryManualGroupMap = new HashMap();
                    ArrayList manualGroupInvoiceIdList = new ArrayList();
                    ArrayList manualGroupReceiptIdList = new ArrayList();
                    String currencyCode = null;
                    boolean recordLocked = false;
                    for (int i = 0; i < manualMatchGroups.length; i++) {
                        manualMatchGroup = manualMatchGroups[i];
                        if (manualMatchGroup.getInvoiceIds() != null) {
                            currentInvoiceIdList = Arrays.asList(manualMatchGroup.getInvoiceIds());
                        }
                        if (manualMatchGroup.getReceiptIds() != null) {
                            currentReceiptIdList = Arrays.asList(manualMatchGroup.getReceiptIds());
                        }
                        Set invoiceSet = getInvoiceSet(currentInvoiceIdList, summaryMatch
                                .isTaxMatchRequired());
                        MerchandiseDocument[] invoiceArray = null;
                        if (invoiceSet != null && invoiceSet.size() > 0) {
                            invoiceArray = (MerchandiseDocument[]) invoiceSet
                                    .toArray(new MerchandiseDocument[invoiceSet.size()]);
                            earliestDueDate = invoiceProcessing(invoiceArray);
                            currencyCode = invoiceArray[0].getCurrencyCode();
                            // check if record is locked, if so create message
                            recordLocked = createLockedInvoiceMessage(invoiceArray, summaryMatch,
                                    manualMatchGroup.getManualGroupId());
                        } else{
                        	continue;
                        }

                        Set receiptSet = getReceiptSet(currentReceiptIdList);
                        Receipt[] receiptArray = null;
                        if (receiptSet != null && receiptSet.size() > 0) {
                            receiptArray = (Receipt[]) receiptSet.toArray(new Receipt[receiptSet
                                    .size()]);
                            if (currencyCode == null) {
                                currencyCode = ServiceFactory.getOrderService()
                                        .getReceiptInfoFromOrderNo(receiptArray[0].getOrderId())
                                        .getOrderCurrency();
                            }
                            // if record is not locked, then need to set it if
                            // any receipts are
                            // locked
                            // if record is already locked, need to lock
                            // receipts, but not reset
                            // variable.
                            if (!recordLocked) {
                                recordLocked = createLockedReceiptMessage(receiptArray,
                                        summaryMatch, manualMatchGroup.getManualGroupId());
                            } else {
                                createLockedReceiptMessage(receiptArray, summaryMatch,
                                        manualMatchGroup.getManualGroupId());
                            }
                        }

                        // Create manualGroupView
                        InvoiceSummaryGroupLevel invoiceGroup = new InvoiceSummaryGroupLevel(
                                prePopulateMerchandiseDocuments(invoiceArray));
                        OnlineReceiptSummaryGroupLevel receiptGroup = new OnlineReceiptSummaryGroupLevel(
                                receiptArray);
                        unmatchedManualGroupView = new UnmatchedManualGroupView(manualMatchGroup
                                .getManualGroupId(), earliestDueDate.getDateString(), currencyCode,
                                recordLocked, invoiceGroup, receiptGroup);

                        // Add manual group to map.
                        summaryManualGroupMap.put(manualMatchGroup.getManualGroupId(),
                                unmatchedManualGroupView);

                        // Add each manual group list to the global manual
                        // groups list.
                        manualGroupInvoiceIdList.addAll(currentInvoiceIdList);
                        manualGroupReceiptIdList.addAll(currentReceiptIdList);
                    }

                    if(!manualGroupInvoiceIdList.isEmpty()){
                    summaryMatch.setSummaryManualGroupMap(summaryManualGroupMap);
                    summaryMatch.setManualGroupInvoiceIdList(manualGroupInvoiceIdList);
                    summaryMatch.setManualGroupReceiptIdList(manualGroupReceiptIdList);
                    }
                }
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getSummaryAutoGroups",
                    Severity.ERROR, e);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    /**
     * Method summaryMatch
     * 
     * This method updates the status to matched for the invoices and receipts. Calls the
     * MatchHistoryService to insert into the matching history tables. Removes the matched invoices
     * and receipts from the result lists.
     * 
     */
    public void summaryMatch(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            // Update status to matched for the invoices
            Match match = summaryMatch.getMatch();
            match.getInvoiceGroup().updateInvoiceMatchStatus(Document.MATCHED);
            MerchandiseDocument[] invoices = match.getInvoiceGroup().getInvoices();
            Receipt[] receipts = match.getReceiptGroup().getReceipts();
            getVarianceService().setSummaryVarianceWithinTolerance(match);
            getMatchStatusService().updateInvoiceStatuses(invoices,
                    ServiceFactory.getPeriodService().getScreenVDate(),
                    ReIMUserContext.getUsername());

            // Update the status to matched for the receipts
            match.getReceiptGroup().updateInvoiceMatchStatus(Receipt.MATCHED);
           
            AShipmentAPI api = (AShipmentAPI) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipmentAPI);
            api.updateReceiptInvcMatchedStatus(receipts, Receipt.MATCHED);
            api.updateReceiptInvoiceQtyMatched(receipts, true);

            // Update Best Terms/ Best Terms Date for the invoices AFTER
            // invoices are set to matched
            ServiceFactory.getTermsService().calculateReceiptOfGoodsDate(invoices, receipts);            

            // Write match to history table.
            Match[] matches = new Match[1];
            matches[0] = match;
            MatchHistoryService.persistSuccessfulSummaryLevelMatches(matches, false);

            // Remove the matched invoices and receipts from the result lists.
            removeMatchedGroupedFromList(summaryMatch);

            ReceiptTrackingService.matchReceipt(match);
        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.summaryMatchService.summaryMatch", Severity.ERROR,
                    SummaryMatchService.class);
        } /*finally {
            // TransactionManagerFactory.getInstance().end();
        }*/
    }

    public Match getMatch(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            Map selectedGroupInvoiceMap = new HashMap();
            Map selectedGroupReceiptMap = new HashMap();
            MerchandiseDocument[] invoiceArray = null;
            Receipt[] receiptArray = null;

            if (summaryMatch.getSelectedGroupInvoiceMap() != null
                    && summaryMatch.getSelectedGroupInvoiceMap().size() > 0
                    && summaryMatch.getSelectedGroupReceiptMap() != null
                    && summaryMatch.getSelectedGroupReceiptMap().size() > 0) {
                selectedGroupInvoiceMap = summaryMatch.getSelectedGroupInvoiceMap();
                invoiceArray = (MerchandiseDocument[]) selectedGroupInvoiceMap.values().toArray(
                        new MerchandiseDocument[selectedGroupInvoiceMap.size()]);

                selectedGroupReceiptMap = summaryMatch.getSelectedGroupReceiptMap();
                receiptArray = (Receipt[]) selectedGroupReceiptMap.values().toArray(
                        new Receipt[selectedGroupReceiptMap.size()]);

                // Determine which supplier to use for tolerances and qty
                // matched required
                int size = invoiceArray.length;
                double highCost = 0;
                double currentCost = 0;
                int elementWithLargestCost = 0;
                for (int i = 0; i < size; i++) {
                    currentCost = invoiceArray[i].getResolutionAdjustedTotalCost();
                    if (currentCost > highCost) {
                        highCost = currentCost;
                        elementWithLargestCost = i;
                    }
                }

                Supplier supplier = new Supplier(invoiceArray[elementWithLargestCost].getVendor()
                        .getVendorId());

                boolean qtyMatchRequired = false;
                SupplierGroup supplierGroup = ServiceFactory.getSupplierGroupService()
                        .getSupplierGroup(supplier.getVendorId());
                if (supplierGroup != null) {
                    qtyMatchRequired = supplierGroup.isMatchTotalQuantity();
                }
                // set the currency for match group, match level to summary.
                InvoiceSummaryGroupLevel invoiceGroup = new InvoiceSummaryGroupLevel(
                        prePopulateMerchandiseDocuments(invoiceArray));
                OnlineReceiptSummaryGroupLevel receiptGroup = new OnlineReceiptSummaryGroupLevel(
                        receiptArray);

                Match match = new Match(supplier);
                match.setInvoiceCurrency(invoiceArray[elementWithLargestCost].getCurrencyCode());
                match.setSummaryOrLineMatch(Tolerance.SUMMARY_LEVEL);
                match.setQtyMatchRequired(qtyMatchRequired);
                // if qty matching is not required, set qty match successful to
                // true
                if (!qtyMatchRequired) {
                    match.setQtyMatchSuccessful(true);
                }
                match.setInvoiceGroup(invoiceGroup);
                match.setReceiptGroup(receiptGroup);
                match.setManualMatching(true);
                ToleranceContainer tolContainer = new ToleranceContainer();
                getMatchService().match(match, tolContainer);
                // Set within tolerance on the form.
                summaryMatch.setToleranceContainer(tolContainer);
                summaryMatch.setQtyMatchRequired(qtyMatchRequired);
                summaryMatch.setWithinCostTolerance(match.isCostMatchSuccessful());
                summaryMatch.setWithinQtyTolerance(match.isQtyMatchSuccessful());
                summaryMatch.setWithinTaxTolerance(match.isTaxValildationSuccessful());
                summaryMatch.setTaxValidationPerformed(match.isTaxValildationPerformed());
                summaryMatch.setMatch(match);

                return match;
            } else {
                return null;
            }
        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.summaryMatchService.getMatch", Severity.ERROR,
                    SummaryMatchService.class);
        } finally {
            // TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * Method createSelectedGroupMaps This method populates the selectedGroupInvoiceMap and
     */
    public void createSelectedGroupMaps(String groupType, String key, ISummaryMatch summaryMatch)
            throws ReIMException {
        try {
            // reset the selectedGroupMaps
            summaryMatch.setSelectedGroupInvoiceMap(null);
            summaryMatch.setSelectedGroupReceiptMap(null);

            Map selectedGroupInvoiceMap = new HashMap();
            Map selectedGroupReceiptMap = new HashMap();
            Map summaryGroupMap = null;

            MerchandiseDocument[] invoices;
            Receipt[] receipts;
            String currencyCode = null;
            // The groupType will be either 'A' for Auto Match or 'M' for Manual
            // Match.
            // If the groupType is 'A', the summaryAutoGroupMap will be accessed
            // with
            // orderNo+Location as the key for retrieving the invoices and
            // receipts.
            // If the groupType is 'M', the summaryManualGroupMap will be
            // accessed with
            // manualGroupId as the key for retrieving the invoices and
            // receipts.
            if (groupType.equals(ReIMConstants.AUTO_MATCH)) {
                summaryGroupMap = summaryMatch.getSummaryAutoGroupMap();
                invoices = ((UnmatchedAutoGroupView) summaryGroupMap.get(key)).getInvoiceGroup()
                        .getInvoices();
                receipts = ((UnmatchedAutoGroupView) summaryGroupMap.get(key)).getReceiptGroup()
                        .getReceipts();
            } else {
                summaryGroupMap = summaryMatch.getSummaryManualGroupMap();
                invoices = ((UnmatchedManualGroupView) summaryGroupMap.get(key)).getInvoiceGroup()
                        .getInvoices();
                receipts = ((UnmatchedManualGroupView) summaryGroupMap.get(key)).getReceiptGroup()
                        .getReceipts();
            }

            // The selectedGroupInvoiceMap and selectedGroupReceiptMap are
            // respectively populated
            // with the retrieved invoices and receipts.
            if (invoices != null && invoices.length > 0) {
                boolean status = false;

                for (int i = 0; i < invoices.length; i++) {
                    if (summaryMatch.getUnmatchedInvoiceMap() != null
                            && summaryMatch.getUnmatchedInvoiceMap().size() > 0) {
                        Map unmatchedInvoiceMap = summaryMatch.getUnmatchedInvoiceMap();
                        MerchandiseDocument[] unmatchInvoices = (MerchandiseDocument[]) unmatchedInvoiceMap
                                .values().toArray(
                                        new MerchandiseDocument[unmatchedInvoiceMap.size()]);
                        for (int j = 0; j < unmatchInvoices.length; j++) {
                            if (unmatchInvoices[j].getDocId() == invoices[i].getDocId())
                                status = true;
                        }
                    }
                    if (!status)
                        selectedGroupInvoiceMap.put(invoices[i].getDocId() + "", invoices[i]);
                }
                currencyCode = invoices[0].getCurrencyCode();
            }

            if (receipts != null && receipts.length > 0) {
                for (int i = 0; i < receipts.length; i++) {
                    selectedGroupReceiptMap.put(receipts[i].getReceiptId(), receipts[i]);
                }
                if (currencyCode == null) {
                    currencyCode = ServiceFactory.getOrderService().getReceiptInfoFromOrderNo(
                            receipts[0].getOrderId()).getOrderCurrency();
                }

            }

            // populate the form.
            summaryMatch.setSelectedCurrencyCode(currencyCode);
            summaryMatch.setSelectedGroupInvoiceMap(selectedGroupInvoiceMap);
            summaryMatch.setSelectedGroupReceiptMap(selectedGroupReceiptMap);
            SummaryMatchListForm summaryMatchListForm = (SummaryMatchListForm) summaryMatch;
            updateInvoiceGroupingTotals(summaryMatchListForm);
            updateReceiptGroupingTotals(summaryMatchListForm);
            calculateGroupedInvoiceTotals(summaryMatch);
            calculateGroupedReceiptTotals(summaryMatch);
            getMatch(summaryMatch);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createSelectedGroupMaps",
                    Severity.ERROR, e);
        }

    }

    /**
     * method: updateSummaryMatchListFormGroupingTotals
     * 
     * This method updates the resolution adjusted cost/qty totals on invoices and available to
     * match cost/qty totals on the receipts on the summary match list form. This method is called
     * while user returns from detail matching and also while entering from the summary match search
     * results. This helps is correct calculation of the variance amounts.
     * 
     * @param summaryMatch
     * @throws ReIMException
     */
    public void updateSummaryMatchListFormGroupingTotals(ISummaryMatch summaryMatch)
            throws ReIMException {
        SummaryMatchListForm summaryMatchListForm = (SummaryMatchListForm) summaryMatch;

        updateInvoiceGroupingTotals(summaryMatchListForm);
        updateReceiptGroupingTotals(summaryMatchListForm);

        calculateGroupedInvoiceTotals(summaryMatchListForm);
        calculateGroupedReceiptTotals(summaryMatchListForm);

        getMatch(summaryMatchListForm);
    }
    
    /**
     * method: updateInvoiceGroupingTotals
     * 
     * This method updates the invoice grouping totals on the SummaryMatchListForm. The cost and
     * quantity totals are calculated considering only the unmatched invoice items. Previously the
     * totals are calculated including both matched and unmatched invoice items. Variance amounts
     * are calculated based on the new totals. Within cost and quantity tolerance booleance will be
     * decided based on the new variance amounts.
     * 
     * @param summaryMatch
     * @throws ReIMException
     */
    protected void updateInvoiceGroupingTotals(SummaryMatchListForm summaryMatchListForm)
            throws ReIMException {
        UnmatchedAutoGroupView[] autoGroups = summaryMatchListForm.getAutoGroups();
        MerchandiseDocument[] autoGroupInvoices = null;

        for (int ii = 0; autoGroups != null && ii < autoGroups.length; ii++) {
            autoGroupInvoices = autoGroups[ii].getInvoiceGroup().getInvoices();
            for (int i = 0; autoGroupInvoices != null && i < autoGroupInvoices.length; i++) {
                long docId = autoGroupInvoices[i].getDocId();

                DocumentItemInvoice[] itemsFromDb = getInvoiceDetailService()
                        .getInvoiceItemsByInvoiceId(Long.toString(docId));

                double totalCost = 0;
                double totalQty = 0;
                for (int j = 0; itemsFromDb != null && j < itemsFromDb.length; j++) {
                    if (itemsFromDb[j].getStatus().equalsIgnoreCase(Document.MATCHED)) {
                        continue;
                    }
                    totalCost += itemsFromDb[j].getResolutionAdjustedExtendedCost();
                    totalQty += itemsFromDb[j].getResolutionAdjustedQtyInvoiced();
                }

                double nonMerchCost = ReIMMoney.parseCurrencyString(
                        autoGroupInvoices[i].getNonMerchAmtTotalAsString()).doubleValue();
                /*
                 * If the total cost and total quantity are equal to zero then that means the
                 * invoices in the group do not have any details. All the invoices are header only
                 * invoices.
                 */
                if (totalCost != 0 && totalQty != 0) {
                    autoGroupInvoices[i].setResolutionAdjustedTotalCost(totalCost + nonMerchCost);
                    autoGroupInvoices[i].setResolutionAdjustedTotalQty(totalQty);
                }
            }
        }
        UnmatchedManualGroupView[] manualGroups = summaryMatchListForm.getManualGroups();
        MerchandiseDocument[] manualGroupInvoices = null;
        for (int ii = 0; manualGroups != null && ii < manualGroups.length; ii++) {
            manualGroupInvoices = manualGroups[ii].getInvoiceGroup().getInvoices();
            for (int i = 0; manualGroupInvoices != null && i < manualGroupInvoices.length; i++) {
                long docId = manualGroupInvoices[i].getDocId();

                DocumentItemInvoice[] itemsFromDb = getInvoiceDetailService()
                        .getInvoiceItemsByInvoiceId(Long.toString(docId));

                double totalCost = 0;
                double totalQty = 0;
                for (int j = 0; itemsFromDb != null && j < itemsFromDb.length; j++) {
                    if (itemsFromDb[j].getStatus().equalsIgnoreCase(Document.MATCHED)) {
                        continue;
                    }
                    totalCost += itemsFromDb[j].getResolutionAdjustedExtendedCost();
                    totalQty += itemsFromDb[j].getResolutionAdjustedQtyInvoiced();
                }

                /*
                 * If the total cost and total quantity are equal to zero then that means the
                 * invoices in the group do not have any details. All the invoices are header only
                 * invoices.
                 */
                if (totalCost != 0 && totalQty != 0) {
                    manualGroupInvoices[i].setResolutionAdjustedTotalCost(totalCost);
                    manualGroupInvoices[i].setResolutionAdjustedTotalQty(totalQty);
                }
            }
        }
    }

    /**
     * method: updateReceiptGroupingTotals
     * 
     * Updates the available to match quantity on the receipt items when user performs the cost/qty
     * resolution from detail match and returns to the summarymatch with some left over descrepant
     * items.
     * 
     * @param summaryMatchListForm
     * @throws ReIMException
     */
    protected void updateReceiptGroupingTotals(SummaryMatchListForm summaryMatchListForm)
            throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            ReceiptSummaryView[] receiptList = getSelectedGroupReceipts(summaryMatchListForm);
            ImPartiallyMatchedReceiptsAccessExt receiptItemAccess = new ImPartiallyMatchedReceiptsAccessExt();
            for (int ii = 0; receiptList != null && ii < receiptList.length; ii++) {
                OnlineReceiptLevel receiptLevel = receiptList[ii].getReceipt();
                String receiptId = receiptLevel.getReceipt().getReceiptId();
                ImPartiallyMatchedReceiptsRow[] receiptItemsMatched = receiptItemAccess
                        .readReceiptItemsMatched(Long.parseLong(receiptId));
                Map receiptItems = receiptLevel.getReceipt().getReceiptItems();

                for (int j = 0; receiptItemsMatched != null && j < receiptItemsMatched.length; j++) {
                    ReceiptItem receiptItem = (ReceiptItem) receiptItems.get(receiptItemsMatched[j]
                            .getItem());
                    double availableToMatchQty = receiptItem.getQtyReceived()
                            - receiptItemsMatched[j].getQtyMatched();
                    receiptItem.setCostMatched(ReceiptService.isCostMatched(
                            receiptItem.getItemId(), receiptId));
                    receiptItem.setAvailableToMatchQty(availableToMatchQty);
                }
            }
        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    /**
     * Method: populateTotalIdLists
     * 
     * This method populates the totalInvoiceIdList and totalReceiptIdList List objects on the
     * summaryMatch argument supplied.
     * 
     * @param summaryMatch
     * @throws ReIMException
     */
    private void populateTotalIdLists(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // These lists will be used as holders for the data that is going
            // to be set on the summary match 'total' lists.
            ArrayList invoiceIdList = null;
            ArrayList receiptIdList = null;

            List sumInvoiceResultList = summaryMatch.getInvoiceResultList();
            List sumReceiptResultList = summaryMatch.getReceiptResultList();

            if (sumInvoiceResultList != null) {
                invoiceIdList = new ArrayList();

                Iterator it = sumInvoiceResultList.iterator();
                while (it.hasNext()) {
                    MerchandiseDocument invoice = (MerchandiseDocument) it.next();
                    invoiceIdList.add(String.valueOf(invoice.getDocId()));
                }
            }
            if (sumReceiptResultList != null) {
                receiptIdList = new ArrayList();

                Iterator it = sumReceiptResultList.iterator();
                while (it.hasNext()) {
                    Receipt receipt = (Receipt) it.next();
                    receiptIdList.add(receipt.getReceiptId());
                }
            }
            summaryMatch.setTotalInvoiceIdList(invoiceIdList);
            summaryMatch.setTotalReceiptIdList(receiptIdList);
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.initializeSummaryMatchList",
                    Severity.ERROR, e, SummaryMatchService.class);
        }
    }

    private InvoiceSummaryView getInvoiceView(MerchandiseDocument invoice,
            ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            String docId = invoice.getDocId() + "";
            invoice.getVendor().setVendorName(getSupplierDesc(invoice.getVendor().getVendorId()));

            InvoiceLevel invoiceLevel = new InvoiceLevel(invoice);
            InvoiceSummaryView invoiceSummaryView = new InvoiceSummaryView(invoiceLevel);
            invoiceSummaryView.setInReviewInd(ServiceFactory.getPriceReviewService()
                    .getInvoiceReviewStatus(docId, null));
            invoiceSummaryView.setDetailsExist(getInvoiceDetailService().invoiceDetailExists(docId));
            // Check if the invoice has any matched lines. This currently
            // restricts the invoice from being moved out of a 'group' if
            // it has any matched items.
            ImInvoiceDetailAccessExt detailAccess = new ImInvoiceDetailAccessExt();
            invoiceSummaryView.setFullyUnmatched(!getInvoiceDetailDao().detailsMatched(
                    DocId.valueOf(docId)));
            // check if this invoice is already locked
            invoiceSummaryView.setRecordLocked(createLockedInvoiceMessage(invoice, summaryMatch));
            return invoiceSummaryView;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getInvoices", Severity.ERROR, e,
                    SummaryMatchService.class);
        }/*
         * finally { //TransactionManagerFactory.getInstance().end(); }
         */
    }

    protected MerchandiseDocument[] prePopulateMerchandiseDocuments(
            MerchandiseDocument[] merchandiseDocuments) throws ReIMException {
        // Pre-populate detail items for InvoiceSummaryGroupLevel
        try {
            for (int i = 0; i < merchandiseDocuments.length; i++) {
                merchandiseDocuments[i].setItems(Arrays.asList(getInvoiceDetailService()
                        .getInvoiceItemsByInvoiceId(merchandiseDocuments[i].getDocId())));
            }
            return merchandiseDocuments;
        } catch (ReIMException e) {
            throw e;
        }
    }

    private UnmatchedAutoGroupView createAutoGroupView(POLocation poLocation,
            ReIMDate earliestDueDate, boolean recordLocked) throws ReIMException {
        InvoiceSummaryGroupLevel invoiceGroup = new InvoiceSummaryGroupLevel(
                prePopulateMerchandiseDocuments(poLocation.getInvoices()));
        OnlineReceiptSummaryGroupLevel receiptGroup = new OnlineReceiptSummaryGroupLevel(poLocation
                .getReceipts());
        return new UnmatchedAutoGroupView(poLocation.getOrder().getOrderNo(), poLocation
                .getLocation().getLocationId(), earliestDueDate.getDateString(), poLocation
                .getOrder().getOrderCurrency(), recordLocked, invoiceGroup, receiptGroup);
    }

    private void populateSummaryAutoGroupMap(ISummaryMatch summaryMatch) throws ReIMException {
        // try {
        // TransactionManagerFactory.getInstance().start();

        // clear out global map
        summaryMatch.setSummaryAutoGroupMap(null);
        // get poLocation Map
        final Map poLocationMap = generatePOLocationsMap(summaryMatch);

        if (!poLocationMap.isEmpty()) {
            POLocation[] poLocations = (POLocation[]) poLocationMap.values().toArray(
                    new POLocation[poLocationMap.size()]);

            // get po location invoices and receipts that can be grouped
            AOrderBean orderBean = (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);
            AShipmentBean shipmentBean = (AShipmentBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AShipmentBean);

            Map summaryAutoGroupMap = new HashMap();
            ArrayList autoGroupReceiptIdList = new ArrayList();
            ArrayList autoGroupInvoiceIdList = new ArrayList();
            // Clear out auto group invoice and receipt id lists
            summaryMatch.setAutoGroupInvoiceIdList(null);
            summaryMatch.setAutoGroupReceiptIdList(null);
            int poLocationsLength = poLocations.length;
            boolean recordLocked = false;
            boolean currentRecordLocked = false;
            int i = 0;
            int j = 0;
            double total = 0;
            int invoicesLength;
            for (i = 0; i < poLocationsLength; i++) {
                POLocation poLocation = poLocations[i];
                // get all invoices for po/location
                orderBean.selectPOLocationInvoices(poLocation);
                // if no invoices, then no auto group, proceed to next
                // po/loc
                if (ArrayUtils.isEmpty(poLocation.getInvoices())) {
                    continue;
                }
                // get the receipts for each poLocation
                shipmentBean.getAllReceiptsByPOLocation(poLocation);
                // if no receipts, then no auto group, proceed to next
                // po/loc
                if (ArrayUtils.isEmpty(poLocation.getReceipts())) {
                    continue;
                }

                MerchandiseDocument[] invoices = poLocation.getInvoices();
                // If currencies do not match then move on to next
                // po/location
                boolean sameCurrency = true;
                for (int z = 0; z + 1 < invoices.length; z++) {
                    if (!invoices[z].getCurrencyCode().equals(invoices[z + 1].getCurrencyCode())) {
                        sameCurrency = false;
                    }
                }
                if (!sameCurrency) {
                    continue;
                }

                // generate receipt list in po locations.
                Receipt[] receipts = poLocation.getReceipts();

                // If any receipt is locked, then the entire auto group
                // needs to be locked.
                recordLocked = false;
                currentRecordLocked = false;
                for (j = 0; j < receipts.length; j++) {
                    autoGroupReceiptIdList.add(receipts[j].getReceiptId());
                    // check to see if record locked.
                    currentRecordLocked = createLockedReceiptMessage(receipts[j], summaryMatch);
                    // if any receipt is locked, then the entire group is
                    // locked.
                    if (currentRecordLocked) {
                        recordLocked = currentRecordLocked;
                    }
                }
                // get the total non-merch cost for each invoice on the
                // poLocation
                total = 0;
                MerchandiseDocument invoice = null;
                invoicesLength = invoices.length;
                ReIMDate earliestDueDate = null;
                ReIMDate currentDueDate = null;

                for (j = 0; j < invoicesLength; j++) {
                    invoice = invoices[j];
                    autoGroupInvoiceIdList.add(invoice.getDocId() + "");
                    // Determine earliest due date for po/loc invoice group
                    currentDueDate = invoice.getDueDate();
                    earliestDueDate = compareDueDates(currentDueDate, earliestDueDate);

                    total = ServiceFactory.getNonMerchandiseDocumentService()
                            .getDoubleTotalNonMerchCost(invoice.getDocId());
                    invoice.setNonMerchAmtTotal(total);
                    // check to see if record locked.
                    currentRecordLocked = createLockedInvoiceMessage(invoice, summaryMatch);
                    // if any invoice is locked, then the entire group is
                    // locked.
                    if (currentRecordLocked) {
                        recordLocked = currentRecordLocked;
                    }
                }
                // Create autoGroupView object.
                summaryAutoGroupMap.put(poLocation.getOrderNo() + "+"
                        + poLocation.getLocation().getLocationId(), createAutoGroupView(poLocation,
                        earliestDueDate, recordLocked));

                // Set variables on the form.
                summaryMatch.setSummaryAutoGroupMap(summaryAutoGroupMap);
                summaryMatch.setAutoGroupInvoiceIdList(autoGroupInvoiceIdList);
                summaryMatch.setAutoGroupReceiptIdList(autoGroupReceiptIdList);
            }
        }
        // }
        /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    private InvoiceSummaryView[] convertInvoices(MerchandiseDocument[] invoices,
            ISummaryMatch summaryMatch) throws ReIMException {
        int groupSize = invoices.length;
        InvoiceSummaryView[] invoiceSummaryView = new InvoiceSummaryView[groupSize];
        for (int i = 0; i < groupSize; i++) {
            invoiceSummaryView[i] = getInvoiceView(invoices[i], summaryMatch);
        }
        return invoiceSummaryView;
    }

    private ReceiptSummaryView[] convertReceipts(Receipt[] receipts, ISummaryMatch summaryMatch)
            throws ReIMException {
        int groupSize = receipts.length;
        ReceiptSummaryView[] receiptSummaryView = new ReceiptSummaryView[groupSize];
        for (int i = 0; i < groupSize; i++) {
            receiptSummaryView[i] = getReceiptView(receipts[i], summaryMatch);
        }
        return receiptSummaryView;
    }

    public ReceiptSummaryView[] getUnmatchedReceiptsOnCancel(ISummaryMatch summaryMatch)
            throws ReIMException {
        if (summaryMatch.getTotalInvoiceIdList() == null) { throw new ReIMException(
                "error.summaryMatchService.getUnmatchedReceipts.improperUse", Severity.DEBUG,
                SummaryMatchService.class);

        }

        if (!MapUtils.isEmpty(summaryMatch.getUnmatchedReceiptMap())) {

            Map<String, Receipt> unmatchedReceiptMap = summaryMatch.getUnmatchedReceiptMap();

            List<String> autoGroupReceiptList = summaryMatch.getAutoGroupReceiptIdList();

            if (CollectionUtils.isNotEmpty(autoGroupReceiptList)) {

                for (String shipment : autoGroupReceiptList) {

                    unmatchedReceiptMap.remove(shipment);
                }
            }
            Receipt[] receipts = unmatchedReceiptMap.values().toArray(
                    new Receipt[unmatchedReceiptMap.size()]);
            if (!ArrayUtils.isEmpty(receipts)) { return convertReceipts(receipts, summaryMatch); }
        }
        return null;
    }

    public ReceiptSummaryView[] getUnmatchedReceipts(ISummaryMatch summaryMatch)
            throws ReIMException {
        if (summaryMatch.getTotalInvoiceIdList() == null) { throw new ReIMException(
                "error.summaryMatchService.getUnmatchedReceipts.improperUse", Severity.DEBUG,
                SummaryMatchService.class);

        }
        if (summaryMatch.getUnmatchedReceiptMap() != null
                && summaryMatch.getUnmatchedReceiptMap().size() > 0) {
            Map unmatchedReceiptMap = summaryMatch.getUnmatchedReceiptMap();
            Receipt[] receipts = (Receipt[]) unmatchedReceiptMap.values().toArray(
                    new Receipt[unmatchedReceiptMap.size()]);
            if (receipts != null && receipts.length > 0) {
                return convertReceipts(receipts, summaryMatch);
            } else {
                return null;
            }
        } else
            return null;
    }

    public InvoiceSummaryView[] getSelectedGroupInvoices(ISummaryMatch summaryMatch)
            throws ReIMException {
        if (summaryMatch.getSelectedGroupInvoiceMap() != null) {
            Map selectedGroupInvoiceMap = summaryMatch.getSelectedGroupInvoiceMap();
            MerchandiseDocument[] invoices = (MerchandiseDocument[]) selectedGroupInvoiceMap
                    .values().toArray(new MerchandiseDocument[selectedGroupInvoiceMap.size()]);
            if (invoices != null && invoices.length > 0) {
                return convertInvoices(invoices, summaryMatch);
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public ReceiptSummaryView[] getSelectedGroupReceipts(ISummaryMatch summaryMatch)
            throws ReIMException {
        if (summaryMatch.getSelectedGroupReceiptMap() != null) {
            Map selectedGroupReceiptMap = summaryMatch.getSelectedGroupReceiptMap();
            Receipt[] receipts = (Receipt[]) selectedGroupReceiptMap.values().toArray(
                    new Receipt[selectedGroupReceiptMap.size()]);
            if (receipts != null && receipts.length > 0) {
                return convertReceipts(receipts, summaryMatch);
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public InvoiceSummaryView[] getUnmatchedInvoicesOnCancel(ISummaryMatch summaryMatch)
            throws ReIMException {

        if (summaryMatch.getTotalInvoiceIdList() == null) { throw new ReIMException(
                "error.summaryMatchService.getUnmatchedInvoices.improperUse", Severity.DEBUG,
                SummaryMatchService.class);

        }
        if (summaryMatch.getUnmatchedInvoiceMap() != null
                && summaryMatch.getUnmatchedInvoiceMap().size() > 0) {
            Map unmatchedInvoiceMap = summaryMatch.getUnmatchedInvoiceMap();

            // Surajeet Changes Starts
            ArrayList autoMatchInvoices = summaryMatch.getAutoGroupInvoiceIdList();
            List autoMatchInvoicesList = new ArrayList();
            autoMatchInvoicesList = autoMatchInvoices;
            if (autoMatchInvoicesList != null && autoMatchInvoicesList.size() > 0) {
                MerchandiseDocument invoice;
                for (Iterator iterator = autoMatchInvoicesList.iterator(); iterator.hasNext();) {
                    long docId = Long.parseLong((String) iterator.next());
                    invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                            .getDocHeadWithTaxByDocId(docId);
                    unmatchedInvoiceMap = summaryMatch.getUnmatchedInvoiceMap();
                    if (unmatchedInvoiceMap.containsKey(String.valueOf(docId))) {
                        unmatchedInvoiceMap.remove(String.valueOf(docId));
                    }
                }
            }

            MerchandiseDocument[] invoices = (MerchandiseDocument[]) unmatchedInvoiceMap.values()
                    .toArray(new MerchandiseDocument[unmatchedInvoiceMap.size()]);

            if (invoices != null && invoices.length > 0) {
                return convertInvoices(invoices, summaryMatch);
            } else {
                return null;
            }
        } else
            return null;
    }

    public InvoiceSummaryView[] getUnmatchedInvoices(ISummaryMatch summaryMatch)
            throws ReIMException {

        if (summaryMatch.getTotalInvoiceIdList() == null) { throw new ReIMException(
                "error.summaryMatchService.getUnmatchedInvoices.improperUse", Severity.DEBUG,
                SummaryMatchService.class);

        }
        if (summaryMatch.getUnmatchedInvoiceMap() != null
                && summaryMatch.getUnmatchedInvoiceMap().size() > 0) {
            Map unmatchedInvoiceMap = summaryMatch.getUnmatchedInvoiceMap();
            MerchandiseDocument[] invoices = (MerchandiseDocument[]) unmatchedInvoiceMap.values()
                    .toArray(new MerchandiseDocument[unmatchedInvoiceMap.size()]);
            if (invoices != null && invoices.length > 0) {
                return convertInvoices(invoices, summaryMatch);
            } else {
                return null;
            }
        } else
            return null;
    }

    /**
     * Method: updateManualGroupMap
     * 
     * This method will update the SummaryManualGroup map so that all invoices and receipts are
     * shown in the correct group.
     * 
     * @param summaryMatch
     *            The summary match object which needs its manual group map updated.
     * @param invoiceArray
     *            For creating the UnmatchedManualGroupView.
     * @param receiptArray
     *            For creating the UnmatchedManualGroupView.
     * @param currencyCode
     *            For creating the UnmatchedManualGroupView.
     * @param manualGroupId
     *            The ID to add to the manual group map.
     */
    private void updateManualGroupMap(final ISummaryMatch summaryMatch,
            final MerchandiseDocument[] invoiceArray, final Receipt[] receiptArray,
            final String currencyCode, final String manualGroupId) throws ReIMException {

        try {
            final ReIMDate earliestDueDate = invoiceProcessing(invoiceArray);
            
            UnmatchedManualGroupView unmatchedManualGroupView = new UnmatchedManualGroupView(
                    manualGroupId, earliestDueDate.getDateString(), currencyCode, false,
                    new InvoiceSummaryGroupLevel(prePopulateMerchandiseDocuments(invoiceArray)),
                    new OnlineReceiptSummaryGroupLevel(receiptArray));

            Map manualGroupMap = summaryMatch.getSummaryManualGroupMap();
                        
            // BRN OLR An error occurred while loading Detail Match List page. Please contact your system administrator. -begin
            if (summaryMatch.getSelectedGroupInvoiceMap() == null){
            	
            	Map selectedGroupInvoiceMap = new HashMap();
                HashMap<String, DocumentItemInvoice> docDetails = new HashMap<String, DocumentItemInvoice>();
                
                for (int i = 0; i < invoiceArray.length; i++) {
                	
                	List<DocumentItemInvoice> rows = invoiceArray[i].getItems();
                	int rowsLength = invoiceArray[i].getItems().size();
                    // add invoice detail lines to the invoice docDetail hashmap
                    for (int k = 0; k < rowsLength; k++) {
                        DocumentItemInvoice documentItem = rows.get(k);            
                        docDetails.put(documentItem.getItem().getItemId(), documentItem);
                    }                
                    invoiceArray[i].setDocDetail(docDetails);
                    selectedGroupInvoiceMap.put(invoiceArray[i].getDocId() + "", invoiceArray[i]);
                }            
                summaryMatch.setSelectedGroupInvoiceMap(selectedGroupInvoiceMap);
            	
            }
            // BRN OLR An error occurred while loading Detail Match List page. Please contact your system administrator. - end

            if (manualGroupMap == null) {
                // There were no existing manual groups in the map. Create a
                // new map, then add our group.
                manualGroupMap = new HashMap();
                manualGroupMap.put(manualGroupId, unmatchedManualGroupView);
                summaryMatch.setSummaryManualGroupMap(manualGroupMap);
            } else {
                // There were some existing groups perhaps, lets add ours.
                summaryMatch.getSummaryManualGroupMap()
                        .put(manualGroupId, unmatchedManualGroupView);
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.updateManualGroupMap",
                    Severity.ERROR, SummaryMatchService.class, new String[] { summaryMatch
                            .getManualGroupId()});
        }
    }

    /**
     * Method: addSummaryManualGroups This method removes selected invoices and/or receipts from
     * their corresponding Unmatched Map and creates a new manualGroupView and manualGroupMap for
     * the selected invoices and/or receipts. Returns the manualGroupId.
     */
    public void addSummaryManualGroup(String[] invoiceIds, String[] receiptIds,
            ISummaryMatch summaryMatch) throws ReIMException {
        try {
            String currencyCode = null;
            // remove invoices from unmatchedInvoiceMap
            MerchandiseDocument[] invoiceArray = null;
            if (invoiceIds != null) {
                int invoiceSize = invoiceIds.length;
                invoiceArray = new MerchandiseDocument[invoiceSize];

                Map unmatchedInvoiceMap = summaryMatch.getUnmatchedInvoiceMap();
                for (int i = 0; i < invoiceSize; i++) {
                    String invoiceId = invoiceIds[i];
                    if (unmatchedInvoiceMap.containsKey(invoiceId)) {
                        invoiceArray[i] = (MerchandiseDocument) unmatchedInvoiceMap.get(invoiceId);
                        unmatchedInvoiceMap.remove(invoiceId);
                    }
                }
                currencyCode = invoiceArray[0].getCurrencyCode();
            }

            // remove receipts from unmatchedReceiptMap
            Receipt[] receiptArray = null;
            Map unmatchedReceiptMap = summaryMatch.getUnmatchedReceiptMap();
            if (receiptIds != null) {
                int receiptSize = receiptIds.length;
                receiptArray = new Receipt[receiptSize];
                for (int i = 0; i < receiptSize; i++) {
                    String receiptId = receiptIds[i];
                    if (unmatchedReceiptMap.containsKey(receiptId)) {
                        receiptArray[i] = (Receipt) unmatchedReceiptMap.get(receiptId);
                        unmatchedReceiptMap.remove(receiptId);
                    }
                }
                if (currencyCode == null) {
                    currencyCode = ServiceFactory.getOrderService().getReceiptInfoFromOrderNo(
                            receiptArray[0].getOrderId()).getOrderCurrency();
                }
            }

            // create manualGroupView
            String manualGroupId = ManualGroupService.getNextGroupId() + "";
            updateManualGroupMap(summaryMatch, invoiceArray, receiptArray, currencyCode,
                    manualGroupId);
            summaryMatch.setManualGroupId(manualGroupId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.addSummaryManualGroup",
                    Severity.ERROR, e);
        }
    }

    /**
     * Method: saveManualGroup This method will save manual groups. If the manual group currently
     * exists, it is removed and a new manual group is created with the current information. Note:
     * The existing manual group that was removed will be recreated with it's original manualGroupId .
     */
    public void saveManualGroup(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            String manualGroupId = summaryMatch.getManualGroupId();
            if (ManualGroupService.manualGroupExists(manualGroupId)
                    || (summaryMatch.getManualGroupsToCombine() != null && summaryMatch
                            .getManualGroupsToCombine().size() > 0)) {
                deleteManualGroup(summaryMatch);
            }
            ManualGroupService.insertManualGroup(manualGroupId);
            ManualGroupService.insertInvoiceGroup(manualGroupId, summaryMatch
                    .getSelectedGroupInvoiceMap());
            ManualGroupService.insertReceiptGroup(manualGroupId, summaryMatch
                    .getSelectedGroupReceiptMap());

            Map invoiceMap = summaryMatch.getSelectedGroupInvoiceMap();
            Map receiptMap = summaryMatch.getSelectedGroupReceiptMap();
            MerchandiseDocument[] invoiceArray = (MerchandiseDocument[]) invoiceMap.values()
                    .toArray(new MerchandiseDocument[invoiceMap.size()]);
            Receipt[] receiptArray = (Receipt[]) receiptMap.values().toArray(
                    new Receipt[receiptMap.size()]);
            String currencyCode = invoiceArray[0].getCurrencyCode();
            updateManualGroupMap(summaryMatch, invoiceArray, receiptArray, currencyCode,
                    manualGroupId);
        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.summaryMatchService.saveManualGroup", Severity.ERROR,
                    SummaryMatchService.class, new String[] { summaryMatch.getManualGroupId()});
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    /**
     * This method is called by the SummaryMatchListCombineGroupsAction in the user interface to
     * combine selected groups.
     * 
     * @param summaryMatch
     *            The summaryMatch object from which to pull the selected groups.
     */
    public void combineGroups(final ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            // These lists will hold the documents that are going to be included
            // in the new manual group.
            final List invoiceList = new ArrayList();
            final List receiptList = new ArrayList();

            // Iterate over selected auto groups to populate the
            // invoice and receipt arrays.

            // A set of auto groups that were flagged for combination with
            // another group.
            final Set autoGroupSetToCombine = summaryMatch.getAutoGroupsToCombine();

            if (autoGroupSetToCombine != null && !autoGroupSetToCombine.isEmpty()) {

                final Map autoGroupMap = summaryMatch.getSummaryAutoGroupMap();

                final Iterator it = autoGroupSetToCombine.iterator();
                while (it.hasNext()) {

                    // Loop through all the auto groups and create views for the
                    // ones that are valid.
                    final String autoGroupId = it.next().toString();

                    if (autoGroupMap.containsKey(autoGroupId)) {
                        UnmatchedAutoGroupView autoGroupView = (UnmatchedAutoGroupView) autoGroupMap
                                .get(autoGroupId);

                        // First, add the invoices.
                        MerchandiseDocument[] groupInvoices = autoGroupView.getInvoiceGroup()
                                .getInvoices();

                        if (groupInvoices != null) {
                            for (int j = 0; j < groupInvoices.length; j++) {
                                invoiceList.add(groupInvoices[j]);
                            }
                        }
                        // Next, add the receipts.
                        Receipt[] groupReceipts = autoGroupView.getReceiptGroup().getReceipts();
                        if (groupReceipts != null) {
                            for (int j = 0; j < groupReceipts.length; j++) {
                                receiptList.add(groupReceipts[j]);
                            }
                        }
                        // The last thing we do here is remove the auto group
                        // from the auto group map.
                        autoGroupMap.remove(autoGroupId);
                    }
                }
            }

            // iterate over selected manual groups to populate the invoice and
            // receipt arrays.
            final Set manualGroupSetToCombine = summaryMatch.getManualGroupsToCombine();

            if (manualGroupSetToCombine != null && !manualGroupSetToCombine.isEmpty()) {

                final Map manualGroupMap = summaryMatch.getSummaryManualGroupMap();

                final Iterator it = manualGroupSetToCombine.iterator();
                while (it.hasNext()) {
                    String manualGroupId = it.next().toString();
                    if (manualGroupMap.containsKey(manualGroupId)) {
                        UnmatchedManualGroupView manualGroupView = (UnmatchedManualGroupView) manualGroupMap
                                .get(manualGroupId);
                        MerchandiseDocument[] groupInvoices = manualGroupView.getInvoiceGroup()
                                .getInvoices();
                        Receipt[] groupReceipts = manualGroupView.getReceiptGroup().getReceipts();

                        if (groupInvoices != null) {
                            for (int j = 0; j < groupInvoices.length; j++) {
                                invoiceList.add(groupInvoices[j]);
                            }
                        }
                        if (groupReceipts != null) {
                            for (int j = 0; j < groupReceipts.length; j++) {
                                receiptList.add(groupReceipts[j]);
                            }
                        }
                    }
                }
            }

            // create manualGroupView
            MerchandiseDocument[] invoices = (MerchandiseDocument[]) invoiceList
                    .toArray(new MerchandiseDocument[invoiceList.size()]);

            Receipt[] receipts = (Receipt[]) receiptList.toArray(new Receipt[receiptList.size()]);

            final String currencyCode = invoices[0].getCurrencyCode();
            final String manualGroupId = String.valueOf(ManualGroupService.getNextGroupId());

            // Update the manual groups with our new group.
            updateManualGroupMap(summaryMatch, invoices, receipts, currencyCode, manualGroupId);

            // Clear set the manual group id for summary matching.
            summaryMatch.setManualGroupId(manualGroupId);

        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.summaryMatchService.combineGroups", Severity.ERROR,
                    SummaryMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    /**
     * Method: generatePOLocationsMap
     * 
     * The method creates a map of PO location results for a specific ISummaryMatch instance. It
     * loops through the invoice / receipt result lists and creates PO locations based on the
     * document data. The map instance this method returns contains 'POLocation' instances.
     * 
     * @param summaryMatch
     *            The ISummaryMatch instance to build PO locations for.
     * @return A map containing 'POLocation' objects, keyed by 'order+locationId'.
     * @throws ReIMException
     */
    private Map generatePOLocationsMap(final ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // The map that this class will return, filled with POLocation
            // objects.
            final Map poLocations = new HashMap();

            final List invoiceResultList = summaryMatch.getInvoiceResultList();
            final List receiptResultList = summaryMatch.getReceiptResultList();

            if (invoiceResultList != null && !invoiceResultList.isEmpty()) {

                final Iterator it = invoiceResultList.iterator();
                while (it.hasNext()) {
                    MerchandiseDocument invoice = (MerchandiseDocument) it.next();
                    final String orderNo = invoice.getOrderNo();
                    final String locationId = invoice.getLocation().getLocationId();
                    final String locationType = invoice.getLocation().getLocationType();
                    final String locationKey = orderNo + "+" + locationId;

                    if (!poLocations.containsKey(locationKey)) {
                        final Location location = new Location(locationId, StringUtils.EMPTY,
                                locationType);
                        poLocations.put(locationKey, new POLocation(new Order(orderNo), location));
                    }
                }
            }

            if (receiptResultList != null && !receiptResultList.isEmpty()) {

                final Iterator it = receiptResultList.iterator();
                while (it.hasNext()) {
                    final Receipt receipt = (Receipt) it.next();
                    final String orderNo = receipt.getOrderId();
                    final Location location = receipt.getReceivingLoc();
                    final String locationKey = orderNo + "+" + location.getLocationId();

                    if (!poLocations.containsKey(locationKey)) {
                        poLocations.put(locationKey, new POLocation(new Order(orderNo), location));
                    }
                }
            }
            return poLocations;

        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getSummaryAutoGroups",
                    Severity.ERROR, e);
        }
    }

    private void populateUnmatchedReceiptMap(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            // clear out global map
            summaryMatch.setUnmatchedReceiptMap(null);
            // Instantiate Map
            Map<String, Receipt> unmatchedReceiptMap = new HashMap<String, Receipt>();
            List receiptIdList = getUnmatchedReceiptList(summaryMatch);

            if (receiptIdList != null && receiptIdList.size() > 0) {
                Receipt receipt;
                for (Iterator iterator = receiptIdList.iterator(); iterator.hasNext();) {
                    receipt = ReceiptService.getReceiptsForMatchingByReceiptId((String) iterator
                            .next());
                    if (receipt != null) {
                        if (!receipt.getInvoiceMatchStatus().equals("M")) {
                            unmatchedReceiptMap.put(receipt.getReceiptId(), receipt);
                        }
                    }

                }
            }
            summaryMatch.setUnmatchedReceiptMap(unmatchedReceiptMap);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getReceipts", Severity.ERROR, e,
                    SummaryMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    private List getUnmatchedInvoiceList(ISummaryMatch summaryMatch) {
        List localTotalInvoiceList = (List) summaryMatch.getTotalInvoiceIdList().clone();
        if (summaryMatch.getAutoGroupInvoiceIdList() != null) {
            localTotalInvoiceList.removeAll(summaryMatch.getAutoGroupInvoiceIdList());
        }
        if (summaryMatch.getManualGroupInvoiceIdList() != null) {
            localTotalInvoiceList.removeAll(summaryMatch.getManualGroupInvoiceIdList());
        }

        return localTotalInvoiceList;
    }

    /**
     * Method createLockedReceiptMessage. This method creates a locked message for an receipt and
     * returns true if one was created, otherwise returns false
     */
    private boolean createLockedReceiptMessage(Receipt[] receipts, ISummaryMatch summaryMatch,
            String manualGroupId) throws ReIMException {
        try {
            boolean recordLocked = false;
            for (int i = 0; i < receipts.length; i++) {
                if (createLockedReceiptMessage(receipts[i], summaryMatch, manualGroupId)) {
                    recordLocked = true;
                }
            }
            return recordLocked;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createLockedMessage",
                    Severity.ERROR, SummaryMatchService.class);
        }
    }

    protected boolean createLockedReceiptMessage(Receipt receipt, ISummaryMatch summaryMatch)
            throws ReIMException {
        try {
            // overload method with no manual group Id.
            return createLockedReceiptMessage(receipt, summaryMatch, "");
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createLockedMessage",
                    Severity.ERROR, SummaryMatchService.class);
        }
    }

    private boolean createLockedReceiptMessage(Receipt receipt, ISummaryMatch summaryMatch,
            String manualGroupId) throws ReIMException {
        if (summaryMatch.getMode().equals(ReIMConstants.EDIT) == false) { return false; }

        String receiptId = receipt.getReceiptId();
        String userId = summaryMatch.getUserId();
        String currentLockingUser = null;
        try {
            // Attempt to lock the receipt
            currentLockingUser = ServiceFactory.getTableRecordLockingService()
                    .lockTableRecordForUser(LockingData.RECEIPT_LOCK_TABLE, userId,
                            Long.parseLong(receiptId));
            if (currentLockingUser.equals(userId)) {
                // If it was me who locked the record or already have a lock on
                // that record, add it
                // to the the list that maintains
                // all the records locked by current user.
                summaryMatch.getReceiptsLockedByUser().add(String.valueOf(receiptId));
                return false;
            } else {
                LockedRecord lockedReceiptRecord = new LockedRecord(receiptId,
                        receipt.getOrderId(), manualGroupId, currentLockingUser);
                summaryMatch.getReceiptLockedMessageList().add(lockedReceiptRecord);
                return true;
            }
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createLockedMessage",
                    Severity.ERROR, SummaryMatchService.class);
        }
    }

    private void populateUnmatchedInvoiceMap(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            // clear out global map
            summaryMatch.setUnmatchedInvoiceMap(null);
            // instantiate Map
            Map unmatchedInvoiceMap = new HashMap();
            List invoiceIdList = getUnmatchedInvoiceList(summaryMatch);
            if (invoiceIdList != null && invoiceIdList.size() > 0) {
                MerchandiseDocument invoice;
                for (Iterator iterator = invoiceIdList.iterator(); iterator.hasNext();) {
                    long docId = Long.parseLong((String) iterator.next());
                    if (summaryMatch.isTaxMatchRequired()) {
                        invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                                .getDocHeadWithTaxByDocId(docId);
                    } else {
                        invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                                .getDocHeadByDocId(docId);
                    }
                    if (!invoice.getStatus().equals(Document.MATCHED)) {
                        invoice.setNonMerchAmtTotal(ServiceFactory
                                .getNonMerchandiseDocumentService().getDoubleTotalNonMerchCost(
                                        invoice.getDocId()));
                        unmatchedInvoiceMap.put(docId + "", invoice);
                    }
                }
            }
            summaryMatch.setUnmatchedInvoiceMap(unmatchedInvoiceMap);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getInvoices", Severity.ERROR, e,
                    SummaryMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    private ReceiptSummaryView getReceiptView(Receipt receipt, ISummaryMatch summaryMatch)
            throws ReIMException {
        boolean isSupplierSiteIndOn = false;
        try {
            // TransactionManagerFactory.getInstance().start();
            OnlineReceiptLevel receiptLevel = new OnlineReceiptLevel(receipt);
            Order order = ServiceFactory.getOrderService().getReceiptInfoFromOrderNo(
                    receipt.getOrderId());
            ReceiptSummaryView receiptSummaryView = new ReceiptSummaryView(receiptLevel);
            isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
                    .isSupplierSiteInd();
            if (isSupplierSiteIndOn) {
                ASupplierBean supplierBean = (ASupplierBean) ReIMBeanFactory
                        .getBean(ReIMBeanFactory.ASupplierBean);
                String supplierParent = supplierBean.getSupplierParent(order.getSupplierId());
                receiptSummaryView.setSupplierId(supplierParent);
                receiptSummaryView.setSupplierName(getSupplierDesc(supplierParent));
            } else {
                receiptSummaryView.setSupplierId(order.getSupplierId());
                receiptSummaryView.setSupplierName(getSupplierDesc(order.getSupplierId()));
            }

            receiptSummaryView.setCurrencyCode(order.getOrderCurrency());
            if (isSupplierSiteIndOn) {

            } else {
                receiptSummaryView.setSupplierId(order.getSupplierId());
            }

            // Check if the receipt has any matched lines. This currently
            // restricts the receipt from being moved out of a 'group' if
            // it has any matched items.
            if (receiptSummaryView.getReceipt().getReceipt().getInvoiceMatchStatus().equals(
                    Receipt.UNMATCHED)) {
                receiptSummaryView.setFullyUnmatched(true);
                receiptSummaryView
                        .setRecordLocked(createLockedReceiptMessage(receipt, summaryMatch));
            } else {
                receiptSummaryView.setFullyUnmatched(false);
            }

            return receiptSummaryView;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getInvoices", Severity.ERROR, e,
                    SummaryMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    private ReIMDate invoiceProcessing(MerchandiseDocument[] invoices) throws ReIMException {
        // get the total non-merch cost for each invoice on the poLocation
        // try {
        // TransactionManagerFactory.getInstance().start();
        double total = 0;
        MerchandiseDocument invoice = null;
        int invoicesLength = invoices.length;
        ReIMDate earliestDueDate = null;
        for (int j = 0; j < invoicesLength; j++) {
            invoice = invoices[j];
            // Determine earliest due date for po/loc invoice group
            earliestDueDate = compareDueDates(invoice.getDueDate(), earliestDueDate);
            total = ServiceFactory.getNonMerchandiseDocumentService().getDoubleTotalNonMerchCost(
                    invoice.getDocId());
            invoice.setNonMerchAmtTotal(total);
        }
        return earliestDueDate;
        // }
        /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */

    }

    private ReIMDate compareDueDates(ReIMDate currentDueDate, ReIMDate earliestDueDate) {
        if (earliestDueDate != null) {
            if (currentDueDate.beforeDate(earliestDueDate)) {
                earliestDueDate = currentDueDate;
            }
        } else {
            earliestDueDate = new ReIMDate(currentDueDate);
        }
        return earliestDueDate;
    }

    private Set getInvoiceSet(List invoiceIdList, boolean isTaxMatchRequired) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            if (invoiceIdList != null && invoiceIdList.size() > 0) {
                Set invoiceList = new HashSet();
                MerchandiseDocument invoice;
                for (Iterator iterator = invoiceIdList.iterator(); iterator.hasNext();) {
                    long docId = Long.parseLong((String) iterator.next());
                    if (isTaxMatchRequired) {
                        invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                                .getDocHeadWithTaxByDocId(docId);
                    } else {
                        invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                                .getDocHeadByDocId(docId);
                    }
                    if (!invoice.getHoldStatus().equals(HoldStatus.HELD)){
                    invoice.setNonMerchAmtTotal(ServiceFactory.getNonMerchandiseDocumentService()
                            .getDoubleTotalNonMerchCost(invoice.getDocId()));
                    invoiceList.add(invoice);
                    }
                }
                return invoiceList;
            } else
                return null;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getInvoices", Severity.ERROR, e,
                    SummaryMatchService.class);
        }/*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    /**
     * Method createLockedInvoiceMessage. This method creates a locked message for an invoice and
     * returns true if one was created, otherwise returns false
     */
    private boolean createLockedInvoiceMessage(MerchandiseDocument invoice[],
            ISummaryMatch summaryMatch, String manualGroupId) throws ReIMException {
        try {
            boolean recordLocked = false;
            for (int i = 0; i < invoice.length; i++) {
                if (createLockedInvoiceMessage(invoice[i], summaryMatch, manualGroupId)) {
                    recordLocked = true;
                }
            }
            return recordLocked;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createLockedMessage",
                    Severity.ERROR, SummaryMatchService.class);
        }
    }

    protected boolean createLockedInvoiceMessage(MerchandiseDocument invoice,
            ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // overload method with no manual group Id.
            return createLockedInvoiceMessage(invoice, summaryMatch, "");
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createLockedMessage",
                    Severity.ERROR, SummaryMatchService.class);
        }
    }

    private boolean createLockedInvoiceMessage(MerchandiseDocument invoice,
            ISummaryMatch summaryMatch, String manualGroupId) throws ReIMException {
        if (summaryMatch.getMode().equals(ReIMConstants.EDIT) == false) { return false; }

        long invoiceId = invoice.getDocId();
        String userId = summaryMatch.getUserId();
        String currentLockingUser = null;
        try {
            // Attempt to lock the invoice
            currentLockingUser = ServiceFactory.getTableRecordLockingService()
                    .lockTableRecordForUser(LockingData.DOC_HEAD_LOCK_TABLE, userId, invoiceId);
            if (currentLockingUser.equals(userId)) {
                // If it was me who locked the record or already have a lock on
                // that record, add it
                // to the the list that maintains
                // all the records locked by current user.
                summaryMatch.getInvoicesLockedByUser().add(String.valueOf(invoiceId));
                return false;
            } else {
                LockedRecord lockedInvoiceRecord = new LockedRecord(invoice.getExtDocId(), invoice
                        .getOrderNo(), manualGroupId, currentLockingUser);
                summaryMatch.getInvoiceLockedMessageList().add(lockedInvoiceRecord);
                return true;
            }
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.createLockedMessage",
                    Severity.ERROR, SummaryMatchService.class);
        }
    }

    public void calculateGroupedInvoiceTotals(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            double totalSelectedCost = 0;
            double totalSelectedQty = 0;
            int arraySize = 0;
            InvoiceSummaryView[] invoiceList = getSelectedGroupInvoices(summaryMatch);
            if (invoiceList != null && invoiceList.length > 0) {
                arraySize = invoiceList.length;
                for (int i = 0; i < arraySize; i++) {
                    InvoiceSummaryView invoice = invoiceList[i];
                    totalSelectedCost += ReIMMoney.parseCurrencyString(
                            invoice.getAdjTotalMerchCost(), summaryMatch.getSelectedCurrencyCode())
                            .doubleValue();
                    totalSelectedQty += ReIMQuantity.parseNumberString(invoice.getTotalQty())
                            .doubleValue();
                }
            }
            // Need to get currency to format properly
            summaryMatch.setInvoiceGroupingCostTotal(totalSelectedCost);
            summaryMatch.setInvoiceGroupingQtyTotal(totalSelectedQty);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.calculateGroupedInvoiceTotals",
                    Severity.ERROR, e, SummaryMatchService.class);
        }
    }

    public void calculateGroupedReceiptTotals(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            double totalSelectedCost = 0;
            double totalSelectedQty = 0;
            double tempAvailableQty = 0;
            int arraySize = 0;
            ReceiptSummaryView[] receiptList = getSelectedGroupReceipts(summaryMatch);
            if (receiptList != null && receiptList.length > 0) {
                arraySize = receiptList.length;
                for (int i = 0; i < arraySize; i++) {
                    ReceiptSummaryView receipt = receiptList[i];
                    totalSelectedCost += ReIMMoney.parseCurrencyString(
                            receipt.getAvailableTotalMerchCost(),
                            summaryMatch.getSelectedCurrencyCode()).doubleValue();
                    tempAvailableQty = ReIMQuantity.parseNumberString(
                            receipt.getAvailableTotalQty()).doubleValue();
                    /* BRN V 1.5 Begin - removed
                    if (tempAvailableQty <= 0) {
                        tempAvailableQty = ReIMQuantity.parseNumberString(receipt.getTotalQty())
                                .doubleValue();
                    }
                    BRN V 1.5 End */
                    totalSelectedQty += tempAvailableQty;
                }
            }
            // Need to get currency to format properly
            summaryMatch.setReceiptGroupingCostTotal(totalSelectedCost);
            summaryMatch.setReceiptGroupingQtyTotal(totalSelectedQty);

        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.calculateGroupedReceiptTotals",
                    Severity.ERROR, e, SummaryMatchService.class);
        }
    }

    /**
     * Method: saveAutoGroup
     * 
     * This method compares the selected invoices and receipts to the original auto group list of
     * invoices and receipts. If either group has changed, the auto group is saved as a manual group
     * and removed from the original auto group map.
     * 
     * @param summaryMatch
     *            The summary match object from which the auto group map, and selected document maps
     *            are pulled.
     */
    public void saveAutoGroup(ISummaryMatch summaryMatch) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            final Map originalAutoMap = summaryMatch.getSummaryAutoGroupMap();
            final Map selectedInvoiceMap = summaryMatch.getSelectedGroupInvoiceMap();
            final Map selectedReceiptMap = summaryMatch.getSelectedGroupReceiptMap();
            final String ordlocKey = summaryMatch.getOrderNo() + '+' + summaryMatch.getLocationId();

            final UnmatchedAutoGroupView autoGroupView = (UnmatchedAutoGroupView) originalAutoMap
                    .get(ordlocKey);

            final MerchandiseDocument[] invoices = autoGroupView.getInvoiceGroup().getInvoices();
            final Receipt[] receipts = autoGroupView.getReceiptGroup().getReceipts();
            boolean saveGroup = false;
            // Check if selected size is different than original group size for
            // both
            // invoices and receipts.

            if (selectedInvoiceMap.size() == invoices.length
                    && selectedReceiptMap.size() == receipts.length) {
                // If both the invoice and receipt size are the same, check that
                // each value on the
                // original list is in the selected list.

                for (int i = 0; i < invoices.length; i++) {
                    final String id = Long.toString(invoices[i].getDocId());
                    if (!selectedInvoiceMap.containsKey(id)) {
                        saveGroup = true;
                        break;
                    }
                }
                if (!saveGroup) {
                    for (int i = 0; i < receipts.length; i++) {
                        final String id = receipts[i].getReceiptId();
                        if (!selectedReceiptMap.containsKey(id)) {
                            saveGroup = true;
                            break;
                        }
                    }
                }

            } else if (selectedInvoiceMap.isEmpty() && selectedReceiptMap.isEmpty()) {
                originalAutoMap.remove(ordlocKey);
            } else {
                saveGroup = true;
            }
            if (saveGroup) {
                // save the modified auto group to db, remove it from existing
                // auto group map.
                String manualGroupId = Long.toString(ManualGroupService.getNextGroupId());
                summaryMatch.setManualGroupId(manualGroupId);
                saveManualGroup(summaryMatch);
                originalAutoMap.remove(ordlocKey);
            }
        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.summaryMatchService.saveAutoGroup", Severity.ERROR,
                    SummaryMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    private List getUnmatchedReceiptList(ISummaryMatch summaryMatch) {
        List localTotalReceiptList = (List) summaryMatch.getTotalReceiptIdList().clone();
        if (summaryMatch.getAutoGroupReceiptIdList() != null) {
            localTotalReceiptList.removeAll(summaryMatch.getAutoGroupReceiptIdList());
        }
        if (summaryMatch.getManualGroupReceiptIdList() != null) {
            localTotalReceiptList.removeAll(summaryMatch.getManualGroupReceiptIdList());
        }

        return localTotalReceiptList;
    }

    private Set getReceiptSet(List receiptIdList) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            if (receiptIdList != null && receiptIdList.size() > 0) {
                Set receiptList = new HashSet();
                Receipt receipt;

                for (Iterator iterator = receiptIdList.iterator(); iterator.hasNext();) {
                    receipt = ReceiptService.getReceiptsForMatchingByReceiptId((String) iterator
                            .next());
                    receiptList.add(receipt);
                }
                return receiptList;
            } else
                return null;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.summaryMatchService.getReceipts", Severity.ERROR, e,
                    SummaryMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    public UnmatchedAutoGroupView[] getSummaryAutoGroups(ISummaryMatch summaryMatch)
            throws ReIMException {
        if (summaryMatch.getTotalInvoiceIdList() == null) { throw new ReIMException(
                "error.summaryMatchService.getSummaryAutoGroups.improperUse", Severity.DEBUG,
                SummaryMatchService.class);

        }
        if (summaryMatch.getSummaryAutoGroupMap() != null
                && summaryMatch.getSummaryAutoGroupMap().size() > 0) {
            Map summaryAutoGroupMap = summaryMatch.getSummaryAutoGroupMap();
            return (UnmatchedAutoGroupView[]) summaryAutoGroupMap.values().toArray(
                    new UnmatchedAutoGroupView[summaryAutoGroupMap.size()]);
        } else {
            return null;
        }
    }

    public ISummaryMatchDao getSummaryMatchDao() {
        return summaryMatchDao;
    }

    @Autowired
    @Required
    public void setSummaryMatchDao(ISummaryMatchDao summaryMatchDao) {
        this.summaryMatchDao = summaryMatchDao;
    }

    public IMatchStatusService getMatchStatusService() {
        return matchStatusService;
    }

    @Autowired
    @Required
    public void setMatchStatusService(IMatchStatusService matchStatusService) {
        this.matchStatusService = matchStatusService;
    }

    private IVarianceService getVarianceService() {
        return varianceService;
    }

    @Autowired
    public void setVarianceService(IVarianceService varianceService) {
        this.varianceService = varianceService;
    }

    public IMatchService getMatchService() {
        return matchService;
    }

    @Autowired
    public void setMatchService(IMatchService matchService) {
        this.matchService = matchService;
    }

    public IInvoiceDetailDao getInvoiceDetailDao() {
        return this.invoiceDetailDao;
    }

    @Autowired
    public void setInvoiceDetailDao(IInvoiceDetailDao invoiceDetailDao) {
        this.invoiceDetailDao = invoiceDetailDao;
    }

    public IInvoiceDetailService getInvoiceDetailService() {
        return invoiceDetailService;
    }

    @Autowired
    public void setInvoiceDetailService(IInvoiceDetailService invoiceDetailService) {
        this.invoiceDetailService = invoiceDetailService;
    }

}
