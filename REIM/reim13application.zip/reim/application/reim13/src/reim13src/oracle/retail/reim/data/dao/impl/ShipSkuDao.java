package oracle.retail.reim.data.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import oracle.retail.reim.business.tax.TaxTransactionType;
import oracle.retail.reim.business.tax.TransactionItemsTaxes;
import oracle.retail.reim.business.tax.TransactionItemsTaxesSearchCriteria;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.dao.IShipSkuDao;
import oracle.retail.reim.data.dao.ITaxDataDao;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.utils.SqlCriteriaBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.retek.reim.business.Item;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.ReceiptWriteOff;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.foundation.rms12.ShipSkuBean;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;

@Repository
public class ShipSkuDao extends SimpleJdbcDaoSupport implements IShipSkuDao {
    private ITaxDataDao taxDataDao;

    public void getReceiptTotalCostAndQty(Receipt[] receipts) {
        try {
            new ShipSkuBean().getReceiptTotalCostAndQty(receipts);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public TreeMap<String, Double> getItemQuantityAvailable(String[] receipts, String item) {
        try {
            return new ShipSkuBean().getItemQuantityAvailable(receipts, item);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public String validateUnmatchedReceiptItem(String itemId, String receiptId) {
        try {
            return new ShipSkuBean().validateUnmatchedReceiptItem(itemId, receiptId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public HashMap<String, Double> getUnmatchedReceiptAmountsByShipmentId(
            ReceiptWriteOff[] receiptWriteOffs) {
        try {
            return new ShipSkuBean().getUnmatchedReceiptAmountsByShipmentId(receiptWriteOffs);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void lockReceiptGroup(Receipt[] receipts) {
        try {
            new ShipSkuBean().lockReceiptGroup(receipts);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }
    
    public ReceiptItem read(Long shipmentId, String itemId) {
        try {
            return new ShipSkuBean().readReceiptItem(Long
					.toString(shipmentId), itemId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public DocumentItemInvoice[] getDocItemsFromReceipts(String[] receiptIds, boolean isCrossDockPO, ReIMDate invoiceDate) {
        try {
            if (receiptIds == null) { throw new ReIMException(
                    "error.shipsku_bean.get_receipt_items", Severity.ERROR, this); }

            // Build a comma delimited list of values for use in the SQL query
            StringBuffer receiptIdValues = new StringBuffer(receiptIds[0]);
            for (int i = 1; i < receiptIds.length; i++) {
                receiptIdValues.append(", ");
                receiptIdValues.append(receiptIds[i]);
            }
            

            // Build the SQL query
            StringBuffer sql = new StringBuffer();
            sql
                    .append(" SELECT s.item item,s.bill_to_loc loc, SUM (s.qty_received) avail_qty, s.unit_cost unit_cost, s.unit_cost_init unit_cost_init, s.vpn FROM  (SELECT ss.item,s.bill_to_loc , ss.unit_cost, ol.unit_cost_init, ss.qty_received, its.vpn FROM  shipment s, v_im_shipsku ss, ordhead oh, v_im_ordloc ol, sups sp, item_supplier its, (SELECT wh LOCATION, 'W' loc_type, physical_wh physical_loc FROM  wh UNION ALL SELECT STORE LOCATION, 'S' loc_type, STORE physical_loc FROM  STORE) l WHERE s.shipment = ss.shipment AND s.order_no = oh.order_no AND oh.supplier = sp.supplier AND oh.supplier = its.supplier AND ol.item = its.item AND s.bill_to_loc = l.LOCATION AND ol.order_no = oh.order_no AND ( ol.LOCATION IN ( SELECT wh FROM  wh WHERE physical_wh IN ( ");
                    		
            if(isCrossDockPO){
	            sql.append("SELECT to_loc FROM  shipment WHERE shipment IN ( ");
	                    		
	            sql.append(receiptIds[0]);
	            sql.append(" ))) OR ol.LOCATION = s.to_loc )  ");
            }
            else{
            	sql.append("SELECT bill_to_loc FROM  shipment WHERE shipment IN ( ");
        		
                sql.append(receiptIds[0]);
            	sql
                .append(" ))) OR ol.LOCATION = s.bill_to_loc )  ");
            }
            sql.append("AND ol.item = ss.item AND NVL(SS.INVC_MATCH_STATUS, 'U') IN ('U','P') AND s.shipment IN (");
            sql.append(receiptIdValues.toString());
            sql.append(" )) s GROUP BY s.item, s.unit_cost, s.unit_cost_init, s.vpn ,s.bill_to_loc");

            SqlCriteriaBuilder crit = new SqlCriteriaBuilder(sql.toString());
            final List<Long>locations = new ArrayList<Long>();
            List<DocumentItemsFromReceiptsRecord> records = this.getSimpleJdbcTemplate().query(
                    crit.toString(), new ParameterizedRowMapper<DocumentItemsFromReceiptsRecord>() {
                        public DocumentItemsFromReceiptsRecord mapRow(ResultSet rs, int rowNum)
                                throws SQLException {

                            DocumentItemsFromReceiptsRecord record = new DocumentItemsFromReceiptsRecord();

                            record.setItem(rs.getString("ITEM"));
                            locations.add(rs.getLong("LOC"));
                            record.setVpn(rs.getString("VPN"));
                            record.setUnitCost(rs.getDouble("UNIT_COST"));
                            record.setInitialUnitCost(rs.getDouble("UNIT_COST_INIT"));
                            record.setAvailableQty(rs.getDouble("AVAIL_QTY"));

                            return record;
                        }
                    }, crit.getParameterValuesAsArray());

            List<DocumentItemInvoice> docItemInvoices = new ArrayList<DocumentItemInvoice>();
            List<String> itemIds = new ArrayList<String>();

            for (DocumentItemsFromReceiptsRecord record : records) {
                DocumentItemInvoice docItem = new DocumentItemInvoice();

                itemIds.add(record.getItem());
                Item item = new Item(record.getItem(), null, record.getVpn());
                docItem.setItem(item);

                docItem.setUnitCost(record.getUnitCost());
                docItem.setInitialUnitCost(record.getInitialUnitCost());
                docItem.setQtyReceived(record.getAvailableQty());

                // get available to match quantity
                for (int i = 0; i < receiptIds.length; i++) {
                    Receipt rcpt = DaoFactory.getShipmentBean().readReceipt(receiptIds[i]);
                    if (rcpt != null && rcpt.getInvoiceMatchStatus() != null
                            && rcpt.getInvoiceMatchStatus().equalsIgnoreCase(Receipt.MATCHED)) {
                        docItem.setQty(docItem.getQty() + 0);
                    } else {
                        docItem.setQty(docItem.getQty()
                                + new ShipSkuBean().getAvailableToMatchQty(Long.valueOf(
                                        receiptIds[i]).longValue(), docItem.getItem().getItemId()));
                    }
                }
                docItemInvoices.add(docItem);
            }

            List<Long> receiptIdsLongs = new ArrayList<Long>();
            for (String receiptId : Arrays.asList(receiptIds)) {
                receiptIdsLongs.add(Long.valueOf(receiptId));
            }

            // Retrieve tax information from RMS
            TransactionItemsTaxesSearchCriteria searchCriteria = new TransactionItemsTaxesSearchCriteria();
            searchCriteria.setTaxTransactionType(TaxTransactionType.SHIPMENT);
            List<Long> transactionNumbers = new ArrayList<Long>();
            transactionNumbers.addAll(receiptIdsLongs);
            searchCriteria.setItems(itemIds);
            searchCriteria.setTransactionNumbers(transactionNumbers);
            searchCriteria.setLocations(locations);
            searchCriteria.setInvoiceDate(invoiceDate.getSQL_Date());
            List<TransactionItemsTaxes> transactionItems = getTaxDataDao()
                    .getTransactionItemsTaxes(searchCriteria);

            for (DocumentItemInvoice documentItemInvoice : docItemInvoices) {
                for (TransactionItemsTaxes transactionItemTaxAmount : transactionItems) {
                    transactionItemTaxAmount.getTaxAmountsSet(documentItemInvoice.getItemId());
                    documentItemInvoice.getTaxes().addAll(
                            transactionItemTaxAmount.getTaxAmountsSet(documentItemInvoice
                                    .getItemId()));
                }

            }

            DocumentItemInvoice[] docItemArray = null;
            if (docItemInvoices.size() > 0) {
                docItemArray = new DocumentItemInvoice[docItemInvoices.size()];
                docItemInvoices.toArray(docItemArray);
            }

            return docItemArray;
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    private class DocumentItemsFromReceiptsRecord {
        private String item;
        private String vpn;
        private Double unitCost;
        private Double initialUnitCost;
        private Double availableQty;

        public DocumentItemsFromReceiptsRecord() {
        }

        public String getItem() {
            return item;
        }

        public void setItem(String item) {
            this.item = item;
        }

        public String getVpn() {
            return vpn;
        }

        public void setVpn(String vpn) {
            this.vpn = vpn;
        }

        public Double getUnitCost() {
            return unitCost;
        }

        public void setUnitCost(Double unitCost) {
            this.unitCost = unitCost;
        }

        public Double getInitialUnitCost() {
            return initialUnitCost;
        }

        public void setInitialUnitCost(Double initialUnitCost) {
            this.initialUnitCost = initialUnitCost;
        }

        public Double getAvailableQty() {
            return availableQty;
        }

        public void setAvailableQty(Double availableQty) {
            this.availableQty = availableQty;
        }
    }

    public ITaxDataDao getTaxDataDao() {
        return taxDataDao;
    }

    @Autowired
    public void setTaxDataDao(oracle.retail.reim.data.dao.ITaxDataDao taxDataDao) {
        this.taxDataDao = taxDataDao;
    }
}
