package oracle.retail.reim.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.data.dao.IInvoiceDetailDao;
import oracle.retail.reim.data.dao.IOrderLocationDao;
import oracle.retail.reim.data.dao.IShipSkuDao;
import oracle.retail.reim.services.IDocumentDetailService;
import oracle.retail.reim.services.IDocumentService;
import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.services.matching.impl.DetailMatchService;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.DocumentItemInvoiceUtil;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.ImDocHeadAccessExt;
import com.retek.reim.foundation.AItemBean;
import com.retek.reim.foundation.AOrderLocationBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.invoiceMatch.DetailMatchInvoiceView;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2    14-May-2013   After performing the RCA, the Order and Receipt Unit cost was not refreshed in Detail Matching screen.
 */

@Service
public class InvoiceDetailService extends com.retek.reim.services.InvoiceDetailService implements
        IInvoiceDetailService {

    private IInvoiceDetailDao invoiceDetailDao;
    private IDocumentDetailService documentDetailService;
    private IDocumentService documentService;
    private IShipSkuDao shipSkuDao;
    private IOrderLocationDao orderLocationDao;

    public List<DocumentItemInvoice> readDetailsByDocId(final Long docId) {
        // return getInvoiceDetailDao().readDetailsByDocId(docId);
        return DocumentItemInvoiceUtil
                .mapImInvoiceDetailRowToDocumentItemInvoice(getInvoiceDetailDao()
                        .readDetailsByDocId(docId));
    }

    public void populateInvoiceItems(Document[] docs) throws ReIMException {
        try {
            for (int i = 0; i < docs.length; i++) {
                populateInvoiceItems(docs[i]);
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.document_service.populate_document_items",
                    Severity.ERROR, e, InvoiceDetailService.class);
        }
    }

    public void populateInvoiceItems(Document doc) throws ReIMException {
        try {
            List<DocumentItemInvoice> rows = getInvoiceDetailDao().readDetailsByDocId(
                    DocId.valueOf(doc.getDocId()));

            if (rows != null && rows.size() > 0) {
                HashMap<String, DocumentItemInvoice> docItems = new HashMap<String, DocumentItemInvoice>();

                for (int j = 0; j < rows.size(); j++) {
                    DocumentItemInvoice docItem = rows.get(j);

                    docItems.put(docItem.getItemId(), docItem);
                }

                doc.setDocDetail(docItems);
            }
        } catch (Exception e) {
            throw new ReIMException("error.document_service.populate_document_items",
                    Severity.ERROR, e, InvoiceDetailService.class);
        }
    }

    public void createInvoiceItems(DocumentItemInvoice[] documentItemInvoices, long docId)
            throws ReIMException {
        List<DocumentItemInvoice> documentItemInvoicesList = Arrays.asList(documentItemInvoices);

        boolean shouldProcessTax = ServiceFactory.getReIMSystemOptionsService().select()
                .isProcessTaxes();

        double unitCost = 0.0;//Double.MIN_VALUE;
        double docQty = 0.0;//Double.MIN_VALUE;
        for (DocumentItemInvoice documentItemInvoice : documentItemInvoicesList) {
            unitCost = documentItemInvoice.getUnitCost();
            docQty = documentItemInvoice.getQty();

            documentItemInvoice.setDocId(docId);
            documentItemInvoice.setResolutionAdjustedUnitCost(unitCost); // initialize
            // to
            // unit cost
            documentItemInvoice.setResolutionAdjustedQtyInvoiced(docQty); // initialize
            // to
            // invoice
            // qty
            documentItemInvoice.setStatus(DocumentItemInvoice.UNMATCHED);
            documentItemInvoice.setCostMatched(false);
            documentItemInvoice.setQtyMatched(false);
            documentItemInvoice.setAdjustmentPending(Affirm.NO_IND);

            if (!shouldProcessTax) {
                documentItemInvoice.setTaxes(Collections.EMPTY_SET);
            }
        }

        getInvoiceDetailDao().create(documentItemInvoicesList);
    }

    /**
     * The method will update the invoice items cost, quantity, resolution adjusted cost, and
     * resolution adjusted quantity. Invoice item's costs and qtys should not be updated unless the
     * invoice is in Ready-for-Match status.
     * 
     * @param DocumentItem
     *            [] updateItems
     */
    public void updateInvoiceItems(long invoiceId, DocumentItemInvoice[] updateItems)
            throws ReIMException {
        List<DocumentItemInvoice> documentItemInvoicesList = Arrays.asList(updateItems);

        double unitCost = Double.MIN_VALUE;
        double docQty = Double.MIN_VALUE;
        for (DocumentItemInvoice documentItemInvoice : documentItemInvoicesList) {
            unitCost = documentItemInvoice.getUnitCost();
            docQty = documentItemInvoice.getQty();

            documentItemInvoice.setResolutionAdjustedUnitCost(unitCost); // initialize
            // to
            // unit cost
            documentItemInvoice.setResolutionAdjustedQtyInvoiced(docQty); // initialize
            // to
            // invoice
            // qty
            documentItemInvoice.setStatus(DocumentItemInvoice.UNMATCHED);
        }
        getInvoiceDetailDao().update(documentItemInvoicesList);
    }

    public DocumentItemInvoice[] getInvoiceItemsByInvoiceId(long invoiceId, String currencyCode)
            throws ReIMException {
        try {
            List<DocumentItemInvoice> rows;
            AItemBean itemBean = (AItemBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AItemBean);
            DocumentItemInvoice[] documentItemInvoices;

            rows = getInvoiceDetailDao().readDetailsByDocId(DocId.valueOf(invoiceId));

            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            Map<String, String> itemVpnMap = null;
            if (systemOptions.isVpnItemLookup()) {

                MerchandiseDocument invc = new MerchandiseDocument(invoiceId);
                invc.setType(Document.MERCHANDISE_INVOICE);

                itemVpnMap = ServiceFactory.getItemSupplierService().getItemVpnMapForDocument(invc);
            }

            Document document = getDocumentService().read(new DocId(invoiceId));

            ArrayList<DocumentItemInvoice> docItems = new ArrayList<DocumentItemInvoice>();

            AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
			.getBean(ReIMBeanFactory.AOrderLocationBean);
            
            if (rows != null && rows.size() > 0) {
                for (int j = 0; j < rows.size(); j++) {
                    DocumentItemInvoice docItem = rows.get(j);
                    Document doc = DaoFactory.getImDocHeadAccessExt().read(docItem.getDocId());
                    
                    String itemId = docItem.getItemId();
                    String itemDesc = StringUtils.defaultString(itemBean.selectItemDesc(itemId));
                    String itemVpn = null;
                    if (systemOptions.isVpnItemLookup()) {
                        itemVpn = itemVpnMap.get(itemId);
                    }
                    Item item = new Item(itemId, itemDesc, itemVpn);
                    docItem.setItem(item);
                    
                    if (doc.getLocation().getLocationType().equals(Document.WAREHOUSE)) {
                    	
                    	
                    	String orderLocation = orderLocationBean.getPOLocationByOrderAndItem(doc.getOrderNo(),
        						docItem.getItemId(),doc.getLoc());
                    	
        				
        				if(orderLocation != null && orderLocation.length()>0)
        				{
        					Location location=new Location();
        					location.setLocationId(orderLocation);
        					document.setLocation(location);
        				}
        				
        			}


                    if (currencyCode != null) {
                        docItem.setCurrencyCode(currencyCode);
                    }

                    docItem.setDocument(document);

                    docItems.add(docItem);
                }
            }

            documentItemInvoices = (DocumentItemInvoice[]) docItems
                    .toArray(new DocumentItemInvoice[docItems.size()]);

            if (documentItemInvoices.length > 0) {
                getDocumentDetailService().getUnitCostInit(documentItemInvoices);
            }

            return documentItemInvoices;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.document_service.populate_document_items",
                    Severity.ERROR, e, InvoiceDetailService.class);
        }
    }

    public void buildInvoiceLines(MerchandiseDocument invoice) throws ReIMException {
        try {

            HashMap<String, DocumentItemInvoice> docDetails = new HashMap<String, DocumentItemInvoice>();
            invoice.setDocDetail(docDetails);

            // query invoice detail lines from the database
            List<DocumentItemInvoice> rows = getInvoiceDetailDao().readDetailsByDocId(
                    DocId.valueOf(invoice.getDocId()));

            if (rows == null || rows.size() == 0) return;

            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            Map<String, String> itemVpnMap = null;
            if (systemOptions.isVpnItemLookup()) {
                invoice.setType(Document.MERCHANDISE_INVOICE);// just to be
                // sure we have
                // the type
                // on the document
                itemVpnMap = ServiceFactory.getItemSupplierService().getItemVpnMapForDocument(
                        invoice);
            }
            int rowsLength = rows.size();
            // add invoice detail lines to the invoice docDetail hashmap
            for (int i = 0; i < rowsLength; i++) {
                DocumentItemInvoice documentItem = rows.get(i);
                String itemVpn = null;
                if (systemOptions.isVpnItemLookup()) {
                    itemVpn = itemVpnMap.get(documentItem.getItemId());
                }
                documentItem.getItem().setVpn(itemVpn);
                
                // Need document vendor and location info later for retreiving tax region info
                documentItem.setDocument(invoice);
                
                // add the invoice line to the invoice
                docDetails.put(documentItem.getItem().getItemId(), documentItem);
            }
        } catch (Exception e) {
            throw new ReIMException("error.build_invoice_lines", Severity.ERROR, e,
                    InvoiceDetailService.class);
        }
    }

    public DocumentItemInvoice buildInvoiceLine(DocumentItemInvoice invoice) throws ReIMException {
        try {
            // query invoice detail lines from the database
            List<DocumentItemInvoice> rows = getInvoiceDetailDao().readDetailsByDocIdAndItem(
                    DocId.valueOf(invoice.getDocId()), new Item(invoice.getItemId()));

            // Because of seach criteria only one row will be returned.  
            if (rows == null || rows.size() == 0) return invoice;

            DocumentItemInvoice documentItem = rows.get(0);
            documentItem.getItem().setItemName(invoice.getItem().getItemName());
            documentItem.setDocument(invoice.getDocument());
            // BRN V1.2 Begin - added
            setOrderItemUnitCost(documentItem);
            // BRN V1.2 End            
            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            Map<String, String> itemVpnMap = null;
            String itemVpn = null;
            if (systemOptions.isVpnItemLookup()) {

                MerchandiseDocument invc = new MerchandiseDocument(documentItem.getDocId());
                invc.setType(Document.MERCHANDISE_INVOICE);
                itemVpnMap = ServiceFactory.getItemSupplierService().getItemVpnMapForDocument(invc);
                itemVpn = itemVpnMap.get(documentItem.getItemId());
            }

            documentItem.getItem().setVpn(itemVpn);
            return documentItem;
        } catch (Exception e) {
            throw new ReIMException("error.build_invoice_line", Severity.ERROR, e,
                    InvoiceDetailService.class);
        }
    }

    public boolean isInvoiceLineMatched(DetailMatchInvoiceView documentView) throws ReIMException {
        try {
            DocumentItemInvoice itemInvoice = documentView.getDocumentItem();
            // query invoice detail lines from the database

            return getInvoiceDetailDao().checkInvoiceItemStatus(
                    DocId.valueOf(itemInvoice.getDocId()), new Item(itemInvoice.getItemId()));
        } catch (Exception e) {
            throw new ReIMException("error.invoice_detail_service.is_invoice_line_matched",
                    Severity.ERROR, e, InvoiceDetailService.class);
        }
    }

    public void deleteInvoiceItems(long docId, List<Item> itemList) throws ReIMException {
        try {
            getInvoiceDetailDao().deleteItemsPerInvoice(DocId.valueOf(docId), itemList);
        } catch (Exception ex) {
            throw new ReIMException("error.failed_to_delete_invoice_items", Severity.ERROR, ex,
                    InvoiceDetailService.class);
        }
    }

    public boolean invoiceDetailExists(String docId) throws ReIMException {
        try {
            return getInvoiceDetailDao().detailsExistforInvoice(DocId.valueOf(docId));
        } catch (Exception ex) {
            throw new ReIMException("error.DocumentService.documentDetailsExist", Severity.ERROR,
                    ex, InvoiceDetailService.class);
        }
    }

    public DocumentItemInvoice[] getInvoiceItemsFromReceipts(String[] receiptIds, boolean isCrossDockPO, ReIMDate invoiceDate)
            throws ReIMException {
        try {
            return getShipSkuDao().getDocItemsFromReceipts(receiptIds, isCrossDockPO, invoiceDate);
        } catch (Exception e) {
            throw new ReIMException("error.DocumentService.getDocItemsFromReceipts",
                    Severity.ERROR, e, InvoiceDetailService.class);
        }
    }

    public DocumentItemInvoice[] getInvoiceItemsFromOrderLocation(String orderNo, String locationId,ReIMDate invoiceDate)
            throws ReIMException {
        try {
            DocumentItemInvoice[] items = getOrderLocationDao().getDocumentItemsFromOrderLocation(
                    orderNo, locationId,invoiceDate);
            return items;
        } catch (Exception e) {
            throw new ReIMException("error.DocumentService.getDocItemsFromOrderLocation",
                    Severity.ERROR, e, InvoiceDetailService.class);
        }
    }
    
    // BRN V1.2 Begin - added
    private/* static */void setOrderItemUnitCost(DocumentItemInvoice invoiceItem)
            throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            String orderNo = invoiceItem.getDocument().getOrderNo();
            Location location = new Location(invoiceItem.getDocument().getLocation()
                    .getLocationId(), "", "");
            String itemId = invoiceItem.getItem().getItemId();
            AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AOrderLocationBean);
            POItemLocation poItemLocation = orderLocationBean.getPOItemLocation(orderNo, location,
                    itemId);
            try // in case the item is not on the order
            {
                invoiceItem.setOrderUnitCost(poItemLocation.getUnitCost());
            } catch (NullPointerException ne) {
                invoiceItem.setOrderUnitCost(0);
            }
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_set_order_item_unit_cost",
                    Severity.ERROR, e, DetailMatchService.class);
        }/*
          * finally { TransactionManagerFactory.getInstance().end(); }
          */
    }
    // BRN V1.2 End
    
    public DocumentItemInvoice[] getInvoiceItemsByInvoiceId(DocId invoiceId) throws ReIMException {
        return getInvoiceItemsByInvoiceId(invoiceId.toLong());
    }

    public DocumentItemInvoice[] getInvoiceItemsByInvoiceId(DocId invoiceId, String currencyCode)
            throws ReIMException {
        return getInvoiceItemsByInvoiceId(invoiceId.toLong(), currencyCode);
    }

    public DocumentItemInvoice[] getInvoiceItemsByInvoiceId(String invoiceId, String currencyCode)
            throws ReIMException {
        return getInvoiceItemsByInvoiceId(Long.parseLong(invoiceId), currencyCode);
    }

    public DocumentItemInvoice[] getInvoiceItemsByInvoiceId(long invoiceId) throws ReIMException {
        return getInvoiceItemsByInvoiceId(invoiceId, null);
    }

    public DocumentItemInvoice[] getInvoiceItemsByInvoiceId(String invoiceId) throws ReIMException {
        return getInvoiceItemsByInvoiceId(invoiceId, null);
    }

    public IInvoiceDetailDao getInvoiceDetailDao() {
        return invoiceDetailDao;
    }

    @Autowired
    public void setInvoiceDetailDao(IInvoiceDetailDao invoiceDetailDao) {
        this.invoiceDetailDao = invoiceDetailDao;
    }

    public IDocumentDetailService getDocumentDetailService() {
        return documentDetailService;
    }

    @Autowired
    public void setDocumentDetailService(IDocumentDetailService documentDetailService) {
        this.documentDetailService = documentDetailService;
    }

    public IDocumentService getDocumentService() {
        return documentService;
    }

    @Autowired
    public void setDocumentService(IDocumentService documentService) {
        this.documentService = documentService;
    }

    public IShipSkuDao getShipSkuDao() {
        return shipSkuDao;
    }

    @Autowired
    public void setShipSkuDao(IShipSkuDao shipSkuDao) {
        this.shipSkuDao = shipSkuDao;
    }

    public IOrderLocationDao getOrderLocationDao() {
        return orderLocationDao;
    }

    @Autowired
    public void setOrderLocationDao(IOrderLocationDao orderLocationDao) {
        this.orderLocationDao = orderLocationDao;
    }
}