package oracle.retail.reim.services.posting.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.business.Account;
import oracle.retail.reim.business.AccountSegment;
import oracle.retail.reim.business.AccountStatus;
import oracle.retail.reim.business.AccountType;
import oracle.retail.reim.business.DocumentStatus;
import oracle.retail.reim.business.PostingDocument;
import oracle.retail.reim.business.PostingDocumentAmount;
import oracle.retail.reim.business.PostingDocumentAmountType;
import oracle.retail.reim.business.PostingDocumentError;
import oracle.retail.reim.business.PostingParameters;
import oracle.retail.reim.business.PostingStatus;
import oracle.retail.reim.business.PostingTranCode;
import oracle.retail.reim.business.SetOfBooks;
import oracle.retail.reim.business.SystemOptions;
import oracle.retail.reim.data.dao.IFinancialPostingAccountDao;
import oracle.retail.reim.data.dao.IFinancialPostingDao;
import oracle.retail.reim.data.dao.IFinancialPostingDao.SelectSumOfAmountsParam.BasicCriteria;
import oracle.retail.reim.data.dao.IFinancialPostingDao.SelectSumOfAmountsParam.CriteriaTax;
import oracle.retail.reim.services.IAccountService;
import oracle.retail.reim.services.IDocumentService;
import oracle.retail.reim.services.IFinancialPostingAccountService;
import oracle.retail.reim.services.IReceiptService;
import oracle.retail.reim.services.ServiceAccessException;
import oracle.retail.reim.services.posting.IDocumentPostingService;
import oracle.retail.reim.services.posting.IFinancialPostingStagingService;
import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.Severity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.services.ISystemOptionsService;
import com.retek.reim.services.SystemOptionsService;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue Description
 * ======= ========= =========== ========= ========================================================
 *    1.1		13-May-2013	Syed Qadri		Commented out the Logger.error to display information as only information. IMS Ticket #154282.
 */

@Service
public abstract class ADocumentPostingService implements IDocumentPostingService {
    private IFinancialPostingDao financialPostingDao;
	private IFinancialPostingAccountDao financialPostingAccountDao;
    private IFinancialPostingStagingService financialPostingStagingService;
    private IFinancialPostingAccountService financialPostingAccountService;
    private IAccountService accountService;
    private IDocumentService documentService;
    private IReceiptService receiptService;
    private ISystemOptionsService systemOptionsService;
    protected ReIMSystemOptions reIMSystemOptions;
    
    public PostingStatus beginPostingProcess(PostingParameters config, String description) {
        PostingStatus status = getFinancialPostingDao().beginPostingProcess(config, description);
        return status;
    }

    public List<PostingDocument> getPostingDocuments(PostingStatus.Id postingStatusId) {
        return getFinancialPostingDao()
                .getPostingDocuments(postingStatusId, null, null, null, null);
    }

    public List<PostingDocumentAmount> getPostingDocumentAmounts(PostingStatus.Id postingStatusId) {
        return getFinancialPostingDao().getPostingDocumentAmounts(postingStatusId, null, null);
    }

    public List<PostingDocumentError> getPostingDocumentErrors(PostingStatus.Id postingStatusId) {
        return getFinancialPostingDao().getPostingDocumentErrors(postingStatusId, null);
    }

    public PostingStatus refreshStatus(PostingStatus status) {
        getFinancialPostingDao().refreshPostingStatus(status);
        return status;
    }

    private void logInValidAccountsInformation(Map<SetOfBooks,List<Account>> accountsMap) {
    	
    	Set<SetOfBooks> sobIds = accountsMap.keySet();
    	for (SetOfBooks sobId : sobIds) {
    		for (Account account : accountsMap.get(sobId)) {
    			
    			if (!AccountStatus.isValidAccount(account.getStatus())) { 
    		    	StringBuffer segments = new StringBuffer();
    				for (AccountSegment segment : account.getSegments()) {
	    				segments.append(" Segment"+segment.getNum()+"--->"+segment.getValue());
	    			}
	    			
	    			Logger.error(this, "Set Of books Id --->" + sobId.getSetOfBooksId()
	    							+ " Account Type --->" + account.getType().getCode()
	    							+ " Account Code --->" + account.getCode()
	    							+ segments.toString()
	    							+ " Account Status--->" + account.getStatus().getCode());
	    			}
    			}
    	}
    }
    public PostingStatus endPostingProcess(PostingStatus status) {
        PostingStatus newStatus = null;

        newStatus = balancePostingNumbers(status);

        logPostingStatus(status, newStatus);

        updateDocumentStatus(status);

        newStatus = endPostingStatus(status);

        cleanUpWorkspace(status);

        return newStatus;
    }

    protected PostingStatus balancePostingNumbers(PostingStatus status) {
        PostingStatus newStatus;
        // Check the balance of the amounts...
        Logger.info(this, "Verifying posted amounts balance... ");
        newStatus = getFinancialPostingStagingService().checkStagedFinancialRowsBalance(status);
        return newStatus;
    }

    protected void logPostingStatus(PostingStatus status, PostingStatus newStatus) {
        if (newStatus.isHasErrors()) {
            logPostingTableContents(Severity.ERROR, status);

            Logger.error(this, "Posting yielded errors. Removing affected staged financial rows.");

            getFinancialPostingStagingService().deleteStagedFinancialRowsWithErrors(status);
        } else if (Logger.isDebugEnabled(this.getClass())) {
            logPostingTableContents(Severity.DEBUG, status);

        }
    }

    protected void updateDocumentStatus(PostingStatus status) {
        // Update the status to POSTED for those with no errors.
        Logger.info(this, "Updated status of documents.");
        getFinancialPostingDao().updateActualDocs(status.getId(), null, null, null,
                DocumentStatus.POSTED, false, null);
    }

    protected PostingStatus endPostingStatus(PostingStatus status) {
        PostingStatus newStatus;
        newStatus = getFinancialPostingDao().endPostingStatus(status);
        return newStatus;
    }

    protected void cleanUpWorkspace(PostingStatus status) {
        if (status.getParameters().isCleanUpPostingDocumentTemporaryTables()) {
            Logger.info(this, "Removing workspace rows for successfully posted documents.");
            getFinancialPostingDao().deletePostingAmountsWithNoErrors(status.getId(), null);
            getFinancialPostingAccountDao().deletePostingAccountsWithNoErrors(status.getId(), null);
            getFinancialPostingDao().deletePostingDocsWithNoErrors(status.getId(), null);
        }
    }


    protected void logPostingTableContents(Severity severity, PostingStatus status) {
        // OLR V1.1 Inserted - Begin
        //Logger.error(this, "Dispalying results for posting_id "+status.getId().getPostingId()+".   Displaying attempted posting rows:  ");
        Logger.log(severity,this, "Dispalying results for posting_id "+status.getId().getPostingId()+".   Displaying attempted posting rows:  ");
        // OLR V1.1 Inserted - End
        
        try {
            getFinancialPostingDao().logPostingResults(severity, status.getId().getPostingId(), this.getClass());
        }
        catch (Throwable ex) {
            Logger.error("Unable to display posting rows.  ", ex);
        }
    }

    public IFinancialPostingAccountDao getFinancialPostingAccountDao() {
        return financialPostingAccountDao;
    }

    @Required
    @Autowired
    public void setFinancialPostingAccountDao(IFinancialPostingAccountDao financialPostingAccountDao) {
        this.financialPostingAccountDao = financialPostingAccountDao;
    }

    protected void postNonMerch(PostingStatus postingStatus, List<PostingDocumentAmount> staged) {

        IFinancialPostingDao.SelectSumOfAmountsParam param = new IFinancialPostingDao.SelectSumOfAmountsParam();
        

        BasicCriteria sumCriteria = new BasicCriteria();
        sumCriteria.setPostingStatus(postingStatus.getId());
        sumCriteria.setAmountTypes(PostingDocumentAmountType.NON_MERCHANDISE_COST);
        param.addCriteria(sumCriteria);
        staged.addAll(createPostingEntries(PostingTranCode.NON_MERCHANDISE_TYPES_FROM_DOC,
                getFinancialPostingDao().selectSumOfAmounts(param)));

    }
    
    protected void postTax(PostingStatus postingStatus, List<PostingDocumentAmount> staged) {

    	//tax for Merchandise Invoice
    	IFinancialPostingDao.SelectSumOfAmountsParam param = new IFinancialPostingDao.SelectSumOfAmountsParam();

    	CriteriaTax sumCriteria = new CriteriaTax();
        sumCriteria.setPostingStatus(postingStatus.getId());
        sumCriteria.setAccountCode(PostingTranCode.TAX.getCode());
        sumCriteria.setAmountTypes(PostingDocumentAmountType.TAX_AMOUNT);
        

        param.addCriteria(sumCriteria);
        staged.addAll(createPostingEntries(PostingTranCode.TAX,
                getFinancialPostingDao().selectSumOfAmounts(param)));
        
        // tax for NonMerch components
        
        param = new IFinancialPostingDao.SelectSumOfAmountsParam();

        sumCriteria = new CriteriaTax();
        sumCriteria.setPostingStatus(postingStatus.getId());
        sumCriteria.setAmountTypes(PostingDocumentAmountType.TAX_AMOUNT);
        
        sumCriteria.setAccountCode(PostingTranCode.TAX_NON_DYNAMIC.getCode());
        param.addCriteria(sumCriteria);
        staged.addAll(createPostingEntries(PostingTranCode.TAX_NON_DYNAMIC,
                getFinancialPostingDao().selectSumOfAmounts(param)));

    }

    protected List<PostingDocumentAmount> createPostingEntries(final PostingTranCode tranCode,
            List<PostingDocumentAmount> amounts) {

        List<PostingDocumentAmount> staged = new ArrayList<PostingDocumentAmount>();

        List<PostingDocumentAmount> validAmounts = new ArrayList<PostingDocumentAmount>();

        // Take amounts with valid accounts and add them to the list
		for (final PostingDocumentAmount amount : amounts) {
			Account account = amount.getAccount();
			if (account == null) {

				new FinancialPostingExceptionHandlerCommand<Account>(
						getClass(), amount.getId().getPostingStatusId(), amount
								.getDocId(), getFinancialPostingDao()) {

					@Override
					protected Account doPostingActivities() throws Throwable {

						String accountCode = resolveAccountCode(tranCode,
								amount);

						logPostingError(PostingDocumentError.Category.ACCOUNTS,
								"Unable to retrieve segments for Account Type "
										+ tranCode.getAccountType()
										+ " for docId "
										+ amount.getDocId()
										+ " for code "
										+ accountCode
										+ " for set of books "
										+ amount.getSetOfBooks()
												.getSetOfBooksId());
						return null;
					}
				}.execute();

				continue;
			}

			validAmounts.add(amount);
		}

        // Save posting entries...
        staged.addAll(getFinancialPostingStagingService().stage(validAmounts));

        return staged;
    }

    protected String resolveAccountCode(PostingTranCode tranCode, PostingDocumentAmount amount) {
        String accountCode = null;
        if (AccountType.BASIC_TRANSACTIONS.equals(tranCode.getAccountType())) {
            return tranCode.getCode();
        } else if (AccountType.NON_MERCH_CODES.equals(tranCode.getAccountType())) {
            accountCode = amount.getNonMerchandiseCode();
        } else if (AccountType.REASON_CODE_ACTIONS.equals(tranCode.getAccountType())) {
            accountCode = amount.getReasonCode();
        } else {
            throw new ServiceAccessException(
                    "Cannot resolve account code for an unknown account type : "
                            + tranCode.getAccountType());
        }

        return accountCode;
    }
    
    protected void loadAndValidateAccounts(PostingStatus status) {
    	Logger.info(this,"Loading accounts");
    	getFinancialPostingAccountDao().loadAccounts(status.getId(), false);
    	Logger.info(this,"Retrieving accounts for validation");
    	Map<SetOfBooks,List<Account>> accountsMap = getFinancialPostingAccountDao().retrieveAcctsForValidation(status.getId());
    	if (accountsMap != null && !accountsMap.isEmpty()) {
    		Logger.info(this,"Validating accounts");
    		getFinancialPostingAccountService().validateAccounts(accountsMap);
    		logInValidAccountsInformation(accountsMap);
    		Logger.info(this,"Updating accounts status");
    		getFinancialPostingAccountDao().updateAccountStatus(status.getId(), accountsMap);
    	}
    }
    
    public String getPrimCurrencyCode() {
    	String currencyCode = null;
    	try {
    		SystemOptions systemOptions = getSystemOptionsService().getSystemOptions();
    		boolean msobInd = systemOptions.isMsobInd();
    		
    		if (!msobInd) {
    			currencyCode =  systemOptions.getCurrencyCode();
    		}
    	 } catch (ReIMException e) {
             throw new ServiceAccessException(e);
         }
    	 
    	 return currencyCode;
    }
    
    public IAccountService getAccountService() {
        return accountService;
    }

    @Required
    @Autowired
    public void setAccountService(IAccountService accountService) {
        this.accountService = accountService;
    }

    public IFinancialPostingStagingService getFinancialPostingStagingService() {
        return financialPostingStagingService;
    }

    @Required
    @Autowired
    public void setFinancialPostingAccountService(
            IFinancialPostingAccountService financialPostingAccountService) {
        this.financialPostingAccountService = financialPostingAccountService;
    }

    public IFinancialPostingAccountService getFinancialPostingAccountService() {
        return financialPostingAccountService;
    }

    @Required
    @Autowired
    public void setFinancialPostingStagingService(
            IFinancialPostingStagingService financialPostingStageRepositoryService) {
        this.financialPostingStagingService = financialPostingStageRepositoryService;
    }
    
    public ISystemOptionsService getSystemOptionsService() {
    	if (this.systemOptionsService == null)  {
        	this.systemOptionsService = new SystemOptionsService();
        }
    	
        return systemOptionsService;
    }

    public void setSystemOptionsService(ISystemOptionsService systemOptionsService) {
        this.systemOptionsService = systemOptionsService;
    }
    
 
    public IDocumentService getDocumentService() {
        return documentService;
    }
  
    public IFinancialPostingDao getFinancialPostingDao() {
        return financialPostingDao;
    }

    @Required
    @Autowired
    public void setFinancialPostingDao(IFinancialPostingDao financialPostingDao) {
        this.financialPostingDao = financialPostingDao;
    }

    @Required
    @Autowired
    public void setDocumentService(IDocumentService documentService) {
        this.documentService = documentService;
    }

    public IReceiptService getReceiptService() {
        return receiptService;
    }

    @Required
    @Autowired
    public void setReceiptService(IReceiptService receiptService) {
        this.receiptService = receiptService;
    }

    public ReIMSystemOptions getReIMSystemOptions() {
        if (reIMSystemOptions == null) return ReIMSystemOptions.getInstance();
        return reIMSystemOptions;
    }

    public void setReIMSystemOptions(ReIMSystemOptions systemOptions) {
        this.reIMSystemOptions = systemOptions;
    }

}
