package oracle.retail.reim.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.business.DocumentType;
import oracle.retail.reim.business.ResolutionActionCode;
import oracle.retail.reim.business.Variance;
import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.document.HoldStatus;
import oracle.retail.reim.business.tax.ItemLocationTaxes;
import oracle.retail.reim.business.tax.ItemTaxCalcCriteria;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.tax.TaxTransactionType;
import oracle.retail.reim.data.dao.IDocumentDao;
import oracle.retail.reim.data.dao.IDocumentDetailDao;
import oracle.retail.reim.data.dao.IDocumentTaxDao;
import oracle.retail.reim.data.dao.IInvoiceDetailDao;
import oracle.retail.reim.data.dao.IResolutionActionDao;
import oracle.retail.reim.data.dao.ITaxCalculationDao;
import oracle.retail.reim.data.dao.IVarianceDao;
import oracle.retail.reim.data.dao.impl.DocumentTaxDao.DocumentTaxesRecord;
import oracle.retail.reim.services.IDateTimeService;
import oracle.retail.reim.services.IDocumentHoldingService;
import oracle.retail.reim.services.IDocumentService;
import oracle.retail.reim.services.IReasonCodeActionRollupService;
import oracle.retail.reim.services.ISupplierOptionsService;
import oracle.retail.reim.services.ServiceAccessException;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.merch.utils.Quantity;
import com.retek.reim.business.Item;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ResolutionMerchandiseInvoice;
import com.retek.reim.business.SupplierOptions;
import com.retek.reim.business.Term;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.DocumentItemReasonCode;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.document.ResolutionAction;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ITermsService;
import com.retek.reim.services.ServiceFactory;

/**
 * This service provides debit memo/credit memo creation rollup for an invoice. It also provides
 * verification of completion of receiver adjustments in RMS. This class wasn't rewritten, just
 * retrofitted since it could be moved to PL/SQL.
 */
@SuppressWarnings("deprecation")
@Service
public class ReasonCodeActionRollupService implements IReasonCodeActionRollupService {

    private IDocumentDao documentDao;
    private IDocumentDetailDao documentDetailDao;
    private IDocumentTaxDao documentTaxDao;
    private IInvoiceDetailDao invoiceDetailDao;
    private IResolutionActionDao resolutionActionDao;
    private IVarianceDao varianceDao;

    private IDateTimeService dateTimeService;
    private IDocumentService documentService;
    private IDocumentHoldingService invoiceHoldingService;
    private ISupplierOptionsService supplierOptionsService;
    private ITermsService termsService = ServiceFactory.getTermsService(); // Legacy

    // service
    private ITaxCalculationDao taxCalculationDao;

    public Collection<ImDocHeadRow> rollup() {
        List<ResolutionAction> actions = resolutionActionDao.getRollupActions();
        return rollup(actions);
    }

    public Collection<ImDocHeadRow> rollup(DocId docId) {
        List<ResolutionAction> actions = resolutionActionDao.getRollupActions(docId);
        return rollup(actions);
    }

    public Collection<ImDocHeadRow> rollup(List<ResolutionAction> actions) {

        try {
            List<ImDocHeadRow> rollupDocs = new ArrayList<ImDocHeadRow>();
            List<DocumentItemReasonCode> rollupDetails = new ArrayList<DocumentItemReasonCode>();
            Map<String, DocumentTaxesRecord> rollupTaxes = new HashMap<String, DocumentTaxesRecord>();
            Map<DocId, List<ResolutionAction>> debitMemoQuantity = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> debitMemoCost = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> debitMemoTax = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> creditMemoQuantity = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> creditMemoCost = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> creditNoteRequestQuantity = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> creditNoteRequestCost = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> creditNoteRequestTax = new HashMap<DocId, List<ResolutionAction>>();
            Map<DocId, List<ResolutionAction>> varianceAdjustments = new HashMap<DocId, List<ResolutionAction>>();
            
            //documentService.updateBestTermsDataForMatchedInvoices();            

            if (CollectionUtils.isNotEmpty(actions)) {

                Map<DocId, Document> documents = resolutionActionDao.readDocumentsForRollup();

                Map<String, SupplierOptions> supplierOptions = createDocumentLists(actions,
                        documents, debitMemoQuantity, debitMemoCost, debitMemoTax,
                        creditMemoQuantity, creditMemoCost, creditNoteRequestQuantity,
                        creditNoteRequestCost, creditNoteRequestTax, varianceAdjustments);

                createDocuments(documents, //
                        debitMemoQuantity, //
                        Document.DEBIT_MEMO_QUANTITY, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                createDocuments(documents, //
                        debitMemoCost, //
                        Document.DEBIT_MEMO_PRICE, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                createDocuments(documents, //
                        debitMemoTax, //
                        Document.DEBIT_MEMO_TAX, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                createDocuments(documents, //
                        creditMemoQuantity, //
                        Document.CREDIT_MEMO_QUANTITY, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                createDocuments(documents, //
                        creditMemoCost, //
                        Document.CREDIT_MEMO_PRICE, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                createDocuments(documents, //
                        creditNoteRequestQuantity, //
                        Document.CREDIT_NOTE_REQUEST_QUANTITY, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, supplierOptions);

                createDocuments(documents, creditNoteRequestCost, //
                        Document.CREDIT_NOTE_REQUEST_PRICE, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                createDocuments(documents, //
                        creditNoteRequestTax, //
                        Document.CREDIT_NOTE_REQUEST_TAX, //
                        rollupDocs, //
                        rollupDetails, //
                        rollupTaxes, //
                        supplierOptions);

                // save new documents
                documentDao.createUsingProvidedDocId(rollupDocs);

                // save new document details

                documentDetailDao.create(rollupDetails);

                // set resolution actions status to 'Rolled-up'
                updateRolledUpActionsStatus(actions);

                // save tax rows
                if (MapUtils.isNotEmpty(rollupTaxes)) {
                    documentTaxDao.createDocumentTaxes((rollupTaxes.values()));
                }
            }
            invoiceHoldingService.holdDocumentsAfterRollup(rollupDocs);

            /*
             * Update the custom fields in the DB for RolledUp documents At this time, the logic in
             * the DB makes sure to only update CNR custom fields
             */

            documentService.updateDocumentCustomFields(rollupDocs);

            /**
             * Return the newly created document rows.
             */
            return rollupDocs;
        } catch (Exception ex) {
            throw new ServiceAccessException(ex);
        }
    }

    /**
     * This method places all of the document header information for the documents with memos or
     * note requests to roll up in the appropriate hashmap. All of the parameters, excepting
     * actionRows and documents, are basically return values.
     */
    protected Map<String, SupplierOptions> createDocumentLists(List<ResolutionAction> actionRows,
            Map<DocId, Document> documents, Map<DocId, List<ResolutionAction>> debitMemoQuantity,
            Map<DocId, List<ResolutionAction>> debitMemoCost,
            Map<DocId, List<ResolutionAction>> debitMemoTax,
            Map<DocId, List<ResolutionAction>> creditMemoQuantity,
            Map<DocId, List<ResolutionAction>> creditMemoCost,
            Map<DocId, List<ResolutionAction>> creditNoteRequestQuantity,
            Map<DocId, List<ResolutionAction>> creditNoteRequestCost,
            Map<DocId, List<ResolutionAction>> creditNoteRequestTax,
            Map<DocId, List<ResolutionAction>> varianceAdjustments) throws ReIMException {

        Map<String, SupplierOptions> supplierOptions = new HashMap<String, SupplierOptions>();

        for (ResolutionAction row : actionRows) {

            Document document = documents.get(row.getDocId());
            String vendor = document.getVendor().getVendorId();

            SupplierOptions options = supplierOptions.get(vendor);

            if (options == null) {
                options = supplierOptionsService.getOptions(vendor);
                supplierOptions.put(vendor, options);
            }

            String action = row.getAction();

            if (action.equals(ResolutionMerchandiseInvoice.CBC)) {
                if (options.isAlwaysSendDebitMemo()) {
                    addRowToHashMap(debitMemoCost, row);
                } else {
                    addRowToHashMap(creditNoteRequestCost, row);
                }
            } else if (action.equals(ResolutionMerchandiseInvoice.CBQ)) {
                if (options.isAlwaysSendDebitMemo()) {
                    addRowToHashMap(debitMemoQuantity, row);
                } else {
                    addRowToHashMap(creditNoteRequestQuantity, row);
                }
            } else if (action.equals(ResolutionMerchandiseInvoice.DMTF)
                    || action.equals(ResolutionMerchandiseInvoice.DMTI)) {
                if (options.isAlwaysSendDebitMemo()) {
                    addRowToHashMap(debitMemoTax, row);
                } else {
                    addRowToHashMap(creditNoteRequestTax, row);
                }
            } else if (action.equals(ResolutionMerchandiseInvoice.CNRTF)
                    || action.equals(ResolutionMerchandiseInvoice.CNRTI)) {

                if (document.getType().equals(Document.CREDIT_NOTE))
                    addRowToHashMap(creditMemoCost, row);

            } else if (action.equals(ResolutionMerchandiseInvoice.CMC)) {
                addRowToHashMap(creditMemoCost, row);
            } else if (action.equals(ResolutionMerchandiseInvoice.CMQ)) {
                addRowToHashMap(creditMemoQuantity, row);
            } else if (action.equals(ResolutionMerchandiseInvoice.RCA)
                    || action.equals(ResolutionMerchandiseInvoice.RCAS)
                    || action.equals(ResolutionMerchandiseInvoice.RUA)
                    || action.equals(ResolutionMerchandiseInvoice.SR)
                    || action.equals(ResolutionMerchandiseInvoice.MR)) {
                /**
                 * If the action is Receiver cost adjustment, receiver cost adjustment supplier,
                 * receiver unit adjustment, split receipt, or match to receipt, then a variance
                 * adjustment is required.
                 */
                addRowToHashMap(varianceAdjustments, row);
            }
        }
        return supplierOptions;
    }

    /**
     * This helper method adds a key to a hashmap if it doesn't exist, or updates its value if the
     * key does exist.
     * 
     * @param map
     *            Hashmap to add key/value to.
     * @param row
     *            Key/value information
     */
    protected void addRowToHashMap(Map<DocId, List<ResolutionAction>> map, ResolutionAction row) {
        DocId docId = row.getDocId();

        List<ResolutionAction> rows = map.get(docId);

        if (rows == null) {
            rows = new ArrayList<ResolutionAction>();
            map.put(docId, rows);
        }

        rows.add(row);
    }

    /**
     * This method rolls up the information for any type of document.
     * 
     * @param documents
     *            Collection of documents with memos/requests being rolled up.
     * @param resolutions
     *            Collection of resolution actions to be rolled up.
     * @param rollupDocs
     *            Final rolled up documents to be created by another method,
     * @param resolutionDocType
     *            Type of rolled up document to be created.
     * @throws ReIMException
     */
    protected void createDocuments(Map<DocId, Document> documents,
            Map<DocId, List<ResolutionAction>> resolutions, String resolutionDocType,
            List<ImDocHeadRow> rollupDocs, List<DocumentItemReasonCode> rollupDetails,
            Map<String, DocumentTaxesRecord> rollupTaxes, Map<String, SupplierOptions> supplierOptions)
            throws ReIMException {

        ReIMSystemOptions options = ReIMUserContext.getSystemOptions();

        for (Map.Entry<DocId, List<ResolutionAction>> entry : resolutions.entrySet()) {

            DocId docId = entry.getKey();
            List<ResolutionAction> resolutionActionRows = entry.getValue();

            Document dicrepantDocument = documents.get(docId);

            ImDocHeadRow resolutionDocHeadRow = buildResolutionDocHeadRow(dicrepantDocument,
                    resolutionDocType, options);

            Quantity docCost = new Quantity(0);
            Quantity docCostIncTax = new Quantity(0);
            Map<String, Quantity> quantities = new HashMap<String, Quantity>();

            Map<String, DocumentTaxesRecord> docTaxes = new HashMap<String, DocumentTaxesRecord>();

            for (ResolutionAction resolutionActionRow : resolutionActionRows) {

                /* ImDocDetailReasonCodesRow detailRow */
                DocumentItemReasonCode resolutionDocItemReasonCode = buildDocumentItemReasonCode(
                        resolutionActionRow, resolutionDocHeadRow, resolutionDocType,
                        dicrepantDocument.getType());
                Quantity docQty = (Quantity) quantities.get(resolutionActionRow.getItemId());

                /**
                 * Keep track of docQty by item to avoid adding multiple invoice values in the case
                 * of cost memo
                 */
                if (docQty == null) {
                    docQty = new Quantity(0);
                }

                docQty = docQty.add(resolutionDocItemReasonCode.getAdjustedQty());
                quantities.put(resolutionActionRow.getItemId(), docQty);

                Quantity extendedCost = new Quantity(resolutionDocItemReasonCode
                        .getAdjustedUnitCost());
                extendedCost = extendedCost.multiply(resolutionDocItemReasonCode.getAdjustedQty());
                docCost = docCost.add(extendedCost);
                docCostIncTax = docCostIncTax.add(extendedCost);

                if (ReIMUserContext.getSystemOptions().isProcessTaxes()) {
                    
                    Set<Tax> taxes = resolutionDocItemReasonCode.getTaxes();
                    Set<Tax> rollupItemTaxes =null;
                    
                    if(taxes != null && taxes.size()>0)
                    {
                    	rollupItemTaxes= new HashSet<Tax>();
                    }

                    for (Tax aTax : taxes) {
                        docCostIncTax = docCostIncTax.add(extendedCost
                                .multiply(aTax.getTaxRate() / 100.0));
                        
                        double rollupTaxAmount=extendedCost.multiply(aTax.getTaxRate() / 100.0).doubleValue();

                        Tax detailRcTax= new Tax();
                        
                        if (aTax.getTaxCode() != null) {

                            if (docTaxes.containsKey(aTax.getTaxCode())) {
                            	DocumentTaxesRecord existingRow = ((DocumentTaxesRecord) docTaxes.get(aTax
                                        .getTaxCode()));
                                double taxBasis = extendedCost.doubleValue();
                                double taxAmount = rollupTaxAmount;
                                
                                
                                /*This logic is to update IM_DOC_DETAIL_RC_TAX */
                                
                                detailRcTax.setTaxRule(aTax.getTaxRule());
                                detailRcTax.setTaxBasis(taxBasis);
                                detailRcTax.setTaxAmount(taxAmount);
                                
                                /*This logic is to add all the taxes in the document which has same tax code, this is used 
                                 * to update IM_DOC_TAX  */
                                taxBasis += existingRow.getTaxBasis();
                                taxAmount += existingRow.getTaxAmount();
                                existingRow.setTaxBasis(taxBasis);
                                existingRow.setTaxAmount(taxAmount);
                                
                                docTaxes.put(aTax.getTaxCode(), existingRow);

                            } else {
                                double taxBasis = extendedCost.doubleValue();
                                double taxAmount = rollupTaxAmount;
                                DocumentTaxesRecord newRow = new DocumentTaxesRecord(resolutionDocItemReasonCode
                                        .getDocId(), aTax.getTaxCode(), aTax.getTaxRate(),
                                        taxBasis, taxAmount);

                                docTaxes.put(aTax.getTaxCode(), newRow);
                                
                                detailRcTax.setTaxRule(aTax.getTaxRule());
                                detailRcTax.setTaxBasis(taxBasis);
                                detailRcTax.setTaxAmount(taxAmount);
                            }
                            
                            rollupItemTaxes.add(detailRcTax);
                        }

                        
                        resolutionDocItemReasonCode.setTaxes(rollupItemTaxes);
                    }
                }
                rollupDetails.add(resolutionDocItemReasonCode);

            }

            /**
             * loop through the map (if not empty) and add the contents to rollupVat
             */
            Collection<DocumentTaxesRecord> taxRows = docTaxes.values();

            for (DocumentTaxesRecord taxRow : taxRows) {

                String key = taxRow.getDocId() + "+" + taxRow.getTaxCode();

                if (rollupTaxes.containsKey(key)) {
                	DocumentTaxesRecord currentRow = rollupTaxes.get(key);
                    currentRow.setTaxBasis(currentRow.getTaxBasis() + taxRow.getTaxBasis());
                } else {
                    rollupTaxes.put(key, taxRow);
                }
            }

            Quantity docQty = new Quantity(0);

            for (Quantity k : quantities.values()) {
                docQty = docQty.add(k);
            }

            double formattedTotalCost = docCost.doubleValue();
            resolutionDocHeadRow.setTotalQty(docQty.doubleValue());
            resolutionDocHeadRow.setTotalCost(formattedTotalCost);
            resolutionDocHeadRow.setResolutionAdjustedTotalQty(docQty.doubleValue());
            resolutionDocHeadRow.setResolutionAdjustedTotalCost(formattedTotalCost);
            resolutionDocHeadRow.setTotalCostIncTax(docCostIncTax.doubleValue());

            rollupDocs.add(resolutionDocHeadRow);
        }
    }

    private boolean isResolutionDocumentNotTaxBased(String resolutionDocType) {
        // the check also can be against DMTI and DMTF actions of resolution action row
        return (!resolutionDocType.equalsIgnoreCase(DocumentType.DEBIT_MEMO_TAX.toString()))
                && (!resolutionDocType.equalsIgnoreCase(DocumentType.CREDIT_NOTE_REQUEST_TAX
                        .toString()));
    }

    private boolean isNotFromTaxDiscrepancy(ResolutionAction resolutionActionRow) {
        return (!resolutionActionRow.getAction().equalsIgnoreCase(
                ResolutionActionCode.CREDIT_NOTE_REQUEST_TAX_FULL_CREDIT_NOTE.toString()))
                && (!resolutionActionRow.getAction().equalsIgnoreCase(
                        ResolutionActionCode.CREDIT_NOTE_REQUEST_TAX_ITEM_ONLY.toString()));
    }

    private void loadTaxesFromSystemUsingApi(Document document,
            DocumentItemReasonCode docItemReasonCode) {
        ItemTaxCalcCriteria c = new ItemTaxCalcCriteria();
        c.setItem(docItemReasonCode.getItemId());
        c.setTaxTranType(TaxTransactionType.PURCHASE_ORDER);
        c.setOverrideUnitCost(docItemReasonCode.getAdjustedQty()
                * docItemReasonCode.getAdjustedUnitCost());
        Long vendor = new Long(document.getVendorId());
        Long locationId = new Long(document.getLocation().getLocationId());
        List<ItemLocationTaxes> results = getTaxCalculationDao().calculateItemLocationTaxes(vendor,
                locationId, document.getDocDate() != null ? document.getDocDate().getSQL_Date() : null, Collections.singletonList(c));
        if(!results.isEmpty()){
            docItemReasonCode.setTaxes(results.get(0).getItemLocTaxes());
        }
    }

    private boolean isQtyBased(String resolutionDocType) {
        return resolutionDocType.equalsIgnoreCase(DocumentType.CREDIT_MEMO_QUANTITY.toString())
                || resolutionDocType.equalsIgnoreCase(DocumentType.CREDIT_NOTE_REQUEST_QUANTITY
                        .toString())
                || resolutionDocType.equalsIgnoreCase(DocumentType.DEBIT_MEMO_QUANTITY.toString());

    }

    protected ImDocHeadRow buildResolutionDocHeadRow(Document dicrepantDocument, String type,
            ReIMSystemOptions options) throws ReIMException {
        try {
            ImDocHeadRow docHeadRow = new ImDocHeadRow();

            ReIMDate currentDate = dicrepantDocument.getDocDate();

            docHeadRow.setNullableFieldsToNull();

            docHeadRow.setDocId(documentDao.getNextDocId().toLong());

            if (type.equals(Document.CREDIT_NOTE_REQUEST_PRICE)
                    || type.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)
                    || type.equals(Document.CREDIT_NOTE_REQUEST_TAX)) {

                /**
                 * Due date should be the new credit note request date (which is vdate) +
                 * debitMemoSendDays
                 */
                String docTerms = dicrepantDocument.getBestTerms();
                ReIMDate dueDate = null;

                if (docTerms != null) {
                    Term term = termsService.getTerms(docTerms);
                    dueDate = new ReIMDate(termsService.calculateTermsDueDate(currentDate
                            .getDateString(), term.getTermId(), currentDate));
                } else {
                    dueDate = new ReIMDate(currentDate);
                }
                dueDate.addDays(options.getDebitMemoSendDays());

                docHeadRow.setDueDate(dueDate.getSQL_Date());
                docHeadRow.setTerms(docTerms);
                docHeadRow.setTermsDscntPct(dicrepantDocument.getTermsDscntPct());

            } else {

                Term term = null;
                if (dicrepantDocument.getBestTerms() == null) {
                    String defaultTerms = ReIMUserContext.getSystemOptions()
                            .getDefaultPayNowTerms();
                    term = termsService.getTerms(defaultTerms);
                } else {
                    String docTerms = dicrepantDocument.getBestTerms();
                    term = termsService.getTerms(docTerms);
                }

                if (!term.getTermId().equals(ReIMConstants.EMPTY_STRING)) {
                    ReIMDate dueDate = new ReIMDate(termsService.calculateTermsDueDate(currentDate
                            .getDateString(), term.getTermId(), currentDate));
                    docHeadRow.setDueDate(dueDate.getSQL_Date());
                } else {
                    docHeadRow.setDueDate(currentDate.getSQL_Date());
                }

                docHeadRow.setTerms(term.getTermId());
                docHeadRow.setTermsDscntPct(term.getPercent());
                docHeadRow.setBestTerms(term.getTermId());
                docHeadRow.setBestTermsDate(currentDate.getTimestamp());
                docHeadRow.setBestTermsDateSource(Document.SOURCE_DOCUMENT_DATE);
                docHeadRow.setBestTermsSource(Document.SOURCE_DOCUMENT);
            }
            
            docHeadRow.setStatus(Document.APPROVED);
            docHeadRow.setDocDate(currentDate.getTimestamp());
            docHeadRow.setType(type);
            docHeadRow.setRefDoc(dicrepantDocument.getDocId());
            docHeadRow.setExtDocId(documentService.getDocumentIdPrefix(type)
                    + dicrepantDocument.getExtDocId());
            docHeadRow.setVendor(dicrepantDocument.getVendor().getVendorId());
            docHeadRow.setVendorType(dicrepantDocument.getVendorType());
            docHeadRow.setEdiUploadInd(ReIMConstants.NO);
            docHeadRow.setEdiDownloadInd(ReIMConstants.NO);

            if (type.equals(Document.MERCHANDISE_INVOICE)) {
                docHeadRow
                        .setPrePaidInd(((MerchandiseDocument) dicrepantDocument).getForcePayInd());
            } else {
                docHeadRow.setPrePaidInd(ReIMConstants.NO);
            }
            docHeadRow.setManuallyPaidInd(ReIMConstants.NO);
            docHeadRow.setCostPreMatch(ReIMConstants.NO);
            docHeadRow.setDetailMatched(ReIMConstants.NO);
            docHeadRow.setOrderNo(dicrepantDocument.getOrderNo());
            docHeadRow.setLocation(dicrepantDocument.getLocation().getLocationId());
            docHeadRow.setLocType(dicrepantDocument.getLocation().getLocationType());
            docHeadRow.setCurrencyCode(dicrepantDocument.getCurrencyCode());
            docHeadRow.setExchangeRate(dicrepantDocument.getExchangeRate());
            docHeadRow.setCreateDate((new ReIMDate()).getTimestamp());
            docHeadRow.setCreateId(ReIMUserContext.getUsername());
            docHeadRow.setLastUpdateId(ReIMUserContext.getUsername());
            docHeadRow.setLastDatetime((new ReIMDate()).getTimestamp());
            docHeadRow.setApprovalDate(currentDate.getTimestamp());
            docHeadRow.setApprovalId(ReIMUserContext.getUsername());
            docHeadRow.setConsignmentInd(ReIMConstants.NO);
            docHeadRow.setRtvInd(ReIMConstants.NO);
            docHeadRow.setTotalCostIncTax(dicrepantDocument.getTotalIncTax());
            docHeadRow.setHoldStatus(HoldStatus.NEVER_HELD.getCode());
            docHeadRow.setSupplierSite(dicrepantDocument.getSupplierSite() != null ? dicrepantDocument.getSupplierSiteId(): null);

            return docHeadRow;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_build_resolution_document_header",
                    Severity.ERROR, e, ReasonCodeActionRollupService.class);
        }
    }

    protected DocumentItemReasonCode buildDocumentItemReasonCode(ResolutionAction resolutionAction,
            ImDocHeadRow resolutionDocHeadRow, String resolutionDocType, String discrepantDocType)
            throws ReIMException {
        try {
            DocumentItemReasonCode docItemRC = new DocumentItemReasonCode();
            docItemRC.setDocId(resolutionDocHeadRow.getDocId());
            docItemRC.setItem(new Item(resolutionAction.getItemId()));
            docItemRC.setReasonCode(resolutionAction.getReasonCode());
            docItemRC.setStatus(Document.APPROVED);
            docItemRC.setCostMatched(Affirm.check(ReIMConstants.NO));
            docItemRC.setQtyMatched(Affirm.check(ReIMConstants.NO));
            Variance var = new Variance(resolutionAction.getReasonCode());

            var = varianceDao.getResolutionUnitCostAndQty(var, resolutionAction.getDocId(),
                    resolutionAction.getItemId());
            if (var != null) {
                docItemRC.setOriginalUnitCost(var.getUnitCost());
                docItemRC.setOriginalQty(var.getQuantity());
                docItemRC.setAdjustedValuesFromOriginal();
            }
            if (null != var && var.getUnitCost() < ReIMConstants.ZERO) {
                docItemRC.setTaxes(getNegativeTaxes(resolutionAction.getTaxes()));
            } else if(resolutionAction.getActionCode().getCode().equalsIgnoreCase(ResolutionActionCode.CREDIT_NOTE_REQUEST_TAX_ITEM_ONLY.getCode()) ||
            		resolutionAction.getActionCode().getCode().equalsIgnoreCase(ResolutionActionCode.CREDIT_NOTE_REQUEST_TAX_FULL_CREDIT_NOTE.getCode())){
            	docItemRC.setTaxes(getReverseTaxes(resolutionAction.getTaxes()));
            }            
            else {
                docItemRC.setTaxes(resolutionAction.getTaxes());
            }

            // TODO:
            docItemRC.setUnitFreight(null);
            docItemRC.setUnitMRP(null);
            docItemRC.setUnitRetail(null);
            // end TODO:
            return docItemRC;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_build_resolution_detail_row", Severity.ERROR, e,
                    ReasonCodeActionRollupService.class);
        }
    }

    private Set<Tax> getNegativeTaxes(Set<Tax> taxes) {
        for (Tax tax : taxes) {
            if (tax.getTaxBasis() > 0) {
                tax.setTaxBasis((-1) * tax.getTaxBasis());
            }
            if (tax.getTaxAmount() > 0) {
                tax.setTaxAmount((-1) * tax.getTaxAmount());
            }
        }

        return taxes;
    }
    
    private Set<Tax> getReverseTaxes(Set<Tax> taxes) {
        for (Tax tax : taxes) {
            
                tax.setTaxBasis((-1) * tax.getTaxBasis());
                tax.setTaxAmount((-1) * tax.getTaxAmount());
        }

        return taxes;
    }

    /**
     * This method updates all action rows passed to it to have a rolled up status.
     * 
     * @param actions
     *            Action rows to have status updated
     */
    protected void updateRolledUpActionsStatus(ResolutionAction[] actions) {
        updateRolledUpActionsStatus(Arrays.asList(actions));
    }

    /**
     * Update all actions to rolled up status. If the action is a receiver adjustment with a pending
     * adjustment, this is where we decide if it should be rolled up or not.
     * 
     * @param actions
     *            The resolution actions to update the status for.
     */
    protected void updateRolledUpActionsStatus(List<ResolutionAction> actions) {
        for (ResolutionAction current : actions) {

            if (current.getActionCode().isReceiverAdjustment()) {

                List<DocumentItemInvoice> detailRows = getInvoiceDetailDao().readDetailsByDocId(
                        current.getDocId());

                for (DocumentItemInvoice detail : detailRows) {
                    if (detail.getItemId().equals(current.getItemId())) {
                        if (Affirm.check(detail.getAdjustmentPending())) {
                            current.setStatus(Resolution.UNROLLED);
                        } else {
                            current.setStatus(Resolution.ROLLEDUP);
                        }
                        break;
                    }
                }
            } else {
                current.setStatus(Resolution.ROLLEDUP);
            }
        }
        resolutionActionDao.update(actions);
    }

    @Required
    @Autowired
    public void setVarianceDao(IVarianceDao varianceDao) {
        this.varianceDao = varianceDao;
    }

    @Required
    @Autowired
    public void setInvoiceHoldingService(IDocumentHoldingService invoiceHoldingService) {
        this.invoiceHoldingService = invoiceHoldingService;
    }

    @Required
    @Autowired
    public void setResolutionActionDao(IResolutionActionDao resolutionActionDao) {
        this.resolutionActionDao = resolutionActionDao;
    }

    @Required
    @Autowired
    public void setDocumentDao(IDocumentDao documentDao) {
        this.documentDao = documentDao;
    }

    @Required
    @Autowired
    public void setInvoiceDetailDao(IInvoiceDetailDao invoiceDetailDao) {
        this.invoiceDetailDao = invoiceDetailDao;
    }

    public IInvoiceDetailDao getInvoiceDetailDao() {
        return this.invoiceDetailDao;
    }

    @Required
    @Autowired
    public void setDocumentDetailDao(IDocumentDetailDao documentDetailDao) {
        this.documentDetailDao = documentDetailDao;
    }

    @Required
    @Autowired
    public void setDocumentTaxDao(IDocumentTaxDao documentTaxDao) {
        this.documentTaxDao = documentTaxDao;
    }

    @Required
    @Autowired
    public void setSupplierOptionsService(ISupplierOptionsService supplierOptionsService) {
        this.supplierOptionsService = supplierOptionsService;
    }

    public void setTermsService(ITermsService termsService) {
        this.termsService = termsService;
    }
    
    @Required
    @Autowired    
    public void setDateTimeService(IDateTimeService dateTimeService) {
        this.dateTimeService = dateTimeService;
    }

    @Required
    @Autowired
    public void setDocumentService(IDocumentService documentService) {
        this.documentService = documentService;
    }

    public ITaxCalculationDao getTaxCalculationDao() {
        return taxCalculationDao;
    }

    @Autowired
    public void setTaxCalculationDao(ITaxCalculationDao taxCalculationDao) {
        this.taxCalculationDao = taxCalculationDao;
    }
}