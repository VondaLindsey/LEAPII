/**
 * 
 */
package oracle.retail.reim.services.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import oracle.retail.reim.business.Allowance;
import oracle.retail.reim.business.AllowanceCode;
import oracle.retail.reim.business.DocumentStatus;
import oracle.retail.reim.business.DocumentType;
import oracle.retail.reim.business.InvoiceDetailAllowance;
import oracle.retail.reim.business.LocationType;
import oracle.retail.reim.business.SettlementCode;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.VendorType;
import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.document.HoldStatus;
import oracle.retail.reim.business.tax.ItemTaxAudit;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.tax.TaxDiscrepancy;
import oracle.retail.reim.business.tax.TaxSource;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.data.dao.IDocDetailReasonCodesDao;
import oracle.retail.reim.data.dao.IDocumentDao;
import oracle.retail.reim.data.dao.IDocumentTaxDao;
import oracle.retail.reim.data.dao.IInvoiceDetailAllowanceDao;
import oracle.retail.reim.data.dao.IInvoiceDetailDao;
import oracle.retail.reim.data.dao.IItemTaxAuditDao;
import oracle.retail.reim.data.dao.INonMerchandiseEntryDao;
import oracle.retail.reim.data.dao.ITaxDiscrepancyDao;
import oracle.retail.reim.services.IDocumentService;
import oracle.retail.reim.services.IEdiDocumentService;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.icu.text.SimpleDateFormat;
import com.retek.merch.utils.ApplicationContext;
import com.retek.merch.utils.RetekException;
import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EDIHeaderTax;
import com.retek.reim.batch.ediupinv.EdiDetailAllowance;
import com.retek.reim.batch.ediupinv.EdiDocBulk;
import com.retek.reim.batch.ediupinv.EdiNonMerchDetail;
import com.retek.reim.batch.ediupinv.EdiTransactionDetail;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.batch.ediupinv.EdiUploadProperties;
import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.ReIMUser;
import com.retek.reim.business.SupplierOptions;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.DocumentItemReasonCode;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.ISequencerDao;
import com.retek.reim.db.ImDocHeadAccess;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.db.SequencerDao;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.foundation.ILocationBean;
import com.retek.reim.foundation.ISupplierBean;
import com.retek.reim.foundation.ISystemOptionsBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.IPeriodService;
import com.retek.reim.services.ISupplierOptionsService;
import com.retek.reim.services.ISystemOptionsService;
import com.retek.reim.services.IVendorService;
import com.retek.reim.services.ServiceFactory;

/**
 * @author Oracle Retail
 * 
 */
/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.1	16-Jun-2014	 Naveen J	ME 231034  ENH-IMS 158956 Reim enhancement - EDI batch date 
 *    1.2	19-Dec-2014	 Naveen J	ME 398410  EDI upload: - Reim invoice detail incorrect :- Same item in EDI invoice multiple times
 * 
 */
@Service
public class EdiDocumentService implements IEdiDocumentService {

    private IDocumentService documentService;
    private IDocDetailReasonCodesDao docDetailReasonCodesDao;

    private IDocumentDao documentDao;
    private IDocumentTaxDao documentTaxDao;

    private IInvoiceDetailDao invoiceDetailDao;

    private IInvoiceDetailAllowanceDao invoiceDetailAllowanceDao;

    private INonMerchandiseEntryDao nonMerchandiseDao;

    private IItemTaxAuditDao itemTaxAuditDao;
    private ITaxDiscrepancyDao taxDiscrepancyDao;
    private ISequencerDao IseqDao;


    // create headrow and assign it to edidocbulk and perform insertion.
    public synchronized void createEdiDocuments(
            EdiTransactionHeader ediTransactionHeader, EdiDocBulk ediDocBulk, boolean isFromScreen)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            Timestamp currentDate = new ReIMDate().getTimestamp();

            ImDocHeadRow docHeadRow = createDocHeadRow(ediTransactionHeader, currentDate);

            long docId = Long.MIN_VALUE;
            if (isFromScreen) {
                // add doc head record directly to database
                ImDocHeadAccess docHeadAccess = new ImDocHeadAccess();
                docHeadAccess.create(docHeadRow);
                docId = docHeadRow.getDocId();
            } else {
                // add doc head record to bulk area
            	docId = ediDocBulk.getDocId();
            	docHeadRow.setDocId(docId);
            	ediDocBulk.setDocId(docId + EdiUploadProperties.DOC_INCREMENT);
                String extDocId = docHeadRow.getExtDocId();
                StringBuffer extDocIdBuffer = new StringBuffer();
                int extDocIdLength = extDocId.length();
                
                // handle UTF8 case
                boolean bUTF8 = false;
                try {
                    int extDocIdBytes = extDocId
                            .getBytes(ReIMConstants.UTF8_ENCODING).length;
                    bUTF8 = extDocIdBytes != extDocIdLength;
                } catch (Exception ex) {
                    throw new ReIMException("error.edi_document_service.create_edi_documents",
                            Severity.ERROR, ex, EdiDocumentService.class);
                }

                // if UTF8, assuming the characters are three bytes each, adjust
                // the length
                // checking accordingly.
                if (bUTF8) {
                    extDocIdLength *= 3;
                }
                
                if (extDocIdLength > 34 && ReIMConstants.YES.equals(ediTransactionHeader.getRtvInd())) 
                {
                    extDocIdBuffer.append(extDocId.substring(0, bUTF8 ? 13 : 34));
                }
                else if (extDocIdLength < 34 && ReIMConstants.YES.equals(ediTransactionHeader.getRtvInd())) 
                {
                    extDocIdBuffer.append(extDocId);
                }
                else if (extDocIdLength > 50 && ReIMConstants.NO.equals(ediTransactionHeader.getRtvInd())) 
                {
                    extDocIdBuffer.append(extDocId.substring(0, bUTF8 ? 13 : 34));
                    extDocIdBuffer.append("-");
                    extDocIdBuffer.append(docId);
                }
                else
                {
                    extDocIdBuffer.append(extDocId);
                }
                docHeadRow.setExtDocId(extDocIdBuffer.toString());
                ediDocBulk.addDocHead(docHeadRow);            
            }

            List<DocumentItemInvoice> invoiceDetailList = new ArrayList<DocumentItemInvoice>();
            List<InvoiceDetailAllowance> invoiceDetailAllowanceList = new ArrayList<InvoiceDetailAllowance>();
            List<DocumentItemReasonCode> docDetailReasonCodeList = new ArrayList<DocumentItemReasonCode>();
            List<NonMerchandiseDocument> documentNonMerchList = new ArrayList<NonMerchandiseDocument>();
            List<ItemTaxAudit> itemTaxAuditList = new ArrayList<ItemTaxAudit>();
            List<TaxDiscrepancy> taxDiscrepancyList = new ArrayList<TaxDiscrepancy>();
            Document document = new Document();

            String docType = docHeadRow.getType();

            EdiTransactionDetail[] ediTransactionDetailList = ediTransactionHeader
                    .getEdiTransactionDetailList();
            if (ediTransactionDetailList != null) {
                // based on the document type, split invoice
                // detail from
                // document detail
                if (docType.equalsIgnoreCase(Document.MERCHANDISE_INVOICE)) {
                    createInvoiceDetailAndAllowanceAndItemTaxAudits(docId,
                            ediTransactionDetailList, currentDate, invoiceDetailList,
                            invoiceDetailAllowanceList, itemTaxAuditList, taxDiscrepancyList,
                            ediTransactionHeader.getOrderNumber());

                    if (checkForItemTaxDiscrepancies(invoiceDetailList)) {
                        docHeadRow.setStatus(Document.TAX_DISCREPANCY);
                        docHeadRow.setTaxDiscCreateDate(ServiceFactory.getPeriodService()
                                .getVDate().getTimestamp());
                        // Update because header record
                        // already inserted.
                        if (isFromScreen)
                            ServiceFactory.getDocumentService().updateImDocHeadRow(docHeadRow);
                    }
                } else if (docType.equalsIgnoreCase(Document.CREDIT_NOTE)
                        || docType.equalsIgnoreCase(Document.CREDIT_NOTE_REQUEST_PRICE)
                        || docType.equalsIgnoreCase(Document.CREDIT_NOTE_REQUEST_QUANTITY)
                        || docType.equalsIgnoreCase(Document.DEBIT_MEMO_PRICE)
                        || docType.equalsIgnoreCase(Document.DEBIT_MEMO_QUANTITY)) {
                    createDocDetailReasonCodeRows(docId, ediTransactionDetailList, currentDate,
                            docDetailReasonCodeList);
                }
            }
            createDocNonMerchRows(docId, docType, ediTransactionHeader.getEdiNonMerchDetailList(),
                    documentNonMerchList);

            // create row for im_doc_tax
            createDocTaxes(docId, docType, ediTransactionHeader.getEDIHeaderTaxList(), document);

            if (invoiceDetailList.size() > 0) {
                ediDocBulk.getInvoiceDetail().addAll(invoiceDetailList);
            }

            if (invoiceDetailAllowanceList.size() > 0) {
                ediDocBulk.getInvoiceDetailAllowance().addAll(invoiceDetailAllowanceList);
            }

            if (docDetailReasonCodeList.size() > 0) {
                ediDocBulk.getDocDetailReasonCodes().addAll(docDetailReasonCodeList);
            }

            if (documentNonMerchList.size() > 0) {
                ediDocBulk.getDocNonMerch().addAll(documentNonMerchList);
            }

            if (document.getTaxes().size() > 0) {
                ediDocBulk.getDocuments().add(document);
            }

            if (itemTaxAuditList.size() > 0) {
                ediDocBulk.getItemTaxAudit().addAll(itemTaxAuditList);
            }

            if (taxDiscrepancyList.size() > 0) {
                ediDocBulk.getTaxDiscrepancyList().addAll(taxDiscrepancyList);
            }

            if (ediDocBulk.getDocHead().size() >= ediDocBulk.getMaxDocumentCount() || isFromScreen) {
                insertEdiDocuments(ediDocBulk, isFromScreen);
            }
        } catch (ReIMException exception) {
            TransactionManagerFactory.getInstance().rollback();
            throw (exception);
        } catch (Exception ex) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.edi_document_service.create_edi_documents",
                    Severity.ERROR, ex, EdiDocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }
    /**
     * Fetch a new sequence and reset the bulk object.
     */
    public static EdiDocBulk initEdiDocBulk(EdiDocBulk ediDocBulk) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            SequencerDao seq = new SequencerDao(EdiUploadProperties.DOC_BULK_SEQUENCE,
                    EdiUploadProperties.getDocBulkSize());
            
            

            List bulkIds = seq.getSequence();

            // Queue up the first available doc ID.
            ediDocBulk.setDocId(SequencerDao.firstInSeq(bulkIds));
            ediDocBulk.setMaxDocumentCount(EdiUploadProperties.getDocBulkSize());

            ediDocBulk.setDocHead(new ArrayList());
            ediDocBulk.setInvoiceDetail(new ArrayList());
            ediDocBulk.setInvoiceDetailAllowance(new ArrayList());
            ediDocBulk.setDocDetailReasonCodes(new ArrayList());
            ediDocBulk.setDocNonMerch(new ArrayList());
            ediDocBulk.setTaxDiscrepancyList(new ArrayList());
            ediDocBulk.setItemTaxAudit(new ArrayList());
            return ediDocBulk;

        } catch (ReIMException exception) {
            throw (exception);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }


    private static void createDocNonMerchRows(long docId, String documentType,
            EdiNonMerchDetail[] ediNonMerchList, List<NonMerchandiseDocument> documentNonMerchList)
            throws ReIMException {
        if (ediNonMerchList != null) {
            EdiNonMerchDetail ediNonMerchDetail = null;
            NonMerchandiseDocument nonMerchandiseDocument = null;
            double nonMerchandiseAmount = 0;
            String nonMerchCode = null;
            int ediNonMerchListLength = ediNonMerchList.length;
            for (int j = 0; j < ediNonMerchListLength; j++) {
                ediNonMerchDetail = ediNonMerchList[j];
                nonMerchandiseAmount = ediNonMerchDetail.getNonMerchandiseAmount();
                nonMerchCode = ediNonMerchDetail.getNonMerchandiseCode();
                nonMerchandiseDocument = new NonMerchandiseDocument(nonMerchCode,
                        nonMerchandiseAmount);
                nonMerchandiseDocument.setDocId(docId);
                nonMerchandiseDocument.setNonMerchTaxes(ediNonMerchDetail.getEdiNonMerchTaxes());
                documentNonMerchList.add(nonMerchandiseDocument);
            }
        }
    }

    // create rows for im_doc_vat (and im_vat_ratea_audit)
    private static void createDocTaxes(long docId, String documentType, EDIHeaderTax[] ediTaxList,
            Document document) throws ReIMException {
        document.setDocId(docId);
        if (ediTaxList != null) {
            EDIHeaderTax ediTaxDetail = null;
            Tax docTax = null;
            double taxBasis = 0;
            Set<Tax> taxes = new HashSet<Tax>();
            int ediTaxListLength = ediTaxList.length;
            for (int j = 0; j < ediTaxListLength; j++) {
                ediTaxDetail = ediTaxList[j];
                taxBasis = ediTaxDetail.getTaxBasis();
                docTax = new Tax(ediTaxDetail.getTaxCode(), ediTaxDetail.getTaxRate(), taxBasis);
                taxes.add(docTax);
                document.setTaxes(taxes);
            }
        }
    }

    public ImDocHeadRow createDocHeadRow(EdiTransactionHeader ediTransactionHeader,
            Timestamp currentDate) throws ReIMException {
        try {
            SupplierOptions supplierOptions = null;
            // set groupid on row object

            ImDocHeadRow row = new ImDocHeadRow();
            row.setNullableFieldsToNull();

            String documentType = ediTransactionHeader.getDocumentType();
            //String vendorId = ediTransactionHeader.getVendorID();
            //String vendorType = ediTransactionHeader.getVendorType();
            String merchType = ediTransactionHeader.getMerchType();
            String rtvInd = ediTransactionHeader.getRtvInd();
            
            
            Vendor vendor = getVendorService().getDocumentVendor(ediTransactionHeader.getVendorID(), VendorType.fromCode(ediTransactionHeader.getVendorType()));
            SettlementCode settlementCode = getSupplierBean().getSettlementCode(vendor.getVendorId());
            
            if (VendorType.isSupplier(vendor.getVendorType())) {
                supplierOptions = getSupplierOptionsService().select(vendor.getVendorId());

                /**
                 * Hold Credit Notes for holding suppliers.
                 */
              
                row.setHoldStatus( (DocumentType.isCreditNote(documentType) && supplierOptions.isHoldInvoice()) ? HoldStatus.HELD.getCode() : HoldStatus.NEVER_HELD.getCode());
            } else {
                // Defect #431 - To resolve EDI upload failing if not type supplier because hold
                // status is not set.
                row.setHoldStatus(HoldStatus.NEVER_HELD.getCode());
            }

            Long dealId = ediTransactionHeader.getDealId();
            double totalCost = ediTransactionHeader.getTotalCost();

            if (documentType.equals(Document.DEBIT_MEMO_PRICE)
                    || documentType.equals(Document.DEBIT_MEMO_QUANTITY)
                    || documentType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)
                    || documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                if (supplierOptions != null && supplierOptions.isAlwaysSendDebitMemo()) {
                    if (!StringUtils.isEmpty(merchType)
                            && (merchType.equals(ReIMConstants.MERCH_TYPE_CONSIGNMENT))) {
                        row.setType(Document.DEBIT_MEMO_QUANTITY);
                    } else {
                        row.setType(documentType);
                    }
                } else {
                    if (!StringUtils.isEmpty(merchType)
                            && (merchType.equals(ReIMConstants.MERCH_TYPE_CONSIGNMENT))) {
                        row.setType(Document.CREDIT_NOTE_REQUEST_QUANTITY);
                    } else {
                        row.setType(documentType);
                    }
                }
            } else {
                row.setType(documentType);
            }

            if (DocumentType.isMerchandiseInvoice(documentType)) {
                
                if ((getSystemOptionsBean().select().getExtInvcMatchInd().equalsIgnoreCase(Affirm.YES_IND) && settlementCode.isERS())||(merchType != null
                        && (merchType.equals(ReIMConstants.MERCH_TYPE_CONSIGNMENT)
                                || merchType.equals(ReIMConstants.MERCH_TYPE_DSD) || merchType
                                .equals(ReIMConstants.MERCH_TYPE_ERS)))) {
                    row.setStatus(Document.MATCHED);
                    row.setMatchDate(ediTransactionHeader.getVendorDocumentDate().getTimestamp());
                    row.setMatchId((ReIMUserContext.getUsername() != null ? ReIMUserContext.getUsername()
                    : EDIConstants.CREATE_ID));
                } else {
                    row.setStatus(Document.READY_FOR_MATCH);
                }
            } else {                
                if(DocumentType.isDebitMemo(documentType) || DocumentType.isCreditNoteRequest(documentType)) {
                                     row.setStatus(DocumentStatus.APPROVED.getVal());
                    }
                
                row.setApprovalDate(ApplicationContext.isBatchApplication() ? getPeriodService().getVDate().getTimestamp() : getPeriodService().getScreenVDate().getTimestamp());
            }

            if (ediTransactionHeader.getOrderNumber() != null)
                row.setOrderNo(ediTransactionHeader.getOrderNumber().intValue());

            if (LocationType.isWarehouse(ediTransactionHeader.getLocationType())) {
                Location tempLoc = getLocationBean().readWarehouse(ediTransactionHeader.getLocation()
                        .toString());

                ediTransactionHeader.setLocation(Long.valueOf(tempLoc.getLocationId()));
                row.setLocation(ediTransactionHeader.getLocation().longValue());
            } else {
                row.setLocation(ediTransactionHeader.getLocation().longValue());
            }
            row.setLocType(ediTransactionHeader.getLocationType());

            row.setTotalDiscount(ediTransactionHeader.getTotalDiscount());
            row.setDocDate(ediTransactionHeader.getVendorDocumentDate().getTimestamp());
            row.setCreateDate(currentDate);
            row.setCreateId((ReIMUserContext.getUsername() != null ? ReIMUserContext.getUsername()
                    : EDIConstants.CREATE_ID));
            row.setVendorType(ediTransactionHeader.getVendorType());
            row.setVendor(ediTransactionHeader.getVendorID());
            if (ediTransactionHeader.getSupplierSiteID() != null ){
                row.setSupplierSite(ediTransactionHeader.getSupplierSiteID());
            }
            
            String extDoc = documentService.getDocumentIdPrefix(documentType);
            if (extDoc != null) {
                row.setExtDocId(extDoc + ediTransactionHeader.getVendorDocumentNumber());
            } else {
                row.setExtDocId(ediTransactionHeader.getVendorDocumentNumber());
            }

            row.setEdiUploadInd(ReIMConstants.YES);
            row.setEdiDownloadInd(ReIMConstants.NO);

            if (merchType != null && merchType.equals(ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {
                String defaultPayNowTermCode = ServiceFactory.getReIMSystemOptionsService()
                        .select().getDefaultPayNowTerms();
                row.setTerms(defaultPayNowTermCode);
                row.setTermsDscntPct(ReIMConstants.ZERO);

            } else {
                row.setTerms(ediTransactionHeader.getTerms());
                row.setTermsDscntPct(ediTransactionHeader.getTermsDiscountPercentage()
                        .doubleValue());
            }
            row.setDueDate(ediTransactionHeader.getDueDate().getSQL_Date());
            row.setPaymentMethod(ediTransactionHeader.getPaymentMethod());
            row.setPrePaidInd(ReIMConstants.NO);
            row.setCurrencyCode(ediTransactionHeader.getCurrencyCode());
            row.setExchangeRate(ediTransactionHeader.getExchangeRate().doubleValue());

            row.setTotalCost(totalCost);
            row.setTotalQty(ediTransactionHeader.getTotalQuantity());
            row.setManuallyPaidInd(ediTransactionHeader.getManuallyPaidInd());

            // version 1.1 Changes done by Naveen J
        	//--------------Internal Patch---------------starts----------
        	//-- fix for ME 231034  - Enhancement 
          
           //old code starts
          //  row.setCustomDocRef1(ediTransactionHeader.getCustomDocumentReference1());
            //old code ends 
            // new code added  :- starts
            if((ediTransactionHeader.getCustomDocumentReference1() != null) && (rtvInd != null && rtvInd.equalsIgnoreCase(ReIMConstants.NO)))
            {
            	row.setCustomDocRef1(ediTransactionHeader.getCustomDocumentReference1()+"#"+new SimpleDateFormat("MMddyyyy").format(currentDate));
             }
            //new code added :- ends
        	//--------------Internal Patch---------------ends----------
        	
            
           
           

            
            row.setCustomDocRef2(ediTransactionHeader.getCustomDocumentReference2());
            row.setCustomDocRef3(ediTransactionHeader.getCustomDocumentReference3());
            row.setCustomDocRef4(ediTransactionHeader.getCustomDocumentReference4());
            row.setLastUpdateId(EDIConstants.CREATE_ID);
            row.setLastDatetime(currentDate);
            row.setFreightType(ediTransactionHeader.getFreightType());

            if (ediTransactionHeader.getCrossReferenceDocumentNumber() != null)
                row.setRefDoc(ediTransactionHeader.getCrossReferenceDocumentNumber().longValue());
            row.setCostPreMatch(ReIMConstants.NO);
            row.setDetailMatched(ReIMConstants.NO);
            row.setResolutionAdjustedTotalCost(totalCost);

            row.setResolutionAdjustedTotalQty(ediTransactionHeader.getTotalQuantity());

            // when dealing with a Credit note or non-merch doc (anything other
            // than a merch
            // doc), need to set the best terms info on doc_head
            if (!documentType.equals(Document.MERCHANDISE_INVOICE)) {
                row.setBestTerms(ediTransactionHeader.getTerms());
                row.setBestTermsSource(Document.SOURCE_DOCUMENT);
                row.setBestTermsDate(ediTransactionHeader.getVendorDocumentDate().getTimestamp());
                row.setBestTermsDateSource(Document.SOURCE_DOCUMENT_DATE);
            }

            if (merchType != null && merchType.equals(ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {
                row.setConsignmentInd(ReIMConstants.YES);
            } else {
                row.setConsignmentInd(ReIMConstants.NO);
            }
            if (merchType != null && merchType.equals(ReIMConstants.MERCH_TYPE_DSD)) {
                row.setDirectStoreDelieveryInd(ReIMConstants.YES);
            } else if ((merchType != null && merchType.equals(ReIMConstants.MERCH_TYPE_ERS))||(settlementCode.isERS())) {
                row.setEvaluatedReceiptSettlementInd(ReIMConstants.YES);
            } else {
                row.setDirectStoreDelieveryInd(ReIMConstants.NO);
                row.setEvaluatedReceiptSettlementInd(null);
            }

            if (dealId == null) {
                row.setDealIdToNull();
            }

            row.setRtvInd(rtvInd);

            double totalCostIncTax = 0;
            totalCostIncTax = ediTransactionHeader.getTotalCost()
                    + ediTransactionHeader.getTotalTaxAmount();
            row.setTotalCostIncTax(totalCostIncTax);
            if (!StringUtils.isBlank(ediTransactionHeader.getGroupId())) {
                row.setGroupId(Long.valueOf(ediTransactionHeader.getGroupId()));
            } else {
                row.setGroupIdToNull();
            }

            return row;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_doc_head_row", Severity.ERROR, e,
                    EdiDocumentService.class);
        }
    }

    private static void createInvoiceDetailAndAllowanceAndItemTaxAudits(long docId,
            EdiTransactionDetail[] ediTransactionDetailList, Timestamp currentDate,
            List<DocumentItemInvoice> invoiceDetailList,
            List<InvoiceDetailAllowance> invoiceDetailAllowanceList,
            List<ItemTaxAudit> itemTaxAuditList, List<TaxDiscrepancy> taxDiscrepancyList,
            Long orderNo) throws ReIMException {
        try {
            EdiTransactionDetail ediTransactionDetail = null;
            DocumentItemInvoice documentItemInvoice = null;
            double itemsAvgUnitCost = 0.0;
            double itemsTotalCost = 0.0;
            double itemsTotalQty = 0.0;
            int ediTransactionDetailListLength = ediTransactionDetailList.length;
            for (int j = 0; j < ediTransactionDetailListLength; j++) {
                ediTransactionDetail = ediTransactionDetailList[j];
                documentItemInvoice = new DocumentItemInvoice();
                documentItemInvoice.setDocId(docId);
                documentItemInvoice.setItem(new Item(ediTransactionDetail.getItem()));

                if (invoiceDetailList.contains(documentItemInvoice)) {
                	
                	// version 1.2 Changes done by Naveen J
                	//--------------Internal Patch---------------starts----------
                	//-- fix for ME 398410 - Incorrect Invoice detail
                	DocumentItemInvoice l_dupDocumentItem=invoiceDetailList.get(invoiceDetailList.indexOf(documentItemInvoice));
                	//fetch qty for of previously added item
                	itemsTotalQty=l_dupDocumentItem.getQty();
                	// calculating total cost of previously added item
                	itemsTotalCost=l_dupDocumentItem.getUnitCost()*itemsTotalQty;
                	
                	//-- fix for ME 398410 - Incorrect Invoice detail
                   //--------------Internal Patch---------------ends----------
                	
                	
                    invoiceDetailList.remove(invoiceDetailList.indexOf(documentItemInvoice));
                    double itemCost = ediTransactionDetail.getOriginalUnitCost();
                    double itemQty = ediTransactionDetail.getOriginalDocumentQuantity();
                    double itemTotalCost = itemCost * itemQty;
                    itemsTotalCost = itemsTotalCost + itemTotalCost;
                    itemsTotalQty = itemsTotalQty + itemQty;
                    itemsAvgUnitCost = itemsTotalCost / itemsTotalQty;
                    documentItemInvoice.setUnitCost(itemsAvgUnitCost);
                    documentItemInvoice.setQty(itemsTotalQty);
                    documentItemInvoice.setResolutionAdjustedQtyInvoiced(itemsTotalQty);
                    documentItemInvoice.setResolutionAdjustedUnitCost(itemsAvgUnitCost);

                } else {
                    double itemCost = ediTransactionDetail.getOriginalUnitCost();
                    double itemQty = ediTransactionDetail.getOriginalDocumentQuantity();
                    double itemTotalCost = itemCost * itemQty;
                    itemsTotalCost = itemTotalCost;
                    itemsTotalQty = ediTransactionDetail.getOriginalDocumentQuantity();
                    documentItemInvoice.setUnitCost(ediTransactionDetail.getOriginalUnitCost());
                    documentItemInvoice.setQty(ediTransactionDetail.getOriginalDocumentQuantity());
                    documentItemInvoice.setResolutionAdjustedQtyInvoiced(ediTransactionDetail
                            .getOriginalDocumentQuantity());
                    documentItemInvoice.setResolutionAdjustedUnitCost(ediTransactionDetail
                            .getOriginalUnitCost());
                }
                documentItemInvoice.setStatus(DocumentItemInvoice.UNMATCHED);
                documentItemInvoice.setAdjustmentPending(ReIMConstants.NO);
                documentItemInvoice.setCostMatched(false);
                documentItemInvoice.setQtyMatched(false);
                documentItemInvoice.setTaxes(ediTransactionDetail.getEdiItemTaxes());
                invoiceDetailList.add(documentItemInvoice);
                // collect all detail allowances
                EdiDetailAllowance[] ediDetailAllowanceList = ediTransactionDetail
                        .getEdiDetailAllowanceList();
                if (ediDetailAllowanceList != null) {
                    EdiDetailAllowance ediDetailAllowance = null;
                    int ediDetailAllowanceListLength = ediDetailAllowanceList.length;
                    for (int k = 0; k < ediDetailAllowanceListLength; k++) {
                        ediDetailAllowance = ediDetailAllowanceList[k];
                        Set<Tax> allowanceTaxes = ediDetailAllowance.getEdiItemAllowanceTaxes();
                        // TODO:setting allowance tax basis with allowance tax amount
                        // need to be changed when the file format changes
                        for (Tax tax : allowanceTaxes) {
                            tax.setTaxBasis(ediDetailAllowance.getAllowanceAmount());
                            tax.setTaxAmount(tax.getTaxBasis() * tax.getTaxRate() / 100);
                        }
                        DocumentItem docItem = new DocumentItem(documentItemInvoice.getItemId(),
                                documentItemInvoice.getUnitCost(), documentItemInvoice.getQty(),
                                allowanceTaxes);
                        docItem.setDocId(docId);
                        AllowanceCode allowanceCode = AllowanceCode.fromCode(ediDetailAllowance
                                .getAllowanceCode());
                        Allowance allowance = new Allowance(allowanceCode, ediDetailAllowance
                                .getAllowanceAmount());
                        InvoiceDetailAllowance invoiceDetailAllowance = new InvoiceDetailAllowance(
                                docItem, allowance);
                        invoiceDetailAllowanceList.add(invoiceDetailAllowance);
                    }
                }
                if (ediTransactionDetail.isToBeAudited()) {
                    Set<Tax> docTaxes = ediTransactionDetail.getEdiItemTaxes();
                    ItemTaxAudit itemTaxAudit = new ItemTaxAudit(DocId.valueOf(docId), orderNo,
                            documentItemInvoice.getItem(), docTaxes, ediTransactionDetail
                                    .getSystemTaxes(), new ReIMUser("ADMIN"));
                    itemTaxAuditList.add(itemTaxAudit);
                }
                // Only flag detail as discrepant if tax processing option
                // is set to reconcile tax.
                if (ReIMSystemOptions.getInstance().isReconcileTax()
                        && ediTransactionDetail.isTaxDiscrepant()) {
                    documentItemInvoice.setTaxDiscrepant(true);
                    TaxDiscrepancy taxDiscrepancy = new TaxDiscrepancy(DocId.valueOf(docId), Long
                            .valueOf(orderNo), new Item(documentItemInvoice.getItemId()),
                            documentItemInvoice.getTaxes(), ediTransactionDetail.getSystemTaxes(),
                            TaxSource.SYSTEM);
                    taxDiscrepancyList.add(taxDiscrepancy);
                }
            }
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_invoice_detail_and_allowance_row",
                    Severity.ERROR, e, EdiDocumentService.class);
        }
    }

    /**
     * This method loops through the passed in items and checks if any have the tax discrepant
     * indicator populated. If so, then at least one item is tax discrepant. This only holds true if
     * the system tax validation is set to 'RECON'cile TAX.
     * 
     * @param invoiceItems
     * @return
     * @throws ReIMException
     */
    private static boolean checkForItemTaxDiscrepancies(List<DocumentItemInvoice> invoiceItems)
            throws ReIMException {
        boolean discrepant = false;
        if (ReIMSystemOptions.getInstance().isReconcileTax()) {
            DocumentItemInvoice[] detailRows = (DocumentItemInvoice[]) invoiceItems
                    .toArray(new DocumentItemInvoice[invoiceItems.size()]);
            for (int i = 0; i < detailRows.length; i++) {
                if (detailRows[i].isTaxDiscrepant() != null && detailRows[i].isTaxDiscrepant()) {
                    discrepant = true;
                    break;
                }
            }
        }
        return discrepant;
    }

    public synchronized void insertEdiDocuments(EdiDocBulk ediDocBulk, boolean isFromScreen) {
        try {
            if (!isFromScreen)
            // If coming from the screen, the doc head has already been
            // persisted in createEdiDocuments
            // Otherwise persist from bulk area
            {
            	ImDocHeadRow[] docHeadRows = new ImDocHeadRow[ediDocBulk.getDocHead().size()];
                ediDocBulk.getDocHead().toArray(docHeadRows);
                DaoFactory.getImDocHeadAccessExt().createUsingProvidedDocId(docHeadRows);
            }

            if (ediDocBulk.getInvoiceDetail().size() > 0) {
                getInvoiceDetailDao().create(ediDocBulk.getInvoiceDetail());
            }

            if (ediDocBulk.getInvoiceDetailAllowance().size() > 0) {
                getInvoiceDetailAllowanceDao().persistInvoiceDetailAllowances(
                        ediDocBulk.getInvoiceDetailAllowance());
            }

            if (ediDocBulk.getDocDetailReasonCodes().size() > 0) {
                getDocDetailReasonCodesDao().create(ediDocBulk.getDocDetailReasonCodes());
            }

            if (ediDocBulk.getDocNonMerch().size() > 0) {
                getNonMerchandiseDao().persistNonMerchDocuments(ediDocBulk.getDocNonMerch());
            }

            if (ediDocBulk.getDocuments().size() > 0) {
                getDocumentTaxDao().persistDocumentTaxes(ediDocBulk.getDocuments());
            }

            if (ediDocBulk.getItemTaxAudit().size() > 0) {
                getItemTaxAuditDao().persistItemTaxAudit(ediDocBulk.getItemTaxAudit());
            }

            if (ediDocBulk.getTaxDiscrepancyList().size() > 0) {
                getTaxDiscrepancyDao().persistTaxDiscrepancies(ediDocBulk.getTaxDiscrepancyList());
            }

            ediDocBulk.setDocHead(new ArrayList<ImDocHeadRow>());
            ediDocBulk.setInvoiceDetail(new ArrayList<DocumentItemInvoice>());
            ediDocBulk.setInvoiceDetailAllowance(new ArrayList<InvoiceDetailAllowance>());
            ediDocBulk.setDocDetailReasonCodes(new ArrayList<DocumentItemReasonCode>());
            ediDocBulk.setDocNonMerch(new ArrayList<NonMerchandiseDocument>());
            ediDocBulk.setDocuments(new ArrayList<Document>());
            ediDocBulk.setItemTaxAudit(new ArrayList<ItemTaxAudit>());
            ediDocBulk.setTaxDiscrepancyList(new ArrayList<TaxDiscrepancy>());
            EdiDocumentService.initEdiDocBulk(ediDocBulk);

        } catch (Exception ex) {

            throw new DataAccessException(ex);

        }
}

    public static void createDocDetailReasonCodeRows(long docId,
            EdiTransactionDetail[] ediTransactionDetailList, Timestamp currentDate,
            List<DocumentItemReasonCode> docDetailReasonCodeList) throws ReIMException {
        try {
            // add to doc detail reason codes collection
            EdiTransactionDetail ediTransactionDetail = null;
            // ImDocDetailReasonCodesRow docDetailReasonCodeRow = null;
            DocumentItemReasonCode docDetailReasonCode = null;

            int ediTransactionDetailListLength = ediTransactionDetailList.length;
            for (int j = 0; j < ediTransactionDetailListLength; j++) {
                ediTransactionDetail = ediTransactionDetailList[j];
                // docDetailReasonCodeRow = new ImDocDetailReasonCodesRow();
                docDetailReasonCode = new DocumentItemReasonCode();
                // docDetailReasonCodeRow.setNullableFieldsToNull();
                docDetailReasonCode.setDocId(docId);
                docDetailReasonCode.setItem(new Item(ediTransactionDetail.getItem()));
                docDetailReasonCode.setReasonCode(ediTransactionDetail.getReasonCode());
                docDetailReasonCode.setStatus(Document.APPROVED);
                docDetailReasonCode.setCostMatched(Affirm.check(ReIMConstants.NO));
                docDetailReasonCode.setQtyMatched(Affirm.check(ReIMConstants.NO));

                double adjustedUnitCost = ediTransactionDetail.getOriginalUnitCost();
                docDetailReasonCode.setOriginalUnitCost(adjustedUnitCost > 0 ? -adjustedUnitCost
                        : adjustedUnitCost);
                docDetailReasonCode.setOriginalQty(ediTransactionDetail
                        .getOriginalDocumentQuantity());

                docDetailReasonCode.setAdjustedValuesFromOriginal();

                // // the following should be updated to support multiple taxes
                // docDetailReasonCode.addTax(new Tax(ediTransactionDetail
                // .getOriginalTaxCode(), ediTransactionDetail
                // .getOriginalTaxRate()));

                docDetailReasonCode.setTaxes(ediTransactionDetail.getEdiItemTaxes());

                docDetailReasonCodeList.add(docDetailReasonCode);
            }
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_doc_detail_row", Severity.ERROR, e,
                    EdiDocumentService.class);
        }
    }
    

    @Autowired
    public void setDocumentService(IDocumentService documentService) {
        this.documentService = documentService;
    }

    public IDocumentService getDocumentService() {
        return documentService;
    }

    private IPeriodService getPeriodService() {
        return ServiceFactory.getPeriodService();
    }   
    
    private ISystemOptionsService getSystemOptionsService() {
        return ServiceFactory.getSystemOptionsService();
    }
    
    private ISupplierBean getSupplierBean() throws RetekException {
        return DaoFactory.getSupplierBean();
    }
    
    private ILocationBean getLocationBean() throws RetekException {
        return DaoFactory.getLocationBean();
    }

    private ISystemOptionsBean getSystemOptionsBean() throws RetekException {
        return  DaoFactory.getSystemOptionsBean();
    }
    
    private AOrderBean getOrderBean() {
        return (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);
    }
    
    private ISupplierOptionsService getSupplierOptionsService() {
        return ServiceFactory.getSupplierOptionsService();
    }
    
    public IDocDetailReasonCodesDao getDocDetailReasonCodesDao() {
        return docDetailReasonCodesDao;
    }

    @Autowired
    public void setDocDetailReasonCodeDao(IDocDetailReasonCodesDao docDetailReasonCodesDao) {
        this.docDetailReasonCodesDao = docDetailReasonCodesDao;
    }

    public IDocumentDao getDocumentDao() {
        return documentDao;
    }

    @Autowired
    public void setDocumentDao(IDocumentDao documentDao) {
        this.documentDao = documentDao;
    }

    public IInvoiceDetailAllowanceDao getInvoiceDetailAllowanceDao() {
        return invoiceDetailAllowanceDao;
    }

    @Autowired
    public void setInvoiceDetailAllowanceDao(IInvoiceDetailAllowanceDao invoiceDetailAllowanceDao) {
        this.invoiceDetailAllowanceDao = invoiceDetailAllowanceDao;
    }

    public IInvoiceDetailDao getInvoiceDetailDao() {
        return invoiceDetailDao;
    }

    @Autowired
    public void setInvoiceDetailDao(IInvoiceDetailDao invoiceDetailDao) {
        this.invoiceDetailDao = invoiceDetailDao;
    }

    public INonMerchandiseEntryDao getNonMerchandiseDao() {
        return nonMerchandiseDao;
    }

    @Autowired
    public void setNonMerchandiseDao(INonMerchandiseEntryDao nonMerchandiseDao) {
        this.nonMerchandiseDao = nonMerchandiseDao;
    }

    public IDocumentTaxDao getDocumentTaxDao() {
        return documentTaxDao;
    }

    @Autowired
    public void setDocumentTaxDao(IDocumentTaxDao documentTaxDao) {
        this.documentTaxDao = documentTaxDao;
    }

    public IItemTaxAuditDao getItemTaxAuditDao() {
        return itemTaxAuditDao;
    }

    @Autowired
    public void setItemTaxAuditDao(IItemTaxAuditDao itemTaxAuditDao) {
        this.itemTaxAuditDao = itemTaxAuditDao;
    }

    public ITaxDiscrepancyDao getTaxDiscrepancyDao() {
        return taxDiscrepancyDao;
    }

    @Autowired
    public void setTaxDiscrepancyDao(ITaxDiscrepancyDao taxDiscrepancyDao) {
        this.taxDiscrepancyDao = taxDiscrepancyDao;
    }
    
    private IVendorService getVendorService() {
        return ServiceFactory.getVendorService();
    }
    
	public void setIseqDao(ISequencerDao iseqDao) {
		IseqDao = iseqDao;
	}

    public ISequencerDao getIseqDao() {
		return IseqDao;
	}

}
