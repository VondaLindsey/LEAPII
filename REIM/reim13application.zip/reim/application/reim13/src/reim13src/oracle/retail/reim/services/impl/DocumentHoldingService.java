package oracle.retail.reim.services.impl;

import java.util.Collection;
import java.util.List;

import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.document.DocumentReference;
import oracle.retail.reim.business.document.DocumentUtils;
import oracle.retail.reim.business.document.HoldStatus;
import oracle.retail.reim.data.dao.IDocumentHoldingDao;
import oracle.retail.reim.services.IDocumentHoldingService;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.reim.db.ImDocHeadRow;

/**
 * {@link IDocumentHoldingService} implementation. See the interface this implements for further
 * details.
 * 
 * @author Oracle Retail
 * 
 */
@Service
public class DocumentHoldingService implements IDocumentHoldingService {
    private IDocumentHoldingDao invoiceHoldingDao;

    public void holdDocumentsAfterRollup(Collection<ImDocHeadRow> rollupDocs) {

        /**
         * Get all the document references, and insert them into the cross reference.
         */
        List<DocumentReference> references = DocumentUtils.convertRows(rollupDocs);

        invoiceHoldingDao.updateInvoiceDocuments(references);
//        Anil P , We will not change the status of held invoices until the user
//        decides to change it through online
//        invoiceHoldingDao.updateDocumentHolding();
    }

    @Required
    public void setInvoiceHoldingDao(IDocumentHoldingDao invoiceHoldingDao) {
        this.invoiceHoldingDao = invoiceHoldingDao;
    }

    public void updateHoldStatus(DocId docId, HoldStatus status) {
        invoiceHoldingDao.updateHoldStatus(docId, status);
    }
}
