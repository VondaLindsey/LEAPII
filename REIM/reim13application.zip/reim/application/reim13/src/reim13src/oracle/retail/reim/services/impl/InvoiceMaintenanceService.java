package oracle.retail.reim.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.VendorType;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.services.IInvoiceMaintenanceService;
import oracle.retail.reim.utils.NumberUtils;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.retek.merch.utils.ApplicationContext;
import com.retek.reim.business.CodeDetail;
import com.retek.reim.business.Comment;
import com.retek.reim.business.InvoiceView;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Term;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.IImDocHeadAccessExt;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.merch.utils.ReIMAttributeManager;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMPageCodes;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.invoiceMaintenance.MaintenanceForm;
import com.retek.reim.ui.nonMerchandiseEntry.NonMerchandiseDocumentDisplay;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		21-May-2013	BNaik		BRN EDI Invoices should not be allowed to be edited.
 *     If any of the items are either matched or discrepancy routed(DETAIL_MATCHED='Y'), then the invoice will be in VIEW mode 
 * 		and cannot be edited. If not, the items can be edited in ready-for-match, unresolved match, and multi-unresolved invoices, and tax discrepancy status.
 * 										
 */

@Service
//TODO: Need to wire the services
//need to remove ServiceFactory Calls
public class InvoiceMaintenanceService implements IInvoiceMaintenanceService {

    public boolean validateTotalMerchandiseCostForMerchInvoices(String docType,
            String totalMerchandiseCost, String currencyCode) throws ReIMException {
        boolean retValue = true;
        if (docType.equals(Document.MERCHANDISE_INVOICE)) {
            double total = ReIMMoney.parseCurrencyString(totalMerchandiseCost, currencyCode)
                    .doubleValue();
            if (totalMerchandiseCost == null || total < 0) {
                retValue = false;
            }
        }
        return retValue;
    }

    public boolean validateCostRange(String value, String currencyCode) throws ReIMException {
        boolean retValue = true;

        double cost = ReIMMoney.parseCurrencyString(value, currencyCode).doubleValue();
        if (cost > Document.MAX_DOCUMENT_TOTAL_COST || cost < Document.MIN_DOCUMENT_TOTAL_COST) {
            retValue = false;
        }
        return retValue;
    }

    public boolean validateTotalNonMerchCostForNonMerchInvoices(String docType,
            String totalNonMerchCost, String currencyCode) throws ReIMException {
        boolean retValue = true;
        double total = 0;
        if (docType.equals(Document.NON_MERCHANDISE_INVOICE)) {
            if (totalNonMerchCost != null) {
                total = ReIMMoney.parseCurrencyString(totalNonMerchCost, currencyCode)
                        .doubleValue();
            }
            if (total == 0) {
                retValue = false;
            }
        }
        return retValue;
    }

    public boolean validateTotalMerchandiseCostForNonMerchInvoices(String docType,
            String totalMerchandiseCost, String currencyCode) throws ReIMException {
        boolean retValue = true;
        if (docType.equals(Document.NON_MERCHANDISE_INVOICE)) {
            double total = ReIMMoney.parseCurrencyString(totalMerchandiseCost, currencyCode)
                    .doubleValue();
            if (total != 0) {
                retValue = false;
            }
        }
        return retValue;
    }

    public boolean validateTotalInvoiceQtyForMerchInvoices(String docType, String invoiceQty)
            throws ReIMException {
        boolean retValue = true;
        if (docType.equals(Document.MERCHANDISE_INVOICE)) {
            // always verify qty > 0
            if (invoiceQty == null || invoiceQty.equals(ReIMConstants.EMPTY_STRING)
                    || ReIMQuantity.parseNumberString(invoiceQty).doubleValue() < 0) {
                retValue = false;
            }
        }
        return retValue;
    }

    public boolean validateTotalMerchCostAndSumOfExtendedItemCost(DocumentItemInvoice[] items,
            String totalMerchandiseCost, String currencyCode) throws ReIMException {
        boolean retValue = true;
        double extendedCostSum = 0;
        double totalMerchCost = ReIMMoney.parseCurrencyString(totalMerchandiseCost, currencyCode)
                .doubleValue();
        for (int i = 0; i < items.length; i++) {
            extendedCostSum += (ReIMMoney.parseCurrencyString(items[i].getExtendedCost(),
                    currencyCode).doubleValue());
        }

        double variancePercentage;
        double systemOptionsCalcTolerance = ReIMSystemOptions.getInstance().getCalcTolerance();
        boolean isPercentTolerance = ReIMSystemOptions.getInstance().getCalcToleranceInd().equals(
                ReIMSystemOptions.PERCENT);

        if (isPercentTolerance) {
            variancePercentage = (NumberUtils.roundDouble((Math.abs(NumberUtils.roundDouble(
                    totalMerchCost, 4)
                    - NumberUtils.roundDouble(extendedCostSum, 4))), 4) / totalMerchCost) * 100;
        } else {
            variancePercentage = (NumberUtils.roundDouble((Math.abs(NumberUtils.roundDouble(
                    totalMerchCost, 4)
                    - NumberUtils.roundDouble(extendedCostSum, 4))), 4));
        }

        if (variancePercentage > systemOptionsCalcTolerance) retValue = false;

        return retValue;
    }

    public boolean validateTotalInvoiceQtyAndSumOfItemQuantity(DocumentItemInvoice[] items,
            String invoiceQty) throws ReIMException {
        boolean retValue = true;
        double sumOfQuantity = 0;
        double totalInvoiceQty = 0;

        for (int i = 0; i < items.length; i++) {
            sumOfQuantity += items[i].getQty();
        }

        if (!StringUtils.isEmpty(invoiceQty)) {
            totalInvoiceQty = ReIMQuantity.parseNumberString(invoiceQty).doubleValue();
        }

        double variancePercentage;
        double systemOptionsCalcTolerance = ReIMSystemOptions.getInstance().getCalcTolerance();
        boolean isPercentTolerance = ReIMSystemOptions.getInstance().getCalcToleranceInd().equals(
                ReIMSystemOptions.PERCENT);
        ;

        if (isPercentTolerance) {
            variancePercentage = (NumberUtils.roundDouble((Math.abs(NumberUtils.roundDouble(
                    totalInvoiceQty, 4)
                    - NumberUtils.roundDouble(sumOfQuantity, 4))), 4) / totalInvoiceQty) * 100;
        } else {
            variancePercentage = (NumberUtils.roundDouble((Math.abs(NumberUtils.roundDouble(
                    totalInvoiceQty, 4)
                    - NumberUtils.roundDouble(sumOfQuantity, 4))), 4));
        }

        if (variancePercentage > systemOptionsCalcTolerance) retValue = false;

        return retValue;
    }

    public boolean validateInvoiceDateNotBeforeVDate(String invoiceDate, ReIMDate vDate)
            throws ReIMException {
        // invoice date must be equal to the businiss date or
        // before the business date

        boolean retValue = false;
        try {
            ReIMDate invDate = new ReIMDate(invoiceDate);

            if (invDate.equalsDate(vDate) || invDate.beforeDate(vDate)) {
                retValue = true;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_maintenance_header.update_failure",
                    Severity.ERROR, e, InvoiceMaintenanceService.class);
        }
        return retValue;
    }

    public boolean checkInvoiceDateBeforePostDatedDocDays(ReIMDate invoiceDate, ReIMDate vDate)
            throws ReIMException {
        // check to see if invoice date is earlier than/before vdate -
        // postDatedDocDays

        boolean retValue = false;
        try {
            // If the calling method does not already have the vDate, get it and
            // continue.
            if (vDate == null) {
                if (ApplicationContext.isBatchApplication()) {
                    vDate = ServiceFactory.getPeriodService().getVDate();
                } else {
                    vDate = ServiceFactory.getPeriodService().getScreenVDate();
                }
            }

            int postDocDays = ReIMUserContext.getSystemOptions().getPostDatedDocDays();
            ReIMDate earliestPostDatedDocDate = new ReIMDate(vDate);
            earliestPostDatedDocDate.addDays(-postDocDays);

            if (invoiceDate.before(earliestPostDatedDocDate)) {
                retValue = true;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_maintenance_header.update_failure",
                    Severity.ERROR, e, InvoiceMaintenanceService.class);
        }
        return retValue;
    }

    /**
     * This method removes "iv", and "commentsForm" shared session objects unconditionally.
     */
    public void removeSharedObjects() {
        ReIMAttributeManager.removeAttribute("iv");
        ReIMAttributeManager.setAttribute(ReIMPageCodes.INVOICE_VIEW, "iv", null);

        ReIMAttributeManager.removeAttribute("commentsForm");
        ReIMAttributeManager.setAttribute(ReIMPageCodes.COMMENTS, "CommentsForm", null);
    }

    public String saveHeaderForm(InvoiceView iv, Comment[] comments, String mode, String userId)
            throws ReIMException {
        try {
            // We want all updates/inserts commited or rolledback together!
            // TransactionManagerFactory.getInstance().start();

            String retString = Document.FAILED;
            ImDocHeadRow aRow = populateRowFromHeaderForm(iv, mode);
            DocumentItemInvoice[] invoiceDetailItems = iv.getInvoiceItemDetails();
            
            String vendor= iv.getVendorId();
            
            boolean isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions().isSupplierSiteInd();
            
            if (isSupplierSiteIndOn && iv.getSupplierSiteId() != null && iv.getSupplierSiteId().trim().length() !=0 ) {
            	
            	vendor=iv.getSupplierSiteId();
			}
            
            boolean taxRegionsEquals = ServiceFactory.getTaxService().isTax(
                    iv.getLocationId() + "", vendor + "", iv.getVendorType());
            if (iv.getDocId() != null && !iv.getDocId().equals(ReIMConstants.EMPTY_STRING)) {
                long docId = Long.parseLong(iv.getDocId());
                if (ReIMSystemOptions.getInstance().isProcessTaxes()) {
                    if (invoiceDetailItems == null) {
                        IInvoiceDetailService invoiceDetailService = ServiceFactory
                                .getInvoiceDetailService();
                        invoiceDetailItems = invoiceDetailService.getInvoiceItemsByInvoiceId(iv
                                .getDocId());
                    }
                    if (!ArrayUtils.isEmpty(invoiceDetailItems) && !ArrayUtils.isEmpty(iv.getTaxes())) {
                        boolean isHeaderAndDetailsHaveSameSetOfTaxes = ServiceFactory.getTaxService()
                                .validateTaxCodeExistInTaxes(invoiceDetailItems, iv.getTaxes());
                        if (!isHeaderAndDetailsHaveSameSetOfTaxes) { throw new ReIMException(
                                "error.taxService_all_details_tax_must_be_entered", Severity.ERROR,
                                InvoiceMaintenanceService.class); }
                    }

                }
                if (iv.getPrePaidInd().equals(ReIMConstants.YES)
                        && iv.getUnresolvedEditModeInd().equals(ReIMConstants.YES)) {
                    retString = Document.SUCCESS;
                } else {
                    retString = ServiceFactory.getDocumentService().updateImDocHeadRow(aRow);
                }
                if (retString.equals(Document.SUCCESS)) {
                    if (invoiceDetailItems != null && invoiceDetailItems.length != 0) {
                        // insert/update/delete detail items.

                        // get the current saved detail items
                        IInvoiceDetailService invoiceDetailService = ServiceFactory
                                .getInvoiceDetailService();
                        DocumentItemInvoice[] savedItems = invoiceDetailService
                                .getInvoiceItemsByInvoiceId(iv.getDocId());

                        // ArrayList of DocumentItems
                        List insertItems = new ArrayList();
                        // ArrayList of DocumentItems
                        List updateItems = new ArrayList();
                        // ArrayList of string itemIds
                        List deleteItems = new ArrayList();

                        separateActions(savedItems, invoiceDetailItems, insertItems, updateItems,
                                deleteItems);

                        // If tax processing, then check for discrepancies,
                        // write
                        // audit records.
                        if (ReIMSystemOptions.getInstance().isProcessTaxes() && taxRegionsEquals) {

                            populateDetailsForDocItems(invoiceDetailItems, String.valueOf(iv
                                    .getOrderNo()), iv.getVendorId(), new ReIMDate(iv
                                    .getInvoiceDate()), iv.getVendorType());
                            ServiceFactory.getDocumentService().validateItemTaxCodesAndRates(
                                    invoiceDetailItems, userId, iv.getLocationId(),
                                    Long.parseLong(iv.getDocId()));
                            // If returns true, then update doc_head_status if
                            // not already
                            // discrepant.
                            if (checkForItemTaxDiscrepancies(invoiceDetailItems)) {
                                // Do not update discrepant date if status does
                                // not change.
                                if (!aRow.getStatus().equals(Document.TAX_DISCREPANCY)) {
                                    aRow.setStatus(Document.TAX_DISCREPANCY);
                                    aRow.setTaxDiscCreateDate(ServiceFactory.getPeriodService()
                                            .getVDate().getTimestamp());
                                    ServiceFactory.getDocumentService().updateImDocHeadRow(aRow);
                                }

                            }
                            // else, no items are discrepant, update status to
                            // ready for match if
                            // not already
                            else {
                                if (!aRow.getStatus().equals(Document.READY_FOR_MATCH)
                                        && iv.getPrePaidInd().equals(ReIMConstants.NO)) {
                                    aRow.setStatus(Document.READY_FOR_MATCH);
                                    aRow.setTaxDiscCreateDateToNull();
                                    ServiceFactory.getDocumentService().updateImDocHeadRow(aRow);
                                }
                            }
                        }

                        // Details may be added to ready-for-match, unresolved
                        // match, and
                        // multi-unresolved invoices, and tax discrepant
                        if (insertItems.size() > 0) {
                            invoiceDetailService.createInvoiceItems(
                                    (DocumentItemInvoice[]) insertItems
                                            .toArray(new DocumentItemInvoice[0]), docId);
                        }
                        
                        // BRN V1.3 Begin - Removed status check
                        // If any of the items are either matched or discrepancy routed(DETAIL_MATCHED='Y'), then the invoice will be in VIEW mode 
                        // and cannot be edited. If not, the items can be edited in ready-for-match, unresolved match, and multi-unresolved invoices, and tax discrepancy status.
                        
                        // Only invoices that have not been through matching can
                        // update details!
                        // we can't!! update the resolution_adjusted amounts
                        // unless the document has
                        // not been through matching.                        
                        if (updateItems.size() > 0) {                       
                        	invoiceDetailService.updateInvoiceItems(docId,
                                    (DocumentItemInvoice[]) updateItems
                                            .toArray(new DocumentItemInvoice[0]));
                        }
                        // Only invoices that have not been through matching can
                        // delete details!
                        if (deleteItems.size() > 0) {
                            invoiceDetailService.deleteInvoiceItems(docId, deleteItems);
                        }
                        
                        // BRN V1.3 End
                    }

                    // edit non merch records
                    if (iv.getNonMerchandiseDocuments() != null
                            && iv.getNonMerchandiseDocuments().length > 0) {
                        populateTaxBasisAndAmountForNonMerchDocuments(iv
                                .getNonMerchandiseDocuments());
                        ServiceFactory.getNonMerchandiseDocumentService()
                                .insertOrUpdateNonMerchDoc(docId, iv.getNonMerchandiseDocuments());
                    } else {
                        NonMerchandiseDocument[] nonMerchDocs = new NonMerchandiseDocument[0];
                        ServiceFactory.getNonMerchandiseDocumentService()
                                .insertOrUpdateNonMerchDoc(docId, nonMerchDocs);
                    }

                    // edit tax breakdown records.
                    if (iv.getTaxes() != null && iv.getTaxes().length > 0) {
                        ServiceFactory.getDocumentService().insertOrUpdateDocTaxes(docId,
                                iv.getTaxes());
                    } else {
                        Tax[] taxes = new Tax[0];
                        ServiceFactory.getDocumentService().insertOrUpdateDocTaxes(docId, taxes);
                    }

                    if (comments != null) {
                        ArrayList commentsToInsert = new ArrayList();

                        int length = comments.length;
                        for (int i = 0; i < length; i++) {
                            if (comments[i].getCommentId() == null
                                    || comments[i].getCommentId()
                                            .equals(ReIMConstants.EMPTY_STRING)) {
                                commentsToInsert.add(comments[i]);
                            }
                        }
                        Comment[] inserts = new Comment[commentsToInsert.size()];
                        commentsToInsert.toArray(inserts);
                        ServiceFactory.getCommentService().insertComments(inserts, docId);
                    }
                }
            } else {
                retString = ServiceFactory.getDocumentService().createImDocHeadRow(aRow);
                if (retString.equals(Document.SUCCESS)) {
                    // Get the new doc id off the row
                    long docId = aRow.getDocId();
                    // set the doc id in the headerForm
                    iv.setDocId(String.valueOf(docId));

                    // Insert the detail records only for merch!
                    if (iv.getInvoiceItemDetails() != null
                            && iv.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
                        // If tax processing, then check for discrepancies,
                        // write
                        // audit records.

                        if (ReIMSystemOptions.getInstance().isProcessTaxes() && taxRegionsEquals) {
                            populateDetailsForDocItems(invoiceDetailItems, String.valueOf(iv
                                    .getOrderNo()), String.valueOf(iv.getVendorId()), new ReIMDate(
                                    iv.getInvoiceDate()), iv.getVendorType());
                            ServiceFactory.getDocumentService().validateItemTaxCodesAndRates(
                                    invoiceDetailItems, userId, iv.getLocationId(),
                                    Long.parseLong(iv.getDocId()));
                            // If returns true, then update doc_head_status
                            if (checkForItemTaxDiscrepancies(invoiceDetailItems)) {
                                aRow.setStatus(Document.TAX_DISCREPANCY);
                                aRow.setTaxDiscCreateDate(ServiceFactory.getPeriodService()
                                        .getVDate().getTimestamp());
                                ServiceFactory.getDocumentService().updateImDocHeadRow(aRow);
                            }
                        }

                        IInvoiceDetailService invoiceDetailService = ServiceFactory
                                .getInvoiceDetailService();
                        invoiceDetailService.createInvoiceItems(invoiceDetailItems, docId);
                    }

                    // - create non-merch (if exists)
                    if (iv.getNonMerchandiseDocuments() != null
                            && iv.getNonMerchandiseDocuments().length > 0) {
                        populateDocIdForNonMerchDocuments(iv.getNonMerchandiseDocuments(), iv
                                .getDocId());
                        populateTaxBasisAndAmountForNonMerchDocuments(iv
                                .getNonMerchandiseDocuments());
                        ServiceFactory.getNonMerchandiseEntryService().persistNonMerchDocuments(
                                Arrays.asList(iv.getNonMerchandiseDocuments()));
                    }

                    if (ServiceFactory.getReIMSystemOptionsService().select().isProcessTaxes()) {
                        ServiceFactory.getDocumentService().insertDocTaxes(docId, iv.getTaxes(),
                                userId, iv.getLocationId());
                    }

                    // - create comments (if exists)
                    ServiceFactory.getCommentService().insertComments(comments, docId);
                }
            }
            return retString;
        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.unable_to_save_invoice", Severity.ERROR, e,
                    InvoiceMaintenanceService.class);
        }
    }

    /**
     * This method loops through the passed in items and checks if any have the tax discrepant
     * indicator populated. If so, then at least one item is tax discrepant. This only holds true if
     * the system tax validation is set to 'RECON'cile TAX.
     * 
     * @param invoiceItems
     * @return
     * @throws ReIMException
     */
    private boolean checkForItemTaxDiscrepancies(DocumentItemInvoice[] invoiceItems) {
        boolean discrepant = false;
        if (ReIMSystemOptions.getInstance().isReconcileTax()) {
            for (int i = 0; i < invoiceItems.length; i++) {
                if (invoiceItems[i].isTaxDiscrepant()
                        && !invoiceItems[i].isTaxDiscrepancyResolved()) {
                    discrepant = true;
                    break;
                }
            }
        }
        return discrepant;
    }

    public void separateActions(DocumentItemInvoice[] savedItems,
            DocumentItemInvoice[] currentItems, List<DocumentItemInvoice> insertItems,
            List<DocumentItemInvoice> updateItems, List<String> deleteItems) throws Exception {
        // The user is not/should never be able to delete all details. Also,
        // currentItems will be null if the user never went to the details page
        // and we don't want to delete the existing ones!!
        if (currentItems != null && currentItems.length != 0) {
            // It is possible that the invoice was entered without details
            // so savedItems is null. All current items should be inserted.
            if (savedItems == null || savedItems.length == 0) {
                insertAllItems(currentItems, insertItems);
                return;
            }

            Map<String, DocumentItemInvoice> currentItemMap = new HashMap<String, DocumentItemInvoice>();
            int length = currentItems.length;

            // put items in map for easy comparison
            for (int i = 0; i < length; i++) {
                currentItemMap.put(currentItems[i].getItemId(), currentItems[i]);
            }

            String savedDocItemId = null;
            DocumentItemInvoice currentDocItem = null;

            length = savedItems.length;
            for (int i = 0; i < length; i++) {
                savedDocItemId = savedItems[i].getItemId();
                currentDocItem = currentItemMap.get(savedDocItemId);

                // saved item is not in the new list of items and should be
                // deleted
                if (currentDocItem == null) {
                    deleteItems.add(savedDocItemId);
                } else // saved item is in the new list and may have been
                // updated
                {
                    // check to see if it really needs updating?
                    // insert into updates list
                    updateItems.add(currentDocItem);

                    // remove this item from the map so we can track what extra
                    // new items should be
                    // inserted
                    currentItemMap.remove(savedDocItemId);

                }
            }
            // All the items left in the currentItemMap are new items that were
            // not in the
            // savedItems list
            // loop through array insead of iterating through the map to avoid
            // all the casting
            length = currentItems.length;
            for (int i = 0; i < length; i++) {
                if (currentItemMap.containsKey(currentItems[i].getItemId()))
                    insertItems.add(currentItems[i]);
            }
        }
    }

    protected void insertAllItems(DocumentItemInvoice[] items, List<DocumentItemInvoice> insertItems)
            throws Exception {
        int length = items.length;
        for (int i = 0; i < length; i++) {
            insertItems.add(items[i]);
        }
    }

    protected ImDocHeadRow populateRowFromHeaderForm(InvoiceView iv, String mode)
            throws ReIMException {
        ImDocHeadRow aRow = null;
        String docStatus = null;
        double totalInvoiceQty = 0;
        double totalCost = 0.0;
        long orderNo = 0;
        long location = 0;
        String locType = null;
        CodeDetail codeDetail = null;

        String bestTerms = null;
        String bestTermsSource = null;
        ReIMDate bestTermsDate = null;
        String bestTermsDateSource = null;
        boolean isSupplierSiteEnabled = false;

        try {
            if(ReIMUserContext.getSystemOptions().isSupplierSiteEnabled()) {
                isSupplierSiteEnabled = true;
            }
            // set up data for nullable and not nullable fields properly
            totalInvoiceQty = iv.getInvoiceQty();
            totalCost = iv.getTotalCost();
            if (iv.getOrderNo() == Integer.MIN_VALUE) {
                orderNo = Long.MIN_VALUE;
            } else {
                orderNo = iv.getOrderNo();
            }
            location = iv.getLocationId();

            ReIMDate invoiceDate = new ReIMDate(iv.getInvoiceDate());
            double exchangeRate = iv.getExchangeRate();

            // set up the doc status
            docStatus = iv.getDocStatus();
            if (iv.getDocumentType().equals(Document.NON_MERCHANDISE_INVOICE)) {
                bestTerms = iv.getInvoiceTermsId();
                bestTermsSource = Document.SOURCE_DOCUMENT;
                bestTermsDate = new ReIMDate(iv.getInvoiceDate());
                bestTermsDateSource = Document.SOURCE_DOCUMENT_DATE;
            }

            // if the location is not null and the type description is greater
            // than 1 get the type
            // CODE
            if (location != Long.MIN_VALUE && iv.getLocationType().length() > 1) {
                codeDetail = ServiceFactory.getCodeDetailService().getCodeDetailRowForTypeAndDesc(
                        CodeDetail.LOC_CODE_TYPE, iv.getLocationType());
                locType = codeDetail.getCode();
            } else {
                locType = iv.getLocationType();
            }

            if (mode.equals(MaintenanceForm.EDIT)
                    || (iv.getDocId() != null && !iv.getDocId().equals(ReIMConstants.EMPTY_STRING))) {
                aRow = new ImDocHeadRow();

                aRow.setDocId(ReIMI18NUtility.parseNumberString(iv.getDocId()).longValue());
                aRow.setType(iv.getDocumentType());
                aRow.setStatus(docStatus);
                aRow.setOrderNo(orderNo);
                aRow.setDocDate(invoiceDate.getTimestamp());
                if(isSupplierSiteEnabled) {
                    aRow.setSupplierSite(iv.getSupplierSiteId());
                }
                aRow.setVendor(iv.getVendorId());
                aRow.setLocation(location);
                aRow.setLocType(locType);
                aRow.setCurrencyCode(iv.getCurrencyCode());
                aRow.setExchangeRate(exchangeRate);
                aRow.setTerms(iv.getInvoiceTermsId());
                aRow.setTotalCost(totalCost);
                aRow.setTotalQty(totalInvoiceQty);
                aRow.setFreightType(iv.getFreightType());
                aRow.setManuallyPaidInd(iv.getManuallyPaidInd());
                aRow.setCustomDocRef1(iv.getCustomDocRef1());
                aRow.setCustomDocRef2(iv.getCustomDocRef2());
                aRow.setCustomDocRef3(iv.getCustomDocRef3());
                aRow.setCustomDocRef4(iv.getCustomDocRef4());
                aRow.setLastDatetime(new ReIMDate().getTimestamp());
                aRow.setLastUpdateId(ReIMUserContext.getUsername());
                aRow.setResolutionAdjustedTotalCost(totalCost);
                aRow.setResolutionAdjustedTotalQty(totalInvoiceQty);
                aRow.setTotalCostIncTax(iv.getEnteredTotalCostIncTax());
                aRow.setDueDate(iv.getDueDate() != null ? (new ReIMDate(iv.getDueDate())
                        .getSQL_Date()) : null);
                if (bestTerms != null) {
                    aRow.setBestTerms(bestTerms);
                } else {
                    aRow.setBestTermsToNull();
                }
                if (bestTermsSource != null) {
                    aRow.setBestTermsSource(bestTermsSource);
                } else {
                    aRow.setBestTermsSourceToNull();
                }
                if (bestTermsDate != null) {
                    aRow.setBestTermsDate(bestTermsDate.getTimestamp());
                } else {
                    aRow.setBestTermsDateToNull();
                }
                if (bestTermsDateSource != null) {
                    aRow.setBestTermsDateSource(bestTermsDateSource);
                } else {
                    aRow.setBestTermsDateSourceToNull();
                }

                IImDocHeadAccessExt docHeadAccess = DaoFactory.getImDocHeadAccessExt();
                ImDocHeadRow docHeadRow = docHeadAccess.read(Long.parseLong(iv.getDocId()), false);
                if (docHeadRow != null) aRow.setParentId(docHeadRow.getParentId());
                if (bestTerms != null && !bestTerms.equals(ReIMConstants.EMPTY_STRING)) {
                    Term termRow = ServiceFactory.getTermsService().getTerms(bestTerms);
                    aRow.setTotalDiscount((totalCost * termRow.getPercent()) / 100); // total
                    // discount
                } else {
                    Term termRow = ServiceFactory.getTermsService()
                            .getTerms(iv.getInvoiceTermsId());
                    aRow.setTotalDiscount((totalCost * termRow.getPercent()) / 100); // total
                    // discount
                }
            } else if (mode.equals(MaintenanceForm.NEW)
                    && (iv.getDocId() == null || iv.getDocId().equals(ReIMConstants.EMPTY_STRING))) {
                ReIMDate currentDate = new ReIMDate();
                Term termRow = ServiceFactory.getTermsService().getTerms(iv.getInvoiceTermsId());
                ReIMDate dueDate = new ReIMDate();
                ReIMDate approvalDate = null;
                if ((iv.getApprovalDate() != null)
                        && (!ReIMConstants.EMPTY_STRING.equals(iv.getApprovalDate()))) {
                    approvalDate = new ReIMDate(iv.getApprovalDate());

                }
                // this should not happen
                if (iv.getDueDate() == null || iv.getDueDate().equals(ReIMConstants.EMPTY_STRING)) {
                    // Discdays is used to calc due date so it is paid
                    // early enough to get discount
                    dueDate.addDays(termRow.getDiscdays());
                } else {
                    dueDate = new ReIMDate(iv.getDueDate());
                }

                aRow = new ImDocHeadRow(iv.getDocumentType(), docStatus, orderNo,
                        location,
                        // location
                        locType, // loc_type
                        Double.MIN_VALUE, // total_discount
                        Long.valueOf(iv.getGroupId()), // group_id
                        Long.MIN_VALUE, // parent id
                        invoiceDate.getTimestamp(), // doc_date
                        currentDate.getTimestamp(), // create_date
                        ReIMUserContext.getUsername(), // create_id
                        iv.getVendorType(), // vendor_type
                        iv.getVendorId(), // vendor_id
                        iv.getInvoiceNumber(), // ext_doc_id
                        ReIMConstants.NO, // edi_upload_ind
                        ReIMConstants.NO, // edi_download_ind
                        iv.getInvoiceTermsId(), // terms
                        termRow.getPercent(), // terms_dscnt_pct
                        dueDate.getSQL_Date(), // due_date
                        null, // payment_method
                        null, // match_id
                        null, // match_date
                        (approvalDate == null) ? null : ReIMUserContext.getUsername(), // approval_id
                        (approvalDate == null) ? null : approvalDate.getTimestamp(), // approval_date
                        ReIMConstants.NO, // forced_pay_ind
                        null, // forced_pay_id
                        null, // post_date
                        iv.getCurrencyCode(), // currency_code
                        exchangeRate,
                        totalCost, // total_cost
                        totalInvoiceQty, // total_qty
                        iv.getManuallyPaidInd(), // manually_paid_ind
                        iv.getCustomDocRef1(), // custom_doc_ref_1
                        iv.getCustomDocRef2(), // custom_doc_ref_2
                        iv.getCustomDocRef3(), // custom_doc_ref_3
                        iv.getCustomDocRef4(), // custom_doc_ref_4
                        ReIMUserContext.getUsername(), // last_update_id
                        new ReIMDate().getTimestamp(), // last_datetime
                        iv.getFreightType(), // freight_type
                        Long.MIN_VALUE, // ref_doc
                        Long.MIN_VALUE, // ref_auth_no
                        ReIMConstants.NO, // cost_pre_match
                        ReIMConstants.NO, // detail_Matched
                        bestTerms, bestTermsSource,
                        bestTermsDate == null ? null : bestTermsDate.getTimestamp(),
                        // best terms date
                        bestTermsDateSource, // best terms date source
                        Double.MIN_VALUE, // variance
                        totalCost, // resolution adjusted total cost
                        totalInvoiceQty, ReIMConstants.NO, Long.MIN_VALUE, ReIMConstants.NO, null,
                        null, iv.getEnteredTotalCostIncTax(),// TOTAL_COST_INC_TAX
                        null, iv.getHoldStatus().getCode());
                aRow.setSupplierSite(iv.getSupplierSiteId());
                // resolution adjusted total qty
                aRow.setTotalDiscount((totalCost * termRow.getPercent()) / 100); // total
                // discount
                if(isSupplierSiteEnabled) {
                    aRow.setSupplierSite(iv.getSupplierSiteId());
                }
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_maintenance_header.update_failure",
                    Severity.ERROR, e, InvoiceMaintenanceService.class);
        }
        return aRow;
    }

    protected boolean lockNewInvoice(long docId) throws ReIMException {
        try {
            String userId = ReIMUserContext.getUsername();
            ServiceFactory.getDocumentService().lockDocumentForUser(docId, userId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_maintenance_header.update_failure",
                    Severity.ERROR, e, InvoiceMaintenanceService.class);
        }
        return true;
    }

    public NonMerchandiseDocument[] getNonMerchDocArray(
            NonMerchandiseDocumentDisplay[] docNonMerchList) throws ReIMException {
        if (docNonMerchList == null) { return null; }

        NonMerchandiseDocument nonMerchDoc = null;
        List<NonMerchandiseDocument> nonMerchDocList = new ArrayList<NonMerchandiseDocument>();
        for (int i = 0; i < docNonMerchList.length; i++) {
            if (docNonMerchList[i].getNonMerchAmt() != 0) {
                nonMerchDoc = new NonMerchandiseDocument();
                nonMerchDoc.setNonMerchCode(docNonMerchList[i].getNonMerchCode());
                nonMerchDoc.setNonMerchCodeDesc(docNonMerchList[i].getNonMerchCodeDesc());
                double nonMerchAmt = docNonMerchList[i].getNonMerchAmt();
                nonMerchDoc.setNonMerchAmt(nonMerchAmt);

                nonMerchDoc.setTaxes(docNonMerchList[i].getTaxes());
                nonMerchDoc.setNonMerchTaxes(docNonMerchList[i].getTaxes());

                // get the service_ind from non_merch_code_head
                // NonMerchCodeHead aRow =
                // NonMerchService.getRowByNonMerchCode(docNonMerchList[i].getNonMerchCode());
                nonMerchDocList.add(nonMerchDoc);
            }
        }

        return (NonMerchandiseDocument[]) nonMerchDocList
                .toArray(new NonMerchandiseDocument[nonMerchDocList.size()]);
    }

    private void populateDocIdForNonMerchDocuments(
            NonMerchandiseDocument[] nonMerchandiseDocuments, String docId) {
        for (NonMerchandiseDocument nonMerchandiseDocument : nonMerchandiseDocuments) {
            nonMerchandiseDocument.setDocId(Long.valueOf(docId));
        }
    }

    private void populateDetailsForDocItems(DocumentItemInvoice[] documentItems, String orderNo,
            String vendorNo, ReIMDate docDate, String vendorType) {
        for (DocumentItemInvoice documentItemInvoice : documentItems) {
            documentItemInvoice.getDocument().setOrderNo(orderNo);
            documentItemInvoice.getDocument().setDocDate(docDate);
            documentItemInvoice.getDocument().setVendor(
                    new Vendor(vendorNo, VendorType.fromCode(vendorType)));
        }

    }

    private void populateTaxBasisAndAmountForNonMerchDocuments(NonMerchandiseDocument[] nonMerchDocs) {
        for (NonMerchandiseDocument nonMerchDoc : nonMerchDocs) {
            for (Tax nonMerchTax : nonMerchDoc.getTaxes()) {
                double nonMerchAmnt = nonMerchDoc.getNonMerchAmt();
                nonMerchTax.setTaxBasis(nonMerchAmnt);
                nonMerchTax.setTaxAmount(nonMerchAmnt * nonMerchTax.getTaxRate() / 100);
            }
        }
    }

}