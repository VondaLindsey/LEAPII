package oracle.retail.reim.data.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import oracle.retail.reim.business.EdiRejectDocumentDetailTaxSearchCriteria;
import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.dao.IEdiRejectDocumentDetailDao;
import oracle.retail.reim.data.dao.IEdiRejectDocumentDetailTaxDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.retek.reim.batch.ediupinv.EdiTransactionDetail;
import com.retek.reim.business.EdiRejectDocumentDetail;
import com.retek.reim.business.Item;
import com.retek.reim.db.ImEDIRejectDocDetailAccess;
import com.retek.reim.db.ImEDIRejectDocDetailAccessExt;
import com.retek.reim.db.ImEDIRejectDocDetailRow;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;

/**
 * -- Modification History
 * -- Version Date      Developer   Description
 * =======  ========= 	=========== ========================================================
 *    1.3	  01-Aug-2013	BNaik		IMS 170223 Edi invoices that have duplicate invoice number soft error
 *                                  (same supplier, same invoice but different PO) do not maintain
 *                                  the invoice detail when the year is appended to invoice number
 *                                  in SMR Edi Maintenance menu.
 */

@Repository
public class EdiRejectDocumentDetailDao extends SimpleJdbcDaoSupport implements
        IEdiRejectDocumentDetailDao {

    private IEdiRejectDocumentDetailTaxDao ediRejectDocumentDetailTaxDao;

    public void create(ImEDIRejectDocDetailRow newRow) {
        try {
            new ImEDIRejectDocDetailAccess().create(newRow);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void create(ImEDIRejectDocDetailRow[] newRows) {
        try {
            new ImEDIRejectDocDetailAccess().create(newRows);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void delete(ImEDIRejectDocDetailRow rowToDelete) {
        try {
            // Delete child table first because of integrity constraints
            getEdiRejectDocumentDetailTaxDao().deleteByDocIdDocDetailId(
                    new DocId(rowToDelete.getDocId()), rowToDelete.getDocDetailId());
            new ImEDIRejectDocDetailAccess().delete(rowToDelete);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void delete(long docId, long docDetailId) {
        try {
            new ImEDIRejectDocDetailAccess().delete(docId, docDetailId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public long getNextDocDetailId() {
        try {
            return new ImEDIRejectDocDetailAccess().getNextDocDetailId();
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public ImEDIRejectDocDetailRow[] read(DALGenPreparedSQLFragment whereClause,
            String additionalTables, String sqlHint, String orderBy) {
        try {
            return new ImEDIRejectDocDetailAccess().read(whereClause, additionalTables, sqlHint,
                    orderBy);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public ImEDIRejectDocDetailRow read(long docId, long docDetailId, boolean noRowsFoundIsError) {
        try {
            return new ImEDIRejectDocDetailAccess().read(docId, docDetailId, noRowsFoundIsError);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public ImEDIRejectDocDetailRow[] read(String whereClause, String additionalTables,
            String sqlHint, String orderBy) {
        try {
            return new ImEDIRejectDocDetailAccess().read(whereClause, additionalTables, sqlHint,
                    orderBy);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public ImEDIRejectDocDetailRow read(String columns[], long docId, long docDetailId,
            boolean noRowsFoundIsError) {
        try {
            return new ImEDIRejectDocDetailAccess().read(columns, docId, docDetailId,
                    noRowsFoundIsError);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public ImEDIRejectDocDetailRow[] read(String columns[], String whereClause,
            String additionalTables, String sqlHint, String orderBy) {
        try {
            return new ImEDIRejectDocDetailAccess().read(columns, whereClause, additionalTables,
                    sqlHint, orderBy);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void update(ImEDIRejectDocDetailRow rowToUpdate) {
        try {
            new ImEDIRejectDocDetailAccess().update(rowToUpdate);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void update(ImEDIRejectDocDetailRow rowToUpdate, Set<Tax> detailTaxes) {
        try {
            // Update child table first because of integrity constraints
            EdiRejectDocumentDetail documentItemInvoice = new EdiRejectDocumentDetail();
            documentItemInvoice.setDocId(rowToUpdate.getDocId());
            documentItemInvoice.setDocumentDetailId(rowToUpdate.getDocDetailId());
            documentItemInvoice.setTaxes(detailTaxes);
            getEdiRejectDocumentDetailTaxDao().update(documentItemInvoice);

            new ImEDIRejectDocDetailAccess().update(rowToUpdate);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void update(ImEDIRejectDocDetailRow[] rowsToUpdate) {
        try {
            new ImEDIRejectDocDetailAccess().update(rowsToUpdate);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void createWithSequence(ImEDIRejectDocDetailRow[] newRows,
            List<EdiRejectDocumentDetail> detailTaxes) {
        try {
            new ImEDIRejectDocDetailAccessExt().createWithSequence(newRows);
            getEdiRejectDocumentDetailTaxDao().persist(detailTaxes);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void delete(long docId) {
        try {
            // Delete child table first because of integrity constraints
            getEdiRejectDocumentDetailTaxDao().delete(new DocId(docId));
            new ImEDIRejectDocDetailAccessExt().delete(docId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public Item[] getDistinctItems(String supplierId) {
        try {
            return new ImEDIRejectDocDetailAccessExt().getDistinctItems(supplierId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public String[] getDocIds(String itemId, String supplierId) {
        try {
            return new ImEDIRejectDocDetailAccessExt().getDocIds(itemId, supplierId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public boolean itemExists(String supplierId, String itemId) {
        try {
            return new ImEDIRejectDocDetailAccessExt().itemExists(supplierId, itemId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public List<EdiRejectDocumentDetail> readByDocId(DocId docId) {
        try {
            ImEDIRejectDocDetailRow[] docDetailRow = new ImEDIRejectDocDetailAccessExt()
                    .readByDocId(docId.toLong());

            // Build searchCriteria for tax dao
            EdiRejectDocumentDetailTaxSearchCriteria searchCriteria = new EdiRejectDocumentDetailTaxSearchCriteria(
                    docId);
            List<EdiRejectDocumentDetail> taxDocuments = getEdiRejectDocumentDetailTaxDao()
                    .findDetailTaxes(searchCriteria);

            // Result document collection as List<EdiRejectDocumentDetail>
            List<EdiRejectDocumentDetail> rejectDetailList = new ArrayList<EdiRejectDocumentDetail>();

            for (ImEDIRejectDocDetailRow docDetail : docDetailRow) {
                EdiRejectDocumentDetail newDetail = new EdiRejectDocumentDetail();

                String item = docDetail.getItem();
                String vpn = docDetail.getVpn();
                double qty = docDetail.getDocQty();
                double unitCost = docDetail.getDocUnitCost();
                newDetail.setItem(item);
                newDetail.setVpn(vpn);
                // String[] upcDetails = upcBean.selectUpcDesc(item);
                // newDetail.setItemDesc(upcDetails[0]);

                // newDetail.setItemSupplement(upcDetails[1]);
                // newDetail.setItemTranLevel(upcDetails[2]);
                newDetail.setDocumentDetailId(new Long(docDetail.getDocDetailId()));
                newDetail.setQuantity(qty);
                newDetail.setUnitCost(unitCost);
                newDetail.setTotalLineItemCost(qty * unitCost);
                newDetail.setErrorColumnId(docDetail.getErrorColumnId());
                // newDetail.setCurrencyCode(currencyCode);

                // Append tax data to EdiTransactionDetail document
                for (EdiRejectDocumentDetail taxDocument : taxDocuments) {
                    if (taxDocument.getDocId() == docId.toLong().longValue()
                            && taxDocument.getDocumentDetailId().longValue() == docDetail
                                    .getDocDetailId()) {
                        newDetail.setTaxes(taxDocument.getTaxes());
                    }
                }

                rejectDetailList.add(newDetail);
            }

            return rejectDetailList;

        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public List<EdiTransactionDetail> readByDocuments(String[] documentIdList) {
        try {
            ImEDIRejectDocDetailRow[] docDetailRow = new ImEDIRejectDocDetailAccessExt()
                    .readByDocuments(documentIdList);

            // Build searchCriteria for tax dao
            List<DocId> docIds = new ArrayList<DocId>();
            for (int i = 0; i < documentIdList.length; i++) {
                docIds.add(new DocId(Integer.valueOf(documentIdList[i]).intValue()));
            }

            EdiRejectDocumentDetailTaxSearchCriteria searchCriteria = new EdiRejectDocumentDetailTaxSearchCriteria(
                    docIds);
            List<EdiRejectDocumentDetail> taxDocuments = getEdiRejectDocumentDetailTaxDao()
                    .findDetailTaxes(searchCriteria);

            // Result document collection as List<EdiTransactionDetail>
            List<EdiTransactionDetail> ediTransactionDetailList = new ArrayList<EdiTransactionDetail>();
            if (docDetailRow != null ) {
            for (int i = 0; i < docDetailRow.length; i++) {
                EdiTransactionDetail ediTransactionDetail = new EdiTransactionDetail(
                        docDetailRow[i].getDocId(), null, docDetailRow[i].getDocDetailId(),
                        docDetailRow[i].getItem(),
                        (docDetailRow[i].getItemSupplement() != null ? docDetailRow[i]
                                .getItemSupplement() : null),
                        (docDetailRow[i].getVpn() != null ? docDetailRow[i].getVpn() : null),
                        docDetailRow[i].getOrigDocQty(), docDetailRow[i].getOrigDocUnitCost());

                // Append tax data to EdiTransactionDetail document
                for (EdiRejectDocumentDetail taxDocument : taxDocuments) {
                    if (taxDocument.getDocId() == docDetailRow[i].getDocId()
                            && taxDocument.getDocumentDetailId().longValue() == (docDetailRow[i]
                                    .getDocDetailId())) {
                        ediTransactionDetail.setEdiItemTaxes(taxDocument.getTaxes());
                    }
                }

                ediTransactionDetailList.add(ediTransactionDetail);
            }
            }

            if (docDetailRow  != null ) {
            	// BRN V1.3 Begin
            	return ediTransactionDetailList;
            } else {
            	return null;
            	// BRN V1.3 End
          }

        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void replace(String oldItem, String newItem, String newItemSupplement, String supplierId) {
        try {
            new ImEDIRejectDocDetailAccessExt().replace(oldItem, newItem, newItemSupplement,
                    supplierId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public IEdiRejectDocumentDetailTaxDao getEdiRejectDocumentDetailTaxDao() {
        return ediRejectDocumentDetailTaxDao;
    }

    @Autowired
    public void setEdiRejectDocumentDetailTaxDao(
            IEdiRejectDocumentDetailTaxDao ediRejectDocumentDetailTaxDao) {
        this.ediRejectDocumentDetailTaxDao = ediRejectDocumentDetailTaxDao;
    }
}
