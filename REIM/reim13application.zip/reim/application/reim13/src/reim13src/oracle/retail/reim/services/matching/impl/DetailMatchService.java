package oracle.retail.reim.services.matching.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.services.IVarianceService;
import oracle.retail.reim.services.matching.IDetailMatchService;
import oracle.retail.reim.services.matching.IMatchService;
import oracle.retail.reim.services.matching.IMatchStatusService;
import oracle.retail.reim.utils.Severity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import smr.retek.reim.services.SmrDocumentService;

import com.retek.reim.RMSInterface.AShipmentAPI;
import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Tolerance;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.match.InvoiceDetailMatchGroup;
import com.retek.reim.business.match.InvoiceDetailSummaryLevel;
import com.retek.reim.business.match.Match;
import com.retek.reim.business.match.ReceiptDetailSummaryLevel;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.db.ImCostDiscrepancyAccessExt;
import com.retek.reim.db.ImPartiallyMatchedReceiptsAccessExt;
import com.retek.reim.db.ImResolutionActionAccessExt;
import com.retek.reim.foundation.AOrderLocationBean;
import com.retek.reim.locking.LockingData;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ReceiptService;
import com.retek.reim.services.ReceiptTrackingService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.matching.MatchHistoryService;
import com.retek.reim.ui.invoiceMatch.DetailMatchInvoiceView;
import com.retek.reim.ui.invoiceMatch.DetailMatchItemsView;
import com.retek.reim.ui.invoiceMatch.DetailMatchListForm;
import com.retek.reim.ui.invoiceMatch.DetailMatchReceiptView;

/**
 * This service is created to move the older <com.retek..>DetailMatchService methods to the new
 * Spring framework. These methods NEED TO BE refactored to perform efficiently with the new
 * framework.
 * 
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.4    14-May-2013   After the item is resolved using split receipt, invoice item is set to matched.
 *    The remaining receipt item was still be seen in Detail Matching screen, but the item description was blank.
 *    1.5    20-June-2013   If the receipt item is quantity matched, then the record did not show up in Detail Matching screen for cost resolution. 
 *                    If the receipt was matched, there was an NullPointerException in Summary Match List screen.
 *    1.6    09-Jul-2013  The users are trained to always resolve cost discrepancies first.      
 *                                     If the receipt item is quantity matched, then the record should not show up in Detail Matching screen.
 *                                     If the receipt item was matched, there was an NullPointerException in Summary Match List screen.                   
 */
 
@Service
public class DetailMatchService implements IDetailMatchService {

    private IMatchStatusService matchStatusService;
    private IMatchService matchService;
    private IVarianceService varianceService;

    /**
     * Method persistInBalanceMatches. This method takes in a list of DetailMatchItemsView's which
     * consist of lists invoice items and lists of receipt items. These have already been determined
     * as matcheds. For each of the DetailMatchItemsView, it calls submitForMatch to create a match
     * object, then places that in an array of matches then passes that to the persistDetailMatches
     * method to update the database.
     */
    public void persistInBalanceMatches(DetailMatchItemsView[] inBalanceItemsList, String userId)
            throws ReIMException {
        try {
            Match[] matches = new Match[inBalanceItemsList.length];
            for (int i = 0; i < inBalanceItemsList.length; i++) {
                DocumentItemInvoice[] invoiceItems = inBalanceItemsList[i].getInvoiceItems();
                ReceiptItem[] receiptItems = inBalanceItemsList[i].getReceiptItems();
                Match match = submitForMatch(invoiceItems, receiptItems, null);
                if (!match.isMatchSuccessful()) { throw new ReIMException(
                        "error.detail_match_service.persist_in_balance_matches_error",
                        Severity.DEBUG, DetailMatchService.class); }
                matches[i] = match;
            }
            persistDetailMatches(matches, userId);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_persist_in_balance_matches",
                    Severity.ERROR, e, DetailMatchService.class);
        }
    }

    /**
     * Method executeMatch. This method takes in a list of invoice items and a list of receipt
     * items. It calls submitForMatch which builds a match object out of those and submits that for
     * a match. It then calls persistDetailMatches to update the database.
     */
    public boolean executeMatch(DetailMatchInvoiceView[] invoiceItemGroupList,
            DetailMatchReceiptView[] receiptItemGroupList, String userId) throws ReIMException {
        try {
            DocumentItemInvoice[] invoiceItems = new DocumentItemInvoice[invoiceItemGroupList.length];
            for (int i = 0; i < invoiceItemGroupList.length; i++) {
                invoiceItems[i] = invoiceItemGroupList[i].getDocumentItem();
            }
            ReceiptItem[] receiptItems = new ReceiptItem[receiptItemGroupList.length];
            for (int i = 0; i < receiptItemGroupList.length; i++) {
                receiptItems[i] = receiptItemGroupList[i].getReceiptItem();
            }
            Match match = submitForMatch(invoiceItems, receiptItems, null);
            Match[] theOnlyMatch = { match};
            boolean isMatchSuccessful = match.isMatchSuccessful();
            
            if (isMatchSuccessful) {
                persistDetailMatches(theOnlyMatch, userId);
            }
            
            return isMatchSuccessful;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_execute_match",
                    Severity.ERROR, e, DetailMatchService.class);
        }
    }

    /**
     * Method rebuildDetailViews.
     * 
     * This method takes in a discrepantItem and an invoice item. It builds a
     * invoiceDetailSummaryLevel and a receiptDetailSummaryLevel. It then recreates one discrepant
     * item.
     * 
     */
    public Map rebuildDetailViews(DetailMatchItemsView[] discrepantItemList,
            DocumentItemInvoice[] invoiceItems, ReceiptItem[] receiptItems, String currencyCode,
            DetailMatchListForm dmListForm) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            // Get all invoice lines from the existing discrepant item list, and
            // selected invoice items
            // and build a hashmap of InvoiceDetailSummaryLevels that will later
            // be used to
            // attemp a match
            Map invoiceDetailSummaryLevels = buildInvoiceDetailSummaryLevels(discrepantItemList,
                    invoiceItems);
            // Get all receipt lines from the existing discrepant item list, and
            // selected receipts items
            // and build a hashmap of ReceiptDetailSummaryLevels that will later
            // be used to
            // attemp a match
            Map receiptDetailSummaryLevels = buildReceiptDetailSummaryLevels(discrepantItemList,
                    receiptItems);
            // For each invoiceDetailSummaryLevel (group of invoice items) key
            // (item+qty),
            // check if there is a receiptDetailSummaryLevel (group of receipt
            // items) with
            // the same key. If so, build a match object out of those and try to
            // match.
            // If match is successful, add to in balance list and remove from
            // both invoice
            // and receipt detail summary level maps. The remainders will be
            // dealt with later.
            List InvoiceDetailSummaryLevelList = new ArrayList(invoiceDetailSummaryLevels.values());
            List receiptDetailSummaryLevelList = new ArrayList(receiptDetailSummaryLevels.values());
            // Take the remaining invoiceDetailSummaryLevels and consolidate by
            // item (regardless of unit cost).
            Map discrepantInvoices = buildDiscrepantInvoices(InvoiceDetailSummaryLevelList);
            // Take the remaining receiptDetailSummaryLevels and consolidate by
            // item (regardless of unit cost).
            Map discrepantReceipts = buildDiscrepantReceipts(receiptDetailSummaryLevelList);
            // For each discrepant item/invoices, check if there exists a
            // discrepant
            // item/receipts. If so, build a discrepant item detail match view
            Map discrepantItems = buildDiscrepantItems(discrepantInvoices, discrepantReceipts,
                    currencyCode, dmListForm);
            // loop through the remaining receipts and buid discrepant item for
            // just the receipt side
            buildDiscrepantItemsFromRemainingReceipts(discrepantReceipts, discrepantItems,
                    currencyCode);
            return discrepantItems;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_building_detail_views",
                    Severity.ERROR, e, DetailMatchService.class);
        } /*
           * finally { TransactionManagerFactory.getInstance().end(); }
           */
    }

    /**
     * Method buildDetailViewsFromSummaryGroup.
     * 
     * This method takes in an umatched group of invoices and receipts from on-line summary
     * matching. It summs up the quantities and determines unit cost by item. It uses the match
     * service to determine if the item is in balance or discrepant.
     * 
     */

    public List buildDetailViewsFromSummaryGroup(Map unmatchedInvoiceMap, Map unmatchedReceiptMap,
            String currencyCode, DetailMatchListForm dmListForm) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            // Get all invoice lines from the invoiceSummaryGroupLevel of the
            // unmatched group
            // and build a hashmap of InvoiceDetailSummaryLevels that will later
            // be used to
            // attemp a match
            Map invoiceDetailSummaryLevels = buildInvoiceDetailSummaryLevels(unmatchedInvoiceMap);
            // Get all receipt lines from the receiptSummaryGroupLevel of the
            // unmatched group
            // and build a hashmap of ReceiptDetailSummaryLevels that will later
            // be used to
            // attemp a match
            Map receiptDetailSummaryLevels = buildReceiptDetailSummaryLevels(unmatchedReceiptMap);
            // For each invoiceDetailSummaryLevel (group of invoice items) key
            // (item+qty),
            // check if there is a receiptDetailSummaryLevel (group of receipt
            // items) with
            // the same key. If so, build a match object out of those and try to
            // match.
            // If match is successful, add to in balance list and remove from
            // both invoice
            // and receipt detail summary level maps. The remainders will be
            // dealt with later.
            Map inBalanceItems = new HashMap();
            List remainingInvoiceDetailSummaryLevels = new ArrayList();
            createInBalanceItems(invoiceDetailSummaryLevels, receiptDetailSummaryLevels,
                    inBalanceItems, remainingInvoiceDetailSummaryLevels, currencyCode, dmListForm);
            // Take the remaining invoiceDetailSummaryLevels and consolidate by
            // item (regardless of unit cost).
            Map discrepantInvoices = buildDiscrepantInvoices(remainingInvoiceDetailSummaryLevels);
            // Take the remaining receiptDetailSummaryLevels and consolidate by
            // item (regardless of unit cost).
            List receiptDetailSummaryLevelList = new ArrayList(receiptDetailSummaryLevels.values());
            Map discrepantReceipts = buildDiscrepantReceipts(receiptDetailSummaryLevelList);
            // For each discrepant item/invoices, check if there exists a
            // discrepant
            // item/receipts. If so, build a discrepant item detail match view
            Map discrepantItems = buildDiscrepantItems(discrepantInvoices, discrepantReceipts,
                    currencyCode, dmListForm);
            // loop through the remaining receipts and buid discrepant item for
            // just the receipt side
            buildDiscrepantItemsFromRemainingReceipts(discrepantReceipts, discrepantItems,
                    currencyCode);
            List itemList = new ArrayList();
            itemList.add(0, inBalanceItems);
            itemList.add(1, discrepantItems);
            return itemList;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_building_detail_views",
                    Severity.ERROR, e, DetailMatchService.class);
        } /*
           * finally { TransactionManagerFactory.getInstance().end(); }
           */
    }

    /**
     * Method buildDiscrepantItemsFromRemainingReceipts. This method loops though the receipts and
     * builds discrepant items just for the receipt side.
     */
    private/* static */void buildDiscrepantItemsFromRemainingReceipts(Map discrepantReceipts,
            Map discrepantItems, String currencyCode) {
        Collection remainingDiscrepantReceipts = discrepantReceipts.values();
        Iterator iterator4 = remainingDiscrepantReceipts.iterator();
        for (int i = 0; i < remainingDiscrepantReceipts.size(); i++) {
            ReceiptDetailSummaryLevel receiptDetailSummaryLevel = (ReceiptDetailSummaryLevel) iterator4
                    .next();
            ReceiptItem[] discrepantReceiptItems = (receiptDetailSummaryLevel.getReceiptItems());
            // initialize quantities and unit costs
            double totalReceiptQty = discrepantReceiptItems[0].getAvailableToMatchQty();
            double receiptUnitCost = discrepantReceiptItems[0].getUnitCost();
            String receiptUnitCostString = discrepantReceiptItems[0].getUnitCost() + "";
            for (int j = 1; j < discrepantReceiptItems.length; j++) {
                totalReceiptQty += discrepantReceiptItems[j].getAvailableToMatchQty();
                if (receiptUnitCost != discrepantReceiptItems[j].getUnitCost()) {
                    receiptUnitCostString = ReIMConstants.MULT;
                }
            }
            Item item = receiptDetailSummaryLevel.getReceiptItems()[0].getItem();

            // The invoice fields are empty since there is no invoice data
            // The variances and within tolerance indicators are empty because
            // they're not applicable
            DetailMatchItemsView discrepantItem = new DetailMatchItemsView(
                    receiptDetailSummaryLevel.getItemId(), item.getItemName(), item.getVpn(), "",
                    "", receiptUnitCostString, "", "", "", "", totalReceiptQty + "", "", "", "",
                    new DocumentItemInvoice[0], receiptDetailSummaryLevel.getReceiptItems(),
                    currencyCode);
            discrepantItems.put(receiptDetailSummaryLevel.getItemId(), discrepantItem);
        } // end for remainig receipts
    }

    /**
     * Method persistDetailMatches. This method takes in an array of match objects and persists
     * those matches to the database. For each of the DetailMatchItemsView, it creates an array of
     * match objects then calls persistDetailMatches to update the database.
     */
    private/* static */void persistDetailMatches(Match[] matches, String userId)
            throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();

            for (int i = 0; i < matches.length; i++) {
                Match match = matches[i];
                
                if (match.isMatchSuccessful()) {
                    checkRequiredLocks(match, userId);
                    // check locks
                    MerchandiseDocument[] invoices = match.getInvoiceGroup().getInvoices();
                    Receipt[] receipts = match.getReceiptGroup().getReceipts();
                    LockingData docHeadTable = LockingData.DOC_HEAD_LOCK_TABLE;
                    LockingData receiptTable = LockingData.RECEIPT_LOCK_TABLE;
                    String lockingUser = "";
                    String extDocId = "";
                    for (int j = 0; j < invoices.length; j++) {
                        extDocId = invoices[j].getExtDocId();
                        lockingUser = ServiceFactory
                                .getTableRecordLockingService()
                                .getUserIdLockingRecordOnTable(docHeadTable, invoices[j].getDocId());
                        if (lockingUser == null) {
                            // TransactionManagerFactory.getInstance().rollback();
                            throw new ReIMException(
                                    "error.detail_match_service.invoice_not_locked",
                                    Severity.DEBUG, DetailMatchService.class,
                                    new String[] { extDocId});
                        }
                        if (!lockingUser.equals(userId)) {
                            // TransactionManagerFactory.getInstance().rollback();
                            throw new ReIMException("error.detail_match_service.invoice_locked",
                                    Severity.DEBUG, DetailMatchService.class, new String[] {
                                            extDocId, lockingUser});
                        }
                    }
                    String receiptId = "";
                    for (int j = 0; j < receipts.length; j++) {
                    	                    			
                        receiptId = receipts[j].getReceiptId();
                        lockingUser = ServiceFactory.getTableRecordLockingService()
                                .getUserIdLockingRecordOnTable(receiptTable,
                                        new Long(receipts[j].getReceiptId()).longValue());
                        if (lockingUser == null) {
                            // TransactionManagerFactory.getInstance().rollback();
                            throw new ReIMException(
                                    "error.detail_match_service.receipt_not_locked",
                                    Severity.DEBUG, DetailMatchService.class,
                                    new String[] { receiptId});
                        }
                        if (!lockingUser.equals(userId)) {
                            // TransactionManagerFactory.getInstance().rollback();
                            throw new ReIMException("error.detail_match_service.receipt_locked",
                                    Severity.DEBUG, DetailMatchService.class, new String[] {
                                            receiptId, lockingUser});
                        }
                    }
                    // Set the varianceWithinTolerance fields
                    getVarianceService().setDetailVarianceWithinTolerance(match);
                    // Persist invoice related fields
                    DocumentItemInvoice[] invoiceItems = ((InvoiceDetailSummaryLevel) match
                            .getInvoiceGroup()).getInvoiceItems();
                    for (int j = 0; j < invoiceItems.length; j++) {
                        invoiceItems[j].setStatus(DocumentItemInvoice.MATCHED);
                        invoiceItems[j].setCostMatched(true);
                        invoiceItems[j].setQtyMatched(true);
                    }
                    // The following service call updates costMatched,
                    // qtyMatched on documentItem
                    // It also updates the detail_matched_status on
                    // MerchandiseDocument, then checks
                    // if all items for that invoice are in matched status,
                    // change the invoice status
                    // to matched
                    List matchedInvoiceIdsPerMatch = getMatchStatusService()
                            .updateInvoiceLinesStatus(invoiceItems, userId);
   
                    deleteDiscrepanciesAndResolutions(invoiceItems);
                    persistReceiptInfo(match, matches);
                }
            }

            MatchHistoryService.persistSuccessfulDetailLevelMatches(matches, false);

        } catch (ReIMException e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw (e);
        } catch (Exception e) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.detail_match_service.failed_persist_detail_matches",
                    Severity.ERROR, e, DetailMatchService.class);
        } /*
           * finally { TransactionManagerFactory.getInstance().end(); }
           */
    }

    /**
     * Method createInBalanceItems. This Method checks if there is a receiptDetailSummaryLevel
     * available for every invoiceDetailSummaryLevel. If there is one then the metod builds a match
     * object out of those receipts and invoices and tries to match. If match is successful it adds
     * them to the inBalance items List and removes them from both invoice and receipts Maps. If
     * not, they go into the remaining invoice detail summary levels so that they go into building
     * the discrepancy items.
     */
    private/* static */void createInBalanceItems(Map invoiceDetailSummaryLevels,
            Map receiptDetailSummaryLevels, Map inBalanceItems,
            List remainingInvoiceDetailSummaryLevels, String currencyCode,
            DetailMatchListForm dmListForm) throws ReIMException {
        String itemCostKey = "";
        Collection invoiceDetailSummaryLevelsKeys = invoiceDetailSummaryLevels.keySet();
        Iterator iterator = invoiceDetailSummaryLevelsKeys.iterator();
        for (int i = 0; i < invoiceDetailSummaryLevelsKeys.size(); i++) {
            itemCostKey = (String) iterator.next();
            InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = (InvoiceDetailSummaryLevel) invoiceDetailSummaryLevels
                    .get(itemCostKey);
            if (receiptDetailSummaryLevels.containsKey(itemCostKey)) {
                ReceiptDetailSummaryLevel receiptDetailSummaryLevel = (ReceiptDetailSummaryLevel) receiptDetailSummaryLevels
                        .get(itemCostKey);
                Match match = new Match();
                try {
                    match = submitForMatch(invoiceDetailSummaryLevel.getInvoiceItems(),
                            receiptDetailSummaryLevel.getReceiptItems(), dmListForm);
                } catch (ReIMException e) {
                    if (e
                            .getMessage()
                            .equals(
                                    ReIMI18NUtility
                                            .getMessage("error.detail_match_service.mixed_match_status_error"))) {
                        remainingInvoiceDetailSummaryLevels.add(invoiceDetailSummaryLevel);
                        continue;
                    } else {
                        throw (e);
                    }
                }
                if (match.isMatchSuccessful()) {
                    // the inReviewInd should be blank since the invoice should
                    // not be in review
                    // the costVariance is 0 since we are looking for receipts
                    // with exact unit cost
                    // costWithinToleranceInd and qtyWithinToleranceInd are "Y"
                    // since there are no variance
                    DetailMatchItemsView inBalanceItem = new DetailMatchItemsView(
                            invoiceDetailSummaryLevel.getItem().getItemId(),
                            invoiceDetailSummaryLevel.getItem().getItemName(),
                            invoiceDetailSummaryLevel.getItem().getVpn(), "", "",
                            receiptDetailSummaryLevel.getReceiptItems()[0].getUnitCost() + "",
                            receiptDetailSummaryLevel.getReceiptItems()[0].getUnitCost() + "",
                            invoiceDetailSummaryLevel.getInvoiceItems()[0]
                                    .getResolutionAdjustedUnitCost()
                                    + "", ReIMConstants.ZERO_STRING, ReIMConstants.YES, match
                                    .getReceiptGroup().getQty().toString(), match.getInvoiceGroup()
                                    .getQty().toString(), getVarianceService()
                                    .calculateQtyVariance(match)
                                    + "", ReIMConstants.YES, invoiceDetailSummaryLevel
                                    .getInvoiceItems(),
                            receiptDetailSummaryLevel.getReceiptItems(), currencyCode);
                    inBalanceItems.put(itemCostKey, inBalanceItem);
                    // remove receipt so we can deal with only the reamining
                    // receipts later
                    receiptDetailSummaryLevels.remove(itemCostKey);
                } // end if match successful
                else {
                    remainingInvoiceDetailSummaryLevels.add(invoiceDetailSummaryLevel);
                }

            } // end if receiptDetailSummaryLevels contains key
            else {
                remainingInvoiceDetailSummaryLevels.add(invoiceDetailSummaryLevel);
            }
        } // end for
    }

    /*
     * Determine if a group of invoices and receipts are potentially resolvable. It would be
     * considered nonresolvable if the unit cost of any given item in the grouping varies accross
     * POs.
     */
    public void validateResolvable(Collection invoices, Collection receipts) throws ReIMException {
        // Just ignore this whole issue if there's only a single PO involved.
        if (!multiplePosExist(invoices, receipts)) { return; }

        for (Iterator invIter = invoices.iterator(); invIter.hasNext();) {
            MerchandiseDocument invoice = (MerchandiseDocument) invIter.next();
            for (Iterator invDetailIter = invoice.getDocDetail().values().iterator(); invDetailIter
                    .hasNext();) {
                DocumentItemInvoice invoiceDetail = (DocumentItemInvoice) invDetailIter.next();

                for (Iterator rcptIter = receipts.iterator(); rcptIter.hasNext();) {
                    Receipt receipt = (Receipt) rcptIter.next();
                    for (Iterator rcptDetailIter = receipt.getReceiptItems().values().iterator(); rcptDetailIter
                            .hasNext();) {
                        ReceiptItem receiptDetail = (ReceiptItem) rcptDetailIter.next();

                        if ((!invoice.getOrderNo().equals(receipt.getOrderId()))
                                && invoiceDetail.getItemId().equals(receiptDetail.getItemId())
                                && (invoiceDetail.getUnitCost() != receiptDetail.getUnitCost())
                                && receiptDetail.getAvailableToMatchQty() > 0) { throw new ReIMException(
                                "error.detail_match_unresolvable", Severity.VALIDATION, this); }
                    }
                }
            }
        }
    }

    /**
     * Method buildDiscrepantItems. This metod assembles discrepant items out of discrepant invoices
     * and discrepant receipts
     */
    private/* static */Map buildDiscrepantItems(Map discrepantInvoices, Map discrepantReceipts,
            String currencyCode, DetailMatchListForm dmListForm) throws ReIMException {
        Map discrepantItems = new HashMap();
        String itemKey = "";
        Collection discrepantInvoiceKeys = discrepantInvoices.keySet();
        Iterator iterator = discrepantInvoiceKeys.iterator();
        for (int i = 0; i < discrepantInvoiceKeys.size(); i++) {
            itemKey = (String) iterator.next();
            InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = (InvoiceDetailSummaryLevel) discrepantInvoices
                    .get(itemKey);
            DocumentItemInvoice[] discrepantInvoiceItems = (invoiceDetailSummaryLevel
                    .getInvoiceItems());
            // initialize quantities and unit costs
            double totalInvoiceQty = discrepantInvoiceItems[0].getResolutionAdjustedQtyInvoiced();
            double invoiceUnitCost = discrepantInvoiceItems[0].getResolutionAdjustedUnitCost();
            String invoiceUnitCostString = discrepantInvoiceItems[0]
                    .getResolutionAdjustedUnitCost()
                    + "";
            double orderUnitCost = discrepantInvoiceItems[0].getOrderUnitCost();
            String orderUnitCostString = discrepantInvoiceItems[0].getOrderUnitCost() + "";
            String matchStatus = "";
            if (discrepantInvoiceItems[0].isCostMatched())
                matchStatus = ReIMConstants.DISCREPANCY_TYPE_COST_ABBR;
            else if (discrepantInvoiceItems[0].isQtyMatched())
                matchStatus = ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR;
            for (int j = 1; j < discrepantInvoiceItems.length; j++) {
                totalInvoiceQty += discrepantInvoiceItems[j].getResolutionAdjustedQtyInvoiced();
                if (invoiceUnitCost != discrepantInvoiceItems[j].getResolutionAdjustedUnitCost()) {
                    invoiceUnitCostString = ReIMConstants.MULT;
                }
                if (orderUnitCost != discrepantInvoiceItems[j].getOrderUnitCost()) {
                    orderUnitCostString = ReIMConstants.MULT;
                }

                if (discrepantInvoiceItems[j].isCostMatched()) {
                    if (matchStatus.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR)
                            || matchStatus.equals("")) matchStatus = ReIMConstants.MULT;
                } else if (discrepantInvoiceItems[j].isQtyMatched()) {
                    if (matchStatus.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)
                            || matchStatus.equals("")) matchStatus = ReIMConstants.MULT;
                } else if (matchStatus.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)
                        || matchStatus.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR))
                    matchStatus = ReIMConstants.MULT;
            }
            if (discrepantReceipts.containsKey(itemKey)) {
                ReceiptDetailSummaryLevel receiptDetailSummaryLevel = (ReceiptDetailSummaryLevel) discrepantReceipts
                        .get(itemKey);
                ReceiptItem[] discrepantReceiptItems = (receiptDetailSummaryLevel.getReceiptItems());
                // initialize quantities and unit costs
                double totalReceiptQty = discrepantReceiptItems[0].getAvailableToMatchQty();
                double receiptUnitCost = discrepantReceiptItems[0].getUnitCost();
                String receiptUnitCostString = discrepantReceiptItems[0].getUnitCost() + "";
                for (int j = 1; j < discrepantReceiptItems.length; j++) {
                    totalReceiptQty += discrepantReceiptItems[j].getAvailableToMatchQty();
                    if (receiptUnitCost != discrepantReceiptItems[j].getUnitCost()) {
                        receiptUnitCostString = ReIMConstants.MULT;
                    }
                }
                Match match = submitForMatch2(discrepantInvoiceItems, discrepantReceiptItems, true,
                        dmListForm);
                double costVariance = 0;
                String costVarianceString = "";
                String costWithinToleranceInd = "";
                String qtyWithinToleranceInd = "";

                if (!invoiceUnitCostString.equals(ReIMConstants.MULT)
                        && !receiptUnitCostString.equals(ReIMConstants.MULT)) {
                    costVariance = getVarianceService().calculateCostVariance(match);
                    costVarianceString = costVariance + "";
                    if (match.isCostMatchSuccessful()) {
                        costWithinToleranceInd = ReIMConstants.YES;
                    } else {
                        costWithinToleranceInd = ReIMConstants.NO;
                    }
                }
                if (match.isQtyMatchSuccessful()) {
                    qtyWithinToleranceInd = ReIMConstants.YES;
                } else {
                    qtyWithinToleranceInd = ReIMConstants.NO;
                }
                DetailMatchItemsView discrepantItem = new DetailMatchItemsView(
                        invoiceDetailSummaryLevel.getItem().getItemId(), invoiceDetailSummaryLevel
                                .getItem().getItemName(), invoiceDetailSummaryLevel.getItem()
                                .getVpn(), getReviewStatus(invoiceDetailSummaryLevel.getInvoices(),
                                itemKey), matchStatus, receiptUnitCostString, orderUnitCostString,
                        invoiceUnitCostString, costVarianceString, costWithinToleranceInd,
                        totalReceiptQty + "", totalInvoiceQty + "", getVarianceService()
                                .calculateQtyVariance(match)
                                + "", qtyWithinToleranceInd, discrepantInvoiceItems,
                        discrepantReceiptItems, currencyCode);
                discrepantItems.put(itemKey, discrepantItem);
                // remove so we can deal with the remaining receipts later
                discrepantReceipts.remove(itemKey);
            } // end if
            else // if receipt is not found, build discrepant item with just
            // the invoice side
            {
                // The receipt fields are empty since there is no receipt data
                // The variances and within tolerance indicators are empty
                // because they're not applicable
                // except for the cost variance which is based on the order unit
                // cost

                double costVariance = 0;
                String costVarianceString = "";
                String costWithinToleranceInd = "";
                String qtyWithinToleranceInd = "";

                if (!invoiceUnitCostString.equals(ReIMConstants.MULT)
                        && !orderUnitCostString.equals(ReIMConstants.MULT)
                        && !orderUnitCostString.equals("")) {
                    // build fake receipt items with only unit cost of that of
                    // the order so a match can be attempted
                    ReceiptItem[] fakeReceiptItems = buildFakeReceiptItems(discrepantInvoiceItems);
                    Match match = submitForMatch2(discrepantInvoiceItems, fakeReceiptItems, false,
                            dmListForm);
                    costVariance = getVarianceService().calculateCostVariance(match);
                    costVarianceString = costVariance + "";
                    if (match.isCostMatchSuccessful()) {
                        costWithinToleranceInd = ReIMConstants.YES;
                    } else {
                        costWithinToleranceInd = ReIMConstants.NO;
                    }
                    if (match.isQtyMatchSuccessful()) {
                        qtyWithinToleranceInd = ReIMConstants.YES;
                    } else {
                        qtyWithinToleranceInd = ReIMConstants.NO;
                    }
                }
                DetailMatchItemsView discrepantItem = new DetailMatchItemsView(
                        invoiceDetailSummaryLevel.getItem().getItemId(), invoiceDetailSummaryLevel
                                .getItem().getItemName(), invoiceDetailSummaryLevel.getItem()
                                .getVpn(), getReviewStatus(invoiceDetailSummaryLevel.getInvoices(),
                                itemKey), matchStatus, "", orderUnitCostString,
                        invoiceUnitCostString, costVarianceString, costWithinToleranceInd, "",
                        totalInvoiceQty + "", totalInvoiceQty * -1 + "", qtyWithinToleranceInd,
                        discrepantInvoiceItems, new ReceiptItem[0], currencyCode);
                discrepantItems.put(itemKey, discrepantItem);
            }
        } // end for

        return discrepantItems;
    }

    /**
     * Method getReviewStatus. This method determines if cost and/or quantity discrepancies exist
     * for a given item and invoices it belongs to.
     */
    private/* static */String getReviewStatus(MerchandiseDocument[] invoices, String itemId)
            throws ReIMException {
        String reviewStatus = "";
        String tempReviewStatus = "";
        reviewStatus = "";
        for (int j = 0; j < invoices.length; j++) {
            tempReviewStatus = ServiceFactory.getPriceReviewService().getInvoiceReviewStatus(
                    new Long(invoices[j].getDocId()).toString(), itemId);
            if (tempReviewStatus != null) {
                if (tempReviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_BOTH_COST_QTY_ABBR)) {
                    reviewStatus = ReIMConstants.DISCREPANCY_TYPE_BOTH_COST_QTY_ABBR;
                    break;
                } else if (tempReviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)
                        && reviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR)) {
                    reviewStatus = ReIMConstants.DISCREPANCY_TYPE_BOTH_COST_QTY_ABBR;
                    break;
                } else if (tempReviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR)
                        && reviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)) {
                    reviewStatus = ReIMConstants.DISCREPANCY_TYPE_BOTH_COST_QTY_ABBR;
                    break;
                } else if (tempReviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)
                        || tempReviewStatus.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR)) {
                    reviewStatus = tempReviewStatus;
                }
            }
        }

        return reviewStatus;
    }

    private/* static */void deleteDiscrepanciesAndResolutions(DocumentItemInvoice[] invoiceItems)
            throws ReIMException {
        // Delete any discrepancies and discrepancy resolutions that exist

        ImResolutionActionAccessExt resAccessExt = new ImResolutionActionAccessExt();
        resAccessExt.deletePartialResolutions(invoiceItems);
        ImCostDiscrepancyAccessExt accessExt = new ImCostDiscrepancyAccessExt();
        for (int j = 0; j < invoiceItems.length; j++) {
            accessExt.deleteCostDiscrepanciesByDocIdAndItemId(invoiceItems[j].getDocId(),
                    invoiceItems[j].getItem().getItemId());
        }
        long discrepancyId = 0;
        for (int j = 0; j < invoiceItems.length; j++) {
            discrepancyId = ServiceFactory.getDiscrepancyService().getQtyDiscrepancyIdForItemDocId(
                    invoiceItems[j].getItem().getItemId(),
                    new Long(invoiceItems[j].getDocId()).toString());
            if (discrepancyId > 0) {
                ServiceFactory.getDiscrepancyService().deleteQuantityDiscrepancy(discrepancyId);
            }
        }
    }

    private/* static */void persistReceiptInfo(Match match, Match[] matches) throws ReIMException {
        // Persist receipt related fields
        Receipt[] receipts = match.getReceiptGroup().getReceipts();
        
        // BRN SplitReceipt Fix - begin
        DocumentItemInvoice[] invoiceItems =        
        						((InvoiceDetailMatchGroup) match.getInvoiceGroup()).getInvoiceItems();
        // BRN SplitReceipt Fix - end
        
        ReceiptItem[] receiptItems = ((ReceiptDetailSummaryLevel) match.getReceiptGroup())
                .getReceiptItems();

        Receipt[] rcpt = new Receipt[receipts.length];
        for (int j = 0; j < receipts.length; j++) {
            HashMap<Integer, ReceiptItem> rcptItem = new HashMap<Integer, ReceiptItem>();
            rcptItem.put(new Integer(j), receiptItems[j]);
            rcpt[j] = new Receipt(receiptItems[j].getReceiptId());
            rcpt[j].setReceiptItems(rcptItem);
        }

        // create or update the IM_PARTIALLY_MATCHED_RECEIPTS rows
        ImPartiallyMatchedReceiptsAccessExt recAccessExt = new ImPartiallyMatchedReceiptsAccessExt();
        recAccessExt.updateReceiptItemStatus(receiptItems); 
        
        /*
         *  BRN SplitReceipt Fix - start
         * "Detail Match" is enabled only when the split receipt is performed on the item
         * and split receipt is allowed when only one item is selected in receipt and invoice frames.
         *  A record is inserted in im_resolution_action table for split receipt detail match with action='SR'
         *  This is required for the reporting purposes.
         */
        SmrDocumentService smrDocumentService = new SmrDocumentService();                   
        smrDocumentService.persistResolutionForSplitReceipt(receiptItems[0], invoiceItems[0] );
        // BRN SplitReceipt Fix - end
        
        // For each receipt, check if all lines are matched.
        Receipt[] matchedReceipts = getMatchStatusService().checkDbMatchedStatus(receipts);

        ReceiptTrackingService.matchReceipt(match);

        // Update matched receipt statuses
        AShipmentAPI api = (AShipmentAPI) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipmentAPI);
        if (matchedReceipts != null && matchedReceipts.length > 0) {
            api.updateReceiptInvcMatchedStatus(matchedReceipts, Receipt.MATCHED);
        }
        // update qty_matched on the shipsku
        api.updateReceiptInvoiceQtyMatched(rcpt, true);
    }

    private/* static */void checkRequiredLocks(Match match, String userId) throws ReIMException {
        MerchandiseDocument[] invoices = match.getInvoiceGroup().getInvoices();

        for (int j = 0; j < invoices.length; j++) {
            String extDocId = invoices[j].getExtDocId();
            checkLock(LockingData.DOC_HEAD_LOCK_TABLE, invoices[j].getDocId(), extDocId, userId,
                    "error.detail_match_service.invoice_locked",
                    "error.detail_match_service.invoice_not_locked");
        }

        Receipt[] receipts = match.getReceiptGroup().getReceipts();

        for (int j = 0; j < receipts.length; j++) {
            String receiptId = receipts[j].getReceiptId();
            checkLock(LockingData.RECEIPT_LOCK_TABLE, new Long(receipts[j].getReceiptId())
                    .longValue(), receiptId, userId, "error.detail_match_service.receipt_locked",
                    "error.detail_match_service.receipt_not_locked");
        }
    }

    private/* static */void checkLock(LockingData tableName, long recordId, String objectId,
            String userId, String lockedKey, String notLockedKey) throws ReIMException {
        String lockingUser = ServiceFactory.getTableRecordLockingService()
                .getUserIdLockingRecordOnTable(tableName, recordId);

        if (lockingUser == null) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(notLockedKey, Severity.DEBUG, DetailMatchService.class,
                    new String[] { objectId});
        }

        if (!lockingUser.equals(userId)) {
            // TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(lockedKey, Severity.DEBUG, DetailMatchService.class,
                    new String[] { objectId, lockingUser});
        }
    }

    /**
     * Method submitForMatch. This method takes in a list of invoice items and a list of receipt
     * items. It calls submitForMatch2 with a allowMult flag of false.
     */
    public Match submitForMatch(DocumentItemInvoice[] invoiceItems, ReceiptItem[] receiptItems,
            DetailMatchListForm dmListForm) throws ReIMException {
        try {
            return submitForMatch2(invoiceItems, receiptItems, false, dmListForm);
        } catch (ReIMException e) {
            throw (e);
        }
    }

    /**
     * Method submitForMatch2. This method takes in a list of invoice items and a list of receipt
     * items. It builds a match object out of those and submits that for a match. A allowMult flag
     * of true means this methos is being called for discrepant items which could have multiple unit
     * costs. This is not allowed under other attempts for match. In the case where allowMult is
     * true, this method is being called just for to attempt to match the quantity only.
     */
    private/* static */Match submitForMatch2(DocumentItemInvoice[] invoiceItems,
            ReceiptItem[] receiptItems, boolean allowMult, DetailMatchListForm dmListForm)
            throws ReIMException {
        final String costMatched = "C";
        final String qtyMatched = "Q";
        final String notMatched = ReIMConstants.NO;
        try {
            // TransactionManagerFactory.getInstance().start();
            if (invoiceItems.length == 0 || receiptItems.length == 0) return null;
            double invoiceUnitCost = invoiceItems[0].getResolutionAdjustedUnitCost();
            String matchStatus = "";
            // check if all invoice lines are cost matched, qty matched, have
            // the same unit cost

            for (int i = 0; i < invoiceItems.length; i++) {
            	matchStatus = "";
                if (invoiceItems[i].isCostMatched()) {
                    if (matchStatus.equals(ReIMConstants.EMPTY_STRING)
                            || matchStatus.equals(costMatched))
                        matchStatus = costMatched;
                    else // mixed match statuses
                    if (allowMult)
                        matchStatus = notMatched;
                    else
                        throw new ReIMException(
                                "error.detail_match_service.mixed_match_status_error",
                                Severity.DEBUG, DetailMatchService.class);
                }
                if (invoiceItems[i].isQtyMatched()) {
                    if (matchStatus.equals(ReIMConstants.EMPTY_STRING)
                            || matchStatus.equals(qtyMatched))
                        matchStatus = qtyMatched;
                    else // mixed match statuses
                    if (allowMult)
                        matchStatus = notMatched;
                    else
                        throw new ReIMException(
                                "error.detail_match_service.mixed_match_status_error",
                                Severity.DEBUG, DetailMatchService.class);
                }

                if (!invoiceItems[i].isCostMatched() && !invoiceItems[i].isQtyMatched()) {
                    if (matchStatus.equals(ReIMConstants.EMPTY_STRING)
                            || matchStatus.equals(notMatched))
                        matchStatus = notMatched;
                    else // mixed match statuses
                    if (allowMult)
                        matchStatus = notMatched;
                    else
                        throw new ReIMException(
                                "error.detail_match_service.mixed_match_status_error",
                                Severity.DEBUG, DetailMatchService.class);
                }

                if (!allowMult) {
                    if (invoiceUnitCost != invoiceItems[i].getResolutionAdjustedUnitCost()) { throw new ReIMException(
                            "error.detail_match_service.unit_costs_not_equal", Severity.DEBUG,
                            DetailMatchService.class); }
                }
            }

            if (!allowMult) {
                double receiptUnitCost = receiptItems[0].getUnitCost();
                for (int i = 0; i < receiptItems.length; i++) {
                    if (receiptUnitCost != receiptItems[i].getUnitCost()) { throw new ReIMException(
                            "error.detail_match_service.unit_costs_not_equal", Severity.DEBUG,
                            DetailMatchService.class); }
                }
            }
            // Build match object and attempt a match to determine total qty and
            // tolerances
            Match match = new Match();
            match.setSummaryOrLineMatch(Tolerance.LINE_LEVEL);
            match.setQtyMatchRequired(true);

            if (matchStatus.equals(costMatched))
                match.setCostMatchSuccessful(true);
            else
                match.setCostMatchSuccessful(false);

            if (matchStatus.equals(qtyMatched))
                match.setQtyMatchSuccessful(true);
            else
                match.setQtyMatchSuccessful(false);

            InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = new InvoiceDetailSummaryLevel(
                    invoiceItems);
            ReceiptDetailSummaryLevel receiptDetailSummaryLevel = new ReceiptDetailSummaryLevel(
                    receiptItems);
            match.setInvoiceCurrency(invoiceDetailSummaryLevel.getInvoiceItems()[0].getCurrencyCode());
            match.setInvoiceGroup(invoiceDetailSummaryLevel);
            match.setReceiptGroup(receiptDetailSummaryLevel);
            match.setSupplier((Supplier) (invoiceDetailSummaryLevel).getInvoiceItems()[0].getDocument().getVendor());

            match.setTaxMatchRequired(false);

            if (dmListForm != null) {
                getMatchService().match(match, dmListForm.getTolContainer());
            } else {
                getMatchService().match(match);
            }
            return match;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_submit_for_match",
                    Severity.ERROR, e, DetailMatchService.class);
        } /*
           * finally { TransactionManagerFactory.getInstance().end(); }
           */
    }

    /**
     * Method buildFakeReceiptItems. This method takes in a list of invoice items and builds and a
     * list of fake receipt items out of them with only a unit cost being equal to the order unit
     * cost. This is done so a match within tolerance could be attempted.
     * 
     * @param DocumentItem
     *            [] - Invoice items
     * @return ReceiptItem[]
     * @throws ReIMException
     */
    private/* static */ReceiptItem[] buildFakeReceiptItems(
            DocumentItemInvoice[] discrepantInvoiceItems) throws ReIMException {
        try {
            ReceiptItem[] fakeReceiptItems = new ReceiptItem[discrepantInvoiceItems.length];
            // verify the receipt items unit cost is the same as that of the
            // order item unit cost
            for (int i = 0; i < discrepantInvoiceItems.length; i++) {
                fakeReceiptItems[i] = new ReceiptItem();
                fakeReceiptItems[i].setUnitCost(discrepantInvoiceItems[i].getOrderUnitCost());
                fakeReceiptItems[i].setAvailableToMatchQty(0);
                fakeReceiptItems[i].setQtyReceived(0);
            }
            return fakeReceiptItems;
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_build_fake_receipt_items",
                    Severity.ERROR, e, DetailMatchService.class);
        }
    }

    /**
     * Method buildReceiptDetailSummaryLevels. This Method gets all receipts lines from
     * ReceiptsSummaryGroupLevel of unmatched group and builds a HashMap of
     * ReceiptDetailSummaryLevels consolidating by item/unit cost.
     */
    private Map buildReceiptDetailSummaryLevels(Map unmatchedReceiptMap) throws ReIMException {
        Collection receipts = unmatchedReceiptMap.values();
        Iterator iterator1 = receipts.iterator();
        int arraySize = 0;
        Map receiptDetailSummaryLevels = new HashMap();
        for (int i = 0; i < receipts.size(); i++) {
            Receipt receipt = (Receipt) iterator1.next();

            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            Map<String, String> itemVpnMap = null;
            if (systemOptions.isVpnItemLookup()) {
                itemVpnMap = ServiceFactory.getItemSupplierService().getItemsVpnMapForReceipt(
                        receipt);
            }
            if (receipt.getInvoiceMatchStatus().equals(Receipt.UNMATCHED)) {
                Map receiptItems = receipt.getReceiptItems();
                String hashMapKey = "";
                //BRN 1.5 Begin - added
                if (receiptItems != null && !receiptItems.isEmpty()){
                	
                    Collection itemList = receiptItems.values();                    
                    Iterator iterator = itemList.iterator();
                    
	                    for (int j = 0; j < itemList.size(); j++) {
	                        ReceiptItem receiptItem = (ReceiptItem) iterator.next();
	                        
	                        //BRN 1.5 Begin - removed
	                        //BRN 1.6 Begin - added if condition back.
	                        if (receiptItem.getAvailableToMatchQty() != 0) {
	                        	
	                            receiptItem.getItem().setItemName(
	                                    ServiceFactory.getItemService().getItemDesc(
	                                            receiptItem.getItem().getItemId()));
	
	                            String itemVpn = null;
	                            if (systemOptions.isVpnItemLookup()) {
	                                itemVpn = itemVpnMap.get(receiptItem.getItem().getItemId());
	                            }
	                            receiptItem.getItem().setVpn(itemVpn);
	                            hashMapKey = receiptItem.getItem().getItemId() + receiptItem.getUnitCost();
	                            // For each receipt item, check it an entry was created
	                            // on receiptDetailSummaryLevels.
	                            // If so, add the receipt line to the existing array of
	                            // receipt lines.
	                            // Otherwise create a new entry with a single receipt
	                            // line in the array.
	                            if (receiptDetailSummaryLevels.containsKey(hashMapKey)) {
	                                ReceiptDetailSummaryLevel receiptDetailSummaryLevel = (ReceiptDetailSummaryLevel) receiptDetailSummaryLevels
	                                        .get(hashMapKey);
	                                arraySize = receiptDetailSummaryLevel.getReceiptItems().length;
	                                ReceiptItem[] newReceiptItemList = new ReceiptItem[arraySize + 1];
	                                ReceiptItem[] previousReceiptItems = receiptDetailSummaryLevel
	                                        .getReceiptItems();
	                                for (int k = 0; k < previousReceiptItems.length; k++) {
	                                    newReceiptItemList[k] = previousReceiptItems[k];
	                                }
	                                newReceiptItemList[arraySize] = receiptItem;
	                                receiptDetailSummaryLevel.setReceiptItems(newReceiptItemList);
	                            } else {
	                                ReceiptItem[] receiptItemList = { receiptItem};
	                                ReceiptDetailSummaryLevel receiptDetailSummaryLevel = new ReceiptDetailSummaryLevel(
	                                        receiptItemList);
	                                receiptDetailSummaryLevels.put(hashMapKey, receiptDetailSummaryLevel);
	                            }
	                        //BRN 1.5 End - removed
	                        //BRN 1.6 Begin - added if condition back.    
	                        } // if qty>0
	                    //BRN 1.5 End - added
	                    } // if (receiptItems != null)
   
                } // for receipt items
            } // if receipt unmatched
        } // for receipts

        return receiptDetailSummaryLevels;
    }

    /**
     * Method buildReceiptDetailSummaryLevels. This Method gets all receipt lines from the
     * discrepantItemList and an array of receiptItems and builds a HashMap of
     * ReceiptDetailSummaryLevels consolidating by item/unit cost.
     * @throws ReIMException 
     */
    private/* static */Map buildReceiptDetailSummaryLevels(
            DetailMatchItemsView[] discrepantItemList, ReceiptItem[] receiptItems) throws ReIMException {
        // combine receipt items from both input lists
        List combinedReceiptItems = new ArrayList();
        
        if (discrepantItemList != null) {
            for (int i = 0; i < discrepantItemList.length; i++) {
                for (int j = 0; j < discrepantItemList[i].getReceiptItems().length; j++) {
                    combinedReceiptItems.add(discrepantItemList[i].getReceiptItems()[j]);
                }
            }
        }
        
        if (receiptItems != null) {
            for (int i = 0; i < receiptItems.length; i++) {
                combinedReceiptItems.add(receiptItems[i]);
            }
        }
        // Create the receiptDetailSummaryLevels from combined list of receipt
        // items
        Map receiptDetailSummaryLevels = new HashMap();
        int arraySize = 0;
        String hashMapKey = "";
        Iterator iterator = combinedReceiptItems.iterator();
        for (int i = 0; i < combinedReceiptItems.size(); i++) {
            ReceiptItem receiptItem = (ReceiptItem) iterator.next();                        
            //BRN 1.6 Begin - added NULL check
            ReceiptItem receiptItemTemp =  ReceiptService.buildReceiptItem(receiptItem.getReceipt(), receiptItem.getItemId());
            if (receiptItemTemp != null)
            	receiptItem.setPartiallyMatched(receiptItemTemp.isPartiallyMatched());
            else
            	receiptItem.setPartiallyMatched(false);
            //BRN 1.6 End
            
           // BRN V1.5 Begin - removed
           //BRN 1.6 Begin - added if condition back. 
           if (receiptItem.getAvailableToMatchQty() > 0) {
            	
            	// BRN V1.4 Begin
            	receiptItem.getItem().setItemName(
                        ServiceFactory.getItemService().getItemDesc(
                                receiptItem.getItem().getItemId()));
            	// BRN V1.4 End
                hashMapKey = receiptItem.getItem().getItemId() + receiptItem.getUnitCost();
                // For each receipt item, check it an entry was created on
                // receiptDetailSummaryLevels.
                // If so, check if the item belongs to the same receipt, if so,
                // add the quantities,
                // else, add the receipt line to the existing array of receipt
                // lines.
                // If there is no entry on receiptDetailSummaryLevels, create a
                // new entry with a single
                // receipt line in the array.
                if (receiptDetailSummaryLevels.containsKey(hashMapKey)) {
                    ReceiptDetailSummaryLevel receiptDetailSummaryLevel = (ReceiptDetailSummaryLevel) receiptDetailSummaryLevels
                            .get(hashMapKey);
                    arraySize = receiptDetailSummaryLevel.getReceiptItems().length;
                    ReceiptItem[] newReceiptItems = new ReceiptItem[arraySize + 1];
                    ReceiptItem[] previousReceiptItems = receiptDetailSummaryLevel
                            .getReceiptItems();
                    boolean isReceiptFound = false;
                    for (int k = 0; k < previousReceiptItems.length; k++) {
                        if (receiptItem.getReceipt().getReceiptId().equals(
                                previousReceiptItems[k].getReceipt().getReceiptId())) {
                            isReceiptFound = true;
                            previousReceiptItems[k].setCostMatched(ReceiptService.isCostMatched(
                                    previousReceiptItems[k].getItemId(), previousReceiptItems[k]
                                            .getReceiptId()));
                            previousReceiptItems[k].setAvailableToMatchQty(previousReceiptItems[k]
                                    .getAvailableToMatchQty()
                                    + receiptItem.getAvailableToMatchQty());
                            break;
                        } else {
                            newReceiptItems[k] = previousReceiptItems[k];
                        }
                    }
                    if (isReceiptFound) {
                        receiptDetailSummaryLevel.setReceiptItems(previousReceiptItems);
                    } else {
                        newReceiptItems[arraySize] = receiptItem;
                        receiptDetailSummaryLevel.setReceiptItems(newReceiptItems);
                    }
                } else {
                    ReceiptItem[] receiptItemList = { receiptItem};
                    ReceiptDetailSummaryLevel receiptDetailSummaryLevel = new ReceiptDetailSummaryLevel(
                            receiptItemList);
                    receiptDetailSummaryLevels.put(hashMapKey, receiptDetailSummaryLevel);
                }
            // BRN V1.5 End - removed
            //BRN 1.6 Begin - added if condition back.    
            } // if qty>0
                
        } // for receipt items

        return receiptDetailSummaryLevels;
    }

    /**
     * Method buildDiscrepantReceipts. This method takes receiptDetailSummaryLevels and consolidates
     * by item regardless of unit cost.
     */
    private/* static */Map buildDiscrepantReceipts(List remainingReceiptDetailSummaryLevels) {
        String itemKey = "";
        Map discrepantReceipts = new HashMap();
        Iterator iterator = remainingReceiptDetailSummaryLevels.iterator();
        ReceiptDetailSummaryLevel remainingReceipt;
        itemKey = "";
        for (int i = 0; i < remainingReceiptDetailSummaryLevels.size(); i++) {
            remainingReceipt = (ReceiptDetailSummaryLevel) iterator.next();
            itemKey = remainingReceipt.getItemId();
            if (discrepantReceipts.containsKey(itemKey)) {
                ArrayList tempList = new ArrayList();
                ReceiptItem[] previousReceiptItems = ((ReceiptDetailSummaryLevel) (discrepantReceipts
                        .get(itemKey))).getReceiptItems();
                ReceiptItem[] newReceiptItems = remainingReceipt.getReceiptItems();
                for (int k = 0; k < previousReceiptItems.length; k++) {
                    tempList.add(previousReceiptItems[k]);
                }
                for (int k = 0; k < newReceiptItems.length; k++) {
                    tempList.add(newReceiptItems[k]);
                }
                ((ReceiptDetailSummaryLevel) (discrepantReceipts.get(itemKey)))
                        .setReceiptItems((ReceiptItem[]) tempList.toArray(new ReceiptItem[tempList
                                .size()]));
            } else {
                discrepantReceipts.put(itemKey, remainingReceipt);
            }
        }
        return discrepantReceipts;
    }

    /**
     * Method buildDiscrepantInvoices. This method takes in a map of invoiceDetailSummaryLevels and
     * consolidates by item regardless of unit cost.
     */
    private/* static */Map buildDiscrepantInvoices(List remainingInvoiceDetailSummaryLevels)
            throws ReIMException {
        Map discrepantInvoices = new HashMap();
        Iterator iterator = remainingInvoiceDetailSummaryLevels.iterator();
        InvoiceDetailSummaryLevel remainingInvoice;
        String itemKey = "";
        for (int i = 0; i < remainingInvoiceDetailSummaryLevels.size(); i++) {
            remainingInvoice = (InvoiceDetailSummaryLevel) iterator.next();
            itemKey = remainingInvoice.getItem() != null ? remainingInvoice.getItem().getItemId()
                    : "";
            if (discrepantInvoices.containsKey(itemKey)) {
                ArrayList tempList = new ArrayList();
                DocumentItemInvoice[] previousInvoiceItems = ((InvoiceDetailSummaryLevel) (discrepantInvoices
                        .get(itemKey))).getInvoiceItems();
                DocumentItemInvoice[] newInvoiceItems = remainingInvoice.getInvoiceItems();
                for (int k = 0; k < previousInvoiceItems.length; k++) {
                    tempList.add(previousInvoiceItems[k]);
                }
                for (int k = 0; k < newInvoiceItems.length; k++) {
                    tempList.add(newInvoiceItems[k]);
                }
                ((InvoiceDetailSummaryLevel) (discrepantInvoices.get(itemKey)))
                        .setInvoiceItems((DocumentItemInvoice[]) tempList
                                .toArray(new DocumentItemInvoice[tempList.size()]));
            } // end if
            else {
                discrepantInvoices.put(itemKey, remainingInvoice);
            }
        } // end for
        return discrepantInvoices;
    }

    /**
     * Method buildInvoiceDetailSummaryLevels. This Method gets all invoice lines from
     * InvoiceSummaryGroupLevel of unmatched group and builds a HashMap of
     * InvoiceDetailSummaryLevels consolidating by item/unit cost.
     */
    private Map buildInvoiceDetailSummaryLevels(Map unmatchedInvoiceMap) throws ReIMException {
        Collection invoices = unmatchedInvoiceMap.values();
        Iterator iterator1 = invoices.iterator();
        Map invoiceDetailSummaryLevels = new HashMap();
        int arraySize = 0;
        for (int i = 0; i < invoices.size(); i++) {
            MerchandiseDocument invoice = (MerchandiseDocument) iterator1.next();
            Map invoiceItems = invoice.getDocDetail();
            String hashMapKey = "";
            Collection itemList = invoiceItems.values();
            Iterator iterator2 = itemList.iterator();
            for (int j = 0; j < itemList.size(); j++) {
                DocumentItemInvoice invoiceItem = (DocumentItemInvoice) iterator2.next();
                if (invoiceItem.getStatus().equals(DocumentItemInvoice.UNMATCHED)) {
                    invoiceItem.getItem().setItemName(
                            ServiceFactory.getItemService().getItemDesc(
                                    invoiceItem.getItem().getItemId()));
                    invoiceItem.getDocument().setOrderNo(invoice.getOrderNo());
                    invoiceItem.getDocument().setLocation(invoice.getLocation());
                    setOrderItemUnitCost(invoiceItem);
                    hashMapKey = invoiceItem.getItem().getItemId()
                            + invoiceItem.getResolutionAdjustedUnitCost();
                    // For each invoice item, check it an entry was created on
                    // invoiceDetailSummaryLevels.
                    // If so, add the invoice line to the existing array of
                    // invoice lines.
                    // Otherwise create a new entry with a single invoice line
                    // in the array.
                    if (invoiceDetailSummaryLevels.containsKey(hashMapKey)) {
                        InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = (InvoiceDetailSummaryLevel) invoiceDetailSummaryLevels
                                .get(hashMapKey);
                        arraySize = invoiceDetailSummaryLevel.getInvoiceItems().length;
                        DocumentItemInvoice[] newInvoiceItemList = new DocumentItemInvoice[arraySize + 1];
                        DocumentItemInvoice[] previousInvoiceItems = invoiceDetailSummaryLevel
                                .getInvoiceItems();
                        for (int k = 0; k < previousInvoiceItems.length; k++) {
                            newInvoiceItemList[k] = previousInvoiceItems[k];
                        }
                        newInvoiceItemList[arraySize] = invoiceItem;
                        invoiceDetailSummaryLevel.setInvoiceItems(newInvoiceItemList);
                    } else {
                        DocumentItemInvoice[] invoiceItemList = { invoiceItem};
                        InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = new InvoiceDetailSummaryLevel(
                                invoiceItemList);
                        invoiceDetailSummaryLevels.put(hashMapKey, invoiceDetailSummaryLevel);
                    }
                } // end if unmatched
            } // end for invoice items
        } // end for invoices in group

        return invoiceDetailSummaryLevels;
    }

    /**
     * Method buildInvoiceDetailSummaryLevels. This Method gets all invoice lines from the
     * discrepantItemList and an array of invoiceItems and builds a HashMap of
     * InvoiceDetailSummaryLevels consolidating by item/unit cost.
     */
    private/* static */Map buildInvoiceDetailSummaryLevels(
            DetailMatchItemsView[] discrepantItemList, DocumentItemInvoice[] invoiceItems) {
        // combine invoice items from both input lists
        List combinedInvoiceItems = new ArrayList();
        if (discrepantItemList != null) {
            for (int i = 0; i < discrepantItemList.length; i++) {
                for (int j = 0; j < discrepantItemList[i].getInvoiceItems().length; j++) {
                    combinedInvoiceItems.add(discrepantItemList[i].getInvoiceItems()[j]);
                }
            }
        }
        if (invoiceItems != null) {
            for (int i = 0; i < invoiceItems.length; i++) {
                combinedInvoiceItems.add(invoiceItems[i]);
            }
        }
        // Create the invoiceDetailSummaryLevels from combined list of invoice
        // items
        Map invoiceDetailSummaryLevels = new HashMap();
        int arraySize = 0;
        String hashMapKey = "";
        Iterator iterator = combinedInvoiceItems.iterator();
        for (int i = 0; i < combinedInvoiceItems.size(); i++) {
            DocumentItemInvoice invoiceItem = (DocumentItemInvoice) iterator.next();
            if (invoiceItem.getStatus().equals(DocumentItemInvoice.UNMATCHED)) {
                hashMapKey = invoiceItem.getItem().getItemId()
                        + invoiceItem.getResolutionAdjustedUnitCost();
                // For each invoice item, check it an entry was created on
                // invoiceDetailSummaryLevels.
                // If so, add the invoice line to the existing array of invoice
                // lines.
                // Otherwise create a new entry with a single invoice line in
                // the array.
                if (invoiceDetailSummaryLevels.containsKey(hashMapKey)) {
                    InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = (InvoiceDetailSummaryLevel) invoiceDetailSummaryLevels
                            .get(hashMapKey);
                    arraySize = invoiceDetailSummaryLevel.getInvoiceItems().length;
                    DocumentItemInvoice[] newInvoiceItemList = new DocumentItemInvoice[arraySize + 1];
                    DocumentItemInvoice[] previousInvoiceItems = invoiceDetailSummaryLevel
                            .getInvoiceItems();
                    for (int k = 0; k < previousInvoiceItems.length; k++) {
                        newInvoiceItemList[k] = previousInvoiceItems[k];
                    }
                    newInvoiceItemList[arraySize] = invoiceItem;
                    invoiceDetailSummaryLevel.setInvoiceItems(newInvoiceItemList);
                } else {
                    DocumentItemInvoice[] invoiceItemList = { invoiceItem};
                    InvoiceDetailSummaryLevel invoiceDetailSummaryLevel = new InvoiceDetailSummaryLevel(
                            invoiceItemList);
                    invoiceDetailSummaryLevels.put(hashMapKey, invoiceDetailSummaryLevel);
                }
            } // end if unmatched
        } // end for invoice items
        return invoiceDetailSummaryLevels;
    }

    /**
     * Method checkUnitCostForCostResolution. This method takes in a list of invoice items and a
     * list of receipt items. It verifies that the unit cost on the corresponding order item is the
     * same as the unit cost on the receipt items.
     * 
     * @param DetailMatchInvoiceView
     *            []
     * @param DetailMatchReceiptView
     *            []
     * @return boolean
     * @throws ReIMException
     */
    public boolean checkUnitCostForCostResolution(DetailMatchInvoiceView[] invoiceItemGroupList,
            DetailMatchReceiptView[] receiptItemGroupList) throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            String orderNo = invoiceItemGroupList[0].getDocumentItem().getDocument().getOrderNo();
            Location location = new Location(invoiceItemGroupList[0].getDocumentItem()
                    .getDocument().getLocation().getLocationId(), "", "");
            String itemId = invoiceItemGroupList[0].getDocumentItem().getItem().getItemId();
            AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AOrderLocationBean);
            POItemLocation poItemLocation = orderLocationBean.getPOItemLocation(orderNo, location,
                    itemId);
            double orderItemUnitCost = 0;
            try // in case the item is not on the order
            {
                orderItemUnitCost = poItemLocation.getUnitCost();
            } catch (NullPointerException ne) {
                return true;
            }

            // verify the receipt items unit cost is the same as that of the
            // order item unit cost
            for (int i = 0; i < receiptItemGroupList.length; i++) {
                if (orderItemUnitCost != receiptItemGroupList[i].getReceiptItem().getUnitCost())
                    return false;
            }
            return true;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_check_unit_cost",
                    Severity.ERROR, e, DetailMatchService.class);
        } /*
           * finally { TransactionManagerFactory.getInstance().end(); }
           */
    }

    /**
     * Method setOrderItemUnitCost. This method takes in a invoice items and sets the order item
     * unit cost.
     * 
     * @param DocumentItem
     *            - invoice item
     * @throws ReIMException
     */
    private/* static */void setOrderItemUnitCost(DocumentItemInvoice invoiceItem)
            throws ReIMException {
        try {
            // TransactionManagerFactory.getInstance().start();
            String orderNo = invoiceItem.getDocument().getOrderNo();
            Location location = new Location(invoiceItem.getDocument().getLocation()
                    .getLocationId(), "", "");
            String itemId = invoiceItem.getItem().getItemId();
            AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AOrderLocationBean);
            POItemLocation poItemLocation = orderLocationBean.getPOItemLocation(orderNo, location,
                    itemId);
            try // in case the item is not on the order
            {
                invoiceItem.setOrderUnitCost(poItemLocation.getUnitCost());
            } catch (NullPointerException ne) {
                invoiceItem.setOrderUnitCost(0);
            }
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.detail_match_service.failed_set_order_item_unit_cost",
                    Severity.ERROR, e, DetailMatchService.class);
        }/*
          * finally { TransactionManagerFactory.getInstance().end(); }
          */
    }

    private boolean multiplePosExist(Collection invoices, Collection receipts) {
        Set existingPos = new HashSet();
        if (multipleInvoicePosExist(invoices, existingPos)) { return true; }
        if (multipleReceiptPosExist(receipts, existingPos)) { return true; }
        return false;
    }

    private boolean multipleInvoicePosExist(Collection invoices, Set existingPos) {
        for (Iterator iter = invoices.iterator(); iter.hasNext();) {
            MerchandiseDocument invoice = (MerchandiseDocument) iter.next();
            existingPos.add(invoice.getOrderNo());
        }
        return existingPos.size() > 1;
    }

    private boolean multipleReceiptPosExist(Collection receipts, Set existingPos) {
        for (Iterator iter = receipts.iterator(); iter.hasNext();) {
            Receipt receipt = (Receipt) iter.next();
            existingPos.add(receipt.getOrderId());
        }
        return existingPos.size() > 1;
    }

    private IMatchStatusService getMatchStatusService() {
        return matchStatusService;
    }

    @Autowired
    public void setMatchStatusService(IMatchStatusService matchStatusService) {
        this.matchStatusService = matchStatusService;
    }

    private IVarianceService getVarianceService() {
        return varianceService;
    }

    @Autowired
    public void setVarianceService(IVarianceService varianceService) {
        this.varianceService = varianceService;
    }

    public IMatchService getMatchService() {
        return matchService;
    }

    @Autowired
    public void setMatchService(IMatchService matchService) {
        this.matchService = matchService;
    }
}
