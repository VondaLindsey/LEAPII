package oracle.retail.reim.data.dao.impl;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.retail.reim.business.Account;
import oracle.retail.reim.business.AccountSegment;
import oracle.retail.reim.business.AccountStatus;
import oracle.retail.reim.business.AccountType;
import oracle.retail.reim.business.DynamicSegmentBusinessAttribute;
import oracle.retail.reim.business.PostingDocumentAccount;
import oracle.retail.reim.business.PostingStatus;
import oracle.retail.reim.business.PostingTranCode;
import oracle.retail.reim.business.SetOfBooks;
import oracle.retail.reim.business.TaxAccount;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.dao.IFinancialPostingAccountDao;
import oracle.retail.reim.data.dao.impl.AccountDao.AccountSegmentsRowMapper;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.DatasourceProperties;
import oracle.retail.reim.utils.DynamicSegmentUtils;
import oracle.retail.reim.utils.SqlCriteriaBuilder;
import oracle.retail.reim.utils.StoredProcedureUtils;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Repository;

import com.retek.reim.business.ReIMSystemPropertiesUtil;

/**
 * Account related operations like select, insert, update for Account segments are done.
 * 
 * @author Vasanth Prabu
 * 
 */
@Repository
public class FinancialPostingAccountDao extends SimpleJdbcDaoSupport implements IFinancialPostingAccountDao {

    public static String NO_VALUE = "NO_VALUE";
    static final String SELECT_POSTING_ACCOUNT = "SELECT SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,SEGMENT5,SEGMENT6,SEGMENT7,SEGMENT8,SEGMENT9,SEGMENT10,SEGMENT11,SEGMENT12,SEGMENT13,SEGMENT14,SEGMENT15,SEGMENT16,SEGMENT17,SEGMENT18,SEGMENT19,SEGMENT20 from IM_POSTING_DOC_ACCOUNTS IPDACC WHERE IPDACC.POSTING_AMT_ID =? AND IPDACC.ACCOUNT_TYPE = ? AND IPDACC.ACCOUNT_CODE = ? AND STATUS=?";
    //   private static final String DELETE_SUCCESSFUL_IM_POSTING_DOC_ACCOUNTS = "DELETE FROM IM_POSTING_DOC_ACCOUNTS IPDA \n"
    //       + " WHERE       POSTING_AMT_ID NOT IN (SELECT POSTING_AMT_ID \n"
    //       + "                         FROM   IM_POSTING_DOC_ERRORS IPDE, IM_POSTING_DOC_AMOUNTS IPDAMT  \n"
    //       + "                         WHERE  IPDE.POSTING_ID = IPDAMT.POSTING_ID \n";


     private static final String DELETE_SUCCESSFUL_IM_POSTING_DOC_ACCOUNTS = "DELETE /*+ all_rows  */ FROM IM_POSTING_DOC_ACCOUNTS IPDA \n"
         + " WHERE  NOT EXISTS (SELECT /*+ use_nl (ipde, ipdamt) NL_AJ */ 1 \n"
         + "                         FROM   IM_POSTING_DOC_ERRORS IPDE, IM_POSTING_DOC_AMOUNTS IPDAMT  \n"
         + "                         WHERE  IPDE.POSTING_ID = IPDAMT.POSTING_ID AND ipda.posting_amt_id = ipdamt.posting_amt_id \n";


//    private static final String DELETE_SUCCESSFUL_IM_POSTING_DOC_ACCOUNTS = " delete FROM IM_POSTING_DOC_ACCOUNTS IPDA \n" + 
//    "         WHERE       POSTING_AMT_ID IN ( SELECT posting_amt_id\n" + 
//    "                                           FROM im_posting_doc_amounts\n" + 
//    "                                           WHERE posting_id = ? \n" + 
//    "                                            AND  doc_id = ? \n" + 
//    "                                          MINUS\n" + 
//    "                                          SELECT /*+ use_ nl (ipde, ipdamt)  */ POSTING_AMT_ID\n" + 
//    "                                          FROM IM_POSTING_DOC_ERRORS IPDE, IM_POSTING_DOC_AMOUNTS IPDAMT  \n" + 
//    "                                         WHERE IPDE.POSTING_ID = IPDAMT.POSTING_ID\n" + 
//    "                                           AND   IPDAMT.POSTING_ID = ?  \n" + 
//    "                                           AND  IPDAMT.doc_id = ? ) "; 
    

        private static final String DELETE_SUCCESSFUL_IM_POSTING_DOC_ACCOUNTS2 = " delete FROM IM_POSTING_DOC_ACCOUNTS IPDA \n" + 
        "         WHERE       POSTING_AMT_ID IN ( SELECT posting_amt_id\n" + 
        "                                           FROM im_posting_doc_amounts\n" + 
        "                                          MINUS\n" + 
        "                                          SELECT /*+ use_ nl (ipde, ipdamt)  */ POSTING_AMT_ID\n" + 
        "                                          FROM IM_POSTING_DOC_ERRORS IPDE, IM_POSTING_DOC_AMOUNTS IPDAMT  \n" + 
        "                                         WHERE IPDE.POSTING_ID = IPDAMT.POSTING_ID\n" ; 

    private static final String SUPPORTING_STORED_PROCEDURE_PACKAGE = "REIM_POSTING_ACCOUNT_SQL";

	/**
     * Retrieves the acct from im_posting_doc_Accounts.
     */
    public Account getAccount(AccountType accountType, String accountCode,SetOfBooks setOfBooks, Long postingAmtId) {
        Account newAcct = new Account();
        newAcct.setType(accountType);
        newAcct.setCode(accountCode);
        newAcct.setPostingTranCode(PostingTranCode.getVal(accountType, accountCode));
        newAcct.setSetOfBooks(setOfBooks);
        
        List<List<AccountSegment>> accountSegments = getSimpleJdbcTemplate().query(SELECT_POSTING_ACCOUNT,
                new AccountSegmentsRowMapper(),
                new Object[] { postingAmtId,
        		accountType.getCode(), accountCode, 
        		AccountStatus.VALID.getCode()
        		});        
        newAcct.setSegments(accountSegments != null && accountSegments.size() > 0 ? accountSegments.get(0) : null);
        return newAcct;
    }
    


    /**
     * Stored procedure that will load the Accounts subjected to posting.
     * 
     * @author Oracle Retail
     * @author Tony Cheng
     */
    public class CallLoadAccounts extends StoredProcedure {
        private final String OBJ_DYNAMIC_BUSINESS_MAPPING = DatasourceProperties.schemaOwner
                + ".OBJ_REIM_DYN_BUSINESS_MAP_TBL";
        private final String OBJ_DYNAMIC_BUSINESS_MAPPING_REC = DatasourceProperties.schemaOwner
                + ".OBJ_REIM_DYN_BUSINESS_MAP_REC";
         
        private static final String I_FORCE_DYNAMIC = "forceDynamic";
        private static final String I_DYNAMIC_SEGMENT_ATTRIBUTES = "dynamicSegmentAttributes";
        static final String FUNCTION_NAME = SUPPORTING_STORED_PROCEDURE_PACKAGE
        									+ ".LOAD_POSTING_ACCOUNTS";
        public static final String IN_POSTING_ID = "postingId";

        Map<String, Object> input = new HashMap<String, Object>();

        public CallLoadAccounts(DataSource ds, 
                Map<Integer, DynamicSegmentBusinessAttribute> dynamicSegmentBusinessAttribs,
                boolean forceDynamic,  Long postingId) {
            super(ds,FUNCTION_NAME);
            try {

                // Validate parameters...
                {
                    if (dynamicSegmentBusinessAttribs == null
                            || dynamicSegmentBusinessAttribs.isEmpty()) { throw new IllegalArgumentException(
                            getClass() + " requires Map<Integer, DynamicSegmentBusinessAttribute>"); }
                }
                
                setFunction(true);

                StoredProcedureUtils.registerOutputStatusParameters(this);

                declareParameter(new SqlParameter(IN_POSTING_ID, Types.NUMERIC));
                input.put(IN_POSTING_ID, postingId);

                declareParameter(new SqlParameter(I_DYNAMIC_SEGMENT_ATTRIBUTES, Types.ARRAY,
                        OBJ_DYNAMIC_BUSINESS_MAPPING));
                input.put(I_DYNAMIC_SEGMENT_ATTRIBUTES,
                		convertToInputParameterType(dynamicSegmentBusinessAttribs));
				
                declareParameter(new SqlParameter(I_FORCE_DYNAMIC, Types.VARCHAR));
                input.put(I_FORCE_DYNAMIC, Affirm.isYOrN(forceDynamic));
                
                compile();
            } catch (Exception ex) {
                throw new DataAccessException(ex);
            }
        }
        private Object convertToInputParameterType(
                Map<Integer, DynamicSegmentBusinessAttribute> dynamicSegmentBusinessAttribs)
                throws CannotGetJdbcConnectionException, SQLException {

            ArrayDescriptor descTbl = ArrayDescriptor.createDescriptor(
                    OBJ_DYNAMIC_BUSINESS_MAPPING, getConnection());

            ArrayList<STRUCT> convertedToStructs = new ArrayList<STRUCT>();

            if (dynamicSegmentBusinessAttribs != null) {

                StructDescriptor desc = StructDescriptor.createDescriptor(
                        OBJ_DYNAMIC_BUSINESS_MAPPING_REC, getConnection());

                for (Integer segmentNum : dynamicSegmentBusinessAttribs.keySet()) {
                    DynamicSegmentBusinessAttribute dynField = dynamicSegmentBusinessAttribs
                            .get(segmentNum);

                    Object[] attributes = new Object[desc.getLength()];
                    attributes[0] = segmentNum;
                    attributes[1] = dynField != null ? dynField.getVal() : null;

                    STRUCT struct = new STRUCT(desc, getConnection(), attributes);

                    convertedToStructs.add(struct);

                }
            }

            Object[] convertedToObjectArray = (Object[]) convertedToStructs
                    .toArray(new Object[convertedToStructs.size()]);

            return new ARRAY(descTbl, getConnection(), convertedToObjectArray);
        }
        public Map<String, Object> execute() {
            return super.execute(input);
        }
        
     }
    /**
     * Stored procedure that will load the Accounts subjected to posting.
     * 
     * @author Oracle Retail
     * @author Tony Cheng
     */
    public class CallRetrieveAccounts extends StoredProcedure {
        static final String FUNCTION_NAME = SUPPORTING_STORED_PROCEDURE_PACKAGE
        									+ ".RETRIEVE_ACCTS_FOR_VALIDATION";
        protected static final String O_ACCOUNTS = "accounts";
        protected final String OBJ_ACCOUNTS = DatasourceProperties.schemaOwner + ".OBJ_REIM_POSTING_ACCT_TBL";

        protected final String OBJ_ACCOUNT_REC = DatasourceProperties.schemaOwner +".OBJ_REIM_POSTING_ACCT_REC"; 

        public static final String IN_POSTING_ID = "postingId";

        Map<String, Object> input = new HashMap<String, Object>();
        
        public CallRetrieveAccounts(DataSource ds, Long postingId) {
            super(ds,FUNCTION_NAME);
                    
            setFunction(true);

            StoredProcedureUtils.registerOutputStatusParameters(this);

            declareParameter(new SqlOutParameter(O_ACCOUNTS, Types.ARRAY,
            		OBJ_ACCOUNTS)); 

            declareParameter(new SqlParameter(IN_POSTING_ID, Types.NUMERIC));
            input.put(IN_POSTING_ID, postingId);

            try {
                 compile();
            } catch (Exception ex) {
                throw new DataAccessException(ex);
            }
        }
        private Map<SetOfBooks,List<Account>> parseAccounts(Map<String, Object> acctsResult)throws SQLException {

    		List<Account> accounts = null;
    		Map<SetOfBooks,List<Account>> accountsMap = new HashMap<SetOfBooks, List<Account>>();
    		
    		Array array = (Array) acctsResult.get(O_ACCOUNTS);
    		if (array != null) {
    		Object[] structs = (Object[]) array.getArray();
    		Object[] attributes;
    		if (structs != null && structs.length > 0) {
    		    
    			for (Object struct : structs) {
    		        attributes = ((STRUCT) struct).getAttributes();
    		        final PostingDocumentAccount account = new PostingDocumentAccount();
    		        
    		        account.setSetOfBooks(new SetOfBooks(((BigDecimal)attributes[20]).longValue()));
    		        for(int i=0; i < ReIMSystemPropertiesUtil.getMaximumSegments(); i++) {
    		        	String segValue = (String)attributes[i];
                        if (!NO_VALUE.equalsIgnoreCase(segValue))
    		        		account.addSegment(new AccountSegment(i + 1,segValue));
    		        }
    		        
    		        
    		        account.setType(AccountType.fromCode((String)attributes[21]));
    		        account.setCode((String)attributes[22]);
    		        account.setStatus(AccountStatus.fromCode((String)attributes[23]));
                    account.setPostingAmtId(((BigDecimal)attributes[24]).longValue());
                    
    		        if (accountsMap.get(account.getSetOfBooks()) == null) {
    		        	accounts = new ArrayList<Account>();
    		        } else {
    		        	accounts = (List<Account>) accountsMap.get(account.getSetOfBooks());
    		        }
		        	accounts.add(account);
		        	accountsMap.put(account.getSetOfBooks(), accounts);
    		    }
    		}
    		}
    		return accountsMap;
    		
        }        
        public Map<SetOfBooks,List<Account>> execute() {

            try {
                Map<String, Object> rawResult = super.execute(input);

                StoredProcedureUtils.checkErrors(rawResult);
                return parseAccounts(rawResult);
            } catch (Exception e) {
                throw new DataAccessException(e);
            }

        }
        
     }

    /**
     * Stored procedure that will update the Accounts status subjected to posting.
     * 
     * @author Oracle Retail
     * @author Tony Cheng
     */
    public class CallUpdateAccountStatus extends StoredProcedure {

    	static final String FUNCTION_NAME = SUPPORTING_STORED_PROCEDURE_PACKAGE
        									+ ".UPDATE_POSTING_ACCOUNTS_STATUS";
        private static final String I_ACCOUNTS = "I_ACCOUNTS";

        protected final String OBJ_ACCOUNTS = DatasourceProperties.schemaOwner+".OBJ_REIM_POSTING_ACCT_TBL";
 
        protected final String OBJ_ACCOUNT_REC = DatasourceProperties.schemaOwner+".OBJ_REIM_POSTING_ACCT_REC";
     
        public static final String IN_POSTING_ID = "postingId";

        Map<String, Object> input = new HashMap<String, Object>();
        

        public CallUpdateAccountStatus(DataSource ds, Long postingId, Map<SetOfBooks,List<Account>> accountsMap) {
            super(ds,FUNCTION_NAME);
            setFunction(true);
            try {
                StoredProcedureUtils.registerOutputStatusParameters(this);
                
                declareParameter(new SqlParameter(IN_POSTING_ID, Types.NUMERIC));
                input.put(IN_POSTING_ID, postingId);

                declareParameter(new SqlParameter(I_ACCOUNTS, Types.ARRAY,OBJ_ACCOUNTS));
                input.put(I_ACCOUNTS,convertToInputParameterType(accountsMap));
				

                compile();
            } catch (Exception ex) {
                throw new DataAccessException(ex);
            }
        }
        
        private Object convertToInputParameterType(
        		Map<SetOfBooks,List<Account>> accountsMap)
                throws CannotGetJdbcConnectionException, SQLException {

            ArrayDescriptor descTbl = ArrayDescriptor.createDescriptor(
            		OBJ_ACCOUNTS, getConnection());

            ArrayList<STRUCT> convertedToStructs = new ArrayList<STRUCT>();
            
            if (accountsMap != null) {

                StructDescriptor desc = StructDescriptor.createDescriptor(
                		OBJ_ACCOUNT_REC, getConnection());
                for (SetOfBooks sobId : accountsMap.keySet()) {

                	List<Account> accounts = accountsMap.get(sobId);
                	for (Account account : accounts) {
	                    Object[] attributes = new Object[desc.getLength()];
	                    for (int i = 0; i <ReIMSystemPropertiesUtil.getMaximumSegments(); i++) {
                            String segVal = account.getSegment(i + 1).getValue();
                            attributes[i] = segVal != null ? segVal : NO_VALUE;
	                    }
	                    attributes[20] = sobId.getSetOfBooksId();
	                    attributes[21] = account.getType().getCode();
	                    attributes[22] = account.getCode();
                        attributes[23] = account.getStatus().getCode();
                        attributes[24] = ((PostingDocumentAccount)account).getPostingAmtId();
	
	                    STRUCT struct = new STRUCT(desc, getConnection(), attributes);
	
	                    convertedToStructs.add(struct);
                	}

                }
            }

            Object[] convertedToObjectArray = (Object[]) convertedToStructs
                    .toArray(new Object[convertedToStructs.size()]);

            return new ARRAY(descTbl, getConnection(), convertedToObjectArray);
        }
        
        public Map<String, Object> execute() {
            return super.execute(input);
        }
        
    }
    
    /**
     * Purges IM_POSTING_ACCOUNT for any row that is not associated with any errors
     * (IM_POSTING_DOC_ERROR)
     */
    public void deletePostingAccountsWithNoErrors(PostingStatus.Id postingStatusId, Long docId) {
    
    if (docId == null) {
        SqlCriteriaBuilder crit = new SqlCriteriaBuilder(DELETE_SUCCESSFUL_IM_POSTING_DOC_ACCOUNTS2);
        crit.and(" IPDAMT.POSTING_ID = ? ", postingStatusId.getPostingId());
        crit.and(" IPDAMT.DOC_ID = ? ", docId);
        crit.appendSql(" )");
        getSimpleJdbcTemplate().update(crit.toString(), 
                                       crit.getParameterValuesAsArray());       
    } else {
        SqlCriteriaBuilder crit = new SqlCriteriaBuilder(DELETE_SUCCESSFUL_IM_POSTING_DOC_ACCOUNTS);
        crit.and(" IPDAMT.POSTING_ID = ? ", postingStatusId.getPostingId());
        crit.and(" IPDAMT.DOC_ID = ? ", docId);
        crit.appendSql(" )");
        getSimpleJdbcTemplate().update(crit.toString(), 
                                       crit.getParameterValuesAsArray());
    }
    }

    /**
     * load  accounts subject to posting.
     */

    public void loadAccounts(PostingStatus.Id postingStatusId, boolean forceDynamicInd) {
        CallLoadAccounts proc = new CallLoadAccounts(getJdbcTemplate()
                .getDataSource(), DynamicSegmentUtils.getBusinessAttributesForSegmentNums(0), forceDynamicInd,
                postingStatusId.getPostingId());
        Map<String, Object> result = proc.execute();
        StoredProcedureUtils.checkErrors(result);
    }

    /**
     * Retrieve accounts to be validated against the financial system.
     */

    public Map<SetOfBooks,List<Account>> retrieveAcctsForValidation(PostingStatus.Id postingStatusId) {
    	CallRetrieveAccounts proc = new CallRetrieveAccounts(getJdbcTemplate().getDataSource(), postingStatusId.getPostingId());
        return proc.execute();
    }

    /**
     * update account status subject to posting.
     */
    public void updateAccountStatus(PostingStatus.Id postingStatusId, Map<SetOfBooks,List<Account>> accountsMap) {
    	CallUpdateAccountStatus proc = new CallUpdateAccountStatus(getJdbcTemplate().getDataSource(), postingStatusId.getPostingId(),accountsMap);
        StoredProcedureUtils.checkErrors(proc.execute());
    }


}
