package oracle.retail.reim.services.matching.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.business.DocumentType;
import oracle.retail.reim.business.MerchandiseInvoiceCostDiscrepancy;
import oracle.retail.reim.business.MerchandiseInvoiceQuantityDiscrepancy;
import oracle.retail.reim.business.document.DiscrepancyDocReference;
import oracle.retail.reim.data.dao.ICostDiscrepancyDao;
import oracle.retail.reim.data.dao.IInvoiceDetailDao;
import oracle.retail.reim.data.dao.IOrderLocationDao;
import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.services.IVarianceService;
import oracle.retail.reim.services.ServiceAccessException;
import oracle.retail.reim.services.matching.IMatchService;
import oracle.retail.reim.services.matching.IMatchStatusService;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.reim.business.Order;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Tolerance;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.match.AutoMatchMetrics;
import com.retek.reim.business.match.InvoiceLevel;
import com.retek.reim.business.match.InvoiceLineLevel;
import com.retek.reim.business.match.InvoiceSummaryGroupLevel;
import com.retek.reim.business.match.Match;
import com.retek.reim.business.match.OrderLineLevel;
import com.retek.reim.business.match.ReceiptSummaryGroupLevel;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.foundation.AAutoMatchThreadedBean;
import com.retek.reim.foundation.AOrderLocationBean;
import com.retek.reim.merch.utils.ReIMAutoMatchThreadBeanFactory;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.services.DiscrepancyVo;
import com.retek.reim.services.ReceiptTrackingService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.matching.AutoMatchMetricsService;
import com.retek.reim.services.matching.MatchHistoryService;

/**
 * AutoMatchService
 * 
 * Date     Reference  Developer     Description
 * ======== ========== ============= ==============================================
 * 20131022 178176     Simon Mann    Retrofitted changes from Oracle patch 17050029.
 *                                   https://ims.olrretail.com/ims/Ticket/Display.html?id=178176
 * 
 * BRN V1.4  30-Oct-2013	BNaik
 * 								IMS 176175 - AutoMatch was not able to calculate the cost variance when unit cost of the item in the receipt is zero
 *                              or when there is no receipt item. As a result the cost_matched was updated to 'Y' even when there was cost discrepancy.
 *                              Oracle had fixed this issue in a different version 13.0.5.6 for the bug # 14142939. 
*                               This bug fix is not forward ported to version 13.1.7 yet. The solution released for bug # 14142939 
*                               is applied to SMR version 13.1.
*                                
*  BRN V1.5 17-Mar-2014	BNaik
*                                IMS 191769 - Automatch errors out with: "java.sql.SQLException: ORA-00001: unique constraint (RMSPRD.UK_IM_COST_DISCREPANCY) violated".
*                                Retrofitted Oracle fix for base bug 17255296.
*                                
*                                
*  NJ V1.6 7-July-2015	Naveen J
*                                ME 498372 - LINUX REIM_AUTO_MATCH Abort: "java.sql.SQLException: ORA-00001: unique constraint (RMSPRD.UK_IM_QTY_DISCREPANCY) violated".
*                                Modified code for 178176 fix applied on October 2013.                       
*                                
*/

@Service
public class AutoMatchService extends com.retek.reim.services.matching.AutoMatchService implements
        oracle.retail.reim.services.matching.IAutoMatchService {

    private IMatchStatusService matchStatusService;
    private IInvoiceDetailService invoiceDetailService;
    private IInvoiceDetailDao invoiceDetailDao;
    private IVarianceService varianceService;
    private IMatchService matchService;
    private IOrderLocationDao orderLocationDao;
    private ICostDiscrepancyDao costDiscrepancyDao;

    public AutoMatchService() {
    }

    /**
     * Method autoMatch.
     * 
     * This method attempts to match invoices with receipts for a common po/location
     * 
     * @throws ReIMException
     */
    public void autoMatch(POLocation[] allPOLocationsForMatching) throws ReIMException {
        /**
         * retrieve globals i.e. vdate, days before due date and primary currency
         */
        super.setGlobals();

        /**
         * separate po locations into 2 groups: 1 for PO Locations without receipts, 1 for PO
         * Locations with receipts
         */
        List<POLocation> noReceipts = new ArrayList<POLocation>();
        List<POLocation> withReceipts = new ArrayList<POLocation>();

        separatePOLOcations(allPOLocationsForMatching, noReceipts, withReceipts);

        List costDiscrepancies = new ArrayList();
        List qtyDiscrepancies = new ArrayList();

        // If no receipts we don't want to process so commneted out the below code
        // OLR Mod 1.01
      //  if (noReceipts.size() > 0) {
      //      POLocation[] noReceiptsArray = new POLocation[noReceipts.size()];
      //      noReceipts.toArray(noReceiptsArray);

            /** cost pre-match po locations that do not have any receipts */
      //      costDiscrepancies = costMatch(noReceiptsArray);

            /**
             * For POLocations without any receipts, potentially generate qty discrepancies
             */
      //      qtyDiscrepancies = routeUnreceivedInvoices(noReceiptsArray);

            /**
             * If not cost pre-matching, and line cost matches, update invoice line cost match
             * indicator
             */
      //      updateDetailCostMatch(costDiscrepancies, qtyDiscrepancies);

      //      updateInvoicesWithoutReceipts(noReceiptsArray);
      //  }

        /** receipt match po locations that have receipts */
        List discrepancies = new ArrayList();
        Match[] successfulSummaryMatches = null;

        if (withReceipts.size() > 0) {
            POLocation[] withReceiptsArray = new POLocation[withReceipts.size()];
            withReceipts.toArray(withReceiptsArray);

            ReceiptMatchResults results = receiptMatch(withReceiptsArray);
            discrepancies = results.getDiscrepancies();
            successfulSummaryMatches = results.getSuccessfulSummaryMatches();

            /** update db with results (status) */
            getMatchStatusService().updateInvoiceStatuses(withReceiptsArray, getVDate(),
                    getUserId());

            updateReceiptStatuses(withReceiptsArray);

            /** delete any existing discrepancy for detail matched invoices */
            deleteCostDiscrepanciesAndPartialResolutions(withReceiptsArray);
        }

        /** Persist any discrepancies that were created */
        discrepancies.addAll(costDiscrepancies);
        discrepancies.addAll(qtyDiscrepancies);
        persistDiscrepancies(discrepancies);

        /** writing the auto-match metrics */
        AutoMatchMetrics metrics = createAutoMatchMetrics(successfulSummaryMatches,
                allPOLocationsForMatching);
        AutoMatchMetricsService.persistMetrics(metrics);
    }

    public void autoMatchWithLocking(POLocation[] allPOLocationsForMatching) throws ReIMException {

        try {
            Match[] successfulSummaryMatches = null;
            ArrayList allPOLocationsForMatchingList = null;

            /**
             * retrieve globals i.e. vdate, days before due date and primary curreny
             */
            super.setGlobals();

            /**
             * separate po locations into 2 groups: 1 for PO Locations without receipts, 1 for PO
             * Locations with receipts
             */
            List<POLocation> noReceipts = new ArrayList<POLocation>();
            List<POLocation> withReceipts = new ArrayList<POLocation>();

            separatePOLOcations(allPOLocationsForMatching, noReceipts, withReceipts);

            allPOLocationsForMatchingList = new ArrayList(Arrays.asList(allPOLocationsForMatching));

            POLocation poLocation = null;
            POLocation poLocation2 = null;

            // If no receipts we don't want to process so commneted out the below code
            // OLR Mod 1.01
         //   if (noReceipts.size() > 0) {
         //       List tempCostDiscrepancies = new ArrayList();
         //       List tempQtyDiscrepancies = new ArrayList();
         //       POLocation[] noReceiptsArray = new POLocation[1];
         //       Iterator noReceiptsIterator = noReceipts.iterator();

         //       while (noReceiptsIterator.hasNext()) {
         //           poLocation = (POLocation) noReceiptsIterator.next();
         //           try {
         //               if (lockRowsIM(poLocation) && lockRowsRMS(poLocation)) {
         //                   noReceiptsArray[0] = poLocation;
                            /**
                             * cost pre-match po locations that do not have any receipts
                             */
         //                   tempCostDiscrepancies = costMatch(noReceiptsArray);

                            /**
                             * For POLocations without any receipts, potentially generate qty
                             * discrepancies
                             */
         //                   tempQtyDiscrepancies = routeUnreceivedInvoices(noReceiptsArray);

                            /**
                             * If not cost pre-matching, and line cost matches, update invoice line
                             * cost match indicator
                             */
          //                  updateDetailCostMatch(tempCostDiscrepancies, tempQtyDiscrepancies);
          //                  updateInvoicesWithoutReceipts(noReceiptsArray);

          //                  persistDiscrepancies(tempCostDiscrepancies);
          //                  persistDiscrepancies(tempQtyDiscrepancies);
          //              } else {
          //                  Iterator<POLocation> allPOLocationsForMatchingListIterator = allPOLocationsForMatchingList
          //                          .iterator();
          //                  while (allPOLocationsForMatchingListIterator.hasNext()) {

          //                      poLocation2 = allPOLocationsForMatchingListIterator.next();

          //                      String order = poLocation2.getOrder().getOrderNo();
          //                      String location = poLocation2.getLocation().getLocationId();

          //                      if (order.equals(poLocation.getOrder().getOrderNo())
          //                              && location
          //                                      .equals(poLocation.getLocation().getLocationId())) {
          //                          allPOLocationsForMatchingListIterator.remove();
          //                      }
          //                  }
          //              }
          //          } finally {
          //              unlockRows(poLocation);
          //          }
          //      }
          //  }

            /** receipt match po locations that have receipts */
            if (withReceipts.size() > 0) {
                List tempDiscrepancies = new ArrayList();

                POLocation[] withReceiptsArray = new POLocation[1];
                Iterator withReceiptsIterator = withReceipts.iterator();

                while (withReceiptsIterator.hasNext()) {
                    poLocation = (POLocation) withReceiptsIterator.next();
                    try {
                        if (lockRowsIM(poLocation) && lockRowsRMS(poLocation)) {
                            withReceiptsArray[0] = poLocation;

                            ReceiptMatchResults results = receiptMatch(withReceiptsArray);
                            tempDiscrepancies = results.getDiscrepancies();
                            successfulSummaryMatches = results.getSuccessfulSummaryMatches();

                            /** update db with results (status) */
                            getMatchStatusService().updateInvoiceStatuses(withReceiptsArray,
                                    getVDate(), getUserId());
                            updateReceiptStatuses(withReceiptsArray);

                            /**
                             * delete any existing discrepancy for detail matched invoices
                             */
                            deleteCostDiscrepanciesAndPartialResolutions(withReceiptsArray);

                            persistDiscrepancies(tempDiscrepancies);

                        } else {
                            Iterator allPOLocationsForMatchingListIterator = allPOLocationsForMatchingList
                                    .iterator();
                            while (allPOLocationsForMatchingListIterator.hasNext()) {
                                poLocation2 = (POLocation) allPOLocationsForMatchingListIterator
                                        .next();
                                if (poLocation2.getOrder().getOrderNo().equals(
                                        poLocation.getOrder().getOrderNo())
                                        && poLocation2.getLocation().getLocationId().equals(
                                                poLocation.getLocation().getLocationId())) {
                                    allPOLocationsForMatchingListIterator.remove();
                                }
                            }
                        }
                    } finally {
                        unlockRows(poLocation);
                    }
                }
            }

            POLocation[] newAllPOLocationsForMatching = new POLocation[allPOLocationsForMatchingList
                    .size()];
            newAllPOLocationsForMatching = (POLocation[]) allPOLocationsForMatchingList
                    .toArray(newAllPOLocationsForMatching);

            /** writing the auto-match metrics */
            AutoMatchMetrics metrics = createAutoMatchMetrics(successfulSummaryMatches,
                    newAllPOLocationsForMatching);
            AutoMatchMetricsService.persistMetrics(metrics);

        } catch (Exception e) {
            throw new ServiceAccessException(e);
        }
    }

    /**
     * Method costMatch.
     * 
     * Performs cost matching for the passed in invoice. It returns a list of cost discrepancies for
     * invoice lines that do not match.
     * 
     * @param poLocation
     * @param invoice
     * @return ArrayList
     * @throws ReIMException
     */
    protected ArrayList costMatch(POLocation poLocation, MerchandiseDocument invoice)
            throws ReIMException {
        try {
            // will hold all cost discrepancies for the invoice
            ArrayList costDiscrepancies = new ArrayList();

            // get the invoice lines from database and set them on invoice
            invoiceDetailService.buildInvoiceLines(invoice);

            Map invoiceLines = invoice.getDocDetail();

            // if there are no invoice lines, cost matching is not possible for
            // this invoice and
            // will
            // not be performed.
            if (invoiceLines == null || invoiceLines.size() == 0) return costDiscrepancies;

            // for each line, determine whether there is a match
            DocumentItemInvoice invoiceLine = null;
            MerchandiseInvoiceCostDiscrepancy costDiscrepancy = null;
            Iterator i = invoiceLines.values().iterator();
            while (i.hasNext()) {
                invoiceLine = (DocumentItemInvoice) i.next();

                // find the corresponding item within the po item locations hash
                // map
                POItemLocation poItemLocation = (POItemLocation) poLocation.getPoItemLocations()
                        .get(invoiceLine.getItem().getItemId());

                // invoice lines with no corresponding order line are ignored
                if (poItemLocation != null) {
                    // attempt to cost match the invoice line
                    costDiscrepancy = costMatch(poLocation, poItemLocation, invoiceLine, invoice);

                    // if a cost discrepancy was generated for the invoice line,
                    // add it to the
                    // cost discrepancies list
                    if (costDiscrepancy != null) costDiscrepancies.add(costDiscrepancy);
                }
            }

            // indicate that cost pre-matching was performed on this invoice
            // with lines.
            invoice.setCostPreMatched(true);

            return costDiscrepancies;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_price_match", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    /**
     * Method costMatch.
     * 
     * Attempts to match unit cost for each invoice line with the unit cost on the order line. This
     * matching is only performed for po locations without receipts. Cost discrepancies are
     * generated and returned for invoice lines that do not match within tolerance.
     * 
     * @param poLocations
     * @return ArrayList
     * @throws ReIMException
     */
    public ArrayList costMatch(POLocation[] poLocations) throws ReIMException {
        try {
            // will hold all cost discrepancies to be written across all po
            // locations
            // TransactionManagerFactory.getInstance().start();

            ArrayList costDiscrepancies = new ArrayList();

            // loop through po locations for cost matching
            int poLocationsLength = poLocations.length;
            for (int i = 0; i < poLocationsLength; i++) {
                // perform cost matching for each po location
                costDiscrepancies.addAll(costMatch(poLocations[i]));
            }

            return costDiscrepancies;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_price_match", Severity.ERROR, e,
                    AutoMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */
    }

    public List routeUnreceivedInvoice(MerchandiseDocument invoice, POLocation poLocation)
            throws ReIMException {
        try {
            List quantityDiscrepancies = new ArrayList();

            // if invoice lines are not populated, retrieve them
            Map invoiceLines = invoice.getDocDetail();
            if (invoiceLines == null || invoiceLines.size() == 0)
                getInvoiceDetailService().buildInvoiceLines(invoice);

            // if invoice lines still do not exist, then quantity discrepancies
            // cannot be created
            // and routed
            invoiceLines = invoice.getDocDetail();
            if (invoiceLines == null || invoiceLines.size() == 0) return quantityDiscrepancies;

            // set the invoice to detail matched
            invoice.setDetailMatched(true);

            // loop through invoice lines
            Iterator i = invoiceLines.values().iterator();
            while (i.hasNext()) {
                // create a qty discrepancy for each line
                quantityDiscrepancies.add(super.createQtyDiscrepancy(poLocation, invoice,
                        (DocumentItemInvoice) i.next()));
            }

            // return discrepancies
            return quantityDiscrepancies;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_route_unreceived_invoice", Severity.ERROR, e,
                    AutoMatchService.class, new String[] { String.valueOf(invoice.getDocId())});
        }
    }

    public List routeUnreceivedInvoices(POLocation[] poLocations) throws ReIMException {
        try {
            // this will hold all the qty discrepancies generated from po
            // locations that haven't
            // been received
            List qtyDiscrepancies = new ArrayList();

            boolean isSingleInvoice = false;

            POLocation poLocation = null;
            MerchandiseDocument[] invoices = null;
            int poLocationLength = poLocations.length;
            for (int i = 0; i < poLocationLength; i++) {
                poLocation = poLocations[i];

                // check if multiple invoices are in a po location
                invoices = poLocation.getInvoices();
                if (invoices.length > 1)
                    isSingleInvoice = false;
                else
                    isSingleInvoice = true;

                // get supplier based routing days for the po location
                int routingDays = poLocation.getOrder().getSupplier().getSupplierOptions()
                        .getQtyDiscDayBeforeRte();

                // for each invoice check if the invoice should be routed
                int invoiceLength = invoices.length;
                for (int j = 0; j < invoiceLength; j++) {
                    // route invoices that have passed the routing date;
                    List costDiscs = ServiceFactory.getDiscrepancyService()
                            .getCostDiscrepanciesForDocId(Long.toString(invoices[j].getDocId()));
                    List qtyDiscs = ServiceFactory.getDiscrepancyService()
                            .getQtyDiscrepanciesForDocId(Long.toString(invoices[j].getDocId()));
                    // if cost or quantity discrepancies are existing for an
                    // invoice then that invoice cannot be
                    // in multi unresolved match status. The status should be
                    // unresolved match.
                    if ((costDiscs == null || costDiscs.size() == 0)
                            && (qtyDiscs == null || qtyDiscs.size() == 0)
                            && isTodayPostRoutingDays(invoices[j], routingDays)) {
                        // multiple invoices in po location, set invoices to
                        // multi-unresolved
                        // status;
                        // single invoice in po location, set invoice to
                        // un-resolved match status
                        invoices[j].setStatus(isSingleInvoice ? Document.UNRESOLVED_MATCH
                                : Document.MULTI_UNRESOLVED);

                        // single invoice in po location
                        if (isSingleInvoice) {
                            // generate discrepancy
                            qtyDiscrepancies
                                    .addAll(routeUnreceivedInvoice(invoices[j], poLocation));
                        }
                    }
                    // invoices that haven't passed the routing date will remain
                    // in READY FOR MATCH
                    // status
                }
            }

            return qtyDiscrepancies;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_route_unreceived_invoices", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    /*
     * Get the itemIds in all the invoices in a polocation
     */
    private ArrayList getItemIdsInAllInvoicesInPOLocation(POLocation poLocation)
            throws ReIMException {
        MerchandiseDocument[] invoices = poLocation.getInvoices();
        ArrayList items = new ArrayList();
        for (int i = 0; i < invoices.length; i++) {
            try {
                invoiceDetailService.buildInvoiceLines(invoices[i]);
            } catch (ReIMException e) {
                throw e;
            } catch (Exception e) {
                throw new ReIMException("Error could not buildInvoiceLines", Severity.ERROR, e,
                        AutoMatchService.class);
            }
            Map docDetails = invoices[i].getDocDetail();
            if (docDetails != null && docDetails.size() > 0) {
                items.addAll(docDetails.keySet());
            }
        }
        return items;
    }

    /**
     * 
     * @param poLocation
     * @return
     * @throws ReIMException
     */
    private ArrayList findEligibleInvoiceslineLevelMatch(POLocation poLocation)
            throws ReIMException {
        ArrayList invoiceList = new ArrayList();
        // get all the invoicesfor a POLocation
        //Do not include those invoices which are already matched in one to one match
        MerchandiseDocument[] allInvoices = poLocation.getInvoices();
        List tempList = new ArrayList();
        int invLength = allInvoices.length;
        for(int j=0;j<invLength;j++){
        	if(!allInvoices[j].getStatus().equalsIgnoreCase(Document.MATCHED))
        			tempList.add(allInvoices[j]);
        }
        
        
        
        MerchandiseDocument[] invoices = (MerchandiseDocument[])tempList.toArray(new MerchandiseDocument[tempList.size()]);
        int invoicesLength = invoices.length;
        // get all the itemIds in all the invoices in a given POLocation
        ArrayList itemsList = getItemIdsInAllInvoicesInPOLocation(poLocation);
        for (int i = 0; i < invoicesLength; i++) {
            // get all the items in a invoice
            Map hmItems = invoices[i].getDocDetail();
            if (hmItems == null || hmItems.size() == 0) {
                continue;
            }
            Set itemKeys = hmItems.keySet();
            Iterator iterInvoiceItem = itemKeys.iterator();
            boolean skip = false;
            // iterate thru the items for an invoice
            while (iterInvoiceItem.hasNext() && !skip) {
                int count = 0;
                String itemId = (String) iterInvoiceItem.next();
                Iterator iterItemsList = itemsList.iterator();
                // iterate thru all the items for a polocation
                while (iterItemsList.hasNext()) {
                    String itemIdFromList = (String) iterItemsList.next();
                    // check if the invoiceItem exist in the list of all items
                    // in all the invoice in a PoLocation.
                    if (itemIdFromList.equals(itemId)) {
                        count++;
                    }
                }
                // if the occurence of InvoiceItem more than once in the list of
                // all item in all invoices in a PoLocation,
                // skip the invoice and continue with next invoice
                if (count > 1) {
                    skip = true;
                    break;
                }
            }
            // Add only that invoice in which the items are existing only that
            // invoice and none of the other invoices in PoLocation.
            if (!skip) {
                invoiceList.add(invoices[i]);
            }
        }
        return invoiceList;
    }

    /**
     * Method receiptMatch.
     * 
     * This method will attempt to match invoices with receipts for the passed in po locations.
     * 
     * @param poLocations
     * @return ArrayList
     * @throws ReIMException
     */
    public ReceiptMatchResults receiptMatch(POLocation[] poLocations) throws ReIMException {
        try {
            // This list will hold all cost and quantity discrepancies generated
            // across the passed in po locations
            // for failed match attempts
            ArrayList discrepancies = new ArrayList();

            // This list will hold all successful matches that are matched at
            // summary level
            ArrayList successfulSummaryMatches = new ArrayList();

            // This list will hold all successful matches that are matched at
            // the detail level.
            // It will also hold all detail mathes that are only quantity
            // matched, but not cost matched.
            ArrayList successfulDetailAndQuantityMatches = new ArrayList();

            // loop through po locations
            POLocation poLocation = null;
            Match poLocationLevelMatch = null;
            int poLocationsLength = poLocations.length;
            for (int i = 0; i < poLocationsLength; i++) {
                poLocation = poLocations[i];

                // Retrieve the supplier options for this order's supplier
                populateSupplierOptions(poLocation);

                // attempt po location level match
                poLocationLevelMatch = poLocationLevelMatch(poLocation);

                // if the po location level match is failed, attempt one to one
                // match
                // Otherwise, if it is successful, continue with the next po
                // location
                if (poLocationLevelMatch.isMatchSuccessful()) {
                    // for po locations that are matched, add to the result
                    // collection for persisting to db
                    successfulSummaryMatches.add(poLocationLevelMatch);
                    continue;
                }

                // Attempt one-to-one matching for po locations that have failed
                // po location level group matching
                successfulSummaryMatches.addAll(summaryOneToOneMatch(poLocation));

                // check the po location's invoices' and receipts' statuses to
                // determine multi-unresolved
                // status and to determine whether the po location as a whole
                // has been matched
                poLocationLevelMatch.setMatchSuccessful(ServiceFactory.getMatchStatusService()
                        .checkMatchedStatus(poLocation));
                boolean isMultiUnresolved = checkMultiUnresolvedStatus(poLocation);

                // if all invoices are matched, go to the next po location
                if (poLocationLevelMatch.isMatchSuccessful()) {
                    continue;
                }

                // if the invoices are in multiUnresolved status check for the
                // eligibility of line
                // level match and if not eligible go to next location
                
                if (isMultiUnresolved) {
                    ArrayList multiUnresolvedInvoiceList = findEligibleInvoiceslineLevelMatch(poLocation);
                    if (multiUnresolvedInvoiceList.size() == 0) {
                        continue;
                    }
                    Receipt[] receipts = getReceiptsForLineLevelMatch(poLocation);
                    Iterator iterMUInvoiceList = multiUnresolvedInvoiceList.iterator();
                    
                    /*// V1.6 - NJ - old code commented - starts here        
                    DetailMatchResults detailMatchResults=null; // OLR 178176 Inserted
	               // V1.6 - NJ- old code commented - ends here    */  
                    
                    
                    while (iterMUInvoiceList.hasNext()) {
                        MerchandiseDocument invoice = (MerchandiseDocument) iterMUInvoiceList
                                .next();
                        
                        if (isTodayPostRoutingDays(invoice,
                        		poLocation.getOrder().getSupplier().getSupplierOptions().getQtyDiscDayBeforeRte())) { // OLR 178176 Inserted
                        	
                        	// Only execute the following if today is after the routing date.
                        
                        	// V1.6 - NJ - old code  reverted to base  - starts here  
	                        	/*-------- old code ----------
	                        	 * detailMatchResults = lineLevelMatch(invoice, receipts,poLocation); // OLR 178176 Modified
	                        	 * -------- old code ----------*/
	                        	//-------- new code ----------
	                        	DetailMatchResults	detailMatchResults = lineLevelMatch(invoice, receipts,poLocation); 
	                        	 //-------- new code ----------*/
                            // V1.6 - NJ- old code  reverted to base  - ends here    */
                        	
                            // Determine whether the entire invoice should be put
	                        // into matched status
	                        ServiceFactory.getMatchStatusService().checkMatchedStatus(invoice);
	                        // Determine whether the all receipts should be put into
	                        // matched status
	                        if (receipts != null) {
	                            ServiceFactory.getMatchStatusService().checkMatchedStatus(receipts, invoice);
	                        }
	                        // If the match is successful, calculate the receipt of
	                        // goods date for the invoice
	                        if (invoice.getStatus().equals(Document.MATCHED) && receipts != null) {
	                            ServiceFactory.getTermsService().calculateReceiptOfGoodsDate(invoice,
	                                    receipts);
	                        }
	                        // Set the detail matched indicator to indicate that
	                        // line level matching
	                        // has been performed for this invoice to avoid
	                        // recycling. Once an invoice has been detail matched,
	                        // it is no longer processed by auto match.
	                        invoice.setDetailMatched(true);
	                /*// V1.6 - NJ - old code commented - starts here        
                        } // OLR 178176 Inserted
    	            // V1.6 - NJ- old code commented - ends here    */  
                        
                        // add any discrepancise that resulted from line level
                        // matching for this po location
                        // to the list for all po locations.
                        if (detailMatchResults != null) {
                            ArrayList discrepanciesFromDetailMatch = detailMatchResults
                                    .getDiscrepancies();
                            if (discrepanciesFromDetailMatch != null
                                    && discrepanciesFromDetailMatch.size() > 0) {
                                discrepancies.addAll(discrepanciesFromDetailMatch);
                                invoice.setStatus(MerchandiseDocument.UNRESOLVED_MATCH);
                            }
                            successfulDetailAndQuantityMatches.addAll(detailMatchResults
                                    .getSuccessfulMatches());
                            //successfulDetailAndQuantityMatches.addAll(detailMatchResults
                             //       .getQuantityMatches());
                        }
                        
                    // V1.6 - NJ - new code added - starts here        
                       //setting detailMatchResults explicitly as null 
                        detailMatchResults=null;
                       // end of if(isTodayPostRoutingDays(invoice,poLocation.getOrder().getSupplier().getSupplierOptions().getQtyDiscDayBeforeRte()))  
                        } // OLR 178176 Inserted
    	            // V1.6 - NJ- new code added - ends here    
                    }
                } else {
                    // Attempt to line level match
                    DetailMatchResults detailMatchResults = lineLevelMatch(poLocation);
                    // add any discrepancise that resulted from line level
                    // matching for this po location
                    // to the list for all po locations.
                    if (detailMatchResults != null) {
                        discrepancies.addAll(detailMatchResults.getDiscrepancies());
                        successfulDetailAndQuantityMatches.addAll(detailMatchResults
                                .getSuccessfulMatches());
                        //successfulDetailAndQuantityMatches.addAll(detailMatchResults
                         //       .getQuantityMatches());
                    }
                }
            }
            

            // if any summary matches are achieved, write to the database, and
            // calculate variance
            Match[] successfulSummaryMatchesArray = null;
            if (successfulSummaryMatches.size() > 0) {
                successfulSummaryMatchesArray = new Match[successfulSummaryMatches.size()];
                successfulSummaryMatches.toArray(successfulSummaryMatchesArray);

                // write successful matches to database
                MatchHistoryService.persistSuccessfulSummaryLevelMatches(
                        successfulSummaryMatchesArray, true);

                // calculate summary match various within tolerance
                getVarianceService().setSummaryVarianceWithinTolerance(
                        successfulSummaryMatchesArray);

                ReceiptTrackingService.matchReceipt(successfulSummaryMatchesArray);
            }

            // if any detail matches are achieved, write to the database, and
            // calculate variance
            Match[] successfulDetailAndQuantitylMatchesArray = null;
            if (successfulDetailAndQuantityMatches.size() > 0) {
                successfulDetailAndQuantitylMatchesArray = new Match[successfulDetailAndQuantityMatches
                        .size()];
                successfulDetailAndQuantityMatches
                        .toArray(successfulDetailAndQuantitylMatchesArray);

                // write successful matches to database
                MatchHistoryService.persistSuccessfulDetailLevelMatches(
                        successfulDetailAndQuantitylMatchesArray, true);

                // detail match variance within tolerance are set inside line
                // level match
                // since the values need to set either cost or qty is successful

                ReceiptTrackingService.matchReceipt(successfulDetailAndQuantitylMatchesArray);
            }

            ReceiptMatchResults receiptMatchResults = new ReceiptMatchResults();
            receiptMatchResults.setDiscrepancies(discrepancies);
            receiptMatchResults.setSuccessfulSummaryMatches(successfulSummaryMatchesArray);

            return receiptMatchResults;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_perform_receipt_match", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    /**
     * Method lineLevelMatch.
     * 
     * This method attempts to match each line item on the invoice with the corresponding receipt
     * items for the po location.
     * 
     * @param poLocation
     * @return ArrayList
     * @throws ReIMException
     */
    public DetailMatchResults lineLevelMatch(POLocation poLocation) throws ReIMException {
        // This will hold the detail match results, both discrepancies and
        // matches
        DetailMatchResults results = null;

        // Get unmatched invoice for line level matching
        MerchandiseDocument invoice = getInvoiceForLineLevelMatch(poLocation);

        // if today is after the routing date, then perform line level matching
        // and route any resulting discrepancies
        if (isTodayPostRoutingDays(invoice, poLocation.getOrder().getSupplier()
                .getSupplierOptions().getQtyDiscDayBeforeRte())) {
            // Retrieve invoice lines from the database for this invoice
            invoiceDetailService.buildInvoiceLines(invoice);

            // if the unmatched invoice has no line level information available,
            // stop processing this invoice. This invoice will be cycled through
            // automatch until
            // lines are entered into the system or there is manual intervention
            Map invoiceLines = invoice.getDocDetail();

            if (invoiceLines != null && invoiceLines.size() > 0) {
                // Get unmatched receipts for line level matching
                Receipt[] receipts = getReceiptsForLineLevelMatch(poLocation);

                // Attempt to line level match the line items on the invoice
                results = lineLevelMatch(invoice, receipts, poLocation);

                // Determine whether the entire invoice should be put into
                // matched status
                ServiceFactory.getMatchStatusService().checkMatchedStatus(invoice);

                // Determine whether the all receipts should be put into matched
                // status
                if (receipts != null) {
                    ServiceFactory.getMatchStatusService().checkMatchedStatus(receipts, invoice);
                }

                // If the match is successful, calculate the receipt of goods
                // date for the invoice
                if (invoice.getStatus().equals(Document.MATCHED)) {
                    ServiceFactory.getTermsService().calculateReceiptOfGoodsDate(invoice, receipts);
                }

                // Set the detail matched indicator to indicate that line level
                // matching
                // has been performed for this invoice to avoid recycling. Once
                // an invoice has been
                // detail matched,
                // it is no longer processed by auto match.
                invoice.setDetailMatched(true);
            }
        }
        return results;
    }

    /**
     * This method iterates over invoices (discrepncies) and sets detail lines to cost match if no
     * cost discrepancy exists.
     * 
     * @param poLocations
     * @param costDiscrepancy
     * @param quantityDiscrepancy
     * @throws ReIMException
     */
    public void updateDetailCostMatch(List costDiscrepancies, List quantityDiscrepancies)
            throws ReIMException {
        try {
            if (quantityDiscrepancies != null && quantityDiscrepancies.size() > 0) {
                Set existingCostDiscrepancies = null;
                Set invoiceLinesToUpdate = new HashSet();
                String key = null;

                existingCostDiscrepancies = super.retrieveCostDiscrepanciesByKey(costDiscrepancies);
                // iterate over qty discrepancies
                // qty discrepancies drive process because no receipts
                // exist, hence if a qty discrepancy exists, then the invoice
                // is past the routing days.
                for (Iterator iter = quantityDiscrepancies.iterator(); iter.hasNext();) {
                    MerchandiseInvoiceQuantityDiscrepancy qtyDiscrepancy = (MerchandiseInvoiceQuantityDiscrepancy) iter
                            .next();
                    long docId = qtyDiscrepancy.getDiscrepantDocId();
                    String itemId = qtyDiscrepancy.getItemId();
                    key = docId + "+" + itemId;
                    // if the current invoice/item has a cost discrepancy, don't
                    // update cost
                    // matched.
                    if (existingCostDiscrepancies.contains(key)) {
                        continue;
                    }
                    // if current invoice/item was previously cost discrepant,
                    // don't update cost
                    // matched.
                    if (getCostDiscrepancyDao().readDiscrepancyByDocumentItem(docId, itemId) != null) {
                        continue;
                    }
                    invoiceLinesToUpdate.add(key);
                }
                // update all detail lines in collection.
                if (invoiceLinesToUpdate.size() > 0) {
                    getInvoiceDetailDao().updateLinesToCostMatched(invoiceLinesToUpdate);
                }
            }

        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_details_to_cost_matched", Severity.ERROR,
                    e, AutoMatchService.class);
        }
    }

    private void calculateLineLevelWithInToleranceValues(MerchandiseDocument invoice,
            Receipt receipt, Match match) throws ReIMException {
        DocumentItemInvoice invoiceLine = null;
        ReceiptItem[] receiptItems = null;
        String itemId = null;

        invoiceDetailService.buildInvoiceLines(invoice);

        Iterator k = invoice.getDocDetail().values().iterator();
        while (k.hasNext()) {
            invoiceLine = (DocumentItemInvoice) k.next();
            itemId = invoiceLine.getItem().getItemId();

            // Need to update the invoice lines to be matched
            invoiceLine.setStatus(Document.MATCHED);
            invoiceLine.setCostMatched(true);
            invoiceLine.setQtyMatched(true);

            // if receipts are passed in, construct a detail match object
            Match detailMatch = null;
            receiptItems = null;
            Receipt[] receipts = new Receipt[1];
            receipts[0] = receipt;
            // get receipt items for the item on the invoice line
            receiptItems = super.getReceiptItemsForItem(receipts, itemId);

            if (receiptItems != null && receiptItems.length > 0) {
                // if there are receipt lines for this item, build a detail
                // match object
                detailMatch = super.createDetailMatch(invoiceLine, receiptItems, invoice
                        .getPoLocation().getOrder());
                // Need to set the cost/qty matched variables to true;
                detailMatch.setCostMatchPerformed(true);
                detailMatch.setCostMatchSuccessful(true);
                detailMatch.setQtyMatchPerformed(true);
                detailMatch.setQtyMatchSuccessful(true);
            }

            if (detailMatch != null) {
                // possibly set cost/qty variance within tolerance
                // ServiceFactory.getVarianceResolutionService().setDetailVarianceWithinTolerance(detailMatch);
                getVarianceService().setDetailVarianceWithinTolerance(detailMatch);
            }
        }
    }

    /**
     * Method poLocationLevelMatch.
     * 
     * This method attempts a po location level summary match for a a given po location. It examines
     * all candidate invoices and receipts associated with the po location. A match is considered
     * successful if the total extended cost and optionally, total quantity of the invoices and the
     * receipts match within tolerance. If the match is successful, set all invoices and receipts
     * associated with the po location to "matched" status; otherwise, set them to "unresolved
     * match" status.
     * 
     * The po location level match object is returned.
     * 
     * @param poLocation
     * @return Match
     * @throws ReIMException
     */
    public Match poLocationLevelMatch(POLocation poLocation) throws ReIMException {
        try {
            Order order = poLocation.getOrder();

            // create new Match object
            Match match = new Match(order.getSupplier());

            // create new Invoice and Receipt POLocationLevel summary objects
            // and set them in the
            // match object
            match.setInvoiceGroup(new InvoiceSummaryGroupLevel(
                    prePopulateMerchandiseDocuments(poLocation.getInvoices())));
            match.setReceiptGroup(new ReceiptSummaryGroupLevel(poLocation.getReceipts()));

            // Po location level matching is summary level matching because it
            // is across invoices
            // and receipts.
            match.setSummaryOrLineMatch(Tolerance.SUMMARY_LEVEL);

            // Determine whether this match is for cost only or cost and
            // quantity based on the
            // order's supplier option

            match.setQtyMatchRequired(order.getSupplier().getSupplierOptions()
                    .getMatchTotalQuantity());
            if (!match.isQtyMatchRequired()) {
                match.setQtyMatchPerformed(true);
                match.setQtyMatchSuccessful(true);
            }

            // set the primary currency
            match.setPrimaryCurrency(getPrimaryCurrency());

            // set invoice currency and exchange rate
            match.setInvoiceCurrency(order.getOrderCurrency());
            match.setExchangeRate(order.getOrderExchangeRate());

            // call the match algorithm
            getMatchService().match(match);

            // set the status for all invoices and receipts in po location if
            // matched
            if (match.isMatchSuccessful()) {
                match.getInvoiceGroup().updateInvoiceMatchStatus(Document.MATCHED);
                match.getReceiptGroup().updateInvoiceMatchStatus(Receipt.MATCHED);
                ServiceFactory.getTermsService().calculateReceiptOfGoodsDate(
                        poLocation.getInvoices(), poLocation.getReceipts());
            } else {
                match.getInvoiceGroup().updateInvoiceMatchStatus(Document.UNRESOLVED_MATCH);
                match.getReceiptGroup().updateInvoiceMatchStatus(Receipt.UNMATCHED);
            }

            // return the match object
            return match;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.cannot_perform_PO_Location_Level_Match", Severity.WARN, e,
                    AutoMatchService.class);
            throw exception;
        }
    }

    /**
     * Method summaryOneToOneMatch.
     * 
     * This method attempts to match one invoice to one receipt at the summary level. It will only
     * come to this point if the PO location level summary match is unsuccessful.
     * 
     * If a match is found (i.e. total extended cost and optionally, total quantity for the invoice
     * and the receipt match within tolerance), set the invoice and the receipt to "matched" status.
     * 
     * The invoice and the receipt will be set into "matched" status only if a one-to-one match is
     * found. If one invoice can be matched to more than one receipt, or if one receipt can be
     * matched to more than one invoice, the invoice and receipt status will remain in "unresolved
     * match" status, and a later process will put them into multi-unresolved status.
     * 
     * @param poLocationLevelMatch
     * @throws ReIMException
     */
    public Collection summaryOneToOneMatch(POLocation poLocation) throws ReIMException {
        try {
            // this will hold all successful matches keyed by docId
            HashMap successfulMatches = new HashMap();

            // get invoices from the poLocation level match
            MerchandiseDocument[] invoices = poLocation.getInvoices();

            // get receipts from the poLocation level match
            Receipt[] receipts = poLocation.getReceipts();

            // This collection will store the already matched receipts for to
            // ensure that one receipt matches to only one invoice.
            HashMap matchedReceipts = new HashMap();

            // this hashmap stores the invoice last matched to the receipt
            // it's keyed by receipt
            HashMap lastMatchedInvoiceForReceipt = new HashMap();

            ReIMSystemOptions options = ReIMSystemOptions.getInstance();

            Order order = poLocation.getOrder();

            // loop through invoices
            MerchandiseDocument invoice = null;
            Receipt previousMatchedReceipt = null;
            InvoiceLevel invoiceLevel = null;
            Receipt receipt = null;
            Match oneToOneMatch = null;
            int invoicesLength = invoices.length;
            for (int i = 0; i < invoicesLength; i++) {
                invoice = invoices[i];

                // intitialize match found flag to false
                boolean matchFound = false;

                previousMatchedReceipt = null;

                // Create invoice summary for match
                invoiceLevel = new InvoiceLevel();
                invoiceLevel.setInvoice(invoice);

                // loop through the receipts for the po location and attempt to
                // match
                // each receipt with the current invoice.
                int receiptsLength = receipts.length;
                for (int j = 0; j < receiptsLength; j++) {
                    receipt = receipts[j];

                    // create match object with invoice level and receipt level
                    // summaries
                    oneToOneMatch = super.buildOneToOneMatch(order, invoiceLevel, receipt);

                    // call match algorithm
                    getMatchService().match(oneToOneMatch);

                    // Only successful matches require a status change
                    // It's assumed that all invoices and receipts enter this
                    // method in unresolved
                    // status
                    // because they are set to unresolved in po location level
                    // matching
                    if (oneToOneMatch.isMatchSuccessful()) {
                        // if the match was successful within tolerance, tax is
                        // enabled, details
                        // exist, and oracle financials is on.
                        // determine the within tolerance values for the items.
                        if (!oneToOneMatch.isExactMatch()
                                && !oneToOneMatch.isTaxValildationPerformed()
                                && options.isProcessTaxes() && options.isFinancialAp()) {
                            calculateLineLevelWithInToleranceValues(invoice, receipt, oneToOneMatch);
                        }

                        // if a previous match has been found for this invoice,
                        // set the invoice and receipt to unresolved match. The
                        // invoice can
                        // match to only one receipt.
                        if (matchFound) {
                            oneToOneMatch.getInvoiceGroup().updateInvoiceMatchStatus(
                                    Document.UNRESOLVED_MATCH);
                            oneToOneMatch.getReceiptGroup().updateInvoiceMatchStatus(
                                    Receipt.UNMATCHED);
                            invoice.setReceiptOfGoodsDate(null);

                            // store this receipt in the matched receipts
                            // collection so that
                            // it is not reused to match with another.
                            matchedReceipts.put(receipt.getReceiptId(), receipt);

                            // set the previously matched receipt's status to
                            // unresolved match
                            previousMatchedReceipt.setInvoiceMatchStatus(Receipt.UNMATCHED);

                            // remove the previous successful match from the
                            // collection
                            successfulMatches.remove(new Long(invoice.getDocId()));
                        } else // it has not been previously found, this a new
                        // match for this
                        // invoice
                        {
                            // set matchfound flag to indicate that a match has
                            // been found for this
                            // invoice
                            matchFound = true;

                            // if the receipt is previously matched to a
                            // different invoice,
                            // set the invoice and receipt to unresolved match.
                            if (matchedReceipts.containsKey(receipt.getReceiptId())) {
                                oneToOneMatch.getInvoiceGroup().updateInvoiceMatchStatus(
                                        Document.UNRESOLVED_MATCH);
                                oneToOneMatch.getReceiptGroup().updateInvoiceMatchStatus(
                                        Receipt.UNMATCHED);

                                // Because this receipt matches to more than one
                                // invoice,
                                // un-match the last invoice that this receipt
                                // was matched to
                                MerchandiseDocument lastMatchedInvoice = (MerchandiseDocument) lastMatchedInvoiceForReceipt
                                        .get(receipt);

                                lastMatchedInvoice.setStatus(Document.UNRESOLVED_MATCH);
                                lastMatchedInvoice.setReceiptOfGoodsDate(null);

                                // remove the last matched invoice from the
                                // successful match
                                // collection
                                successfulMatches.remove(new Long(lastMatchedInvoice.getDocId()));
                            } else {
                                // Otherwise, a valid one-to-one match has been
                                // found
                                // Store the successfully matched receipt to
                                // ensure that it does
                                // not also match to another invoice
                                matchedReceipts.put(receipt.getReceiptId(), receipt);
                                oneToOneMatch.getInvoiceGroup().updateInvoiceMatchStatus(
                                        Document.MATCHED);
                                oneToOneMatch.getReceiptGroup().updateInvoiceMatchStatus(
                                        Receipt.MATCHED);

                                // add the successful match to the collection
                                successfulMatches.put(new Long(invoice.getDocId()), oneToOneMatch);
                                invoice.setReceiptOfGoodsDate(receipt.getReceiptDate());
                            }
                        }

                        // Store the invoice that the receipt matches to in
                        // order to
                        // un-match that invoice if the receipt matches to more
                        // than one invoice.
                        lastMatchedInvoiceForReceipt.put(receipt, invoice);

                        // Store the receipt that the invoice matches to in
                        // order to
                        // un-match that receipt if the invoice matches to more
                        // than one receipt.
                        previousMatchedReceipt = receipt;
                    } else if (oneToOneMatch.isTaxValildationPerformed()
                            && !oneToOneMatch.isTaxValildationSuccessful()) {
                        oneToOneMatch.getInvoiceGroup().updateInvoiceMatchStatus(
                                Document.TAX_DISCREPANCY);
                        oneToOneMatch.getReceiptGroup().updateInvoiceMatchStatus(Receipt.UNMATCHED);
                    }
                }
            }
            return successfulMatches.values();
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_perform_invoice_level_matching", Severity.WARN,
                    e, AutoMatchService.class);
        }
    }

    private MerchandiseDocument[] prePopulateMerchandiseDocuments(
            MerchandiseDocument[] merchandiseDocuments) throws ReIMException {
        // Pre-populate detail items for InvoiceSummaryGroupLevel
        try {
            for (int i = 0; i < merchandiseDocuments.length; i++) {
                merchandiseDocuments[i].setItems(Arrays.asList(getInvoiceDetailService()
                        .getInvoiceItemsByInvoiceId(merchandiseDocuments[i].getDocId())));
            }
            return merchandiseDocuments;
        } catch (ReIMException e) {
            throw e;
        }
    }

    public void autoMatch(String threadBy, String threadByData) throws ReIMException {
        POLocation[] allPOLocationsForMatching = getPOLocationsForAutoMatch(threadBy, threadByData);

        if (!ArrayUtils.isEmpty(allPOLocationsForMatching)) {
            try {
                if (isProcessLocks()) {
                    autoMatchWithLocking(allPOLocationsForMatching);
                } else {
                    autoMatch(allPOLocationsForMatching);
                }
            } catch (ReIMException e) {
                throw e;
            }
        }
    }

    public String[] getThreadData(String threadBy) throws ReIMException {
        String[] threadData = null;

        AAutoMatchThreadedBean threadByBean = (AAutoMatchThreadedBean) ReIMAutoMatchThreadBeanFactory
                .getBean(threadBy);

        threadData = threadByBean.getThreadData();

        return threadData;
    }

    /**
     * Method costMatch.
     * 
     * Performs cost matching for the invoices for the passed in po location. It returns a list of
     * cost discrepancies for any invoice lines that do not match.
     * 
     * @param poLocation
     * @return ArrayList
     * @throws ReIMException
     */
    private ArrayList costMatch(POLocation poLocation) throws ReIMException {

        try {

            // TransactionManagerFactory.getInstance().start();

            // will hold all cost discrepancies for the po location
            ArrayList costDiscrepancies = new ArrayList();

            // get supplier options and set it on order supplier
            // for cost matching, the ap reviewer is needed to route any
            // discrepancies
            populateSupplierOptions(poLocation);

            // get the po item locations for the po location
            // user DAO..
            // AOrderLocationBean bean = (AOrderLocationBean) ReIMBeanFactory
            // .getBean(ReIMBeanFactory.AOrderLocationBean);
            // HashMap poItemLocations =
            // bean.getPOItemLocationsByOrderLocation(poLocation.getOrder()

            HashMap poItemLocations = getOrderLocationDao().getPOItemLocationsByOrderLocation(
                    poLocation.getOrder().getOrderNo(), poLocation.getLocation());

            poLocation.setPoItemLocations(poItemLocations);

            // loop through invoices for cost matching
            MerchandiseDocument[] invoices = poLocation.getInvoices();
            MerchandiseDocument invoice = null;
            int invoicesLength = invoices.length;
            for (int i = 0; i < invoicesLength; i++) {
                invoice = invoices[i];

                // Only cost match invoices that have not been previously cost
                // matched
                // An invoice will only be cost matched once and will not be
                // recycled through cost
                // matching.
                if (!invoice.isCostPreMatched()) {
                    // perform cost matching for each invoice
                    costDiscrepancies.addAll(costMatch(poLocation, invoice));
                }
            }

            return costDiscrepancies;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_price_match", Severity.ERROR, e,
                    AutoMatchService.class);
        } /*
         * finally { TransactionManagerFactory.getInstance().end(); }
         */

    }

    // inner class
    public class ReceiptMatchResults {
        private ArrayList discrepancies;

        private Match[] successfulSummaryMatches;

        public ArrayList getDiscrepancies() {
            return discrepancies;
        }

        public Match[] getSuccessfulSummaryMatches() {
            return successfulSummaryMatches;
        }

        public void setDiscrepancies(ArrayList discrepancies) {
            this.discrepancies = discrepancies;
        }

        public void setSuccessfulSummaryMatches(Match[] successfulSummaryMatches) {
            this.successfulSummaryMatches = successfulSummaryMatches;
        }
    }

    /**
     * Method costMatch. Moved from the old <com.retek...>AutoMatchService Batch. Will probably need
     * refactoring
     * 
     * Performs cost matching for the passed in invoice line. It returns a cost discrepancy if the
     * match is unsuccessful.
     * 
     * @param poLocation
     * @param poItemLocation
     * @param invoiceLine
     * @param invoice
     * @return CostDiscrepancy
     * @throws ReIMException
     */
    /* protected */public MerchandiseInvoiceCostDiscrepancy costMatch(POLocation poLocation,
            POItemLocation poItemLocation, DocumentItemInvoice invoiceLine,
            MerchandiseDocument invoice) throws ReIMException {
        try {
            MerchandiseInvoiceCostDiscrepancy costDiscrepancy = null;

            // Create the match object that will be used to call the match
            // algorithm for this
            // cost match
            Match costMatch = createCostMatch(poLocation, poItemLocation, invoiceLine);

            // call the match algorithm
            getMatchService().match(costMatch);

            if (costMatch.isCostMatchSuccessful()) {
                // set cost variance within tolerance if cost match succeeds
                getVarianceService().setDetailVarianceWithinTolerance(costMatch);
            } else if (!costDiscExistsForTheDocIdAndItem(invoiceLine)) {
                // if the cost match fails, generate a cost discrepancy.
                costDiscrepancy = createCostDiscrepancy(poLocation, poItemLocation.getUnitCost(),
                        invoice, invoiceLine);
            }

            return costDiscrepancy;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_price_match", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    /**
     * Method lineLevelMatch. Moved from the old <com.retek...>AutoMatchService. Will probably need
     * refactoring
     * 
     * This method attempts to match all the lines on the passed in invoice with a corresponding
     * line on the passed in receipt.
     * 
     * @param invoice
     * @param receipt
     * @param poLocation
     * @return ArrayList
     * @throws ReIMException
     */
    /* protected */public DetailMatchResults lineLevelMatch(MerchandiseDocument invoice,
            Receipt[] receipts, POLocation poLocation) throws ReIMException {
        try {
            // This list will contain all the cost and qty discrepancies for the
            // invoice
            ArrayList discrepancies = new ArrayList();

            // This list will hold all successful detail matches
            ArrayList successfulDetailMatches = new ArrayList();

            // This will hod all quantity matches where cost is discrepant
            ArrayList quantityMatches = new ArrayList();

            // loop through items in the invoice if invoice lines exist.
            // Otherwise, if lines do not exist, the invoice remains in
            // unresolved status
            DocumentItemInvoice invoiceLine = null;
            ReceiptItem[] receiptItems = null;
            MerchandiseInvoiceCostDiscrepancy costDiscrepancy = null;
            MerchandiseInvoiceQuantityDiscrepancy qtyDiscrepancy = null;
            String itemId = null;
            Order order = poLocation.getOrder();

            AOrderLocationBean bean = (AOrderLocationBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AOrderLocationBean);

            Iterator k = invoice.getDocDetail().values().iterator();
            while (k.hasNext()) {
                invoiceLine = (DocumentItemInvoice) k.next();
                itemId = invoiceLine.getItem().getItemId();
                if(invoiceLine.getStatus().equals(DocumentItemInvoice.MATCHED)){
                	continue;
                }
                // if receipts are passed in, construct a detail match object
                Match detailMatch = null;
                receiptItems = null;
                //BRN V 1.5 Begin
                qtyDiscrepancy = null; 
                costDiscrepancy = null;                
                //BRN V 1.5 End
                if (receipts != null) {
                    // get receipt items for the item on the invoice line
                    receiptItems = getReceiptItemsForItem(receipts, itemId);

                    if (receiptItems != null && receiptItems.length > 0) {
                        // if there are receipt lines for this item, build a
                        // detail match object
                        detailMatch = createDetailMatch(invoiceLine, receiptItems, order);
                    }
                }

                // If a detail match object has been successfully constructed,
                // attempt a match
                if (detailMatch != null) {
                    // call the match algorithm
                    getMatchService().match(detailMatch);

                    // possibly set cost/qty variance within tolerance
                    getVarianceService().setDetailVarianceWithinTolerance(detailMatch);

                    // set the cost and qty matching result to invoice line
                    invoiceLine.setCostMatched(detailMatch.isCostMatchSuccessful());
                    invoiceLine.setQtyMatched(detailMatch.isQtyMatchSuccessful());

                    if (detailMatch.isMatchSuccessful()) {
                        detailMatch.getInvoiceGroup().updateInvoiceMatchStatus(
                                DocumentItemInvoice.MATCHED);
                        detailMatch.getReceiptGroup().updateInvoiceMatchStatus(ReceiptItem.MATCHED);
                        successfulDetailMatches.add(detailMatch);
                    } else {
                        if (!detailMatch.isCostMatchSuccessful()
                                && !costDiscExistsForTheDocIdAndItem(invoiceLine)) {
                            // create cost discrepancy
                            // The unit cost for all receipt items for the same
                            // item should be the
                            // same.
                            // Therefore, the unit cost of the first receipt
                            // item will be sufficient
                            // to create the discrepancy.
                            costDiscrepancy = createCostDiscrepancy(poLocation, receiptItems[0]
                                    .getUnitCost(), invoice, invoiceLine);

                            // add it to discrepancies array list
                            discrepancies.add(costDiscrepancy);
                        }

                        if (!detailMatch.isQtyMatchSuccessful()
                                && !qtyDiscExistsForTheDocIdAndItem(invoiceLine)) {
                            // create qty discrepancy here
                            qtyDiscrepancy = createQtyDiscrepancy(poLocation, receiptItems,
                                    invoice, invoiceLine);

                            // add it to discrepancies array list
                            discrepancies.add(qtyDiscrepancy);
                        } else {
                            // Add this quantity match to the list of quantity
                            // matches
                            quantityMatches.add(detailMatch);
                        }
                    }
                } else {
                	// if the line does not exist on the receipt or there is no
                    // unmatched receipt, automatically cost match and create qty discrepancy
                    // get po item location for the item to perform cost
                    // matching 
                    POItemLocation poItemLocation = bean.getPOItemLocationForAutoMatch(order
                            .getOrderNo(), poLocation.getLocation(), itemId);

                    boolean costDiscExists = false;
                    if (poItemLocation != null) {
                        costDiscExists = costDiscExistsForTheDocIdAndItem(invoiceLine);
                        if (!costDiscExists) {
                            // attempt to cost match the invoice line
                            costDiscrepancy = costMatch(poLocation, poItemLocation, invoiceLine,
                                    invoice);
                        }
                        if (costDiscrepancy != null) {
                        	//BRN V1.4 added line
                        	costDiscExists = true;
                            discrepancies.add(costDiscrepancy);
                        } 
                    }                    
                   // BRN V1.4 begin
                    else {
                    	costDiscExists = true;
                    } 
                    // BRN V1.4 end
                    
                    if (!costDiscExists) {
                    	invoiceLine.setCostMatched(true);
                    }
                    
                    if (!qtyDiscExistsForTheDocIdAndItem(invoiceLine)) {
                        // Qty discrepancies are always created because no
                        // receipt or receipt line exists.
                        qtyDiscrepancy = createQtyDiscrepancy(poLocation, receipts, invoice,
                                invoiceLine);
                    }
                    if (qtyDiscrepancy != null) {
                        discrepancies.add(qtyDiscrepancy);
                    }
                }
            }

            // Create results
            DetailMatchResults detailMatchResults = new DetailMatchResults();
            detailMatchResults.setDiscrepancies(discrepancies);
            detailMatchResults.setSuccessfulMatches(successfulDetailMatches);
            detailMatchResults.setQuantityMatches(quantityMatches);

            return detailMatchResults;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_perform_line_level_match", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    /**
     * Method createQtyDiscrepancy.
     * 
     * If only receipts are passed, it is assumed that there are no corresponding items on those
     * receipts for the invoice lines passed. Create qty discrepancy with received qty of 0.
     * 
     * If no receipts are passed, create qty discrepancy at header level only.
     * 
     * @param poLocation
     * @param receipts
     * @param invoice
     * @param invoiceLine
     * @return QuantityDiscrepancy
     * @throws ReIMException
     */
    private MerchandiseInvoiceQuantityDiscrepancy createQtyDiscrepancy(POLocation poLocation,
            Receipt[] receipts, MerchandiseDocument invoice, DocumentItemInvoice invoiceLine)
            throws ReIMException {
        try {
            MerchandiseInvoiceQuantityDiscrepancy qtyDiscrepancy = createQtyDiscrepancy(poLocation,
                    invoice, invoiceLine);

            // With some receipts, set quantities received
            if (receipts != null && receipts.length > 0) {
                List<DiscrepancyDocReference> receiptRefs = new ArrayList<DiscrepancyDocReference>();

                for (Receipt receipt : receipts) {
                    DiscrepancyDocReference receiptRef = new DiscrepancyDocReference(qtyDiscrepancy
                            .getDiscrepancyId(), Long.valueOf(receipt.getReceiptId()));
                    receiptRefs.add(receiptRef);
                }
                qtyDiscrepancy.setSupportingDocsRefs(receiptRefs);
            } else {
                // if there are no receipts for this invoice line, set the
                // received quantities to null
                qtyDiscrepancy.setSupportingDocsRefs(null);
            }

            return qtyDiscrepancy;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_qty_discrepancy", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    private boolean qtyDiscExistsForTheDocIdAndItem(DocumentItemInvoice invoiceLine)
            throws ReIMException {
        boolean discrepancyExists = false;
        long qtyDiscId = ServiceFactory.getDiscrepancyService().getQtyDiscrepancyIdForItemDocId(
                invoiceLine.getItemId(), Long.toString(invoiceLine.getDocId()));
        if (qtyDiscId != -1) {
            discrepancyExists = true;
        }
        return discrepancyExists;
    }

    /**
     * Method createCostPreMatch.
     * 
     * This method creates a match object specifically for cost matching an invoice line's unit cost
     * with a po item location's unit cost
     * 
     * @param poLocation
     * @param poItemLocation
     * @param invoiceLine
     * @return Match
     * @throws ReIMException
     */
    private Match createCostMatch(POLocation poLocation, POItemLocation poItemLocation,
            DocumentItemInvoice invoiceLine) throws ReIMException {
        try {
            Order order = poLocation.getOrder();

            // create new cost match object
            Match costMatch = new Match();
            costMatch.setSupplier(order.getSupplier());
            // cost matching is always at line level
            costMatch.setSummaryOrLineMatch(Tolerance.LINE_LEVEL);
            // cost matching is only for unit cost, qty is never required
            costMatch.setQtyMatchRequired(false);
            // indicate whether this line has already been cost matched
            costMatch.setCostMatchSuccessful(invoiceLine.isCostMatched());

            costMatch.setPrimaryCurrency(getPrimaryCurrency());
            costMatch.setInvoiceCurrency(order.getOrderCurrency());
            costMatch.setExchangeRate(order.getOrderExchangeRate());

            // create invoice summary for the line level match
            InvoiceLineLevel invoiceLineLevel = new InvoiceLineLevel();
            invoiceLineLevel.setInvoiceItem(invoiceLine);

            // create receipt summary - for cost match, receipts are not present
            // and the cost is
            // retrieved from the po item location, which is the same cost as
            // the receipt item cost
            OrderLineLevel orderLineLevel = new OrderLineLevel();
            orderLineLevel.setPoItemLocation(poItemLocation);

            // set summaries in the match object
            costMatch.setInvoiceGroup(invoiceLineLevel);
            costMatch.setReceiptGroup(orderLineLevel);

            return costMatch;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_price_match", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    private boolean costDiscExistsForTheDocIdAndItem(DocumentItemInvoice invoiceLine)
            throws ReIMException {
        boolean discrepancyExists = false;
        ArrayList costDiscs = (ArrayList) ServiceFactory.getDiscrepancyService()
                .getCostDiscrepanciesForDocId(Long.toString(invoiceLine.getDocId()));
        if (costDiscs != null) {
            for (int ii = 0; ii < costDiscs.size(); ii++) {
                DiscrepancyVo row = (DiscrepancyVo) costDiscs.get(ii);
                if (row.getItemId().equals(invoiceLine.getItemId())) {
                    discrepancyExists = true;
                    break;
                }
            }
        }
        return discrepancyExists;
    }

    /**
     * Method createCostDiscrepancy.
     * 
     * This method creates a cost discrepancy object for a failed match
     * 
     * @param poLocation
     * @param orderUnitCost
     * @param invoice
     * @param invoiceLine
     * @return CostDiscrepancy
     * @throws ReIMException
     */
    private MerchandiseInvoiceCostDiscrepancy createCostDiscrepancy(POLocation poLocation,
            double orderUnitCost, MerchandiseDocument invoice, DocumentItemInvoice invoiceLine)
            throws ReIMException {
        try {
            Order order = poLocation.getOrder();
            Supplier supplier = order.getSupplier();

            MerchandiseInvoiceCostDiscrepancy costDiscrepancy = new MerchandiseInvoiceCostDiscrepancy();

            costDiscrepancy.setDiscrepantDocControlTotalCost(invoice.getTotalCost().doubleValue());
            costDiscrepancy.setDiscrepantDocCurrencyCode(order.getOrderCurrency());
            costDiscrepancy.setDiscrepantDocId(invoice.getDocId());
            costDiscrepancy.setDiscrepantDocUnitCost(invoiceLine.getUnitCost());
            costDiscrepancy.setDiscrepantDocDueDate(invoice.getDueDate());
            costDiscrepancy.setItem(invoiceLine.getItem());
            costDiscrepancy.setLocation(poLocation.getLocation());
            costDiscrepancy.setOrderNo(Integer.parseInt(order.getOrderNo()));
            costDiscrepancy.setSupportingDocUnitCost(orderUnitCost);
            costDiscrepancy.setSupplierId(Long.parseLong(supplier.getVendorId()));
            costDiscrepancy.setApReviewer(supplier.getSupplierOptions().getApReviewer());
            costDiscrepancy.setTermsDscntPct(invoice.getTermsDscntPct().doubleValue());

            // never have debit memo reason code for matching generated
            // discrepancy
            costDiscrepancy.setDebitMemoReasonCode(null);

            // always merchandise invoice for matching generated discrepancy
            costDiscrepancy.setDiscrepantDocType(DocumentType.MERCHANDISE_INVOICE);

            return costDiscrepancy;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_cost_discrepancy", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    /**
     * Method createQtyDiscrepancy.
     * 
     * This method creates a quantity discrepancy object for a failed match.
     * 
     * @param poLocation
     * @param receiptId
     * @param qtyReceived
     * @param invoice
     * @param invoiceLine
     * @return QuantityDiscrepancy
     * @throws ReIMException
     */
    private MerchandiseInvoiceQuantityDiscrepancy createQtyDiscrepancy(POLocation poLocation,
            ReceiptItem[] receiptItems, MerchandiseDocument invoice, DocumentItemInvoice invoiceLine)
            throws ReIMException {
        try {
            MerchandiseInvoiceQuantityDiscrepancy qtyDiscrepancy = createQtyDiscrepancy(poLocation,
                    invoice, invoiceLine);
            List<DiscrepancyDocReference> receiptRefs = new ArrayList<DiscrepancyDocReference>();

            for (ReceiptItem receiptItem : receiptItems) {
                DiscrepancyDocReference receiptRef = new DiscrepancyDocReference(qtyDiscrepancy
                        .getDiscrepancyId(), Long.valueOf(receiptItem.getReceiptId()));
                receiptRefs.add(receiptRef);
            }

            qtyDiscrepancy.setSupportingDocsRefs(receiptRefs);

            return qtyDiscrepancy;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_create_qty_discrepancy", Severity.ERROR, e,
                    AutoMatchService.class);
        }
    }

    public oracle.retail.reim.services.matching.IMatchStatusService getMatchStatusService() {
        return matchStatusService;
    }

    @Required
    @Autowired
    public void setMatchStatusService(
            oracle.retail.reim.services.matching.IMatchStatusService matchStatusService) {
        this.matchStatusService = matchStatusService;
    }

    public IInvoiceDetailService getInvoiceDetailService() {
        return invoiceDetailService;
    }

    @Required
    @Autowired
    public void setInvoiceDetailService(IInvoiceDetailService invoiceDetailService) {
        this.invoiceDetailService = invoiceDetailService;
    }

    public IInvoiceDetailDao getInvoiceDetailDao() {
        return invoiceDetailDao;
    }

    @Required
    @Autowired
    public void setDocumentItemInvoiceDao(IInvoiceDetailDao invoiceDetailDao) {
        this.invoiceDetailDao = invoiceDetailDao;
    }

    private IVarianceService getVarianceService() {
        return varianceService;
    }

    @Required
    @Autowired
    public void setVarianceService(IVarianceService varianceService) {
        this.varianceService = varianceService;
    }

    public IMatchService getMatchService() {
        return matchService;
    }

    @Required
    @Autowired
    public void setMatchService(IMatchService matchService) {
        this.matchService = matchService;
    }

    @Required
    @Autowired
    public void setOrderLocationDao(IOrderLocationDao orderLocationDao) {
        this.orderLocationDao = orderLocationDao;
    }

    public IOrderLocationDao getOrderLocationDao() {

        return this.orderLocationDao;

    }

    @Required
    @Autowired
    public void setCostDiscrepancyDao(ICostDiscrepancyDao costDiscrepancyDao) {
        this.costDiscrepancyDao = costDiscrepancyDao;
    }

    public ICostDiscrepancyDao getCostDiscrepancyDao() {

        return this.costDiscrepancyDao;

    }

}
