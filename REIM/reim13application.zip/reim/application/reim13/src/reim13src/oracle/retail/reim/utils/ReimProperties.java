package oracle.retail.reim.utils;

import com.retek.merch.utils.Utility;

/**
 * 
 * 
 * @author Oracle Retail
 * @author Jonathan Cone
 */
public class ReimProperties {

    public static final Integer DOCUMENT_SEARCH_RECORDS_MAX = Integer.parseInt(Utility
            .getApplicationValue("document.search.records.maximum"));

    public static final Integer DOCUMENT_QUANTITY_DECIMALS_ALLOWED = Integer.parseInt(Utility
            .getApplicationValue("document.quantity.decimals.allowed"));

    public static final String DOCUMENT_BATCH_DATE_FORMAT = Utility
            .getApplicationValue("document.batch.date.format");

    public static final Integer DATE_CACHE_POLL_INTERVAL = Integer.parseInt(Utility
            .getApplicationValue("date.cache.poll.interval"));

    public static final Boolean DOCUMENT_HEADER_QUANTITY_REQUIRED = Boolean.valueOf(Utility
            .getApplicationValue("document.header.quantity.required"));

    public static final String DOCUMENT_NUMBER_VALIDATION_REGEXPR = Utility
            .getApplicationValue("document.number.validatation.regexpr");

    public static final Boolean DOCUMENT_NUMBER_ALLOW_LEADING_ZERO = Boolean.valueOf(Utility
            .getApplicationValue("document.number.allow.leading.zero"));

    public static final Integer DOCUMENT_PURGE_DEALS_DAYS = Integer.parseInt(Utility
            .getApplicationValue("document.purge.deals.days"));
    
    public static final String ALWAYS_SHOW_SUPPLIER_SITE = Utility
    .getApplicationValue("always.show.suppliersite");
    
    // BRN SplitReceipt Fix - reason code from Detail Matching screen 
    public static final String SPLIT_RECEIPT_REASON_CODE = Utility
    	    .getApplicationValue("split_receipt_reason_code");

    public static final String SESSION_KEY = "reim_session";
    public static final String USER_KEY = "user.key";

}
