package oracle.retail.reim.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ReimClassPathXmlApplicationContext extends ClassPathXmlApplicationContext {

	public ReimClassPathXmlApplicationContext(String[] configLocations)
			throws BeansException {
		super(configLocations);
	}
	
	protected void postProcessBeanFactory(ConfigurableListableBeanFactory configurablelistablebeanfactory){
		((AbstractAutowireCapableBeanFactory) configurablelistablebeanfactory).setAllowRawInjectionDespiteWrapping(true);
    }

}
