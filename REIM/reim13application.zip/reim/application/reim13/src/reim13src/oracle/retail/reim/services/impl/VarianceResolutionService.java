package oracle.retail.reim.services.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.data.dao.IDocDetailReasonCodesDao;
import oracle.retail.reim.services.IDealService;
import oracle.retail.reim.services.IDocumentService;
import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.services.IVarianceResolutionService;
import oracle.retail.reim.services.IVarianceService;
import oracle.retail.reim.services.matching.ICreditNoteDetailMatchService;
import oracle.retail.reim.services.matching.IMatchService;
import oracle.retail.reim.services.matching.IMatchStatusService;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.ReimProperties;
import oracle.retail.reim.utils.Severity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retek.merch.utils.Money;
import com.retek.merch.utils.Quantity;
import com.retek.reim.business.Comment;
import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ResolutionCreditNote;
import com.retek.reim.business.ResolutionDisputedCreditMemo;
import com.retek.reim.business.ResolutionMerchandiseInvoice;
import com.retek.reim.business.Tolerance;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.DocumentItemReasonCode;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.document.ResolutionDocument;
import com.retek.reim.business.match.InvoiceDetailSummaryLevel;
import com.retek.reim.business.match.InvoiceDiscrepancyLevel;
import com.retek.reim.business.match.InvoiceLineLevel;
import com.retek.reim.business.match.Match;
import com.retek.reim.business.match.ReceiptDetailSummaryLevel;
import com.retek.reim.business.match.ReceiptDiscrepancyLevel;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.IImCostDiscrepancyAccessExt;
import com.retek.reim.db.IImDocHeadAccessExt;
import com.retek.reim.db.IImInvoiceDetailAccessExt;
import com.retek.reim.db.IImQtyDiscrepancyAccessExt;
import com.retek.reim.db.IImReceiverCostAdjustAccess;
import com.retek.reim.db.IImReceiverUnitAdjustAccess;
import com.retek.reim.db.IImResolutionActionAccessExt;
import com.retek.reim.db.IImReversalResolutionActionAccessExt;
import com.retek.reim.db.ImCostDiscrepancyRow;
import com.retek.reim.db.ImDocHeadAccess;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.db.ImInvoiceDetailRow;
import com.retek.reim.db.ImPartiallyMatchedReceiptsAccessExt;
import com.retek.reim.db.ImPartiallyMatchedReceiptsRow;
import com.retek.reim.db.ImReceiverCostAdjustRow;
import com.retek.reim.db.ImReceiverUnitAdjustRow;
import com.retek.reim.db.ImResolutionActionRow;
import com.retek.reim.db.ImReversalResolutionActionRow;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.foundation.AOrderLocationBean;
import com.retek.reim.foundation.AShipSkuBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.DisputedCreditMemoResolutionService;
import com.retek.reim.services.ReceiptService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.matching.MatchHistoryService;
import com.retek.reim.ui.discrepancyResolution.VarianceResolution;

/**
 * BRN OLR 135775 RCA not updating the ORDLOC and SHIPSKU correctly.
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 * 1.4		22-Mar-2013	BNaik		IMS135775:  ReIM: RCA not updating the ORDLOC and SHIPSKU correctly
 * 										Move the call to Auto Resolve to the trigger and remove from the Java code when RCA is performed.
 * 										Also, if the quantity resolution is performed without a receipt, the cost resolution is not required.
 * 										The item is set to matched without having to resolve if there is any cost variance too on the item.
 * 	1.5		20-Jun-2013	BNaik		Record to be inserted in Im_partially_matched_receipts table for quantity resolution.
 * 	1.6		09-Jul-2013	BNaik		When there is both a cost and quantity discrepancy 
 *                                                      if you do the quantity discrepancy first it takes on the invoice cost and disappears from the screen.  
 *                                                      Users are trained to do cost discrepancies first.  
 *                                                      Since this is the case we should leave this as is since it isn't causing any issues in JDE.
 */
 
@Service
public class VarianceResolutionService extends com.retek.reim.services.VarianceResolutionService
        implements IVarianceResolutionService {

	private IMatchStatusService matchStatusService;
	private ICreditNoteDetailMatchService creditNoteDetailMatchService;
    private IDocDetailReasonCodesDao docDetailReasonCodesDao;
    private IDealService dealService;
    private IInvoiceDetailService invoiceDetailService;
    private IVarianceService varianceService;
    private IMatchService matchService;
    private IDocumentService documentService;

    public IDocumentService getDocumentService() {
		return documentService;
	}
    @Autowired
	public void setDocumentService(IDocumentService documentService) {
		this.documentService = documentService;
	}

	public String formatAmount(double amount, String type, String currencyCode)
            throws ReIMException {
        if (type.equals(ReasonCode.COST_DISCREPANCY)) {
            return ReIMMoney.getCostString(amount, currencyCode, ReIMConstants.UNIT_COST);
        } else if (type.equals(ReasonCode.QUANTITY_DISCREPANCY)) {
            return ReIMQuantity.getQuantityString(amount);
        } else {
            return null;
        }
    }

    // TODO: This method has been migarted from the old <com.retek..>
    // service. It should be refactored to conform to the new framework
    // standards.
    public VarianceResolution[] createVarianceResolutions(Resolution[] resolutions)
            throws ReIMException {
        if (resolutions != null) {
            int varianceResolutionLength = resolutions.length;
            VarianceResolution[] varianceResolutions = new VarianceResolution[varianceResolutionLength];
            Resolution resolution;
            boolean merchandiseInvoiceResolution = false;
            boolean creditNoteResolution = false;
            boolean creditMemoResolution = false;

            if (resolutions[0] instanceof ResolutionMerchandiseInvoice) {
                merchandiseInvoiceResolution = true;
            } else if (resolutions[0] instanceof ResolutionDisputedCreditMemo) {
                creditMemoResolution = true;
            } else if (resolutions[0] instanceof ResolutionCreditNote) {
                creditNoteResolution = true;
            } else {
                // Should never get here.
                return null;
            }

            for (int i = 0; i < varianceResolutionLength; i++) {
                Double adjustedAmount = null;
                String adjustedAmountFormatted = null;
                Long rerouteBusinessRoleId = null;

                if (merchandiseInvoiceResolution) {
                    resolution = (ResolutionMerchandiseInvoice) resolutions[i];

                    if (resolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        adjustedAmount = resolution.getAdjustedCost();
                    } else {
                        adjustedAmount = new Double(resolution.getAdjustedQuantity().toString());
                    }

                    if (resolution.getAction().equals(ReasonCode.REROUTE_COST_DISCREPANCY)
                            || resolution.getAction().equals(
                                    ReasonCode.REROUTE_QUANTITY_DISCREPANCY)) {
                        adjustedAmountFormatted = "";
                    } else {
                        adjustedAmountFormatted = formatAmount(adjustedAmount.doubleValue(),
                                resolution.getDiscrepancyType(), resolution.getCurrencyCode());
                    }

                    rerouteBusinessRoleId = resolution.getRerouteBusinessRoleId();

                    varianceResolutions[i] = new VarianceResolution(
                            resolution.getDiscrepancyType(), resolution.getDocId(),
                            Document.MERCHANDISE_INVOICE, resolution.getDiscrepancyItemId(), null,
                            resolution.getReasonCode(), resolution.getReasonCodeDesc(), resolution
                                    .getAction(), adjustedAmount, adjustedAmountFormatted,
                            (rerouteBusinessRoleId != null ? String.valueOf(rerouteBusinessRoleId)
                                    : null), resolution.getComments(),
                            resolution.getCurrencyCode(), resolution.getStatus(), resolution
                                    .getResolutionSaved());
                } else if (creditMemoResolution) // ResolutionDisputedCreditMemo
                {
                    resolution = (ResolutionDisputedCreditMemo) resolutions[i];

                    if (resolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        adjustedAmount = resolution.getAdjustedCost();
                    } else {
                        adjustedAmount = new Double(resolution.getAdjustedQuantity().toString());
                    }

                    if (resolution.getAction().equals(ReasonCode.REROUTE_COST_DISCREPANCY)
                            || resolution.getAction().equals(
                                    ReasonCode.REROUTE_QUANTITY_DISCREPANCY)) {
                        adjustedAmountFormatted = "";
                    } else {
                        adjustedAmountFormatted = formatAmount(adjustedAmount.doubleValue(),
                                resolution.getDiscrepancyType(), resolution.getCurrencyCode());
                    }

                    rerouteBusinessRoleId = resolution.getRerouteBusinessRoleId();

                    varianceResolutions[i] = new VarianceResolution(
                            resolution.getDiscrepancyType(),
                            resolution.getDocId(),
                            (resolution.getDiscrepancyType().equals(Resolution.TYPE_QUANTITY) ? Document.CREDIT_MEMO_QUANTITY
                                    : Document.CREDIT_MEMO_PRICE), resolution
                                    .getDiscrepancyItemId(), null, resolution.getReasonCode(),
                            resolution.getReasonCodeDesc(), resolution.getAction(), adjustedAmount,
                            adjustedAmountFormatted, (rerouteBusinessRoleId != null ? String
                                    .valueOf(rerouteBusinessRoleId) : null), resolution
                                    .getComments(), resolution.getCurrencyCode(), resolution
                                    .getStatus(), resolution.getResolutionSaved());
                }

                else if (creditNoteResolution) {

                    resolution = (ResolutionCreditNote) resolutions[i];

                    if (resolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        adjustedAmount = resolution.getAdjustedCost();
                    } else {
                        adjustedAmount = new Double(resolution.getAdjustedQuantity().toString());
                    }

                    adjustedAmountFormatted = formatAmount(adjustedAmount.doubleValue(), resolution
                            .getDiscrepancyType(), resolution.getCurrencyCode());

                    varianceResolutions[i] = new VarianceResolution(
                            resolution.getDiscrepancyType(),
                            resolution.getDocId(),
                            (resolution.getDiscrepancyType().equals(Resolution.TYPE_QUANTITY) ? Document.CREDIT_NOTE_REQUEST_QUANTITY
                                    : Document.CREDIT_NOTE_REQUEST_PRICE), resolution
                                    .getDiscrepancyItemId(), null, resolution.getReasonCode(),
                            resolution.getReasonCodeDesc(), resolution.getAction(), adjustedAmount,
                            adjustedAmountFormatted, null, resolution.getComments(), resolution
                                    .getCurrencyCode(), resolution.getStatus(), resolution
                                    .getResolutionSaved());
                } else {
                    return null;
                }
            }
            return varianceResolutions;
        }
        return null;
    }

    /*
     * This method has been migrated from the old <com.retek.reim..> service to remove compilation
     * errors. It still needs refactoring (non-Javadoc)
     * 
     * @see
     * com.retek.reim.services.IVarianceResolutionService#getResolutionActionsForDocItemType(java
     * .lang.String, long, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    public Resolution[] getResolutionActionsForDocItemType(String docType, long docId,
            String itemId, String discrepancyType, String debitMemoReasonCode, String currencyCode)
            throws ReIMException {
        try {
            ArrayList resolutionList = new ArrayList();
            String commentDiscrepancyType;
            Comment[] comments;

            if (docType.equals(Document.MERCHANDISE_INVOICE)) {
                IImResolutionActionAccessExt access = DaoFactory.getImResolutionActionAccessExt();
                ImResolutionActionRow[] row = access.getResolutionActionsForDocItemType(docId,
                        itemId, discrepancyType, ResolutionMerchandiseInvoice.UNROLLED);

                if (row != null) {
                    for (int i = 0; i < row.length; i++) {
                        commentDiscrepancyType = null;
                        if (discrepancyType.equals(Resolution.TYPE_COST)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_COST;
                        } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_QUANTITY;
                        }
                        comments = ServiceFactory.getCommentService().getCommentsForDocItemReason(
                                commentDiscrepancyType, row[i].getDocId(), row[i].getItemId(),
                                row[i].getReasonCode());

                        resolutionList
                                .add(new ResolutionMerchandiseInvoice(discrepancyType, row[i]
                                        .getDocId(), row[i].getItemId(), row[i].getReasonCode(),
                                        ServiceFactory.getReasonCodesService().getReasonCodeDesc(
                                                row[i].getReasonCode()), row[i].getAction(),
                                        (row[i].isUnitCostNull() ? null : new Double(row[i]
                                                .getUnitCost())), (row[i].isQuantityNull() ? null
                                                : new Double(row[i].getQuantity())), null,
                                        // quantity discrepancy ID
                                        null, // reroute role ID
                                        currencyCode, comments, // comments
                                        row[i].getStatus(), Resolution.SAVED, null));
                    }
                }
            } else if (docType.equals(Document.CREDIT_NOTE)) {
                IImResolutionActionAccessExt access = DaoFactory.getImResolutionActionAccessExt();
                ImResolutionActionRow[] row = access.getResolutionActionsForDocItemType(docId,
                        itemId, discrepancyType, Resolution.UNROLLED);

                if (row != null) {
                    for (int i = 0; i < row.length; i++) {
                        commentDiscrepancyType = null;
                        if (discrepancyType.equals(Resolution.TYPE_COST)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_COST;
                        } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_QUANTITY;
                        }
                        comments = ServiceFactory.getCommentService().getCommentsForDocItemReason(
                                commentDiscrepancyType, row[i].getDocId(), row[i].getItemId(),
                                row[i].getReasonCode());

                        resolutionList
                                .add(new ResolutionCreditNote(discrepancyType, row[i].getDocId(),
                                        row[i].getItemId(), row[i].getReasonCode(), ServiceFactory
                                                .getReasonCodesService().getReasonCodeDesc(
                                                        row[i].getReasonCode()),
                                        row[i].getAction(), (row[i].isUnitCostNull() ? null
                                                : new Double(row[i].getUnitCost())), (row[i]
                                                .isQuantityNull() ? null : new Double(row[i]
                                                .getQuantity())), null,
                                        // quantity discrepancy ID
                                        null, // reroute role ID
                                        currencyCode, comments, // comments
                                        row[i].getStatus(), Resolution.SAVED, null));
                    }
                }
            } else // disputed credit memo
            {
                IImReversalResolutionActionAccessExt access = DaoFactory
                        .getImReversalResolutionActionAccessExt();
                ImReversalResolutionActionRow[] row = access
                        .getResolutionActionsForDocItemReasonCode(docId, itemId, discrepancyType,
                                debitMemoReasonCode, ResolutionMerchandiseInvoice.UNROLLED);

                if (row != null) {
                    for (int i = 0; i < row.length; i++) {
                        commentDiscrepancyType = null;
                        if (discrepancyType.equals(Resolution.TYPE_COST)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_COST;
                        } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_QUANTITY;
                        }
                        comments = ServiceFactory.getCommentService().getCommentsForDocItemReason(
                                commentDiscrepancyType, row[i].getDocId(), row[i].getItem(),
                                row[i].getReasonCode());

                        resolutionList.add(new ResolutionDisputedCreditMemo(discrepancyType, row[i]
                                .getDocId(), row[i].getItem(), row[i].getDebitReasonCode(), row[i]
                                .getReasonCode(), ServiceFactory.getReasonCodesService()
                                .getReasonCodeDesc(row[i].getReasonCode()),
                        // reasonCodeDesc
                                row[i].getAction(), new Double(row[i].getUnitCost()), new Double(
                                        row[i].getQuantity()), null,
                                // quantity discrepancy ID
                                null, // reroute role ID
                                currencyCode, comments, // comments
                                row[i].getStatus(), Resolution.SAVED));
                    }
                }
            }

            if (resolutionList != null && resolutionList.size() > 0) {
                return (Resolution[]) resolutionList.toArray(new Resolution[resolutionList.size()]);
            } else {
                return null;
            }
        } catch (ReIMException e) {
            throw (e);
        }
    }

    /**
     * This method saves changes to resolution adjusted extended cost and quantity if all
     * discrepancies for a line have been resolved.
     * 
     * @param document
     *            Document being resolved
     * @param existingDetailRow
     *            Existing im_invoice_detail row being updated
     * @param resolution
     *            Current resolution
     * @param updateDocDetail
     *            Im_invoice_detail row with current changes
     * @throws ReIMException
     */
    // private static void updateDocHeadDetail(
    // ResolutionMerchandiseInvoice resolution,
    // ImInvoiceDetailRow existingDetailRow)
    // throws ReIMException
    private void updateDocHeadDetail(Resolution resolution, String docType, ArrayList receiptIds,
            ImPartiallyMatchedReceiptsRow[] matchedReceiptItems, boolean fromDetailMatch)
            throws ReIMException {
        // Only save doc detail and header changes if line is fully resolved
        // For cost resolution, it means cost discrepancy no longer exists for
        // the invoice line
        // For qty resolution, it means qty discrepancy no longer exists for the
        // invoice line
        if (resolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
            IImCostDiscrepancyAccessExt costAccess = DaoFactory.getImCostDiscrepancyAccessExt();
            ImCostDiscrepancyRow costRow = costAccess.readDiscrepancyByDocumentItem(resolution
                    .getDocId(), resolution.getDiscrepancyItemId());

            if (costRow != null) return;
        } else // qty type
        {
            IImQtyDiscrepancyAccessExt qtyAccess = DaoFactory.getImQtyDiscrepancyAccessExt();
            // ImQtyDiscrepancyAccessExt qtyAccess = new
            // ImQtyDiscrepancyAccessExt();
            boolean qtyDiscExists = qtyAccess.qtyDiscrepancyExists(Long.toString(resolution
                    .getDocId()), resolution.getDiscrepancyItemId());

            if (qtyDiscExists) return;
        }

        // Discrepancy is fully resolved, write resolution adjusted cost or qty
        // for both header and
        // detail
        // get all resolution actions for the resolution type (COST or QTY)
        IImResolutionActionAccessExt resolutionAccess = DaoFactory.getImResolutionActionAccessExt();
        // ImResolutionActionAccessExt resolutionAccess = new
        // ImResolutionActionAccessExt();
        ImResolutionActionRow[] actionRows = resolutionAccess.getResolutionActionsForDocItemType(
                resolution.getDocId(), resolution.getDiscrepancyItemId(), resolution
                        .getDiscrepancyType(), Resolution.UNROLLED);

        if (resolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
            if (docType.equals(Document.MERCHANDISE_INVOICE))
                performResolutionAdjustedCostUpdate(actionRows, resolution.getDocId(), resolution
                        .getDiscrepancyItemId(), receiptIds, fromDetailMatch, resolution
                        .getCurrencyCode());
            else
                performCreditNoteResolutionAdjustedCostUpdate(actionRows, resolution.getDocId(),
                        resolution.getDiscrepancyItemId());
        } else {
            if (docType.equals(Document.MERCHANDISE_INVOICE))
                performResolutionAdjustedQtyUpdate(actionRows, resolution.getDocId(), resolution
                        .getDiscrepancyItemId(), receiptIds, matchedReceiptItems, fromDetailMatch);
            else
                performCreditNoteResolutionAdjustedQtyUpdate(actionRows, resolution.getDocId(),
                        resolution.getDiscrepancyItemId());
        }
    }

    /**
     * This method is called once all quantity and cost discrepancies for a line item have been
     * resolved. It updates both im_doc_detail_reason_codes and im_doc_head for extended cost and
     * unit cost. This method also calls the match status service to to update the statuses.
     * 
     * @param origDocId
     *            The doc Id of the original document
     * @param itemId
     *            The Id of the item whose discrepancy is being resolved
     * @param resolutions
     *            All current resolutions for this item
     */
    // TODO: This method has only been migrated from the old <com.retek..>
    // service. It should be refactored to conform to the new framework
    // standards.
    private/* static */void performCreditNoteResolutionAdjustedCostUpdate(
            ImResolutionActionRow[] resolutions, long origDocId, String itemId)
            throws ReIMException {
        //
        // IImDocDetailReasonCodesAccessExt detailAccess = DaoFactory
        // .getImDocDetailReasonCodesAccessExt();

        List<DocumentItemReasonCode> existingDocDetail = getDocDetailReasonCodesDao()
                .readDetailsByDocItemReasonCode(new DocId(Long.valueOf(origDocId)),
                        new Item(itemId), null);

        Quantity totalLineUnitCostChange = new Quantity(0.0);

        if (resolutions != null) {
            int length = resolutions.length;

            for (int i = 0; i < length; i++) {
                ImResolutionActionRow resolution = resolutions[i];
                Quantity unitCost = new Quantity(resolution.getUnitCost());
                if (unitCost != null) {
                    // Add all unit cost changes for all resolutions for this
                    // line
                    totalLineUnitCostChange = totalLineUnitCostChange.add(unitCost.doubleValue());
                }
            }
        }

        // THE ENTERED ADJUSTED COST IS A DIFFERENCE
        if (existingDocDetail != null && !existingDocDetail.isEmpty()) {
            if (totalLineUnitCostChange.doubleValue() != 0) {
                if (resolutions != null) {
                    if (resolutions.length > 0) {
                        long docId = resolutions[0].getDocId();

                        // Retrieve existing adjusted unit cost for this line
                        double existingDetailUnitCost = existingDocDetail.get(0)
                                .getAdjustedUnitCost();

                        // Add existing adjusted cost to total of resolution
                        // adjusted
                        // costs
                        Quantity newDetailUnitCost = totalLineUnitCostChange
                                .add(existingDetailUnitCost);

                        // Save total to doc detail
                        existingDocDetail.get(0).setAdjustedUnitCost(
                                newDetailUnitCost.doubleValue());

                        // Create extended cost from product of resolution
                        // adjusted
                        // quantity
                        // and adjusted cost
                        Quantity totalLineExtendedCostChange = totalLineUnitCostChange
                                .multiply(existingDocDetail.get(0).getAdjustedQty());

                        // Add adjusted extended cost to existing extended cost
                        // on
                        // doc
                        // head
                        IImDocHeadAccessExt access = DaoFactory.getImDocHeadAccessExt();
                        double totalCost = access.readResolutionAdjustedTotalCost(docId)
                                .doubleValue();
                        Quantity newTotalCost = totalLineExtendedCostChange.add(totalCost);

                        // Save extended cost to doc head
                        ImDocHeadRow docHead = new ImDocHeadRow(docId);
                        docHead.setResolutionAdjustedTotalCost(newTotalCost.doubleValue());
                        access.update(docHead);
                    }// end for resolution.length>0
                }// end if resolutions!=null
            }// end if totalLineUnitCostChange.doubleValue()
            existingDocDetail.get(0).setCostMatched(Affirm.check(ReIMConstants.YES));
            getDocDetailReasonCodesDao().update(existingDocDetail.get(0));
            // Update header status to matched if all lines are matched
            // new DocumentItemReasonCode(existingDocDetail[0]);

            DocumentItemReasonCode documentItemReasonCode = existingDocDetail.get(0);
            DocumentItemReasonCode[] oneDocumentItemReasonCode = { documentItemReasonCode};

            ServiceFactory.getCreditNoteMatchStatusService().updateResolutionDocLinesStatus(
                    oneDocumentItemReasonCode, ReIMUserContext.getUsername());

        }// end if !existingDocDetail.isEmpty()

    }

    /**
     * This method is called once all quantity and cost discrepancies for a line item have been
     * resolved. It updates both im_doc_detail_reason_codes and im_doc_head for extended cost and
     * unit cost. This method also calls the match status service to to update the statuses.
     * 
     * @param origDocId
     *            The doc Id of the original document
     * @param itemId
     *            The Id of the item whose discrepancy is being resolved
     * @param resolutions
     *            All current resolutions for this item
     */
    // TODO: This method has only been migarted from the old <com.retek..>
    // service. It should be refactored to conform to the new framework
    // standards.
    private/* static */void performCreditNoteResolutionAdjustedQtyUpdate(
            ImResolutionActionRow[] resolutions, long origDocId, String itemId)
            throws ReIMException {

        // IImDocDetailReasonCodesAccessExt detailAccess = DaoFactory
        // .getImDocDetailReasonCodesAccessExt();

        // get ReasonCodes Dao
        // ImDocDetailReasonCodesRow[] existingDocDetail = detailAccess
        // .readDetailsByDocItemReasonCode(origDocId, itemId, null);
        List<DocumentItemReasonCode> existingDocDetail = getDocDetailReasonCodesDao()
                .readDetailsByDocItemReasonCode(new DocId(origDocId), new Item(itemId), null);
        
        for(DocumentItemReasonCode detailReasonCode:existingDocDetail){
        	detailReasonCode.setDocument(documentService.read(detailReasonCode.getDocument().getId()));
        }
        
        
        Quantity totalLineQtyChange = new Quantity(0.0);
        

        if (resolutions != null) {
            int length = resolutions.length;

            // Add all quantity resolution differences to get final adjustment
            // difference
            for (int i = 0; i < length; i++) {
                ImResolutionActionRow resolution = resolutions[i];

                // Do not adjust the doc Qty or costs for Receiver unit
                // adjustments--i.e leave qty =
                // 0.0
                if (!resolution.isQuantityNull()) {
                    Quantity lineQty = new Quantity(resolution.getQuantity());
                    totalLineQtyChange = totalLineQtyChange.add(lineQty);
                }
            }
        }

        // THE ENTERED ADJUSTED QUANTITY IS A DIFFERENCE

        if (totalLineQtyChange.doubleValue() != 0) {
            long docId = resolutions[0].getDocId();

            double existingDetailQty = existingDocDetail.get(0).getAdjustedQty();

            // Add adjustment difference to existing detail quantity to get
            // adjusted quantity...save
            // to detail
            Quantity newDetailQty = totalLineQtyChange.add(existingDetailQty);
            existingDocDetail.get(0).setAdjustedQty(newDetailQty.doubleValue());

            // add adjustment difference to existing header quantity to get
            // adjusted quantity...save
            // to header
            ImDocHeadAccess headAccess = new ImDocHeadAccess();
            ImDocHeadRow docHead = headAccess.read(docId, true);

            double existingTotalQty = docHead.getResolutionAdjustedTotalQty();
            Quantity newTotalQty = totalLineQtyChange.add(existingTotalQty);
            docHead.setResolutionAdjustedTotalQty(newTotalQty.doubleValue());

            // calculate the new adjusted total cost by creating new extended
            // cost from resolution
            // quantity difference and new resolution price
            double adjUnitCost = existingDocDetail.get(0).getAdjustedUnitCost();

            Quantity totalLineExtendedCostChange = totalLineQtyChange.multiply(adjUnitCost);

            double existingTotalCost = docHead.getResolutionAdjustedTotalCost();
            Quantity newTotalCost = totalLineExtendedCostChange.add(existingTotalCost);

            docHead.setResolutionAdjustedTotalCost(newTotalCost.doubleValue());
            headAccess.update(docHead);
        }

        existingDocDetail.get(0).setQtyMatched(Affirm.check(ReIMConstants.YES));

        getDocDetailReasonCodesDao().update(existingDocDetail.get(0));
        // Update header status to matched if all lines are matched
        // DocumentItemReasonCode documentItemReasonCode = new
        // DocumentItemReasonCode(
        // existingDocDetail.get(0));

        DocumentItemReasonCode documentItemReasonCode = existingDocDetail.get(0);

        DocumentItemReasonCode[] oneDocumentItemReasonCode = { documentItemReasonCode};
        ServiceFactory.getCreditNoteMatchStatusService().updateResolutionDocLinesStatus(
                oneDocumentItemReasonCode, ReIMUserContext.getUsername());

    }

    public Document getDocument(Resolution[] resolutions) throws ReIMException {
        Document fullDocument = null;
        if (resolutions != null && resolutions.length > 0) {
            fullDocument = ServiceFactory.getDocumentService().getDocHeadByDocId(
                    resolutions[0].getDocId());
//            invoiceDetailService.populateInvoiceItems(fullDocument);
            if (fullDocument.getType().equals(Document.MERCHANDISE_INVOICE)) {
                invoiceDetailService.populateInvoiceItems(fullDocument);
            } else {
                getCreditNoteDetailMatchService().buildDocumentItemReasonCodes(
                        (ResolutionDocument) fullDocument);
            }
        }
        return fullDocument;
    }

    /**
     * This method provides the main workflow for variance resolution actions. All variances for a
     * single line must be resolved before any document header information is updated.
     * 
     * @param resolutions
     *            Resolutions for either cost or quantity for a single Document Item
     * @throws ReIMException
     */
    // TODO: This method has only been migrated from the old <com.retek..>
    // service. It should be refactored to conform to the new framework
    // standards.
    public void saveLineItemVarianceResolutions(Resolution[] resolutions, Document fullDocument,
            boolean withinTolerance, ArrayList receiptIds, boolean fromDetailMatch)
            throws ReIMException {
        // THIS IS ONLY TO BE CALLED FOR A SINGLE LINE ITEM RESOLUTION!
        // THIS SHOULD ONLY BE CALLED FOR EITHER COST OR QTY DISCREPANCIES - NOT
        // BOTH AT ONCE!
        try {
            boolean reRouteActionIncluded = false;
            
            // BRN OLR 135775 added the transaction for any errors in RCA trigger 
            TransactionManagerFactory.getInstance().start();

            int resolutionsLength = resolutions.length;
            String receiptId = null;
            
            ArrayList resolutionActionRows = new ArrayList();
            ArrayList resolutionComments = new ArrayList();
            ArrayList receiverCostAdjRows = new ArrayList();
            ArrayList receiverUnitAdjRows = new ArrayList();

            double originalQuantity = Double.MIN_VALUE;
            Long qtyDiscId = null;

            if (fullDocument == null) {
                // TODO: Tamseela:Service being called from within the same JVM
                // do not need to be exposed as remote services.
                // So Why did the old method use ServiceFactory here?
                // fullDocument = ServiceFactory.getVarianceResolutionService()
                // .getDocument(resolutions);
                fullDocument = getDocument(resolutions);
            }

            if (fullDocument.getType().equals(Document.MERCHANDISE_INVOICE)) {
                DocumentItemInvoice fullDocumentItem = (DocumentItemInvoice) fullDocument
                        .getDocDetail().get(resolutions[0].getDiscrepancyItemId());
                        //Anil
                        if (fullDocumentItem  == null ) {
                            originalQuantity = 0.0;
                        } else {
                              originalQuantity = fullDocumentItem.getQty();
                        }
            } else {
                // type is credit note
                DocumentItemReasonCode fullDocumentItem = (DocumentItemReasonCode) fullDocument
                        .getDocDetail().get(resolutions[0].getDiscrepancyItemId());
                originalQuantity = fullDocumentItem.getAdjustedQty();
            }

            for (int i = 0; i < resolutionsLength; i++) {
                // Some of the resolutions may have already been saved during a
                // previous instance.
                // Once saved,
                // a resolution is not allowed to be edited or deleted.
                if (resolutions[i].getResolutionSaved().equals(Resolution.NEW)) {
                    Resolution resolution = resolutions[i];

                    if (fullDocument.getType().equals(Document.MERCHANDISE_INVOICE))
                        ((ResolutionMerchandiseInvoice) resolution).setOriginalDocQty(new Double(
                                originalQuantity));
                    else
                        // ResolutionCreditNote
                        ((ResolutionCreditNote) resolution).setOriginalDocQty(new Double(
                                originalQuantity));

                    qtyDiscId = resolution.getQtyDiscrepancyId();
                    String action = resolution.getAction();
                    
                    boolean haveReceipts = (receiptIds != null);

                    if (haveReceipts) // case of detail mathing created discrepancy
                    {
                    	// go through all available receipts and shipment in Im_resolution_action table.
                    	for (int k = 0; k < receiptIds.size(); k++) {
                    		if (receiptIds.get(k) instanceof Receipt) {
                    			receiptId = ((Receipt) receiptIds.get(k)).getReceiptId();
                    		} else {
                    			receiptId = (String) receiptIds.get(k);
                    		}
                    	}
                    }
                    //If there are more than one receipts, then the first receipt will be stored in Im_resolution_action
                    resolution.setReceiptId(receiptId);

                    if (action.equals(ResolutionMerchandiseInvoice.CBC)) // Charge
                    // Back
                    // Cost
                    {
                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.CBQ)) // Charge
                    // Back
                    // Quantity
                    {
                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.CMC)) // Credit
                    // Memo
                    // Cost
                    {
                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.CMQ))
                    // Credit Memo Quantity
                    {
                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.DWO))
                    // Discrepancy Write-Off
                    {
                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.MR))
                    // Match to Receipt
                    {
                        // TODO: Ask whether match to receipt receipts need to
                        // be persisted
                        // as a part of the discrepancy for discrepancy history

                        // *** Note: If match to receipt receipts are to be
                        // persisted as part of the
                        // *** discrepancy, then the set receipt item method
                        // should be modified to
                        // *** remove the receipt from the non_sr_receipts
                        // collection to avoid
                        // having
                        // *** the receipt qty counted twice.
                    } else if (action.equals(ResolutionMerchandiseInvoice.RCA))
                    // Receiver Cost Adjustment Order and Receipt Only
                    {
                         
                    	
                    	createReceiverAdjustmentRow( resolution, receiverCostAdjRows,
                                receiverUnitAdjRows, fullDocument, receiptIds);

                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                        
                        
                    } else if (action.equals(ResolutionMerchandiseInvoice.RCAS))
                    // Receiver Cost Adjustment Order/Receipt/Supplier Cost
                    {
                        createReceiverAdjustmentRow(resolution, receiverCostAdjRows,
                                receiverUnitAdjRows, fullDocument, receiptIds);

                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.RCD))
                    // Reroute Cost Discrepancy
                    { // set boolean to indicate that this resolution should
                        // not be migrated to
                        // history (thus statis is not updated)
                        reRouteActionIncluded = true;
                        changeCostDiscrepancyReviewGroup(resolution);
                    } else if (action.equals(ResolutionMerchandiseInvoice.RQD))
                    // Reroute Quantity Discrepancy
                    { // set boolean to indicate that this resolution should
                        // not be migrated to
                        // history (thus statis is not updated)
                        reRouteActionIncluded = true;
                        changeQuantityDiscrepancyReviewGroup(resolution);
                    } else if (action.equals(ResolutionMerchandiseInvoice.RUA))
                    // Receiver Unit Adjustment
                    {
                        createReceiverAdjustmentRow(resolution, receiverCostAdjRows,
                                receiverUnitAdjRows, fullDocument, receiptIds);

                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    } else if (action.equals(ResolutionMerchandiseInvoice.SR))
                    // Split Receipt
                    {
                        // Split receipt is handled differently in how receipt
                        // is set in
                        // setReceiptItem()
                        createResolutionActionRow(resolution, resolutionActionRows, fullDocument);
                    }

                    if (resolution.getComments() != null && resolution.getComments().length > 0) {
                        resolutionComments.addAll(ServiceFactory.getVarianceResolutionService()
                                .buildDocumentDetailCommentRows(resolution.getComments()));
                    }
                }
            }

            // insert actionResolutionRows
            IImResolutionActionAccessExt resolutionAccess = DaoFactory
                    .getImResolutionActionAccessExt();
            ImResolutionActionRow[] resolutionRows = new ImResolutionActionRow[resolutionActionRows
                    .size()];
            resolutionAccess.create((ImResolutionActionRow[]) resolutionActionRows
                    .toArray(resolutionRows));

            // insert receiver cost adjustment rows
            IImReceiverCostAdjustAccess costAccess = DaoFactory.getImReceiverCostAdjustAccess();

            // Before inserting new rows we need to make sure that there is no
            // adjustment
            // are scheduled for the same order/item/location
            // If an adjustment is available, it needs to be updated
            ImReceiverCostAdjustRow existingRow = null;
            ImReceiverCostAdjustRow newRow = null;

            for (int i = 0; i < receiverCostAdjRows.size(); i++) {
                newRow = (ImReceiverCostAdjustRow) receiverCostAdjRows.get(i);
                String[] locations = new String[1];                                
                locations[0] = String.valueOf(newRow.getLocation());

                AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
                        .getBean(ReIMBeanFactory.AOrderLocationBean);

                existingRow = costAccess.read(newRow.getOrderNo(), newRow.getItem(), newRow
                        .getLocation(), false);
                if (existingRow == null) {
                    if (fullDocument.getLocation().getLocationType().equals(Document.WAREHOUSE)) {
                        locations = orderLocationBean.getPOItemLocationForWH(String.valueOf(newRow
                                .getOrderNo()), fullDocument.getLocation().getLocationId(), newRow
                                .getItem());
                        for(String loc:locations){
                        	existingRow = costAccess.read(newRow.getOrderNo(), newRow.getItem(), Long.parseLong(loc), false);
                        	if(existingRow == null){
                        		newRow.setLocation(Long.parseLong(loc));
                        		break;
                        	}
                        }   
                    }

                    costAccess.create(newRow);
                } else
                    costAccess.update(newRow);
            }

            try {
                // insert receiver unit adjustment rows
                IImReceiverUnitAdjustAccess unitAccess = DaoFactory.getImReceiverUnitAdjustAccess();
                ImReceiverUnitAdjustRow[] unitRows = new ImReceiverUnitAdjustRow[receiverUnitAdjRows
                        .size()];
                unitAccess.create((ImReceiverUnitAdjustRow[]) receiverUnitAdjRows.toArray(unitRows));
            } catch (ReIMException ex) {
                if (ex.getCause().getMessage().indexOf("CHILD") != -1) {
                    throw new ReIMException("Error.child_shipment_exists", Severity.ERROR, ex,
                            VarianceResolutionService.class);
                } else {
                    throw new ReIMException("DALGen.cannot_perform_insert", Severity.ERROR, ex,
                            VarianceResolutionService.class);
                }
            }

            // Only migrate discrepancy completely resolved, not those with
            // reroute actions
            // involved.
            // Receipt quantities are only set to matched once the discrepancy
            // is fully resolved.
            ImPartiallyMatchedReceiptsRow[] matchedReceiptItems = null;
            if (!reRouteActionIncluded && withinTolerance) {
                if (qtyDiscId == null) {
                    if (fullDocument.getType().equals(Document.CREDIT_NOTE)) {
                        ServiceFactory.getCreditNoteDiscrepancyService()
                                .migrateCostDiscrepancyToHistory(resolutions[0]);
                    } else {
                        ServiceFactory.getDiscrepancyService().migrateCostDiscrepancyToHistory(
                                resolutions[0]);
                    }
                } else {
                    if (fullDocument.getType().equals(Document.CREDIT_NOTE)) {
                        ServiceFactory.getCreditNoteDiscrepancyService()
                                .migrateQuantityDiscrepancyToHistory(qtyDiscId.longValue());
                    } else {
                        // Since this is a qty discrepancy and it has been fully
                        // resolved, update
                        // the matched
                        // quantities used from receipts to resolve this
                        // discrepancy
                    	IImInvoiceDetailAccessExt detailAccess = DaoFactory.getImInvoiceDetailAccessExt();
                    	ImInvoiceDetailRow existingDetailRow = detailAccess.read(resolutions[0].getDocId(),resolutions[0].getDiscrepancyItemId(), true);
                    	if (existingDetailRow.getCostMatched().equalsIgnoreCase(ReIMConstants.YES))
                    	{
                    		ArrayList matchedItems = (ArrayList) setReceiptItem(resolutions, qtyDiscId);
                    		if (matchedItems != null) {
                            matchedReceiptItems = (ImPartiallyMatchedReceiptsRow[]) matchedItems
                                    .toArray(new ImPartiallyMatchedReceiptsRow[matchedItems.size()]);
                    		}
                    	}
                        ServiceFactory.getDiscrepancyService().migrateQuantityDiscrepancyToHistory(
                                qtyDiscId.longValue());
                    }
                }
            }

            saveResolutionCommentRows(resolutionComments);

            if (resolutions != null && resolutions.length > 0) {
                Resolution resolution = resolutions[0];

                if (fullDocument.getType().equals(Document.MERCHANDISE_INVOICE)) {
                    IImInvoiceDetailAccessExt detailAccess = DaoFactory
                            .getImInvoiceDetailAccessExt();
                    ImInvoiceDetailRow existingDetailRow = detailAccess.read(resolution.getDocId(),
                            resolution.getDiscrepancyItemId(), true);

                    // Set adjustment pending for item if any receiver
                    // adjustments exist
                    if (receiverUnitAdjRows.size() > 0 || receiverCostAdjRows.size() > 0) {
                        existingDetailRow.setAdjustmentPending(ReIMConstants.YES);
                        // always update adjustment pending flag here because it
                        // won't be
                        // updated in updateDocHeadDetail method if it is a
                        // partial resolution
                        detailAccess.update(existingDetailRow);
                    }
                }
                
                updateDocHeadDetail(resolution, fullDocument.getType(), receiptIds,
                        matchedReceiptItems, fromDetailMatch);
            }
        } catch (ReIMException e) {
        	// BRN V1.4 -added below line
        	TransactionManagerFactory.getInstance().rollback();
            throw (e);
        } catch (Exception e) {
        	// BRN V1.4 -added below line
        	TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.unable_to_save_variance_resolutions", Severity.ERROR, e,
                    VarianceResolutionService.class);
        // BRN V1.4 OLR End 135775 added the transaction for any errors in RCA trigger
        } finally {        	
            TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * This method execute saveLineItemVarianceResolutions() and saveSelectedAmount().
     * 
     * @throws ReIMException
     */
    public void saveSelectedResolutionsAndAmount(Resolution[] resolutions, Document fullDocument,
            boolean withinTolerance, long discrepancyId, String discrepancyType,
            double selectedAmount, boolean applyAll, Double orderItemUnitCost,
            Double docItemUnitCost, double outstandingVariance, ArrayList receipts,
            boolean fromDetailMatch) throws ReIMException {
        try {
        	ArrayList discrepancies = new ArrayList();
        	
        	if (!applyAll) {
            if (fullDocument.getType().equals(Document.MERCHANDISE_INVOICE)
                    || fullDocument.getType().equals(Document.CREDIT_NOTE)) {
                // If the discrepancy has been resolved within tolerance, update
                // the variance within
                // tolerance for the invoice item
                if (withinTolerance)
                    getVarianceService().updateVarianceWithinTolerance(discrepancyId,
                            discrepancyType, outstandingVariance);
                
                
                

                saveLineItemVarianceResolutions(resolutions, fullDocument, withinTolerance,
                        receipts, fromDetailMatch);
            } else {
                DisputedCreditMemoResolutionService.persistResolutions(resolutions, discrepancyId,
                        withinTolerance);
                approveDisputedCreditMemo(resolutions, fullDocument.getDocId());
            }
            saveSelectedAmount(discrepancyId, discrepancyType, selectedAmount);
        	}
			// APPLY ALL FUNCTIONALITY IMPLEMENTATION
            if (discrepancyType.equals(Resolution.TYPE_COST) && applyAll) {
                String item = resolutions[0].getDiscrepancyItemId();

                discrepancies = selectDiscrepenciesByItemCostsApplyAll(item,orderItemUnitCost.doubleValue(),docItemUnitCost.doubleValue());

                int resSize = resolutions.length;
                
                for (Iterator docIdIter = discrepancies.iterator(); docIdIter.hasNext();) {

					String discId = (String) docIdIter.next();
					
					long docId = (Long) docIdIter.next();

					long discrepancyIds = Long.parseLong(discId);
					
					String discrepantItem = (String) docIdIter.next();



                    for (int j = 0; j < resSize; j++) {
                        Comment[] comments = resolutions[j].getComments();
                        if (comments != null) {
                            for (int i = 0; i < comments.length; i++) {
                                comments[i].setDocId(Long.valueOf(docId));
                            }
                        }
                        resolutions[j].setDocId(docId);
                        resolutions[j].setDiscrepancyItemId(discrepantItem);
                    }
                    
                    fullDocument = getDocument(resolutions);

                    if (fullDocument.getType().equals(Document.MERCHANDISE_INVOICE)) {
                    	
                    	String shipment = ServiceFactory.getReceiptService().findReceipt(fullDocument.getDocId(),fullDocument.getOrderNo());
                        if(null== shipment)
                        {  receipts = null; }
                        else	
                        {for (int i = 0; i < receipts.size(); i++) {
                        if (receipts.get(i) instanceof Receipt) {
                         ((Receipt) receipts.set(i,shipment)).setReceiptId(shipment);
                           } 
                        else {
                         receipts.set(i,shipment);
                             }
                          }
                        }
                    	if (withinTolerance)
                    	{
							getVarianceService().updateVarianceWithinTolerance(discrepancyIds,discrepancyType, outstandingVariance);
                    	}
						
                        saveLineItemVarianceResolutions(resolutions, fullDocument,withinTolerance, receipts, fromDetailMatch);
                    } else {
                        DisputedCreditMemoResolutionService.persistResolutions(resolutions,
                        		discrepancyIds, withinTolerance);
                        approveDisputedCreditMemo(resolutions, fullDocument.getDocId());
                    }
                    saveSelectedAmount(discrepancyIds, discrepancyType, selectedAmount);
                
                }
            }
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_save_all_item_variance_resolutions",
                    Severity.ERROR, e, VarianceResolutionService.class);
        }
    }

    /*
     * Why is there a static method in a Spring Service?:Tamseela
     */
    // TODO: Static?
    /* static */void approveDisputedCreditMemo(Resolution[] resolutions, long origDocId)
            throws ReIMException {

        boolean approved = false;
        for (int i = 0; i < resolutions.length; i++) {
            // Some of the resolutions may have already been saved during a
            // previous instance. Once saved,
            // a resolution is not allowed to be edited or deleted.
            if (resolutions[i].getResolutionSaved().equals(Resolution.NEW)
                    && resolutions[i].getAction().equals(
                            ReasonCode.APPROVE_CREDIT_IN_DISPUTED_STATUS)) {
                approved = true;
            }
        }
        if (approved) {
            ServiceFactory.getDocumentService().updateDocumentStatus(origDocId, Document.APPROVED,
                    ReIMUserContext.getUsername());
        }
    }

    public Resolution[] createResolutions(VarianceResolution[] varianceResolutions)
            throws ReIMException {
        if (varianceResolutions != null) {
            int varianceResolutionLength = varianceResolutions.length;
            Resolution[] resolutions = new Resolution[varianceResolutionLength];
            VarianceResolution varianceResolution;
            String docType = varianceResolutions[0].getDocType();

            for (int i = 0; i < varianceResolutionLength; i++) {
                Double adjustedCost = null;
                Double adjustedQuantity = null;
                Long rerouteBusinessRoleId = null;

                varianceResolution = varianceResolutions[i];

                if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                    adjustedCost = varianceResolution.getAdjustedAmount();
                } else {
                    // adjustedAmount is null if action is re-reroute
                    if (varianceResolution.getAdjustedAmount() != null) {
                        adjustedQuantity = new Double(varianceResolution.getAdjustedAmount()
                                .doubleValue());
                    }
                }

                if (varianceResolution.getRerouteBusinessRoleId() != null) {
                    rerouteBusinessRoleId = new Long(varianceResolution.getRerouteBusinessRoleId());
                }

                if (docType.equals(Document.MERCHANDISE_INVOICE)) {
                    if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        resolutions[i] = new ResolutionMerchandiseInvoice(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedCost, rerouteBusinessRoleId,
                                varianceResolution.getCurrencyCode(), varianceResolution
                                        .getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved());
                    } else {
                        resolutions[i] = new ResolutionMerchandiseInvoice(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedQuantity, varianceResolution
                                        .getQtyDiscrepancyId(), rerouteBusinessRoleId,
                                varianceResolution.getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved(), varianceResolution
                                        .getReceiptId());
                        // If this is a resolution for match to receipt, then
                        // the match to receipt attribute needs to be set.
                        if (varianceResolution.getAction() != null
                                && varianceResolution.getAction().equals(
                                        ResolutionMerchandiseInvoice.MR)) {
                            ((ResolutionMerchandiseInvoice) resolutions[i])
                                    .setMatchToReceiptItem(varianceResolution
                                            .getMatchToReceiptItem());
                        }

                        if (varianceResolution.getAction() != null
                                && varianceResolution.getAction().equals(
                                        ResolutionMerchandiseInvoice.SR)) {
                            ((ResolutionMerchandiseInvoice) resolutions[i])
                                    .setSplitReceiptItems(varianceResolution.getReceiptItems());
                        }
                    }
                } else if (docType.equals(Document.CREDIT_NOTE)) {
                    if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        resolutions[i] = new ResolutionCreditNote(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedCost, null, varianceResolution
                                        .getCurrencyCode(), varianceResolution.getComments(),
                                varianceResolution.getStatus(), varianceResolution
                                        .getResolutionSaved());
                    } else {
                        resolutions[i] = new ResolutionCreditNote(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedQuantity, varianceResolution
                                        .getQtyDiscrepancyId(), null, varianceResolution
                                        .getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved(), null);
                    }
                }

                else // ResolutionDisputedCreditMemo
                {
                    if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        resolutions[i] = new ResolutionDisputedCreditMemo(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution
                                        .getDebitMemoReasonCode(), varianceResolution
                                        .getReasonCode(), varianceResolution.getReasonCodeDesc(),
                                varianceResolution.getAction(), adjustedCost,
                                rerouteBusinessRoleId, varianceResolution.getCurrencyCode(),
                                varianceResolution.getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved());
                    } else {
                        resolutions[i] = new ResolutionDisputedCreditMemo(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution
                                        .getDebitMemoReasonCode(), varianceResolution
                                        .getReasonCode(), varianceResolution.getReasonCodeDesc(),
                                varianceResolution.getAction(), adjustedQuantity,
                                varianceResolution.getQtyDiscrepancyId(), rerouteBusinessRoleId,
                                varianceResolution.getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved());
                    }

                }
            }
            return resolutions;
        }
        return null;
    }

    /**
     * This helper method returns whether a variance resolution is within tolerance.
     * 
     * @return Tolerance validation result
     * @param outstandingVariance
     *            Resolution amount to be validated
     * @throws ReIMException
     */
    // method migrated from older <com.retek..>service to remove compilation
    // errors in the Action classes. Might need refactoring
    public boolean isCostVarianceWithinTolerance(double outstandingVariance, double docCost,
            double receiptOrderCost, String item, Document fullDocument) throws ReIMException {
        if (outstandingVariance == 0) {
            // there is no variance; therefore, no need to check tolerance
            return true;
        } else {
            InvoiceDiscrepancyLevel invoiceDiscrepancyLevel = new InvoiceDiscrepancyLevel(item,
                    new Double(docCost), null);
            ReceiptDiscrepancyLevel receiptDiscrepancyLevel = new ReceiptDiscrepancyLevel(
                    new Double(receiptOrderCost), null);
            Match match = new Match();
            if (fullDocument != null) {
                match.setSupplier((Supplier) fullDocument.getVendor());
                match.setInvoiceCurrency(fullDocument.getCurrencyCode());
                match.setExchangeRate(fullDocument.getExchangeRate());
            }
            // the getPrimaryCurrency() method is still in the old Service
            // framework
            match.setPrimaryCurrency(ServiceFactory.getSystemOptionsService().getPrimaryCurrency());
            match.setSummaryOrLineMatch(Tolerance.LINE_LEVEL);
            match.setQtyMatchSuccessful(true);
            match.setCostMatchSuccessful(false);
            match.setInvoiceGroup(invoiceDiscrepancyLevel);
            match.setReceiptGroup(receiptDiscrepancyLevel);
            getMatchService().match(match);
            if (match.isCostMatchSuccessful()) {
                return true;
            } else {
                return false;
            }
        }
    }

    // method migrated from older <com.retek..>service to remove compilation
    // errors in the Action classes. Might need refactoring
    public double calculateOutstandingVariance(String costType, String currencyCode,
            String invCNCostQnty, String recCNRCostQnty, VarianceResolution[] resolutionList)
            throws ReIMException {
        BigDecimal outstandingCostQntyVariance;
        Quantity costVariance = new Quantity(calculateCostQntyVariance(costType, currencyCode,
                invCNCostQnty, recCNRCostQnty));
        Quantity sumResolutions = new Quantity(calculateSumResolutions(resolutionList));

        // use Quantity subtraction to get exact value
        outstandingCostQntyVariance = new BigDecimal(costVariance.subtract(sumResolutions)
                .doubleValue());
        outstandingCostQntyVariance = outstandingCostQntyVariance.setScale(4,
                BigDecimal.ROUND_HALF_UP);
        return outstandingCostQntyVariance.doubleValue();
    }

    // method migrated from older <com.retek..>service to remove compilation
    // errors in the Action classes. Might need refactoring
    private double calculateCostQntyVariance(String type, String currencyCode,
            String invCNCostQnty, String recCNRCostQnty) throws ReIMException {
        // It is essential that Money or quantity be used for subtraction as we
        // need to maintain
        // the exact values. i.e we need to be able to evaluate to exactly 0.0
        // which may not happen
        // if exact precision is not maintained.

        if (type == null || invCNCostQnty == null || recCNRCostQnty == null) { return 0; }

        Money moneyCNInCost = ReIMMoney.parseCurrencyString(invCNCostQnty, currencyCode);

        if (type.equals(Document.CREDIT_MEMO_PRICE) || type.equals(Document.CREDIT_MEMO_QUANTITY)) { return moneyCNInCost
                .doubleValue(); }

        Money moneyCNRReCost = ReIMMoney.parseCurrencyString(recCNRCostQnty, currencyCode);

        // Regardless of the cost selection, the oustanding variance will always
        // be order cost minus
        // document cost.
        return (moneyCNRReCost.subtract(moneyCNInCost).doubleValue());
    }

    // method migrated from older <com.retek..>service to remove compilation
    // errors in the Action classes. Might need refactoring
    public double calculateSumResolutions(VarianceResolution[] resolutionList) {
        double reasonCodeAmount = 0;
        if (resolutionList != null && resolutionList.length > 0) {
            int resolutionListLength = resolutionList.length;
            for (int i = 0; i < resolutionListLength; i++) {
                if (!resolutionList[i].getAction().equals(ReasonCode.REROUTE_COST_DISCREPANCY)
                        && !resolutionList[i].getAction().equals(
                                ReasonCode.REROUTE_QUANTITY_DISCREPANCY)) {
                    reasonCodeAmount += resolutionList[i].getAdjustedAmount().doubleValue();
                }
            }
        }
        return reasonCodeAmount;
    }

    public VarianceResolution applyVarianceResolution(String docId, String docType, String itemId,
            String debitMemoReasonCode, String reasonCode, String reasonCodeDesc, String action,
            Double adjustedAmount, String adjustedAmountFormatted, String qtyDiscrepancyId,
            String rerouteBusinessRoleId, Comment[] comments, String receiptId)
            throws ReIMException {
        try {
            return new VarianceResolution(Resolution.TYPE_QUANTITY, new Long(docId).longValue(),
                    docType, itemId, debitMemoReasonCode, reasonCode, reasonCodeDesc, action,
                    adjustedAmount, adjustedAmountFormatted, new Long(qtyDiscrepancyId),
                    rerouteBusinessRoleId, comments, Resolution.UNROLLED, Resolution.NEW, receiptId);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_apply_resolution", Severity.ERROR, e,
                    VarianceResolutionService.class);
        }
    }

    public VarianceResolution applyVarianceResolution(String discrepancyType, String docId,
            String docType, String itemId, String debitMemoReasonCode, String reasonCode,
            String reasonCodeDesc, String action, Double adjustedAmount,
            String adjustedAmountFormatted, String rerouteBusinessRoleId, Comment[] comments,
            String currencyCode, String status, String resolutionSaved) throws ReIMException {
        try {
            return new VarianceResolution(discrepancyType, new Long(docId).longValue(), docType,
                    itemId, debitMemoReasonCode, reasonCode, reasonCodeDesc, action,
                    adjustedAmount, adjustedAmountFormatted, rerouteBusinessRoleId, comments,
                    currencyCode, status, resolutionSaved);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_apply_resolution", Severity.ERROR, e,
                    VarianceResolutionService.class);
        }
    }

    public double calculateCreditNoteOutstandingQuantityVarianceByApplyAmount(
            double currentOutstandingQtyVariance, double applyAmount) throws ReIMException {
        return currentOutstandingQtyVariance - applyAmount;
    }

    public double calculateCreditNoteOustandingQuantityVarianceByVarianceResolutions(
            double quantityVariance, VarianceResolution[] varianceResolutions) throws ReIMException {
        double allVarianceTotal = 0;

        if (varianceResolutions != null) {

            for (int i = 0; i < varianceResolutions.length; i++) {
                allVarianceTotal += varianceResolutions[i].getAdjustedAmount().doubleValue();
            }
        }

        return quantityVariance - allVarianceTotal;
    }

    /**
     * This method creates a receiver adjustment row in the database for the resolution.
     * 
     * @param document
     *            Invoice being resolved
     * @param receiverCostAdjRows
     *            Hashmap of rows for cost adjustments - row is added to this
     * @param receiverUnitAdjRows
     *            Hashmap of rows for unit adjustments - row is added to this
     * @param resolution
     *            Current receiver adjustment resolution
     * @throws ReIMException
     */
    // TODO: Tamseela. this method is migrated to the new
    // <oracle.retail..> package from <com.retek..> package. It should be
    // refactored to remove all references to the old framework
    public void createReceiverAdjustmentRow(Resolution resolution, ArrayList receiverCostAdjRows,
            ArrayList receiverUnitAdjRows, Document document, ArrayList receipts)
            throws ReIMException {
        String action = resolution.getAction();

        boolean isCostAdjustment = action.equals(ResolutionMerchandiseInvoice.RCA)
                || action.equals(ResolutionMerchandiseInvoice.RCAS);

        String receiptId = null;
        Receipt receipt = null;
        String order_no = null;
        String supplier_no = null;
        String location = null;

        /*
         * If a discrepancy was created through detail matching, we can have PO/location on an
         * invoice to differ from PO/location on a receipt On the other hand, a discrepancy created
         * through Automatch will always have the same PO/location for an invoice and a receipt.
         * 
         * That's why the records for discrepancies created through detail matching we'll have
         * receipts and we'll use receipt information. For automatch created discrepancies, there
         * won't be any receipts and we'll use invoice information (but order/location will be the
         * same for a receipt and for an invoice)
         */

        boolean haveReceipts = (receipts != null);
        if (isCostAdjustment) {
            if (haveReceipts) // case of detail mathing created discrepancy
            {
                // go through all available receipts and create a row for each
                // receipt
                // adjustment should be made based on receipt, not order
                // information
                for (int i = 0; i < receipts.size(); i++) {
                    if (receipts.get(i) instanceof Receipt) {
                        receiptId = ((Receipt) receipts.get(i)).getReceiptId();
                    } else {
                        receiptId = (String) receipts.get(i);
                    }

                    receipt = ReceiptService.readReceipt(receiptId);
                    order_no = receipt.getOrderId();
                    supplier_no = getDealService().readSupplierByOrderId(order_no);
                    // BRN V 1.4 Begin OLR 135775 Below line was sending bill_to_loc, so the record in Im_receiver_cost_adjust table.
                    // location = receipt.getReceivingLoc().getLocationId();
                    location = document.getLocation().getLocationId();
                    // BRN V 1.4 End
                    receiverCostAdjRows.addAll(produceCostAdjustmentRows(order_no, location,
                            supplier_no, resolution, document, action, receiptId));
                } // end for
            } else // case of auto matching created discrepancy
            {
                // we can have only one row
                order_no = document.getOrderNo();
                location = document.getLocation().getLocationId();
                supplier_no = document.getVendor().getVendorId();

                receiverCostAdjRows.addAll(produceCostAdjustmentRows(order_no, location,
                        supplier_no, resolution, document, action, null));
            }
        } // end if
        else {
            // Should be RUA
            // for unit adjustment receipt is known.
            // We need to create just one record per resolution
            receiptId = resolution.getReceiptId();
            receipt = ReceiptService.readReceipt(receiptId);
            location = receipt.getReceivingLoc().getLocationId();

            long seqNo = 1;

            ImReceiverUnitAdjustRow unitRow = new ImReceiverUnitAdjustRow(
                    Long.parseLong(receiptId), resolution.getDiscrepancyItemId(), seqNo);
            unitRow.setAdjustedItemQty(-resolution.getAdjustedQuantity().longValue());
            unitRow.setNullableFieldsToNull();
            unitRow.setLocation(Long.parseLong(location));
            unitRow.setReasonCode(resolution.getReasonCode());
            unitRow.setUserId(ReIMUserContext.getUsername());

            receiverUnitAdjRows.add(unitRow);
        }
    }

    private ArrayList produceCostAdjustmentRows(String order_no, String location,
            String supplier_no, Resolution resolution, Document document, String action,
            String receiptId) throws ReIMException {

        String[] locations = new String[1];
        locations[0] = location;

        AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
                .getBean(ReIMBeanFactory.AOrderLocationBean);

        if (document.getLocation().getLocationType().equals(Document.WAREHOUSE)) {
            locations = orderLocationBean.getPOItemLocationForWH(order_no, location, resolution
                    .getDiscrepancyItemId());
        }

        ArrayList costAdjustRows = new ArrayList();
        for (int i = 0; i < locations.length; i++) {
            ImReceiverCostAdjustRow costRow = new ImReceiverCostAdjustRow(Integer
                    .parseInt(order_no), resolution.getDiscrepancyItemId(), Long
                    .parseLong(locations[i]));

            Quantity newUnitcost = getReceiverAdjustmentNewCost(document, resolution);
            costRow.setAdjustedUnitCost(newUnitcost.doubleValue());
            costRow.setCurrencyCode(document.getCurrencyCode());
            costRow.setNullableFieldsToNull();
            costRow.setReasonCode(resolution.getReasonCode());
            costRow.setUserId(ReIMUserContext.getUsername());
            if (receiptId == null) {
                costRow.setShipment(-1);
            } else {
                costRow.setShipment(new Long(receiptId).longValue());
            }

            if (action.equals(ResolutionMerchandiseInvoice.RCA)) {
                costRow.setType("POR");
            } else {
                costRow.setType("PORS");
            }
            costRow.setSupplier(Long.parseLong(supplier_no));
            costAdjustRows.add(costRow);
        }
        return costAdjustRows;
    }

    /**
     * This method creates resolution action row object for current resolution.
     * 
     * @param resolution
     *            Resolution to create resolution action row for.
     * @param resolutionActionRows
     *            Collection of resolution action rows to add row to.
     * @param document
     *            Document for resolution
     * @throws ReIMException
     */
    // TODO: Tamseela. this method is migrated to the new
    // <oracle.retail..> package from the old <comretek..> package it should be
    // refactored to remove all references to the old framework
    public void createResolutionActionRow(Resolution resolution, ArrayList resolutionActionRows,
            Document document) throws ReIMException {
        ImResolutionActionRow row = new ImResolutionActionRow(resolution.getDocId(), resolution
                .getDiscrepancyItemId(), resolution.getReasonCode());
        row.setNullableFieldsToNull();

        String receiptId = null;
        double adjustedQty = Double.MIN_VALUE;
        Quantity adjustedExtendedCost = new Quantity(Double.MIN_VALUE);
        Quantity cost = new ReIMQuantity(Double.MIN_VALUE);

        if (resolution.getAdjustedQuantity() != null) {
            if (resolution.getAction().equals(ResolutionMerchandiseInvoice.RUA)) {                
//                adjustedQty = getReceiverAdjustmentNewQty(receiptId, resolution).doubleValue();
// Anil P Above line is bug
                adjustedQty = getReceiverAdjustmentNewQty(resolution.getReceiptId(), resolution).doubleValue();
                
            } else {
                adjustedQty = resolution.getAdjustedQuantity().doubleValue();
            }
        }

        if (resolution.getAdjustedCost() != null) {
            cost = new ReIMQuantity(resolution.getAdjustedCost().doubleValue());

            if (document.getType().equals(Document.MERCHANDISE_INVOICE)) {
                adjustedExtendedCost = cost.multiply(((ResolutionMerchandiseInvoice) resolution)
                        .getOriginalDocQty().doubleValue());

            } else {
                adjustedExtendedCost = cost.multiply(((ResolutionCreditNote) resolution)
                        .getOriginalDocQty().doubleValue());
            }

            if (resolution.getAction().equals(ResolutionMerchandiseInvoice.RCA)
                    || resolution.getAction().equals(ResolutionMerchandiseInvoice.RCAS)) {
                // we want to save the NEW UNIT cost but EXTENDED cost is still
                // a Diff Extended Cost
                // for posting
                cost = getReceiverAdjustmentNewCost(document, resolution);
            }
        }
        
        row.setAction(resolution.getAction());

        if (adjustedQty != Double.MIN_VALUE) {
            row.setQuantity(adjustedQty);
        }

        if (adjustedExtendedCost.doubleValue() != Double.MIN_VALUE) {
            row.setExtendedCost(adjustedExtendedCost.doubleValue());
        }

        if (cost.doubleValue() != Double.MIN_VALUE) {
            row.setUnitCost(cost.doubleValue());
        }
        
        receiptId = resolution.getReceiptId();
        // Only gets the first item because only one is needed - mainly
        // to get which receipt
        // for this resolution
        if (receiptId != null){
        	row.setShipment(Long.parseLong(resolution.getReceiptId()));
        }else{
        	row.setShipment(0);        	
        }
        
        row.setStatus(ResolutionMerchandiseInvoice.UNROLLED);

        resolutionActionRows.add(row);
    }

    /**
     * This method returns the new cost for a receiver adjustment by adding the diff from the
     * resolution.
     * 
     * @return New cost after receiver adjustment is applied
     * @param document
     *            Document associated with resolution
     * @param resolution
     *            Current receiver adjustment resolution
     * @throws ReIMException
     */
    private Quantity getReceiverAdjustmentNewCost(Document document, Resolution resolution)
            throws ReIMException {
        // determine NEW cost from diff
        Location loc = new Location();
        loc.setLocationId(document.getLocation().getLocationId());
        AOrderLocationBean ordLoc = (AOrderLocationBean) ReIMBeanFactory
                .getBean(ReIMBeanFactory.AOrderLocationBean);
        POItemLocation itemLoc = ordLoc.getPOItemLocation(document.getOrderNo(), loc, resolution
                .getDiscrepancyItemId());

        Quantity orderUnitCost = new Quantity(itemLoc.getUnitCost());
        return orderUnitCost.add((-resolution.getAdjustedCost().doubleValue()));
    }

    /**
     * This method returns the new quantity for a receiver adjustment by adding the diff from the
     * resolution.
     * 
     * @return New quantity after receiver adjustment is applied
     * @param receipt
     *            receipt item defining the receipt the quantity is adjusted on
     * @param resolution
     *            Current receiver adjustment resolution
     * @throws ReIMException
     */
    private Quantity getReceiverAdjustmentNewQty(String receiptItem, Resolution resolution)
            throws ReIMException {
        Quantity qtyReceived = getReceiverAdjustmentCurrentQty(receiptItem, resolution
                .getDiscrepancyItemId());

        // Determine the NEW qty from the diff
        return qtyReceived.add(-resolution.getAdjustedQuantity().longValue());
    }

    /**
     * This method returns the current quantity for a receiver adjustment.
     * 
     * @return Current quantity before receiver adjustment is applied
     * @param receipt
     *            ID defining the receipt the quantity is adjusted on
     * @param itemId
     *            ID defining the item for the receipt
     * @throws ReIMException
     */
    public Quantity getReceiverAdjustmentCurrentQty(String receiptId, String itemId)
            throws ReIMException {
        try {
            AShipSkuBean shipSku = (AShipSkuBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AShipSkuBean);
            
            ReceiptItem item = shipSku.readReceiptItem(receiptId, itemId);

            return new Quantity(item.getQtyReceived());
        } catch (ReIMException e) {
            throw (e);
        }
    }

    /**
     * This method is called once all quantity and cost discrepancies for a line item have been
     * resolved. It updates both im_invoice_detail and im_doc_head for extended cost and quantity.
     * For the extended cost the adjusted quantity difference is multiplied by either the existing
     * cost or a new cost from the cost discrepancy resolutions (if existing). The original extended
     * cost has already been applied if necessary in the costupdate method. This method also sets
     * the line item quantity status to matched.
     * 
     * @param docDetail
     *            New im_invoice_detail record for updates
     * @param docHead
     *            New im_doc_head record for updates
     * @param existingDocDetail
     *            Existing invoice_detail row to obtain original quantity.
     * @param resolutions
     *            All current resolutions for this item
     * @throws ReIMException
     */
    protected void performResolutionAdjustedQtyUpdate(ImResolutionActionRow[] resolutions,
            long origDocId, String itemId, ArrayList receiptIds,
            ImPartiallyMatchedReceiptsRow[] matchedReceiptItems, boolean fromDetailMatch)
            throws ReIMException {
        IImInvoiceDetailAccessExt detailAccess = DaoFactory.getImInvoiceDetailAccessExt();
        ImInvoiceDetailRow existingDocDetail = detailAccess.read(origDocId, itemId, true);

        //
        Quantity totalLineQtyChange = new Quantity(0.0);
        //BRN V 1.5 Begin -added
        boolean splitReceipt = false;
        
        if (resolutions != null) {
            int length = resolutions.length;

            // Add all quantity resolution differences to get final adjustment
            // difference
            for (int i = 0; i < length; i++) {
                ImResolutionActionRow resolution = resolutions[i];
                
                // BRN V 1.5 Begin - added
                if(resolution.getAction().equals(ResolutionMerchandiseInvoice.SR)){
                	splitReceipt = true;
                }
                // BRN V 1.5 End
                // Do not adjust the doc Qty or costs for Receiver unit
                // adjustments--i.e leave qty =
                // 0.0
                if (!resolution.isQuantityNull()
                        && !resolution.getAction().equals(ResolutionMerchandiseInvoice.RUA)
                        && !resolution.getAction().equals(ResolutionMerchandiseInvoice.MR)
                        && !resolution.getAction().equals(ResolutionMerchandiseInvoice.SR)) {
                    Quantity lineQty = new Quantity(resolution.getQuantity());
                    totalLineQtyChange = totalLineQtyChange.add(lineQty);
                }
            }
        }

        // THE ENTERED ADJUSTED QUANTITY IS A DIFFERENCE
        // add adjustment difference to existing header quantity to get adjusted
        // quantity...save to
        // header
        long docId = existingDocDetail.getDocId();
        ImDocHeadAccess headAccess = new ImDocHeadAccess();
        ImDocHeadRow docHead = headAccess.read(docId, true);

        if (totalLineQtyChange.doubleValue() != 0) {
            double existingDetailQty = existingDocDetail.getResolutionAdjustedQty();

            // Add adjustment difference to existing detail quantity to get
            // adjusted quantity...save
            // to detail
            Quantity newDetailQty = totalLineQtyChange.add(existingDetailQty);
            existingDocDetail.setResolutionAdjustedQty(newDetailQty.doubleValue());

            double existingTotalQty = docHead.getResolutionAdjustedTotalQty();
            Quantity newTotalQty = totalLineQtyChange.add(existingTotalQty);
            docHead.setResolutionAdjustedTotalQty(newTotalQty.doubleValue());

            // calculate the new adjusted total cost by creating new extended
            // cost from resolution
            // quantity difference and new resolution price
            double adjUnitCost = existingDocDetail.getResolutionAdjustedUnitCost();

            Quantity totalLineExtendedCostChange = totalLineQtyChange.multiply(adjUnitCost);

            double existingTotalCost = docHead.getResolutionAdjustedTotalCost();
            Quantity newTotalCost = totalLineExtendedCostChange.add(existingTotalCost);

            docHead.setResolutionAdjustedTotalCost(newTotalCost.doubleValue());
            docHead.setLastDatetime(new ReIMDate().getTimestamp());
            docHead.setLastUpdateId(ReIMUserContext.getUsername());
            headAccess.update(docHead);
        }

        existingDocDetail.setQtyMatched(ReIMConstants.YES);

        // BRN V 1.4 Begin - If the there is no receipt, then only quantity resolution is required. 
        // This SMR requirement because the unit cost cannot be compared with directly ORDLOC as it depends on
        // 3-way matching between invoice, receipt and PO by linking locations.
        // im_doc_head.location = shipment.bill_to_loc = store.store
        // ordloc.location = store.default_wh (virtual warehouse)
        // Therefore, quantity difference is charged back at the invoice unit cost in the Debit Memo Quantity.
        // BRN V 1.6 Begin - removed if condition
        //if (ReIMConstants.YES.equals(existingDocDetail.getCostMatched())) {
        	existingDocDetail.setStatus(DocumentItemInvoice.MATCHED);
        //}
         // BRN V 1.6 End
        /*
        if(receiptIds.size() == 0 ){        	
        	existingDocDetail.setStatus(DocumentItemInvoice.MATCHED);        
        } */
        // BRN V 1.4 End
        
        // BRN V 1.5 Begin - Record to be inserted in Im_partially_matched_receipts table for quantity resolution.
        if(receiptIds.size() > 0 && !splitReceipt){        
        	updatePartiallyMatchedReceipts(receiptIds, itemId, Long.toString(docHead.getOrderNo()),
                    Long.toString(docHead.getLocation()));
        }
        // BRN V 1.5 End

        detailAccess.update(existingDocDetail);
        
        if (existingDocDetail.getStatus().equals(DocumentItemInvoice.MATCHED)) {
			persistSuccessfulDetailLevelMatches(existingDocDetail, receiptIds);
		}

        if (existingDocDetail.getStatus().equals(DocumentItemInvoice.MATCHED)) {
            MerchandiseDocument invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                    .getDocHeadByDocId(docId);
            getInvoiceDetailService().buildInvoiceLines(invoice);
            ServiceFactory.getMatchStatusService().checkMatchedStatus(invoice);

            if (invoice.getStatus().equals(Document.MATCHED)) {

	            ImDocHeadRow updateHeadRow = new ImDocHeadRow();
	            updateHeadRow.setDocId(docId);	            
                updateHeadRow.setStatus(Document.MATCHED);
                updateHeadRow.setMatchDate(ServiceFactory.getPeriodService().getScreenVDate()
                        .getTimestamp());
	        	updateHeadRow.setMatchId(ReIMUserContext.getUsername());
	        	updateHeadRow.setLastDatetime(new ReIMDate().getTimestamp());
	        	updateHeadRow.setLastUpdateId(ReIMUserContext.getUsername());
	        	headAccess.update(updateHeadRow);
	            
	            if (receiptIds.size() == 0) {
	                updateReceiptForMatched(Long.toString(docHead.getOrderNo()), Long
	                        .toString(docHead.getLocation()), receiptIds);
	            } else {
	                createReceiptItemPosting(receiptIds, itemId, existingDocDetail, docId,
	                        matchedReceiptItems);
	            }
	
	            updateReceiptsForMatched(receiptIds, itemId, Long.toString(docHead.getOrderNo()),
	                    Long.toString(docHead.getLocation()));
        			
            } else {
                createReceiptItemPosting(receiptIds, itemId, existingDocDetail, docId,
                        matchedReceiptItems);
                if (fromDetailMatch) {
                    updateReceiptsForMatched(receiptIds, itemId, Long
                            .toString(docHead.getOrderNo()), Long.toString(docHead.getLocation()));
                } else {
                    updateReceiptsForNonMatched(receiptIds, itemId, Long.toString(docHead
                            .getOrderNo()), Long.toString(docHead.getLocation()));
                }

            }
            
        } else if (!fromDetailMatch && existingDocDetail.getCostMatched().equalsIgnoreCase(ReIMConstants.YES)) {
            createReceiptItemPosting(receiptIds, itemId, existingDocDetail, docId,
                    matchedReceiptItems);

            updateReceiptsForNonMatched(receiptIds, itemId, Long.toString(docHead.getOrderNo()),
                    Long.toString(docHead.getLocation()));
        }
    }

    /**
     * This helper method returns whether a variance resolution is within tolerance.
     * 
     * @return Tolerance validation result
     * @param outstandingVariance
     *            Resolution amount to be validated
     * @throws ReIMException
     */
    public boolean isQuantityVarianceWithinTolerance(double outstandingVariance,
            double docQuantity, double receiptOrderQuantity, String item, Document fullDocument)
            throws ReIMException {
        if (outstandingVariance == 0) {
            // there is no variance; therefore, no need to check tolerance
            return true;
        } else {
            InvoiceDiscrepancyLevel invoiceDiscrepancyLevel = new InvoiceDiscrepancyLevel(item,
                    null, new Double(docQuantity));
            ReceiptDiscrepancyLevel receiptDiscrepancyLevel = new ReceiptDiscrepancyLevel(null,
                    new Double(receiptOrderQuantity));
            Match match = new Match();
            if (fullDocument != null) {
                match.setSupplier((Supplier) fullDocument.getVendor());
                match.setInvoiceCurrency(fullDocument.getCurrencyCode());
                match.setExchangeRate(fullDocument.getExchangeRate());
            }
            match.setPrimaryCurrency(ServiceFactory.getSystemOptionsService().getPrimaryCurrency());
            match.setSummaryOrLineMatch(Tolerance.LINE_LEVEL);
            match.setQtyMatchSuccessful(false);
            match.setCostMatchSuccessful(true);
            match.setQtyMatchRequired(true);
            match.setInvoiceGroup(invoiceDiscrepancyLevel);
            match.setReceiptGroup(receiptDiscrepancyLevel);
            getMatchService().match(match);
            if (match.isQtyMatchSuccessful()) {
                return true;
            } else {
                return false;
            }
        }
    }
    
    private void persistSuccessfulDetailLevelMatches(
			ImInvoiceDetailRow existingDocDetail, List receiptIds)
			throws ReIMException {

		DocumentItemInvoice documentItemInvoice = new DocumentItemInvoice();
		documentItemInvoice.setDocument(new Document(existingDocDetail
				.getDocId()));
		documentItemInvoice.setItem(new Item(existingDocDetail.getItem()));
		InvoiceLineLevel invoiceGroup = new InvoiceLineLevel();
		invoiceGroup.setInvoiceItem(documentItemInvoice);

		ReceiptItem[] receiptItems = new ReceiptItem[receiptIds.size()];
		for (int i = 0; i < receiptIds.size(); i++) {
			ReceiptItem receiptItem = new ReceiptItem();
			receiptItem.setReceipt(new Receipt((String) receiptIds.get(i)));
			receiptItem.setItemId(existingDocDetail.getItem());
			receiptItems[i] = receiptItem;
		}
		ReceiptDetailSummaryLevel receiptGroup = new ReceiptDetailSummaryLevel(
				receiptItems);

		Match match = new Match();
		match.setInvoiceGroup(invoiceGroup);
		match.setReceiptGroup(receiptGroup);
		MatchHistoryService.persistSuccessfulDetailLevelMatches(
				new Match[] { match }, false);
	}
    
    /**
     * This method selects all the discrepancy items which as got same cost discrepancy.
     * @param itemId
     * @param orderCost
     * @param invoiceCost
     * @return Discrepency list
     * @throws ReIMException
     */
    		
    public static ArrayList selectDiscrepenciesByItemCostsApplyAll(String itemId, double orderCost,
            double invoiceCost) throws ReIMException {
        try {
            AOrderBean ordBean = (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);
            TransactionManagerFactory.getInstance().start();
            return ordBean.selectDiscrepenciesByItemCostsApplyAll(itemId, orderCost, invoiceCost);
        } catch (ReIMException re) {
            throw (re);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_select_discrepencies_by_item_costs",
                    Severity.ERROR, e, VarianceResolutionService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private IMatchStatusService getMatchStatusService() {
        return matchStatusService;
    }

    @Autowired
    public void setMatchStatusService(IMatchStatusService matchStatusService) {
        this.matchStatusService = matchStatusService;
    }

    public IDocDetailReasonCodesDao getDocDetailReasonCodesDao() {
        return docDetailReasonCodesDao;
    }

    @Autowired
    public void setDocDetailReasonCodesDao(IDocDetailReasonCodesDao detailAccess) {
        this.docDetailReasonCodesDao = detailAccess;
    }

    private ICreditNoteDetailMatchService getCreditNoteDetailMatchService() {
        return creditNoteDetailMatchService;
    }

    @Autowired
    public void setCreditNoteDetailMatchService(
            ICreditNoteDetailMatchService creditNoteDetailMatchService) {
        this.creditNoteDetailMatchService = creditNoteDetailMatchService;
    }

    private IDealService getDealService() {
        return dealService;
    }

    @Autowired
    public void setDealService(IDealService dealService) {
        this.dealService = dealService;
    }

    public IInvoiceDetailService getInvoiceDetailService() {
        return invoiceDetailService;
    }

    @Autowired
    public void setInvoiceDetailService(IInvoiceDetailService invoiceDetailService) {
        this.invoiceDetailService = invoiceDetailService;
    }

    private IVarianceService getVarianceService() {
        return varianceService;
    }

    @Autowired
    public void setVarianceService(IVarianceService varianceService) {
        this.varianceService = varianceService;
    }

    public IMatchService getMatchService() {
        return matchService;
    }

    @Autowired
    public void setMatchService(IMatchService matchService) {
        this.matchService = matchService;
    }

}
