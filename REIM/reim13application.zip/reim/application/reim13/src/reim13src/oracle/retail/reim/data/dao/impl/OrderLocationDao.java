package oracle.retail.reim.data.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import oracle.retail.reim.business.LocationType;
import oracle.retail.reim.business.tax.ItemLocationTaxes;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.tax.TaxTransactionType;
import oracle.retail.reim.business.tax.TransactionItemsTaxes;
import oracle.retail.reim.business.tax.TransactionItemsTaxesSearchCriteria;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.dao.IOrderLocationDao;
import oracle.retail.reim.data.dao.ITaxDataDao;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.utils.SqlCriteriaBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.foundation.rms12.OrderLocationBean;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.translation.DataTranslationService;
import com.retek.reim.ui.lov.LocationLOV;

@Repository
public class OrderLocationDao extends SimpleJdbcDaoSupport implements IOrderLocationDao {
    private static final String GET_DOCUMENT_ITEMS_FROM_ORDER_SQL = " SELECT ol.order_no order_no, w.physical_wh LOCATION, 'W' loc_type, im.item item, im.item_desc item_desc, SUM (ol.qty_ordered) qty_ordered, ol.unit_cost unit_cost FROM  v_im_ordloc ol, item_master im, wh w WHERE ol.LOCATION = w.wh AND ol.order_no = ? AND ol.item = im.item GROUP BY ol.order_no, w.physical_wh, im.item, im.item_desc, ol.unit_cost UNION SELECT ol.order_no order_no, s.STORE LOCATION, 'S' loc_type, im.item item, im.item_desc item_desc, ol.qty_ordered qty_ordered, ol.unit_cost unit_cost FROM  v_im_ordloc ol, item_master im, STORE s WHERE ol.LOCATION = s.STORE AND ol.order_no = ? AND ol.item = im.item GROUP BY ol.order_no, s.STORE, im.item, im.item_desc, ol.qty_ordered, ol.unit_cost ORDER BY LOCATION, item ";
    private static final String GET_POITEMS_FOR_INVOICE_DETAILS = " SELECT o.item item, o.vpn vpn, o.unit_cost unit_cost, o.unit_cost_init unit_cost_init, SUM (o.qty_ordered) qty_ordered, o.LOCATION LOCATION, o.loc_type loc_type " +
    		"FROM  (SELECT ol.item, its.vpn, ol.unit_cost, ol.unit_cost_init, ol.qty_ordered, l.physical_loc LOCATION, l.loc_type " +
    		"FROM  ordhead oh, v_im_ordloc ol, sups s, item_supplier its, " +
    		"(SELECT wh LOCATION, 'W' loc_type, physical_wh physical_loc FROM  wh WHERE physical_wh = ? " +
    		"UNION ALL SELECT STORE LOCATION, 'S' loc_type, STORE physical_loc FROM  STORE WHERE STORE = ?" +
    		"UNION ALL SELECT AH.WH LOCATION, 'S' loc_type, AD.TO_LOC physical_loc FROM ALLOC_DETAIL AD, ALLOC_HEADER AH WHERE AD.ALLOC_NO=AH.ALLOC_NO and AH.ORDER_NO = ? AND AD.TO_LOC = ? ) l " +
    		"WHERE oh.order_no = ol.order_no AND oh.supplier = s.supplier AND ol.LOCATION = l.LOCATION AND ol.item = its.item AND its.supplier = oh.supplier AND oh.order_no = ?) o " +
    		"GROUP BY o.item, o.LOCATION, o.loc_type, o.unit_cost, o.unit_cost_init, o.vpn ORDER BY o.item ";
    // migrated from the OrderLocBean..
    private static final String GET_POITEMLOCS_BY_ORDER_LOCATION = "SELECT ITEM, UNIT_COST"
            + " FROM V_IM_ORDLOC_STORES_PHYS_WH ";
    private static final String SELECT_ORDER_WH_LOCS = "SELECT L.LOCATION FROM V_IM_ORDLOC L WHERE L.LOCATION IN (SELECT WH FROM  WH WHERE PHYSICAL_WH = ?) AND L.LOC_TYPE = 'W' AND L.ORDER_NO = ? AND L.ITEM = ?";

    protected ITaxDataDao taxDataDao;

    public OrderLocationDao() {
        super();
    }

    public POItemLocation getPOItemLocation(String orderNo, Location location, String itemId) {
        try {
            return new OrderLocationBean().getPOItemLocation(orderNo, location, itemId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    // public HashMap<String, POItemLocation> getPOItemLocationsByOrderLocation(String orderNo,
    // Location location) {
    // try {
    // return new OrderLocationBean().getPOItemLocationsByOrderLocation(orderNo, location);
    // } catch (Exception e) {
    // throw new DataAccessException(e);
    // }
    // }

    public String getRandomOrderLocationDepartment(POLocation poLocation) {
        try {
            return new OrderLocationBean().getRandomOrderLocationDepartment(poLocation);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void getUnitCostInit(DocumentItem[] documentItems) {
        try {
            new OrderLocationBean().getUnitCostInit(documentItems);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public LocationLOV[] select() {
        try {
            return new OrderLocationBean().select();
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public DocumentItemInvoice[] getDocumentItemsFromOrder(String orderNo) {
        DocumentItemInvoice[] docItemArray = null;

        try {
            if (orderNo == null) { throw new ReIMException(
                    "error.ord_loc_bean.order_loc_cannot_be_null", Severity.DEBUG, this); }

            SqlCriteriaBuilder crit = new SqlCriteriaBuilder(GET_DOCUMENT_ITEMS_FROM_ORDER_SQL);
            crit.addParameterValues(new Object[] { Long.parseLong(orderNo.trim()),
                    Long.parseLong(orderNo.trim())});

            List<DocumentItemsFromOrderRecord> records = this.getSimpleJdbcTemplate().query(
                    crit.toString(), new ParameterizedRowMapper<DocumentItemsFromOrderRecord>() {
                        public DocumentItemsFromOrderRecord mapRow(ResultSet rs, int rowNum)
                                throws SQLException {

                            DocumentItemsFromOrderRecord record = new DocumentItemsFromOrderRecord();

                            record.setLocation(rs.getLong("LOCATION"));
                            record.setLocType(rs.getString("LOC_TYPE"));
                            record.setItem(rs.getString("ITEM"));
                            record.setItemDesc(rs.getString("ITEM_DESC"));
                            record.setQtyOrdered(rs.getDouble("QTY_ORDERED"));
                            record.setUnitCost(rs.getDouble("UNIT_COST"));

                            return record;
                        }
                    }, crit.getParameterValuesAsArray());

            List<DocumentItemInvoice> docItemsList = new ArrayList<DocumentItemInvoice>();
            List<Long> locations = new ArrayList<Long>();
            List<String> items = new ArrayList<String>();

            // create doc item objects
            for (DocumentItemsFromOrderRecord record : records) {
                DocumentItemInvoice docItem = new DocumentItemInvoice();
                docItem.setDocument(new MerchandiseDocument());

                locations.add(record.getLocation());
                docItem.getDocument().getLocation().setLocationId(record.getLocation());
                docItem.getDocument().getLocation().setLocationType(record.getLocType());

                items.add(record.getItem());

                Item item = new Item(record.getItem());
                if (DataTranslationService.isTranslationRequired(ReIMUserContext.getUserLanguage())) {
                    item.setItemName(DataTranslationService.getItemDesc(record.getItemDesc(),
                            ReIMUserContext.getUserLanguage()));
                } else {
                    item.setItemName(record.getItemDesc());
                }

                docItem.setItem(item);
                docItem.setQty(record.getQtyOrdered());
                docItem.setUnitCost(record.getUnitCost());
                docItemsList.add(docItem);
            }

            TransactionItemsTaxesSearchCriteria searchCriteria = new TransactionItemsTaxesSearchCriteria();
            searchCriteria.setItems(items);
            searchCriteria.setTaxTransactionType(TaxTransactionType.PURCHASE_ORDER);
            searchCriteria.setLocations(locations);
            searchCriteria.setTransactionNumbers(Long.valueOf(orderNo));

            List<TransactionItemsTaxes> transactionItemsTaxesList = getTaxDataDao()
                    .getTransactionItemsTaxes(searchCriteria);

            // We should never get transactionItemsTaxes empty. For a particular order
            // number there always be a single element
            if (transactionItemsTaxesList.size() > 0) {
                TransactionItemsTaxes transactionItemsTaxes = transactionItemsTaxesList.iterator()
                        .next();

                for (DocumentItemInvoice docItem : docItemsList) {
                    ItemLocationTaxes itemLocationTaxes = (null != transactionItemsTaxes
                            .findItemLocationByItemLocation(docItem.getItemId(), Long
                                    .valueOf(docItem.getDocument().getLocation().getLocationId())) ? transactionItemsTaxes
                            .findItemLocationByItemLocation(docItem.getItemId(), Long
                                    .valueOf(docItem.getDocument().getLocation().getLocationId()))
                            : new ItemLocationTaxes());

                    docItem.setTaxes(itemLocationTaxes.getItemLocTaxes());
                }
            }

            if (docItemsList.size() > 0) {
                docItemArray = new DocumentItemInvoice[docItemsList.size()];
                docItemArray = (DocumentItemInvoice[]) docItemsList.toArray(docItemArray);
            }

            return docItemArray;
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    private class DocumentItemsFromOrderRecord {
        private Long location;
        private String locType;
        private String item;
        private String itemDesc;
        private Double qtyOrdered;
        private Double unitCost;

        public DocumentItemsFromOrderRecord() {
        }

        public Long getLocation() {
            return location;
        }

        public void setLocation(Long location) {
            this.location = location;
        }

        public String getLocType() {
            return locType;
        }

        public void setLocType(String locType) {
            this.locType = locType;
        }

        public String getItem() {
            return item;
        }

        public void setItem(String item) {
            this.item = item;
        }

        public String getItemDesc() {
            return itemDesc;
        }

        public void setItemDesc(String itemDesc) {
            this.itemDesc = itemDesc;
        }

        public Double getQtyOrdered() {
            return qtyOrdered;
        }

        public void setQtyOrdered(Double qtyOrdered) {
            this.qtyOrdered = qtyOrdered;
        }

        public Double getUnitCost() {
            return unitCost;
        }

        public void setUnitCost(Double unitCost) {
            this.unitCost = unitCost;
        }
    }

    public DocumentItemInvoice[] getDocumentItemsFromOrderLocation(String orderNo, String locationId,ReIMDate invoiceDate) {
        try {
            if (orderNo == null || locationId == null) { throw new ReIMException(
                    "error.ord_loc_bean.order_loc_cannot_be_null", Severity.DEBUG, this); }
            Long order = Long.valueOf(orderNo.trim());
            Long location = Long.valueOf(locationId.trim());

            SqlCriteriaBuilder crit = new SqlCriteriaBuilder(GET_POITEMS_FOR_INVOICE_DETAILS);
            crit.addParameterValues(new Object[] { location, location, order, location, order});

            List<DocumentItemInvoice> records = this.getSimpleJdbcTemplate().query(crit.toString(),
                    new ParameterizedRowMapper<DocumentItemInvoice>() {
                        public DocumentItemInvoice mapRow(ResultSet rs, int rowNum)
                                throws SQLException {

                            DocumentItemInvoice record = new DocumentItemInvoice();

                            record
                                    .setItem(new Item(rs.getString("ITEM"), null, rs
                                            .getString("VPN")));
                            record.setQty(rs.getDouble("QTY_ORDERED"));
                            record.setUnitCost(rs.getDouble("UNIT_COST"));
                            record.setInitialUnitCost(rs.getDouble("UNIT_COST_INIT"));

                            return record;
                        }
                    }, crit.getParameterValuesAsArray());

            // Gather data for creating Tax API search criteria
            List<String> items = new ArrayList<String>();
            for (DocumentItemInvoice record : records) {
                items.add(record.getItem().getItemId());
            }

            // Create Tax API search criteria
            TransactionItemsTaxesSearchCriteria searchCriteria = new TransactionItemsTaxesSearchCriteria();
            searchCriteria.setItems(items);
            searchCriteria.setTaxTransactionType(TaxTransactionType.PURCHASE_ORDER);
            searchCriteria.setTransactionNumbers(Long.valueOf(orderNo));
            ArrayList<Long> locations = new ArrayList<Long>();
            locations.add(location);
            searchCriteria.setLocations(locations);
            searchCriteria.setInvoiceDate(invoiceDate.getSQL_Date());

            // Call Tax API
            List<TransactionItemsTaxes> transactionItemsTaxessList = getTaxDataDao()
                    .getTransactionItemsTaxes(searchCriteria);

            // TA: the Dao call *does* return un-intitialized List<> when NO taxes are found.
            // Therefore commenting out the following
            // TransactionItemsTaxes transactionItemsTaxes = transactionItemsTaxessList.get(0);

            // Apply Tax API results to DocumentItemInvoice list
            for (DocumentItemInvoice docItem : records) {

                Set<Tax> orderItemTaxes = new HashSet<Tax>();
                // Its the responsibility of the TAX API to return one result with all Taxes for a
                // item+location combination ..
                for (TransactionItemsTaxes transactionItemsTaxes : transactionItemsTaxessList) {
                    ItemLocationTaxes itemLocTaxes = transactionItemsTaxes
                            .findItemLocationByItemLocation(docItem.getItemId(), Long
                                    .valueOf(locationId));

                    if (itemLocTaxes != null) {
                        orderItemTaxes.addAll(itemLocTaxes.getItemLocTaxes());
                    }
                }

                docItem.setTaxes(orderItemTaxes);

            }

            return (DocumentItemInvoice[]) records.toArray(new DocumentItemInvoice[records.size()]);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public HashMap<String, POItemLocation> getPOItemLocationsByOrderLocation(String orderNo,
            Location location) {

        HashMap<String, POItemLocation> poItemLocations = new HashMap<String, POItemLocation>();
        final Location loc = location;// param.
        // stmt = (OraclePreparedStatement) conn
        // .prepareStatement(GET_POITEMLOCS_BY_ORDER_LOCATION);

        SqlCriteriaBuilder crit = new SqlCriteriaBuilder(GET_POITEMLOCS_BY_ORDER_LOCATION);
        crit.where("ORDER_NO = ?", orderNo.trim());
        crit.and("LOCATION = ? ", location.getLocationId());

        List<POItemLocation> poItemLocsList = this.getJdbcTemplate().query(crit.toString(),
                crit.getParameterValuesAsArray(), new ParameterizedRowMapper<POItemLocation>() {

                    public POItemLocation mapRow(ResultSet rs, int rowNum) throws SQLException {

                        String itemId = rs.getString("ITEM");

                        POItemLocation poItemLocation = new POItemLocation();
                        poItemLocation.setItem(new Item());
                        poItemLocation.getItem().setItemId(itemId);

                        poItemLocation.setLocation(loc);
                        poItemLocation.setUnitCost(rs.getDouble("UNIT_COST"));

                        return poItemLocation;
                    }
                });

        // convert list to HashMap..
        for (POItemLocation poLoc : poItemLocsList) {
            poItemLocations.put(poLoc.getItem().getItemId(), poLoc);
        }

        return poItemLocations;

    }
    
	public List<Location> getVirtualWhLocs(POItemLocation poItemLocation) {

		if (!poItemLocation.getLocation().getLocationType().equals(
				LocationType.WAREHOUSE.getVal())) {
			throw new IllegalArgumentException(
					"Expect a warehouse as a location");
		}

		SqlCriteriaBuilder crit = new SqlCriteriaBuilder(SELECT_ORDER_WH_LOCS);
		crit.addParameterValues(new Object[] {
				poItemLocation.getLocation().getLocationId(),
				poItemLocation.getOrderId(),
				poItemLocation.getItem().getItemId() });

		List<Location> locs = this.getSimpleJdbcTemplate().query(
				crit.toString(), new ParameterizedRowMapper<Location>() {
					public Location mapRow(ResultSet rs, int rowNum)
							throws SQLException {

						Location location = new Location();
						location.setLocationType(LocationType.WAREHOUSE
								.getVal());
						location.setLocationId(rs.getLong("LOCATION"));

						return location;
					}
				}, crit.getParameterValuesAsArray());

		return locs;
	}

    public void setMerch(boolean isMerch) {
        try {
            new OrderLocationBean().setMerch(isMerch);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setOrderNo(String newOrderNo) {
        try {
            new OrderLocationBean().setOrderNo(newOrderNo);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setStoreId(String newStoreId) {
        try {
            new OrderLocationBean().setStoreId(newStoreId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setWhId(String newWhId) {
        try {
            new OrderLocationBean().setWhId(newWhId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public double calculateVarianceWithinTolerance(long invoiceId) {
        try {
            return new OrderLocationBean().calculateVarianceWithinTolerance(invoiceId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public POItemLocation getPOItemLocationForAutoMatch(String orderNo, Location location,
            String itemId) {
        try {
            return new OrderLocationBean().getPOItemLocationForAutoMatch(orderNo, location, itemId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public String[] getPOItemLocationForWH(String orderNo, String location, String itemId) {
        try {
            return new OrderLocationBean().getPOItemLocationForWH(orderNo, location, itemId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public boolean isMerch() {
        try {
            return new OrderLocationBean().isMerch();
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public LocationLOV[] selectReceivedOrderLocations() {
        try {
            return new OrderLocationBean().selectReceivedOrderLocations();
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setOrderBy(String orderBy) {
        try {
            new OrderLocationBean().setOrderBy(orderBy);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setStoreName(String newStoreName) {
        try {
            new OrderLocationBean().setStoreName(newStoreName);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setSupplierId(String supplierId) {
        try {
            new OrderLocationBean().setSupplierId(supplierId);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public void setWhName(String newWhName) {
        try {
            new OrderLocationBean().setWhName(newWhName);
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    public ITaxDataDao getTaxDataDao() {
        return taxDataDao;
    }

    @Autowired
    public void setTaxDataDao(ITaxDataDao taxDataDao) {
        this.taxDataDao = taxDataDao;
    }
}
