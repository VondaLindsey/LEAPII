package oracle.retail.reim.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Utility class for loading the Spring container in a non-web-app environment. This is required for
 * excuting things like batch jobs. What we want to do is make this a component itself, that way we
 * can inject the appropriate context. Don't touch this.
 * 
 * @author Oracle Retail
 * 
 */
@Component
public class SpringContext implements ApplicationContextAware {
    private static ApplicationContext applicationContext;

    /**
     * Get the application context, if an instance of this class has been instatiated by Spring, the
     * context object will return the context that the instance belongs to, otherwise a new context
     * will be created and returned.
     * 
     * @return the appropriate context based on if this class has been instantiated by Spring.
     */
    public static ApplicationContext getContext() {
        if (applicationContext == null) {
        	ApplicationContext context =  SpringHolder.context;
        	((AbstractAutowireCapableBeanFactory)(context.getAutowireCapableBeanFactory())).setAllowRawInjectionDespiteWrapping(true);
        	return context;
        } else {
            return applicationContext;
        }
    }

    /**
     * Holder pattern for the Spring context.
     */
    private static class SpringHolder {
        static final String[] CONFIG_FILES = new String[] {
                "com/retek/reim/reim-datasource-config.xml",
                "com/retek/reim/reim-service-config.xml", "com/retek/reim/reim-dao-config.xml",
                "com/retek/reim/reim-batch-config.xml", "com/retek/reim/reim-util-config.xml" };
               // "com/retek/reim/reim-ui-config.xml"};

        private static ApplicationContext context = new ReimClassPathXmlApplicationContext(CONFIG_FILES);
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        SpringContext.applicationContext = applicationContext;
    }
}
