package com.retek.reim.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.data.dao.IInvoiceDetailDao;
import oracle.retail.reim.services.impl.InvoiceMaintenanceService;
import oracle.retail.reim.utils.ReimProperties;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.retek.reim.business.CurrencyRate;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ResolutionDisputedCreditMemo;
import com.retek.reim.business.document.CreditMemoPrice;
import com.retek.reim.business.document.CreditMemoQty;
import com.retek.reim.business.document.CreditNote;
import com.retek.reim.business.document.CreditRequestPrice;
import com.retek.reim.business.document.CreditRequestQty;
import com.retek.reim.business.document.CreditRequestTax;
import com.retek.reim.business.document.DebitMemoPrice;
import com.retek.reim.business.document.DebitMemoQty;
import com.retek.reim.business.document.DebitMemoTax;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemReasonCode;
import com.retek.reim.business.document.DocumentReference;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.IImDocHeadAccessExt;
import com.retek.reim.db.IImDocVatAccessExt;
import com.retek.reim.db.ImDocHeadAccess;
import com.retek.reim.db.ImDocHeadAccessExt;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.db.ImDocVatRow;
import com.retek.reim.db.ImInvoiceDetailAllowanceAccessExt;
import com.retek.reim.db.ImInvoiceDetailAllowanceRow;
import com.retek.reim.db.ImReasonCodesRow;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.locking.LockingData;
import com.retek.reim.locking.TableRecordLockingService;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;

/**
 * @see oracle.retail.reim.services.impl.DocumentService
 * 
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		21-May-2013	BNaik		BRN EDI Invoices should not be allowed to be edited.
 *     If any of the items are either matched or discrepancy routed(DETAIL_MATCHED='Y'), then the invoice will be in VIEW mode 
 * 		and cannot be edited. If not, the items can be edited in ready-for-match, unresolved match, and multi-unresolved invoices, and tax discrepancy status.
 * 										
 */
@Deprecated
public class DocumentService implements IDocumentService {

    private IInvoiceDetailDao invoiceDetailDao;

    public void updateDocumentStatusToDelete(Document[] documents, String updateUserId)
            throws ReIMException {
        try {
            long[] docIds = new long[documents.length];

            for (int i = 0; i < documents.length; i++) {
                /**
                 * Documents in RMTCH/URMTCH/MUMTCH status can be deleted. Prepaid invoices and
                 * documents that have records in IM_RESOLUTION_ACTION cannot be deleted.
                 */

                if (documents[i].isPrePaidInd()) {
                    throw new ReIMException("error.invoice_advanced_search_result_delete_prepaid",
                            Severity.DEBUG, DocumentService.class, new String[] { documents[i]
                                    .getExtDocId()});
                } else if (documents[i].getType().equals(Document.CREDIT_NOTE)) {
                    if (!documents[i].getStatus().equals(Document.APPROVED)) { throw new ReIMException(
                            "error.invoice_adv_search_action.delete.credit_note_status_not_approved",
                            Severity.DEBUG, DocumentService.class); }
                } else if (!documents[i].getStatus().equals(Document.READY_FOR_MATCH)
                        && !documents[i].getStatus().equals(Document.UNRESOLVED_MATCH)
                        && !documents[i].getStatus().equals(Document.MULTI_UNRESOLVED)
                        && !documents[i].getStatus().equals(Document.TAX_DISCREPANCY)
                        && documents[i].getType().equalsIgnoreCase("MRCHI")) {
                    throw new ReIMException(
                            "error.invoice_advanced_search_result_status_not_rmtch",
                            Severity.DEBUG, DocumentService.class);
                } else if (ServiceFactory.getInvoiceAdvSearchService().resolutionActionExists(
                        documents[i].getDocId())) { throw new ReIMException(
                        "error.invoice_advanced_search_result_action_exists", Severity.DEBUG,
                        DocumentService.class, new String[] { documents[i].getExtDocId()}); }
                docIds[i] = documents[i].getDocId();
            }

            updateDocumentStatus(docIds, Document.DELETE, updateUserId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.document_service.update_document_status",
                    Severity.ERROR, e, DocumentService.class);
        }
    }

    public void updateDocumentStatus(Document[] documents, String docStatus, String updateUserId)
            throws ReIMException {
        try {
            long[] docIds = new long[documents.length];

            for (int i = 0; i < documents.length; i++) {
                docIds[i] = documents[i].getDocId();
            }

            updateDocumentStatus(docIds, docStatus, updateUserId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.document_service.update_document_status",
                    Severity.ERROR, e, DocumentService.class);
        }
    }

    public void updateDocumentStatus(long[] documentIds, String docStatus, String updateUserId)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImDocHeadRow[] rows = new ImDocHeadRow[documentIds.length];
            ImDocHeadRow headRow = null;

            for (int i = 0; i < documentIds.length; i++) {
                headRow = new ImDocHeadRow();
                headRow.setDocId(documentIds[i]);
                headRow.setStatus(docStatus);
                headRow.setLastUpdateId(ReIMUserContext.getUsername());
                headRow.setLastDatetime(new ReIMDate().getTimestamp());

                if (docStatus.equals(Document.POSTED)) {
                    headRow.setPostDate(new ReIMDate().getTimestamp());
                }

                rows[i] = headRow;
            }

            DaoFactory.getImDocHeadAccessExt().update(rows);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.document_service.update_document_status",
                    Severity.ERROR, e, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void updateDocumentStatus(long documentId, String docStatus, String updateUserId)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            access.updateStatusByDocId(documentId, docStatus, updateUserId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.document_service.update_document_status",
                    Severity.ERROR, e, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    // todo: Verify this method is necessary
    public Document getDocHeadByDocId(long docId) throws ReIMException {
        Document document;

        try {
            TransactionManagerFactory.getInstance().start();

            IImDocHeadAccessExt access = DaoFactory.getImDocHeadAccessExt();
            document = access.read(docId);
            if (ReIMUserContext.getSystemOptions().isProcessTaxes()
                    && ReIMUserContext.getSystemOptions().isReconcileTax()) {
                IImDocVatAccessExt vatAccessExt = DaoFactory.getImDocVatAccessExt();
                ImDocVatRow[] docTaxes = vatAccessExt.read(docId + "");
                if (docTaxes != null && docTaxes.length > 0) {
                    Set<Tax> taxes = new HashSet<Tax>();
                    for (int i = 0; i < docTaxes.length; i++) {
                        Tax tax = new Tax(docTaxes[i].getTaxtCode(), docTaxes[i].getTaxRate(),
                                docTaxes[i].getTaxBasis());
                        taxes.add(tax);

                    }
                    document.setTaxes(taxes);
                }
            }
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            // stop using this error message!!
            throw new ReIMException("error.DocumentService.unknown_doc_head_by_doc_id",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

        return document;
    }

    public Document getDocHeadWithTaxByDocId(long docId) throws ReIMException {
        Document document;

        try {
            TransactionManagerFactory.getInstance().start();

            IImDocHeadAccessExt access = DaoFactory.getImDocHeadAccessExt();
            document = access.getMerchandiseDocHeadWithTax(docId);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            // stop using this error message!!
            throw new ReIMException("error.DocumentService.unknown_doc_head_with_tax_by_doc_id",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

        return document;
    }

    public String getDocumentTypeDescription(String docType) {
        String msg = null;

        if (docType.equalsIgnoreCase(Document.MERCHANDISE_INVOICE)) {
            msg = "Code.DOCTYP.MRCHI";
        } else if (docType.equalsIgnoreCase(Document.NON_MERCHANDISE_INVOICE)) {
            msg = "Code.DOCTYP.NMRCHI";
        } else if (docType.equalsIgnoreCase(Document.CREDIT_NOTE)) {
            msg = "Code.DOCTYP.CRDNT";
        } else if (docType.equals(Document.CREDIT_NOTE_REQUEST_PRICE))
        // Price changed to cost
        {
            msg = "Code.DOCTYP.CRDNRC";
        } else if (docType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
            msg = "Code.DOCTYP.CRDNRQ";
        } else if (docType.equals(Document.CREDIT_NOTE_REQUEST_TAX)) {
            msg = "Code.DOCTYP.CRDNRT";
        } else if (docType.equals(Document.CREDIT_MEMO_PRICE))
        // Price changed to cost
        {
            msg = "Code.DOCTYP.CRDMEC";
        } else if (docType.equals(Document.CREDIT_MEMO_QUANTITY)) {
            msg = "Code.DOCTYP.CRDMEQ";
        } else if (docType.equals(Document.DEBIT_MEMO_PRICE))
        // Price changed to cost
        {
            msg = "Code.DOCTYP.DEBMEC";
        } else if (docType.equals(Document.DEBIT_MEMO_QUANTITY)) {
            msg = "Code.DOCTYP.DEBMEQ";
        } else if (docType.equals(Document.DEBIT_MEMO_TAX)) {
            msg = "Code.DOCTYP.DEBMET";
        }

        return ReIMI18NUtility.getMessage(msg);

    } // end of getInvoiceType

    public String getDocumentTypeByPrefix(final String docPrefix) {
        String type = StringUtils.EMPTY;
        ReIMSystemOptions sysOptions = ReIMUserContext.getSystemOptions();

        if (sysOptions != null) {
            if (docPrefix.equals(sysOptions.getCreditMemoPrefixCost())) {
                return Document.CREDIT_MEMO_PRICE;
            } else if (docPrefix.equals(sysOptions.getCreditMemoPrefixQty())) {
                return Document.CREDIT_MEMO_QUANTITY;
            } else if (docPrefix.equals(sysOptions.getCreditNotePrefixCost())) {
                return Document.CREDIT_NOTE_REQUEST_PRICE;
            } else if (docPrefix.equals(sysOptions.getCreditNotePrefixQty())) {
                return Document.CREDIT_NOTE_REQUEST_QUANTITY;
            } else if (docPrefix.equals(sysOptions.getCreditNotePrefixTax())) {
                return Document.CREDIT_NOTE_REQUEST_TAX;
            } else if (docPrefix.equals(sysOptions.getDebitMemoPrefixCost())) {
                return Document.DEBIT_MEMO_PRICE;
            } else if (docPrefix.equals(sysOptions.getDebitMemoPrefixQty())) {
                return Document.DEBIT_MEMO_QUANTITY;
            } else if (docPrefix.equals(sysOptions.getDebitMemoPrefixTax())) { return Document.DEBIT_MEMO_TAX; }
        }
        return type;
    }

    public String getDocumentIdPrefix(String docType) {
        String prefix = StringUtils.EMPTY;

        if (ReIMUserContext.getSystemOptions() != null) {
            if (docType.equals(Document.CREDIT_MEMO_PRICE)) {
                prefix = ReIMUserContext.getSystemOptions().getCreditMemoPrefixCost();
            } else if (docType.equals(Document.CREDIT_MEMO_QUANTITY)) {
                prefix = ReIMUserContext.getSystemOptions().getCreditMemoPrefixQty();
            } else if (docType.equalsIgnoreCase(Document.CREDIT_NOTE)) {
                prefix = StringUtils.EMPTY;
            } else if (docType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)) {
                prefix = ReIMUserContext.getSystemOptions().getCreditNotePrefixCost();
            } else if (docType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                prefix = ReIMUserContext.getSystemOptions().getCreditNotePrefixQty();
            } else if (docType.equals(Document.CREDIT_NOTE_REQUEST_TAX)) {
                prefix = ReIMUserContext.getSystemOptions().getCreditNotePrefixTax();
            } else if (docType.equals(Document.DEBIT_MEMO_PRICE)) {
                prefix = ReIMUserContext.getSystemOptions().getDebitMemoPrefixCost();
            } else if (docType.equals(Document.DEBIT_MEMO_QUANTITY)) {
                prefix = ReIMUserContext.getSystemOptions().getDebitMemoPrefixQty();
            } else if (docType.equals(Document.DEBIT_MEMO_TAX)) {
                prefix = ReIMUserContext.getSystemOptions().getDebitMemoPrefixTax();
            }
        }

        return prefix;

    }

    public String getDocumentStatusDescription(String docStatus) {
        String msg = null;

        if (docStatus.equalsIgnoreCase(Document.READY_FOR_MATCH)) {
            msg = "Code.DOCSTS.RMTCH";
        } else if (docStatus.equalsIgnoreCase(Document.UNRESOLVED_MATCH)) {
            msg = "Code.DOCSTS.URMTCH";
        } else if (docStatus.equalsIgnoreCase(Document.MULTI_UNRESOLVED)) {
            msg = "Code.DOCSTS.MURMTH";
        } else if (docStatus.equalsIgnoreCase(Document.MATCHED)) {
            msg = "Code.DOCSTS.MTCH";
        } else if (docStatus.equalsIgnoreCase(Document.DISPUTED)) {
            msg = "Code.DOCSTS.DISPUT";
        } else if (docStatus.equalsIgnoreCase(Document.APPROVED)) {
            msg = "Code.DOCSTS.APPRVE";
        } else if (docStatus.equalsIgnoreCase(Document.POSTED)) {
            msg = "Code.DOCSTS.POSTED";
        } else if (docStatus.equalsIgnoreCase(Document.WGRP)) {
            msg = "Code.DOCSTS.WGRP";
        } else if (docStatus.equalsIgnoreCase(Document.VOID)) {
            msg = "Code.DOCSTS.VOID";
        } else if (docStatus.equalsIgnoreCase(Document.SUBMITTED)) {
            msg = "Code.DOCSTS.SUBMIT";
        } else if (docStatus.equalsIgnoreCase(Document.TAX_DISCREPANCY)) {
            msg = "Code.DOCSTS.TAXDISCREP";
        }

        return ReIMI18NUtility.getMessage(msg);

    }

    public String getDocumentStatus(String docStatusDescription) {
        String status = null;

        if (docStatusDescription != null) {
            if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.RMTCH"))) {
                status = Document.READY_FOR_MATCH;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.URMTCH"))) {
                status = Document.UNRESOLVED_MATCH;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.MURMTH"))) {
                status = Document.MULTI_UNRESOLVED;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.MTCH"))) {
                status = Document.MATCHED;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.DISPUT"))) {
                status = Document.DISPUTED;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.APPRVE"))) {
                status = Document.APPROVED;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.POSTED"))) {
                status = Document.POSTED;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.WGRP"))) {
                status = Document.WGRP;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.VOID"))) {
                status = Document.VOID;
            } else if (docStatusDescription.equalsIgnoreCase(ReIMI18NUtility
                    .getMessage("Code.DOCSTS.TAXDISCREP"))) {
                status = Document.TAX_DISCREPANCY;
            }

        }
        return status;

    }

    public String getFreightTypeDescription(String freightType) throws ReIMException {
        String msg = null;
        String desc = null;
        try {
            if (freightType.equalsIgnoreCase(Document.COLLECT)) {
                msg = "Code.SHMT.CC";
            } else if (freightType
                    .equalsIgnoreCase(Document.COLLECT_FREIGHT_CREDITED_BACK_TO_CUSTOMER)) {
                msg = "Code.SHMT.CF";
            } else if (freightType.equalsIgnoreCase(Document.DEFINED_BY_BUYER_AND_SELLER)) {
                msg = "Code.SHMT.DF";
            } else if (freightType.equalsIgnoreCase(Document.MIXED)) {
                msg = "Code.SHMT.MX";
            } else if (freightType.equalsIgnoreCase(Document.PREPAID_BUT_CHARGED_TO_CUSTOMER)) {
                msg = "Code.SHMT.PC";
            } else if (freightType.equalsIgnoreCase(Document.PREPAID_ONLY)) {
                msg = "Code.SHMT.PO";
            } else if (freightType.equalsIgnoreCase(Document.PREPAID_BY_SELLER)) {
                msg = "Code.SHMT.PP";
            }
            desc = ReIMI18NUtility.getMessage(msg);
        } catch (Exception e) {
            throw new ReIMException("document_service.error_getting_freight_type", Severity.ERROR,
                    e, DocumentService.class);
        }
        return desc;

    }

    public Document initializeDocument(String documentType) throws ReIMException {

        Document document = null;
        try {
            if (documentType.equals(Document.MERCHANDISE_INVOICE)) {
                document = new MerchandiseDocument();
            } else if (documentType.equals(Document.NON_MERCHANDISE_INVOICE)) {
                document = new NonMerchandiseDocument();
            } else if (documentType.equals(Document.CREDIT_NOTE)) {
                document = new CreditNote();
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)) {
                document = new CreditRequestPrice();
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                document = new CreditRequestQty();
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_TAX)) {
                document = new CreditRequestTax();
            } else if (documentType.equals(Document.CREDIT_MEMO_PRICE)) {
                document = new CreditMemoPrice();
            } else if (documentType.equals(Document.CREDIT_MEMO_QUANTITY)) {
                document = new CreditMemoQty();
            } else if (documentType.equals(Document.DEBIT_MEMO_PRICE)) {
                document = new DebitMemoPrice();
            } else if (documentType.equals(Document.DEBIT_MEMO_QUANTITY)) {
                document = new DebitMemoQty();
            } else if (documentType.equals(Document.DEBIT_MEMO_TAX)) {
                document = new DebitMemoTax();
            }
        } catch (Exception e) {
            throw new ReIMException("documentService.initializeDocument", Severity.ERROR, e,
                    DocumentService.class);
        }

        return document;
    }

    public String getBestTermsSource(String docSource) {
        String msg = null;

        if (docSource != null) {
            if (docSource.equalsIgnoreCase(Document.SOURCE_ORDER)) {
                msg = "Code.SOURCE_ORDER_TERMS";
            } else if (docSource.equalsIgnoreCase(Document.SOURCE_DOCUMENT)) {
                msg = "Code.SOURCE_INVOICE_TERMS";
            }
        }

        return ReIMI18NUtility.getMessage(msg);

    }

    public String getBestTermsDateSource(String docDateSource) {
        String msg = null;

        if (docDateSource != null) {
            if (docDateSource.equalsIgnoreCase(Document.SOURCE_RECEIPT_OF_GOODS_DATE)) {
                msg = "Code.SOURCE_RECEIPT_OF_GOODS_DATE";
            } else if (docDateSource.equalsIgnoreCase(Document.SOURCE_DOCUMENT_DATE)) {
                msg = "Code.SOURCE_INVOICE_DATE";
            }
        }

        return ReIMI18NUtility.getMessage(msg);

    }

    public void populateDocHeadInfo(Document doc) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            access.populateDocHeadInfo(doc);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_populate_doc_head_info", Severity.ERROR, e,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Map<String, String> getDocDetails(String docId) throws ReIMException {
        Map<String, String> details = new HashMap<String, String>();
        try {
            TransactionManagerFactory.getInstance().start();
            details = invoiceDetailDao.getDetailExistenceForInvoice(DocId.valueOf(docId));
        } catch (Exception e) {
            throw new ReIMException("error.cannot_populate_doc_head_info", Severity.ERROR, e,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

        return details;
    }

    public String getExtDocIdByVendor(String vendorType, String vendorId, String extDocId)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            return access.readExtDocIdByVendor(vendorType, vendorId, extDocId);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            // stop using this error message!!
            throw new ReIMException("error.DocumentService.unknown_ext_doc_id_by_vendor",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public String getExtDocId(String docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            return access.readExtDocId(docId);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR, ex,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    protected static List getListFromCommaSeparateString(String values) {
        List a = null;

        if (values != null && values.length() > 0) {
            a = new ArrayList();
            StringTokenizer st = new StringTokenizer(values, ",");
            while (st.hasMoreTokens()) {
                a.add(st.nextToken());
            }
        }

        return a;
    }

    public String getDocumentIdFromExternalId(String externalId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.getDocumentIdFromExternalId(externalId, null);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.failed_to_retrieve_document_detail", Severity.ERROR, ex,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public String updateImDocHeadRow(ImDocHeadRow aRow) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccess access = new ImDocHeadAccess();
            access.update(aRow);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
        return Document.SUCCESS;
    }

    public String createImDocHeadRow(ImDocHeadRow aRow) throws ReIMException {
        boolean isDuplicate = true;
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccess access = new ImDocHeadAccess();

            if (aRow.getType().equals(Document.MERCHANDISE_INVOICE)
                    || aRow.getType().equals(Document.NON_MERCHANDISE_INVOICE)) {
                isDuplicate = checkExtDocIdIsDuplicate(aRow.getVendor(), aRow.getExtDocId(),
                        Document.MERCHANDISE_INVOICE);
                if (!isDuplicate) {
                    isDuplicate = checkExtDocIdIsDuplicate(aRow.getVendor(), aRow.getExtDocId(),
                            Document.NON_MERCHANDISE_INVOICE);
                }
            } else {
                isDuplicate = checkExtDocIdIsDuplicate(aRow.getVendor(), aRow.getExtDocId(), aRow
                        .getType());
            }
            if (isDuplicate) {
                return Document.DUPLICATE;
            } else {
                access.create(aRow);
            }
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

        return Document.SUCCESS;
    }

    public boolean checkExtDocIdIsDuplicate(String vendor, String extDocId, String docType)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            IImDocHeadAccessExt docHeadAccessExt = DaoFactory.getImDocHeadAccessExt();
            return docHeadAccessExt.docHeadExist(vendor, extDocId, docType);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    // Single record locks
    public String lockDocumentForUser(long docId, String userId) throws ReIMException {
        try {
            return ServiceFactory.getTableRecordLockingService().lockTableRecordForUser(
                    LockingData.DOC_HEAD_LOCK_TABLE, userId, docId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.document_service.lock_doc_head", Severity.ERROR, e,
                    DocumentService.class);
        }
    }

    public String getDocumentLockUserId(long docId) throws ReIMException {
        try {
            return ServiceFactory.getTableRecordLockingService().getUserIdLockingRecordOnTable(
                    LockingData.DOC_HEAD_LOCK_TABLE, docId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.document_service.get_doc_lock_user", Severity.ERROR, e,
                    DocumentService.class);
        }
    }

    public void releaseDocumentLock(long docId) throws ReIMException {
        try {
            TableRecordLockingService.releaseLockOnRecord(LockingData.DOC_HEAD_LOCK_TABLE, docId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.document_service.release_doc_lock", Severity.ERROR, e,
                    DocumentService.class);
        }
    }

    public boolean lockRecordGroup(String userId, long[] docIds) throws ReIMException {
        try {
            return ServiceFactory.getTableRecordLockingService().lockTableRecordGroupForUser(
                    LockingData.DOC_HEAD_LOCK_TABLE, userId, docIds);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_adv_search.lock_group", Severity.ERROR, e,
                    DocumentService.class);
        }
    }

    public void releaseRecordGroupLockForUser(String userId, long[] docIds) throws ReIMException {
        try {
            ServiceFactory.getTableRecordLockingService().releaseLockOnRecordGroupForUser(
                    LockingData.DOC_HEAD_LOCK_TABLE, userId, docIds);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_adv_search.release_group_lock", Severity.ERROR,
                    e, DocumentService.class);
        }
    }

    public double getTotalAllowances(String documentId) throws ReIMException {
        try {
            double total = 0.0;
            TransactionManagerFactory.getInstance().start();

            ImInvoiceDetailAllowanceAccessExt access = new ImInvoiceDetailAllowanceAccessExt();
            ImInvoiceDetailAllowanceRow[] rows = access.getTotalAllowancesByDocumentId(documentId);

            if (rows != null && rows.length > 0) {
                for (int j = 0; j < rows.length; j++) {
                    if (rows[j].allowanceAmountIsPopulated())
                        total += rows[j].getAllowanceAmount();
                }
            }
            return total;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_calculate_total_allowances", Severity.ERROR,
                    ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public String getMatchDateByDocumentId(String documentId) throws ReIMException {
        try {
            Timestamp matchDate = null;
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            ImDocHeadRow row = access.getMatchDateByDocumentId(documentId);

            if (row != null) {
                matchDate = row.getMatchDate();
            }
            if (matchDate == null) { return ""; }
            return new ReIMDate(matchDate).getDisplayString();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_match_date", Severity.ERROR, ex,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public String getApprovalDateByDocumentId(String documentId) throws ReIMException {
        try {
            Timestamp approvalDate = null;
            TransactionManagerFactory.getInstance().start();

            if (documentId == null) return "";

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            ImDocHeadRow row = access.getApprovalDateByDocumentId(documentId);

            if (row != null) {
                approvalDate = row.getApprovalDate();
            }

            if (approvalDate == null) {
                approvalDate = ServiceFactory.getPeriodService().getScreenVDate().getTimestamp();
            }
            return new ReIMDate(approvalDate).getDisplayString();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approval_date", Severity.ERROR, ex,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public MerchandiseDocument[] readMatchedInvoicesForPosting() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readMatchedInvoicesForPosting();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_matched_invoices", Severity.ERROR,
                    ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Document[] readApprovedCreditNotes() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readApprovedDocuments(Document.CREDIT_NOTE);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approved_credit_notes",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * Method: readMatchedCreditNotesForTheAction
     * 
     * This method fetches the matched credit notes through the given resolution action type.
     * Returns the array of the credit note documents.
     * 
     * @param action
     *            resoltuion action type like DWO.
     * @return array of Document objects.
     * @exception throws
     *                ReIMException
     */
    public Document[] readMatchedCreditNotesForTheAction(String action) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            return access.readMatchedCreditNotesForTheAction(action);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_matched_credit_notes",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Document[] readApprovedCreditMemos() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readApprovedCreditMemos();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approved_credit_memos",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Document[] readApprovedDebitMemos() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readApprovedDebitMemos();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approved_debit_memos",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public ImDocHeadRow[] readApprovedCreditNoteRequests() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readApprovedCreditNoteRequests();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approved_credit_note_requests",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Vector readLateCreditNoteRequests() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readLateCreditNoteRequests();
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approved_credit_note_requests",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public MerchandiseDocument[] getAllInvoices(POLocation[] poLocations) {

        MerchandiseDocument invoices[] = new MerchandiseDocument[0];

        if (!ArrayUtils.isEmpty(poLocations)) {
            for (int i = 0; i < poLocations.length; i++) {
                MerchandiseDocument[] locInvoices = poLocations[i].getInvoices();
                if (!ArrayUtils.isEmpty(locInvoices)) {
                    for (int j = 0; j < locInvoices.length; j++) {
                        invoices = (MerchandiseDocument[]) ArrayUtils.add(invoices, locInvoices[j]);
                    }
                }
            }
        }
        return invoices;
    }

    public String getOrderInfoByDocumentId(long docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            Document docHead = ServiceFactory.getDocumentService().getDocHeadByDocId(docId);
            return docHead.getOrderNo();
        } catch (ReIMException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ReIMException("error.cannot_populate_order_number", Severity.ERROR, ex,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void updatePrePaid(Document[] invoices, boolean prePaid, String userId)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            access.updatePrePaid(invoices, prePaid, userId);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_pre_paid_on_doc_head", Severity.ERROR, e,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * Method getAllowanceCodeAmt.
     * 
     * This method returns HashMap of Allowance Code and Allowance Amount for document id, and item
     * id.
     * 
     * @param documentId
     * @param itemId
     * @return HashMap
     * @throws ReIMException
     */
    public HashMap getAllowanceCodeAmt(String docId, String itemId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImInvoiceDetailAllowanceAccessExt imDocDetailAllowanceAccessExt = new ImInvoiceDetailAllowanceAccessExt();
            ImInvoiceDetailAllowanceRow imDocDetailAllowanceRow[] = imDocDetailAllowanceAccessExt
                    .getAllowancesByDocumentIdNItemId(docId, itemId);
            HashMap allowanceCodeAmt = new HashMap();
            if (imDocDetailAllowanceRow != null && imDocDetailAllowanceRow.length > 0) {
                for (int i = 0; i < imDocDetailAllowanceRow.length; i++) {
                    allowanceCodeAmt.put(imDocDetailAllowanceRow[i].getAllowanceCode(), ""
                            + imDocDetailAllowanceRow[i].getAllowanceAmount());
                }
            }
            return allowanceCodeAmt;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.DocumentService.invoice_deals", Severity.ERROR, ex,
                    DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * Method getReferenceDocumentInfo.
     * 
     * This method returns the document type, external document ID for the specified document. If
     * the specified document has a reference document attached to it, then the method will also
     * return the document type, document ID, and external document ID for the referenced document.
     * 
     * @param docId
     * @return DocumentReference
     * @throws ReIMException
     */
    public DocumentReference getReferenceDocumentInfo(long docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            DocumentReference documentReferenceInfo = new DocumentReference();

            ImDocHeadAccess access = new ImDocHeadAccess();
            ImDocHeadRow row = new ImDocHeadRow(docId);
            row = access.read(docId, true);

            documentReferenceInfo.setDocId(docId);
            documentReferenceInfo.setExtDocId(row.getExtDocId());
            documentReferenceInfo.setDocType(row.getType());

            if (row.refDocIsPopulated() && row.getRefDoc() != Long.MIN_VALUE) {
                // If there is a reference document attached to the specified
                // document, then
                // get its information as well.
                documentReferenceInfo.setRefDocId(new Long(row.getRefDoc()));
                row = new ImDocHeadRow(documentReferenceInfo.getRefDocId().longValue());
                row = access.read(row.getDocId(), false);

                documentReferenceInfo.setRefExtDocId(row.getExtDocId());
                documentReferenceInfo.setRefDocType(row.getType());
            }

            return documentReferenceInfo;

        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.failed_to_retrieve_reference_document", Severity.ERROR,
                    ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * Method deleteDocument.
     * 
     * This method deletes document or an invoice.
     * 
     * @param docId
     * @throws ReIMException
     */

    public void deleteDocument(long docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            access.deleteDocument(docId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

    }

    /**
     * 
     * @param docId
     *            Id of a child invoice
     * @return Id of a parent invoice if docId belong to a child invoice, -1 otherwise
     * @throws ReIMException
     * 
     * If you need to get multiple parent Ids, use filterParentDocuments instead Otherwise you will
     * hit the database for every document separetly and for a big number of docs it will lead to
     * perform. problems
     */
    public long getParentId(long docId) throws ReIMException {
        try {
            long result;
            TransactionManagerFactory.getInstance().start();
            ImDocHeadAccess access = new ImDocHeadAccess();
            String[] columns = new String[1];
            columns[0] = ImDocHeadAccess.parentIdColumn;
            ImDocHeadRow row = access.read(columns, docId, false);
            if (row.parentIdIsPopulated())
                result = row.getParentId();
            else
                result = -1;
            return result;
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    /*
     * The methods will filter the documents and will returns the ones that have parents or null
     * otherwise
     * 
     * @param docIds Ids of a invoices @return Ids of parent invoices if docId belong to a child
     * invoice, null otherwise @throws ReIMException
     */
    public long[] filterParentDocuments(long[] docIds) throws ReIMException {
        if (docIds == null || docIds.length == 0) return null;

        String strDocId = "";
        String documents = "";

        for (int i = 0; i < docIds.length; i++) {
            strDocId = String.valueOf(docIds[i]);
            if (i > 0)
                documents = documents + ", " + strDocId;
            else
                documents = documents + strDocId;
        }
        try {
            TransactionManagerFactory.getInstance().start();
            ImDocHeadAccessExt access = new ImDocHeadAccessExt();
            return access.readParentDocuments(documents);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public double getExchangeRate(String orderNo, String currencyCode, ReIMDate docDate)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            Double exchangeRate = null;
            // if orderNo is defined and order has exchange rate, get order's
            // exchange rate
            if (orderNo != null) {
                AOrderBean orderBean = (AOrderBean) ReIMBeanFactory
                        .getBean(ReIMBeanFactory.AOrderBean);
                exchangeRate = orderBean.getExchangeRate(orderNo);
            }
            // if order exchange rate is not defined or order was null
            // get the consolidated exchange rate based on the currency code
            if (exchangeRate == null) {
                CurrencyRate rateObj = ServiceFactory.getCurrencyService()
                        .getConsolidatedExchangeRate(currencyCode, docDate);
                exchangeRate = rateObj.getExchangeRate();
            }

            return exchangeRate.doubleValue();
        } catch (ReIMException e) {
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public double getExchangeRate(String orderNo, String vendorId, String vendorType,
            ReIMDate docDate) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            Double exchangeRate = null;
            // if orderNo is defined and order has exchange rate, get order's
            // exchange rate
            if (orderNo != null) {
                AOrderBean orderBean = (AOrderBean) ReIMBeanFactory
                        .getBean(ReIMBeanFactory.AOrderBean);
                exchangeRate = orderBean.getExchangeRate(orderNo);
            }
            // if order exchange rate is not defined or order was null
            // get the consolidated exchange rate based on the vendor id and the
            // document date
            if (exchangeRate == null) {
                // get vendor currency code
                String currencyCode = ServiceFactory.getVendorService().getVendorCurrency(
                        vendorType, vendorId);

                if (currencyCode == null) { throw new ReIMException(
                        "error.vendor_currency_not_defined", Severity.ERROR, DocumentService.class,
                        new String[] { vendorId}); }

                CurrencyRate rateObj = ServiceFactory.getCurrencyService()
                        .getConsolidatedExchangeRate(currencyCode, docDate);
                exchangeRate = rateObj.getExchangeRate();
            }

            return exchangeRate.doubleValue();
        } catch (ReIMException e) {
            throw e;
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Document[] readApprovedNonMerchInvoices() throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImDocHeadAccessExt access = new ImDocHeadAccessExt();

            return access.readApprovedDocuments(Document.NON_MERCHANDISE_INVOICE);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.unable_to_retrieve_approved_nonmerch_invoices",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public static boolean validateDocumentDateNotBeforeVDate(String documentDate, ReIMDate vDate)
            throws ReIMException {
        // documet date must be equal to the businiss date or
        // before the business date
        boolean retValue = false;
        try {
            ReIMDate docDate = new ReIMDate(documentDate);

            if (docDate.equalsDate(vDate) || docDate.beforeDate(vDate)) {
                retValue = true;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_maintenance_header.update_failure",
                    Severity.ERROR, e, InvoiceMaintenanceService.class);
        }
        return retValue;
    }

    public static boolean checkDocumentDateBeforePostDatedDocDays(ReIMDate documentDate,
            ReIMDate vDate) throws ReIMException {
        // check to see if document date is earlier than/before vdate -
        // postDatedDocDays

        boolean retValue = false;
        try {
            // If the calling method does not already have the vDate, get it and
            // continue.
            if (vDate == null) {
                vDate = ServiceFactory.getPeriodService().getVDate();
            }

            int postDocDays = ReIMUserContext.getSystemOptions().getPostDatedDocDays();
            ReIMDate earliestPostDatedDocDate = new ReIMDate(vDate);
            earliestPostDatedDocDate.addDays(-postDocDays);

            if (documentDate.before(earliestPostDatedDocDate)) {
                retValue = true;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.invoice_maintenance_header.update_failure",
                    Severity.ERROR, e, InvoiceMaintenanceService.class);
        }
        return retValue;
    }

    public String getDocumentStatusByExtDocId(String extDocId) throws ReIMException {
        String status = null;

        try {
            TransactionManagerFactory.getInstance().start();

            IImDocHeadAccessExt access = DaoFactory.getImDocHeadAccessExt();
            status = access.getDocumentStatusByExtDocId(extDocId);
            return status;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            // stop using this error message!!
            throw new ReIMException("error.DocumentService.unknown_doc_head_by_doc_id",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

    }
    
    // BRN OLR V1.1 Start - added
    public String getDetailMatchedByDocId(String docId) throws ReIMException {
        String status = null;

        try {
            TransactionManagerFactory.getInstance().start();

            IImDocHeadAccessExt access = DaoFactory.getImDocHeadAccessExt();
            status = access.getDetailMatchedByDocId(docId);
            return status;
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            // stop using this error message!!
            throw new ReIMException("error.DocumentService.unknown_doc_head_by_doc_id",
                    Severity.ERROR, ex, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }
    // BRN OLR V1.1 End
    
    /**
     * This method will approve all the details and the header. 
     * 
     * @param docId Document ID
     * @param statusCode status of the document (DISPUT|SUBMIT)
     * @return If all the details were approved successfully then it will return true. 
     *         If one or more details have already been denied then it will return false. 
     */
    public boolean approveDocument(String docId, String statusCode) throws ReIMException {

        try {
            TransactionManagerFactory.getInstance().start();

            boolean allDetailsApproved = true;

            if (Document.DISPUTED.equals(statusCode)) {
                allDetailsApproved = this.approveDisputedDocument(docId);
            } else {
                this.approveSubmittedDocument(docId);
            }

            return allDetailsApproved;

        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw (e);
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.unable_to_approve_credit_in_disputed_status",
                    Severity.ERROR, e, DocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private boolean approveDisputedDocument(String docId) throws ReIMException {

        Document docHeader = this.getDocHeadByDocId(Long.parseLong(docId));

        DocumentItemReasonCode[] docDetailsArr = ServiceFactory.getDocumentDetailService()
        .getDocumentItemReasonCodesByDocId(docId);

        List<DocumentItemReasonCode> docDetails = new ArrayList<DocumentItemReasonCode>();

        int deniedDetailCount = 0;
        for (DocumentItemReasonCode detail : docDetailsArr) {

            if (DocumentItemReasonCode.DISPUTED.equals(detail.getStatus())){ 
                docDetails.add(detail);              
            } else if(DocumentItemReasonCode.DENIED.equals(detail.getStatus()))
                deniedDetailCount++;
        }      
        
        if(docDetailsArr.length > 0 && docDetails.isEmpty())
            throw new ReIMException("error.no_details_to_approve", Severity.WARN, DocumentService.class);        

        this.processResolutions(docHeader, docDetails);       
        
        Set<Long> docIds = new HashSet<Long>();
        docIds.add(Long.parseLong(docId));
        
        //This call will determine if the header status should be updated to APPROVED
        ImDocHeadAccessExt docHeadAccess = new ImDocHeadAccessExt();        
        docHeadAccess.updateRevesalCreditMemoAfterRollup(docIds, ReIMUserContext.getUsername());
        
        return (deniedDetailCount == 0);
    }

    private void approveSubmittedDocument(String docId) throws ReIMException {

        ServiceFactory.getDocumentDetailService().updateDocumentDetailStatus(Long.parseLong(docId),
                Document.APPROVED, ReIMUserContext.getUsername());

        ServiceFactory.getDocumentService().updateDocumentStatus(Long.parseLong(docId),
                Document.APPROVED, ReIMUserContext.getUsername());
    }    

    private void processResolutions(Document docHeader, List<DocumentItemReasonCode> docDetails)
            throws ReIMException {

        for (DocumentItemReasonCode docDetail : docDetails) {

            ResolutionDisputedCreditMemo resolution = new ResolutionDisputedCreditMemo();

            resolution.setDocId(docHeader.getDocId());
            resolution.setAction(ResolutionDisputedCreditMemo.APPROVE_CREDIT_IN_DISPUTED_STATUS);

            String itemId = docDetail.getItemId();
            resolution.setDiscrepancyItemId(itemId);

            String discrepancyType = (Document.CREDIT_MEMO_QUANTITY.equals(docHeader.getType())) ? ResolutionDisputedCreditMemo.TYPE_QUANTITY
                    : ResolutionDisputedCreditMemo.TYPE_COST;

            resolution.setDiscrepancyType(discrepancyType);

            long discrepancyId = this.getDiscrepancyId(docHeader, itemId);
            resolution.setQtyDiscrepancyId(discrepancyId);

            resolution.setResolutionSaved(Resolution.NEW);
            resolution.setAdjustedCost(docDetail.getAdjustedUnitCost());
            resolution.setAdjustedQuantity(docDetail.getAdjustedQty());

            String reasonCodeId = this.getReasonCodeIdForACDSAction(discrepancyType);
            resolution.setReasonCode(reasonCodeId);

            resolution.setDebitMemoReasonCode(docDetail.getReasonCode());

            Resolution[] resolutions = new ResolutionDisputedCreditMemo[] { resolution};
            DisputedCreditMemoResolutionService
                    .persistResolutions(resolutions, discrepancyId, true);

        }
    }

    private long getDiscrepancyId(Document docHeader, String itemId) throws ReIMException {

        long discrepancyId = -1;

        if (Document.CREDIT_MEMO_QUANTITY.equals(docHeader.getType())) {
            discrepancyId = ServiceFactory.getDiscrepancyService().getQtyDiscrepancyIdForItemDocId(
                    itemId, Long.toString(docHeader.getDocId()));
        } else {
            discrepancyId = ServiceFactory.getDiscrepancyService()
                    .getCostDiscrepancyIdForItemDocId(itemId, Long.toString(docHeader.getDocId()));
        }

        if (discrepancyId == -1)
            throw new ReIMException("error.discrepancy_service.get_discrepancy_id_for_item_doc_id",
                    Severity.ERROR, this.getClass());

        return discrepancyId;
    }

    private String getReasonCodeIdForACDSAction(String discrepancyType) throws ReIMException {

        long businessRoleId = ReIMUserContext.getUserRole().getBusinessRoleId();

        String reasonCodeType = (ResolutionDisputedCreditMemo.TYPE_QUANTITY.equals(discrepancyType)) ? ReasonCode.QUANTITY_DISCREPANCY
                : ReasonCode.COST_DISCREPANCY;

        String reasonCodeAction = ReasonCode.APPROVE_CREDIT_IN_DISPUTED_STATUS;

        List<ImReasonCodesRow> reasonCodes = ServiceFactory.getReasonCodesService()
                .getReasonCodesForTypeAndAction(businessRoleId, reasonCodeType, reasonCodeAction);

        if (reasonCodes.isEmpty())
            throw new ReIMException("error.reason_code_undefined", Severity.ERROR, this.getClass(),
                    new String[] { ReasonCode.APPROVE_CREDIT_IN_DISPUTED_STATUS});

        String reasonCodeId = reasonCodes.get(0).getReasonCodeId();

        return reasonCodeId;
    }

    public IInvoiceDetailDao getInvoiceDetailDao() {
        return invoiceDetailDao;
    }

    @Autowired
    public void setInvoiceDetailDao(IInvoiceDetailDao invoiceDetailDao) {
        this.invoiceDetailDao = invoiceDetailDao;
    }

}
