package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.DatasourceProperties;
import oracle.retail.reim.utils.Severity;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.retek.reim.business.Location;
import com.retek.reim.business.Order;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.ReceiptWriteOff;
import com.retek.reim.business.SummaryMatchSearchCriteria;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.services.ReceiptService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.lov.ReceiptLOV;

abstract public class AShipmentBean {
    // Attributes from the table
    protected String shipment;

    protected String orderNo;

    protected String asn;

    protected String supplier;

    protected String orderBy = "";

    // the dirty-bit flags for attributes
    protected boolean isShipmentChanged;

    protected boolean isOrderNoChanged;

    protected boolean isASNChanged;

    protected boolean isSupplierChanged;

    protected static final String receipt_cost_discrepancy = "SELECT 'X' FROM IM_DOC_HEAD"
			+ " DH,IM_INVOICE_DETAIL DET,SHIPMENT SH"
			+ " WHERE DH.DOC_ID=DET.DOC_ID"
			+ " AND SH.ORDER_NO=DH.ORDER_NO"
			+ " AND DH.STATUS IN('URMTCH','MURMTH')"
			+ " AND TYPE='MRCHI'"
			+ " AND DET.STATUS='UNMTCH'"
			+ " AND DET.ITEM=?"
			+ " AND DET.COST_MATCHED='N'" + " AND SH.SHIPMENT=?";

    private final String SELECT_RECEIPTS_FOR_WO_SQL = "SELECT S.SHIPMENT,S.RECEIVE_DATE,S.ORDER_NO,S.BILL_TO_LOC,O.SUPPLIER,O.CURRENCY_CODE,O.EXCHANGE_RATE FROM SHIPMENT S,PERIOD P,ORDHEAD O,IM_SUPPLIER_OPTIONS SO,IM_SYSTEM_OPTIONS SYS,SUPS SU WHERE S.ORDER_NO = O.ORDER_NO AND O.SUPPLIER = SU.SUPPLIER AND VDATE >= (S.RECEIVE_DATE + DECODE(NVL(SO.CLOSE_OPEN_SHIPMENT_DAYS, 0),0,SYS.CLOSE_OPEN_RECEIPT_DAYS,SO.CLOSE_OPEN_SHIPMENT_DAYS)) AND S.RECEIVE_DATE IS NOT NULL AND S.STATUS_CODE IN('R', 'U', 'C') AND NVL(S.INVC_MATCH_STATUS, 'U') = 'U' AND NOT EXISTS (SELECT 'X' FROM IM_DOC_HEAD DH,IM_INVOICE_DETAIL DET,SHIPMENT SH WHERE DH.DOC_ID=DET.DOC_ID AND SH.ORDER_NO=DH.ORDER_NO AND DH.STATUS IN('URMTCH','MURMTH') AND TYPE='MRCHI' AND DET.STATUS='UNMTCH' AND SH.SHIPMENT= S.SHIPMENT )";

    protected static final String HIDE_GROUPS_WITH_RECEIPT_OVERAGES_CLAUSE = "  and (1 = decode(sh.invc_match_status, 'U', 1,\n"
            + "                     (SELECT 1\n"
            + "                        FROM im_doc_head dh\n"
            + "                       WHERE dh.order_no = sh.order_no\n"
            + "                         AND dh.LOCATION = sh.bill_to_loc\n"
            + "                         AND dh.TYPE = 'MRCHI'\n"
            + "                         AND dh.status IN (\n" + "'"
            + Document.READY_FOR_MATCH
            + "', '"
            + Document.UNRESOLVED_MATCH
            + "', '"
            + Document.MULTI_UNRESOLVED
            + "', '"
            + Document.DELETE
            + "', '"
            + Document.WGRP
            + "'\n"
            + ")))\n"
            + "           OR NOT EXISTS (SELECT 1\n"
            + "                            FROM im_doc_head dh\n"
            + "                           WHERE dh.order_no = sh.order_no\n"
            + "                             AND dh.LOCATION = sh.bill_to_loc\n"
            + "                             AND dh.TYPE = 'MRCHI')\n"
            + "          )		\n"
            + "      AND (   NOT EXISTS (SELECT 1\n"
            + "                            FROM im_manual_group_receipts gr\n"
            + "                           WHERE gr.shipment = sh.shipment)\n"
            + " 			 OR 1 = decode(sh.invc_match_status, 'U', 1,\n"
            + "                        (SELECT 1\n"
            + "                           FROM im_doc_head dh,\n"
            + "                                im_manual_group_receipts gr,\n"
            + "                                im_manual_group_invoices gi\n"
            + "                          WHERE gr.shipment = sh.shipment\n"
            + "                            AND gr.GROUP_ID = gi.GROUP_ID\n"
            + "                            AND gi.invoice_id = dh.doc_id\n"
            + "                            AND dh.TYPE = 'MRCHI'\n"
            + "                            AND dh.status IN (\n"
            + "'"
            + Document.READY_FOR_MATCH
            + "', '"
            + Document.UNRESOLVED_MATCH
            + "', '"
            + Document.MULTI_UNRESOLVED
            + "', '"
            + Document.DELETE + "', '" + Document.WGRP + "'\n" + "))))";

    public void setShipment(String newShipment) {
        if (newShipment.length() > 0) {
            shipment = newShipment;
            isShipmentChanged = true;
        }
    }

    public void setOrderNo(String newOrderNo) {
        if (newOrderNo.length() > 0) {
            orderNo = newOrderNo;
            isOrderNoChanged = true;
        }
    }

    public void setASN(String newASN) {
        if (newASN.length() > 0) {
            asn = newASN;
            isASNChanged = true;
        }
    }

    public void setSupplier(String newSupplier) {
        if (newSupplier.length() > 0) {
            supplier = newSupplier;
            isSupplierChanged = true;
        }
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = " order by " + orderBy;
    }

    protected StringBuffer selectSQL = new StringBuffer(
            "Select A.SHIPMENT, A.ORDER_NO, A.ASN, B.SUPPLIER ").append(
            "from SHIPMENT A, ORDHEAD B ").append("where A.STATUS_CODE in ('R', 'U', 'C')  AND A.RECEIVE_DATE IS NOT NULL  ").append(
            "and NVL(A.INVC_MATCH_STATUS,'" + Receipt.UNMATCHED + "') = '" + Receipt.UNMATCHED
                    + "' ").append("AND A.ORDER_NO = B.ORDER_NO");

    protected String prependWhere = "";

    public ReceiptLOV[] selectReceipt(boolean matchToLinkedSupplier) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;
        boolean isSupplierSiteIndOn = false;
        try {
        	isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
            .isSupplierSiteInd();
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            String where = constructWhere(matchToLinkedSupplier ,isSupplierSiteIndOn);
            StringBuffer query = selectSQL.append(where).append(orderBy);

            rs = stmt.executeQuery(query.toString());

            ArrayList dataList = new ArrayList(1);
            String asn;
            while (rs.next()) {
                asn = rs.getString(3);
                if (asn == null) {
                    asn = "";
                }
                dataList.add(new ReceiptLOV(rs.getLong(1) + "", rs.getLong(2) + "", asn));
            }

            int l = dataList.size();
            ReceiptLOV data[] = new ReceiptLOV[l];
            dataList.toArray(data);

            return data;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("Error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }

    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes. Currently
    // the implementation of the where clause does not require use of isEmpty
    // as there is always a WHERE specified. If changed to be more dynamic,
    // simply
    // add "where 1=1 " to avoid all the extra logic of isEmpty -- "AND" will
    // always
    // be appended
    protected String constructWhere(boolean matchToLinkedSupplier , boolean isSupplierSiteIndOn) {
        StringBuffer where = new StringBuffer();

        if (prependWhere.length() > 0) {
            where.append(prependWhere);
        }

        if (isShipmentChanged) {
            where.append(" AND A.SHIPMENT LIKE '");
            where.append(shipment);
            where.append("'");
        }

        if (isOrderNoChanged) {
            where.append(" AND A.ORDER_NO=");
            where.append(orderNo);
        }

        if (isASNChanged) {
            where.append("  AND A.ASN=");
            where.append("'");
            where.append(asn);
            where.append("'");
        }

        if (isSupplierChanged) {
            where.append(" AND ");

            if (matchToLinkedSupplier) {
                where.append(" (");
            }

            where.append("B.SUPPLIER=");
            where.append(supplier);

            if(isSupplierSiteIndOn)
            {
            	where.append(" OR B.SUPPLIER IN ( SELECT SUPPLIER FROM SUPS WHERE SUPPLIER_PARENT = " + supplier +")");
            }

            if (matchToLinkedSupplier) {
                where
                        .append(" OR EXISTS (SELECT 'X' FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 ");
                where
                        .append(" WHERE B.SUPPLIER = L2.SUPPLIER_ID AND L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID = ");
                where.append(supplier);
                where.append("))");
            }
        }

        // The complete WHERE clause is returned here
        if (where.length() != 0) {
            return where.toString();
        }

        else {
            return "";
        }
    } // end of whereConstruct

    public Receipt[] selectReceiptsFromInvoiceOrder(String orderNo, String location)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String query = "SELECT A.SHIPMENT, A.ORDER_NO, A.RECEIVE_DATE, A.BILL_TO_LOC BILL_TO_LOC, A.BILL_TO_LOC_TYPE, O.CURRENCY_CODE, A.INVC_MATCH_STATUS FROM SHIPMENT A, ORDHEAD O WHERE A.ORDER_NO = ? AND A.INVC_MATCH_STATUS NOT IN ('C','M') AND A.BILL_TO_LOC = ? AND A.ORDER_NO = O.ORDER_NO AND A.RECEIVE_DATE IS NOT NULL  AND A.STATUS_CODE in ('R', 'U', 'C')";
            stmt = (OraclePreparedStatement) conn.prepareStatement(query);
            stmt.setString(1, orderNo);
            stmt.setString(2, location);
            rs = stmt.executeQuery();

            ArrayList receiptsList = createReceiptFromRS(rs);
            Receipt[] receipts = new Receipt[receiptsList.size()];

            return (Receipt[]) receiptsList.toArray(receipts);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.shipment_bean.get_receipt", Severity.ERROR, e, this);
            }
        }
    }

    public HashMap getReceiptExistenceForInvoices(String docIdsWhereClause) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();
            HashMap receiptsExist = new HashMap();

            StringBuffer query = new StringBuffer("Select B.DOC_ID ");
            query.append("FROM SHIPMENT A, IM_DOC_HEAD B ");
            query.append("WHERE A.ORDER_NO = B.ORDER_NO ");
            query.append("AND NVL(A.BILL_TO_LOC, A.TO_LOC) = B.LOCATION ");
            query.append("AND NVL(A.BILL_TO_LOC_TYPE, A.TO_LOC_TYPE) = B.LOC_TYPE ");
            query.append("AND A.RECEIVE_DATE IS NOT NULL ");
            query.append("AND A.STATUS_CODE IN ('R', 'U', 'C') ");
            query.append("AND B.DOC_ID IN(");

            query.append(" SELECT /*+ index(dh, im_doc_head_i1) */ dh.doc_id FROM im_doc_head dh ");
            query.append(docIdsWhereClause);

            query.append(")");

            rs = stmt.executeQuery(query.toString());

            while (rs.next()) {
                String docId = String.valueOf(rs.getLong("DOC_ID"));
                receiptsExist.put(docId, docId);
            }

            return receiptsExist;
        } catch (Exception e) {
            throw new ReIMException("error.could_not_identify_receipt_existence", Severity.ERROR,
                    e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.could_not_identify_receipt_existence", Severity.ERROR, e, this);
            }
        }
    }

    private ArrayList createReceiptFromRS(ResultSet rs) throws ReIMException {
        ArrayList receipts = new ArrayList();
        Location receiveLoc = new Location();
        long location = Long.MIN_VALUE;
        String orderNo = null;
        String locType = null;

        try {
            while (rs.next()) {
                Receipt receipt = new Receipt();
                receipt.setReceiptId(String.valueOf(rs.getLong("SHIPMENT")));
                location = rs.getLong("BILL_TO_LOC");
                locType = rs.getString("BILL_TO_LOC_TYPE");

                orderNo = String.valueOf(rs.getLong("ORDER_NO"));
                if (rs.wasNull()) {
                    // order number should never be null, we only deal with
                    // orders
                    throw new ReIMException("error.shipment_bean.null_order_no", Severity.ERROR,
                            this, new String[] { receipt.getReceiptId()});
                } else {
                    receipt.setOrderId(orderNo);
                    receipt.setCurrencyCode(rs.getString("CURRENCY_CODE"));
                }
                Date receiptDate = rs.getDate("RECEIVE_DATE");

                if (rs.wasNull()) {
                    receipt.setReceiptDate(null);
                } else {
                    receipt.setReceiptDate(new ReIMDate(receiptDate));
                }
                receipt.setInvoiceMatchStatus(rs.getString("INVC_MATCH_STATUS"));

                ILocationBean locationBean = DaoFactory.getLocationBean();

                if (locType.equals("S")) {
                    receiveLoc.setLocationName(locationBean.selectStoreDesc(location));
                } else {
                    receiveLoc.setLocationName(locationBean.selectWhDesc(location));
                }
                receiveLoc.setLocationId(String.valueOf(location));
                receiveLoc.setLocationType(locType);
                receipt.setReceivingLoc(receiveLoc);

                receipts.add(receipt);
            }

            return receipts;
        } catch (ReIMException e) {
            throw e;
        } catch (SQLException e) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, e, this);
        } catch (Exception e) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, e, this);
        }
    }

    public Receipt readReceipt(String receiptId) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer("S.SHIPMENT = ?");

            DALGenPreparedSQLFragment statementFragment = new DALGenPreparedSQLFragment(whereClause
                    .toString());
            statementFragment.setString(1, receiptId);

            Receipt[] receipt = readReceipts(statementFragment, null);
            if (receipt != null && receipt.length != 0)
                return receipt[0];
            else
                return null;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception ex) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, ex, this);
        }
    }

    private Receipt[] readReceipts(DALGenPreparedSQLFragment whereClause, String orderBy)
            throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs = null;

        Receipt[] receiptArray = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT S.SHIPMENT, S.BILL_TO_LOC BILL_TO_LOC, S.BILL_TO_LOC_TYPE, S.ORDER_NO, S.RECEIVE_DATE, O.CURRENCY_CODE, S.INVC_MATCH_STATUS FROM SHIPMENT S, ORDHEAD O ");

            sqlText.append(" WHERE S.STATUS_CODE in ('R', 'U', 'C') ");
            sqlText.append(" AND S.RECEIVE_DATE IS NOT NULL ");
            sqlText.append("AND S.ORDER_NO = O.ORDER_NO ");

            if (whereClause != null) {
                sqlText.append(" AND ");
                sqlText.append(whereClause.getSQLFragment());
            }

            if (orderBy != null) {
                sqlText.append(" ORDER BY ");
                sqlText.append(orderBy);
            }

            String sqlTxt = sqlText.toString();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            whereClause.callSettersOnPreparedStatement(stmnt, 1);
            rs = stmnt.executeQuery();

            ArrayList receipts = createReceiptFromRS(rs);

            if (receipts.size() > 0) {
                // build a new array sized to the number of elements inserted
                // into the vector
                receiptArray = new Receipt[receipts.size()];
                // copy the vector elements into the array
                receipts.toArray(receiptArray);
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception ex) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, ex, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, ex, this);
            }
        }

        return receiptArray;
    }

    private static final String READ_ITEM_RECEIPTS_BY_PO_LOCATION = "SELECT S.SHIPMENT,I.ITEM,SUM(I.QTY_RECEIVED) AVAILABLE_TO_MATCH_QTY, "
            + " I.UNIT_COST, NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.RECEIVE_DATE, 'N' PARTIALLY_MATCHED  "
            + "  FROM SHIPMENT S,v_im_shipsku I"
            + " WHERE S.SHIPMENT = I.SHIPMENT "
            + " AND NOT EXISTS (SELECT 'X' FROM IM_PARTIALLY_MATCHED_RECEIPTS MR "
            + " WHERE MR.ITEM = I.ITEM "
            + " AND MR.SHIPMENT = S.SHIPMENT) "
            + " AND NOT EXISTS (SELECT 'X' FROM IM_MANUAL_GROUP_RECEIPTS MG "
            + " WHERE MG.SHIPMENT = S.SHIPMENT) "
            + " AND NOT EXISTS (SELECT 'X' FROM IM_QTY_DISCREPANCY QD, IM_QTY_DISCREPANCY_RECEIPT QR "
            + " WHERE QD.QTY_DISCREPANCY_ID = QR.QTY_DISCREPANCY_ID "
            + " AND QD.ITEM = I.ITEM "
            + " AND QR.RECEIPT_ID = S.SHIPMENT) "
            + "   AND NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') = '"
            + Receipt.UNMATCHED
            + "' AND S.STATUS_CODE in ('"
            + Receipt.RECEIVED_STATUS
            + "', '"
            + Receipt.UNMATCHED_STATUS
			+ "', '"
			+ Receipt.CLOSED_STATUS
			+ "') "
                       + " AND S.RECEIVE_DATE IS NOT NULL "

            + "') "
            + "  AND S.ORDER_NO = ?"
            + "   AND S.BILL_TO_LOC = ?"
            + "GROUP BY S.SHIPMENT,I.ITEM, I.UNIT_COST, S.INVC_MATCH_STATUS, S.RECEIVE_DATE"
            + " UNION ALL "
            + "SELECT S.SHIPMENT,I.ITEM,SUM(I.QTY_RECEIVED) - M.QTY_MATCHED AVAILABLE_TO_MATCH_QTY, "
            + " I.UNIT_COST, NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.RECEIVE_DATE, 'Y' PARTIALLY_MATCHED  "
            + "  FROM SHIPMENT S,v_im_shipsku I, IM_PARTIALLY_MATCHED_RECEIPTS M "
            + " WHERE S.SHIPMENT = I.SHIPMENT "
            + " AND M.SHIPMENT = I.SHIPMENT "
            + " AND M.ITEM = I.ITEM "
            + " AND M.QTY_MATCHED < (SELECT SUM(QTY_RECEIVED) FROM v_im_shipsku SS WHERE SS.SHIPMENT = S.SHIPMENT AND SS.ITEM = M.ITEM)"
            + // Only get lines that are partially matched
            " AND NOT EXISTS (SELECT 'X' FROM IM_MANUAL_GROUP_RECEIPTS MG "
            + " WHERE MG.SHIPMENT = S.SHIPMENT) "
            + " AND NOT EXISTS (SELECT 'X' FROM IM_QTY_DISCREPANCY QD, IM_QTY_DISCREPANCY_RECEIPT QR "
            + " WHERE QD.QTY_DISCREPANCY_ID = QR.QTY_DISCREPANCY_ID "
            + " AND QD.ITEM = I.ITEM "
            + " AND QR.RECEIPT_ID = S.SHIPMENT) "
            + "   AND NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') = '"
            + Receipt.UNMATCHED
            + "' AND S.STATUS_CODE in ('"
            + Receipt.RECEIVED_STATUS
            + "', '"
        	+ Receipt.UNMATCHED_STATUS
			+ "', '"
			+ Receipt.CLOSED_STATUS
			+ "') "
                      + " AND S.RECEIVE_DATE IS NOT NULL "

            + "') "
            + "  AND S.ORDER_NO = ?"
            + "   AND S.BILL_TO_LOC = ?"
            + " GROUP BY I.ITEM, S.SHIPMENT, I.UNIT_COST, S.INVC_MATCH_STATUS, S.RECEIVE_DATE, M.QTY_MATCHED ";

    /**
     * This method is called by Automatch and only retrieves the necessary attributes of Receipts
     * and Receipt Items.
     */
    public Receipt[] readItemReceiptsByPOLocation(POLocation poLoc) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(READ_ITEM_RECEIPTS_BY_PO_LOCATION);
            stmt.clearParameters();
            stmt.setString(1, poLoc.getOrder().getOrderNo());

            // For RMS 10.0, this location must be the physical location, not
            // the virtual.
            // Shipments and invoices are always expressed as physical
            // locations.
            stmt.setString(2, poLoc.getLocation().getLocationId());
            stmt.setString(3, poLoc.getOrder().getOrderNo());

            // For RMS 10.0, this location must be the physical location, not
            // the virtual.
            // Shipments and invoices are always expressed as physical
            // locations.
            stmt.setString(4, poLoc.getLocation().getLocationId());

            rs = stmt.executeQuery();

            return createItemReceiptsForPOLocationRS(rs);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception ex) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, ex, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }

    private Receipt[] createItemReceiptsForPOLocationRS(ResultSet rs) throws ReIMException {
        // Receipts by receipt id
        HashMap receipts = new HashMap();
        Receipt[] receiptArray = null;
        Receipt receipt = null;
        ReceiptItem receiptItem = null;
        String currentReceiptId = null;

        try {
            while (rs.next()) {
                receiptItem = new ReceiptItem();
                receiptItem.setItemId(rs.getString("ITEM"));
                receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));

                receiptItem.setPartiallyMatched(rs.getString("PARTIALLY_MATCHED").equals(
                        ReIMConstants.YES) ? true : false);

                currentReceiptId = rs.getString("SHIPMENT");

                // attempt to retrieve the receipt from the already created
                // receipts hashmap
                receipt = (Receipt) receipts.get(currentReceiptId);

                // If this is a new receipt, create a receipt object for it
                if (receipt == null) {
                    // the receipt was not found in the hashmap
                    // create a new Receipt, set the Receipt Item on it and save
                    // it in the HashMap
                    receipt = new Receipt();

                    receipt.setReceiptId(currentReceiptId);

                    // Invoice matching doe not use the RMS partially matched
                    // status, only unmatched
                    receipt.setInvoiceMatchStatus(Receipt.UNMATCHED);

                    if (rs.getDate("RECEIVE_DATE") != null) {
                        receipt.setReceiptDate(new ReIMDate(rs.getDate("RECEIVE_DATE")));
                    } else {
                        receipt.setReceiptDate(null);
                    }

                    // Add the receipt to the receipts collection
                    receipts.put(receipt.getReceiptId(), receipt);
                }

                // Give the receipt item a reference to its receipt
                receiptItem.setReceipt(receipt);

                receiptItem.setCostMatched(ReceiptService.isCostMatched(receiptItem
						.getItemId(),receiptItem
						.getReceiptId()));
                // default to 0 if available to match is null
                receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH_QTY"));

                // add the receipt item to the receipt
                receipt.putReceiptItem(receiptItem.getItemId(), receiptItem);
            }

            if (receipts.size() > 0) {
                receiptArray = new Receipt[receipts.size()];
                receipts.values().toArray(receiptArray);
            }

            return receiptArray;
        } catch (Exception e) {
            throw new ReIMException("error.shipment_bean.createItemReceiptsForPOLocation",
                    Severity.ERROR, e, this);
        }
    }

    private static final String Q1 = "insert into im_order_location_temp(order_no, "
            + "                                   location)  "
            + "                            select /*+ index(dh im_doc_head_i12) */ "
            + "                                   distinct dh.order_no, "
            + "                                   dh.location "
            + "                              from im_doc_head dh, "
            + "                                   ordhead oh "
            + "                             where dh.order_no = oh.order_no and dh.location IN (SELECT DISTINCT COLUMN_VALUE AS location from TABLE(CAST(? as " + DatasourceProperties.schemaOwner.toUpperCase() + ".NUMBERLIST_TBL)) ) "
            + "                               and not exists (select 'x' "
            + "                                                 from im_manual_group_invoices mg "
            + "                                                where dh.doc_id = mg.invoice_id "
            + "                                                  and rownum = 1) "
            + "                               and dh.detail_matched = 'N' "
            + "                               and dh.type = 'MRCHI' "
            + "                               and dh.status in ('RMTCH', 'URMTCH', 'TAXDIS', 'MURMTH') ";

    private static final String Q2 = "insert into im_discrepancy_receipts_temp(receipt_id, "
            + "                                         item) "
            + "                                  select distinct qr.receipt_id, "
            + "                                         qd.item item "
            + "                                    from im_qty_discrepancy qd, "
            + "                                         im_qty_discrepancy_receipt qr "
            + "                                   where qr.qty_discrepancy_id = qd.qty_discrepancy_id and qd.location IN (SELECT DISTINCT COLUMN_VALUE AS location from TABLE(CAST(? as " + DatasourceProperties.schemaOwner.toUpperCase() + ".NUMBERLIST_TBL)) ) ";

    private static final String Q3 = "  select /*+ index(s, shipment_i1) */ "
            + "         olt.order_no, " + "         olt.location, " + "         ss.shipment, "
            + "         ss.item, "
            + "         (sum(ss.qty_received) - nvl(m.qty_matched, 0)) available_to_match_qty, "
            + "         ss.unit_cost, "
            + "         nvl(s.invc_match_status, 'U') invc_match_status, "
            + "         s.receive_date, "
            + "         decode(m.item, null, 'N', 'Y') partially_matched "
            + "    from im_order_location_temp olt, " + "         shipment s, "
            + "         v_im_shipsku ss, " + "         im_manual_group_receipts mg, "
            + "         im_discrepancy_receipts_temp drt, "
            + "         im_partially_matched_receipts m " + "   where m.item (+) = ss.item "
            + "     and m.shipment (+) = ss.shipment " + "     and drt.receipt_id is null "
            + "     and drt.item (+) = ss.item " + "     and drt.receipt_id (+) = ss.shipment "
            + "     and ss.shipment = s.shipment " + "     and mg.shipment is null "
            + "     and mg.shipment (+) = s.shipment "
            + "     and nvl (s.invc_match_status, 'U') = 'U' "
            + "     and s.status_code in ('R', 'U', 'C') " + "     and s.order_no = olt.order_no "
            + "     and s.receive_date is not null "
            + "     and s.bill_to_loc = olt.location " + "group by olt.order_no, "
            + "         olt.location, " + "         ss.shipment, " + "         ss.item, "
            + "         ss.unit_cost, " + "         s.invc_match_status, "
            + "         s.receive_date, " + "         m.item, " + "         m.qty_matched "
            + "  having nvl(m.qty_matched, 0) <= sum(ss.qty_received) " + "order by olt.order_no, "
            + "         olt.location, " + "         ss.shipment ";

    /**
     * This method is called by Automatch and only retrieves the necessary attributes of Receipts
     * and Receipt Items for invoices that are ready for match.
     * @param locationList
     *
     */
    public HashMap readItemReceiptsByPOLocationForReadyForAutoMatch(ArrayList locationList) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String schemaOwner = DatasourceProperties.schemaOwner;

            ArrayDescriptor ad = ArrayDescriptor.createDescriptor(schemaOwner.toUpperCase() + ".NUMBERLIST_TBL",conn);
            ARRAY locationArray = new ARRAY(ad,conn,locationList.toArray());

            stmt = (OraclePreparedStatement) conn.prepareStatement(Q1);
            stmt.setARRAY(1,locationArray);
            stmt.executeQuery();

            stmt = (OraclePreparedStatement) conn.prepareStatement(Q2);
            stmt.setARRAY(1,locationArray);
            stmt.executeQuery();

            stmt = (OraclePreparedStatement) conn.prepareStatement(Q3);
            rs = stmt.executeQuery();

            return createItemReceiptsForPOLocationRSForReadyForMatch(rs);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception ex) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, ex, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }

    private HashMap createItemReceiptsForPOLocationRSForReadyForMatch(ResultSet rs)
            throws ReIMException {
        // Receipts by receipt id
        HashMap poLocRcpts = new HashMap();
        String currentPOLoc = null;
        String previousPOLoc = null;

        String currentShipment = null;
        String previousShipment = null;

        Receipt receipt = null;
        ReceiptItem receiptItem = null;

        ArrayList receiptList = null;

        try {
            while (rs.next()) {
                currentPOLoc = rs.getString("ORDER_NO") + "_" + rs.getString("LOCATION");
                currentShipment = rs.getString("SHIPMENT");

                // Build receiptItem
                receiptItem = new ReceiptItem();
                receiptItem.setItemId(rs.getString("ITEM"));
                receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));

                receiptItem.setPartiallyMatched(rs.getString("PARTIALLY_MATCHED").equals(
                        ReIMConstants.YES) ? true : false);

                if (!currentShipment.equals(previousShipment)) {
                    if (previousShipment != null) {
                        receiptList.add(receipt);
                    }

                    receipt = new Receipt();

                    receipt.setReceiptId(currentShipment);

                    // Invoice matching does not use the RMS partially matched
                    // status, only unmatched
                    receipt.setInvoiceMatchStatus(Receipt.UNMATCHED);
                    receipt.setReceivingLoc(new Location(rs.getString("LOCATION")));

                    if (rs.getDate("RECEIVE_DATE") != null) {
                        receipt.setReceiptDate(new ReIMDate(rs.getDate("RECEIVE_DATE")));
                    } else {
                        receipt.setReceiptDate(null);
                    }
                }

                // Give the receipt item a reference to its receipt
                receiptItem.setReceipt(receipt);
                receiptItem.setCostMatched(ReceiptService.isCostMatched(receiptItem
						.getItemId(),receiptItem
						.getReceiptId()));

                // default to 0 if available to match is null
                receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH_QTY"));


                // add the receipt item to the receipt
                receipt.putReceiptItem(receiptItem.getItemId(), receiptItem);

                if (!currentPOLoc.equals(previousPOLoc)) {
                    if (previousPOLoc != null) {
                        poLocRcpts.put(previousPOLoc, receiptList);
                    }
                    receiptList = new ArrayList();
                }

                previousPOLoc = currentPOLoc;
                previousShipment = currentShipment;
            }

            // process the last result set record
            if (currentPOLoc != null) {
                if (currentShipment != null) {
                    receiptList.add(receipt);
                }
                poLocRcpts.put(currentPOLoc, receiptList);
            }

            return poLocRcpts;
        } catch (Exception e) {
            throw new ReIMException("error.shipment_bean.createItemReceiptsForPOLocation",
                    Severity.ERROR, e, this);
        }
    }

    private static final String GET_ALL_RECEIPTS_BY_PO_LOCATION = "SELECT /*+ FIRST_ROWS */ S.SHIPMENT,I.ITEM,SUM(I.QTY_RECEIVED) QTY_RECEIVED, "
            + "SUM(I.QTY_RECEIVED) - nvl(M.QTY_MATCHED,0) AVAILABLE_TO_MATCH_QTY, "
            + " I.UNIT_COST, NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.RECEIVE_DATE "
            + "  FROM SHIPMENT S,v_im_shipsku I, IM_PARTIALLY_MATCHED_RECEIPTS M  "
            + " WHERE S.SHIPMENT = I.SHIPMENT "
            + " AND S.RECEIVE_DATE IS NOT NULL "
            + " AND M.SHIPMENT(+) = I.SHIPMENT AND M.ITEM(+) = I.ITEM "
            + "   AND S.STATUS_CODE in ('"
            + Receipt.RECEIVED_STATUS
            + "', '"
            + Receipt.UNMATCHED_STATUS
            + "', '"
			+ Receipt.CLOSED_STATUS
			+ "') AND S.INVC_MATCH_STATUS != '"

            + Receipt.MATCHED
            + "' AND S.INVC_MATCH_STATUS != '"
            + Receipt.CLOSED
            + "' AND S.ORDER_NO = ?"
            + "   AND S.BILL_TO_LOC = ?"
            + " AND NOT EXISTS (SELECT 'X'"
            + " FROM im_manual_group_receipts mr "
            + " WHERE s.shipment = mr.shipment )"
            + " GROUP BY I.ITEM, S.SHIPMENT, I.UNIT_COST, S.INVC_MATCH_STATUS, S.RECEIVE_DATE, M.QTY_MATCHED";

    /**
     * This method is called by Summary match and retrieves all receipts and their items,
     * independent of status, for a given po/location.
     */
    public void getAllReceiptsByPOLocation(POLocation poLoc) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement(GET_ALL_RECEIPTS_BY_PO_LOCATION);
            stmt.setString(1, poLoc.getOrder().getOrderNo());
            stmt.setString(2, poLoc.getLocation().getLocationId());

            rs = stmt.executeQuery();
            createAllReceiptsForPOLocationRS(rs, poLoc);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception ex) {
            throw new ReIMException("error.shipment_bean.get_receipt_items_by_polocation",
                    Severity.ERROR, ex, this, new String[] { poLoc.getOrder().getOrderNo(),
                            poLoc.getLocation().getLocationId()});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.shipment_bean.get_receipt_items_by_polocation",
                        Severity.ERROR, ex, this, new String[] { poLoc.getOrder().getOrderNo(),
                                poLoc.getLocation().getLocationId()});
            }
        }
    }

    private void createAllReceiptsForPOLocationRS(ResultSet rs, POLocation poLoc)
            throws ReIMException {
        HashMap receipts = new HashMap();
        Receipt[] receiptArray = null;
        Receipt receipt = null;
        ReceiptItem receiptItem = null;
        String currentReceiptId = null;

        try {
            String orderNo = poLoc.getOrderNo();
            Location location = poLoc.getLocation();
            while (rs.next()) {
                receiptItem = new ReceiptItem();
                receiptItem.setItemId(rs.getString("ITEM"));
                receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));

                // default to 0 if available to match is null
                receiptItem.setQtyReceived(rs.getDouble("QTY_RECEIVED"));
                receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH_QTY"));

                currentReceiptId = rs.getString("SHIPMENT");

                // attempt to retrieve the receipt from the already created
                // receipts hashmap
                receipt = (Receipt) receipts.get(currentReceiptId);

                // If this is a new receipt, create a receipt object for it
                if (receipt == null) {
                    // the receipt was not found in the hashmap
                    // create a new Receipt, set the Receipt Item on it and save
                    // it in the HashMap
                    receipt = new Receipt();

                    receipt.setReceiptId(currentReceiptId);
                    receipt.setOrderId(orderNo);
                    receipt.setReceivingLoc(location);
                    // Invoice matching doe not use the RMS partially matched
                    // status, only unmatched
                    receipt.setInvoiceMatchStatus(rs.getString("INVC_MATCH_STATUS"));

                    if (rs.getDate("RECEIVE_DATE") != null) {
                        receipt.setReceiptDate(new ReIMDate(rs.getDate("RECEIVE_DATE")));
                    } else {
                        receipt.setReceiptDate(null);
                    }
                    // Add the receipt to the receipts collection
                    receipts.put(receipt.getReceiptId(), receipt);
                }

                // Give the receipt item a reference to its receipt
                receiptItem.setReceipt(receipt);
                receiptItem.setCostMatched(ReceiptService.isCostMatched(receiptItem
										.getItemId(),receiptItem
										.getReceiptId()));

                // add the receipt item to the receipt
                receipt.putReceiptItem(receiptItem.getItemId(), receiptItem);
            }

            if (receipts.size() > 0) {
                receiptArray = new Receipt[receipts.size()];
                receipts.values().toArray(receiptArray);
                poLoc.setReceipts(receiptArray);
            }
        } catch (Exception e) {
            throw new ReIMException("error.shipment_bean.createItemReceiptsForPOLocation",
                    Severity.ERROR, e, this);
        }
    }

    private static final String READ_RECEIPTS_BY_RECEIPT_IDS = "SELECT /*+ FIRST_ROWS */ S.SHIPMENT,S.ORDER_NO,S.BILL_TO_LOC BILL_TO_LOC,S.BILL_TO_LOC_TYPE,S.RECEIVE_DATE,I.ITEM,SUM(I.QTY_RECEIVED) QTY_RECEIVED, "
            + " SUM(I.QTY_RECEIVED) - nvl(M.QTY_MATCHED,0) AVAILABLE_TO_MATCH_QTY,"
            + " I.UNIT_COST, NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS"
            + "  FROM SHIPMENT S,v_im_shipsku I, IM_PARTIALLY_MATCHED_RECEIPTS M"
            + " WHERE S.SHIPMENT = I.SHIPMENT "
            + " AND M.SHIPMENT(+) = I.SHIPMENT AND M.ITEM(+) = I.ITEM"
            + " AND S.RECEIVE_DATE IS NOT NULL "
            + "   AND S.STATUS_CODE in ('"
            + Receipt.RECEIVED_STATUS
            + "', '"
            + Receipt.UNMATCHED_STATUS
            + "', '"
			+ Receipt.CLOSED_STATUS
			+ "') AND S.SHIPMENT =? "

            + " GROUP BY S.SHIPMENT, S.ORDER_NO, S.BILL_TO_LOC, S.BILL_TO_LOC_TYPE, S.RECEIVE_DATE, S.INVC_MATCH_STATUS, I.ITEM, I.UNIT_COST, M.QTY_MATCHED";

    public Receipt readReceiptsForMatchingByReceiptId(String receiptId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            if (receiptId != null && receiptId.length() > 0) {
                Connection conn = TransactionManagerFactory.getInstance().getConnection();
                stmt = (OraclePreparedStatement) conn
                        .prepareStatement(READ_RECEIPTS_BY_RECEIPT_IDS);
                stmt.setString(1, receiptId);
                rs = stmt.executeQuery();

                return selectReceiptsByReceiptId(rs);
            } else
                return null;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception ex) {
            throw new ReIMException("error.shipment_bean.get_receipt", Severity.ERROR, ex, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }

    private Receipt selectReceiptsByReceiptId(ResultSet rs) throws ReIMException {
        Receipt receipt = null;
        ReceiptItem receiptItem = null;
        String currentReceipt = null;

        try {
            while (rs.next()) {
                receiptItem = new ReceiptItem();
                currentReceipt = rs.getString("SHIPMENT");

                receiptItem.setReceiptId(currentReceipt);
                receiptItem.setItemId(rs.getString("ITEM"));
                receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));

                // default to 0 if qty_received is null
                receiptItem.setQtyReceived(rs.getDouble("QTY_RECEIVED"));
                receiptItem.setCostMatched(ReceiptService
						.isCostMatched(receiptItem.getItemId(), receiptItem
								.getReceiptId()));
                //receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH_QTY"));

                receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH_QTY"), true);
                if (receipt != null) {
                    // the receipt already exists
                    // set the Receipt Item in the ReceiptItem HashMap on the
                    // receipt
                    receipt.putReceiptItem(receiptItem.getItemId(), receiptItem);
                } else {
                    // the receipt was not found in the hashmap
                    // create a new Receipt, set the Receipt Item on it and save
                    // it in the HashMap
                    receipt = new Receipt();

                    receipt.setReceiptId(currentReceipt);
                    receipt.setOrderId(rs.getString("ORDER_NO"));
                    receipt.setReceivingLoc(new Location(rs.getString("BILL_TO_LOC"), null, rs
                            .getString("BILL_TO_LOC_TYPE")));
                    receipt.setReceiptDate(new ReIMDate(rs.getDate("RECEIVE_DATE")));
                    receipt.setInvoiceMatchStatus(rs.getString("INVC_MATCH_STATUS"));

                    receipt.putReceiptItem(receiptItem.getItemId(), receiptItem);
                }
                // Give the receipt item a reference to its receipt
                receiptItem.setReceipt(receipt);
            }

            return receipt;
        } catch (Exception e) {
            throw new ReIMException("error.shipment_bean.selectReceiptsByReceiptId",
                    Severity.ERROR, e, this);
        }
    }

    public HashMap getReceiptsForMatching(SummaryMatchSearchCriteria searchCriteria)
            throws ReIMException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        boolean isSupplierSiteIndOn = false;

        try {
            isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
                    .isSupplierSiteInd();
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            String sql = buildDynamicWhereClause(searchCriteria, isSupplierSiteIndOn);

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql);

            int i = 1;
            if (searchCriteria.getReceiptItemId() != null
                    && searchCriteria.getReceiptItemId().length() > 0)
                stmt.setString(i++, searchCriteria.getReceiptItemId());
            if (searchCriteria.getSupplierIdList() != null
                    && searchCriteria.getSupplierIdList().size() > 0) {
                if (searchCriteria.getSupplierId() != null
                        && searchCriteria.getSupplierId().length() > 0) {
                    stmt.setLong(i++, Long.parseLong(searchCriteria.getSupplierId()));
                    if (searchCriteria.isIncludeLinkedSuppliers()){
                        stmt.setLong(i++, Long.parseLong(searchCriteria.getSupplierId()));
                    }
                    if(searchCriteria.getSupplierSiteId()!=null && !searchCriteria.getSupplierSiteId().equals("")) {
                        stmt.setLong(i++, Long.parseLong(searchCriteria.getSupplierSiteId()));
                    }
                } else {
                    stmt.setString(i++, searchCriteria.getApReviewer());
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setString(i++, searchCriteria.getApReviewer());
                }
            }
            if (searchCriteria.getReceiptOrderNo() != null
                    && searchCriteria.getReceiptOrderNo().length() > 0) {
                stmt.setLong(i++, Long.parseLong(searchCriteria.getReceiptOrderNo()));
            }
            if (searchCriteria.getReceiptLocationId() != null
                    && searchCriteria.getReceiptLocationId().length() > 0) {
                stmt.setLong(i++, Long.parseLong(searchCriteria.getReceiptLocationId()));
            }
            if (searchCriteria.getReceiptId() != null && searchCriteria.getReceiptId().length() > 0) {
                stmt.setString(i++, searchCriteria.getReceiptId());
            }
            if (searchCriteria.getFromReceiptDate() != null) {
                String fromReceiveDate = formatter.format(searchCriteria.getFromReceiptDate());
                stmt.setString(i++, fromReceiveDate);
            }
            if (searchCriteria.getToReceiptDate() != null) {
                String toReceiptDate = formatter.format(searchCriteria.getToReceiptDate());
                stmt.setString(i++, toReceiptDate);
            }
            if (searchCriteria.getCurrency() != null && searchCriteria.getCurrency().length() > 0) {
                stmt.setString(i++, searchCriteria.getCurrency());
            }
            if (searchCriteria.getFromReceiptCost() != null
                    && searchCriteria.getFromReceiptCost().length() > 0) {
                stmt.setLong(i++, Long.parseLong(searchCriteria.getFromReceiptCost()));
            }
            if (searchCriteria.getToReceiptCost() != null
                    && searchCriteria.getToReceiptCost().length() > 0) {
                stmt.setLong(i++, Long.parseLong(searchCriteria.getToReceiptCost()));
            }

            rs = stmt.executeQuery();

            HashMap map = new HashMap();
            long currentSupplierId = Long.MIN_VALUE;
            long previousSupplierId = -1;
            ArrayList receiptIdList = new ArrayList();
            String receiptId = null;
            String orderNo = null;
            String locationId = null;
            String locType = null;
            Location location = null;
            Receipt receipt = null;
            boolean firstRecord = true;
            while (rs.next()) {
                currentSupplierId = rs.getLong("SUPPLIER");
                receiptId = rs.getString("RECEIPT_ID");
                orderNo = rs.getString("ORDER_NO");
                locationId = rs.getString("LOCATION");
                locType = rs.getString("LOC_TYPE");
                location = new Location();
                location.setLocationId(locationId);
                location.setLocationType(locType);
                receipt = new Receipt();
                receipt.setReceiptId(receiptId);
                receipt.setOrderId(orderNo);
                receipt.setReceivingLoc(location);
                if (firstRecord) {
                    previousSupplierId = currentSupplierId;
                    firstRecord = false;
                }
                if (currentSupplierId != previousSupplierId) {
                    map.put(previousSupplierId + "", receiptIdList);
                    previousSupplierId = currentSupplierId;
                    receiptIdList = new ArrayList();
                    receiptIdList.add(receipt);
                } else {
                    receiptIdList.add(receipt);
                }
            }
            if (currentSupplierId != Long.MIN_VALUE) {
                map.put(currentSupplierId + "", receiptIdList);
            }
            return map;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                        exception, this);

            }
        }
    }

    private String buildDynamicWhereClause(SummaryMatchSearchCriteria searchCriteria,
            boolean isSupplierSiteIndOn) {
        StringBuffer sql = new StringBuffer();

        if (!CollectionUtils.isEmpty(searchCriteria.getSupplierIdList())) {

            if (!StringUtils.isEmpty(searchCriteria.getSupplierId())
                    && !searchCriteria.isIncludeLinkedSuppliers()) {
                sql.append("SELECT /*+ FIRST_ROWS */ ");
            } else if (searchCriteria.isIncludeLinkedSuppliers()) {
                sql.append("SELECT /*+ FIRST_ROWS */ ");
            } else {
                sql.append("SELECT /*+ INDEX(OH ORDHEAD_I2) INDEX(SH SHIPMENT_I1)*/ ");
            }
        } else {
            sql.append("SELECT /*+ INDEX(OH ORDHEAD_I11) INDEX(SH SHIPMENT_I2) */ ");
        }

        if (!StringUtils.isEmpty(searchCriteria.getReceiptItemId())) {
            if (isSupplierSiteIndOn) {
                sql
                        .append(" SH.SHIPMENT RECEIPT_ID, SH.ORDER_NO, SH.BILL_TO_LOC LOCATION, S.SUPPLIER_PARENT SUPPLIER, SH.BILL_TO_LOC_TYPE LOC_TYPE FROM ORDHEAD OH, SHIPMENT SH, v_im_shipsku SK, SUPS S WHERE SH.STATUS_CODE in ('R', 'U', 'C') AND NVL(SH.INVC_MATCH_STATUS,'U') = 'U' AND OH.ORDER_NO = SH.ORDER_NO AND OH.STATUS IN ('A','C') AND SK.SHIPMENT = SH.SHIPMENT AND SH.RECEIVE_DATE IS NOT NULL AND SK.ITEM = ? AND S.SUPPLIER = OH.SUPPLIER ");
            } else {

                sql
                        .append(" SH.SHIPMENT RECEIPT_ID, SH.ORDER_NO, SH.BILL_TO_LOC LOCATION, OH.SUPPLIER, SH.BILL_TO_LOC_TYPE LOC_TYPE FROM ORDHEAD OH, SHIPMENT SH, v_im_shipsku SK WHERE SH.STATUS_CODE in ('R', 'U', 'C') AND NVL(SH.INVC_MATCH_STATUS,'U') = 'U' AND OH.ORDER_NO = SH.ORDER_NO AND OH.STATUS IN ('A','C') AND SK.SHIPMENT = SH.SHIPMENT AND SH.RECEIVE_DATE IS NOT NULL AND SK.ITEM = ? ");

            }

        } else {
            if (isSupplierSiteIndOn) {
                sql
                        .append(" SH.SHIPMENT RECEIPT_ID, SH.ORDER_NO, SH.BILL_TO_LOC LOCATION, S.SUPPLIER_PARENT SUPPLIER, SH.BILL_TO_LOC_TYPE LOC_TYPE FROM ORDHEAD OH, SHIPMENT SH, SUPS S WHERE SH.STATUS_CODE in ('R', 'U', 'C') AND NVL(SH.INVC_MATCH_STATUS, 'U') = 'U' AND OH.ORDER_NO = SH.ORDER_NO AND OH.STATUS IN ('A','C') AND SH.RECEIVE_DATE IS NOT NULL AND S.SUPPLIER = OH.SUPPLIER ");
            } else {

                sql
                        .append(" SH.SHIPMENT RECEIPT_ID, SH.ORDER_NO, SH.BILL_TO_LOC LOCATION, OH.SUPPLIER, SH.BILL_TO_LOC_TYPE LOC_TYPE FROM ORDHEAD OH, SHIPMENT SH WHERE SH.STATUS_CODE in ('R', 'U', 'C') AND NVL(SH.INVC_MATCH_STATUS, 'U') = 'U' AND OH.ORDER_NO = SH.ORDER_NO AND SH.RECEIVE_DATE IS NOT NULL AND OH.STATUS IN ('A','C') ");

            }
        }

        StringBuffer sqlText = new StringBuffer(sql);

        if (!CollectionUtils.isEmpty(searchCriteria.getSupplierIdList())) {
            if (!StringUtils.isEmpty(searchCriteria.getSupplierId())
                    && !searchCriteria.isIncludeLinkedSuppliers()) {
                if (isSupplierSiteIndOn) {
                    sqlText
                            .append(" AND OH.SUPPLIER IN(SELECT SUPPLIER FROM SUPS WHERE SUPPLIER_PARENT = ?");

                    if(searchCriteria.getSupplierSiteId()!=null && !searchCriteria.getSupplierSiteId().equals("")) {
                        sqlText.append(" AND SUPPLIER = ? ");
                    }

                    sqlText.append(" ) ");
                }  else {
                    sqlText.append(" AND OH.SUPPLIER =?");
                }

            } else {
                sqlText.append(" AND OH.SUPPLIER IN (" + searchCriteria.getSupplierIdQuery() + ")");
            }
        }
        if (searchCriteria.getReceiptOrderNo() != null
                && searchCriteria.getReceiptOrderNo().length() > 0) {
            sqlText.append(" AND OH.ORDER_NO = ?");
        }
        if (searchCriteria.getReceiptLocationId() != null
                && searchCriteria.getReceiptLocationId().length() > 0) {
            sqlText.append(" AND SH.BILL_TO_LOC = ?");
        }
        if (searchCriteria.getReceiptId() != null && searchCriteria.getReceiptId().length() > 0) {
            sqlText.append(" AND SH.SHIPMENT LIKE ?");
        }
        if (searchCriteria.getFromReceiptDate() != null) {
            sqlText.append(" AND TRUNC(SH.RECEIVE_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getToReceiptDate() != null) {
            sqlText.append(" AND TRUNC(SH.RECEIVE_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCurrency() != null && searchCriteria.getCurrency().length() > 0) {
            sqlText.append(" AND OH.CURRENCY_CODE = ?");
        }
        if (searchCriteria.getFromReceiptCost() != null
                && searchCriteria.getFromReceiptCost().length() > 0) {
            sqlText
                    .append(" AND (SELECT SUM(SK.UNIT_COST * SK.QTY_RECEIVED ) FROM v_im_shipsku SK WHERE SH.SHIPMENT = SK.SHIPMENT) >= ?");
        }
        if (searchCriteria.getToReceiptCost() != null
                && searchCriteria.getToReceiptCost().length() > 0) {
            sqlText
                    .append(" AND (SELECT SUM(SK.UNIT_COST * SK.QTY_RECEIVED) FROM v_im_shipsku SK WHERE SH.SHIPMENT = SK.SHIPMENT) <= ?");
        }
        if (searchCriteria.isHideGroupsWithReceiptOverages()) {
            sqlText
                    .append(" AND (EXISTS (SELECT 1 FROM IM_DOC_HEAD DH"
                            + "    	   		              WHERE DH.ORDER_NO = SH.ORDER_NO"
                            + " 				                        AND DH.LOCATION = SH.BILL_TO_LOC"
                            + "                                     AND DH.TYPE = '"
                            + Document.MERCHANDISE_INVOICE
                            + "'"
                            + "                                     AND DH.STATUS IN ("
                            + getDocStatusesForHideGroups()
                            + ") "
                            + "                                     OR SH.INVC_MATCH_STATUS = '"
                            + Receipt.UNMATCHED
                            + "')"
                            + "    	   OR NOT EXISTS (SELECT 1 FROM IM_DOC_HEAD DH "
                            + "                              WHERE DH.ORDER_NO = SH.ORDER_NO"
                            + "                                        AND DH.TYPE = '"
                            + Document.MERCHANDISE_INVOICE
                            + "'"
                            + "                                        AND DH.LOCATION = SH.BILL_TO_LOC))"
                            + " AND (NOT EXISTS (SELECT 1 FROM IM_MANUAL_GROUP_RECEIPTS GR WHERE GR.SHIPMENT = SH.SHIPMENT)"
                            + "        OR"
                            + "        EXISTS (SELECT 1 FROM IM_DOC_HEAD DH, IM_MANUAL_GROUP_RECEIPTS GR, IM_MANUAL_GROUP_INVOICES GI"
                            + "                          WHERE GR.SHIPMENT = SH.SHIPMENT"
                            + "                                    AND GR.GROUP_ID = GI.GROUP_ID"
                            + "                                    AND GI.INVOICE_ID = DH.DOC_ID"
                            + "                                    AND DH.TYPE = '"
                            + Document.MERCHANDISE_INVOICE
                            + "'"
                            + "                                    AND DH.STATUS IN ("
                            + getDocStatusesForHideGroups()
                            + ") "
                            + "                                    OR SH.INVC_MATCH_STATUS = '"
                            + Receipt.UNMATCHED + "'))");
        }
        if (isSupplierSiteIndOn) {
            sqlText.append(" ORDER BY S.SUPPLIER_PARENT");
        } else {
            sqlText.append(" ORDER BY OH.SUPPLIER");
        }

        return sqlText.toString();
    }

    private String getDocStatusesForHideGroups() {
        String statusGroup = " '" + Document.READY_FOR_MATCH + "', '" + Document.UNRESOLVED_MATCH
                + "', '" + Document.MULTI_UNRESOLVED + "', '" + Document.DELETE + "', '"
                + Document.WGRP + "' ";

        return statusGroup;
    }

    /**
     * Method updateReceiptInvcMatchedStatusToMatched.
     *
     * This method is temporary and should not be used as a pattern. This table is owned by RMS and
     * more thought should be given to maintenance to RMS tables from outside systems like Invoice
     * Matching.
     *
     * @param matchedReceipts
     * @throws ReIMException
     */
    public void updateReceiptInvcMatchedStatusToMatched(Receipt[] matchedReceipts)
            throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String sql = "UPDATE SHIPMENT SET INVC_MATCH_STATUS = ? WHERE SHIPMENT = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql);

            Receipt receipt = null;
            int receiptsLength = matchedReceipts.length;
            for (int i = 0; i < receiptsLength; i++) {
                receipt = matchedReceipts[i];
                stmt.setString(1, Receipt.MATCHED);
                stmt.setLong(2, Long.parseLong(receipt.getReceiptId()));
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    public boolean receiptExistsForOrderLocation(String receiptId, String orderNo, String locationId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT 'X'"
                    + " FROM SHIPMENT S " + " WHERE S.SHIPMENT = ?" + " AND S.ORDER_NO = ? "
                    + " AND S.BILL_TO_LOC = ?");

            stmt.setLong(1, Long.parseLong(receiptId));
            stmt.setLong(2, Long.parseLong(orderNo));
            stmt.setLong(3, Long.parseLong(locationId));

            rs = stmt.executeQuery();

            if (rs.next())
                return true;
            else
                return false;
        } catch (Exception e) {
            throw new ReIMException("error.receipt_exists_for_order_location", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.receipt_exists_for_order_location", Severity.ERROR, e, this);
            }
        }
    }

    public boolean receiptIsReceivedAndUnmatched(String receiptId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT 'X'" + " FROM SHIPMENT S " + " WHERE S.SHIPMENT = ? "
                    		+ "   AND S.STATUS_CODE in (?, ?, ?) "
        					+ "   AND S.RECEIVE_DATE IS NOT NULL "

                            + "   AND NVL(S.INVC_MATCH_STATUS, ?) = ? ");

            stmt.setLong(1, Long.parseLong(receiptId));
            stmt.setString(2, Receipt.RECEIVED_STATUS);
            stmt.setString(3, Receipt.UNMATCHED_STATUS);
            stmt.setString(4,Receipt.CLOSED_STATUS);
			stmt.setString(5, Receipt.UNMATCHED);
			stmt.setString(6, Receipt.UNMATCHED);


            rs = stmt.executeQuery();

            if (rs.next())
                return true;
            else
                return false;
        } catch (Exception e) {
            throw new ReIMException("error.receipt_status_validation", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.receipt_status_validation", Severity.ERROR, e, this);
            }
        }
    }

    public boolean receiptExistsInManualGroup(String receiptId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT 'X'"
                    + " FROM SHIPMENT S " + " WHERE S.SHIPMENT = ?" + " AND NOT EXISTS (SELECT 'X'"
                    + " FROM IM_MANUAL_GROUP_RECEIPTS MG" + " WHERE MG.SHIPMENT = S.SHIPMENT "
                    + " AND MG.SHIPMENT = ?)");

            stmt.setLong(1, Long.parseLong(receiptId));
            stmt.setLong(2, Long.parseLong(receiptId));

            rs = stmt.executeQuery();

            if (rs.next())
                return true;
            else
                return false;
        } catch (Exception e) {
            throw new ReIMException("error.receipt_manual_group_validation", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.receipt_manual_group_validation", Severity.ERROR, e, this);
            }
        }
    }

    public boolean receiptIsPartOfDiscrepancy(String receiptId, long qtyDiscrepancyId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT 'X'"
                    + " FROM SHIPMENT S " + " WHERE S.SHIPMENT = ?"
                    + "   AND NOT EXISTS (SELECT 'X'"
                    + "                     FROM IM_QTY_DISCREPANCY_RECEIPT Q"
                    + "                    WHERE Q.RECEIPT_ID = S.SHIPMENT "
                    + "                      AND Q.RECEIPT_ID = ? "
                    + "                      AND Q.QTY_DISCREPANCY_ID = ?)");

            stmt.setLong(1, Long.parseLong(receiptId));
            stmt.setLong(2, Long.parseLong(receiptId));
            stmt.setLong(3, qtyDiscrepancyId);

            rs = stmt.executeQuery();

            if (rs.next())
                return true;
            else
                return false;
        } catch (Exception e) {
            throw new ReIMException("error.receipt_discrepancy_validation", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.receipt_discrepancy_validation", Severity.ERROR, e, this);
            }
        }
    }

    public ReceiptWriteOff[] getOpenReceiptsForClosing() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        boolean isSupplierSiteIndOn = false;
        final StringBuffer openReceiptsSql = new StringBuffer(SELECT_RECEIPTS_FOR_WO_SQL);

        try {
        	isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService()
					.getSystemOptions().isSupplierSiteInd();

        	ReceiptWriteOff[] receiptWriteOffArray = null;

            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            if (isSupplierSiteIndOn) {
            	openReceiptsSql.append(" AND NVL(SU.SUPPLIER_PARENT, SU.SUPPLIER) = SO.SUPPLIER");
            } else {
            	openReceiptsSql.append(" AND SU.SUPPLIER = SO.SUPPLIER");
            }

            stmt = (OraclePreparedStatement) conn.prepareStatement(openReceiptsSql.toString());

            rs = stmt.executeQuery();

            List<ReceiptWriteOff> receiptWriteOffs = new ArrayList<ReceiptWriteOff>();
            while (rs.next()) {
                ReceiptWriteOff receiptWriteOff = new ReceiptWriteOff();

                receiptWriteOff.setReceiptNumber(rs.getLong("SHIPMENT"));

                Date date = rs.getDate("RECEIVE_DATE");
                if (!rs.wasNull()) receiptWriteOff.setReceiptDate(new ReIMDate(date));

                receiptWriteOff.setLocation(new Location(rs.getString("BILL_TO_LOC")));

                Order order = new Order(rs.getString("ORDER_NO"));
                order.setSupplier(new Supplier(rs.getString("SUPPLIER")));
                order.setOrderCurrency(rs.getString("CURRENCY_CODE"));
                order.setOrderExchangeRate(Double.valueOf(rs.getString("EXCHANGE_RATE")));
                receiptWriteOff.setOrder(order);

                receiptWriteOffs.add(receiptWriteOff);
            }

            if (receiptWriteOffs.size() > 0) {
                receiptWriteOffArray = new ReceiptWriteOff[receiptWriteOffs.size()];
                receiptWriteOffs.toArray(receiptWriteOffArray);
            }

            return receiptWriteOffArray;
        } catch (Exception e) {
            throw new ReIMException("error.get_open_receipts_for_closing", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.get_open_receipts_for_closing", Severity.ERROR, e, this);
            }
        }
    }

    /**
     * This method will retrieve the latest receipt date for an invoice that is matched through
     * manual detail matching. It will check the detail match history to find out all the receipts
     * that are matched to the invoice through detail matching.
     *
     * @see com.retek.reim.foundation.AShipmentBean#getLatestReceiptOfGoodsDate(long)
     */
    public ReIMDate getLatestReceiptOfGoodsDate(long invoiceId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("select max(receive_date) from shipment "
                            + " where shipment in (select receipt_id "
                            + "                      from im_detail_match_rcpt_history rh "
                            + "                     where match_id in (select match_id "
                            + "                                          from im_detail_match_invc_history "
                            + "                                         where invoice_id = ?)) ");

            stmt.setLong(1, invoiceId);
            rs = stmt.executeQuery();

            if (rs.next())
                return new ReIMDate(rs.getDate(1));
            else
                return null;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_get_latest_receipt_date", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.cannot_get_latest_receipt_date", Severity.ERROR, e, this);
            }
        }
    }

    public void lockReceiptGroup(Receipt[] receipts) throws ReIMException, SQLException {
        OraclePreparedStatement stmt = null;
        try {
            StringBuffer sql = new StringBuffer(
                    "SELECT 'x' FROM SHIPMENT WHERE SHIPMENT.SHIPMENT in (");

            for (int i = 0; i < receipts.length; i++) {
                sql.append(receipts[i].getReceiptId());
                if (i + 1 % 1000 == 0) {
                    sql.append(") FOR UPDATE NOWAIT");
                    Connection conn = TransactionManagerFactory.getInstance().getConnection();
                    stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
                    stmt.execute();
                    sql = new StringBuffer("SELECT 'x' FROM SHIPMENT WHERE SHIPMENT.SHIPMENT in (");
                } else if (i + 1 == receipts.length) {
                    sql.append(") FOR UPDATE NOWAIT");
                    Connection conn = TransactionManagerFactory.getInstance().getConnection();
                    stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
                    stmt.execute();
                } else {
                    sql.append(", ");
                }
            }
        } catch (SQLException exception) {
            if (exception.getMessage().equals(
                    "ORA-00054: resource busy and acquire with NOWAIT specified\n")) {
                throw exception;
            } else {
                throw new ReIMException("error.shipment_bean.lock", Severity.ERROR, exception, this);
            }
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.shipment_bean.lock", Severity.ERROR, exception, this);
            }
        }
    }

    public void updateReceiptInvcMatchedStatus(ArrayList receits, String newStatus)
            throws ReIMException {
        if (receits == null || (receits != null && receits.size() == 0)) { return; }

        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        long shipmentId = 0;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if(newStatus!=null && newStatus.equalsIgnoreCase(Receipt.UNMATCHED))
            {
            	 stmt = (OraclePreparedStatement) conn
                 .prepareStatement("UPDATE SHIPMENT SET INVC_MATCH_STATUS = ? , INVC_MATCH_DATE = NULL WHERE SHIPMENT = ?");
            }
            else{
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("UPDATE SHIPMENT SET INVC_MATCH_STATUS = ? WHERE SHIPMENT = ?");
            }
            for (int i = 0; i < receits.size(); i++) {
                shipmentId = ((Long) receits.get(i)).longValue();
                stmt.setString(1, newStatus);
                stmt.setLong(2, shipmentId);
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_get_latest_receipt_date", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException(
                        "error.cannot_get_latest_receipt_date", Severity.ERROR, e, this);
            }
        }
    }

    /**
	 * @param item
	 * @param shipment
	 * @return
	 * @throws ReIMException
	 * This method determines whether an item of a receipt has cost
	 * discrepancy or not
	 */
	public boolean isCostMatched(long item, long shipment) throws ReIMException {
		OraclePreparedStatement stmt = null;
		ResultSet rs = null;
		TransactionManagerFactory.getInstance().start();
		try {

			Connection conn = TransactionManagerFactory.getInstance()
					.getConnection();
			stmt = (OraclePreparedStatement) conn
					.prepareStatement(receipt_cost_discrepancy);
			stmt.setString(1, Long.toString(item));
			stmt.setLong(2, shipment);
			rs = stmt.executeQuery();
			if (rs != null && rs.next()) {
				return false;
			} else {
				return true;
			}

		} catch (Exception e) {
			throw new ReIMException("error.cannot_get_latest_receipt_date",
					Severity.ERROR, e, this);
		} finally {
			try {
				TransactionManagerFactory.getInstance().end();
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception e) {
				throw new ReIMException(
						"error.cannot_get_latest_receipt_date", Severity.ERROR,
						e, this);
			}
		}
	}

	public String receiptIsPartOfCrossDockPO(String orderNo, String location) throws ReIMException {
    	if(StringUtils.isEmpty(orderNo) || StringUtils.isEmpty(location)) {
    		return null;
    	}

    	OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement("" +
            		"SELECT TO_LOC, BILL_TO_LOC FROM SHIPMENT WHERE ORDER_NO = ? AND BILL_TO_LOC=?");

            stmt.setLong(1, Long.parseLong(orderNo));
            stmt.setLong(2, Long.parseLong(location));
            String toLocation="";
            String matchLocation="";
            rs = stmt.executeQuery();

            if(rs != null && rs.next()) {
            	 toLocation = rs.getString("TO_LOC");
            	 matchLocation = rs.getString("BILL_TO_LOC");

            	if(StringUtils.isEmpty(toLocation) || StringUtils.isEmpty(matchLocation)) {
            		return ReIMConstants.NO;
            	} else if((toLocation.trim()).equalsIgnoreCase((matchLocation.trim()))) {
            		return ReIMConstants.NO;
            	} else {
            		return ReIMConstants.YES;
            	}

            }


        } catch (Exception e) {
        	throw new ReIMException("error occoured in database connection", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("connection already closed", Severity.ERROR, e, this);
            }
        }
    	return "N";
    }

	public String findReceipt(long docId,String orderNo) throws ReIMException {
		OraclePreparedStatement stmt = null;
		ResultSet resultSet = null;

	try {
	Connection conn = TransactionManagerFactory.getInstance().getConnection();

	String sqlQuery = "SELECT  DISTINCT sk.shipment shipment FROM shipsku sk, shipment sh, im_doc_head idh, im_invoice_detail iid " +
	" WHERE sh.to_loc = idh.location" +
	" AND idh.doc_id = iid.doc_id " +
	" AND sk.shipment = sh.shipment " +
	"AND sh.invc_match_status  = 'U' " +
	"AND sk.item = iid.item " +
	"AND idh.order_no = ? " +
	"AND idh.doc_id = ? " +
	"AND sh.order_no = ? ";

	stmt = (OraclePreparedStatement) conn.prepareStatement(sqlQuery);
	stmt.setString(1, orderNo);
	stmt.setLong(2, docId);
	stmt.setString(3, orderNo);
	resultSet = stmt.executeQuery();
	String receiptId = null ;
	if(resultSet.next())
		{
		receiptId = resultSet.getString("SHIPMENT");
		}

	return receiptId;
	} catch (Exception exception) {
	throw new ReIMException("error.shipment_bean.get_receipt",					Severity.ERROR, exception, this);
	}
	 finally {
	try {
		if (resultSet != null) {
		resultSet.close();
			}
	if (stmt != null) {
		stmt.close();
			}
		} catch (Exception e) {throw new ReIMException(
	"error.shipment_bean.get_receipt.close_stmt_rs",
		Severity.ERROR, e, this);
				}
			}
		}
}