package com.retek.reim.db;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleStatement;
import oracle.retail.reim.business.DocumentItemReasonCodeStatus;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.deal.DealId;
import oracle.retail.reim.business.deal.DealType;
import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.document.HoldStatus;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.MatchLevel;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.*;


import org.apache.commons.lang.StringUtils;

import com.retek.merch.utils.Utility;
import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.business.ByteLengths;
import com.retek.reim.business.CreditNoteSummaryMatchSearchCriteria;
import com.retek.reim.business.Location;
import com.retek.reim.business.Order;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.ResolutionMerchandiseInvoice;
import com.retek.reim.business.SummaryMatchSearchCriteria;
import com.retek.reim.business.document.CreditNote;
import com.retek.reim.business.document.CreditRequest;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemReasonCode;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.document.ResolutionDocument;
import com.retek.reim.foundation.OracleDocIDObject;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.invoiceMaintenance.DocumentSearchCriteria;
import com.retek.reim.ui.lov.DocumentLOV;
import com.retek.reim.ui.lov.LovUtils;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		13-May-2013	Syed Qadri		Modification Change :Commented out the SELECT statement to use the new one. IMS Ticket # 160668 (Release 1549). This is for 
 * 		                                                         performance enhancement according Metalink Doc id 847827 applied Bug fix 8507757.
 *    1.3		07-Apr-2015	 Naveen J	ME 426347  426347-EDI - EZCOM 810/856 Duplication Issue - modified query   READ_EXT_DOC_ID_BY_VENDOR		
 * 								
 */

public class ImDocHeadAccessExt extends ImDocHeadAccess implements IImDocHeadAccessExt {
    private static final String SELECT_VENDOR = "SELECT DISTINCT VENDOR FROM IM_DOC_HEAD WHERE GROUP_ID IS NOT NULL  AND VENDOR_TYPE = ?";

    private static final String UPDATE_STATUS_BY_GROUP_ID = "UPDATE IM_DOC_HEAD SET STATUS = ?, LAST_UPDATE_ID = ?, LAST_DATETIME = ? WHERE GROUP_ID = ?";

    private static final String UPDATE_STATUS_BY_DOC_ID_FOR_DETAILS_MATCHED = "UPDATE IM_DOC_HEAD SET IM_DOC_HEAD.STATUS='MTCH',IM_DOC_HEAD.LAST_UPDATE_ID = ?, IM_DOC_HEAD.MATCH_ID = ?, IM_DOC_HEAD.MATCH_DATE = ?, IM_DOC_HEAD.LAST_DATETIME = ? WHERE IM_DOC_HEAD.DOC_ID = ? AND NOT EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL D WHERE D.DOC_ID = ? AND D.STATUS = 'UNMTCH') ";

    private static final String UPDATE_STATUS_BY_DOC_ID = "UPDATE IM_DOC_HEAD SET STATUS = ? , IM_DOC_HEAD.LAST_UPDATE_ID = ?, IM_DOC_HEAD.LAST_DATETIME = ? WHERE DOC_ID = ? ";

    private static final String UPDATE_STATUS_TO_APPROVED_BY_DOC_ID = "UPDATE IM_DOC_HEAD SET STATUS = ? , IM_DOC_HEAD.LAST_UPDATE_ID = ?, IM_DOC_HEAD.LAST_DATETIME = ?, IM_DOC_HEAD.APPROVAL_ID = ?, IM_DOC_HEAD.APPROVAL_DATE = ? WHERE DOC_ID = ? ";

    // NJ 1.3 Inserted - Begin
    // old code
    //       private static final String READ_EXT_DOC_ID_BY_VENDOR = "SELECT EXT_DOC_ID FROM IM_DOC_HEAD ID WHERE ID.VENDOR_TYPE = ? AND ID.VENDOR = ? AND ID.EXT_DOC_ID = ? AND ID.STATUS <> 'DELETE' union select EXT_DOC_ID from im_edi_reject_doc_head IED where IED.VENDOR_TYPE = ? AND IED.VENDOR = ? AND IED.EXT_DOC_ID = ? ";
    // new code  
    		private static final String READ_EXT_DOC_ID_BY_VENDOR = "SELECT EXT_DOC_ID FROM IM_DOC_HEAD ID WHERE ID.VENDOR_TYPE = ? AND ID.VENDOR = ? AND trim(ID.EXT_DOC_ID) = ? AND ID.STATUS <> 'DELETE' union select EXT_DOC_ID from im_edi_reject_doc_head IED where IED.VENDOR_TYPE = ? AND IED.VENDOR = ? AND trim(IED.EXT_DOC_ID) = ? ";
    // NJ V1.2 Inserted - End
    

    private static final String READ_EXT_DOC_ID = " SELECT EXT_DOC_ID FROM IM_DOC_HEAD WHERE DOC_ID = ? ";

    private static final String SELECT_FOR_GET_MERCHANDISE_DOC_HEAD_WITH_TAX = "SELECT DH.ORDER_NO, "
            // potential hint: /*+ INDEX(DH IM_DOC_HEAD_I10) INDEX(OH
            // PK_ORDHEAD) */
            + "DH.LOCATION, DH.LOC_TYPE, DH.VENDOR, DH.DOC_ID, DH.EXT_DOC_ID, TERMS_DSCNT_PCT, "
            + "DH.DOC_DATE, DH.TOTAL_COST, DH.TOTAL_QTY, DH.RESOLUTION_ADJUSTED_TOTAL_COST, "
            + "DH.RESOLUTION_ADJUSTED_TOTAL_QTY, DH.DUE_DATE, DH.STATUS, DH.CURRENCY_CODE INVOICE_CURRENCY_CODE, "
            + "DH.FREIGHT_TYPE, DH.TOTAL_DISCOUNT, DH.GROUP_ID, DH.CREATE_DATE, DH.CREATE_ID, DH.VENDOR_TYPE, "
            + "DH.EDI_UPLOAD_IND, DH.EDI_DOWNLOAD_IND, DH.TERMS, DH.PAYMENT_METHOD, DH.MATCH_ID, DH.MATCH_DATE, "
            + "DH.APPROVAL_ID, DH.APPROVAL_DATE, DH.PRE_PAID_IND, DH.PRE_PAID_ID, DH.POST_DATE, DH.MANUALLY_PAID_IND, "
            + "DH.CONSIGNMENT_IND, DH.RTV_IND, DH.CUSTOM_DOC_REF_1, DH.CUSTOM_DOC_REF_2, DH.CUSTOM_DOC_REF_3, "
            + "DH.CUSTOM_DOC_REF_4, DH.LAST_UPDATE_ID, DH.LAST_DATETIME, DH.BEST_TERMS, DH.BEST_TERMS_DATE, "
            + "DH.BEST_TERMS_DATE_SOURCE, DH.BEST_TERMS_SOURCE, DH.EXCHANGE_RATE, DH.DEAL_ID, DH.DEAL_TYPE, "
            + "DH.VARIANCE_WITHIN_TOLERANCE, DH.TAX_DISC_CREATE_DATE, DH.TOTAL_COST_INC_TAX, "
            + "TAXES.TAX_CODE, TAXES.TAX_RATE, TAXES.BASIS, TAXES.MERCH_IND ";

    private static final String FROM_FOR_GET_MERCHANDISE_DOC_HEAD_WITH_TAX = "FROM IM_DOC_HEAD DH, "
            // This hint may be needed for performance /*+ INDEX(idv
            // IM_DOC_TAX_I1)*/
            + "(SELECT IDT.DOC_ID, TAX_CODE, TAX_RATE, TAX_BASIS AS BASIS, 1 AS MERCH_IND "
            + "     FROM IM_DOC_TAX IDT UNION ALL "
            + "          SELECT IDNMT.DOC_ID, IDNMT.TAX_CODE, IDNMT.TAX_RATE, IDNMT.TAX_BASIS AS BASIS, 0 AS MERCH_IND "
            + "               FROM IM_DOC_NON_MERCH_TAX IDNMT ) TAXES ";

    private static final String WHERE_FOR_GET_MERCHANDISE_DOC_HEAD_WITH_TAX = "WHERE "
            + "DH.DOC_ID = TAXES.DOC_ID(+) AND DH.DOC_ID = ?";

    private static final String SELECT_FOR_RESOLUTION_DOCUMENT_WITH_NON_MERCH_TOTAL = "SELECT SUM(NON_MERCH_AMT) NON_MERCH_AMT_TOTAL, IM_DOC_HEAD.DOC_ID,IM_DOC_HEAD.TYPE,IM_DOC_HEAD.STATUS,IM_DOC_HEAD.ORDER_NO,IM_DOC_HEAD.LOCATION,IM_DOC_HEAD.LOC_TYPE,IM_DOC_HEAD.TOTAL_DISCOUNT,IM_DOC_HEAD.GROUP_ID,IM_DOC_HEAD.PARENT_ID,IM_DOC_HEAD.DOC_DATE,IM_DOC_HEAD.CREATE_DATE,IM_DOC_HEAD.CREATE_ID,IM_DOC_HEAD.VENDOR_TYPE,IM_DOC_HEAD.VENDOR,IM_DOC_HEAD.EXT_DOC_ID,IM_DOC_HEAD.EDI_UPLOAD_IND,IM_DOC_HEAD.EDI_DOWNLOAD_IND,IM_DOC_HEAD.TERMS,IM_DOC_HEAD.TERMS_DSCNT_PCT,IM_DOC_HEAD.DUE_DATE,IM_DOC_HEAD.PAYMENT_METHOD,IM_DOC_HEAD.MATCH_ID,IM_DOC_HEAD.MATCH_DATE,IM_DOC_HEAD.APPROVAL_ID,IM_DOC_HEAD.APPROVAL_DATE,IM_DOC_HEAD.PRE_PAID_IND,IM_DOC_HEAD.PRE_PAID_ID,IM_DOC_HEAD.POST_DATE,IM_DOC_HEAD.CURRENCY_CODE,IM_DOC_HEAD.EXCHANGE_RATE,IM_DOC_HEAD.TOTAL_COST,IM_DOC_HEAD.TOTAL_QTY,IM_DOC_HEAD.MANUALLY_PAID_IND,IM_DOC_HEAD.CUSTOM_DOC_REF_1,IM_DOC_HEAD.CUSTOM_DOC_REF_2,IM_DOC_HEAD.CUSTOM_DOC_REF_3,IM_DOC_HEAD.CUSTOM_DOC_REF_4,IM_DOC_HEAD.LAST_UPDATE_ID,IM_DOC_HEAD.LAST_DATETIME,IM_DOC_HEAD.FREIGHT_TYPE,IM_DOC_HEAD.REF_DOC,IM_DOC_HEAD.REF_AUTH_NO,IM_DOC_HEAD.COST_PRE_MATCH,IM_DOC_HEAD.DETAIL_MATCHED,IM_DOC_HEAD.BEST_TERMS,IM_DOC_HEAD.BEST_TERMS_SOURCE,IM_DOC_HEAD.BEST_TERMS_DATE,IM_DOC_HEAD.BEST_TERMS_DATE_SOURCE,IM_DOC_HEAD.VARIANCE_WITHIN_TOLERANCE,IM_DOC_HEAD.RESOLUTION_ADJUSTED_TOTAL_COST,IM_DOC_HEAD.RESOLUTION_ADJUSTED_TOTAL_QTY,IM_DOC_HEAD.CONSIGNMENT_IND,IM_DOC_HEAD.DEAL_ID,IM_DOC_HEAD.RTV_IND,IM_DOC_HEAD.DISCOUNT_DATE,IM_DOC_HEAD.DEAL_TYPE,IM_DOC_HEAD.TOTAL_COST_INC_TAX,IM_DOC_HEAD.TAX_DISC_CREATE_DATE, IM_DOC_HEAD.HOLD_STATUS   "
            + " FROM IM_DOC_HEAD, IM_DOC_NON_MERCH dnm, TABLE(CAST(? as "
            + Utility.getApplicationValue("datasource.schema.owner")
            + ".OBJ_DOC_ID_TBL) ) di \n"
            + " WHERE IM_DOC_HEAD.DOC_ID = dnm.doc_id (+) and IM_DOC_HEAD.doc_id = di.doc_id and IM_DOC_HEAD.status != 'MTCH' "
            + " group by IM_DOC_HEAD.DOC_ID,IM_DOC_HEAD.TYPE,IM_DOC_HEAD.STATUS,IM_DOC_HEAD.ORDER_NO,IM_DOC_HEAD.LOCATION,IM_DOC_HEAD.LOC_TYPE,IM_DOC_HEAD.TOTAL_DISCOUNT,IM_DOC_HEAD.GROUP_ID,IM_DOC_HEAD.PARENT_ID,IM_DOC_HEAD.DOC_DATE,IM_DOC_HEAD.CREATE_DATE,IM_DOC_HEAD.CREATE_ID,IM_DOC_HEAD.VENDOR_TYPE,IM_DOC_HEAD.VENDOR,IM_DOC_HEAD.EXT_DOC_ID,IM_DOC_HEAD.EDI_UPLOAD_IND,IM_DOC_HEAD.EDI_DOWNLOAD_IND,IM_DOC_HEAD.TERMS,IM_DOC_HEAD.TERMS_DSCNT_PCT,IM_DOC_HEAD.DUE_DATE,IM_DOC_HEAD.PAYMENT_METHOD,IM_DOC_HEAD.MATCH_ID,IM_DOC_HEAD.MATCH_DATE,IM_DOC_HEAD.APPROVAL_ID,IM_DOC_HEAD.APPROVAL_DATE,IM_DOC_HEAD.PRE_PAID_IND,IM_DOC_HEAD.PRE_PAID_ID,IM_DOC_HEAD.POST_DATE,IM_DOC_HEAD.CURRENCY_CODE,IM_DOC_HEAD.EXCHANGE_RATE,IM_DOC_HEAD.TOTAL_COST,IM_DOC_HEAD.TOTAL_QTY,IM_DOC_HEAD.MANUALLY_PAID_IND,IM_DOC_HEAD.CUSTOM_DOC_REF_1,IM_DOC_HEAD.CUSTOM_DOC_REF_2,IM_DOC_HEAD.CUSTOM_DOC_REF_3,IM_DOC_HEAD.CUSTOM_DOC_REF_4,IM_DOC_HEAD.LAST_UPDATE_ID,IM_DOC_HEAD.LAST_DATETIME,IM_DOC_HEAD.FREIGHT_TYPE,IM_DOC_HEAD.REF_DOC,IM_DOC_HEAD.REF_AUTH_NO,IM_DOC_HEAD.COST_PRE_MATCH,IM_DOC_HEAD.DETAIL_MATCHED,IM_DOC_HEAD.BEST_TERMS,IM_DOC_HEAD.BEST_TERMS_SOURCE,IM_DOC_HEAD.BEST_TERMS_DATE,IM_DOC_HEAD.BEST_TERMS_DATE_SOURCE,IM_DOC_HEAD.VARIANCE_WITHIN_TOLERANCE,IM_DOC_HEAD.RESOLUTION_ADJUSTED_TOTAL_COST,IM_DOC_HEAD.RESOLUTION_ADJUSTED_TOTAL_QTY,IM_DOC_HEAD.CONSIGNMENT_IND,IM_DOC_HEAD.DEAL_ID,IM_DOC_HEAD.RTV_IND,IM_DOC_HEAD.DISCOUNT_DATE,IM_DOC_HEAD.DEAL_TYPE,IM_DOC_HEAD.TOTAL_COST_INC_TAX,IM_DOC_HEAD.TAX_DISC_CREATE_DATE, IM_DOC_HEAD.HOLD_STATUS ";

    private final static String SELECT_DOC_FROM_EXT_DOC_ID_AND_VENDOR = "SELECT IMDH.STATUS FROM IM_DOC_HEAD IMDH WHERE IMDH.EXT_DOC_ID = ? AND IMDH.VENDOR = ?";

    public void deleteDocument(long docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            // Delete detail comments
            String sql = "DELETE FROM IM_DOC_DETAIL_COMMENTS WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, docId);
            stmt.executeUpdate();
            if (stmt != null) stmt.close();

            // Delete comments
            sql = "DELETE FROM IM_DOC_HEAD_COMMENTS WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, docId);
            stmt.executeUpdate();
            if (stmt != null) stmt.close();

            // Delete details reason codes
            sql = "DELETE FROM IM_DOC_DETAIL_REASON_CODES WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, docId);
            stmt.executeUpdate();
            if (stmt != null) stmt.close();

            // Delete details
            sql = "DELETE FROM IM_INVOICE_DETAIL WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, docId);
            stmt.executeUpdate();
            if (stmt != null) stmt.close();

            // Delete non merch costs
            sql = "DELETE FROM IM_DOC_NON_MERCH WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, docId);
            stmt.executeUpdate();
            if (stmt != null) stmt.close();

            // Finally delete head
            sql = "DELETE FROM IM_DOC_HEAD WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, docId);
            stmt.executeUpdate();
            if (stmt != null) stmt.close();

        } catch (Exception exception) {
            throw new ReIMException("error.unable_to_delete_document", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.unable_to_delete_document", Severity.ERROR,
                        exception, this);

            }
        }
    }

    public boolean docHeadExist(String vendor, String extDocId) throws ReIMException {
        return docHeadExist(vendor, extDocId, null);
    }

    public boolean docHeadExist(String vendor, String extDocId, String docType)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer sql = new StringBuffer("SELECT EXT_DOC_ID FROM IM_DOC_HEAD");
            sql.append(" WHERE VENDOR = ? AND EXT_DOC_ID = ?");
            if (docType != null) {
                sql.append(" AND TYPE = ?");
            }
            sql.append(" AND STATUS != 'DELETE'");
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setString(1, vendor);
            stmt.setString(2, extDocId);
            if (docType != null) {
                stmt.setString(3, docType);
            }

            rs = stmt.executeQuery();

            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }
    private static final String SELECT_MATCH_CNR = "SELECT DISTINCT EXT_DOC_ID FROM IM_DOC_HEAD IDH, IM_MATCH_DOC MD WHERE MD.PROCESS_ID = ? AND MD.CONFIG_ID = ? AND MD.SUPPLIER = ? AND MD.MATCH_LEVEL = ? AND MD.DOC_REF = IDH.DOC_ID AND MD.DOC_TYPE IN ('CRDNRC', 'CRDNRQ', 'CRDNRT')";
    public String[] readDocumentsAssociatedWithMatch(Long processId, Long configId, Long supplier, MatchLevel matchLevel) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList arrayList = new ArrayList();
        String[] extDocIds =null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_MATCH_CNR);
            stmt.setLong(1, processId);
            stmt.setLong(2, configId);
            stmt.setLong(3, supplier);
            stmt.setString(4, matchLevel.getCode());

            rs = stmt.executeQuery();
            while (rs.next()) {
                arrayList.add(rs.getString(1));
            }
            if(arrayList.size()>0)
            {
                extDocIds = (String[]) arrayList.toArray(new String[arrayList.size()]);
            }
            return extDocIds;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }

    public String documentExists(String extDocId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer sql = new StringBuffer("SELECT DOC_ID FROM IM_DOC_HEAD");
            sql.append(" WHERE EXT_DOC_ID = ? AND");
            sql.append(" (TYPE = ? OR TYPE = ? OR TYPE = ? OR TYPE = ?)");
            sql.append(" AND STATUS != 'DELETE'");
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setString(1, extDocId);
            stmt.setString(2, Document.CREDIT_NOTE_REQUEST_PRICE);
            stmt.setString(3, Document.CREDIT_NOTE_REQUEST_QUANTITY);
            stmt.setString(4, Document.DEBIT_MEMO_PRICE);
            stmt.setString(5, Document.DEBIT_MEMO_QUANTITY);

            rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("DOC_ID");
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }

    public String[] selectVendor(String vendorType) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList arrayList = new ArrayList();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_VENDOR);
            stmt.setString(1, vendorType);

            rs = stmt.executeQuery();

            while (rs.next()) {
                String vendorId = rs.getString(1);
                arrayList.add(vendorId);
            }

            String[] vendorIds = (String[]) arrayList.toArray(new String[arrayList.size()]);
            return vendorIds;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);

            }
        }
    }

    public Document[] readByGroupId(long groupId) throws ReIMException {
        try {
            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment(groupIdColumn
                    + " = ? AND " + statusColumn + " = 'WGRP' ");
            // + " = ? AND " + statusColumn + " != ? ");
            frag.setLong(1, groupId);
            // frag.setString(2, Document.DELETE);
            String orderBy = "DOC_ID DESC";

            ImDocHeadRow[] rows = this.read(frag, null, null, orderBy);

            return populateDocuments(rows);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_read_Head_info_for_group", Severity.ERROR,
                    exception, this);
        }

    }

    public void updateStatus(String groupId, String status) throws ReIMException {
        OraclePreparedStatement stmt = null;


        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_STATUS_BY_GROUP_ID);
            stmt.setString(1, status);
            stmt.setString(2, ReIMUserContext.getUsername());
            stmt.setTimestamp(3, new ReIMDate().getTimestamp());
            stmt.setString(4, groupId);

            stmt.executeUpdate();
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_update_status", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_update_status", Severity.ERROR, exception,
                        this);

            }
        }
    }

    public void updateStatusByDocId(long docId, String status, String userId) throws ReIMException {
        OraclePreparedStatement stmt = null;


        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (Document.APPROVED.equals(status)) {
                stmt = (OraclePreparedStatement) conn
                        .prepareStatement(UPDATE_STATUS_TO_APPROVED_BY_DOC_ID);
                stmt.setString(1, status);
                stmt.setString(2, userId);
                stmt.setTimestamp(3, new ReIMDate().getTimestamp());
                stmt.setString(4, userId);
                stmt.setTimestamp(5, new ReIMDate().getTimestamp());
                stmt.setLong(6, docId);
            } else {
                stmt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_STATUS_BY_DOC_ID);
                stmt.setString(1, status);
                stmt.setString(2, userId);
                stmt.setTimestamp(3, new ReIMDate().getTimestamp());
                stmt.setLong(4, docId);
            }

            stmt.executeUpdate();
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_update_status", Severity.ERROR, exception,
                    this);
        } finally {
            try {

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_update_status", Severity.ERROR, exception,
                        this);

            }
        }
    }

    public Document read(long docId) throws ReIMException {
        try {
            // ensure that this is only used for merchandise doc id's!!
            ImDocHeadAccess access = new ImDocHeadAccess();
            ImDocHeadRow row = access.read(docId, false);
            if (row != null) {
                return convertRowToDocument(row);
            } else {
                return null;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        }
    }

    public Document getMerchandiseDocHeadWithTax(long docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer query = new StringBuffer(1000);
            query.append(SELECT_FOR_GET_MERCHANDISE_DOC_HEAD_WITH_TAX);
            query.append(FROM_FOR_GET_MERCHANDISE_DOC_HEAD_WITH_TAX);
            query.append(WHERE_FOR_GET_MERCHANDISE_DOC_HEAD_WITH_TAX);

            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            stmt.setLong(1, docId);
            rs = stmt.executeQuery();

            return convertResultSetToMerchandiseDocumentWithTax(rs);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException sqle) {
                throw new ReIMException("error.sql_error", Severity.ERROR, sqle, this);
            }
        }
    }

    public Map getResolutionDocsWithNonMerchAmount(Collection docIds) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(SELECT_FOR_RESOLUTION_DOCUMENT_WITH_NON_MERCH_TOTAL);
            OracleDocIDObject docTable = new OracleDocIDObject();
            stmt.setARRAY(1, docTable.getArrayForDocIdsByIdCollection(docIds, conn));
            rs = stmt.executeQuery();

            return convertResultSetToResolutionDocuments(rs);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException sqle) {
                throw new ReIMException("error.sql_error", Severity.ERROR, sqle, this);
            }
        }
    }

    /**
     * @param searchCriteria
     *            Search criteria entered by user in the form
     * @param isSupplierSearch
     *            flag that specified weather we need to get data on reviewers or not
     * @return Array of documents that meets criteria
     * @throws ReIMException
     */
    public Document[] populateDocumentsList(DocumentSearchCriteria searchCriteria,
            boolean isSupplierSearch) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            StringBuffer sqlText = new StringBuffer();

            if (searchCriteria.getVendorId() != null || searchCriteria.getVendorType() != null) {
                sqlText.append("SELECT /*+ index(dh, im_doc_head_i1) */ ");
            } else {
                sqlText.append("SELECT");
            }

            sqlText
                    .append(" DH.TYPE, DH.ORDER_NO, DH.STATUS, DH.DOC_DATE, DH.DOC_ID, DH.DEAL_ID, DH.EXT_DOC_ID, DH.DUE_DATE, DH.VENDOR, DH.TOTAL_COST, DH.FREIGHT_TYPE, DH.EDI_UPLOAD_IND, DH.LOCATION, DH.VENDOR_TYPE, DH.CURRENCY_CODE, DH.PRE_PAID_IND, DH.TOTAL_COST_INC_TAX, DH.DEAL_TYPE, DH.HOLD_STATUS, ");

            if (isSupplierSearch) {
                sqlText.append("OP.AP_REVIEWER, ");
            }
            sqlText
                    .append("DH.BEST_TERMS, DH.BEST_TERMS_SOURCE, DH.BEST_TERMS_DATE, DH.BEST_TERMS_DATE_SOURCE, DH.MANUALLY_PAID_IND, DH.CONSIGNMENT_IND , DH.DSD_IND, DH.ERS_IND FROM IM_DOC_HEAD DH");

            if (isSupplierSearch) {
                sqlText.append(", IM_SUPPLIER_OPTIONS OP ");
            }

            sqlText.append(populateDocumentsListWhereClause(searchCriteria, true));

            if (isSupplierSearch) {
                sqlText
                        .append(" AND DH.VENDOR = TO_CHAR(OP.SUPPLIER) AND (DH.VENDOR_TYPE = 'SUPP' OR DH.VENDOR_TYPE = 'S')");
            }

            rs = stmt.executeQuery(sqlText.toString());

            return createDocuments(rs, isSupplierSearch);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.doc_head_ext_bean.cannot_populate_doc_list",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception ex) {
                throw new ReIMException("error.doc_head_ext_bean.cannot_populate_doc_list",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * @param searchCriteria
     * @param useApReviewerCriteria
     *            flag that indicate if we want to add ap_reviewer as part of the string The flag
     *            should be set to true for general search and to false for searches with
     *            ap_reviewer
     * @return SQL string that will narrow down search
     */
    public String populateDocumentsListWhereClause(DocumentSearchCriteria searchCriteria,
            boolean useApReviewerCriteria) {

        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");

        StringBuffer sqlText = new StringBuffer();

        sqlText.append(" WHERE ");
        boolean firstClause = true;

        if (StringUtils.isNotBlank(searchCriteria.getStatus())) {
            if (!firstClause) {
                sqlText.append(" AND");
            }
            if (searchCriteria.getStatus().equals(Document.ALL_INCLUDE_POSTED))
                sqlText
                        .append(" DH.STATUS IN ('RMTCH','MURMTH','URMTCH','MTCH','APPRVE','POSTED','DISPUT','SUBMIT','TAXDIS','VOID') ");
            else {
                if (!searchCriteria.getStatus().equals(Document.ALL_INCLUDE_POSTED))
                    sqlText.append(" DH.STATUS = '").append(searchCriteria.getStatus()).append("'");
            }
        } else {
            if (!firstClause) {
                sqlText.append(" AND");
            }

            sqlText.append(" DH.STATUS != '").append(MerchandiseDocument.DELETE).append("'");
            sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.WGRP).append("'");
            sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.POSTED).append("'");

            if(searchCriteria.getActionType().equalsIgnoreCase("EDIT")&& (!searchCriteria.getDocType().equalsIgnoreCase("MRCHI") ))
            {
                sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.READY_FOR_MATCH).append("'");
                sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.MATCHED).append("'");
                sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.VOID).append("'");
                sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.SUBMITTED).append("'");
            }

            if (searchCriteria.getActionType() != null
                    && searchCriteria.getActionType().equals(ReIMConstants.EDIT)) {
                sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.MATCHED).append(
                        "'");
                sqlText.append(" AND DH.STATUS != '").append(MerchandiseDocument.POSTED)
                        .append("'");
            }
        }

        if (!StringUtils.isBlank(searchCriteria.getConsignment())) {
            sqlText.append(" AND");
            sqlText.append(" CONSIGNMENT_IND = '").append(searchCriteria.getConsignment()).append(
                    "'");
        }

        if (!StringUtils.isBlank(searchCriteria.getDealInd())
                && ReIMConstants.YES.equals(searchCriteria.getDealInd())) {
            sqlText.append(" AND");
            sqlText.append(" DH.DEAL_ID > 0 ");
        }

        // ****Join Conditions****
        if (searchCriteria.getItemId() != null
                && !searchCriteria.getItemId().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText
                    .append(" AND (EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL DD WHERE DH.DOC_ID = DD.DOC_ID AND DD.ITEM = '");
            sqlText.append(searchCriteria.getItemId()).append("')");
            sqlText
                    .append(" OR EXISTS (SELECT 'X' FROM IM_DOC_DETAIL_REASON_CODES RC WHERE DH.DOC_ID = RC.DOC_ID AND RC.ITEM = '");
            sqlText.append(searchCriteria.getItemId()).append("'))");
        }

        if (searchCriteria.getPrePaid() != null
                && !searchCriteria.getPrePaid().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.PRE_PAID_IND = '").append(searchCriteria.getPrePaid()).append(
                    "'");
        }

        if (searchCriteria.getOrderId() != null
                && !searchCriteria.getOrderId().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.ORDER_NO = '").append(searchCriteria.getOrderId()).append("'");
        }

        if (searchCriteria.getLocationId() != null
                && !searchCriteria.getLocationId().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.LOCATION = '").append(searchCriteria.getLocationId()).append(
                    "'");
        }

        if (searchCriteria.getVendorId() != null
                && !searchCriteria.getVendorId().equals(ReIMConstants.EMPTY_STRING)) {
            if (searchCriteria.getVendorId().indexOf("'") > 0) {
                searchCriteria.setVendorId(LovUtils
                        .replace(searchCriteria.getVendorId(), "'", "''"));
            }
            sqlText.append(" AND DH.VENDOR = '").append(searchCriteria.getVendorId()).append("'");
        }

        if (searchCriteria.getVendorType() != null
                && !searchCriteria.getVendorType().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.VENDOR_TYPE = '").append(searchCriteria.getVendorType())
                    .append("'");
        }

        if (searchCriteria.getDocType() != null
                && !searchCriteria.getDocType().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.TYPE = '").append(searchCriteria.getDocType()).append("'");
        }
        if (searchCriteria.getExternalDocId() != null
                && !searchCriteria.getExternalDocId().equals(ReIMConstants.EMPTY_STRING)) {
            // User must enter '%' for partial search
            sqlText.append(" AND UPPER(DH.EXT_DOC_ID) LIKE UPPER('").append(
                    searchCriteria.getExternalDocId()).append("')");
        }

        if (searchCriteria.getInvoiceFromDate() != null) {
            String invoiceFromDate = formatter.format(searchCriteria.getInvoiceFromDate());

            sqlText.append(" AND DH.DOC_DATE >= to_date('").append(invoiceFromDate).append(
                    "', 'YYYYMMDD')");
        }

        if (searchCriteria.getInvoiceToDate() != null) {
            String invoiceToDate = formatter.format(searchCriteria.getInvoiceToDate());

            sqlText.append(" AND TRUNC(DH.DOC_DATE) <= to_date('").append(invoiceToDate).append(
                    "', 'YYYYMMDD')");
        }

        // Use the Search Form static final to stay in synch with jsp list
        // values
        if (searchCriteria.getPriceReview() != null
                && !searchCriteria.getPriceReview().equals(ReIMConstants.EMPTY_STRING)
                && searchCriteria.getPriceReview().equals(ReIMConstants.YES)) {
            sqlText
                    .append(" AND EXISTS (SELECT 'X' FROM IM_COST_DISCREPANCY C WHERE C.DOC_ID = DH.DOC_ID ");
            sqlText.append(") ");
        }

        if (searchCriteria.getPriceReview() != null
                && !searchCriteria.getPriceReview().equals(ReIMConstants.EMPTY_STRING)
                && searchCriteria.getPriceReview().equals(ReIMConstants.NO)) {
            sqlText
                    .append(" AND NOT EXISTS (SELECT 'X' FROM IM_COST_DISCREPANCY C WHERE C.DOC_ID = DH.DOC_ID ");
            sqlText.append(") ");
        }

        if (searchCriteria.getPriceReviewGroup() != null
                && !searchCriteria.getPriceReviewGroup().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText
                    .append(" AND EXISTS (SELECT 'X' FROM IM_COST_DISCREPANCY C WHERE C.DOC_ID = DH.DOC_ID AND C.BUSINESS_ROLE_ID = ");
            sqlText.append(searchCriteria.getPriceReviewGroup());
            sqlText.append(") ");
        }
        // Use the Search Form static final to stay in synch with jsp list
        // values
        if (searchCriteria.getQtyReview() != null
                && searchCriteria.getQtyReview().equals(ReIMConstants.YES)) {
            sqlText
                    .append(" AND EXISTS (SELECT 'X' FROM IM_QTY_DISCREPANCY Q WHERE Q.DOC_ID = DH.DOC_ID ");
            sqlText.append(") ");
        }

        if (searchCriteria.getQtyReview() != null
                && searchCriteria.getQtyReview().equals(ReIMConstants.NO)) {
            sqlText
                    .append(" AND NOT EXISTS (SELECT 'X' FROM IM_QTY_DISCREPANCY Q WHERE Q.DOC_ID = DH.DOC_ID ");
            sqlText.append(") ");
        }

        if (searchCriteria.getQtyReviewGroup() != null
                && !searchCriteria.getQtyReviewGroup().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText
                    .append(" AND EXISTS (SELECT 'X' FROM IM_QTY_DISCREPANCY Q,IM_QTY_DISCREPANCY_ROLE QR WHERE Q.DOC_ID = DH.DOC_ID AND Q.QTY_DISCREPANCY_ID = QR.QTY_DISCREPANCY_ID AND QR.BUSINESS_ROLE_ID = ");
            sqlText.append(searchCriteria.getQtyReviewGroup());
            sqlText.append(") ");
        }

        if (searchCriteria.getFreightType() != null
                && !searchCriteria.getFreightType().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.FREIGHT_TYPE = '").append(searchCriteria.getFreightType())
                    .append("'");
        }

        if (searchCriteria.getDueFromDate() != null) {
            String dueFromDate = formatter.format(searchCriteria.getDueFromDate());

            sqlText.append(" AND DH.DUE_DATE >= to_date('").append(dueFromDate).append(
                    "', 'YYYYMMDD')");
        }

        if (searchCriteria.getDueToDate() != null) {
            String dueToDate = formatter.format(searchCriteria.getDueToDate());

            sqlText.append(" AND TRUNC(DH.DUE_DATE) <= to_date('").append(dueToDate).append(
                    "', 'YYYYMMDD')");

        }

        if (searchCriteria.getInvoiceTotalCostFrom() != Double.MIN_VALUE) {
            sqlText.append(" AND DH.TOTAL_COST >= ").append(
                    searchCriteria.getInvoiceTotalCostFrom());
        }

        if (searchCriteria.getInvoiceTotalCostTo() != Double.MIN_VALUE) {
            sqlText.append(" AND DH.TOTAL_COST <= ").append(searchCriteria.getInvoiceTotalCostTo());
        }

        if (searchCriteria.getBeginQuantity() != null
                && !searchCriteria.getBeginQuantity().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.TOTAL_QTY >= ").append(searchCriteria.getBeginQuantity());
        }

        if (searchCriteria.getEndQuantity() != null
                && !searchCriteria.getEndQuantity().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.TOTAL_QTY <= ").append(searchCriteria.getEndQuantity());
        }

        if (searchCriteria.getCurrencyCode() != null
                && !searchCriteria.getCurrencyCode().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.CURRENCY_CODE = '").append(searchCriteria.getCurrencyCode())
                    .append("'");
        }

        if (searchCriteria.getPaymentTerms() != null
                && !searchCriteria.getPaymentTerms().equals(ReIMConstants.EMPTY_STRING)) {
            sqlText.append(" AND DH.TERMS = '").append(searchCriteria.getPaymentTerms())
                    .append("'");
        }

        if (searchCriteria.getDetailsExist() != null
                && searchCriteria.getDetailsExist().equals(ReIMConstants.YES)) {
            sqlText
                    .append(" AND (EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL DD WHERE DH.DOC_ID = DD.DOC_ID) ");
            sqlText
                    .append(" OR EXISTS (SELECT 'X' FROM IM_DOC_DETAIL_REASON_CODES RC WHERE DH.DOC_ID = RC.DOC_ID)) ");
        }

        if (searchCriteria.getDetailsExist() != null
                && searchCriteria.getDetailsExist().equals(ReIMConstants.NO)) {
            sqlText
                    .append(" AND NOT EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL DD WHERE DH.DOC_ID = DD.DOC_ID) ");
            sqlText
                    .append(" AND NOT EXISTS (SELECT 'X' FROM IM_DOC_DETAIL_REASON_CODES RC WHERE DH.DOC_ID = RC.DOC_ID) ");
        }

        if (searchCriteria.getApReviewer() != null
                && !searchCriteria.getApReviewer().equals(ReIMConstants.EMPTY_STRING)) {
            if (useApReviewerCriteria) {
                sqlText.append(" AND OP.AP_REVIEWER = '");
                sqlText.append(searchCriteria.getApReviewer());
                sqlText.append("' ");
            }
        }

        return sqlText.toString();

    }

    private Document[] createDocuments(ResultSet rs, boolean isSupplierSearch) throws ReIMException {
        String AP_REVIEWER_NOT_APPLICABLE = "   ";
        ArrayList<Document> documents = new ArrayList<Document>();
        Document[] documentsArray = null;
        Date date;
        int rowCount = 0;

        try {
            while (rs.next()) {
                rowCount++;
                if (rowCount > ReimProperties.DOCUMENT_SEARCH_RECORDS_MAX) { throw new ReIMException(
                        "error.max_rows_reached", Severity.WARN, this); }
                String documentType = rs.getString("TYPE");
                Document doc = ServiceFactory.getDocumentService().initializeDocument(documentType);

                if (doc == null) { throw new ReIMException(
                        "error.doc_head_ext_bean.invalid_doc_type", Severity.DEBUG, this,
                        new String[] { documentType});

                }

                String ind;
                doc.setDocId(rs.getLong("DOC_ID"));
                doc.setType(documentType);
                doc.setDocPrefix(getDocumentPrefixByDocumentType(documentType));
                doc.setStatus(rs.getString("STATUS"));
                long dealIdLong = rs.getLong(ImDocHeadAccess.dealIdColumn);
                DealId dealId = dealIdLong != 0 ? DealId.valueOf(dealIdLong) : null;
                doc.setDealId(dealId);
                doc.setHoldStatus(rs.getString("HOLD_STATUS"));

                /**
                 * Since requirements have changed and this is used when searching for all types of
                 * documents, this is not a true POLocation. For invoices, the POLocation is full
                 * (order and loc). A non-merch invoice may be null, just an order, or a full
                 * POLocation. Other documents (non invoice or non-merch) will have a location and
                 * may have an order.
                 */
                POLocation poLoc = new POLocation();
                String orderNo = String.valueOf(rs.getLong("ORDER_NO"));

                if (!rs.wasNull()) {
                    poLoc.setOrder(new Order(orderNo));
                    doc.setOrderNo(orderNo);
                }

                String location = String.valueOf(rs.getLong("LOCATION"));
                if (!rs.wasNull()) {
                    poLoc.setLocation(new Location(location));
                }

                doc.setPoLocation(poLoc);

                date = rs.getDate("DOC_DATE");
                if (!rs.wasNull()) {
                    doc.setDocDate(new ReIMDate(date));
                }

                if (!rs.wasNull()) {
                    doc.setCreateDate(new ReIMDate(date));
                }

                Vendor vendor = ServiceFactory.getVendorService().initializeVendor(
                        rs.getString("VENDOR_TYPE"));
                vendor.setVendorId(rs.getString("VENDOR"));
                doc.setVendor(vendor);
                doc.setExtDocId(rs.getString("EXT_DOC_ID"));

                ind = rs.getString("EDI_UPLOAD_IND");
                if (ind.equalsIgnoreCase(ReIMConstants.YES)) {
                    doc.setEdiUploadInd(true);
                } else {
                    doc.setEdiUploadInd(false);
                }

                ind = rs.getString("MANUALLY_PAID_IND");
                if (ind.equalsIgnoreCase(ReIMConstants.YES)) {
                    doc.setManuallyPaidInd(true);
                } else {
                    doc.setManuallyPaidInd(false);
                }

                date = rs.getDate("DUE_DATE");
                if (!rs.wasNull()) {
                    doc.setDueDate(new ReIMDate(date));
                }

                doc.setCurrencyCode(rs.getString("CURRENCY_CODE"));
                doc.setPrePaidInd((rs.getString("PRE_PAID_IND").equals(ReIMConstants.YES) ? true
                        : false));
                doc.setTotalCost(rs.getDouble("TOTAL_COST"));
                doc.setFreightType(rs.getString("FREIGHT_TYPE"));
                doc
                        .setConsignmentInd((rs.getString("CONSIGNMENT_IND").equals(
                                ReIMConstants.YES) ? true : false));

                doc.setDirectStoreDelieveryInd((rs.getString("DSD_IND").equals(
                        ReIMConstants.YES) ? true : false));
                doc.setEvaluatedReceiptSettlementInd((rs.getString("ERS_IND").equals(
                        ReIMConstants.YES) ? true : false));
                if (isSupplierSearch)
                    doc.setApReviewer(rs.getString("AP_REVIEWER"));
                else
                    doc.setApReviewer(AP_REVIEWER_NOT_APPLICABLE);
                doc.setBestTerms(rs.getString("BEST_TERMS"));
                doc.setBestTermsSource(rs.getString("BEST_TERMS_SOURCE"));
                date = rs.getDate("BEST_TERMS_DATE");
                if (!rs.wasNull()) {
                    doc.setBestTermsDate(new ReIMDate(date));
                }
                doc.setBestTermsDateSource(rs.getString("BEST_TERMS_DATE_SOURCE"));
                doc.setTotalCostIncTax(rs.getDouble("TOTAL_COST_INC_TAX"));
                doc.setDealType(rs.getString("DEAL_TYPE") != null ? DealType.fromCode(rs
                        .getString("DEAL_TYPE")) : null);
                documents.add(doc);
            }

            if (documents.size() != 0) {
                documentsArray = (Document[]) documents.toArray(new Document[documents.size()]);
            }

        } catch (SQLException e) {
            throw new ReIMException("error.doc_head_ext_bean.cannot_create_documents",
                    Severity.ERROR, e, this);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.doc_head_ext_bean.cannot_create_documents",
                    Severity.ERROR, e, this);
        }

        return documentsArray;
    }

    private String getDocumentPrefixByDocumentType(String documentType) {
        if ((documentType == null) || (ReIMUserContext.getSystemOptions() == null)) {
            return null;
        } else if (documentType.equalsIgnoreCase(Document.CREDIT_MEMO_PRICE)) {
            return ReIMUserContext.getSystemOptions().getCreditMemoPrefixCost();
        } else if (documentType.equalsIgnoreCase(Document.CREDIT_MEMO_QUANTITY)) {
            return ReIMUserContext.getSystemOptions().getCreditMemoPrefixQty();
        } else if (documentType.equalsIgnoreCase(Document.CREDIT_NOTE_REQUEST_PRICE)) {
            return ReIMUserContext.getSystemOptions().getCreditNotePrefixCost();
        } else if (documentType.equalsIgnoreCase(Document.CREDIT_NOTE_REQUEST_TAX)) {
            return ReIMUserContext.getSystemOptions().getCreditNotePrefixTax();
        } else if (documentType.equalsIgnoreCase(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
            return ReIMUserContext.getSystemOptions().getCreditNotePrefixQty();
        } else if (documentType.equalsIgnoreCase(Document.CREDIT_NOTE)) {
            return ""; // no prefix for credit note
        } else if (documentType.equalsIgnoreCase(Document.DEBIT_MEMO_PRICE)) {
            return ReIMUserContext.getSystemOptions().getDebitMemoPrefixCost();
        } else if (documentType.equalsIgnoreCase(Document.DEBIT_MEMO_QUANTITY)) {
            return ReIMUserContext.getSystemOptions().getDebitMemoPrefixQty();
        } else if (documentType.equalsIgnoreCase(Document.DEBIT_MEMO_TAX)) {
            return ReIMUserContext.getSystemOptions().getDebitMemoPrefixTax();
        } else {
            return null;
        }
    }

    public void populateDocHeadInfo(Document doc) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            // ****Select Clause ****
            StringBuffer sqlText = new StringBuffer();
            sqlText
                    .append("SELECT TERMS, CURRENCY_CODE, EXCHANGE_RATE, TOTAL_QTY, TOTAL_COST_INC_TAX, PAYMENT_METHOD, CUSTOM_DOC_REF_1, CUSTOM_DOC_REF_2, CUSTOM_DOC_REF_3, CUSTOM_DOC_REF_4, CREATE_ID, REF_DOC, GROUP_ID, SUPPLIER_SITE_ID");

            // ****From Clause****
            sqlText.append(" FROM IM_DOC_HEAD ");

            // ****Where Clause****

            sqlText.append(" WHERE DOC_ID = " + doc.getDocId() + " ");

            rs = stmt.executeQuery(sqlText.toString());

            if (rs.next()) {
                doc.setTerms(rs.getString("TERMS"));
                doc.setCurrencyCode(rs.getString("CURRENCY_CODE"));
                doc.setExchangeRate(rs.getDouble("EXCHANGE_RATE"));
                doc.setTotalQty(rs.getDouble("TOTAL_QTY"));
                doc.setTotalCostIncTax(rs.getDouble("TOTAL_COST_INC_TAX"));
                doc.setPaymentMethod(rs.getString("PAYMENT_METHOD"));
                doc.setCustomDocRef1(rs.getString("CUSTOM_DOC_REF_1"));
                doc.setCustomDocRef2(rs.getString("CUSTOM_DOC_REF_2"));
                doc.setCustomDocRef3(rs.getString("CUSTOM_DOC_REF_3"));
                doc.setCustomDocRef4(rs.getString("CUSTOM_DOC_REF_4"));
                doc.setCreateId(rs.getString("CREATE_ID"));
                long refDoc = rs.getLong("REF_DOC");
                if (!rs.wasNull()) {
                    doc.setRefDoc(Long.valueOf(refDoc));
                }
                Long groupId = rs.getLong("GROUP_ID");
                if (!rs.wasNull()) {
                    doc.setGroupId(groupId);
                }
                Vendor supplierSite = new Vendor();
                supplierSite.setVendorId(rs.getString("SUPPLIER_SITE_ID"));
                doc.setSupplierSite(supplierSite);
            }
        } catch (Exception e) {
            throw new ReIMException("error.cannot_populate_doc_head_info", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception ex) {
                throw new ReIMException("error.cannot_populate_doc_head_info", Severity.ERROR, ex,
                        this);
            }
        }
    }

    // this method will only return an array of type Document...if you need it
    // to return something than this (i.e. MerchandiseDocument array, do your
    // casting
    // after this call.
    private MerchandiseDocument[] populateMerchandiseDocuments(ImDocHeadRow[] rows)
            throws Exception {
        ArrayList<Document> arrayList = new ArrayList<Document>();

        if (rows != null) {
            for (int i = 0; i < rows.length; i++) {
                arrayList.add(convertRowToDocument(rows[i]));
            }
        }

        MerchandiseDocument[] documents = (MerchandiseDocument[]) arrayList
                .toArray(new MerchandiseDocument[arrayList.size()]);
        return documents;
    }

    private Document[] populateDocuments(ImDocHeadRow[] rows) throws Exception {
        ArrayList<Document> arrayList = new ArrayList<Document>();

        for (int i = 0; i < rows.length; i++) {
            arrayList.add(convertRowToDocument(rows[i]));
        }

        Document[] documents = (Document[]) arrayList.toArray(new Document[arrayList.size()]);
        return documents;
    }

    private void convertRowToMerchandiseDocument(ImDocHeadRow row, MerchandiseDocument merchDoc)
            throws ReIMException {
        // set any attributes unique to a merchandise document here
        double varianceWithinTolerance = row.getVarianceWithinTolerance();

        if (varianceWithinTolerance == Double.MIN_VALUE) {
            merchDoc.setVarianceWithinTolerance(null);
        } else {
            merchDoc.setVarianceWithinTolerance(new Double(varianceWithinTolerance));
        }

        merchDoc.setResolutionAdjustedTotalCost(row.getResolutionAdjustedTotalCost());
        merchDoc.setResolutionAdjustedTotalQty(row.getResolutionAdjustedTotalQty());
        merchDoc.setForcePayInd(row.getPrePaidInd());
        merchDoc.setTaxDiscrepancyCreateDate(row.getTaxDiscCreateDate() != null ? new ReIMDate(row
                .getTaxDiscCreateDate()) : null);

        // add po/location to merch document to drive matching this invoice
        Order order = new Order();
        order.setOrderNo(merchDoc.getOrderNo());
        Location location = new Location();
        location.setLocationId(merchDoc.getLocation().getLocationId());
        location.setLocationType(merchDoc.getLocation().getLocationType());
        POLocation poLoc = new POLocation(order, location);
        merchDoc.setPoLocation(poLoc);
    }

    private void convertRowToResolutionDocument(ImDocHeadRow row,
            ResolutionDocument resolutionDocument) throws ReIMException {
        // set any attributes unique to a merchandise document here
        double varianceWithinTolerance = row.getVarianceWithinTolerance();

        if (varianceWithinTolerance == Double.MIN_VALUE) {
            resolutionDocument.setVarianceWithinTolerance(null);
        } else {
            resolutionDocument.setVarianceWithinTolerance(new Double(varianceWithinTolerance));
        }

        resolutionDocument.setResolutionAdjustedTotalCost(row.getResolutionAdjustedTotalCost());
        resolutionDocument.setResolutionAdjustedTotalQty(row.getResolutionAdjustedTotalQty());
        // resolutionDocument.setForcePayInd(row.getPrePaidInd());
        // add po/location to merch document to drive matching this invoice
        Order order = new Order();
        order.setOrderNo(resolutionDocument.getOrderNo());
        Location location = new Location();
        location.setLocationId(resolutionDocument.getLocation().getLocationId());
        location.setLocationType(resolutionDocument.getLocation().getLocationId());
        POLocation poLoc = new POLocation(order, resolutionDocument.getLocation());
        resolutionDocument.setPoLocation(poLoc);
    }

    private Document convertResultSetToMerchandiseDocumentWithTax(ResultSet rs)
            throws ReIMException, SQLException {
        MerchandiseDocument document = null;
        Location docLocation = null;
        Set<Tax> merchTaxes = null;
        boolean firstRecord = true;

        while (rs.next()) {
            if (firstRecord) {
                document = new MerchandiseDocument();
                docLocation = new Location();
                document.setLocation(docLocation);
                document.setDocId(rs.getLong(ImDocHeadAccess.docIdColumn));
                document.setType(Document.MERCHANDISE_INVOICE);
                document.setStatus(rs.getString(ImDocHeadAccess.statusColumn));

                double totalDiscount = rs.getDouble(ImDocHeadAccess.totalDiscountColumn);
                document.setTotalDiscount(totalDiscount == Double.MIN_VALUE ? 0 : totalDiscount);

                document.setGroupId(rs.getLong(ImDocHeadAccess.groupIdColumn));
                document.setGroupEntryInd(true);

                Date docDate = rs.getDate(ImDocHeadAccess.docDateColumn);
                document.setDocDate(docDate == null ? null : new ReIMDate(docDate));

                Date createDate = rs.getDate(ImDocHeadAccess.createDateColumn);
                document.setCreateDate(createDate == null ? null : new ReIMDate(createDate));
                document.setCreateId(rs.getString(ImDocHeadAccess.createIdColumn));

                String vendorType = rs.getString(ImDocHeadAccess.vendorTypeColumn);
                Vendor vendor = ServiceFactory.getVendorService().initializeVendor(vendorType);
                vendor.setVendorId(rs.getString(ImDocHeadAccess.vendorColumn));
                document.setVendor(vendor);
                document.setVendorType(vendorType);

                document.setExtDocId(rs.getString(ImDocHeadAccess.extDocIdColumn));

                if (rs.getString(ImDocHeadAccess.ediUploadIndColumn).equalsIgnoreCase(
                        ReIMConstants.YES)) {
                    document.setEdiUploadInd(true);
                } else {
                    document.setEdiUploadInd(false);
                }

                if (rs.getString(ImDocHeadAccess.ediDownloadIndColumn).equalsIgnoreCase(
                        ReIMConstants.YES)) {
                    document.setEdiDownloadInd(true);
                } else {
                    document.setEdiDownloadInd(false);
                }

                document.setTerms(rs.getString(ImDocHeadAccess.termsColumn));
                document.setTermsDscntPct(rs.getDouble(ImDocHeadAccess.termsDscntPctColumn));

                Date dueDate = rs.getDate(ImDocHeadAccess.dueDateColumn);
                document.setDueDate(dueDate == null ? null : new ReIMDate(dueDate));

                document.setPaymentMethod(rs.getString(ImDocHeadAccess.paymentMethodColumn));
                document.setMatchId(rs.getString(ImDocHeadAccess.matchIdColumn));

                Date matchDate = rs.getDate(ImDocHeadAccess.matchDateColumn);
                document.setMatchDate(matchDate == null ? null : new ReIMDate(matchDate));

                document.setApprovalId(rs.getString(ImDocHeadAccess.approvalIdColumn));

                Date approvalDate = rs.getDate(ImDocHeadAccess.approvalDateColumn);
                document.setApprovalDate(approvalDate == null ? null : new ReIMDate(approvalDate));

                String prepaidInd = rs.getString(ImDocHeadAccess.prePaidIndColumn);
                if (prepaidInd.equalsIgnoreCase(ReIMConstants.YES)) {
                    document.setPrePaidInd(true);
                } else {
                    document.setPrePaidInd(false);
                }

                document.setForcePayId(rs.getString(ImDocHeadAccess.prePaidIdColumn));

                Date postDate = rs.getDate(ImDocHeadAccess.postDateColumn);
                document.setPostDate(postDate == null ? null : new ReIMDate(postDate));

                document.setCurrencyCode(rs.getString("INVOICE_CURRENCY_CODE"));
                document.setTotalCost(rs.getDouble(ImDocHeadAccess.totalCostColumn));
                document.setTotalQty(rs.getDouble(ImDocHeadAccess.totalQtyColumn));

                if (rs.getString(ImDocHeadAccess.manuallyPaidIndColumn).equalsIgnoreCase(
                        ReIMConstants.YES)) {
                    document.setManuallyPaidInd(true);
                } else {
                    document.setManuallyPaidInd(false);
                }

                if (rs.getString(ImDocHeadAccess.consignmentIndColumn).equalsIgnoreCase(
                        ReIMConstants.YES)) {
                    document.setConsignmentInd(true);
                } else {
                    document.setConsignmentInd(false);
                }

                if (rs.getString(ImDocHeadAccess.rtvIndColumn).equalsIgnoreCase(ReIMConstants.YES)) {
                    document.setRtvChargebackInd(true);
                } else {
                    document.setRtvChargebackInd(false);
                }

                document.setCustomDocRef1(rs.getString(ImDocHeadAccess.customDocRef1Column));
                document.setCustomDocRef2(rs.getString(ImDocHeadAccess.customDocRef2Column));
                document.setCustomDocRef3(rs.getString(ImDocHeadAccess.customDocRef3Column));
                document.setCustomDocRef4(rs.getString(ImDocHeadAccess.customDocRef4Column));
                document.setLastUpdateId(rs.getString(ImDocHeadAccess.lastUpdateIdColumn));

                Date lastUpdateDate = rs.getDate(ImDocHeadAccess.lastDatetimeColumn);
                document.setLastUpdateDateTime(lastUpdateDate == null ? null : new ReIMDate(
                        lastUpdateDate));

                document.setFreightType(rs.getString(ImDocHeadAccess.freightTypeColumn));
                document.setBestTerms(rs.getString(ImDocHeadAccess.bestTermsColumn));
                document.setBestTermsSource(rs.getString(ImDocHeadAccess.bestTermsSourceColumn));

                Date bestTermsDate = rs.getDate(ImDocHeadAccess.bestTermsDateColumn);
                document.setBestTermsDate(bestTermsDate == null ? null
                        : new ReIMDate(bestTermsDate));

                document.setBestTermsDateSource(rs
                        .getString(ImDocHeadAccess.bestTermsDateSourceColumn));
                document.setExchangeRate(rs.getDouble(ImDocHeadAccess.exchangeRateColumn));

                long location = rs.getLong(ImDocHeadAccess.locationColumn);
                if (location == Long.MIN_VALUE) {
                    document.getLocation().setLocationId((String) null);
                } else {
                    document.getLocation().setLocationId(Long.toString(location));
                    document.getLocation().setLocationType(
                            rs.getString(ImDocHeadAccess.locTypeColumn));
                }

                long orderNo = rs.getLong(ImDocHeadAccess.orderNoColumn);
                if (orderNo == Long.MIN_VALUE) {
                    document.setOrderNo((String) null);
                } else {
                    document.setOrderNo(Long.toString(orderNo));
                }

                double varianceWithinTolerance = rs
                        .getDouble(ImDocHeadAccess.varianceWithinToleranceColumn);
                if (varianceWithinTolerance == Double.MIN_VALUE) {
                    document.setVarianceWithinTolerance(null);
                } else {
                    document.setVarianceWithinTolerance(new Double(varianceWithinTolerance));
                }

                document.setResolutionAdjustedTotalCost(rs
                        .getDouble(ImDocHeadAccess.resolutionAdjustedTotalCostColumn));
                document.setResolutionAdjustedTotalQty(rs
                        .getDouble(ImDocHeadAccess.resolutionAdjustedTotalQtyColumn));

                Date taxDiscCreateDate = rs.getDate(ImDocHeadAccess.taxDiscCreateDateColumn);
                document.setTaxDiscrepancyCreateDate(taxDiscCreateDate != null ? new ReIMDate(
                        taxDiscCreateDate) : null);

                // add po/location to merch document to drive matching this
                // invoice
                Order order = new Order();
                order.setOrderNo(document.getOrderNo());

                POLocation poLoc = new POLocation(order, document.getLocation());
                document.setPoLocation(poLoc);

                long dealIdLong = rs.getLong(ImDocHeadAccess.dealIdColumn);
                DealId dealId = dealIdLong != 0 ? DealId.valueOf(dealIdLong) : null;
                document.setDealId(dealId);

                document
                        .setDealType(rs.getString(ImDocHeadAccess.dealTypeColumn) != null ? DealType
                                .fromCode(rs.getString(ImDocHeadAccess.dealTypeColumn))
                                : null);
                document.setTotalCostIncTax(rs.getDouble(ImDocHeadAccess.totalCostIncTaxColumn));

                merchTaxes = new HashSet<Tax>();

                firstRecord = false;
            }

            String merchInd = rs.getString("merch_ind");
            if (merchInd != null) {
                Tax tax = new Tax(rs.getString("TAX_CODE"), rs.getDouble("TAX_RATE"));
                tax.setTaxBasis(rs.getDouble("BASIS"));
                if (merchInd.equals("1")) {
                    merchTaxes.add(tax);
                } else {
                    document.addNonMerchTax(tax);
                }
            }
        }

        if (document != null) {
            document.setTaxes(merchTaxes);
        }

        return document;
    }

    private Map convertResultSetToResolutionDocuments(ResultSet rs) throws ReIMException,
            SQLException {
        ResolutionDocument document = null;
        Map docMap = new HashMap();

        while (rs.next()) {
            document = (ResolutionDocument) ServiceFactory.getDocumentService().initializeDocument(
                    rs.getString(ImDocHeadAccess.typeColumn));
            document.setDocId(rs.getLong(ImDocHeadAccess.docIdColumn));
            document.setType(rs.getString(ImDocHeadAccess.typeColumn));
            document.setStatus(rs.getString(ImDocHeadAccess.statusColumn));
            document.setCurrencyCode(rs.getString(ImDocHeadAccess.currencyCodeColumn));
            double totalDiscount = rs.getDouble(ImDocHeadAccess.totalDiscountColumn);
            document.setTotalDiscount(totalDiscount == Double.MIN_VALUE ? 0 : totalDiscount);

            document.setGroupId(rs.getLong(ImDocHeadAccess.groupIdColumn));
            document.setGroupEntryInd(true);
            document.setHoldStatus(rs.getString(ImDocHeadAccess.holdStatusColumn));

            Date docDate = rs.getDate(ImDocHeadAccess.docDateColumn);
            document.setDocDate(docDate == null ? null : new ReIMDate(docDate));

            Date createDate = rs.getDate(ImDocHeadAccess.createDateColumn);
            document.setCreateDate(createDate == null ? null : new ReIMDate(createDate));
            document.setCreateId(rs.getString(ImDocHeadAccess.createIdColumn));

            String vendorType = rs.getString(ImDocHeadAccess.vendorTypeColumn);
            Vendor vendor = ServiceFactory.getVendorService().initializeVendor(vendorType);
            vendor.setVendorId(rs.getString(ImDocHeadAccess.vendorColumn));
            document.setVendor(vendor);
            document.setVendorType(vendorType);

            document.setExtDocId(rs.getString(ImDocHeadAccess.extDocIdColumn));

            if (rs.getString(ImDocHeadAccess.ediUploadIndColumn)
                    .equalsIgnoreCase(ReIMConstants.YES)) {
                document.setEdiUploadInd(true);
            } else {
                document.setEdiUploadInd(false);
            }

            if (rs.getString(ImDocHeadAccess.ediDownloadIndColumn).equalsIgnoreCase(
                    ReIMConstants.YES)) {
                document.setEdiDownloadInd(true);
            } else {
                document.setEdiDownloadInd(false);
            }

            document.setTerms(rs.getString(ImDocHeadAccess.termsColumn));
            document.setTermsDscntPct(rs.getDouble(ImDocHeadAccess.termsDscntPctColumn));

            Date dueDate = rs.getDate(ImDocHeadAccess.dueDateColumn);
            document.setDueDate(dueDate == null ? null : new ReIMDate(dueDate));

            document.setPaymentMethod(rs.getString(ImDocHeadAccess.paymentMethodColumn));
            document.setMatchId(rs.getString(ImDocHeadAccess.matchIdColumn));

            Date matchDate = rs.getDate(ImDocHeadAccess.matchDateColumn);
            document.setMatchDate(matchDate == null ? null : new ReIMDate(matchDate));

            document.setApprovalId(rs.getString(ImDocHeadAccess.approvalIdColumn));

            Date approvalDate = rs.getDate(ImDocHeadAccess.approvalDateColumn);
            document.setApprovalDate(approvalDate == null ? null : new ReIMDate(approvalDate));

            String prepaidInd = rs.getString(ImDocHeadAccess.prePaidIndColumn);
            if (prepaidInd.equalsIgnoreCase(ReIMConstants.YES)) {
                document.setPrePaidInd(true);
            } else {
                document.setPrePaidInd(false);
            }

            document.setForcePayId(rs.getString(ImDocHeadAccess.prePaidIdColumn));

            Date postDate = rs.getDate(ImDocHeadAccess.postDateColumn);
            document.setPostDate(postDate == null ? null : new ReIMDate(postDate));
            document.setTotalCost(rs.getDouble(ImDocHeadAccess.totalCostColumn));
            document.setTotalQty(rs.getDouble(ImDocHeadAccess.totalQtyColumn));

            if (rs.getString(ImDocHeadAccess.manuallyPaidIndColumn).equalsIgnoreCase(
                    ReIMConstants.YES)) {
                document.setManuallyPaidInd(true);
            } else {
                document.setManuallyPaidInd(false);
            }

            if (rs.getString(ImDocHeadAccess.consignmentIndColumn).equalsIgnoreCase(
                    ReIMConstants.YES)) {
                document.setConsignmentInd(true);
            } else {
                document.setConsignmentInd(false);
            }

            if (rs.getString(ImDocHeadAccess.rtvIndColumn).equalsIgnoreCase(ReIMConstants.YES)) {
                document.setRtvChargebackInd(true);
            } else {
                document.setRtvChargebackInd(false);
            }

            document.setCustomDocRef1(rs.getString(ImDocHeadAccess.customDocRef1Column));
            document.setCustomDocRef2(rs.getString(ImDocHeadAccess.customDocRef2Column));
            document.setCustomDocRef3(rs.getString(ImDocHeadAccess.customDocRef3Column));
            document.setCustomDocRef4(rs.getString(ImDocHeadAccess.customDocRef4Column));
            document.setLastUpdateId(rs.getString(ImDocHeadAccess.lastUpdateIdColumn));

            Date lastUpdateDate = rs.getDate(ImDocHeadAccess.lastDatetimeColumn);
            document.setLastUpdateDateTime(lastUpdateDate == null ? null : new ReIMDate(
                    lastUpdateDate));

            document.setFreightType(rs.getString(ImDocHeadAccess.freightTypeColumn));
            document.setBestTerms(rs.getString(ImDocHeadAccess.bestTermsColumn));
            document.setBestTermsSource(rs.getString(ImDocHeadAccess.bestTermsSourceColumn));

            Date bestTermsDate = rs.getDate(ImDocHeadAccess.bestTermsDateColumn);
            document.setBestTermsDate(bestTermsDate == null ? null : new ReIMDate(bestTermsDate));

            document
                    .setBestTermsDateSource(rs.getString(ImDocHeadAccess.bestTermsDateSourceColumn));
            document.setExchangeRate(rs.getDouble(ImDocHeadAccess.exchangeRateColumn));

            long location = rs.getLong(ImDocHeadAccess.locationColumn);
            if (location == Long.MIN_VALUE) {
                document.getLocation().setLocationId((String) null);
            } else {
                document.getLocation().setLocationId(Long.toString(location));
                document.getLocation().setLocationType(rs.getString(ImDocHeadAccess.locTypeColumn));
            }

            long orderNo = rs.getLong(ImDocHeadAccess.orderNoColumn);
            if (orderNo == Long.MIN_VALUE) {
                document.setOrderNo((String) null);
            } else {
                document.setOrderNo(Long.toString(orderNo));
            }

            double varianceWithinTolerance = rs
                    .getDouble(ImDocHeadAccess.varianceWithinToleranceColumn);
            if (varianceWithinTolerance == Double.MIN_VALUE) {
                document.setVarianceWithinTolerance(null);
            } else {
                document.setVarianceWithinTolerance(new Double(varianceWithinTolerance));
            }

            document.setResolutionAdjustedTotalCost(rs
                    .getDouble(ImDocHeadAccess.resolutionAdjustedTotalCostColumn));
            document.setResolutionAdjustedTotalQty(rs
                    .getDouble(ImDocHeadAccess.resolutionAdjustedTotalQtyColumn));

            // add po/location to merch document to drive matching this invoice
            Order order = new Order();
            order.setOrderNo(document.getOrderNo());

            POLocation poLoc = new POLocation(order, document.getLocation());
            document.setPoLocation(poLoc);

            long dealIdLong = rs.getLong(ImDocHeadAccess.dealIdColumn);
            DealId dealId = dealIdLong != 0 ? DealId.valueOf(dealIdLong) : null;
            document.setDealId(dealId);

            document.setDealType(rs.getString(ImDocHeadAccess.dealTypeColumn) != null ? DealType
                    .fromCode(rs.getString(ImDocHeadAccess.dealTypeColumn)) : null);
            document.setTotalCostIncTax(rs.getDouble(ImDocHeadAccess.totalCostIncTaxColumn));
            document.setNonMerchAmtTotal(rs.getDouble("NON_MERCH_AMT_TOTAL"));
            docMap.put(document.getDocId() + "", document);
        }
        return docMap;
    }

    private Document convertRowToDocument(ImDocHeadRow row) throws ReIMException {
        // construct a Document object based on the row returned
        Document docHead = ServiceFactory.getDocumentService().initializeDocument(row.getType());

        docHead.setDocId(row.getDocId());
        docHead.setType(row.getType());
        docHead.setStatus(row.getStatus());
        docHead.setTotalDiscount(row.getTotalDiscount() == Double.MIN_VALUE ? 0 : row
                .getTotalDiscount());
        docHead.setGroupId(row.getGroupId());
        if (row.groupIdIsPopulated()) {
            docHead.setGroupEntryInd(true);
        }
        docHead.setDocDate(row.getDocDate() == null ? null : new ReIMDate(row.getDocDate()));
        docHead.setCreateDate(row.getCreateDate() == null ? null
                : new ReIMDate(row.getCreateDate()));
        docHead.setCreateId(row.getCreateId());

        Vendor vendor = ServiceFactory.getVendorService().initializeVendor(row.getVendorType());
        vendor.setVendorId(row.getVendor());
        docHead.setVendor(vendor);
        docHead.setVendorType(row.getVendorType());

        if((!row.isSupplierSiteNull()) && row.getSupplierSite().length() != 0)
        {
        Vendor supplierSite = ServiceFactory.getVendorService().initializeVendor(row.getVendorType());
        supplierSite.setVendorId(row.getSupplierSite());
        docHead.setSupplierSite(supplierSite);
        }


        docHead.setExtDocId(row.getExtDocId());

        if (row.getEdiUploadInd().equalsIgnoreCase(ReIMConstants.YES)) {
            docHead.setEdiUploadInd(true);
        } else {
            docHead.setEdiUploadInd(false);
        }

        if (row.getEdiDownloadInd().equalsIgnoreCase(ReIMConstants.YES)) {
            docHead.setEdiDownloadInd(true);
        } else {
            docHead.setEdiDownloadInd(false);
        }

        docHead.setTerms(row.getTerms());
        docHead.setTermsDscntPct(row.getTermsDscntPct());
        docHead.setDueDate(row.getDueDate() == null ? null : new ReIMDate(row.getDueDate()));
        docHead.setPaymentMethod(row.getPaymentMethod());
        docHead.setMatchId(row.getMatchId());
        docHead.setMatchDate(row.getMatchDate() == null ? null : new ReIMDate(row.getMatchDate()));
        docHead.setApprovalId(row.getApprovalId());
        docHead.setApprovalDate(row.getApprovalDate() == null ? null : new ReIMDate(row
                .getApprovalDate()));

        if (ReIMConstants.YES.equalsIgnoreCase(row.getPrePaidInd())) {
            docHead.setPrePaidInd(true);
        } else {
            docHead.setPrePaidInd(false);
        }

        docHead.setForcePayId(row.getPrePaidId());
        docHead.setPostDate(row.getPostDate() == null ? null : new ReIMDate(row.getPostDate()));
        docHead.setCurrencyCode(row.getCurrencyCode());
        docHead.setTotalCost(row.getTotalCost());
        docHead.setTotalQty(row.getTotalQty());

        if (ReIMConstants.YES.equalsIgnoreCase(row.getManuallyPaidInd())) {
            docHead.setManuallyPaidInd(true);
        } else {
            docHead.setManuallyPaidInd(false);
        }

        if (ReIMConstants.YES.equalsIgnoreCase(row.getConsignmentInd())) {
            docHead.setConsignmentInd(true);
        } else {
            docHead.setConsignmentInd(false);
        }

        if (ReIMConstants.YES.equalsIgnoreCase(row.getRtvInd())) {
            docHead.setRtvChargebackInd(true);
        } else {
            docHead.setRtvChargebackInd(false);
        }

        if (ReIMConstants.YES.equalsIgnoreCase(row.getDirectStoreDelieveryInd())) {
            docHead.setDirectStoreDelieveryInd(true);
        } else {
            docHead.setDirectStoreDelieveryInd(false);
        }

        if (ReIMConstants.YES.equalsIgnoreCase(row.getEvaluatedReceiptSettlementInd())) {
            docHead.setEvaluatedReceiptSettlementInd(true);
        } else {
            docHead.setEvaluatedReceiptSettlementInd(false);
        }

        docHead.setCustomDocRef1(row.getCustomDocRef1());
        docHead.setCustomDocRef2(row.getCustomDocRef2());
        docHead.setCustomDocRef3(row.getCustomDocRef3());
        docHead.setCustomDocRef4(row.getCustomDocRef4());
        docHead.setLastUpdateId(row.getLastUpdateId());
        docHead.setLastUpdateDateTime(row.getLastDatetime() == null ? null : new ReIMDate(row
                .getLastDatetime()));
        docHead.setFreightType(row.getFreightType());
        docHead.setRefDoc(Long.valueOf(row.getRefDoc()));
        docHead.setBestTerms(row.getBestTerms());
        docHead.setBestTermsSource(row.getBestTermsSource());
        docHead.setBestTermsDate(row.getBestTermsDate() == null ? null : new ReIMDate(row
                .getBestTermsDate()));
        docHead.setBestTermsDateSource(row.getBestTermsDateSource());
        docHead.setExchangeRate(row.getExchangeRate());

        if (row.getLocation() == Long.MIN_VALUE) {
            docHead.getLocation().setLocationId((String) null);
        } else {
            docHead.getLocation().setLocationId(Long.toString(row.getLocation()));
            docHead.getLocation().setLocationType(row.getLocType());
        }

        if (row.getOrderNo() == Long.MIN_VALUE) {
            docHead.setOrderNo((String) null);
        } else {
            docHead.setOrderNo(Long.toString(row.getOrderNo()));
        }

        if (docHead.getType().equals(Document.MERCHANDISE_INVOICE)) {
            convertRowToMerchandiseDocument(row, (MerchandiseDocument) docHead);
        }

        if (docHead.getType().equals(Document.CREDIT_NOTE)
                || docHead.getType().equals(Document.CREDIT_NOTE_REQUEST_PRICE)
                || docHead.getType().equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
            convertRowToResolutionDocument(row, (ResolutionDocument) docHead);
        }

        if (row.getDealId() == Long.MIN_VALUE) {
            docHead.setDealId(null);
        } else {
            docHead.setDealId(DealId.valueOf(row.getDealId()));
        }

        docHead.setDealType(row.getDealType());
        docHead.setTotalCostIncTax(row.getTotalCostIncTax());
        docHead.setHoldStatus(HoldStatus.fromCode(row.getHoldStatus()));
        if(row.getDiscountDate() != null) {
            docHead.setDiscountDate(new ReIMDate(row.getDiscountDate()));
        }
        return docHead;
    }

    /**
     * Retrieve the document status from the STATUS column of the IM_DOC_HEAD table based on the
     * vendor ID and an external document ID.
     *
     * @param extDocId
     *            The external document ID to get the status for.
     * @param vendorId
     *            The vendor that the external document ID belongs to.
     *
     * @return A String reference containing the document status, per the constants defined in the
     *         Document class.
     *
     * @throws ReIMException
     *             when an I/O error occurs in the DAL.
     */
    public String getDocumentStatusFromExternalIdAndVendor(String extDocId, String vendorId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String status = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            // Query as specified at the beginning of the class.
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(SELECT_DOC_FROM_EXT_DOC_ID_AND_VENDOR);
            stmt.setString(1, extDocId);
            stmt.setString(2, vendorId);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                status = resultSet.getString("STATUS");
            }

            return status;
        } catch (Exception exception) {
            // TODO: Return the appropriate error resource string.
            throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                // TODO: Return the appropriate error resource string.
                throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                        exception, this);

            }
        }

    }

    public String readExtDocIdByVendor(String vendorType, String vendorId, String extDocId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String selectedExtDocId = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(READ_EXT_DOC_ID_BY_VENDOR);
            stmt.setString(1, vendorType);
            stmt.setString(2, vendorId);
            stmt.setString(3, extDocId);
            stmt.setString(4, vendorType);
            stmt.setString(5, vendorId);
            stmt.setString(6, extDocId);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                selectedExtDocId = resultSet.getString("EXT_DOC_ID");
            }

            return selectedExtDocId;
        } catch (Exception exception) {
            throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                        exception, this);

            }
        }
    }

    public String readExtDocId(String docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String selectedExtDocId = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(READ_EXT_DOC_ID);
            stmt.setString(1, docId);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                selectedExtDocId = resultSet.getString("EXT_DOC_ID");
            }

            return selectedExtDocId;
        } catch (Exception exception) {
            throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                        exception, this);

            }
        }
    }

    /**
     * Retrieve a DOC_ID based on the supplied parameters. If no document exists for the given
     * criteria, return the null type.
     *
     * @param vendor
     *            The vendor string for the supplied external document ID.
     * @param externalId
     *            The external document ID for which to query.
     * @param type
     *            The type of the document, i.e. Credit Note - Cost, Debit Memo - Quantity, etc.
     * @return The document ID for the supplied parameters, null otherwise.
     * @throws ReIMException
     *             Thrown on I/O error.
     */
    public String getDocumentIdFromExternalId(String vendor, String externalId, String type)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String selectedDocId = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer sqlText = new StringBuffer(
                    "SELECT DOC_ID FROM IM_DOC_HEAD WHERE EXT_DOC_ID=? AND TYPE=? AND VENDOR=?");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());
            stmt.setString(1, externalId);
            stmt.setString(2, type);
            stmt.setString(3, vendor);

            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                selectedDocId = resultSet.getString("DOC_ID");
            }

            return selectedDocId;
        } catch (Exception exception) {
            throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException exception) {
                throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                        exception, this);

            }
        }
    }

    public String getDocumentIdFromExternalId(String externalId, String type) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String selectedDocId = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT DOC_ID FROM IM_DOC_HEAD WHERE EXT_DOC_ID=?");
            if (type != null) {
                sqlText.append("AND type=?");
            }
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());
            stmt.setString(1, externalId);
            if (type != null) {
                stmt.setString(2, type);
            }
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                selectedDocId = resultSet.getString("DOC_ID");
            }

            return selectedDocId;
        } catch (Exception exception) {
            throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException exception) {
                throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR,
                        exception, this);

            }
        }
    }

    @SuppressWarnings("unused")
	public void updateDocHeadForMatching(MerchandiseDocument[] invoices, String userId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            MerchandiseDocument invoice = null;
            int invoicesLength = invoices.length;

            String sql = "UPDATE IM_DOC_HEAD SET STATUS = ?, DETAIL_MATCHED = ?, MATCH_ID = ?, MATCH_DATE = ?, "
                    + " VARIANCE_WITHIN_TOLERANCE = ?, LAST_DATETIME = ?, LAST_UPDATE_ID = ?,  "
                    + " TAX_DISC_CREATE_DATE = ?  WHERE DOC_ID = ?";

            String sql2 = "UPDATE IM_DOC_HEAD SET STATUS = ?, DETAIL_MATCHED = ?, MATCH_ID = ?, MATCH_DATE = ?, "
                    + " VARIANCE_WITHIN_TOLERANCE = ?, LAST_DATETIME = ?, LAST_UPDATE_ID = ?,  "
                    + " TAX_DISC_CREATE_DATE = ?  WHERE DOC_ID = ?";

//            System.out.println(" updateDocHeadForMatching " + invoice.getOrderNo() );
//            System.out.println(" updateDocHeadForMatching invoice.getLocation().getLocationId() " + invoices.length + invoices );
//            System.out.println(" updateDocHeadForMatching invoice.getLocation().getLocationType() " + invoice.getLocation().getLocationType() );
//            if (invoice.getOrderNo() != null && invoice.getLocation().getLocationId() != null && invoice.getLocation().getLocationType() != null ) {
              if (invoices.length  > 0  ) {

                 stmt = (OraclePreparedStatement) conn.prepareStatement(sql2);
                for (int i = 0; i < invoicesLength; i++) {
                    invoice = invoices[i];
                    stmt.setString(1, invoice.getStatus());
                    stmt.setString(2, invoice.isDetailMatched() ? ReIMConstants.YES : ReIMConstants.NO);
                    stmt.setString(3, invoice.getMatchId());

                    if (invoice.getMatchDate() != null) {
                        stmt.setDate(4, invoice.getMatchDate().getSQL_Date());
                    } else {
                        stmt.setNull(4, java.sql.Types.DATE);
                    }

                    if (invoice.getVarianceWithinTolerance() != null) {
                        stmt.setDouble(5, invoice.getVarianceWithinTolerance().doubleValue());
                    } else {
                        stmt.setNull(5, java.sql.Types.DOUBLE);
                    }

                    stmt.setTimestamp(6, new ReIMDate().getTimestamp());
                    stmt.setString(7, userId);
                    ReIMDate currentDate = invoice.getTaxDiscrepancyCreateDate();
                    if (invoice.getStatus().equals(Document.TAX_DISCREPANCY)) {
                        if (currentDate == null) {
                            stmt.setTimestamp(8, ServiceFactory.getPeriodService().getVDate()
                                    .getTimestamp());
                        } else {
                            stmt.setTimestamp(8, currentDate.getTimestamp());
                        }
                    } else {
                        stmt.setTimestamp(8, null);
                    }

                    stmt.setLong(9, invoice.getDocId());
                    
                    stmt.addBatch();
                }
                
            } else {
                stmt = (OraclePreparedStatement) conn.prepareStatement(sql);

                for (int i = 0; i < invoicesLength; i++) {
                    invoice = invoices[i];
                    stmt.setString(1, invoice.getStatus());
                    stmt.setString(2, invoice.isDetailMatched() ? ReIMConstants.YES : ReIMConstants.NO);
                    stmt.setString(3, invoice.getMatchId());

                    if (invoice.getMatchDate() != null) {
                        stmt.setDate(4, invoice.getMatchDate().getSQL_Date());
                    } else {
                        stmt.setNull(4, java.sql.Types.DATE);
                    }

                    if (invoice.getVarianceWithinTolerance() != null) {
                        stmt.setDouble(5, invoice.getVarianceWithinTolerance().doubleValue());
                    } else {
                        stmt.setNull(5, java.sql.Types.DOUBLE);
                    }

                    stmt.setTimestamp(6, new ReIMDate().getTimestamp());
                    stmt.setString(7, userId);
                    ReIMDate currentDate = invoice.getTaxDiscrepancyCreateDate();
                    if (invoice.getStatus().equals(Document.TAX_DISCREPANCY)) {
                        if (currentDate == null) {
                            stmt.setTimestamp(8, ServiceFactory.getPeriodService().getVDate()
                                    .getTimestamp());
                        } else {
                            stmt.setTimestamp(8, currentDate.getTimestamp());
                        }
                    } else {
                        stmt.setTimestamp(8, null);
                    }

                    stmt.setLong(9, invoice.getDocId());
 // Date Modified : October 24, 2012
 // Modified by : Syed Qadri
 //Fix Made according to SMR Ticket 123436. Put the code inside the Loop. Before the 
 // add batch was outside the loop.                    
                    stmt.addBatch();
            }
               
            }
            stmt.executeBatch();
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_update_invoice_status", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.cannot_update_invoice_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    public void updateResolutionDocHeadForMatching(ResolutionDocument[] resolutionDocs,
            String userId) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String sql = "UPDATE IM_DOC_HEAD SET STATUS = ?, DETAIL_MATCHED = ?, MATCH_ID = ?, MATCH_DATE = ?, "
                    + " VARIANCE_WITHIN_TOLERANCE = ?, LAST_DATETIME = ?, LAST_UPDATE_ID = ? WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql);

            ResolutionDocument resolutionDoc = null;
            int resolutionDocsLength = resolutionDocs.length;
            for (int i = 0; i < resolutionDocsLength; i++) {
                resolutionDoc = resolutionDocs[i];
                stmt.setString(1, resolutionDoc.getStatus());
                stmt.setString(2, resolutionDoc.isDetailMatched() ? ReIMConstants.YES
                        : ReIMConstants.NO);
                stmt.setString(3, resolutionDoc.getMatchId());

                if (resolutionDoc.getMatchDate() != null) {
                    stmt.setDate(4, resolutionDoc.getMatchDate().getSQL_Date());
                } else {
                    stmt.setNull(4, java.sql.Types.DATE);
                }

                if (resolutionDoc.getVarianceWithinTolerance() != null) {
                    stmt.setDouble(5, resolutionDoc.getVarianceWithinTolerance().doubleValue());
                } else {
                    stmt.setNull(5, java.sql.Types.DOUBLE);
                }

                stmt.setTimestamp(6, new ReIMDate().getTimestamp());
                stmt.setString(7, userId);
                stmt.setLong(8, resolutionDoc.getDocId());

                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_update_invoice_status", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.cannot_update_invoice_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    public void updateInvoicesWithoutReceiptsForAutoMatch(MerchandiseDocument[] invoices,
            String userId) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String sql = "UPDATE IM_DOC_HEAD SET COST_PRE_MATCH = ?, DETAIL_MATCHED = ?, STATUS = ?, LAST_DATETIME = ?, LAST_UPDATE_ID = ? WHERE DOC_ID = ?";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql);

            MerchandiseDocument invoice = null;
            int invoicesLength = invoices.length;
            for (int i = 0; i < invoicesLength; i++) {
                invoice = invoices[i];
                stmt.setString(1, (invoice.isCostPreMatched() ? ReIMConstants.YES
                        : ReIMConstants.NO));
                stmt.setString(2,
                        (invoice.isDetailMatched() ? ReIMConstants.YES : ReIMConstants.NO));
                stmt.setString(3, invoice.getStatus());
                stmt.setTimestamp(4, new ReIMDate().getTimestamp());
                stmt.setString(5, userId);
                stmt.setLong(6, invoice.getDocId());
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException exception) {
            throw new ReIMException("error.cannot_update_invoice_price_matched_status",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_update_invoice_price_matched_status",
                        Severity.ERROR, exception, this);
            }
        }
    }

    public HashMap getInvoicesForMatching(SummaryMatchSearchCriteria searchCriteria)
            throws ReIMException {

        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = buildDynamicWhereClause(searchCriteria, conn);
            rs = stmt.executeQuery();
            HashMap map = new HashMap();
            long currentSupplierId = Long.MIN_VALUE;
            String supplierSiteId = null;
            long previousSupplierId = -1;
            ArrayList invoiceIdList = new ArrayList();
            long invoiceId = Long.MIN_VALUE;
            String orderNo = null;
            String locationId = null;
            String locType = null;
            MerchandiseDocument invoice = null;
            boolean firstRecord = true;
            while (rs.next()) {
                currentSupplierId = rs.getLong("VENDOR");
                supplierSiteId = rs.getString("SUPPLIER_SITE_ID");
                invoiceId = rs.getLong("INVOICE_ID");
                orderNo = rs.getString("ORDER_NO");
                locationId = rs.getString("LOCATION");
                locType = rs.getString("LOC_TYPE");
                invoice = new MerchandiseDocument();
                if(supplierSiteId != null) {
                    Vendor supplierSite = new Vendor();
                    supplierSite.setVendorId(supplierSiteId);
                    invoice.setSupplierSite(supplierSite);

                }
                invoice.setDocId(invoiceId);
                invoice.setOrderNo(orderNo);
                invoice.getLocation().setLocationId(locationId);
                invoice.getLocation().setLocationType(locType);
                if (firstRecord) {
                    previousSupplierId = currentSupplierId;
                    firstRecord = false;
                }
                if (currentSupplierId != previousSupplierId) {
                    map.put(previousSupplierId + "", invoiceIdList);
                    previousSupplierId = currentSupplierId;
                    invoiceIdList = new ArrayList();
                    invoiceIdList.add(invoice);
                } else {
                    invoiceIdList.add(invoice);
                }
            }
            // add last vendor to list unless it's null
            if (currentSupplierId != Long.MIN_VALUE) {
                map.put(currentSupplierId + "", invoiceIdList);
            }
            return map;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                        exception, this);

            }
        }
    }

    protected OraclePreparedStatement buildDynamicWhereClause(
            SummaryMatchSearchCriteria searchCriteria, Connection conn) throws ReIMException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        String fromClause = " SELECT /*+ INDEX(DH IM_DOC_HEAD_I10) */ DH.DOC_ID INVOICE_ID, DH.ORDER_NO, DH.LOCATION, DH.VENDOR, DH.LOC_TYPE, DH.SUPPLIER_SITE_ID FROM IM_DOC_HEAD DH";

        StringBuffer sqlText = new StringBuffer(fromClause);
        String queryPart1 = "";
        String queryPart2 = "";

        if (searchCriteria.getInvoiceItemId() != null
                && searchCriteria.getInvoiceItemId().length() > 0) {
            sqlText.append(" ,IM_INVOICE_DETAIL DD");
        }

        sqlText.append(" WHERE DH.TYPE = 'MRCHI' AND DH.VENDOR_TYPE = 'SUPP' AND DH.HOLD_STATUS <> 'H'  ");

        if (searchCriteria.getInvoiceItemId() != null
                && searchCriteria.getInvoiceItemId().length() > 0) {
            sqlText.append(" AND DD.DOC_ID = DH.DOC_ID AND DD.ITEM = ?");
        }

        if (searchCriteria.getSupplierIdList() != null
                && searchCriteria.getSupplierIdList().size() > 0) {
            if (searchCriteria.getSupplierId() != null
                    && searchCriteria.getSupplierId().length() > 0
                    && !searchCriteria.isIncludeLinkedSuppliers()) {
                sqlText.append("   AND DH.VENDOR = ?");
            } else {
                // sqlText.append(" AND DH.VENDOR IN
                // (").append(searchCriteria.getSupplierIdQuery())
                // .append(")");
                if (searchCriteria.getSupplierId() != null
                        && searchCriteria.getSupplierId().length() > 0) {
                    queryPart1 = "SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION ALL SELECT L2.SUPPLIER_ID FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 WHERE L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID  = ?";
                } else {
                    // AP Reviewer must have bee supplied
                    queryPart1 = "SELECT SUPPLIER FROM IM_SUPPLIER_OPTIONS WHERE AP_REVIEWER = ?";
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        queryPart2 = " UNION ALL SELECT L2.SUPPLIER_ID FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 WHERE L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID IN (SELECT SO.SUPPLIER FROM IM_SUPPLIER_OPTIONS SO WHERE SO.AP_REVIEWER = ?)";
                }
                sqlText.append("   AND DH.VENDOR IN (").append(queryPart1 + queryPart2).append(")");
            }

        }
        if (searchCriteria.getSupplierSiteId() != null
                && searchCriteria.getSupplierSiteId().length() > 0) {
            sqlText.append("   AND DH.SUPPLIER_SITE_ID = ?");
        }
        if (searchCriteria.getInvoiceOrderNo() != null
                && searchCriteria.getInvoiceOrderNo().length() > 0) {
            sqlText.append("   AND DH.ORDER_NO = ?");
        }
        if (searchCriteria.getInvoiceLocationId() != null
                && searchCriteria.getInvoiceLocationId().length() > 0) {
            sqlText.append("   AND DH.LOCATION = ?");
        }
        if (searchCriteria.getExtDocId() != null && searchCriteria.getExtDocId().length() > 0) {
            // User must enter '%' for partial search
            sqlText.append("   AND UPPER(DH.EXT_DOC_ID) LIKE UPPER(?)");
        }
        if (searchCriteria.getFromDocDate() != null) {
            sqlText.append("   AND TRUNC(DH.DOC_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getToDocDate() != null) {
            sqlText.append("   AND TRUNC(DH.DOC_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getFromDueDate() != null) {
            sqlText.append("   AND TRUNC(DH.DUE_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getToDueDate() != null) {
            sqlText.append("   AND TRUNC(DH.DUE_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCurrency() != null && searchCriteria.getCurrency().length() > 0) {
            sqlText.append("   AND DH.CURRENCY_CODE = ?");
        }
        if (searchCriteria.getFromDocumentCost() != null
                && searchCriteria.getFromDocumentCost().length() > 0) {
            sqlText.append("   AND DH.TOTAL_COST >= ?");
        }
        if (searchCriteria.getToDocumentCost() != null
                && searchCriteria.getToDocumentCost().length() > 0) {
            sqlText.append("   AND DH.TOTAL_COST <= ?");
        }
        if (searchCriteria.getStatus() != null && searchCriteria.getStatus().length() > 0) {
            if (searchCriteria.getStatus().equals(Document.UNRESOLVED_MATCH)) {
                sqlText.append(" AND DH.STATUS in ('" + Document.UNRESOLVED_MATCH + "','"
                        + Document.READY_FOR_MATCH + "')");
            } else if (searchCriteria.getStatus().equals(Document.MULTI_UNRESOLVED)) {
                sqlText.append(" AND DH.STATUS = '" + Document.MULTI_UNRESOLVED + "'");
            }
        } else {
            sqlText.append("   AND DH.STATUS IN ('");
            sqlText.append(Document.READY_FOR_MATCH);
            sqlText.append("','");
            sqlText.append(Document.UNRESOLVED_MATCH);
            sqlText.append("','");
            sqlText.append(Document.MULTI_UNRESOLVED);
            sqlText.append("')");
        }
        if (searchCriteria.getDetailsExist() != null
                && searchCriteria.getDetailsExist().length() > 0) {
            if (searchCriteria.getDetailsExist().equalsIgnoreCase(ReIMConstants.YES)) {
                sqlText.append("   AND DH.DOC_ID IN (SELECT DOC_ID");
                sqlText.append("                       FROM IM_INVOICE_DETAIL)");
            } else if (searchCriteria.getDetailsExist().equalsIgnoreCase(ReIMConstants.NO)) {
                sqlText.append("   AND DH.DOC_ID NOT IN (SELECT DOC_ID");
                sqlText.append("                           FROM IM_INVOICE_DETAIL)");
            }
        }
        sqlText.append(" ORDER BY DH.VENDOR");

        try {
            OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText
                    .toString());
            int i = 1;
            if (searchCriteria.getInvoiceItemId() != null
                    && searchCriteria.getInvoiceItemId().length() > 0)
                stmt.setString(i++, searchCriteria.getInvoiceItemId());
            if (searchCriteria.getSupplierIdList() != null
                    && searchCriteria.getSupplierIdList().size() > 0) {
                if (searchCriteria.getSupplierId() != null
                        && searchCriteria.getSupplierId().length() > 0) {
                    stmt.setLong(i++, Long.parseLong(searchCriteria.getSupplierId()));
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setLong(i++, Long.parseLong(searchCriteria.getSupplierId()));
                } else {
                    stmt.setString(i++, searchCriteria.getApReviewer());
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setString(i++, searchCriteria.getApReviewer());
                }
            }
            if (searchCriteria.getSupplierSiteIdList() != null
                    && searchCriteria.getSupplierSiteIdList().size() > 0) {
                if (searchCriteria.getSupplierSiteId() != null
                        && searchCriteria.getSupplierSiteId().length() > 0) {
                    stmt.setLong(i++, Long.parseLong(searchCriteria.getSupplierSiteId()));
                }
            }

            if (searchCriteria.getInvoiceOrderNo() != null
                    && searchCriteria.getInvoiceOrderNo().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getInvoiceOrderNo()));
            if (searchCriteria.getInvoiceLocationId() != null
                    && searchCriteria.getInvoiceLocationId().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getInvoiceLocationId()));
            if (searchCriteria.getExtDocId() != null && searchCriteria.getExtDocId().length() > 0)
                stmt.setString(i++, searchCriteria.getExtDocId());
            if (searchCriteria.getFromDocDate() != null) {
                String fromDocDate = formatter.format(searchCriteria.getFromDocDate());
                stmt.setString(i++, fromDocDate);
            }
            if (searchCriteria.getToDocDate() != null) {
                String toDocDate = formatter.format(searchCriteria.getToDocDate());
                stmt.setString(i++, toDocDate);
            }
            if (searchCriteria.getFromDueDate() != null) {
                String fromDueDate = formatter.format(searchCriteria.getFromDueDate());
                stmt.setString(i++, fromDueDate);
            }
            if (searchCriteria.getToDueDate() != null) {
                String toDueDate = formatter.format(searchCriteria.getToDueDate());
                stmt.setString(i++, toDueDate);
            }
            if (searchCriteria.getCurrency() != null && searchCriteria.getCurrency().length() > 0)
                stmt.setString(i++, searchCriteria.getCurrency());
            if (searchCriteria.getFromDocumentCost() != null
                    && searchCriteria.getFromDocumentCost().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getFromDocumentCost()));
            if (searchCriteria.getToDocumentCost() != null
                    && searchCriteria.getToDocumentCost().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getToDocumentCost()));

            return stmt;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                    exception, this);
        }
    }

    public HashMap getCreditNotesGroupedBySupplier(
            CreditNoteSummaryMatchSearchCriteria searchCriteria) throws ReIMException {
        OraclePreparedStatement stmt = null;
        Connection conn = TransactionManagerFactory.getInstance().getConnection();
        stmt = buildCreditNoteDynamicWhereClause(searchCriteria, conn);
        return getCreditNotesGroupedBySupplier(stmt);
    }

    public HashMap getCreditNoteRequestsGroupedBySupplier(
            CreditNoteSummaryMatchSearchCriteria searchCriteria) throws ReIMException {
        OraclePreparedStatement stmt = null;
        Connection conn = TransactionManagerFactory.getInstance().getConnection();
        stmt = buildCreditNoteRequestDynamicWhereClause(searchCriteria, conn);
        return getCreditNoteRequestsGroupedBySupplier(stmt);
    }

    public HashMap getCreditNotesGroupedBySupplier(OraclePreparedStatement stmt)
            throws ReIMException {
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery();
            HashMap map = new HashMap();
            long currentSupplierId = Long.MIN_VALUE;
            long creditNoteId = Long.MIN_VALUE;
            String orderNo = null;
            String locationId = null;
            String locType = null;
            CreditNote creditNote = null;
            while (rs.next()) {
                currentSupplierId = rs.getLong("VENDOR");
                creditNoteId = rs.getLong("CREDIT_NOTE_ID");
                orderNo = rs.getString("ORDER_NO");
                locationId = rs.getString("LOCATION");
                locType = rs.getString("LOC_TYPE");
                creditNote = new CreditNote();
                creditNote.setDocId(creditNoteId);
                creditNote.setOrderNo(orderNo);
                creditNote.getLocation().setLocationId(locationId);
                creditNote.getLocation().setLocationType(locType);
                creditNote.setHoldStatus(rs.getString("HOLD_STATUS"));
                if (map.get(currentSupplierId + "") != null) {
                    ((ArrayList) map.get(currentSupplierId + "")).add(creditNote);
                } else {
                    ArrayList creditNoteIdList = new ArrayList();
                    creditNoteIdList.add(creditNote);
                    map.put(currentSupplierId + "", creditNoteIdList);
                }
            }

            return map;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_credits_requests_for_match",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_credits_requests_for_match",
                        Severity.ERROR, exception, this);

            }
        }
    }

    public HashMap getCreditNoteRequestsGroupedBySupplier(OraclePreparedStatement stmt)
            throws ReIMException {
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery();
            HashMap map = new HashMap();
            long currentSupplierId = Long.MIN_VALUE;
            long creditNoteId = Long.MIN_VALUE;
            String orderNo = null;
            String locationId = null;
            String locType = null;
            CreditRequest creditNote = null;
            while (rs.next()) {
                currentSupplierId = rs.getLong("VENDOR");
                creditNoteId = rs.getLong("CREDIT_NOTE_ID");
                orderNo = rs.getString("ORDER_NO");
                locationId = rs.getString("LOCATION");
                locType = rs.getString("LOC_TYPE");
                creditNote = new CreditRequest();
                creditNote.setDocId(creditNoteId);
                creditNote.setOrderNo(orderNo);
                creditNote.getLocation().setLocationId(locationId);
                creditNote.getLocation().setLocationType(locType);
                if (map.get(currentSupplierId + "") != null) {
                    ((ArrayList) map.get(currentSupplierId + "")).add(creditNote);
                } else {
                    ArrayList creditNoteIdList = new ArrayList();
                    creditNoteIdList.add(creditNote);
                    map.put(currentSupplierId + "", creditNoteIdList);
                }
            }
            return map;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_credits_requests_for_match",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_credits_requests_for_match",
                        Severity.ERROR, exception, this);

            }
        }
    }

    protected OraclePreparedStatement buildCreditNoteDynamicWhereClause(
            CreditNoteSummaryMatchSearchCriteria searchCriteria, Connection conn)
            throws ReIMException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        String fromClause = " SELECT DH.DOC_ID CREDIT_NOTE_ID, DH.ORDER_NO, DH.LOCATION, DH.VENDOR, DH.LOC_TYPE, DH.HOLD_STATUS FROM IM_DOC_HEAD DH";

        StringBuffer sqlText = new StringBuffer(fromClause);

        if (searchCriteria.getCreditNoteItemId() != null
                && searchCriteria.getCreditNoteItemId().length() > 0) {
            sqlText.append(" ,IM_DOC_DETAIL_REASON_CODES DD");
        }

        sqlText.append(" WHERE DH.TYPE = 'CRDNT' AND DH.VENDOR_TYPE = 'SUPP'");

        if (searchCriteria.getCreditNoteItemId() != null
                && searchCriteria.getCreditNoteItemId().length() > 0) {
            sqlText.append(" AND DD.DOC_ID = DH.DOC_ID AND DD.ITEM = ?");
        }

        if (searchCriteria.getSupplierIdList() != null
                && searchCriteria.getSupplierIdList().size() > 0) {
            if (searchCriteria.getSupplierId() != null
                    && searchCriteria.getSupplierId().length() > 0
                    && !searchCriteria.isIncludeLinkedSuppliers())
                sqlText.append("   AND DH.VENDOR = ?");
            else
                sqlText.append("   AND DH.VENDOR IN (").append(searchCriteria.getSupplierIdQuery())
                        .append(")");
        }
        if (searchCriteria.getCreditNoteOrderNo() != null
                && searchCriteria.getCreditNoteOrderNo().length() > 0) {
            sqlText.append("   AND DH.ORDER_NO = ?");
        }
        if (searchCriteria.getCreditNoteLocationId() != null
                && searchCriteria.getCreditNoteLocationId().length() > 0) {
            sqlText.append("   AND DH.LOCATION = ?");
        }
        if (searchCriteria.getCreditNoteFromDocDate() != null) {
            sqlText.append("   AND TRUNC(DH.DOC_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteToDocDate() != null) {
            sqlText.append("   AND TRUNC(DH.DOC_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteFromDueDate() != null) {
            sqlText.append("   AND TRUNC(DH.DUE_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteToDueDate() != null) {
            sqlText.append("   AND TRUNC(DH.DUE_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteCurrency() != null
                && searchCriteria.getCreditNoteCurrency().length() > 0) {
            sqlText.append("   AND DH.CURRENCY_CODE = ?");
        }
        if (searchCriteria.getCreditNoteFromDocumentCost() != null
                && searchCriteria.getCreditNoteFromDocumentCost().length() > 0) {
            sqlText.append("   AND DH.TOTAL_COST >= ?");
        }
        if (searchCriteria.getCreditNoteToDocumentCost() != null
                && searchCriteria.getCreditNoteToDocumentCost().length() > 0) {
            sqlText.append("   AND DH.TOTAL_COST <= ?");
        }
        if (searchCriteria.getCreditNoteExtDocId() != null
                && searchCriteria.getCreditNoteExtDocId().length() > 0) {
            sqlText.append("   AND UPPER(DH.EXT_DOC_ID) like UPPER(?)");
        }

        /**
         * <pre>
         * We only match credit notes when:
         *
         * 1) The credit note is NOT on hold and is in POSTED status.
         *  OR
         * 2) The credit note IS on hold or has been released from hold and is in APPRVE status.
         *
         * If you see a credit note in POSTED status with a hold status of 'R',
         * that means it was at one point matched from APPRVE status.
         *
         * </pre>
         */
        sqlText
                .append(" AND ((DH.STATUS = 'POSTED' AND DH.HOLD_STATUS IN( 'N','P')) OR (DH.STATUS = 'APPRVE' AND (DH.HOLD_STATUS IN ('H','R')))) ");

        if (searchCriteria.getCreditNoteDetailsExist() != null
                && searchCriteria.getCreditNoteDetailsExist().length() > 0) {
            if (searchCriteria.getCreditNoteDetailsExist().equalsIgnoreCase(ReIMConstants.YES)) {
                sqlText.append("   AND DH.DOC_ID IN (SELECT DOC_ID");
                sqlText.append("                       FROM IM_DOC_DETAIL_REASON_CODES)");
            } else if (searchCriteria.getCreditNoteDetailsExist()
                    .equalsIgnoreCase(ReIMConstants.NO)) {
                sqlText.append("   AND DH.DOC_ID NOT IN (SELECT DOC_ID");
                sqlText.append("                           FROM IM_DOC_DETAIL_REASON_CODES)");
            }
        }

        try {
            OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText
                    .toString());
            int i = 1;
            if (searchCriteria.getCreditNoteItemId() != null
                    && searchCriteria.getCreditNoteItemId().length() > 0)
                stmt.setString(i++, searchCriteria.getCreditNoteItemId());
            if (searchCriteria.getSupplierIdList() != null
                    && searchCriteria.getSupplierIdList().size() > 0) {
                if (searchCriteria.getSupplierId() != null
                        && searchCriteria.getSupplierId().length() > 0) {
                    stmt.setString(i++, searchCriteria.getSupplierId());
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setString(i++, searchCriteria.getSupplierId());
                } else {
                    stmt.setString(i++, searchCriteria.getApReviewer());
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setString(i++, searchCriteria.getApReviewer());
                }
            }
            if (searchCriteria.getCreditNoteOrderNo() != null
                    && searchCriteria.getCreditNoteOrderNo().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getCreditNoteOrderNo()));
            if (searchCriteria.getCreditNoteLocationId() != null
                    && searchCriteria.getCreditNoteLocationId().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getCreditNoteLocationId()));
            if (searchCriteria.getCreditNoteFromDocDate() != null) {
                String fromDocDate = formatter.format(searchCriteria.getCreditNoteFromDocDate());
                stmt.setString(i++, fromDocDate);
            }
            if (searchCriteria.getCreditNoteToDocDate() != null) {
                String toDocDate = formatter.format(searchCriteria.getCreditNoteToDocDate());
                stmt.setString(i++, toDocDate);
            }
            if (searchCriteria.getCreditNoteFromDueDate() != null) {
                String fromDueDate = formatter.format(searchCriteria.getCreditNoteFromDueDate());
                stmt.setString(i++, fromDueDate);
            }
            if (searchCriteria.getCreditNoteToDueDate() != null) {
                String toDueDate = formatter.format(searchCriteria.getCreditNoteToDueDate());
                stmt.setString(i++, toDueDate);
            }
            if (searchCriteria.getCreditNoteCurrency() != null
                    && searchCriteria.getCreditNoteCurrency().length() > 0)
                stmt.setString(i++, searchCriteria.getCreditNoteCurrency());
            if (searchCriteria.getCreditNoteFromDocumentCost() != null
                    && searchCriteria.getCreditNoteFromDocumentCost().length() > 0)
                stmt.setDouble(i++, Double.parseDouble(searchCriteria
                        .getCreditNoteFromDocumentCost()));
            if (searchCriteria.getCreditNoteToDocumentCost() != null
                    && searchCriteria.getCreditNoteToDocumentCost().length() > 0)
                stmt.setDouble(i++, Double
                        .parseDouble(searchCriteria.getCreditNoteToDocumentCost()));
            if (searchCriteria.getCreditNoteExtDocId() != null
                    && searchCriteria.getCreditNoteExtDocId().length() > 0)
                stmt.setString(i++, searchCriteria.getCreditNoteExtDocId());

            return stmt;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                    exception, this);
        }
    }

    protected OraclePreparedStatement buildCreditNoteRequestDynamicWhereClause(
            CreditNoteSummaryMatchSearchCriteria searchCriteria, Connection conn)
            throws ReIMException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        String fromClause = " SELECT /*+ USE_CONCAT  */ DH.DOC_ID CREDIT_NOTE_ID, DH.ORDER_NO, DH.LOCATION, DH.VENDOR, DH.LOC_TYPE FROM IM_DOC_HEAD DH";

        StringBuffer sqlText = new StringBuffer(fromClause);

        if (searchCriteria.getCreditNoteRequestItemId() != null
                && searchCriteria.getCreditNoteRequestItemId().length() > 0) {
            sqlText.append(" ,IM_DOC_DETAIL_REASON_CODES DD");
        }

        sqlText.append(" WHERE");

        sqlText.append(" (DH.TYPE = '");
        sqlText.append(Document.CREDIT_NOTE_REQUEST_PRICE);
        sqlText.append("'");
        sqlText.append(" or DH.TYPE = '");
        sqlText.append(Document.CREDIT_NOTE_REQUEST_QUANTITY);
        sqlText.append("'");
        sqlText.append(" or DH.TYPE = '");
        sqlText.append(Document.CREDIT_NOTE_REQUEST_TAX);
        sqlText.append("'");
        sqlText.append(" )");

        sqlText.append("   AND DH.VENDOR_TYPE = 'SUPP'");

        if (searchCriteria.getCreditNoteRequestItemId() != null
                && searchCriteria.getCreditNoteRequestItemId().length() > 0) {
            sqlText.append(" AND DD.DOC_ID = DH.DOC_ID AND DD.ITEM = ?");
        }

        if (searchCriteria.getSupplierIdList() != null
                && searchCriteria.getSupplierIdList().size() > 0) {
            if (searchCriteria.getSupplierId() != null
                    && searchCriteria.getSupplierId().length() > 0
                    && !searchCriteria.isIncludeLinkedSuppliers())
                sqlText.append("   AND DH.VENDOR = ?");
            else
                sqlText.append("   AND DH.VENDOR IN (").append(searchCriteria.getSupplierIdQuery())
                        .append(")");
        }

        if (searchCriteria.getCreditNoteRequestOrderNo() != null
                && searchCriteria.getCreditNoteRequestOrderNo().length() > 0) {
            sqlText.append("   AND DH.ORDER_NO = ?");
        }

        if (searchCriteria.getCreditNoteRequestLocationId() != null
                && searchCriteria.getCreditNoteRequestLocationId().length() > 0) {
            sqlText.append("   AND DH.LOCATION = ?");
        }
        if (searchCriteria.getCreditNoteRequestFromDocDate() != null) {
            sqlText.append("   AND TRUNC(DH.DOC_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteRequestToDocDate() != null) {
            sqlText.append("   AND TRUNC(DH.DOC_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteRequestFromDueDate() != null) {
            sqlText.append("   AND TRUNC(DH.DUE_DATE) >= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteRequestToDueDate() != null) {
            sqlText.append("   AND TRUNC(DH.DUE_DATE) <= to_date(?, 'YYYYMMDD')");
        }
        if (searchCriteria.getCreditNoteRequestCurrency() != null
                && searchCriteria.getCreditNoteRequestCurrency().length() > 0) {
            sqlText.append("   AND DH.CURRENCY_CODE = ?");
        }
        if (searchCriteria.getCreditNoteRequestFromDocumentCost() != null
                && searchCriteria.getCreditNoteRequestFromDocumentCost().length() > 0) {
            sqlText.append("   AND DH.TOTAL_COST >= ?");
        }
        if (searchCriteria.getCreditNoteRequestToDocumentCost() != null
                && searchCriteria.getCreditNoteRequestToDocumentCost().length() > 0) {
            sqlText.append("   AND DH.TOTAL_COST <= ?");
        }

        sqlText.append(" AND (DH.STATUS = '");
        sqlText.append(Document.APPROVED);
        sqlText.append("') ");

        if (searchCriteria.getCreditNoteRequestDetailsExist() != null
                && searchCriteria.getCreditNoteRequestDetailsExist().length() > 0) {
            if (searchCriteria.getCreditNoteRequestDetailsExist().equalsIgnoreCase(
                    ReIMConstants.YES)) {
                sqlText.append("   AND DH.DOC_ID IN (SELECT DOC_ID");
                sqlText.append("                       FROM IM_DOC_DETAIL_REASON_CODES)");
            } else if (searchCriteria.getCreditNoteRequestDetailsExist().equalsIgnoreCase(
                    ReIMConstants.NO)) {
                sqlText.append("   AND DH.DOC_ID NOT IN (SELECT DOC_ID");
                sqlText.append("                           FROM IM_DOC_DETAIL_REASON_CODES)");
            }
        }
        if (searchCriteria.getCreditNoteRequestExtDocId() != null
                && searchCriteria.getCreditNoteRequestExtDocId().length() > 0) {
            sqlText.append("   AND UPPER(DH.EXT_DOC_ID) like UPPER(?)");
        }

        try {
            OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText
                    .toString());
            int i = 1;
            if (searchCriteria.getCreditNoteRequestItemId() != null
                    && searchCriteria.getCreditNoteRequestItemId().length() > 0)
                stmt.setString(i++, searchCriteria.getCreditNoteRequestItemId());
            if (searchCriteria.getSupplierIdList() != null
                    && searchCriteria.getSupplierIdList().size() > 0) {
                if (searchCriteria.getSupplierId() != null
                        && searchCriteria.getSupplierId().length() > 0) {
                    stmt.setString(i++, searchCriteria.getSupplierId());
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setString(i++, searchCriteria.getSupplierId());
                } else {
                    stmt.setString(i++, searchCriteria.getApReviewer());
                    if (searchCriteria.isIncludeLinkedSuppliers())
                        stmt.setString(i++, searchCriteria.getApReviewer());
                }
            } else if (searchCriteria.getSupplierId() != null
                    && searchCriteria.getSupplierId().length() > 0) {
                stmt.setString(i++, searchCriteria.getSupplierId());
            }
            if (searchCriteria.getCreditNoteRequestOrderNo() != null
                    && searchCriteria.getCreditNoteRequestOrderNo().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getCreditNoteRequestOrderNo()));
            if (searchCriteria.getCreditNoteRequestLocationId() != null
                    && searchCriteria.getCreditNoteRequestLocationId().length() > 0)
                stmt.setLong(i++, Long.parseLong(searchCriteria.getCreditNoteRequestLocationId()));
            if (searchCriteria.getCreditNoteRequestFromDocDate() != null) {
                String fromDocDate = formatter.format(searchCriteria
                        .getCreditNoteRequestFromDocDate());
                stmt.setString(i++, fromDocDate);
            }
            if (searchCriteria.getCreditNoteRequestToDocDate() != null) {
                String toDocDate = formatter.format(searchCriteria.getCreditNoteRequestToDocDate());
                stmt.setString(i++, toDocDate);
            }
            if (searchCriteria.getCreditNoteRequestFromDueDate() != null) {
                String fromDueDate = formatter.format(searchCriteria
                        .getCreditNoteRequestFromDueDate());
                stmt.setString(i++, fromDueDate);
            }
            if (searchCriteria.getCreditNoteRequestToDueDate() != null) {
                String toDueDate = formatter.format(searchCriteria.getCreditNoteRequestToDueDate());
                stmt.setString(i++, toDueDate);
            }
            if (searchCriteria.getCreditNoteRequestCurrency() != null
                    && searchCriteria.getCreditNoteRequestCurrency().length() > 0)
                stmt.setString(i++, searchCriteria.getCreditNoteRequestCurrency());
            if (searchCriteria.getCreditNoteRequestFromDocumentCost() != null
                    && searchCriteria.getCreditNoteRequestFromDocumentCost().length() > 0)
                stmt.setDouble(i++, Double.parseDouble(searchCriteria
                        .getCreditNoteRequestFromDocumentCost()));
            if (searchCriteria.getCreditNoteRequestToDocumentCost() != null
                    && searchCriteria.getCreditNoteRequestToDocumentCost().length() > 0)
                stmt.setDouble(i++, Double.parseDouble(searchCriteria
                        .getCreditNoteRequestToDocumentCost()));
            if (searchCriteria.getCreditNoteRequestExtDocId() != null
                    && searchCriteria.getCreditNoteRequestExtDocId().length() > 0)
                stmt.setString(i++, searchCriteria.getCreditNoteRequestExtDocId());

            return stmt;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invcs_for_match", Severity.ERROR,
                    exception, this);
        }
    }

    public ImDocHeadRow getApprovalDateByDocumentId(String documentId) throws ReIMException {
        try {
            String[] columns = new String[] { "APPROVAL_DATE"};

            return super.read(columns, new Long(documentId).longValue(), true);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("ImDocHeadAccessExt.get_approval_date_by_document_id",
                    Severity.ERROR, e, this);
        }
    }

    public ImDocHeadRow getMatchDateByDocumentId(String documentId) throws ReIMException {
        try {
            String[] columns = new String[] { "MATCH_DATE"};

            return super.read(columns, new Long(documentId).longValue(), true);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("ImDocHeadAccessExt.get_match_date_by_document_id",
                    Severity.ERROR, e, this);
        }
    }

    /**
     * selectCreditNoteRequests(String, String)
     *
     * @param supplier
     *            id
     * @param external
     *            doc id of a credit note request cost or qty (with system options prefix)
     * @return DocumentLOV[]
     *
     *         Overloaded LOV query that returns a Credit Note Request - Cost or Credit Note
     *         Request- Qty documentLOV. The External Doc id must have the associated system option
     *         prefix otherwise invalid id will be returned.
     *
     *         i.e. CRQEXT12345678 where CRQ is the system option prefix for desired document type
     */
    public DocumentLOV[] selectCreditNoteRequests(String supplier, String extDocId)
            throws ReIMException {

        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String prefix = null;

            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            String documentType = null;
            String dbExtDocId = null;
            String dynamicWhere = null;

            if (extDocId != null && !extDocId.equals(ReIMConstants.EMPTY_STRING)) {
                // One or more documents may have the same External Document Id
                // but only one (per supplier) of each document TYPE should
                // exist.
                // Ensure we return the correct document by comparing the prefix
                // that the
                // user entered to the document type

                // STRIP OFF THE THREE LETTER SYSTEM OPTIONS PREFIX
                prefix = extDocId.substring(0, 3);

                if (prefix.equalsIgnoreCase(systemOptions.getCreditNotePrefixQty())) {
                    documentType = Document.CREDIT_NOTE_REQUEST_QUANTITY;
                } else if (prefix.equalsIgnoreCase(systemOptions.getCreditNotePrefixCost())) {
                    documentType = Document.CREDIT_NOTE_REQUEST_PRICE;
                } else {
                    // invalid id. Id must be Credit Note Request Cost or Qty
                    return null;
                }

                dbExtDocId = extDocId.substring(3);

                dynamicWhere = " WHERE TYPE = '" + documentType + "' AND EXT_DOC_ID = ?";
            } else {
                dynamicWhere = " WHERE TYPE IN ('" + Document.CREDIT_NOTE_REQUEST_PRICE + "','"
                        + Document.CREDIT_NOTE_REQUEST_QUANTITY + "') ";
            }

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT DOC_ID, STATUS, EXT_DOC_ID, TYPE"
                            + " FROM IM_DOC_HEAD " + dynamicWhere + " AND VENDOR = ?"
                            + " ORDER BY EXT_DOC_ID");

            if (extDocId != null) {
                stmt.setString(1, dbExtDocId);
                stmt.setString(2, supplier);
            } else {
                stmt.setString(1, supplier);
            }

            rs = stmt.executeQuery();

            return createDocLOVfromRS(rs);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_crdtNtRqsts", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_crdtNtRqsts", Severity.ERROR,
                        exception, this);

            }
        }
    }

    // This could be changed to be used for more than just credit note requests
    private DocumentLOV[] createDocLOVfromRS(ResultSet rs) throws Exception {
        String dispalyExtDocId = null;
        String status = null;
        String docId = null;
        String type = null;
        DocumentLOV docLOV = null;
        ArrayList docsList = new ArrayList();
        String costPrefix = ReIMUserContext.getSystemOptions().getCreditNotePrefixCost();
        String qtyPrefix = ReIMUserContext.getSystemOptions().getCreditNotePrefixQty();

        while (rs.next()) {
            dispalyExtDocId = rs.getString("EXT_DOC_ID");
            status = rs.getString("STATUS");
            docId = rs.getString("DOC_ID");
            type = rs.getString("TYPE");

            if (type.equals(Document.CREDIT_NOTE_REQUEST_PRICE)) {

                docLOV = new DocumentLOV(costPrefix + dispalyExtDocId, status, docId);
            } else {
                // credit note request qty
                docLOV = new DocumentLOV(qtyPrefix + dispalyExtDocId, status, docId);
            }

            docsList.add(docLOV);
        }

        DocumentLOV[] docLOVArray = new DocumentLOV[docsList.size()];
        docLOVArray = (DocumentLOV[]) docsList.toArray(docLOVArray);
        return docLOVArray;
    }

    public MerchandiseDocument[] readMatchedInvoicesForPosting() throws ReIMException {
        try {
            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment(
                    "TYPE = ? AND STATUS = ? AND NOT EXISTS (SELECT 'X' FROM IM_RESOLUTION_ACTION R WHERE R.DOC_ID = IM_DOC_HEAD.DOC_ID AND R.STATUS = 'U') AND NOT EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL I WHERE I.DOC_ID = IM_DOC_HEAD.DOC_ID AND I.ADJUSTMENT_PENDING = 'Y')");

            frag.setString(1, Document.MERCHANDISE_INVOICE);
            frag.setString(2, Document.MATCHED);
            ImDocHeadRow[] rows = this.read(frag, null, null, null);

            // When status is matched, then populateMerchandiseDocuments will
            // ONLY return
            // Document objects that are MerchandiseDocument objects.
            return populateMerchandiseDocuments(rows);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.unable_to_retrieve_matched_invoices", Severity.ERROR,
                    exception, this);
        }
    }

    public Document[] readApprovedDocuments(String docType) throws ReIMException {
        try {
            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment(typeColumn + " = ? and "
                    + statusColumn + " = ? ");
            frag.setString(1, docType);
            frag.setString(2, Document.APPROVED);
            ImDocHeadRow[] rows = this.read(frag, null, null, null);

            return (rows == null) ? null : populateDocuments(rows);
        } catch (Exception exception) {
            throw new ReIMException("error.unable_to_retrieve_approved_documents", Severity.ERROR,
                    exception, this);
        }
    }

    public Document[] readApprovedDebitMemos() throws ReIMException {
        try {
            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment("(" + typeColumn
                    + " = ? or " + typeColumn + " = ? or " + typeColumn + " = ?) and "
                    + statusColumn + " = ? ");
            frag.setString(1, Document.DEBIT_MEMO_PRICE);
            frag.setString(2, Document.DEBIT_MEMO_QUANTITY);
            frag.setString(3, Document.DEBIT_MEMO_TAX);
            frag.setString(4, Document.APPROVED);
            ImDocHeadRow[] rows = this.read(frag, null, null, null);

            return (rows == null) ? null : populateDocuments(rows);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.unable_to_retrieve_approved_documents", Severity.ERROR,
                    exception, this);
        }
    }

    public Document[] readApprovedCreditMemos() throws ReIMException {
        try {
            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment("(" + typeColumn
                    + " = ? or " + typeColumn + " = ?) and " + statusColumn + " = ? ");
            frag.setString(1, Document.CREDIT_MEMO_PRICE);
            frag.setString(2, Document.CREDIT_MEMO_QUANTITY);
            frag.setString(3, Document.APPROVED);
            ImDocHeadRow[] rows = this.read(frag, null, null, null);

            return (rows == null) ? null : populateDocuments(rows);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.unable_to_retrieve_approved_documents", Severity.ERROR,
                    exception, this);
        }
    }

    public ImDocHeadRow[] readApprovedCreditNoteRequests() throws ReIMException {
        try {
            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment("(" + typeColumn
                    + " = ? or " + typeColumn + " = ? or " + typeColumn + " = ?) and "
                    + statusColumn + " = ? ");
            frag.setString(1, Document.CREDIT_NOTE_REQUEST_QUANTITY);
            frag.setString(2, Document.CREDIT_NOTE_REQUEST_PRICE);
            frag.setString(3, Document.CREDIT_NOTE_REQUEST_TAX);
            frag.setString(4, Document.APPROVED);
            ImDocHeadRow[] rows = this.read(frag, null, null, null);

            return rows;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.unable_to_retrieve_approved_credit_note_requests",
                    Severity.ERROR, exception, this);
        }
    }

    /**
     * This method returns the resolution adjusted total cost field for a given document.
     *
     * @return Resolution adjusted total cost
     * @param docId
     *            Document id
     * @throws ReIMException
     */
    public Double readResolutionAdjustedTotalCost(long docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        Double resolutionAdjustedTotalCost = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT RESOLUTION_ADJUSTED_TOTAL_COST from IM_DOC_HEAD where DOC_ID = ?");
            stmt.setLong(1, docId);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                resolutionAdjustedTotalCost = new Double(resultSet
                        .getDouble("RESOLUTION_ADJUSTED_TOTAL_COST"));
            }

            return resolutionAdjustedTotalCost;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_retrieve_adj_cost", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.could_not_retrieve_adj_cost", Severity.ERROR,
                        exception, this);

            }
        }
    }
    public Double readResolutionAdjustedTotalQty(long docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        Double resolutionAdjustedTotalQty = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT RESOLUTION_ADJUSTED_TOTAL_QTY from IM_DOC_HEAD where DOC_ID = ?");
            stmt.setLong(1, docId);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                resolutionAdjustedTotalQty = new Double(resultSet
                        .getDouble("RESOLUTION_ADJUSTED_TOTAL_QTY"));
            }

            return resolutionAdjustedTotalQty;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_retrieve_adj_cost", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.could_not_retrieve_adj_cost", Severity.ERROR,
                        exception, this);

            }
        }
    }
    /**
     * @param documents
     *            a String that has a coma separated list of document ids
     * @return null if no documents from the list supplied have parents or an array of parent
     *         document ids
     * @throws ReIMException
     */
    public long[] readParentDocuments(String documents) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        Vector list = new Vector();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT UNIQUE DOC_ID FROM IM_DOC_HEAD WHERE PARENT_ID IS NOT NULL AND DOC_ID IN ("
                            + documents + ")");
            // stmt.setString(1, documents);
            resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                list.add(Long.valueOf(resultSet.getLong("DOC_ID")));
            }
            if (list.isEmpty())
                return null;
            else {
                Object[] objects = list.toArray();
                int arraySize = objects.length;
                long[] result = new long[arraySize];

                for (int i = 0; i < arraySize; i++) {
                    result[i] = ((Long) objects[i]).longValue();
                }
                return result;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new ReIMException("error.cannot_retrieve_parent_docs", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_parent_docs", Severity.ERROR,
                        exception, this);
            }
        }
    }

    /**
     * This method returns document information for documents(merch and credit notes) available for
     * rollup. These documents must have a status of matched a resolution action status of unrolled
     *
     * @return Collection of im_doc_head row objects
     * @throws ReIMException
     */
    public Map<DocId, Document> readDocumentsForRollup() {
        try {
            Map<DocId, Document> documents = new HashMap<DocId, Document>();

            StringBuffer whereClause = new StringBuffer();
            whereClause
                    .append("EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL D, IM_RESOLUTION_ACTION A WHERE A.STATUS = 'U' AND IM_DOC_HEAD.STATUS = 'MTCH' AND IM_DOC_HEAD.TYPE = 'MRCHI' AND IM_DOC_HEAD.DOC_ID = D.DOC_ID AND D.DOC_ID = A.DOC_ID AND D.ITEM = A.ITEM) OR EXISTS (SELECT 'X' FROM IM_RESOLUTION_ACTION A, IM_DOC_DETAIL_REASON_CODES R WHERE A.STATUS = 'U' AND IM_DOC_HEAD.STATUS = 'MTCH' AND IM_DOC_HEAD.TYPE != 'MRCHI' AND IM_DOC_HEAD.DOC_ID = R.DOC_ID AND R.ITEM = A.ITEM)");

            ImDocHeadRow[] rows = read(whereClause.toString(), null, null, null);

            if (rows != null) {
                int length = rows.length;

                for (int i = 0; i < length; i++) {
                    Document row = convertRowToDocument(rows[i]);
                    documents.put(DocId.valueOf(row.getDocId()), row);
                }
            }

            return documents;
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }

    /**
     * Method: readMatchedCreditNotesForTheAction
     *
     * This method reads the matched and unrolled credit note data from the im_doc_head and
     * im_resolution_actions tables and returns the Documents array.
     *
     * @param resAction
     * @return
     * @throws ReIMException
     */
    public Document[] readMatchedCreditNotesForTheAction(String resAction) throws ReIMException {
        Document[] documents = null;
        try {
            ImDocHeadRow[] docHeadRows = readCredinoteRecords(resAction, Document.CREDIT_NOTE,
                    Document.MATCHED, ResolutionMerchandiseInvoice.UNROLLED);
            if (docHeadRows != null) {
                int length = docHeadRows.length;
                documents = new Document[length];
                for (int i = 0; i < length; i++) {
                    Document row = convertRowToDocument(docHeadRows[i]);
                    documents[i] = row;
                }
            }
            return documents;
        } catch (ReIMException ex) {
            throw ex;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_retrieve_documents", Severity.ERROR,
                    exception, this);
        }
    }

    /**
     * method: readCredinoteRecords
     *
     * Performs the database query to retrieve the im_doc_head rows using attributes from
     * im_doc_head and im_resolution_action rows based on the given criteria.
     *
     * @param resAction
     * @param docType
     * @param matchStatus
     * @param rollupStatus
     * @return ImDocHeadRow array
     * @throws ReIMException
     */
    private ImDocHeadRow[] readCredinoteRecords(String resAction, String docType,
            String matchStatus, String rollupStatus) throws ReIMException {
        OracleStatement stmnt = null;
        ResultSet rs1 = null;
        String sqlTxt = null;

        try {
            StringBuffer whereClause = new StringBuffer();
            whereClause.append(" FROM IM_DOC_HEAD DH,");
            whereClause.append(" IM_RESOLUTION_ACTION RA");
            whereClause.append(" WHERE DH.DOC_ID = RA.DOC_ID");
            whereClause.append(" AND DH.TYPE = '");
            whereClause.append(Document.CREDIT_NOTE);
            whereClause.append("' ");
            whereClause.append(" AND DH.STATUS = '");
            whereClause.append(matchStatus);
            whereClause.append("' ");
            whereClause.append(" AND RA.ACTION = '");
            whereClause.append(resAction);
            whereClause.append("' ");
            whereClause.append(" AND RA.STATUS = '");
            whereClause.append(rollupStatus);
            whereClause.append("' ");

            String selectString = "SELECT distinct DH.DOC_ID,DH.TYPE,DH.STATUS,DH.ORDER_NO,DH.LOCATION,DH.LOC_TYPE, DH.TOTAL_DISCOUNT,DH.GROUP_ID,DH.PARENT_ID, DH.DOC_DATE,DH.CREATE_DATE,DH.CREATE_ID, DH.VENDOR_TYPE,DH.VENDOR,DH.EXT_DOC_ID, DH.EDI_UPLOAD_IND,DH.EDI_DOWNLOAD_IND, DH.TERMS,DH.TERMS_DSCNT_PCT,DH.DUE_DATE, DH.PAYMENT_METHOD,DH.MATCH_ID, DH.MATCH_DATE,DH.APPROVAL_ID, DH.APPROVAL_DATE,DH.PRE_PAID_IND, DH.PRE_PAID_ID,DH.POST_DATE, DH.CURRENCY_CODE,DH.EXCHANGE_RATE, DH.TOTAL_COST,DH.TOTAL_QTY, DH.MANUALLY_PAID_IND, DH.CUSTOM_DOC_REF_1, DH.CUSTOM_DOC_REF_2, DH.CUSTOM_DOC_REF_3, DH.CUSTOM_DOC_REF_4,DH.LAST_UPDATE_ID,DH.LAST_DATETIME,DH.FREIGHT_TYPE,DH.REF_DOC,DH.REF_AUTH_NO,DH.COST_PRE_MATCH,DH.DETAIL_MATCHED,DH.BEST_TERMS,DH.BEST_TERMS_SOURCE,DH.BEST_TERMS_DATE,DH.BEST_TERMS_DATE_SOURCE,DH.VARIANCE_WITHIN_TOLERANCE,DH.RESOLUTION_ADJUSTED_TOTAL_COST,DH.RESOLUTION_ADJUSTED_TOTAL_QTY,DH.CONSIGNMENT_IND,DH.DEAL_ID,DH.RTV_IND,DH.DISCOUNT_DATE,DH.DEAL_TYPE,DH.TOTAL_COST_INC_TAX,DH.TAX_DISC_CREATE_DATE,DH.DSD_IND,DH.ERS_IND, RA.ACTION, RA.ITEM, RA.EXTENDED_COST,  RA.QUANTITY,  RA.REASON_CODE,  RA.STATUS,  RA.UNIT_COST,  RA.SHIPMENT";
            sqlTxt = selectString + whereClause.toString();

            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OracleStatement) conn.createStatement();
            stmnt.defineColumnType(1, Types.BIGINT);
            stmnt.defineColumnType(2, Types.VARCHAR, 6);
            stmnt.defineColumnType(3, Types.VARCHAR, 10);
            stmnt.defineColumnType(4, Types.BIGINT);
            stmnt.defineColumnType(5, Types.BIGINT);
            stmnt.defineColumnType(6, Types.VARCHAR, 1);
            stmnt.defineColumnType(7, Types.DOUBLE);
            stmnt.defineColumnType(8, Types.BIGINT);
            stmnt.defineColumnType(9, Types.BIGINT);
            stmnt.defineColumnType(10, Types.TIMESTAMP);
            stmnt.defineColumnType(11, Types.TIMESTAMP);
            stmnt.defineColumnType(12, Types.VARCHAR, 30);
            stmnt.defineColumnType(13, Types.VARCHAR, 6);
            stmnt.defineColumnType(14, Types.VARCHAR, 10);
            stmnt.defineColumnType(15, Types.VARCHAR, 150);
            stmnt.defineColumnType(16, Types.VARCHAR, 1);
            stmnt.defineColumnType(17, Types.VARCHAR, 1);
            stmnt.defineColumnType(18, Types.VARCHAR, 15);
            stmnt.defineColumnType(19, Types.DOUBLE);
            stmnt.defineColumnType(20, Types.TIMESTAMP);
            stmnt.defineColumnType(21, Types.VARCHAR, 6);
            stmnt.defineColumnType(22, Types.VARCHAR, 30);
            stmnt.defineColumnType(23, Types.TIMESTAMP);
            stmnt.defineColumnType(24, Types.VARCHAR, 30);
            stmnt.defineColumnType(25, Types.TIMESTAMP);
            stmnt.defineColumnType(26, Types.VARCHAR, 1);
            stmnt.defineColumnType(27, Types.VARCHAR, 30);
            stmnt.defineColumnType(28, Types.TIMESTAMP);
            stmnt.defineColumnType(29, Types.VARCHAR, 3);
            stmnt.defineColumnType(30, Types.DOUBLE);
            stmnt.defineColumnType(31, Types.DOUBLE);
            stmnt.defineColumnType(32, Types.DOUBLE);
            stmnt.defineColumnType(33, Types.VARCHAR, 1);
            stmnt.defineColumnType(34, Types.VARCHAR, 60);
            stmnt.defineColumnType(35, Types.VARCHAR, 60);
            stmnt.defineColumnType(36, Types.VARCHAR, 60);
            stmnt.defineColumnType(37, Types.VARCHAR, 60);
            stmnt.defineColumnType(38, Types.VARCHAR, 30);
            stmnt.defineColumnType(39, Types.TIMESTAMP);
            stmnt.defineColumnType(40, Types.VARCHAR, 6);
            stmnt.defineColumnType(41, Types.BIGINT);
            stmnt.defineColumnType(42, Types.BIGINT);
            stmnt.defineColumnType(43, Types.VARCHAR, 1);
            stmnt.defineColumnType(44, Types.VARCHAR, 1);
            stmnt.defineColumnType(45, Types.VARCHAR, 15);
            stmnt.defineColumnType(46, Types.VARCHAR, 6);
            stmnt.defineColumnType(47, Types.TIMESTAMP);
            stmnt.defineColumnType(48, Types.VARCHAR, 6);
            stmnt.defineColumnType(49, Types.DOUBLE);
            stmnt.defineColumnType(50, Types.DOUBLE);
            stmnt.defineColumnType(51, Types.DOUBLE);
            stmnt.defineColumnType(52, Types.VARCHAR, 1);
            stmnt.defineColumnType(53, Types.BIGINT);
            stmnt.defineColumnType(54, Types.VARCHAR, 1);
            stmnt.defineColumnType(55, Types.TIMESTAMP);
            stmnt.defineColumnType(56, Types.VARCHAR, 1);
            stmnt.defineColumnType(57, Types.DOUBLE);
            stmnt.defineColumnType(58, Types.TIMESTAMP);
            stmnt.defineColumnType(59, Types.VARCHAR, 1);
            stmnt.defineColumnType(60, Types.VARCHAR, 1);

            rs1 = stmnt.executeQuery(sqlTxt);
            Vector<ImDocHeadRow> creditNotesVector = new Vector<ImDocHeadRow>();
            ArrayList docIdsList = new ArrayList();
            // check for valid ResultSet
            while (rs1.next()) {
                long orderNo = rs1.getLong(4);
                if (rs1.wasNull()) {
                    orderNo = Long.MIN_VALUE;
                }
                double totalDiscount = rs1.getDouble(7);
                if (rs1.wasNull()) {
                    totalDiscount = Double.MIN_VALUE;
                }
                long groupId = rs1.getLong(8);
                if (rs1.wasNull()) {
                    groupId = Long.MIN_VALUE;
                }
                long parentId = rs1.getLong(9);
                if (rs1.wasNull()) {
                    parentId = Long.MIN_VALUE;
                }
                long refDoc = rs1.getLong(41);
                if (rs1.wasNull()) {
                    refDoc = Long.MIN_VALUE;
                }
                long refAuthNo = rs1.getLong(42);
                if (rs1.wasNull()) {
                    refAuthNo = Long.MIN_VALUE;
                }
                double varianceWithinTolerance = rs1.getDouble(49);
                if (rs1.wasNull()) {
                    varianceWithinTolerance = Double.MIN_VALUE;
                }
                long dealId = rs1.getLong(53);
                if (rs1.wasNull()) {
                    dealId = Long.MIN_VALUE;
                }
                if (!docIdsList.contains(Long.toString(rs1.getLong(1)))) {
                    docIdsList.add(Long.toString(rs1.getLong(1)));
                    creditNotesVector.add(new ImDocHeadRow(rs1.getLong(1), rs1.getString(2), rs1
                            .getString(3), orderNo, rs1.getLong(5), rs1.getString(6),
                            totalDiscount, groupId, parentId, rs1.getTimestamp(10), rs1
                                    .getTimestamp(11), rs1.getString(12), rs1.getString(13), rs1
                                    .getString(14), rs1.getString(15), rs1.getString(16), rs1
                                    .getString(17), rs1.getString(18), rs1.getDouble(19), rs1
                                    .getDate(20), rs1.getString(21), rs1.getString(22), rs1
                                    .getTimestamp(23), rs1.getString(24), rs1.getTimestamp(25), rs1
                                    .getString(26), rs1.getString(27), rs1.getTimestamp(28), rs1
                                    .getString(29), rs1.getDouble(30), rs1.getDouble(31), rs1
                                    .getDouble(32), rs1.getString(33), rs1.getString(34), rs1
                                    .getString(35), rs1.getString(36), rs1.getString(37), rs1
                                    .getString(38), rs1.getTimestamp(39), rs1.getString(40),
                            refDoc, refAuthNo, rs1.getString(43), rs1.getString(44), rs1
                                    .getString(45), rs1.getString(46), rs1.getTimestamp(47), rs1
                                    .getString(48), varianceWithinTolerance, rs1.getDouble(50), rs1
                                    .getDouble(51), rs1.getString(52), dealId, rs1.getString(54),
                            rs1.getTimestamp(55), rs1.getString(56) != null ? DealType.fromCode(rs1
                                    .getString(56)) : null, rs1.getDouble(57),
                            rs1.getTimestamp(58), rs1.getString(61), rs1.getString(59), rs1.getString(60)));
                }
            }
            ImDocHeadRow[] docHeadRows = null;
            if (creditNotesVector.size() > 0) {
                docHeadRows = new ImDocHeadRow[creditNotesVector.size()];
                creditNotesVector.copyInto(docHeadRows);
            }

            return docHeadRows;
        } catch (SQLException ex) {
            throw new ReIMException("DALGen.cannot_perform_bulk_select", Severity.ERROR, ex, this,
                    new String[] { sqlTxt, String.valueOf(" (no bind variables) ")});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    private static final String SELECT_LATE_CNR_SQL = "SELECT DH.DOC_ID, DH.TYPE, DH.EXT_DOC_ID FROM IM_DOC_HEAD DH, IM_SUPPLIER_OPTIONS SO WHERE  TRUNC(DH.DUE_DATE) <= ? AND DH.STATUS = 'APPRVE' AND DH.TYPE IN ('CRDNRC','CRDNRT','CRDNRQ') AND DH.VENDOR = SO.SUPPLIER AND SO.SEND_DEBIT_MEMO = 'L'";
    private static final String CRITERIA_APPRVE = " AND NOT EXISTS (SELECT 'X' FROM IM_DOC_HEAD IDH WHERE IDH.REF_DOC = DH.DOC_ID AND IDH.TYPE IN ('DEBMEC','DEBMEQ','DEBMET'))";

    public Vector readLateCreditNoteRequests() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        Date vdate = ServiceFactory.getPeriodService().getVDate().getSQL_Date();
        ReIMDate reimVdate = new ReIMDate(vdate);
        long docId = 0;
        String docType = null;
        String extDocId = null;

        Vector lateDocIds = new Vector();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            reimVdate.addDays(systemOptions.getDebitMemoSendDays());

            if(Boolean.valueOf(Utility.getApplicationValue("void_late_credit_note_requests"))){
                stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_LATE_CNR_SQL);
            } else {
                stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_LATE_CNR_SQL + CRITERIA_APPRVE);
            }
            stmt.setDate(1, reimVdate.getSQL_Date());

            rs = stmt.executeQuery();

            while (rs.next()) {
                docId = rs.getLong(1);
                docType = rs.getString(2);
                extDocId = rs.getString(3);

                ImDocHeadRow row = new ImDocHeadRow();

                row.setDocId(docId);
                row.setType(docType);
                row.setExtDocId(extDocId);

                lateDocIds.add(row);
            }

            return lateDocIds;

        } catch (Exception exception) {
            throw new ReIMException("error.cannot_access_late_credit_note_requests",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_access_late_credit_note_requests",
                        Severity.ERROR, exception, this);

            }
        }
    }

    public long createDebitMemoHeaderFromLateCreditNoteRequest(String docType, String userId,
            long existingDocId, String extDocId) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String sqlTxt = "INSERT INTO IM_DOC_HEAD "
                + "(DOC_ID,TYPE,STATUS,ORDER_NO,LOCATION,LOC_TYPE,TOTAL_DISCOUNT,GROUP_ID,DOC_DATE,CREATE_DATE,CREATE_ID,VENDOR_TYPE,VENDOR,EXT_DOC_ID,EDI_UPLOAD_IND,EDI_DOWNLOAD_IND,TERMS,TERMS_DSCNT_PCT,DUE_DATE,PAYMENT_METHOD,MATCH_ID,MATCH_DATE,APPROVAL_ID,APPROVAL_DATE,PRE_PAID_IND,PRE_PAID_ID,POST_DATE,CURRENCY_CODE,EXCHANGE_RATE,TOTAL_COST,TOTAL_QTY,MANUALLY_PAID_IND,CUSTOM_DOC_REF_1,CUSTOM_DOC_REF_2,CUSTOM_DOC_REF_3,CUSTOM_DOC_REF_4,LAST_UPDATE_ID,LAST_DATETIME,FREIGHT_TYPE,REF_DOC,REF_AUTH_NO,COST_PRE_MATCH,DETAIL_MATCHED,BEST_TERMS,BEST_TERMS_SOURCE,BEST_TERMS_DATE,BEST_TERMS_DATE_SOURCE,VARIANCE_WITHIN_TOLERANCE,RESOLUTION_ADJUSTED_TOTAL_COST,RESOLUTION_ADJUSTED_TOTAL_QTY,CONSIGNMENT_IND,DEAL_ID,DEAL_TYPE,RTV_IND, TOTAL_COST_INC_TAX) "
                + "  SELECT ?,?,STATUS,ORDER_NO,LOCATION,LOC_TYPE,TOTAL_DISCOUNT,GROUP_ID,?,?,?,VENDOR_TYPE,VENDOR,?,EDI_UPLOAD_IND,EDI_DOWNLOAD_IND,TERMS,TERMS_DSCNT_PCT,?,PAYMENT_METHOD,MATCH_ID,MATCH_DATE,?,?,PRE_PAID_IND,PRE_PAID_ID,POST_DATE,CURRENCY_CODE,EXCHANGE_RATE,TOTAL_COST,TOTAL_QTY,MANUALLY_PAID_IND,CUSTOM_DOC_REF_1,CUSTOM_DOC_REF_2,CUSTOM_DOC_REF_3,CUSTOM_DOC_REF_4,?,?,FREIGHT_TYPE,DOC_ID,REF_AUTH_NO,COST_PRE_MATCH,DETAIL_MATCHED,?,'"
                + Document.SOURCE_DOCUMENT
                + "',?,'"
                + Document.SOURCE_DOCUMENT_DATE
                + "',VARIANCE_WITHIN_TOLERANCE,RESOLUTION_ADJUSTED_TOTAL_COST,RESOLUTION_ADJUSTED_TOTAL_QTY,CONSIGNMENT_IND,DEAL_ID,DEAL_TYPE,RTV_IND,TOTAL_COST_INC_TAX"
                + "  FROM IM_DOC_HEAD WHERE DOC_ID = ? ";
        try {
            // For debit memos created as the result of an expired due date
            // on a Credit Note Request, set best terms/source, best terms
            // date/source
            // on IM_DOC_HEAD and IM_FINANCIALS_STAGE for the debit memo as the
            // following:
            // BEST TERMS - default pay now terms from system options
            // BEST TERMS SOURCE - DOC
            // BEST TERMS DATE - Approval Date of the DM (which is vdate)
            // BEST TERMS DATE SOURCE - DOC

            Timestamp vdate = ServiceFactory.getPeriodService().getVDate().getTimestamp();
            ReIMSystemOptions systemOptions = ServiceFactory.getReIMSystemOptionsService().select();

            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            long seqVal = getNextDocId();
            stmnt.setLong(1, seqVal);
            stmnt.setString(2, docType);
            stmnt.setTimestamp(3, vdate); // doc date
            stmnt.setTimestamp(4, new ReIMDate().getTimestamp()); // create
            // date
            stmnt.setString(5, userId); // create id
            stmnt.setString(6, extDocId);
            stmnt.setTimestamp(7, vdate); // due date
            stmnt.setString(8, userId); // approval id
            stmnt.setTimestamp(9, vdate); // set approval date
            stmnt.setString(10, userId); // last update id
            stmnt.setTimestamp(11, new ReIMDate().getTimestamp()); // last
            // update
            // datetime
            stmnt.setString(12, systemOptions.getDefaultPayNowTerms()); // best
            // terms
            stmnt.setTimestamp(13, vdate); // best terms date
            stmnt.setLong(14, existingDocId);

            stmnt.executeUpdate();

            if (seqVal != Integer.MIN_VALUE) {
                return seqVal;
            } else {
                return Integer.MIN_VALUE;
            }
        }

        catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_create_debit_memo_from_existing_document",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.cannot_create_debit_memo_from_existing_document",
                        Severity.ERROR, exception, this);
            }
        }
    }

    public void updatePrePaid(Document[] invoices, boolean prePaid, String userId)
            throws ReIMException {
        OraclePreparedStatement pstmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            pstmt = (OraclePreparedStatement) conn.prepareStatement("UPDATE IM_DOC_HEAD "
                    + " SET PRE_PAID_IND = ?" + " ,LAST_UPDATE_ID = ?" + " ,LAST_DATETIME = ?"
                    + " ,PRE_PAID_ID = ?" + " WHERE DOC_ID = ?");

            int invoicesLength = invoices.length;
            for (int i = 0; i < invoicesLength; i++) {
                pstmt.setString(1, (prePaid ? ReIMConstants.YES : ReIMConstants.NO));
                pstmt.setString(2, userId);
                pstmt.setDate(3, new ReIMDate().getSQL_Date());
                pstmt.setString(4, userId);
                pstmt.setLong(5, invoices[i].getDocId());

                pstmt.addBatch();
            }

            pstmt.executeBatch();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_pre_paid_on_doc_head", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (pstmt != null) pstmt.close();
            } catch (Exception e) {
                throw new ReIMException("error.cannot_update_pre_paid_on_doc_head", Severity.ERROR,
                        e, this);
            }
        }
    }

    /**
     * Method updateRevesalCreditMemoAfterRollup.
     *
     * This method update the header status, total cost and total quantity for debit reversal credit
     * memos that are rolled up. The total cost and quantity should only include lines that are in
     * approved status. The total cost should also include any non-merch cost associated with the
     * document.
     *
     * @param whereClause
     *            : This should specify a list of documents to be updated.
     * @throws ReIMException
     */
    public void updateRevesalCreditMemoAfterRollup(Set docIds, String userId) throws ReIMException {
        OraclePreparedStatement pstmt =null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String datePattern = ReIMDate.getDateFormatPattern();

            Iterator it = docIds.iterator();
            while (it.hasNext()) {
                boolean approveStatusFlag = false;
	            boolean deniedStatusFlag = false;
	            boolean disputeStatusFlag = false;
	            String docStatus="";
	            long docId = ((Long) it.next()).longValue();

	            int totalDetailLines= 0; //Variable totalDetailLines represents all the detail lines
	            int deniedDetailLines=0; //Variable deniedDetailLines represents the number of detail lines that are denied.
	            String finalStatus= Document.DISPUTED;

	            StringBuffer statusQuery = new StringBuffer()
	            .append("SELECT STATUS FROM IM_DOC_DETAIL_REASON_CODES R ")
	            .append(" WHERE R.DOC_ID=?");

	            pstmt = (OraclePreparedStatement) conn.prepareStatement(statusQuery.toString());
	            pstmt.setLong(1,docId);
	            rs = pstmt.executeQuery();


	            //Looping through all the detail lines (IM_DOC_DETAIL_REASON_CODE) of the credit memo document.
	            while (rs.next()) {
	            	totalDetailLines++;
	            	docStatus = rs.getString(1);
	            	if(docStatus.equalsIgnoreCase(DocumentItemReasonCode.DENIED))
	            	{
	            		deniedDetailLines++;
	            	}
	            	if(docStatus.equalsIgnoreCase(Document.APPROVED))
	            	{
	            		approveStatusFlag=true;
	            	}
	            	if(docStatus.equalsIgnoreCase(Document.DISPUTED))
	            	{
	            		disputeStatusFlag=true;
	            	}
	            }

	            //Checking if all the detail lines in table IM_DOC_DETAIL_REASON_CODE for the credit memo document.
	            //are denied or not. Based on that the credit memo document is left in disputed status.
	            if(totalDetailLines==deniedDetailLines && totalDetailLines > 0 ){
	            	deniedStatusFlag=true;
	            	finalStatus=Document.DISPUTED;
	            }else if(!deniedStatusFlag && disputeStatusFlag){
	            	finalStatus=Document.DISPUTED;
	            }else if(!deniedStatusFlag && !disputeStatusFlag && approveStatusFlag){
	            	finalStatus=Document.APPROVED;
	            }else if (deniedStatusFlag && approveStatusFlag){
	            	finalStatus=Document.APPROVED;
	            }else if (totalDetailLines == 0){
	            	finalStatus=Document.APPROVED;
	            }
	            // Update total qty and total cost on doc head based on approved
	            // detail lines extended
	            // cost and line qty ONLY when finalstatus is decided as APPROVED.

	            if(finalStatus.equals(Document.APPROVED)){


	            		StringBuffer sql = new StringBuffer()
			            .append("UPDATE IM_DOC_HEAD H SET H.STATUS = '"+ finalStatus + "'")


			            .append(", H.APPROVAL_DATE = (SELECT VDATE FROM PERIOD) ")
			            .append(", H.APPROVAL_ID = '")
	                    .append(userId)
	                    .append("'")
	                    .append(", H.LAST_UPDATE_ID = '")
	                    .append(ReIMUserContext.getUsername())
	                    .append("'")
	                    .append(", H.LAST_DATETIME = to_date('")
	                    .append(new ReIMDate())
	                    .append("', '")
	                    .append(datePattern)
	                    .append("')")
	                    .append(", H.TOTAL_QTY = (SELECT NVL(SUM(R.ADJUSTED_QTY), 0) ")
	                    .append("                   FROM IM_DOC_DETAIL_REASON_CODES R ")
	                    .append("                  WHERE R.DOC_ID = H.DOC_ID ")
	                    .append("                    AND R.STATUS = '")
	                    .append(DocumentItemReasonCode.APPROVED)
	                    .append("') ")
	                    .append(
	                            ", H.TOTAL_COST = (SELECT NVL(SUM(R.ADJUSTED_QTY*R.ADJUSTED_UNIT_COST), 0) ")
	                    .append("                   FROM IM_DOC_DETAIL_REASON_CODES R ").append(
	                            "                  WHERE R.DOC_ID = H.DOC_ID ").append(
	                            "                    AND R.STATUS = '").append(
	                            DocumentItemReasonCode.APPROVED).append("') ").append(" WHERE H.DOC_ID =?");


	                    //.append(whereClause);
	            pstmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
	            pstmt.setLong(1,docId);
	            pstmt.executeUpdate();

                    StringBuffer sb = new StringBuffer()
                            .append("UPDATE im_doc_head h SET h.total_cost_inc_tax =  (select sum((d.adjusted_qty *d.adjusted_unit_cost)*(1+(nvl(dt.tax_rate,0)/100))) ")
                            .append("  from im_doc_detail_reason_codes d, im_doc_detail_rc_tax dt ")
                            .append("   where d.doc_id = h.doc_id and d.im_doc_detail_reason_codes_id = dt.im_doc_detail_reason_codes_id(+)")
                            .append("    AND d.STATUS = '")
                            .append(DocumentItemReasonCode.APPROVED).append("')")
                            .append(" WHERE H.DOC_ID=?");
    		            pstmt = (OraclePreparedStatement) conn.prepareStatement(sb.toString());
    		            pstmt.setLong(1,docId);
    		            pstmt.executeUpdate();



    		            // add the non-merch costs to the document total cost. It's possible
    		            // that there is no
    		            // non-merch cost.
    		            sql = new StringBuffer()
    		                    .append("UPDATE IM_DOC_HEAD H ")
    		                    .append(
    		                            " SET H.TOTAL_COST = H.TOTAL_COST + (SELECT NVL(SUM(NM.NON_MERCH_AMT), 0)")
    		                    .append("                                      FROM IM_DOC_NON_MERCH NM ")
    		                    .append("                                     WHERE NM.DOC_ID = H.DOC_ID) ")
    		                    .append(
    		                            ", H.RESOLUTION_ADJUSTED_TOTAL_COST = H.TOTAL_COST + (SELECT NVL(SUM(NM.NON_MERCH_AMT), 0)")
    		                    .append(
    		                            "                                                       FROM IM_DOC_NON_MERCH NM ")
    		                    .append(
    		                            "                                                      WHERE NM.DOC_ID = H.DOC_ID) ")
    		                    .append(", H.RESOLUTION_ADJUSTED_TOTAL_QTY = H.TOTAL_QTY ")
    		                    .append(", H.TOTAL_COST_INC_TAX = H.TOTAL_COST_INC_TAX + (SELECT NVL(SUM(NMT.NON_MERCH_AMT*(1+(nvl(NMTT.TAX_RATE,0)/100))),0) ")
    		                    .append(" FROM IM_DOC_NON_MERCH NMT, IM_DOC_NON_MERCH_TAX NMTT WHERE NMT.DOC_ID = H.DOC_ID AND NMT.DOC_ID = NMTT.DOC_ID(+)) ")
    		                    .append(" WHERE H.DOC_ID=?");


    		            pstmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
    		            pstmt.setLong(1,docId);
    		            pstmt.executeUpdate();

    		            StringBuffer sql_tax_delete = new StringBuffer().append("DELETE FROM IM_DOC_TAX WHERE doc_id = ?");
	            		pstmt = (OraclePreparedStatement) conn.prepareStatement(sql_tax_delete.toString());
    		            pstmt.setLong(1,docId);
    		            pstmt.executeUpdate();

    		            StringBuffer sql_tax_insert = new StringBuffer().append("INSERT INTO IM_DOC_TAX")
    		            .append(" SELECT  ?,TAX_CODE,TAX_RATE,SUM(TAX_BASIS),SUM(TAX_AMOUNT) FROM (")
    		            .append(" SELECT ? DOC_ID,IDDRT.TAX_CODE TAX_CODE,IDDRT.TAX_RATE TAX_RATE,IDDRT.TAX_BASIS TAX_BASIS,IDDRT.TAX_AMOUNT TAX_AMOUNT")
    		            .append(" FROM IM_DOC_DETAIL_REASON_CODES IDDRC,IM_DOC_DETAIL_RC_TAX IDDRT")
    		            .append(" WHERE IDDRC.IM_DOC_DETAIL_REASON_CODES_ID = IDDRT.IM_DOC_DETAIL_REASON_CODES_ID AND")
    		            .append(" IDDRC.DOC_ID = ? AND IDDRC.STATUS = '")
    		            .append(DocumentItemReasonCode.APPROVED).append("'")
    		            .append(" UNION ALL")
    		            .append(" SELECT  ?,INMT.TAX_CODE,INMT.TAX_RATE,INMT.TAX_BASIS,INMT.TAX_AMOUNT")
    		            .append(" FROM IM_DOC_NON_MERCH_TAX INMT")
    		            .append(" WHERE DOC_ID = ? )")
    		            .append(" GROUP BY DOC_ID,TAX_CODE,TAX_RATE");
    		            pstmt = (OraclePreparedStatement) conn.prepareStatement(sql_tax_insert.toString());
    		            pstmt.setLong(1,docId);
    		            pstmt.setLong(2,docId);
    		            pstmt.setLong(3,docId);
    		            pstmt.setLong(4,docId);
    		            pstmt.setLong(5,docId);
    		            pstmt.executeUpdate();
	            		}
           		 	}
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_update_reversal_credit_memo_after_rollup",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.cannot_update_reversal_credit_memo_after_rollup",
                        Severity.ERROR, exception, this);
            }
        }
    }

    /**
     * Method constructWhereClauseByDocIds.
     *
     * This method construct a where clause based on a set of document ids.
     *
     * @param docIds
     * @return String
     * @throws Exception
     */
    private static String constructWhereClauseByDocIds(Set docIds) throws Exception {
        StringBuffer whereClause = new StringBuffer("DOC_ID IN (");

        boolean firstTime = true;
        Iterator it = docIds.iterator();
        while (it.hasNext()) {
            long docId = ((Long) it.next()).longValue();

            if (firstTime) {
                whereClause.append(docId);
                firstTime = false;
            } else {
                whereClause.append(",").append(docId);
            }
        }
        whereClause.append(")");

        return whereClause.toString();
    }

    private static final String EXPORT_SELECT_FROM_DOC_HEAD = "      SELECT idh.type, \n "
            + "        idh.doc_id, \n " + "        idh.ref_doc, \n " + "        idh.order_no, \n"
            + "        idh.location, \n" + "        idh.loc_type, \n" + "        idh.doc_date, \n"
            + "        idh.ext_doc_id, \n" + "        idh.vendor, \n " + "        idh.terms, \n "
            + "        idh.due_date, \n " + "        idh.exchange_rate, \n "
            + "        idh.currency_code, \n " + "        idh.total_cost, \n "
            + "        idh.total_qty, \n " + "        idh.consignment_ind, \n "
            + "        idh.deal_id, \n " + "        idh.rtv_ind, \n " + "        idh.status \n "
            + "   FROM im_doc_head idh \n " + "  WHERE idh.type in ('"
            + Document.DEBIT_MEMO_PRICE
            + "',\n'"
            + Document.DEBIT_MEMO_QUANTITY
            + "',\n'"
            + Document.CREDIT_MEMO_PRICE
            + "',\n'"
            + Document.CREDIT_MEMO_QUANTITY
            + "',\n'"
            + Document.CREDIT_NOTE_REQUEST_TAX
            + "',\n'"
            + Document.CREDIT_NOTE_REQUEST_PRICE
            + "',\n'"
            + Document.CREDIT_NOTE_REQUEST_QUANTITY
            + "'\n )"
            + "    and idh.status in( '"
            + Document.APPROVED
            + "',\n'"
            + Document.SUBMITTED
            + "',\n'"
            + Document.POSTED
            + "'\n)"
            + "    and idh.edi_download_ind = '"
            + ReIMConstants.NO + "'\n" + "ORDER BY idh.vendor, \n" + "         idh.doc_id";

    /**
     * This method will get all relevant information for documents to be exported via EDI 812 from
     * IM_DOC_HEAD
     *
     * @return ArrayList of EdiTransactionHeader Objects
     * @throws ReIMException
     */

    public ArrayList<EdiTransactionHeader> selectDocHeadRowsForExport() throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs = null;
        ArrayList<EdiTransactionHeader> transactionHeaderList = new ArrayList<EdiTransactionHeader>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(EXPORT_SELECT_FROM_DOC_HEAD);
            rs = stmnt.executeQuery();

            while (rs.next()) {
                EdiTransactionHeader tranHead = new EdiTransactionHeader();

                tranHead.setDocumentId(Long.valueOf(rs.getLong("doc_id")));
                tranHead.setDocumentType(rs.getString("type"));
                tranHead.setVendorDocumentNumber(rs.getString("ext_doc_id"));
                tranHead.setInvoiceNumber(rs.getString("ref_doc"));
                tranHead.setVendorID(rs.getString("vendor"));
                ReIMDate date = new ReIMDate(rs.getDate("doc_date"));
                tranHead.setVendorDocumentDate(date);
                tranHead.setOrderNumber(Long.valueOf(rs.getLong("order_no")));
                tranHead.setLocation(Long.valueOf(rs.getLong("location")));
                tranHead.setLocationType(rs.getString("loc_type"));
                tranHead.setTerms(rs.getString("terms"));
                tranHead.setDueDate(new ReIMDate(rs.getDate("due_date")));
                tranHead.setExchangeRate(new Double(rs.getDouble("exchange_rate")));
                tranHead.setCurrencyCode(rs.getString("currency_code"));
                tranHead.setTotalCost(rs.getDouble("total_cost"));
                tranHead.setTotalQuantity(rs.getDouble("total_qty"));
                if (rs.getString("consignment_ind").equals(ReIMConstants.YES)) {
                    tranHead.setMerchType(ReIMConstants.MERCH_TYPE_CONSIGNMENT);
                } else {
                    tranHead.setMerchType(null);
                }
                tranHead.setRtvInd(rs.getString("rtv_ind"));
                rs.getLong("deal_id");
                if (rs.wasNull()) {
                    tranHead.setDealId(null);
                } else {
                    tranHead.setDealId(Long.valueOf(rs.getLong("deal_id")));
                }

                if (rs.getString("status").equals(Document.APPROVED)) {
                    tranHead.setDealApprovalInd(Document.APPROVED_STATUS);
                } else if (rs.getString("status").equals(Document.SUBMITTED)) {
                    tranHead.setDealApprovalInd(Document.SUBMITTED_STATUS);
                } else {
                    tranHead.setDealApprovalInd(null);
                }
                tranHead.setRecordDescriptor(EDIConstants.THEAD);
                tranHead.setIsEdiDownload(true);
                tranHead.setOrignalRecord(tranHead.createFlatRecord());

                transactionHeaderList.add(tranHead);
            }

            return transactionHeaderList;
        } catch (Exception e) {
            throw new ReIMException("error.select_doc_head_rows_for_export", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.select_doc_head_rows_for_export.close_rs_or_stmnt",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private static final String UPDATE_STATUS_FOR_EXPORT = "     UPDATE im_doc_head \n"
            + "   SET edi_download_ind = '" + ReIMConstants.YES + "' \n" + " WHERE doc_id = ?";

    /**
     * This method will set the status of the input document ids to exported.
     *
     * @param docIdsExported
     *            Set of document ids to be set to exported status
     * @throws ReIMException
     */

    public void setStatusExported(Set docIdsExported) throws ReIMException {
        OraclePreparedStatement stmnt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            Iterator iter = docIdsExported.iterator();

            stmnt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_STATUS_FOR_EXPORT);

            while (iter.hasNext()) {


                stmnt.setLong(1, ((Long) iter.next()).longValue());

                stmnt.executeUpdate();
            }
        } catch (Exception e) {
            throw new ReIMException("error.set_status_exported", Severity.ERROR, e, this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.set_status_exported.close_stmt", Severity.ERROR,
                        exception, this);
            }
        }
    }

    /**
     * Method: create. This method will insert a multiple rows on the database using populated row
     * objects. Note that any sequence values will be automatically fetched by this method. To
     * determine the value of a sequence after performing an insert, you may call the relevant
     * get..() method on the row.
     *
     * This method was copied from the generated access class, and then changed to assume that the
     * correct, new seqval is already inserted into the objects.
     *
     * @param newRows
     *            An array of populated row objects to insert on the DB.
     */
    public void createUsingProvidedDocId(ImDocHeadRow[] newRows) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String sqlTxt = "INSERT INTO IM_DOC_HEAD(DOC_ID,TYPE,STATUS,ORDER_NO,LOCATION,LOC_TYPE,TOTAL_DISCOUNT,GROUP_ID,PARENT_ID,DOC_DATE,CREATE_DATE,CREATE_ID,VENDOR_TYPE,VENDOR,EXT_DOC_ID,EDI_UPLOAD_IND,EDI_DOWNLOAD_IND,TERMS,TERMS_DSCNT_PCT,DUE_DATE,PAYMENT_METHOD,MATCH_ID,MATCH_DATE,APPROVAL_ID,APPROVAL_DATE,PRE_PAID_IND,PRE_PAID_ID,POST_DATE,CURRENCY_CODE,EXCHANGE_RATE,TOTAL_COST,TOTAL_QTY,MANUALLY_PAID_IND,CUSTOM_DOC_REF_1,CUSTOM_DOC_REF_2,CUSTOM_DOC_REF_3,CUSTOM_DOC_REF_4,LAST_UPDATE_ID,LAST_DATETIME,FREIGHT_TYPE,REF_DOC,REF_AUTH_NO,COST_PRE_MATCH,DETAIL_MATCHED,BEST_TERMS,BEST_TERMS_SOURCE,BEST_TERMS_DATE,BEST_TERMS_DATE_SOURCE,VARIANCE_WITHIN_TOLERANCE,RESOLUTION_ADJUSTED_TOTAL_COST,RESOLUTION_ADJUSTED_TOTAL_QTY,CONSIGNMENT_IND,DEAL_ID,RTV_IND,DEAL_TYPE, TOTAL_COST_INC_TAX,DSD_IND,ERS_IND,DISCOUNT_DATE,TAX_DISC_CREATE_DATE,HOLD_STATUS,SUPPLIER_SITE_ID,MANUALLY_CREATED_IND) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            long orderNo;
            long location;
            double totalDiscount;
            long groupId;
            long parentId;
            long refDoc;
            long refAuthNo;
            long dealId;
            double varinaceWithinTolerance;
            int arrayLen = newRows.length;
            for (int i = 0; i < arrayLen; i++) {
                stmnt.setLong(1, newRows[i].getDocId());
                stmnt.setString(2, newRows[i].getType());
                stmnt.setString(3, newRows[i].getStatus());
                orderNo = newRows[i].getOrderNo();
                if (orderNo == Long.MIN_VALUE) {
                    stmnt.setNull(4, Types.BIGINT);
                } else {
                    stmnt.setLong(4, orderNo);
                }
                location = newRows[i].getLocation();
                if (location == Long.MIN_VALUE) {
                    stmnt.setNull(5, Types.BIGINT);
                } else {
                    stmnt.setLong(5, location);
                }
                stmnt.setString(6, newRows[i].getLocType());
                totalDiscount = newRows[i].getTotalDiscount();
                if (totalDiscount == Double.MIN_VALUE) {
                    stmnt.setNull(7, Types.DOUBLE);
                } else {
                    stmnt.setDouble(7, totalDiscount);
                }
                groupId = newRows[i].getGroupId();
                if (groupId == Long.MIN_VALUE) {
                    stmnt.setNull(8, Types.BIGINT);
                } else {
                    stmnt.setLong(8, groupId);
                }
                parentId = newRows[i].getParentId();
                if (parentId == Long.MIN_VALUE) {
                    stmnt.setNull(9, Types.BIGINT);
                } else {
                    stmnt.setLong(9, parentId);
                }
                stmnt.setTimestamp(10, newRows[i].getDocDate());
                stmnt.setTimestamp(11, newRows[i].getCreateDate());
                stmnt.setString(12, newRows[i].getCreateId());
                stmnt.setString(13, newRows[i].getVendorType());
                stmnt.setString(14, newRows[i].getVendor());
                stmnt.setString(15, newRows[i].getExtDocId());
                stmnt.setString(16, newRows[i].getEdiUploadInd());
                stmnt.setString(17, newRows[i].getEdiDownloadInd());
                stmnt.setString(18, newRows[i].getTerms());
                stmnt.setDouble(19, newRows[i].getTermsDscntPct());
                stmnt.setDate(20, newRows[i].getDueDate());
                stmnt.setString(21, newRows[i].getPaymentMethod());
                stmnt.setString(22, newRows[i].getMatchId());
                stmnt.setTimestamp(23, newRows[i].getMatchDate());
                stmnt.setString(24, newRows[i].getApprovalId());
                stmnt.setTimestamp(25, newRows[i].getApprovalDate());
                stmnt.setString(26, newRows[i].getPrePaidInd());
                stmnt.setString(27, newRows[i].getPrePaidId());
                stmnt.setTimestamp(28, newRows[i].getPostDate());
                stmnt.setString(29, newRows[i].getCurrencyCode());
                stmnt.setDouble(30, newRows[i].getExchangeRate());
                stmnt.setDouble(31, newRows[i].getTotalCost());
                stmnt.setDouble(32, newRows[i].getTotalQty());
                stmnt.setString(33, newRows[i].getManuallyPaidInd());
                stmnt.setString(34, newRows[i].getCustomDocRef1());
                stmnt.setString(35, newRows[i].getCustomDocRef2());
                stmnt.setString(36, newRows[i].getCustomDocRef3());
                stmnt.setString(37, newRows[i].getCustomDocRef4());
                stmnt.setString(38, ReIMUserContext.getUsername());
                stmnt.setTimestamp(39, new ReIMDate().getTimestamp());
                stmnt.setString(40, newRows[i].getFreightType());
                refDoc = newRows[i].getRefDoc();
                if (refDoc == Long.MIN_VALUE) {
                    stmnt.setNull(41, Types.BIGINT);
                } else {
                    stmnt.setLong(41, refDoc);
                }
                refAuthNo = newRows[i].getRefAuthNo();
                if (refAuthNo == Long.MIN_VALUE) {
                    stmnt.setNull(42, Types.BIGINT);
                } else {
                    stmnt.setLong(42, refAuthNo);
                }
                stmnt.setString(43, newRows[i].getCostPreMatch());
                stmnt.setString(44, newRows[i].getDetailMatched());
                stmnt.setString(45, newRows[i].getBestTerms());
                stmnt.setString(46, newRows[i].getBestTermsSource());
                stmnt.setTimestamp(47, newRows[i].getBestTermsDate());
                stmnt.setString(48, newRows[i].getBestTermsDateSource());
                varinaceWithinTolerance = newRows[i].getVarianceWithinTolerance();
                if (varinaceWithinTolerance == Double.MIN_VALUE) {
                    stmnt.setNull(49, Types.DOUBLE);
                } else {
                    stmnt.setDouble(49, varinaceWithinTolerance);
                }
                stmnt.setDouble(50, newRows[i].getResolutionAdjustedTotalCost());
                stmnt.setDouble(51, newRows[i].getResolutionAdjustedTotalQty());
                stmnt.setString(52, newRows[i].getConsignmentInd());
                dealId = newRows[i].getDealId();
                if (dealId == Long.MIN_VALUE) {
                    stmnt.setNull(53, Types.BIGINT);
                } else {
                    stmnt.setLong(53, dealId);
                }

                stmnt.setString(54, newRows[i].getRtvInd());
                if (newRows[i].getDealType() == null) {
                    stmnt.setNull(55, Types.VARCHAR);
                } else {
                    stmnt.setString(55, newRows[i].getDealType().getCode());
                }
                stmnt.setDouble(56, newRows[i].getTotalCostIncTax());
                stmnt.setString(57, (newRows[i].getDirectStoreDelieveryInd()!=null ? newRows[i].getDirectStoreDelieveryInd()  : Affirm.NO_IND));
                stmnt.setString(58, (newRows[i].getEvaluatedReceiptSettlementInd()!=null ? Affirm.YES_IND : Affirm.NO_IND));
                stmnt.setTimestamp(59, newRows[i].getDiscountDate());
                stmnt.setTimestamp(60, newRows[i].getTaxDiscCreateDate());
                stmnt.setString(61, newRows[i].getHoldStatus());
                stmnt.setString(62, newRows[i].getSupplierSite());
                stmnt.setString(63,"N");
                stmnt.addBatch();
            }
            stmnt.executeBatch();
        } catch (ReIMException e) {
            throw e;
        } catch (BatchUpdateException ex1) {
            String exMsg = "(unable to determine which batch row caused the error)";
            throw new ReIMException("DALGen.cannot_perform_insert", Severity.ERROR, ex1, this,
                    new String[] { sqlTxt, exMsg});
        } catch (SQLException ex) {
            String exMsg = "(unable to determine which batch row caused the error)";
            throw new ReIMException("DALGen.cannot_perform_insert", Severity.ERROR, ex, this,
                    new String[] { sqlTxt, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    public ImDocHeadRow read(long docId, boolean noRowsFoundIsError) throws ReIMException {
        return super.read(docId, noRowsFoundIsError);
    }

    public void updateStatusByDocIdForDetailsMatched(long docId, String userId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;


        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(UPDATE_STATUS_BY_DOC_ID_FOR_DETAILS_MATCHED);
            stmt.setString(1, userId);
            stmt.setString(2, userId);
            stmt.setTimestamp(3, new ReIMDate().getTimestamp());
            stmt.setTimestamp(4, new ReIMDate().getTimestamp());
            stmt.setLong(5, docId);
            stmt.setLong(6, docId);

            stmt.executeUpdate();
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_update_status", Severity.ERROR, exception,
                    this);
        } finally {
            try {
                 if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_update_status", Severity.ERROR, exception,
                        this);

            }
        }
    }

    public boolean isRefDocPopulated(String docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String refDocId = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT REF_DOC FROM IM_DOC_HEAD WHERE DOC_ID = ? ");
            stmt.setString(1, docId);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                refDocId = resultSet.getString("REF_DOC");
            }

            if (StringUtils.isEmpty(refDocId)) {
                return false;
            } else {
                return true;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.doc_head_failed_to_get_ref_doc_id", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.doc_head_failed_to_get_ref_doc_id", Severity.ERROR,
                        exception, this);

            }
        }
    }

    public ByteLengths getDocumentMaxByteLengths() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            // OLR V1.2 Inserted - Begin
            // stmt = (OraclePreparedStatement) conn
            //        .prepareStatement("SELECT MAX(EXT_DOC_ID), MAX(CUSTOM_DOC_REF_1) FROM IM_DOC_HEAD ");
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT EXT_DOC_ID, CUSTOM_DOC_REF_1 FROM IM_DOC_HEAD where rownum = 1 and ext_doc_id is not null and CUSTOM_DOC_REF_1 is not null ");
            // OLR V1.2 Inserted - End
        
            ByteLengths docByteLengths = new ByteLengths();
            rs = stmt.executeQuery();
            if (rs.next()) {
                docByteLengths.setExtDocIdSize(rs.getMetaData().getColumnDisplaySize(1));
                docByteLengths.setDocNbrSize(rs.getMetaData().getColumnDisplaySize(2));
            }
            return docByteLengths;

        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }

    public String getDocumentStatusByExtDocId(String extDocId) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs1 = null;
        String status = null;

        String tableQuery = "SELECT IM_DOC_HEAD.STATUS FROM IM_DOC_HEAD WHERE IM_DOC_HEAD.EXT_DOC_ID LIKE ?";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
            stmnt.setString(1, extDocId);
            rs1 = stmnt.executeQuery();
            if (rs1.next()) {
                status = rs1.getString(1);
                return (status);
            } else {

                Exception ex = new Exception();
                String exMsg = "" + "Bind variable 1 type=long, value=" + extDocId + ";";
                throw new ReIMException("DALGen.cannot_perform_single_select", Severity.ERROR, ex,
                        this, new String[] { tableQuery, exMsg});

            }
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variable 1 type=long, value=" + extDocId + ";";
            throw new ReIMException("DALGen.cannot_perform_single_select", Severity.ERROR, ex,
                    this, new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }
    
    public String getDetailMatchedByDocId(String docId) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs1 = null;
        String status = null;

        String tableQuery = "SELECT IM_DOC_HEAD.DETAIL_MATCHED FROM IM_DOC_HEAD WHERE IM_DOC_HEAD.DOC_ID = ? ";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
            stmnt.setString(1, docId);
            rs1 = stmnt.executeQuery();
            if (rs1.next()) {
                status = rs1.getString(1);
                return (status);
            } else {

                Exception ex = new Exception();
                String exMsg = "" + "Bind variable 1 type=long, value=" + docId + ";";
                throw new ReIMException("DALGen.cannot_perform_single_select", Severity.ERROR, ex,
                        this, new String[] { tableQuery, exMsg});

            }
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variable 1 type=long, value=" + docId + ";";
            throw new ReIMException("DALGen.cannot_perform_single_select", Severity.ERROR, ex,
                    this, new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

}