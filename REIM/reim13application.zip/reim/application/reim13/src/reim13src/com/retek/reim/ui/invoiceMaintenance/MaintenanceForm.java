package com.retek.reim.ui.invoiceMaintenance;

import org.apache.struts.action.ActionForm;

import com.retek.reim.merch.utils.ReIMConstants;

public class MaintenanceForm extends ActionForm implements ReIMConstants {
    // BUTTONS and other static variables for ALL documents (invoices and 'documents')pages
    public static final String OK = "OK";
    public static final String DETAILS = "DETAILS";
    public static final String APPROVE = "APPROVE";
    public static final String CANCEL = "CANCEL";
    public static final String OK_REPEAT = "OK_REPEAT";
    public static final String VOID = "VOID";
    public static final String COMMENTS = "COMMENTS";
    public static final String DELETE = "DELETE";
    public static final String ADD = "ADD";

    // button and page mode
    public static final String REVERSE = "REVERSE";

    // page modes
    public static final String NEW = "NEW";
    public static final String EDIT = "EDIT";
    public static final String VIEW = "VIEW";
    public static final String MASSEDIT = "MASSEDIT";

    public static final String ADD_ITEM_BUTTON = "ADDITEM";
    public static final String UPDATE_ITEM_BUTTON = "UPDATEITEM";
    public static final String APPROVED = "APPROVED";

    public static final String EXT_DOC_ID = "1";
    public static final String REFERENCE_1 = "2";
    public static final String REFERENCE_2 = "3";
    public static final String REFERENCE_3 = "4";
    public static final String REFERENCE_4 = "5";

    protected String poReceiptNumber;
    protected String poLocation;
    protected String poReceiptFromDate;
    protected String poReceiptToDate;

    public String getPoLocation() {
        return this.poLocation;
    }

    public String getPoReceiptFromDate() {
        return this.poReceiptFromDate;
    }

    public String getPoReceiptNumber() {
        return this.poReceiptNumber;
    }

    public String getPoReceiptToDate() {
        return this.poReceiptToDate;
    }

    public void setPoLocation(String poLocation) {
        this.poLocation = poLocation;
    }

    public void setPoReceiptFromDate(String poReceiptFromDate) {
        this.poReceiptFromDate = poReceiptFromDate;
    }

    public void setPoReceiptNumber(String poReceiptNumber) {
        this.poReceiptNumber = poReceiptNumber;
    }

    public void setPoReceiptToDate(String poReceiptToDate) {
        this.poReceiptToDate = poReceiptToDate;
    }
}
