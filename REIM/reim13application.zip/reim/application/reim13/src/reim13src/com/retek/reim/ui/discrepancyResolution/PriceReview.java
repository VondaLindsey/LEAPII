package com.retek.reim.ui.discrepancyResolution;

import org.apache.commons.lang.StringUtils;

import com.retek.reim.business.DiscrepancyCostReview;
import com.retek.reim.business.Location;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.services.I18NService;
import com.retek.reim.services.IUserRoleMaintenanceService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.UserRoleMaintenanceService;

/**
 * PriceReview is a get-only object based on the DiscrepancyCostReview business object.
 */
public class PriceReview {
    private IUserRoleMaintenanceService userRoleMaintenanceService = ServiceFactory
            .getUserRoleMaintenanceService();
    protected long docId;
    protected String invoiceNbr;
	protected String documentType;
    protected String documentTypeDesc;
    protected String department;
    protected String classId;
    protected String supplier;
    protected String supplierName;
    protected ReIMDate resolveByDate;
    protected String cashDiscount;
    protected String routeDate;
    protected String reviewerGroup;
    protected String reviewerGroupName;
    protected String orderId;
    protected Location location;
    protected String noOfLineExceptions;
    protected double totalDocumentAmount;
    protected String totalDocumentAmountFormatted;
    protected String currency;
    protected String apReviewer;

    private PriceReview() {
    }

    public PriceReview(DiscrepancyCostReview costReview) throws ReIMException {
        this.docId = costReview.getDocId();
        this.invoiceNbr = costReview.getExternalDocId();
        this.documentType = costReview.getDocumentType();
        this.department = costReview.getDepartment();
        this.classId = costReview.getClassId();
        this.supplier = costReview.getSupplier();
        this.supplierName = costReview.getSupplierName();
        this.resolveByDate = costReview.getResolveByDate();
        this.cashDiscount = costReview.getCashDiscount();
        this.routeDate = costReview.getRouteDate().toString();
        this.reviewerGroup = costReview.getReviewerGroup();
        this.reviewerGroupName = costReview.getReviewerGroupName();
        this.orderId = costReview.getOrderId();
        this.location = costReview.getLocation();
        this.noOfLineExceptions = costReview.getNoOfLineExceptions();
        this.currency = costReview.getCurrency();
        this.totalDocumentAmount = costReview.getTotalDocumentAmount();
        this.totalDocumentAmountFormatted = ReIMMoney.getCostString(this.totalDocumentAmount,
                this.currency);
        this.apReviewer = costReview.getApReviewer();
    }

    public void decreaseNoOfLineExceptions() {
        this.noOfLineExceptions = String.valueOf(Long.parseLong(this.noOfLineExceptions) - 1);
    }

    public void increaseNoOfLineExceptions() {
        this.noOfLineExceptions = String.valueOf(Long.parseLong(this.noOfLineExceptions) + 1);
    }

    public PriceReview copyForNewReviewerGroup(String newReviewerGroup) throws ReIMException {
        PriceReview newPriceReview = new PriceReview();

        newPriceReview.docId = this.docId;
        newPriceReview.documentType = this.documentType;
        newPriceReview.documentTypeDesc = this.documentTypeDesc;
        newPriceReview.department = this.department;
        newPriceReview.classId = this.classId;
        newPriceReview.supplier = this.supplier;
        newPriceReview.supplierName = this.supplierName;
        newPriceReview.resolveByDate = this.resolveByDate;
        newPriceReview.cashDiscount = this.cashDiscount;
        newPriceReview.routeDate = this.routeDate;
        newPriceReview.reviewerGroup = newReviewerGroup;
        newPriceReview.reviewerGroupName = this.userRoleMaintenanceService.getBusinessRoleByRoleId(
                Long.parseLong(newReviewerGroup)).getBusinessRoleName();
        newPriceReview.orderId = this.orderId;
        newPriceReview.location = this.location;
        newPriceReview.noOfLineExceptions = String.valueOf(1);
        newPriceReview.totalDocumentAmount = this.totalDocumentAmount;
        newPriceReview.totalDocumentAmountFormatted = this.totalDocumentAmountFormatted;
        newPriceReview.currency = this.currency;
        newPriceReview.apReviewer = this.apReviewer;

        return newPriceReview;

    }

    public String getDocumentTypeDesc() {
        return ServiceFactory.getDocumentService().getDocumentTypeDescription(documentType);
    }

    public String getResolveByDate() {
        return resolveByDate.getDisplayString();
    }

    public ReIMDate getResolveByDateAsReIMDate() {
        return resolveByDate;
    }

    public ReIMDate getRouteDateAsReIMDate() throws Exception {
        return new ReIMDate(routeDate);
    }

    public String getEncodedSupplierName() throws ReIMException {
        if (StringUtils.isNotEmpty(supplierName)) {
            return I18NService.encodeString(supplierName);
        } else {
            return supplierName;
        }
    }

    public String getCashDiscountDesc() {
        return (cashDiscount.equals(ReIMConstants.YES) ? ReIMI18NUtility.getWidget("label.yes")
                : ReIMI18NUtility.getWidget("label.no"));
    }

    // Getter Methods
    public String getApReviewer() {
        return apReviewer;
    }

    public String getCashDiscount() {
        return cashDiscount;
    }

    public String getClassId() {
        return classId;
    }

    public String getCurrency() {
        return currency;
    }

    public String getDepartment() {
        return department;
    }

    public long getDocId() {
        return docId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public Location getLocation() {
        return location;
    }

    public String getNoOfLineExceptions() {
        return noOfLineExceptions;
    }

    public String getOrderId() {
        if (this.orderId != null) {
            return orderId;
        } else {
            return "";
        }

    }

    public String getReviewerGroup() {
        return reviewerGroup;
    }

    public String getReviewerGroupName() {
        return reviewerGroupName;
    }

    public String getRouteDate() {
        return routeDate;
    }

    public String getSupplier() {
        return supplier;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public double getTotalDocumentAmount() {
        return totalDocumentAmount;
    }

    public String getTotalDocumentAmountFormatted() {
        return totalDocumentAmountFormatted;
    }

    public void setUserRoleMaintenanceService(IUserRoleMaintenanceService userRoleMaintenanceService) {
        this.userRoleMaintenanceService = userRoleMaintenanceService;
    }
    
    public String getInvoiceNbr() {
		return invoiceNbr;
	}

	public void setInvoiceNbr(String invoiceNbr) {
		this.invoiceNbr = invoiceNbr;
	}
}
