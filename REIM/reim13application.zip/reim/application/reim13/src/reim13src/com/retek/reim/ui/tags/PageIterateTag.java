package com.retek.reim.ui.tags;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.commons.lang.StringUtils;

import com.retek.merch.utils.ObjectComparator;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.merch.utils.Sorter;
import com.retek.reim.services.PreferenceService;

import javax.servlet.http.HttpSession;

public class PageIterateTag extends BodyTagSupport {
    private static final long serialVersionUID = 1L;

    public final static String TRUE = "true";
    public final static String FALSE = "false";
    private String positionKey = "currentPosition";
    private String orderByKey = "orderBy";
    private String directionKey = "direction";
    private String oldSortByKey = "oldSortBy";
    private String oldDirectionByKey = "oldDirectionBy";
    private String typeKey = "type";
    private String requestedViewNameKey = "requestedViewName";
    private String modelKey = "model";
    private String id;
    private String name;
    private String property;
    private String tableWidth = "100%";
    private int numberOfRows = 15;
    private String rowStyle = "tableEvenRow";
    private String alternatingRowStyle = "tableOddRow";
    private String colSpan = ReIMConstants.ZERO_STRING;
    private String style = "gEvenRow";
    private String headerClass = "gMoveableHeader";
    private boolean paging = true;
    private String flexColumnTitleKey;
    private String persistId = modelKey;
    private int currentPageOffset = 0;
    private int currentRow = 0;
    private Object[] array;
    private boolean isFirstTime = true;
    private HttpServletRequest request;
    private String currentRowStyle = alternatingRowStyle;
    private boolean isHeaderOnly = false;
    private String scrollableHeader = FALSE;
    private ColumnsHolder ch = null;
    private boolean hasFlexColumnsCapabilityRequested;
    private String onDoubleClickMethod;
    private String userName;
    private String pageName;
    private String viewName;
    private boolean failedProperViewInitialization = false;
    private String onClickMethod;

    // Initially, setParent() and setPageContext() are called by the JSP engine.
    // Then any "set" methods for attributes of the tag are called. Next,
    // the following methods are invoked in this order:
    // doStartTag(), setBodyContent(), doInitBody(), doAfterBody(), and
    // doEndTag().
    public PageIterateTag() {
    }

    public int doStartTag() throws JspException {
        int repeatBody = EVAL_BODY_INCLUDE;
        isFirstTime = true;
        // Set this to false again because OC4J doesn't work the same way as
        // Tomcat.
        this.setIsHeaderOnly(false);
        request = (HttpServletRequest) pageContext.getRequest();
        userName = ReIMUserContext.getUsername();
        pageName = this.getFlexColumnTitleKey() + this.getPersistId();
        if (pageName.length() > 40) {
            StringBuffer sb = new StringBuffer();
            sb
                    .append("Combined length of flexColumnTitleKey & persistId should not exceed 40 characters\n");
            sb.append("Current value: '");
            sb.append(pageName);
            sb.append("' is of length: ");
            sb.append(pageName.length());
            throw new JspException(sb.toString());
        }
        hasFlexColumnsCapabilityRequested = ((this.getFlexColumnTitleKey() == null) || (this
                .getFlexColumnTitleKey().trim().equals(ReIMConstants.EMPTY_STRING))) ? false : true;
        if (hasFlexColumnsCapabilityRequested) {
            // Query the database for columns configuration: either display a
            // requested view or an active view name if there is no
            // request for specific view to be displayed
            viewName = this.getRequestedViewName();
            try {
                if (viewName.equals(ReIMConstants.EMPTY_STRING)) {
                    viewName = PreferenceService.getActiveViewName(userName, pageName);
                }
                // register the active view in the database
                if (viewName != null) {
                    PreferenceService.registerActiveView(userName, pageName, viewName);
                }
                ch = new ColumnsHolder(userName, pageName, viewName);
                // Disable Flexible columns capability if we fail to load the
                // views
                if (ch.isInitSuccessful() == false) {
                    hasFlexColumnsCapabilityRequested = false;
                    failedProperViewInitialization = true;
                    ch = new ColumnsHolder();
                }
            } catch (ReIMException e) {
                e.printStackTrace();
                throw new JspException(e);
            }
        } else {
            // No flex columns capability were requested
            ch = new ColumnsHolder();
        }

        // Make the orderBy key unique between different invocations.
        // The request should not have the orderByKey defined, otherwise in OC4J
        // the persistId keeps
        // appending to orderByKey with every sort invoke.
        if (request.getParameter(orderByKey) == null) {
            this.orderByKey = this.orderByKey + persistId;
        }
        // this.POSITION_KEY = this.POSITION_KEY + persistId;
        // this.TYPE_KEY = this.TYPE_KEY + persistId;
        // this.DIRECTION_KEY = this.DIRECTION_KEY + persistId;
        // ch is a shared object between this tag and children column tags. All
        // will be adding to this...
        // We use the session object to store the ColumnsHolder object.
        request.getSession().setAttribute(persistId, ch);
        array = this.getArray();

        try {
            ch.appendPreHTML(generateJavascript());
            ch.appendPreHTML(this.generateFlexColumnJScript());
            if (this.getScrollableHeader() != null
                    && this.getScrollableHeader().trim().length() > 0
                    && this.getScrollableHeader().equalsIgnoreCase(TRUE)) {
                ch.appendPreHTML("<tr id='gMoveableTableHeader' class='gMoveableTableHeader'>");
            } else {
                ch.appendPreHTML("<tr class='" + currentRowStyle + "'>");
            }
            if (null == array || array.length == 0 || null == array[0]) {
                this.setIsHeaderOnly(true);
            } else {
                sort();
                filter();
                if (array.length == 0) {
                    this.setIsHeaderOnly(true);
                } else {
                    currentPageOffset = getCurrentPageOffset();
                    currentRow = currentPageOffset;
                    if (currentRow >= array.length) {
                        currentPageOffset = (array.length - this.numberOfRows);
                        currentRow = (array.length - this.numberOfRows);
                        pageContext.getSession().setAttribute(id, array[currentRow++]);
                        pageContext.getSession().setAttribute(positionKey, "" + currentRow);
                        request.getSession().setAttribute(positionKey, currentRow);
                    } else {
                        pageContext.getSession().setAttribute(id, array[currentRow++]);
                    }
                }
            }
            return repeatBody;
        } catch (Exception ioe) {
            ioe.printStackTrace();
            throw new JspException(ioe);
        }
    }

    public int doAfterBody() throws JspException {
        // This is if the filter didn't bring back any search criteria
        if (this.isHeaderOnly()) return EVAL_PAGE;
        int repeatBody = SKIP_BODY;
        reverseRowColor();
        try {
            if (isFirstTime) {
                isFirstTime = false;
                repeatBody = EVAL_BODY_AGAIN;
            } else {
                if (!this.isPaging()) {
                    this.setNumberOfRows(String.valueOf(this.array.length));
                }
                if (currentRow < (currentPageOffset + numberOfRows) && currentRow < array.length) {
                    pageContext.setAttribute(id, array[currentRow++]);
                    repeatBody = EVAL_BODY_AGAIN;
                }
            }
        } catch (Exception ioe) {
            throw new JspException(ioe);
        }
        return repeatBody;
    }

    public int doEndTag() throws JspException {
        try {
            Locale locale = ReIMUserContext.getLocale();
            if (this.isHeaderOnly()) {
                ch.appendPostHTML("<tr id='no_records_found' class='" + this.getStyle() + "'>");
                String message = ReIMI18NUtility.getWidget("message.no_records_found", locale);
                ch.appendPostHTML("<td align=\"center\" colspan=\"" + this.getColSpan() + "\"><b>"
                        + message + "</b></td>");
                ch.appendPostHTML("</tr>\n");
            }
            if (this.isPaging()) {
                ch.appendPostHTML(doPaging());
            }
            pageContext.getOut().println(ch.getPreHTML());
            if (!StringUtils.isEmpty(getOnClickMethod())) {
                pageContext.getOut().println(
                        ch.getAllRows(getRowStyle(), getAlternatingRowStyle(), null,
                        		getOnClickMethod()));
            } else if (!StringUtils.isEmpty(getOnDoubleClickMethod())) {
                pageContext.getOut().println(
                		ch.getAllRows(getRowStyle(), getAlternatingRowStyle(),
                                getOnDoubleClickMethod()));
            } else {
                pageContext.getOut()
                        .println(ch.getAllRows(getRowStyle(), getAlternatingRowStyle()));
            }
            pageContext.getOut().println(ch.getPostHTML());
        } catch (IOException e) {
            throw new JspException(e);
        } finally {
            // tidy up for jsp tag lifecycle
            cleanUp();
        }
        if (failedProperViewInitialization) {
            System.out.println(getFormattedErrorMessage());
        }
        return EVAL_PAGE;
    }

    private String getFormattedErrorMessage() {
        StringBuffer msgHead = new StringBuffer();
        msgHead
                .append("***************************************************************************\n");
        msgHead
                .append("* Failed to load views... we are disabeling flexible columns capability   *\n");
        msgHead
                .append("* until you fix the problem. Following is what you should do:             *\n");
        msgHead
                .append("* 1) Add a new set of records to im_base_data.sql script file.            *\n");
        msgHead
                .append("* 2) Run the sql script to reload all the records.                        *\n");
        msgHead
                .append("* The Script will delete IM_GLOBAL_PREFERECES and IM_USER_PREFERENCES     *\n");
        msgHead
                .append("* tables. This is essential for the clean operation of the tag.           *\n");
        msgHead
                .append("***************************************************************************\n");
        return msgHead.toString();
    }

    private String generateFlexColumnJScript() throws JspException, ReIMException {
        StringBuffer sb = new StringBuffer();
        sb.append(ReIMConstants.EMPTY_STRING);
        if (hasFlexColumnsCapabilityRequested) {
            String selectObject = ("document." + name) + ".flexColumnViews";
            sb.append("<script language=\"JavaScript\" src=\"javascript/ColumnOrderDialog2.js\"></script>\n");
            sb.append("<script language=\"JavaScript\" type=\"text/javascript\"> \n");
            sb.append("<!-- \n");
            sb.append("	var cod = new ColumnOrderDialog(" + "\"");
            sb.append(persistId);
            sb.append("\"");
            sb.append("); \n");
            sb.append("-->	\n");
            sb.append("</script>\n");
            sb.append("<tr id='gMoveableHeader' ");
            sb.append("class='");
            sb.append(this.getHeaderClass());
            sb.append("'>");
            sb.append("<td colspan=\"" + this.getColSpan() + "\" align=\"left\">");
            String msg = ReIMI18NUtility.getMessage(this.getFlexColumnTitleKey());
            String customize = ReIMI18NUtility.getMessage("column.order.customize_view");
            sb.append("<b>&nbsp;");
            sb.append(msg);
            sb.append("&nbsp;&nbsp;</b>");
            sb.append("<a href=\"#\" onclick=\"javascript:cod.show(event,");
            sb.append(selectObject);
            sb.append("); return false;\"><img alt=\"");
            sb.append(customize);
            sb.append("\" src=\"images/columns.gif\" border=\"0\"/></a>");
            sb.append("&nbsp;&nbsp;");
            String viewsHTML = doViews(selectObject, getReferredPage());
            sb.append(viewsHTML);
            sb.append("</td>");
            sb.append("</tr>");
        }
        return sb.toString();
    }

    private String doViews(String selectObject, String referredPage) throws JspException,
            ReIMException {
        StringBuffer sb = new StringBuffer();
        String[] allViewNames = PreferenceService.getAllViewNames(userName, pageName);
        // if there are no loaded views, throw an exception and do not display
        // the views selection menu
        if (allViewNames != null) {
            sb
                    .append("<select size=\"1\" name=\"flexColumnViews\" class=\"gList\" onChange=\"javascript:cod.loadViewByName(");
            sb.append(selectObject);
            sb.append(", '");
            sb.append(referredPage);
            sb.append("'); return false;\">");
            String selected;
            for (int i = 0; i < allViewNames.length; i++) {
                selected = allViewNames[i].equals(viewName) ? "selected" : "";
                sb.append("<option ");
                sb.append(selected);
                sb.append(">");
                sb.append(allViewNames[i]);
                sb.append("</option>");
            }
            sb.append("</select>");
        } else {
            throw new JspException("\n" + getFormattedErrorMessage());
        }
        return sb.toString();
    }

    private String doPaging() {
    	request = (HttpServletRequest)pageContext.getRequest();
    	HttpSession session = request.getSession();
    	if(session.getAttribute("returningScreen") != null)
    	{
    	currentPageOffset = getCurrentPageOffset();
    	session.removeAttribute("returningScreen");
    	}

        StringBuffer paging = new StringBuffer();
        // If array is empty there's nothing to display on the page.
        if (array == null || array.length == 0) return "";
        int resultSize = array.length;
        paging.append("<tr class='");
        paging.append(currentRowStyle);
        paging.append("'><td colspan='");
        paging.append(colSpan);
        paging.append("' align='left'>");
        Locale locale = ReIMUserContext.getLocale();
        String next = ReIMI18NUtility.getWidget("Link.next", locale);
        String prev = ReIMI18NUtility.getWidget("Link.prev", locale);
        if ((currentPageOffset + 1 > numberOfRows)) {
            paging.append("<a class='");
            paging.append(style);
            paging.append("' href=\"javascript:doPaging('");
            paging.append((currentPageOffset - numberOfRows));
            paging.append("');\">[");
            paging.append(prev);
            paging.append("]</a> ");
        }
        generatePageNumbers(paging, resultSize, style);
        if (currentPageOffset + numberOfRows < resultSize) {
            paging.append(" <a class='");
            paging.append(style);
            paging.append("' href=\"javascript:doPaging('");
            paging.append((currentPageOffset + numberOfRows));
            paging.append("');\">[");
            paging.append(next);
            paging.append("]</a> ");
        }
        paging.append("&nbsp;&nbsp;&nbsp;</td></tr>\n");

        if(session.getAttribute("avoidingScreen") != null)
        {
        session.removeAttribute("avoidingScreen");
        }
        else
        {
        session.setAttribute("currentPageOffset",new Integer(currentPageOffset));
        }

        return paging.toString();
    }

    private void generatePageNumbers(StringBuffer out, long resultSize, String style) {
        long currentPage = currentPageOffset / numberOfRows;
        long pageCount = (long) Math.ceil((double) resultSize / numberOfRows);
        for (long i = 0; i < pageCount; i++) {
            if (i == currentPage) {
                out.append(" <B>");
                out.append((i + 1));
                out.append("</B> ");
            } else {
                out.append("<a class='");
                out.append(style);
                out.append("' href=\"javascript:doPaging('");
                out.append((numberOfRows * i));
                out.append("');\">");
                out.append((i + 1));
                out.append("</a> ");
            }
        }
    }

    private String getReferredPage() {
        String referer = request.getRequestURI();
        referer = referer.substring(referer.lastIndexOf("/") + 1);
        if (referer.indexOf("?") > -1) {
            referer = referer.substring(0, referer.indexOf("?"));
        }
        return referer;
    }

    private void reverseRowColor() {
        if (currentRowStyle.equals(alternatingRowStyle))
            currentRowStyle = rowStyle;
        else
            currentRowStyle = alternatingRowStyle;
    }

    private boolean allFiltersMatch(Object line, TreeMap filterMap) throws JspException {
        Iterator itrKey = filterMap.keySet().iterator();
        boolean isPassed = false;
        while (itrKey.hasNext()) {
            String key = (String) itrKey.next();
            String value = (String) filterMap.get(key);
            if (ColumnTag.getLineAttributeValue(line, key) != null
                    && ColumnTag.getLineAttributeValue(line, key).toString()
                            .equalsIgnoreCase(value)) {
                isPassed = true;
            } else
                return false;
        } // end while
        return isPassed;
    }

    private void filter() throws JspException {
        Enumeration filterColumnNames = request.getParameterNames();
        Locale locale = ReIMUserContext.getLocale();
        String all = ReIMI18NUtility.getWidget("Dropdown.all", locale);

        TreeMap filterMap = new TreeMap();
        while (filterColumnNames.hasMoreElements()) {
            String filterName = filterColumnNames.nextElement().toString();
            try {
                String filterValue = filterName.startsWith("filterColumn") ? URLDecoder.decode(
                        request.getParameter(filterName), "UTF-8") : request
                        .getParameter(filterName);

                if (filterName.startsWith("filterColumn" + persistId + "@") && filterValue != null
                        && !filterValue.equalsIgnoreCase(all)) {
                    // Strip filterColumn_ from the name
                    String s = filterName.substring(filterName.indexOf("@") + 1);
                    filterMap.put(s, filterValue);
                }
            } catch (UnsupportedEncodingException e) {
                throw new JspException(e);
            }

        }
        if (filterMap.isEmpty()) {
            // There is nothing to filter
            return;
        }
        TreeMap resultMap = new TreeMap();
        for (int i = 0; i < array.length; i++) {
            if (allFiltersMatch(array[i], filterMap)) {
                resultMap.put(new Integer(i), array[i]);
            }
        } // end for
        array = resultMap.values().toArray();
    }

    private void sort() throws JspException {
        try {
            boolean sort = true;
            String oldSortColumn = (String) request.getSession().getAttribute(oldSortByKey);
            String oldSortDirection = (String) request.getSession().getAttribute(oldDirectionByKey);

            String sortColumn = request.getParameter(orderByKey);
            String sortDirection = request.getParameter(directionKey);
            String sortType = request.getParameter(typeKey);
            if (array == null || array.length == 0) return;
            int type = ObjectComparator.ALPHANUMERIC;
            if (sortType != null && sortType.length() > 0) {
                type = Integer.parseInt(sortType);
            }
            if (oldSortColumn != null && oldSortDirection != null) {

                if (oldSortColumn.equals(sortColumn)) {
                    if (oldSortDirection.equals(sortDirection)) {
                        sort = false;
                    }
                }
            }

            if (sort) {
                Sorter.sort(array, sortColumn, sortDirection, type);
                request.getSession().setAttribute(oldSortByKey, sortColumn);
                request.getSession().setAttribute(oldDirectionByKey, sortDirection);

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new JspException(e);
        }
    }

    private int getCurrentPageOffset() {
        if (array == null || array.length == 0) return 0;
        if (null == request.getParameter(positionKey)
                || Integer.parseInt(request.getParameter(positionKey)) > array.length)
        {
        	if(request.getSession().getAttribute("returningScreen") != null)
        	{
	        	if(request.getSession().getAttribute("currentPageOffset") != null)
	        		return((Integer)request.getSession().getAttribute("currentPageOffset")).intValue();
	        	else
	        		return 0;
        	}
        	else
        		return 0;

        } else {

        	if(request.getSession().getAttribute("returningScreen") != null)
        	{
        		if(request.getSession().getAttribute("currentPageOffset") != null)
        			return((Integer)request.getSession().getAttribute("currentPageOffset")).intValue();
        		else
        			return 0;
        	}
        	else
        		return Integer.parseInt(request.getParameter(positionKey));
        }
    }

    private Object[] getArray() throws JspException {
        try {
            Object form = pageContext.findAttribute(name);
            Method getMethod = ReflectionUtils.getAccessorMethod(property, form);
            return (Object[]) getMethod.invoke(form, null);
        } catch (Exception ioe) {
            ioe.printStackTrace();
            throw new JspException(ioe);
        }
    }

    private String generateJavascript() {
        StringBuffer out = new StringBuffer();
        String documentForm = "document." + name + ".";
        out.append("<script language='Javascript'>\n");
        out.append("function doSortColumn(columnName, direction,type)\n{\n    ");
        out.append(documentForm);
        out.append(orderByKey);
        out.append(".value=columnName;\n    ");
        out.append(documentForm);
        out.append(directionKey);
        out.append(".value=direction;\n    ");
        out.append(documentForm);
        out.append(typeKey);
        out.append(".value=type;\n    ");
        out.append(documentForm);
        out.append(positionKey);
        out.append(".value=0;\n    ");
        out.append(documentForm);
        out.append("action='");
        out.append(getReferredPage());
        out.append("';\n    ");
        out.append(documentForm);
        out.append("submit();\n}\n\nfunction doPaging(position)\n{\n    ");
        out.append(documentForm);
        out.append(positionKey);
        out.append(".value=position;\n    ");
        out.append(documentForm);
        out.append("action='");
        out.append(getReferredPage());
        out.append("';\n    ");
        out.append(documentForm);
        out.append("submit();\n}");
        if (!StringUtils.isEmpty(getOnDoubleClickMethod())) {
            out.append("\n	function onDoubleClickHighLightRow(object)\n");
            out.append("	{\n");
            out
                    .append("		if  (object.className == object.tagName || object.className == 'gLOVRow')\n");
            out.append("		{\n");
            out.append("			if  (object.className == 'gLOVRow')\n");
            out.append("			{\n");
            out.append("				if  (object.id == 'SELECTED0')\n");
            out.append("				{\n");
            out.append("					object.className = 'gOddRow';\n");
            out.append("					object.id = 0;\n");
            out.append("				}\n");
            out.append("				else if (object.id == 'SELECTED1')\n");
            out.append("				{\n");
            out.append("					object.className = 'gEvenRow';\n");
            out.append("					object.id = 1;\n");
            out.append("				}\n");
            out.append("			}\n");
            out.append("			else\n");
            out.append("			{\n");
            out.append("				var element0 = document.getElementById('SELECTED0');\n");
            out.append("				var element1 = document.getElementById('SELECTED1');\n");
            out.append("				if (element0 != null)\n");
            out.append("				{\n");
            out.append("					element0.className='gOddRow';\n");
            out.append("					element0.id=0;\n");
            out.append("				}\n");
            out.append("				else if (element1 != null)\n");
            out.append("				{\n");
            out.append("					element1.className='gEvenRow';\n");
            out.append("					element1.id=1;\n");
            out.append("				}\n");
            out.append("				object.className='gLOVRow';\n");
            out.append("				object.id= (object.id%2==0) ? 'SELECTED0' : 'SELECTED1';\n");
            out.append("			}\n");
            out.append("		}\n");
            out.append("	}\n");
        } else if (!StringUtils.isEmpty(getOnClickMethod())) {
            out.append("\n	function onClickHighLightRow(object)\n");
            out.append("	{\n");
            out
                    .append("		if  (object.className == object.tagName || object.className == 'gLOVRow')\n");
            out.append("		{\n");
            out.append("			if  (object.className == 'gLOVRow')\n");
            out.append("			{\n");
            out.append("				if  (object.id == 'SELECTED0')\n");
            out.append("				{\n");
            out.append("					object.className = 'gOddRow';\n");
            out.append("					object.id = 0;\n");
            out.append("				}\n");
            out.append("				else if (object.id == 'SELECTED1')\n");
            out.append("				{\n");
            out.append("					object.className = 'gEvenRow';\n");
            out.append("					object.id = 1;\n");
            out.append("				}\n");
            out.append("			}\n");
            out.append("			else\n");
            out.append("			{\n");
            out.append("				var element0 = document.getElementById('SELECTED0');\n");
            out.append("				var element1 = document.getElementById('SELECTED1');\n");
            out.append("				if (element0 != null)\n");
            out.append("				{\n");
            out.append("					element0.className='gOddRow';\n");
            out.append("					element0.id=0;\n");
            out.append("				}\n");
            out.append("				else if (element1 != null)\n");
            out.append("				{\n");
            out.append("					element1.className='gEvenRow';\n");
            out.append("					element1.id=1;\n");
            out.append("				}\n");
            out.append("				object.className='gLOVRow';\n");
            out.append("				object.id= (object.id%2==0) ? 'SELECTED0' : 'SELECTED1';\n");
            out.append("			}\n");
            out.append("		}\n");
            out.append("	}\n");
        }
        out.append("\n</script>\n");
        out.append("<input type='hidden' name='");
        out.append(directionKey);
        out.append("' value='");
        out.append(getSortDirection());
        out.append("'>");
        out.append("<input type='hidden' name='");
        out.append(orderByKey);
        out.append("' value='");
        out.append(getSortColumn());
        out.append("'>");
        out.append("<input type='hidden' name='");
        out.append(typeKey);
        out.append("' value='");
        out.append(getSortType());
        out.append("'>");
        out.append("<input type='hidden' name='");
        out.append(positionKey);
        out.append("' value='");
        out.append(getCurrentPageOffset());
        out.append("'>");
        out.append("<input type='hidden' name='");
        out.append(requestedViewNameKey);
        out.append("' value='");
        out.append(getRequestedViewName());
        out.append("'>");
        return out.toString();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNumberOfRows() {
        return String.valueOf(numberOfRows);
    }

    public String getProperty() {
        return property;
    }

    public String getTableWidth() {
        return tableWidth;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumberOfRows(String numberOfRows) {
        this.numberOfRows = Integer.parseInt(numberOfRows);
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public void setTableWidth(String tableWidth) {
        this.tableWidth = tableWidth;
    }

    public String getSortType() {
        if (null != request.getParameter(typeKey)) {
            return request.getParameter(typeKey);
        } else {
            return "";
        }
    }

    public String getSortColumn() {
        if (null != request.getParameter(orderByKey)) {
            return request.getParameter(orderByKey);
        } else {
            return "";
        }
    }

    public String getSortDirection() {
        if (null != request.getParameter(directionKey)) {
            return request.getParameter(directionKey);
        } else {
            return Sorter.ASCENDING;
        }
    }

    public boolean isFirstTime() {
        return isFirstTime;
    }

    public void setIsFirstTime(boolean isFirstTime) {
        this.isFirstTime = isFirstTime;
    }

    HttpServletRequest getRequest() {
        return request;
    }

    void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public String getAlternatingRowStyle() {
        return alternatingRowStyle;
    }

    public String getRowStyle() {
        return rowStyle;
    }

    public void setAlternatingRowStyle(String primaryRowColor) {
        this.alternatingRowStyle = primaryRowColor;
    }

    public void setRowStyle(String secondaryRowColor) {
        this.rowStyle = secondaryRowColor;
    }

    public String getColSpan() {
        return colSpan;
    }

    public void setColSpan(String colSpan) {
        this.colSpan = colSpan;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public boolean isHeaderOnly() {
        return isHeaderOnly;
    }

    public void setIsHeaderOnly(boolean isHeaderOnly) {
        this.isHeaderOnly = isHeaderOnly;
    }

    public String getScrollableHeader() {
        return scrollableHeader;
    }

    public void setScrollableHeader(String scrollableHeader) {
        this.scrollableHeader = scrollableHeader;
    }

    public boolean isPaging() {
        return paging;
    }

    public void setPaging(boolean paging) {
        this.paging = paging;
    }

    public String getFlexColumnTitleKey() {
        return flexColumnTitleKey;
    }

    public void setFlexColumnTitleKey(String flexColumnTitleKey) {
        this.flexColumnTitleKey = flexColumnTitleKey;
    }

    public String getPersistId() {
        return persistId;
    }

    public void setPersistId(String persistId) {
        this.persistId = persistId;
    }

    public String getOrderByKey() {
        return orderByKey;
    }

    public String getPositionKey() {
        return positionKey;
    }

    public String getTypeKey() {
        return typeKey;
    }

    public String getDirectionKey() {
        return directionKey;
    }

    public String getModelKey() {
        return modelKey;
    }

    public void setDirectionKey(String dIRECTION_KEY) {
        directionKey = dIRECTION_KEY;
    }

    public void setModelKey(String mODEL_KEY) {
        modelKey = mODEL_KEY;
    }

    public void setOrderByKey(String oRDER_BY_KEY) {
        orderByKey = oRDER_BY_KEY;
    }

    public void setPositionKey(String pOSITION_KEY) {
        positionKey = pOSITION_KEY;
    }

    public void setTypeKey(String tYPE_KEY) {
        typeKey = tYPE_KEY;
    }

    public int getCurrentRow() {
        return currentRow;
    }

    public String getCurrentRowStyle() {
        return currentRowStyle;
    }

    public void setCurrentPageOffset(int currentPageOffset) {
        this.currentPageOffset = currentPageOffset;
    }

    public void setCurrentRow(int currentRow) {
        this.currentRow = currentRow;
    }

    public void setCurrentRowStyle(String currentRowStyle) {
        this.currentRowStyle = currentRowStyle;
    }

    public void setNumberOfRows(int numberOfRows) {
        this.numberOfRows = numberOfRows;
    }

    public String getRequestedViewName() {
        if (null != request.getParameter(requestedViewNameKey)) {
            return request.getParameter(requestedViewNameKey);
        } else {
            return "";
        }
    }

    public String getOnDoubleClickMethod() {
        return onDoubleClickMethod;
    }

    public void setOnDoubleClickMethod(String onDoubleClickMethod) {
        this.onDoubleClickMethod = onDoubleClickMethod;
    }

	public String getOnClickMethod() {
		return onClickMethod;
	}

	public void setOnClickMethod(String onClickMethod) {
		this.onClickMethod = onClickMethod;
	}

    public String getHeaderClass() {
        return headerClass;
    }

    public void setHeaderClass(String string) {
        headerClass = string;
    }

    public void release() {
        cleanUp();
        super.release();
    }

    private void cleanUp() {
        array = null;
        request = null;
        ch = null;
    }
}