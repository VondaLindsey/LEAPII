package com.retek.reim.ui.invoiceMaintenance;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import oracle.retail.reim.business.Vendor;

import com.retek.reim.business.Option;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.UserRole;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.vendor.VendorUtility;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;

public final class InvoiceAdvSearchForm extends MaintenanceForm {
    // Save the user role on the form for later use.
    private UserRole userRole;

    private String actionType = "";
    private String docType = "";
    // This is really the extDocId that the user is entering!
    private String docId = "";
    private String docStatus = "";
    private String beginDate = "";
    private String endDate = "";
    private String vendorTypeSelect = "";
    private String docTypeSelect = "";
    private String beginDueDate = "";
    private String endDueDate = "";
    private String beginTotalCost = "";
    private String endTotalCost = "";
    private String beginQuantity = "";
    private String endQuantity = "";
    private String priceRev = "";
    private String qtyRev = "";
    private String prePaid = "";
    private String detailsExist = "";
    private String freightType = "";
    private String paymentTermsLOV = "";
    private String paymentTermsLOVDesc = "";
    private String apReviewerLOV = "";
    private String apReviewerLOVDesc = "";
    private String button = "";
    private String consignment = "";
    private String deal = "";

    // drop down list menus
    private Collection actionOptions = new Vector();
    private Collection docTypeOptions = new Vector();
    private Collection docStatusOptions = new Vector();
    private Collection vendorTypeOptions = new Vector();
    private Collection qtyRevOptions = new Vector();
    private Collection priceRevOptions = new Vector();
    private Collection freightTypeOptions = new Vector();
    private Collection prePaidOptions = new Vector();
    private Collection detailsExistOptions = new Vector();
    private Collection consignmentOptions = new ArrayList();
    private Collection dealOptions = new ArrayList();

    // hidden fields
    private String vendor = "";
    private String vendorDesc = "";
    private String orderNo = "";
    private String ordDesc = "";
    private String receiptNo = "";
    private String recDesc = "";
    private String location = "";
    private String locDesc = "";
    private String dept = "";
    private String item = "";
    private String itemName = "";
    private String currency = "";
    private String currName = "";
    private String costRole = "";
    private String costRoleDesc = "";
    private String qtyRole = "";
    private String qtyRoleDesc = "";
    private String apReviewerLOVDesc2 = "";
    private String apRevDescSave = "";
    private String termsDescSave = "";
    private String statusCode = "";
    private ReIMDate vDate;
    private String defDate = ""; // default beginDate to 14 days before vdate

    public Collection getActionOptions() {
        return actionOptions;
    }

    public String getActionType() {
        return actionType;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public String getBeginDueDate() {
        return beginDueDate;
    }

    public String getBeginTotalCost() {
        return beginTotalCost;
    }

    public String getCurrency() {
        return currency;
    }

    public String getDept() {
        return dept;
    }

    public String getDocId() {
        return docId;
    }

    public String getDocStatus() {
        return docStatus;
    }

    public Collection getDocStatusOptions() {
        return docStatusOptions;
    }

    public String getDocType() {
        return docType;
    }

    public Collection getDocTypeOptions() {
        return docTypeOptions;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getEndDueDate() {
        return endDueDate;
    }

    public String getEndTotalCost() {
        return endTotalCost;
    }

    public String getFreightType() {
        return freightType;
    }

    public Collection getFreightTypeOptions() {
        return freightTypeOptions;
    }

    public String getItem() {
        return item;
    }

    public String getLocation() {
        return location;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getPrePaid() {
        return prePaid;
    }

    public Collection getPrePaidOptions() {
        return prePaidOptions;
    }

    public String getPriceRev() {
        return priceRev;
    }

    public Collection getPriceRevOptions() {
        return priceRevOptions;
    }

    public String getQtyRev() {
        return qtyRev;
    }

    public Collection getQtyRevOptions() {
        return qtyRevOptions;
    }

    public String getReceiptNo() {
        return receiptNo;
    }

    public String getVendorTypeSelect() {
        return vendorTypeSelect;
    }

    public Collection getVendorTypeOptions() {
        return vendorTypeOptions;
    }

    public String getButton() {
        return button;
    }

    public String getVendorDesc() {
        return vendorDesc;
    }

    public String getVendor() {
        return vendor;
    }

    public String getLocDesc() {
        return locDesc;
    }

    public String getItemName() {
        return itemName;
    }

    public String getcurrName() {
        return currName;
    }

    public String getOrdDesc() {
        return ordDesc;
    }

    public String getRecDesc() {
        return recDesc;
    }

    public String getDefDate() {
        return defDate;
    }

    public ReIMDate getVDate() {
        return vDate;
    }

    public String getCostRole() {
        return costRole;
    }

    public String getCostRoleDesc() {
        return costRoleDesc;
    }

    public String getQtyRole() {
        return qtyRole;
    }

    public String getQtyRoleDesc() {
        return qtyRoleDesc;
    }

    public String getBeginQuantity() {
        return beginQuantity;
    }

    public String getDetailsExist() {
        return detailsExist;
    }

    public String getEndQuantity() {
        return endQuantity;
    }

    public String getPaymentTermsLOV() {
        return paymentTermsLOV;
    }

    public String getPaymentTermsLOVDesc() {
        return paymentTermsLOVDesc;
    }

    public Collection getDetailsExistOptions() {
        return detailsExistOptions;
    }

    public String getApReviewerLOV() {
        return apReviewerLOV;
    }

    public String getApReviewerLOVDesc() {
        return apReviewerLOVDesc;
    }

    public String getApReviewerLOVDesc2() {
        return apReviewerLOVDesc2;
    }

    public String getApRevDescSave() {
        return apRevDescSave;
    }

    public String getTermsDescSave() {
        return termsDescSave;
    }

    // setters
    public void setActionOptions(Collection actionOptions) {
        this.actionOptions = actionOptions;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public void setBeginDate(String beginDate) throws ReIMException {

        this.beginDate = beginDate;
    }

    public void setBeginDueDate(String beginDueDate) {
        this.beginDueDate = beginDueDate;
    }

    public void setBeginTotalCost(String beginTotalCost) {
        this.beginTotalCost = beginTotalCost;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

    public void setDocStatusOptions(Collection docStatusOptions) {
        this.docStatusOptions = docStatusOptions;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public void setDocTypeOptions(Collection docTypeOptions) {
        this.docTypeOptions = docTypeOptions;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setEndDueDate(String endDueDate) {
        this.endDueDate = endDueDate;
    }

    public void setEndTotalCost(String endTotalCost) {
        this.endTotalCost = endTotalCost;
    }

    public void setFreightType(String freightType) {
        this.freightType = freightType;
    }

    public void setFreightTypeOptions(Collection freightTypeOptions) {
        this.freightTypeOptions = freightTypeOptions;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public void setPrePaid(String prePaid) {
        this.prePaid = prePaid;
    }

    public void setPrePaidOptions(Collection prePaidOptions) {
        this.prePaidOptions = prePaidOptions;
    }

    public void setPriceRev(String priceRev) {
        this.priceRev = priceRev;
    }

    public void setPriceRevOptions(Collection priceRevOptions) {
        this.priceRevOptions = priceRevOptions;
    }

    public void setQtyRev(String qtyRev) {
        this.qtyRev = qtyRev;
    }

    public void setQtyRevOptions(Collection qtyRevOptions) {
        this.qtyRevOptions = qtyRevOptions;
    }

    public void setReceiptNo(String receiptNo) {
        this.receiptNo = receiptNo;
    }

    public void setVendorTypeSelect(String vendorTypeSelect) {
        this.vendorTypeSelect = vendorTypeSelect;
    }

    public void setVendorTypeOptions(Collection vendorTypeOptions) {
        this.vendorTypeOptions = vendorTypeOptions;
    }

    public void setButton(String button) {
        this.button = button;
    }

    public void setVendorDesc(String vendorDesc) {
        this.vendorDesc = vendorDesc;
    }

    public void setVendor(String vendorId) {
        this.vendor = vendorId;
    }

    public void setLocDesc(String locDesc) {
        this.locDesc = locDesc;
    }

    public void setItemName(String itemDesc) {
        this.itemName = itemDesc;
    }

    public void setcurrName(String currDesc) {
        this.currName = currDesc;
    }

    public void setOrdDesc(String ordDesc) {
        this.ordDesc = ordDesc;
    }

    public void setRecDesc(String recDesc) {
        this.recDesc = recDesc;
    }

    public void setDefDate(String defDate) {
        this.defDate = defDate;
    }

    public void setVDate(ReIMDate vDate) {
        this.vDate = vDate;
    }

    public void setCostRole(String costRole) {
        this.costRole = costRole;
    }

    public void setCostRoleDesc(String costRoleDesc) {
        this.costRoleDesc = costRoleDesc;
    }

    public void setQtyRole(String qtyRole) {
        this.qtyRole = qtyRole;
    }

    public void setQtyRoleDesc(String qtyRoleDesc) {
        this.qtyRoleDesc = qtyRoleDesc;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    public void setBeginQuantity(String beginQuantity) {
        this.beginQuantity = beginQuantity;
    }

    public void setDetailsExist(String detailsExist) {
        this.detailsExist = detailsExist;
    }

    public void setEndQuantity(String endQuantity) {
        this.endQuantity = endQuantity;
    }

    public void setPaymentTermsLOV(String paymentTermsLOV) {
        this.paymentTermsLOV = paymentTermsLOV;
    }

    public void setPaymentTermsLOVDesc(String paymentTermsLOVDesc) {
        this.paymentTermsLOVDesc = paymentTermsLOVDesc;
    }

    public void setApReviewerLOV(String apReviewerLOV) {
        this.apReviewerLOV = apReviewerLOV;
    }

    public void setDetailsExistOptions(Collection detailsExistOptions) {
        this.detailsExistOptions = detailsExistOptions;
    }

    public void setApReviewerLOVDesc(String apReviewerLOVDesc) {
        this.apReviewerLOVDesc = apReviewerLOVDesc;
    }

    public void setApReviewerLOVDesc2(String apReviewerLOVDesc2) {
        this.apReviewerLOVDesc2 = apReviewerLOVDesc2;
    }

    public void setApRevDescSave(String apRevDescSave) {
        this.apRevDescSave = apRevDescSave;
    }

    public void setTermsDescSave(String termsDescSave) {
        this.termsDescSave = termsDescSave;
    }

    public void populateCollections() {

        if (actionOptions.size() == 0) {
            actionOptions.add(new Option(VIEW, ReIMI18NUtility.getWidget("button.view")));
            actionOptions.add(new Option(NEW, ReIMI18NUtility.getWidget("new")));
            actionOptions.add(new Option(EDIT, ReIMI18NUtility.getWidget("button.edit")));
            actionOptions.add(new Option(MASSEDIT, ReIMI18NUtility
                    .getWidget("Dropdown.massEdit")));
            actionOptions.add(new Option(VOID, ReIMI18NUtility
                    .getWidget("Dropdown.voidCreditNoteRequest")));
            
        }

        populateDocTypeOptions();

        if (vendorTypeOptions.size() == 0) {
            populateVendorTypeOptions();
            vendorTypeSelect = Vendor.SUPPLIER;
        }

        populateDocStatusOptions();

        if (qtyRevOptions.size() == 0) {
            qtyRevOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            qtyRevOptions.add(new Option(YES, ReIMI18NUtility.getWidget("label.yes")));
            qtyRevOptions.add(new Option(NO, ReIMI18NUtility.getWidget("label.no")));
        }

        if (priceRevOptions.size() == 0) {
            priceRevOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            priceRevOptions.add(new Option(YES, ReIMI18NUtility.getWidget("label.yes")));
            priceRevOptions.add(new Option(NO, ReIMI18NUtility.getWidget("label.no")));
        }

        if (prePaidOptions.size() == 0) {
            prePaidOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            prePaidOptions.add(new Option(YES, ReIMI18NUtility.getWidget("label.yes")));
            prePaidOptions.add(new Option(NO, ReIMI18NUtility.getWidget("label.no")));
        }

        if (detailsExistOptions.size() == 0) {
            detailsExistOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            detailsExistOptions.add(new Option(YES, ReIMI18NUtility.getWidget("label.yes")));
            detailsExistOptions.add(new Option(NO, ReIMI18NUtility.getWidget("label.no")));
        }

        if (freightTypeOptions.size() == 0) {
            freightTypeOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            freightTypeOptions.add(new Option(Document.COLLECT, ReIMI18NUtility
                    .getMessage("Code.SHMT.CC")));
            freightTypeOptions.add(new Option(Document.COLLECT_FREIGHT_CREDITED_BACK_TO_CUSTOMER,
                    ReIMI18NUtility.getMessage("Code.SHMT.CF")));
            freightTypeOptions.add(new Option(Document.DEFINED_BY_BUYER_AND_SELLER, ReIMI18NUtility
                    .getMessage("Code.SHMT.DF")));
            freightTypeOptions.add(new Option(Document.MIXED, ReIMI18NUtility
                    .getMessage("Code.SHMT.MX")));
            freightTypeOptions.add(new Option(Document.PREPAID_BUT_CHARGED_TO_CUSTOMER,
                    ReIMI18NUtility.getMessage("Code.SHMT.PC")));
            freightTypeOptions.add(new Option(Document.PREPAID_ONLY, ReIMI18NUtility
                    .getMessage("Code.SHMT.PO")));
            freightTypeOptions.add(new Option(Document.PREPAID_BY_SELLER, ReIMI18NUtility
                    .getMessage("Code.SHMT.PP")));
        }

        if (this.dealOptions.size() == 0) {
            this.dealOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            this.dealOptions.add(new Option(YES, ReIMI18NUtility.getWidget("label.yes")));
            this.dealOptions.add(new Option(NO, ReIMI18NUtility.getWidget("label.no")));
        }

        if (this.consignmentOptions.size() == 0) {
            this.consignmentOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            this.consignmentOptions.add(new Option(YES, ReIMI18NUtility.getWidget("label.yes")));
            this.consignmentOptions.add(new Option(NO, ReIMI18NUtility.getWidget("label.no")));
        }
    }

    public void populateVendorTypeOptions() {
        vendorTypeOptions = VendorUtility.getAllVendorTypesForFormOptionsList(true, false);
    }

    public void populateDocTypeOptions() {
        if (docTypeOptions.size() == 0) {
            populateAllDocTypeOptions();
        } else {
        	docTypeOptions = new Vector();
        	if (getActionType() != null && getActionType().equals(EDIT)) {
        		docTypeOptions.add(new Option(Document.MERCHANDISE_INVOICE, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.MRCHI")));
        		docTypeSelect = Document.MERCHANDISE_INVOICE;
        		
        		docTypeOptions.add(new Option(Document.CREDIT_MEMO_PRICE, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDMEC")));
        		docTypeSelect = Document.CREDIT_MEMO_PRICE;

        		docTypeOptions.add(new Option(Document.CREDIT_MEMO_QUANTITY, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDMEQ")));
        		docTypeSelect = Document.CREDIT_MEMO_QUANTITY;

        		docTypeOptions.add(new Option(Document.CREDIT_NOTE, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDNT")));
        		docTypeSelect = Document.CREDIT_NOTE;

        		docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_PRICE, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDNRC")));
        		docTypeSelect = Document.CREDIT_NOTE_REQUEST_PRICE;

        		docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_QUANTITY, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDNRQ")));
        		docTypeSelect = Document.CREDIT_NOTE_REQUEST_QUANTITY;

        		docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_TAX, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDNRT")));
        		docTypeSelect = Document.CREDIT_NOTE_REQUEST_TAX;

        		docTypeOptions.add(new Option(Document.DEBIT_MEMO_PRICE, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.DEBMEC")));
        		docTypeSelect = Document.DEBIT_MEMO_PRICE;

        		docTypeOptions.add(new Option(Document.DEBIT_MEMO_QUANTITY, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.DEBMEQ")));
        		docTypeSelect = Document.DEBIT_MEMO_QUANTITY;

        		docTypeOptions.add(new Option(Document.DEBIT_MEMO_TAX, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.DEBMET")));
        		docTypeSelect = Document.DEBIT_MEMO_TAX;
        		
        	} else if (getActionType() != null && getActionType().equals(VOID)) {
        		docTypeOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
        		docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_PRICE, ReIMI18NUtility
        				.getWidget("Code.DOCTYP.CRDNRC")));
                docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_QUANTITY,
                        ReIMI18NUtility.getWidget("Code.DOCTYP.CRDNRQ")));
                docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_TAX, ReIMI18NUtility
                        .getWidget("Code.DOCTYP.CRDNRT")));
            } else {
                populateAllDocTypeOptions();
            }
        }
    }

    /**
     * Method populateAllDocTypeOptions.
     * 
     * This method populates the doc type collection used in the document type drop-down list on the
     * Document Search screen.
     */
    public void populateAllDocTypeOptions() {
        boolean taxEnabled = ReIMSystemOptions.getInstance().isProcessTaxes();
        docTypeOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
        docTypeOptions.add(new Option(Document.MERCHANDISE_INVOICE, ReIMI18NUtility
                .getWidget("Code.DOCTYP.MRCHI")));
        docTypeOptions.add(new Option(Document.NON_MERCHANDISE_INVOICE, ReIMI18NUtility
                .getWidget("Code.DOCTYP.NMRCHI")));
        docTypeOptions.add(new Option(Document.CREDIT_MEMO_PRICE, ReIMI18NUtility
                .getWidget("Code.DOCTYP.CRDMEC")));
        docTypeOptions.add(new Option(Document.CREDIT_MEMO_QUANTITY, ReIMI18NUtility
                .getWidget("Code.DOCTYP.CRDMEQ")));
        docTypeOptions.add(new Option(Document.CREDIT_NOTE, ReIMI18NUtility
                .getWidget("Code.DOCTYP.CRDNT")));
        docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_PRICE, ReIMI18NUtility
                .getWidget("Code.DOCTYP.CRDNRC")));
        docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_QUANTITY, ReIMI18NUtility
                .getWidget("Code.DOCTYP.CRDNRQ")));
        if (taxEnabled) {
            docTypeOptions.add(new Option(Document.CREDIT_NOTE_REQUEST_TAX, ReIMI18NUtility
                    .getWidget("Code.DOCTYP.CRDNRT")));
        }
        docTypeOptions.add(new Option(Document.DEBIT_MEMO_PRICE, ReIMI18NUtility
                .getWidget("Code.DOCTYP.DEBMEC")));
        docTypeOptions.add(new Option(Document.DEBIT_MEMO_QUANTITY, ReIMI18NUtility
                .getWidget("Code.DOCTYP.DEBMEQ")));
        if (taxEnabled) {
            docTypeOptions.add(new Option(Document.DEBIT_MEMO_TAX, ReIMI18NUtility
                    .getWidget("Code.DOCTYP.DEBMET")));
        }
    }

    /**
     * Method populateDocStatusOptions.
     * 
     * This method populates the doc status collection used in the status drop-down list on the
     * Document Search screen.
     */
    public void populateDocStatusOptions() {
        if (getActionType() != null && getActionType().equals(EDIT)) {
            docStatusOptions = new Vector();
            docStatusOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            docStatusOptions.add(new Option(Document.READY_FOR_MATCH, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.RMTCH")));
            docStatusOptions.add(new Option(Document.UNRESOLVED_MATCH, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.URMTCH")));
            docStatusOptions.add(new Option(Document.MULTI_UNRESOLVED, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.MURMTH")));
            docStatusOptions.add(new Option(Document.TAX_DISCREPANCY, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.TAXDISCREP")));
        } else {
            docStatusOptions = new Vector();
            if (getActionType().equals(VIEW) || getActionType().equals(EMPTY_STRING)) {
                docStatusOptions.add(new Option(Document.ALL_EXCEPT_POSTED, ReIMI18NUtility
                        .getWidget("Code.DOCSTS.ALEXPOST")));
                docStatusOptions.add(new Option(Document.ALL_INCLUDE_POSTED, ReIMI18NUtility
                        .getWidget("Code.DOCSTS.ALINPOST")));
            } else {
                docStatusOptions.add(new Option(EMPTY_STRING, EMPTY_STRING));
            }
            docStatusOptions.add(new Option(Document.READY_FOR_MATCH, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.RMTCH")));
            docStatusOptions.add(new Option(Document.UNRESOLVED_MATCH, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.URMTCH")));
            docStatusOptions.add(new Option(Document.MULTI_UNRESOLVED, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.MURMTH")));
            docStatusOptions.add(new Option(Document.TAX_DISCREPANCY, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.TAXDISCREP")));
            docStatusOptions.add(new Option(Document.VOID, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.VOID")));
            docStatusOptions.add(new Option(Document.MATCHED, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.MTCH")));
            docStatusOptions.add(new Option(Document.DISPUTED, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.DISPUT")));
            docStatusOptions.add(new Option(Document.APPROVED, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.APPRVE")));
            docStatusOptions.add(new Option(Document.POSTED, ReIMI18NUtility
                    .getWidget("Code.DOCSTS.POSTED")));
            docStatusOptions.add(new Option(Document.SUBMITTED, ReIMI18NUtility
                    .getWidget("Code.DCGRPS.SUBMIT")));
        }
    }

    /**
     * Method reset.
     * 
     * This method resets all the fields on the Document Search screen.
     */
    public void reset() throws ReIMException {
        actionType = EMPTY_STRING;
        docType = EMPTY_STRING;
        docId = EMPTY_STRING;
        docStatus = EMPTY_STRING;
        beginDate = EMPTY_STRING;
        endDate = EMPTY_STRING;
        vendorTypeSelect = EMPTY_STRING;
        beginDueDate = EMPTY_STRING;
        endDueDate = EMPTY_STRING;
        beginTotalCost = EMPTY_STRING;
        endTotalCost = EMPTY_STRING;
        priceRev = EMPTY_STRING;
        qtyRev = EMPTY_STRING;
        prePaid = EMPTY_STRING;
        freightType = EMPTY_STRING;
        beginQuantity = EMPTY_STRING;
        endQuantity = EMPTY_STRING;
        apReviewerLOV = EMPTY_STRING;
        apReviewerLOVDesc = EMPTY_STRING;
        detailsExist = EMPTY_STRING;
        paymentTermsLOV = EMPTY_STRING;
        paymentTermsLOVDesc = EMPTY_STRING;
        button = EMPTY_STRING;

        actionOptions = new Vector();
        docTypeOptions = new Vector();
        docStatusOptions = new Vector();
        vendorTypeOptions = new Vector();
        qtyRevOptions = new Vector();
        priceRevOptions = new Vector();
        freightTypeOptions = new Vector();
        prePaidOptions = new Vector();
        consignmentOptions = new Vector();
        dealOptions = new Vector();

        orderNo = EMPTY_STRING;
        ordDesc = EMPTY_STRING;
        location = EMPTY_STRING;
        vendor = EMPTY_STRING;
        dept = EMPTY_STRING;
        item = EMPTY_STRING;
        receiptNo = EMPTY_STRING;
        recDesc = EMPTY_STRING;
        currency = EMPTY_STRING;
        locDesc = EMPTY_STRING;
        vendorDesc = EMPTY_STRING;
        itemName = EMPTY_STRING;
        currName = EMPTY_STRING;
        costRole = EMPTY_STRING;
        costRoleDesc = EMPTY_STRING;
        qtyRole = EMPTY_STRING;
        qtyRoleDesc = EMPTY_STRING;
        apReviewerLOVDesc2 = EMPTY_STRING;
        apRevDescSave = EMPTY_STRING;
        termsDescSave = EMPTY_STRING;
        statusCode = EMPTY_STRING;

        actionType = VIEW;
        vendorTypeSelect = Vendor.SUPPLIER;
        this.setBeginDate(this.getDefDate());
    }

    /**
     * Method reset.
     * 
     * This method resets some the fields on the Document Search screen.
     */
    public void refreshForm() throws ReIMException {
        docType = "";
        docId = "";
        docStatus = "";
        beginDate = "";
        endDate = "";
        vendorTypeSelect = "";
        beginDueDate = "";
        endDueDate = "";
        beginTotalCost = "";
        endTotalCost = "";
        priceRev = "";
        qtyRev = "";
        prePaid = "";
        freightType = "";
        beginQuantity = "";
        endQuantity = "";
        apReviewerLOV = "";
        apReviewerLOVDesc = "";
        detailsExist = "";
        paymentTermsLOV = "";
        paymentTermsLOVDesc = "";
        button = "";

        orderNo = "";
        ordDesc = "";
        location = "";
        vendor = "";
        dept = "";
        item = "";
        receiptNo = "";
        recDesc = "";
        currency = "";
        locDesc = "";
        vendorDesc = "";
        itemName = "";
        currName = "";
        costRole = "";
        costRoleDesc = "";
        qtyRole = "";
        qtyRoleDesc = "";
        apReviewerLOVDesc2 = "";
        apRevDescSave = "";
        termsDescSave = "";
        statusCode = "";
        consignment = "";
        deal = "";

        vendorTypeSelect = Vendor.SUPPLIER;
        this.setBeginDate(this.getDefDate());
    }

    /**
     * Method reset.
     * 
     * This method resets some the fields on the Document Search screen.
     */
    public void docTypeRefreshForm() throws ReIMException { 
    	docId = "";
        docStatus = "";
        beginDate = "";
        endDate = "";
        vendorTypeSelect = "";
        beginDueDate = "";
        endDueDate = "";
        beginTotalCost = "";
        endTotalCost = "";
        priceRev = "";
        qtyRev = "";
        prePaid = "";
        freightType = "";
        beginQuantity = "";
        endQuantity = "";
        apReviewerLOV = "";
        apReviewerLOVDesc = "";
        detailsExist = "";
        paymentTermsLOV = "";
        paymentTermsLOVDesc = "";
        button = "";

        orderNo = "";
        ordDesc = "";
        location = "";
        vendor = "";
        dept = "";
        item = "";
        receiptNo = "";
        recDesc = "";
        currency = "";
        locDesc = "";
        vendorDesc = "";
        itemName = "";
        currName = "";
        costRole = "";
        costRoleDesc = "";
        qtyRole = "";
        qtyRoleDesc = "";
        apReviewerLOVDesc2 = "";
        apRevDescSave = "";
        termsDescSave = "";
        statusCode = "";
        consignment = "";
        deal = "";

        vendorTypeSelect = Vendor.SUPPLIER;
        this.setBeginDate(this.getDefDate());
    }
    
    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getDocTypeSelect() {
        return docTypeSelect;
    }

    public void setDocTypeSelect(String string) {
        docTypeSelect = string;
    }

    public String getConsignment() {
        return this.consignment;
    }

    public void setConsignment(String string) {
        this.consignment = string;
    }

    public String getDeal() {
        return this.deal;
    }

    public void setDeal(String string) {
        this.deal = string;
    }

    public Collection getConsignmentOptions() {
        return this.consignmentOptions;
    }

    public void setConsignmentOptions(Collection collection) {
        this.consignmentOptions = collection;
    }

    public Collection getDealOptions() {
        return this.dealOptions;
    }

    public void setDealOptions(Collection collection) {
        this.dealOptions = collection;
    }
}
