package com.retek.reim.services;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import oracle.retail.reim.business.tax.Tax;

import com.retek.reim.business.POLocation;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.business.document.DocumentReference;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;

/**
 * @see oracle.retail.reim.services.IDocumentService
 * 
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		21-May-2013	BNaik		BRN EDI Invoices should not be allowed to be edited.
 *     If any of the items are either matched or discrepancy routed(DETAIL_MATCHED='Y'), then the invoice will be in VIEW mode 
 * 		and cannot be edited. If not, the items can be edited in ready-for-match, unresolved match, and multi-unresolved invoices, and tax discrepancy status.
 * 
 */
@Deprecated
public interface IDocumentService {

    public void updateDocumentStatusToDelete(Document[] documents, String updateUserId)
            throws ReIMException;

    public String getExtDocId(String docId) throws ReIMException;

    public void updateDocumentStatus(long documentId, String docStatus, String updateUserId)
            throws ReIMException;

    public void updateDocumentStatus(long[] documentIds, String docStatus, String updateUserId)
            throws ReIMException;

    public void updateDocumentStatus(Document[] documents, String docStatus, String updateUserId)
            throws ReIMException;

    public Document getDocHeadByDocId(long docId) throws ReIMException;

    public Document getDocHeadWithTaxByDocId(long docId) throws ReIMException;

    public String getDocumentTypeDescription(String docType);

    public String getDocumentIdPrefix(String docType);

    public String getDocumentStatusDescription(String docStatus);

    public String getDocumentStatus(String docStatusDescription);

    public String getFreightTypeDescription(String freightType) throws ReIMException;

    public Document initializeDocument(String documentType) throws ReIMException;

    public String getBestTermsSource(String docSource);

    public String getBestTermsDateSource(String docDateSource);

    public void populateDocHeadInfo(Document doc) throws ReIMException;

    public Map<String, String> getDocDetails(String docId) throws ReIMException;

    public String getExtDocIdByVendor(String vendorType, String vendorId, String extDocId)
            throws ReIMException;

    public String getDocumentIdFromExternalId(String externalId) throws ReIMException;

    public String updateImDocHeadRow(ImDocHeadRow aRow) throws ReIMException;

    public String createImDocHeadRow(ImDocHeadRow aRow) throws ReIMException;

    public boolean checkExtDocIdIsDuplicate(String vendor, String extDocId, String docType)
            throws ReIMException;

    public String lockDocumentForUser(long docId, String userId) throws ReIMException;

    public String getDocumentLockUserId(long docId) throws ReIMException;

    public void releaseDocumentLock(long docId) throws ReIMException;

    public boolean lockRecordGroup(String userId, long[] docIds) throws ReIMException;

    public void releaseRecordGroupLockForUser(String userId, long[] docIds) throws ReIMException;

    public double getTotalAllowances(String documentId) throws ReIMException;

    public String getMatchDateByDocumentId(String documentId) throws ReIMException;

    public String getApprovalDateByDocumentId(String documentId) throws ReIMException;

    public MerchandiseDocument[] readMatchedInvoicesForPosting() throws ReIMException;

    public Document[] readApprovedCreditNotes() throws ReIMException;

    public Document[] readApprovedCreditMemos() throws ReIMException;

    public Document[] readApprovedDebitMemos() throws ReIMException;

    public ImDocHeadRow[] readApprovedCreditNoteRequests() throws ReIMException;

    public Vector readLateCreditNoteRequests() throws ReIMException;

    public MerchandiseDocument[] getAllInvoices(POLocation[] poLocations);

    public String getOrderInfoByDocumentId(long docId) throws ReIMException;

    public void updatePrePaid(Document[] invoices, boolean prePaid, String userId)
            throws ReIMException;

    public HashMap getAllowanceCodeAmt(String docId, String itemId) throws ReIMException;

    public DocumentReference getReferenceDocumentInfo(long docId) throws ReIMException;

    public void deleteDocument(long docId) throws ReIMException;

    public long getParentId(long docId) throws ReIMException;

    public long[] filterParentDocuments(long[] docIds) throws ReIMException;

    public double getExchangeRate(String orderNo, String vendorId, String vendorType,
            ReIMDate docDate) throws ReIMException;

    public double getExchangeRate(String orderNo, String currencyCode, ReIMDate docDate)
            throws ReIMException;

    public Document[] readApprovedNonMerchInvoices() throws ReIMException;
    
    // method migrated to the new DocumentService
    // public void updateImDocHeadCostsAndQuantitiesForRtv(final long docId)
    // throws ReIMException;

    public String getDocumentTypeByPrefix(final String docPrefix);

    public Document[] readMatchedCreditNotesForTheAction(String action) throws ReIMException;
    
    public String getDocumentStatusByExtDocId(String extDocId) throws ReIMException;
    
    // BRN OLR V1.1 Start - added    
    public String getDetailMatchedByDocId(String docId) throws ReIMException;
    // BRN OLR V1.1 End    
    /**
     * This method will approve all the details and the header. 
     * 
     * @param docId Document ID
     * @param statusCode status of the document (DISPUT|SUBMIT)
     * @return If all the details were approved successfully then it will return true. 
     *         If one or more details have already been denied then it will return false. 
     */
    public boolean approveDocument(String docId, String statusCode) throws ReIMException;

}