package com.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.business.ReIMSystemPropertiesUtil;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		13-May-2013	Syed Qadri		Modification Change :Commented out the SELECT statement to use the new one. IMS Ticket # 160668 (Release 1549). This is for 
 * 		                                                         performance enhancement according Metalink Doc id 847827 applied Bug fix 8507757.
 * 										
 */

public class ImGlCrossRefAccessExt extends ImGlCrossRefAccess implements
        IImGlCrossRefAccessExt {
    private static final String SELECT_DISTINCT_ACC_CODES =
            "SELECT DISTINCT ACCOUNT_CODE FROM IM_GL_CROSS_REF WHERE ACCOUNT_TYPE = ? AND SET_OF_BOOKS_ID = ? ";
    private static final String SELECT_DISTINCT_SOB =
            "SELECT DISTINCT SET_OF_BOOKS_ID,SET_OF_BOOKS_DESC FROM FIF_GL_SETUP ";
    private static final String SELECT_SET_OF_BOOKS_ID_BY_LOCATION =
            "SELECT distinct LOC_SOB.SET_OF_BOOKS_ID FROM MV_LOC_SOB LOC_SOB WHERE LOC_SOB.LOCATION in (SELECT (CASE MLS.LOCATION_TYPE WHEN 'W' THEN (SELECT (CASE WHEN WAREHOUSE.PRIMARY_VWH IS NULL THEN WAREHOUSE.WH ELSE (SELECT V_WAREHOUSE.WH FROM WH V_WAREHOUSE WHERE WAREHOUSE.PRIMARY_VWH = V_WAREHOUSE.WH) END) FROM WH WAREHOUSE WHERE WAREHOUSE.WH = MLS.LOCATION) ELSE MLS.LOCATION END) AS REAL_LOC FROM MV_LOC_SOB MLS WHERE LOCATION = ?)";

    public void deleteGlCrossRef() throws Exception {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn =
                    TransactionManagerFactory.getInstance().getConnection();
            stmt =
                    (OraclePreparedStatement) conn
                            .prepareStatement("DELETE FROM IM_GL_CROSS_REF");
            stmt.executeUpdate();
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_delete_gl_cross_ref",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception ex) {
                throw new ReIMException("error.cannot_delete_gl_cross_ref",
                        Severity.ERROR, ex, this);
            }
        }
    }

    public ImGlCrossRefRow[] getAllByAccTypeAndAccCode(String accountType,
            String accountCode, long sobId) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer("ACCOUNT_TYPE = ?");
            whereClause.append(" AND ACCOUNT_CODE = ?");
            whereClause.append(" AND SET_OF_BOOKS_ID = ?");

            DALGenPreparedSQLFragment stmnt =
                    new DALGenPreparedSQLFragment(whereClause.toString());

            // This MUST order by seg number or all account will be off!!
            String orderBy = "SEGMENT_NO";

            stmnt.setString(1, accountType);
            stmnt.setString(2, accountCode);
            stmnt.setLong(3, sobId);

            return super.read(stmnt, null, null, orderBy);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException(
                    "ImGlCrossRefAccessExt.getAllByAccTypeAndAccCode",
                    Severity.ERROR, e, this);
        }
    }

    public Vector getDistinctAccCodeByAccType(String accountType, long sobId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs1 = null;
        Vector mappedbasetransactions = new Vector(0);

        try {
            Connection conn =
                    TransactionManagerFactory.getInstance().getConnection();
            stmt =
                    (OraclePreparedStatement) conn
                            .prepareStatement(SELECT_DISTINCT_ACC_CODES);

            stmt.setString(1, accountType);
            stmt.setLong(2, sobId);
            rs1 = stmt.executeQuery();
            while (rs1.next()) {
                mappedbasetransactions.add(rs1.getString("ACCOUNT_CODE"));
            }

            return mappedbasetransactions;
        } catch (SQLException exception) {
            throw new ReIMException("error.cannot_access_im_gl_cross_ref",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.getDistinctAccCodeByAccType",
                        Severity.ERROR, exception, this);
            }
        }
    }

    public void updateLines(ImGlCrossRefRow[] accountLines, long sobId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;

        String sqlUpdate =
                "UPDATE IM_GL_CROSS_REF " + " SET SEGMENT_VALUE = ? "
                        + " WHERE ACCOUNT_TYPE = ? "
                        + "   AND ACCOUNT_CODE = ? " + "   AND SEGMENT_NO = ? ";
        sqlUpdate = sqlUpdate + " AND SET_OF_BOOKS_ID = ?";

        try {
            // set all invoice lines status to be updated to the invoices'
            // status
            Connection conn =
                    TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlUpdate);

            ImGlCrossRefRow accountLine = null;

            for (int i = 0; i < accountLines.length; i++) {
                accountLine = accountLines[i];
                stmt.setString(1, accountLine.getSegmentValue());
                stmt.setString(2, accountLine.getAccountType());
                stmt.setString(3, accountLine.getAccountCode());
                stmt.setInt(4, accountLine.getSegmentNo());
                stmt.setLong(5, accountLine.getSob_id());
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (ReIMException e) {
            throw e;
        } catch (SQLException exception) {
            throw new ReIMException("error.cannot_update_gl_cross_ref",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_update_gl_cross_ref",
                        Severity.ERROR, exception, this);
            }
        }
    }

    /**
     * Method: update. This method updates an array of rows on the database
     * using the primary key of each row.
     * 
     * @param rowsToUpdate
     *                An array of row objects. Each object must have the primary
     *                key populated and at least one other attribute.
     * 
     */
    public void updateRTV(ImGlCrossRefRow[] rowsToUpdate, String oldReasonCode)
            throws ReIMException {
        if (rowsToUpdate.length <= BATCH_UPDATE_ROW_THRESHOLD) {
            int arrayLen = rowsToUpdate.length;
            for (int i = 0; i < arrayLen; i++) {
                this.update(rowsToUpdate[i]);
            }
            return;
        }
        OraclePreparedStatement stmnt = null;
        String tableQuery = null;
        try {
            Connection conn =
                    TransactionManagerFactory.getInstance().getConnection();
            // NOTE : The population status of the first row will be assumed to
            // be exactly the same
            // as the rest
            // NOTE : Mixing different objects with different fields populated
            // is NOT currently
            // supported.
            if (rowsToUpdate[0].isFullyPopulated()) {
                tableQuery =
                        "UPDATE IM_GL_CROSS_REF SET IM_GL_CROSS_REF.SEGMENT_VALUE = ?,IM_GL_CROSS_REF.ACCOUNT_CODE = ? WHERE IM_GL_CROSS_REF.ACCOUNT_TYPE = ? AND IM_GL_CROSS_REF.ACCOUNT_CODE = ? AND IM_GL_CROSS_REF.SEGMENT_NO = ?";
                stmnt =
                        (OraclePreparedStatement) conn
                                .prepareStatement(tableQuery);
                int arrayLen = rowsToUpdate.length;
                int nbrLoops = 0;
                boolean arrayGreater = false;
                for (int i = 0; i < arrayLen; i++) {
                    int record = 0;
                    if (arrayGreater) {
                        stmnt.executeBatch();
                        stmnt.close();
                        i = 0;
                        arrayLen -= ARRAY_PROCESS_SIZE;
                        arrayGreater = false;
                        stmnt =
                                (OraclePreparedStatement) conn
                                        .prepareStatement(tableQuery);
                    }
                    if (arrayLen > ARRAY_PROCESS_SIZE) {
                        arrayGreater = true;
                        for (int x = 0; x < ARRAY_PROCESS_SIZE; x++) {
                            record = x + (nbrLoops * ARRAY_PROCESS_SIZE);
                            stmnt.setString(1, rowsToUpdate[record]
                                    .getSegmentValue());
                            stmnt.setString(2, rowsToUpdate[record]
                                    .getAccountCode());
                            stmnt.setString(3, rowsToUpdate[record]
                                    .getAccountType());
                            stmnt.setString(4, oldReasonCode);
                            stmnt
                                    .setInt(5, rowsToUpdate[record]
                                            .getSegmentNo());
                            stmnt.addBatch();
                        }
                        nbrLoops += 1;
                    } else {
                        record = i + (nbrLoops * ARRAY_PROCESS_SIZE);
                        stmnt.setString(1, rowsToUpdate[record]
                                .getSegmentValue());
                        stmnt.setString(2, rowsToUpdate[record]
                                .getAccountCode());
                        stmnt.setString(3, rowsToUpdate[record]
                                .getAccountType());
                        stmnt.setString(4, oldReasonCode);
                        stmnt.setInt(5, rowsToUpdate[record].getSegmentNo());
                        stmnt.addBatch();
                    }
                }
            } else {
                StringBuffer sqlText =
                        new StringBuffer("UPDATE IM_GL_CROSS_REF SET ");
                String comma = "";
                if (rowsToUpdate[0].segmentValueIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_GL_CROSS_REF.SEGMENT_VALUE=?");
                    comma = ",";
                }
                sqlText
                        .append(" ,IM_GL_CROSS_REF.ACCOUNT_CODE = ? WHERE IM_GL_CROSS_REF.ACCOUNT_TYPE = ? AND IM_GL_CROSS_REF.ACCOUNT_CODE = ? AND IM_GL_CROSS_REF.SEGMENT_NO = ?");
                tableQuery = sqlText.toString();
                stmnt =
                        (OraclePreparedStatement) conn
                                .prepareStatement(tableQuery);
                int arrayLen = rowsToUpdate.length;
                int idx;
                int nbrLoops = 0;
                boolean arrayGreater = false;
                for (int i = 0; i < arrayLen; i++) {
                    int record = 0;
                    if (arrayGreater) {
                        stmnt.executeBatch();
                        stmnt.close();
                        i = 0;
                        arrayLen -= ARRAY_PROCESS_SIZE;
                        arrayGreater = false;
                        stmnt =
                                (OraclePreparedStatement) conn
                                        .prepareStatement(tableQuery);
                    }
                    if (arrayLen > ARRAY_PROCESS_SIZE) {
                        arrayGreater = true;
                        for (int x = 0; x < ARRAY_PROCESS_SIZE; x++) {
                            idx = 1;
                            record = x + (nbrLoops * ARRAY_PROCESS_SIZE);
                            if (rowsToUpdate[record].segmentValueIsPopulated()) {
                                stmnt.setString(idx++, rowsToUpdate[record]
                                        .getSegmentValue());
                            }
                            stmnt.setString(idx++, rowsToUpdate[record]
                                    .getAccountCode());
                            stmnt.setString(idx++, rowsToUpdate[record]
                                    .getAccountType());
                            stmnt.setString(idx++, oldReasonCode);
                            stmnt.setInt(idx++, rowsToUpdate[record]
                                    .getSegmentNo());
                            stmnt.addBatch();
                        }
                        nbrLoops += 1;
                    } else {
                        idx = 1;
                        record = i + (nbrLoops * ARRAY_PROCESS_SIZE);
                        if (rowsToUpdate[record].segmentValueIsPopulated()) {
                            stmnt.setString(idx++, rowsToUpdate[record]
                                    .getSegmentValue());
                        }
                        stmnt.setString(idx++, rowsToUpdate[record]
                                .getAccountCode());
                        stmnt.setString(idx++, rowsToUpdate[record]
                                .getAccountType());
                        stmnt.setString(idx++, oldReasonCode);
                        stmnt
                                .setInt(idx++, rowsToUpdate[record]
                                        .getSegmentNo());
                        stmnt.addBatch();
                    }
                }
            }
            stmnt.executeBatch();
        }

        catch (SQLException ex) {
            String exMsg =
                    "(unable to determine which batch row caused the error)";
            throw new ReIMException("DALGen.cannot_perform_update",
                    Severity.ERROR, ex, this, new String[] { tableQuery,
                            exMsg });
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException(
                        "DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    private static final String DELETE =
            "DELETE FROM IM_GL_CROSS_REF WHERE ACCOUNT_CODE = ?";

    public void delete(String accountCode) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn =
                    TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(DELETE);
            stmt.setString(1, accountCode);
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.im_gl_cross_ref_ext.delete",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.im_gl_cross_ref_ext.delete",
                        Severity.ERROR, exception, this);
            }
        }
    }

    public int getSegmentTextMaxByteLength() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            int segmentByteLength = 0;
            Connection conn =
                    TransactionManagerFactory.getInstance().getConnection();
            // OLR V1.2 Inserted - Start
            // stmt = (OraclePreparedStatement) conn
            //        .prepareStatement("SELECT MAX(SEGMENT_VALUE) FROM IM_GL_CROSS_REF ");
            stmt =  (OraclePreparedStatement) conn
                            .prepareStatement("SELECT SEGMENT_VALUE FROM IM_GL_CROSS_REF where rownum = 1 and SEGMENT_VALUE is not null");
           // OLR V1.2 Inserted - End
            
            rs = stmt.executeQuery();
            if (rs.next()) {
                segmentByteLength = (rs.getMetaData().getColumnDisplaySize(1));
            }
            return segmentByteLength;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR,
                        exception, this);
            }
        }
    }

    public Map getDistinctSobIds() throws ReIMException {
        return getSetOfBookIdentifiers(null);
    }

    
    public Map getSobValues(String id) throws ReIMException {
        return getSetOfBookIdentifiers(Long.valueOf(id));
    }

    public Long getSOB(final String location) throws ReIMException {
        Long sobId = (Long) (new JdbcSupport() {
            protected Object doPerform() throws ReIMException, SQLException {
                JdbcStatement stmnt = prepareStatement(SELECT_SET_OF_BOOKS_ID_BY_LOCATION);
                stmnt.getActualStatement().setLong(1, Long.parseLong(location));
                ResultSet rs1 = stmnt.executeQuery();
                if (rs1.next() && rs1.getLong(1) != 0) {
                    return new Long(rs1.getLong(1));
                } else {
                    return null;
                }
            }
        }.executeQuery());

        return sobId;
    }
    
    protected Map getSetOfBookIdentifiers(final Long sobId) throws ReIMException {
    	//final Map setOfBooksId = new HashMap();
        Map setOfBooksId = (Map) (new JdbcSupport() {
            protected Object doPerform() throws ReIMException, SQLException {
                Map setOfBooksId = new HashMap();
                String sql = SELECT_DISTINCT_SOB;
                
                sql+=" WHERE SET_OF_BOOKS_ID = nvl(?,SET_OF_BOOKS_ID) ";
                JdbcStatement stmt = prepareStatement(sql);
                stmt.getActualStatement().setObject(1, sobId);
                String sobID;
                String desc;
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                	sobID = rs.getString("SET_OF_BOOKS_ID");
                	desc =  rs.getString("SET_OF_BOOKS_DESC");
                	setOfBooksId.put(sobID, desc);
                    
                    
                }
                return setOfBooksId;
            }
        }.executeQuery());
        
         return setOfBooksId;
    }
    
    public ImGlCrossRefRow[] getGlCrossRefByAccTypeAndAccCode(String accountType,String accountCode) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer("ACCOUNT_TYPE = ?");
            whereClause.append(" AND ACCOUNT_CODE = ?");

            DALGenPreparedSQLFragment stmnt =
                    new DALGenPreparedSQLFragment(whereClause.toString());

            // This MUST order by seg number or all account will be off!!
            String orderBy = "SEGMENT_NO";

            stmnt.setString(1, accountType);
            stmnt.setString(2, accountCode);

            return super.read(stmnt, null, null, orderBy);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException(
                    "ImGlCrossRefAccessExt.getAllByAccTypeAndAccCode",
                    Severity.ERROR, e, this);
        }
    }

}
