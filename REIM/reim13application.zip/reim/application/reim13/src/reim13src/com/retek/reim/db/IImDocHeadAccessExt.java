package com.retek.reim.db;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import oracle.retail.reim.business.MatchLevel;
import oracle.retail.reim.business.document.DocId;

import com.retek.reim.business.ByteLengths;
import com.retek.reim.business.CreditNoteSummaryMatchSearchCriteria;
import com.retek.reim.business.SummaryMatchSearchCriteria;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.ResolutionDocument;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.ui.invoiceMaintenance.DocumentSearchCriteria;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		21-May-2013	BNaik		BRN EDI Invoices should not be allowed to be edited.
 *     If any of the items are either matched or discrepancy routed(DETAIL_MATCHED='Y'), then the invoice will be in VIEW mode 
 * 		and cannot be edited. If not, the items can be edited in ready-for-match, unresolved match, and multi-unresolved invoices, and tax discrepancy status.
 * 										
 */

public interface IImDocHeadAccessExt {
    public String getDocumentIdFromExternalId(String externalId, String type) throws ReIMException;

    public String getDocumentIdFromExternalId(String vendor, String externalId, String type)
            throws ReIMException;

    public String documentExists(String extDocId) throws ReIMException;

    public HashMap getCreditNotesGroupedBySupplier(
            CreditNoteSummaryMatchSearchCriteria searchCriteria) throws ReIMException;

    public HashMap getCreditNoteRequestsGroupedBySupplier(
            CreditNoteSummaryMatchSearchCriteria searchCriteria) throws ReIMException;

    public void updateResolutionDocHeadForMatching(ResolutionDocument[] resolutionDocs,
            String userId) throws ReIMException;

    public Document read(long docId) throws ReIMException;

    public void update(ImDocHeadRow[] rowsToUpdate) throws ReIMException;

    public void update(ImDocHeadRow rowToUpdate) throws ReIMException;

    public boolean docHeadExist(String vendor, String extDocId, String docType)
            throws ReIMException;

    public void create(ImDocHeadRow newRow) throws ReIMException;

    public void create(ImDocHeadRow[] newRows) throws ReIMException;

    public Double readResolutionAdjustedTotalCost(long docId) throws ReIMException;

    public long createDebitMemoHeaderFromLateCreditNoteRequest(String docType, String userId,
            long existingDocId, String extDocId) throws ReIMException;

    public Document[] populateDocumentsList(DocumentSearchCriteria searchCriteria,
            boolean isSupplierSearch) throws ReIMException;

    public ImDocHeadRow read(long docId, boolean noRowsFoundIsError) throws ReIMException;

    public void createUsingProvidedDocId(ImDocHeadRow[] newRows) throws ReIMException;

    public HashMap getInvoicesForMatching(SummaryMatchSearchCriteria searchCriteria)
            throws ReIMException;

    public Document getMerchandiseDocHeadWithTax(long docId) throws ReIMException;

    public Map getResolutionDocsWithNonMerchAmount(Collection docIds) throws ReIMException;

    public ByteLengths getDocumentMaxByteLengths() throws ReIMException;

    public boolean isRefDocPopulated(String docId) throws ReIMException;

    public Map<DocId, Document> readDocumentsForRollup();

    public String getDocumentStatusByExtDocId(String extDocId) throws ReIMException;
    
    // BRN OLR V1.1 Start - added
    public String getDetailMatchedByDocId(String docId) throws ReIMException;
    // BRN OLR V1.1 End
    public String getDocumentStatusFromExternalIdAndVendor(String extDocId, String vendorId)
            throws ReIMException;
    
    public String[] readDocumentsAssociatedWithMatch(Long processId, Long configId, Long supplier, MatchLevel matchLevel) 
    		throws ReIMException; 
    
    public void updateStatusByDocIdForDetailsMatched(long docId, String userId) throws ReIMException ;

}