package com.retek.reim.foundation;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.Location;
import com.retek.reim.business.Order;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;

/**
 * 
 * This class gets all the invoices that are candidate for matching.
 */
public abstract class AAutoMatchDrivingQueryBean {
    private static final String DRIVING_QUERY_SELECT_CLAUSE = " SELECT  /*+ INDEX(DH IM_DOC_HEAD_I10) INDEX(OH PK_ORDHEAD) */ "
            + " DH.ORDER_NO, DH.LOCATION, DH.LOC_TYPE, OH.SUPPLIER, DH.VENDOR, DH.VENDOR_TYPE, "
            + "DH.DOC_ID, DH.EXT_DOC_ID, DH.TERMS_DSCNT_PCT, DH.DOC_DATE, "
            + "DH.TOTAL_COST, DH.TOTAL_QTY, DH.RESOLUTION_ADJUSTED_TOTAL_COST, "
            + "DH.RESOLUTION_ADJUSTED_TOTAL_QTY, DH.DUE_DATE, DH.STATUS,  "
            + "OH.CURRENCY_CODE ORDER_CURRENCY_CODE, DH.CURRENCY_CODE INVOICE_CURRENCY_CODE, "
            + "OH.EXCHANGE_RATE, OH.WRITTEN_DATE, DH.COST_PRE_MATCH, DH.PRE_PAID_IND, DH.FREIGHT_TYPE, "
            + "DH.MANUALLY_PAID_IND, DH.TOTAL_COST_INC_TAX, DH.TAX_DISC_CREATE_DATE, "
            + "TAXES.tax_code, TAXES.tax_rate, TAXES.basis, TAXES.merch_ind, id.doc_id as DETAIL_EXISTS ";

    // May want to exclude the hit to the TAX tables for clients that don't use tax
    private static final String DRIVING_QUERY_FROM_CLAUSE = " FROM IM_DOC_HEAD DH, ORDHEAD OH, "
            + " (SELECT "
            + // This Hint may be needed for performance /*+ INDEX(idt IM_DOC_TAX_I1)
            // */
            "	  idt.doc_id, tax_code, tax_rate, tax_basis as basis, 1 as merch_ind "
            + "   FROM IM_DOC_TAX IDT "
            + "      UNION ALL  "
            + "  SELECT "
            + // This Hint may be
            // needed for
            // performance /*+
            // INDEX(idnm
            // IM_DOC_NON_MERCH_I1)
            // */
            "    idnm.doc_id, tax_code, tax_rate, tax_basis as basis, 0 as merch_ind "
            + "   FROM IM_DOC_NON_MERCH_TAX IDNM	) TAXES , "
            + "  (SELECT distinct doc_id from IM_INVOICE_DETAIL) ID ";

    private static final String DRIVING_QUERY_WHERE_CLAUSE = " WHERE DH.ORDER_NO = OH.ORDER_NO "
            + " AND DH.DETAIL_MATCHED = 'N' "
            + " AND DH.HOLD_STATUS != 'H' "
            + " AND DH.TOTAL_COST > 0 AND DH.DOC_ID = TAXES.DOC_ID(+) "
            + " AND DH.DOC_ID = ID.DOC_ID(+) " + " AND     ( (DH.STATUS = '"
            + Document.TAX_DISCREPANCY + "' AND  ID.doc_id is NULL) " + " OR (DH.STATUS = '"
            + Document.READY_FOR_MATCH + "' OR DH.STATUS = '" + Document.UNRESOLVED_MATCH
            + "' OR DH.STATUS = '" + Document.MULTI_UNRESOLVED + "')) AND DH.TYPE = '"
            + Document.MERCHANDISE_INVOICE + "'" + " AND NOT EXISTS (SELECT 'X' "
            + "                   FROM IM_MANUAL_GROUP_INVOICES MG "
            + "                  WHERE DH.DOC_ID = MG.INVOICE_ID AND ROWNUM = 1) ";

    private static final String DRIVING_QUERY_ORDER_BY_CLAUSE = " ORDER BY DH.ORDER_NO,DH.LOCATION, DH.DOC_ID ";

    public POLocation[] createPOLocationsForAutoMatchRS(ResultSet rs) throws ReIMException {
        List<MerchandiseDocument> invoices = null;
        MerchandiseDocument[] invoicesArray = null;
        List<POLocation> poLocations = new ArrayList<POLocation>();
        POLocation[] poLocationsArray = null;
        POLocation poLocation = null;
        MerchandiseDocument invoice = null;
        String currentOrder = null;
        String currentLocation = null;
        String currentDocument = null;
        String previousOrder = null;
        String previousLocation = null;
        String previousDocument = null;

        Set<Tax> merchTaxes = null;
        
        try {
            boolean firstTime = true;
            while (rs.next()) {
                currentOrder = rs.getString("ORDER_NO");

                // For RMS 10.0, this needs to be the physical location, not the virtual.
                // Therefore, the location must come from im_doc_head, which always has phyiscal.
                currentLocation = rs.getString("LOCATION");

                if (!currentOrder.equals(previousOrder)
                        || !currentLocation.equals(previousLocation)) {
                    if (!firstTime) {
                        invoicesArray = new MerchandiseDocument[invoices.size()];
                        invoices.toArray(invoicesArray);
                        poLocation.setInvoices(invoicesArray);
                        poLocations.add(poLocation);
                    }

                    poLocation = new POLocation();
                    Location location = new Location();
                    Order order = new Order();

                    // Populate the new PO/Location
                    order.setOrderNo(currentOrder);
                    order.setSupplier(new Supplier());
                    order.getSupplier().setVendorId(rs.getString("SUPPLIER"));
                    order.setOrderCurrency(rs.getString("ORDER_CURRENCY_CODE"));
                    order.setOrderExchangeRate(new Double(rs.getDouble("EXCHANGE_RATE")));
                    order.setWrittenDate(new ReIMDate(rs.getDate("WRITTEN_DATE")));
                    poLocation.setOrder(order);

                    location.setLocationId(currentLocation);
                    location.setLocationType(rs.getString("LOC_TYPE"));
                    poLocation.setLocation(location);

                    invoices = new ArrayList<MerchandiseDocument>();
                }
                currentDocument = rs.getString("DOC_ID");
                // it a new document or the first one...
                if (!currentDocument.equals(previousDocument)) {
                    // new invoice so set the final Taxes
                    if (invoice != null) {
                        invoice.setTaxes(merchTaxes);
                    }

                    // get a New invoice
                    invoice = new MerchandiseDocument();
                    invoice.setDocId(rs.getLong("DOC_ID"));
                    invoice.setType(Document.MERCHANDISE_INVOICE);
                    invoice.setExtDocId(rs.getString("EXT_DOC_ID"));
                    invoice.setVendor(new Supplier(rs.getString("VENDOR")));
                    invoice.setVendorType(rs.getString("VENDOR_TYPE"));
                    invoice.setOrderNo(currentOrder);
                    invoice.setCurrencyCode(rs.getString("INVOICE_CURRENCY_CODE"));
                    invoice.setTermsDscntPct(rs.getDouble("TERMS_DSCNT_PCT"));
                    invoice.setTotalCost(rs.getDouble("TOTAL_COST"));
                    invoice.setTotalQty(rs.getDouble("TOTAL_QTY"));

                    invoice.setExchangeRate(rs.getDouble("EXCHANGE_RATE"));

                    invoice.setResolutionAdjustedTotalCost(rs
                            .getDouble("RESOLUTION_ADJUSTED_TOTAL_COST"));
                    invoice.setResolutionAdjustedTotalQty(rs
                            .getDouble("RESOLUTION_ADJUSTED_TOTAL_QTY"));
                    invoice.setDueDate(new ReIMDate(rs.getDate("DUE_DATE")));
                    invoice.setDocDate(new ReIMDate(rs.getDate("DOC_DATE")));
                    invoice.setCostPreMatched(rs.getString("COST_PRE_MATCH").equals(
                            ReIMConstants.YES) ? true : false);
                    invoice
                            .setPrePaidInd(rs.getString("PRE_PAID_IND").equals(ReIMConstants.YES) ? true
                                    : false);
                    invoice.setStatus(rs.getString("STATUS"));
                    invoice.setFreightType(rs.getString("FREIGHT_TYPE"));
                    invoice.setManuallyPaidInd(rs.getString("MANUALLY_PAID_IND").equals(
                            ReIMConstants.YES) ? true : false);
                    invoice.setTotalCostIncTax(rs.getDouble("TOTAL_COST_INC_TAX"));
                    if (rs.getDate("TAX_DISC_CREATE_DATE") != null) {
                        invoice.setTaxDiscrepancyCreateDate(new ReIMDate(rs
                                .getDate("TAX_DISC_CREATE_DATE")));
                    }
                    if (rs.getString("DETAIL_EXISTS") != null) {
                        invoice.setDetailsExist(true);
                    } else {
                        invoice.setDetailsExist(false);
                    }

                    invoice.getLocation().setLocationId(currentLocation);
                    invoice.setPoLocation(poLocation);

                    merchTaxes = new HashSet<Tax>();
                    String merchInd = rs.getString("merch_ind");
                    if (merchInd != null) {
                        Tax tax = new Tax(rs.getString("tax_code"), rs.getDouble("tax_rate"), rs
                                .getDouble("basis"));

                        if (merchInd.equals("1")) {
                            merchTaxes.add(tax);
                        } else {
                        	if (invoice != null) {
                        		invoice.addNonMerchTax(tax);
                        	}
                        }
                    }
                    invoices.add(invoice);
                } else {
                    String merchInd = rs.getString("merch_ind");
                    if (merchInd != null) {
                        Tax tax = new Tax(rs.getString("tax_code"), rs.getDouble("tax_rate"), rs
                                .getDouble("basis"));

                        if (merchInd.equals("1")) {
                            merchTaxes.add(tax);
                        } else {
                        	if (invoice != null) {
                        		invoice.addNonMerchTax(tax);
                        	}
                        }
                    }
                }

                // loop maintenance
                firstTime = false;
                previousDocument = currentDocument;
                previousOrder = currentOrder;
                previousLocation = currentLocation;
            }

            // handle last invoice
            if (invoice != null) {
                invoice.setTaxes(merchTaxes);
            }

            // handle the last poLocation
            if (invoices != null && invoices.size() > 0) {
                invoicesArray = new MerchandiseDocument[invoices.size()];
                invoices.toArray(invoicesArray);
                poLocation.setInvoices(invoicesArray);
                poLocations.add(poLocation);
            }

            if (poLocations.size() > 0) {
                poLocationsArray = new POLocation[poLocations.size()];
                poLocations.toArray(poLocationsArray);
            }

            return poLocationsArray;
        } catch (Exception e) {
            throw new ReIMException("error.ord_loc_bean.createPOLocationForAutoMatchRS",
                    Severity.ERROR, e, this);
        }
    }

    public String getDrivingQuerySelectClause() {
        return DRIVING_QUERY_SELECT_CLAUSE;
    }

    public String getDrivingQueryFromClause() {
        return DRIVING_QUERY_FROM_CLAUSE;
    }

    public String getDrivingQueryWhereClause() {
        return DRIVING_QUERY_WHERE_CLAUSE;
    }

    public String getDrivingQueryOrderByClause() {
        return DRIVING_QUERY_ORDER_BY_CLAUSE;
    }
}
