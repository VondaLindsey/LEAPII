package com.retek.reim.business;

import com.retek.merch.utils.Quantity;
import com.retek.reim.foundation.AShipmentBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMQuantity;

/**
 * -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		20-Jun-2013	BNaik		Reverting the Oracle Bug 6955602 fix because it allows summary matching on the receipt 
 *    including the quantities of the receipt item that had been already resolved with another invoice.                                           									
 */
public class ReceiptItem implements Cloneable {
    public static final String UNMATCHED = "UNMTCH";
    public static final String MATCHED = "MTCH";

    private Receipt receipt;
    private String receiptId;
    private double unitCost;
    private double qtyReceived;
    private double qtyMatched;
    private double availableToMatchQty;
    private String invoiceMatchStatus;
    private boolean partiallyMatched;
    private Item item;
    private double weightReceived;
    private String weightReceivedUOM;
    private boolean costMatched;

    public ReceiptItem() {

    }

    public ReceiptItem(String itemId) {
        this.item = new Item(itemId);
    }

    public ReceiptItem(String itemId, double unitCost) {
        this.item = new Item(itemId);
        this.unitCost = unitCost;
    }

    public ReceiptItem(String itemId, double unitCost, double availableToMatchQty) {
        this.item = new Item(itemId);
        this.unitCost = unitCost;
        this.availableToMatchQty = availableToMatchQty;
    }

    public ReceiptItem(String itemId, Receipt receipt) {
        this.item = new Item(itemId);
        this.receipt = receipt;
    }

    public String getItemId() {
        return this.getItem().getItemId();
    }
    
    public String getItemVpn() {
        return this.getItem().getVpn();
    }

    public double getAvailableToMatchQty() {
        return availableToMatchQty;
    }

    public double getUnitCost() {
        return unitCost;
    }

    public void setItemId(String itemId) {
        this.getItem().setItemId(itemId);
    }
    
    public void setItemVpn(String itemVpn) {
        this.getItem().setVpn(itemVpn);
    }

    public void setAvailableToMatchQty(double availableToMatchQty) {

    	this.availableToMatchQty = availableToMatchQty;
    		
    		/* BRN V 1.3 Start
    		try {
		    		AShipmentBean bean = (AShipmentBean) ReIMBeanFactory
					 .getBean(ReIMBeanFactory.AShipmentBean);
				
					if(availableToMatchQty<=0 && this.item!=null && this.receiptId!=null && !bean.isCostMatched(Long.parseLong(this.item.getItemId()),Long.parseLong(this.receiptId))){
						this.availableToMatchQty =this.qtyReceived;
					}else{
						this.availableToMatchQty = availableToMatchQty;
					}
			} catch (ReIMException e) {
 			// TODO Auto-generated  block
 			e.printStackTrace();
 			}		
			BRN V 1.3 End  */
	}
    
    public void setAvailableToMatchQty(double availableToMatchQty, boolean fromSummaryUnmatchedReceipts) {
    		this.availableToMatchQty = availableToMatchQty;
	}

    public void setUnitCost(double unitCost) {
        this.unitCost = unitCost;
    }

    public String getReceiptId() {
        if ((null == this.receiptId || this.receiptId.length() <= 0) && null != this.receipt) {
            return this.receipt.getReceiptId();
        } else {
            return this.receiptId;
        }
    }

    public void setReceiptId(String receiptId) {
        this.receiptId = receiptId;
    }

    public String getInvoiceMatchStatus() {
        return invoiceMatchStatus;
    }

    public void setInvoiceMatchStatus(String invoiceMatchStatus) {
        this.invoiceMatchStatus = invoiceMatchStatus;
    }

    public Receipt getReceipt() {
        return receipt;
    }

    public void setReceipt(Receipt receipt) {
        this.receipt = receipt;
    }

    public double getQtyReceived() {
        return qtyReceived;
    }

    public void setQtyReceived(double qtyReceived) {
        this.qtyReceived = qtyReceived;
    }

    public boolean isPartiallyMatched() {
        return partiallyMatched;
    }

    public void setPartiallyMatched(boolean partiallyMatched) {
        this.partiallyMatched = partiallyMatched;
    }

    public Object clone() {
        Object obj = null;

        try {
            obj = super.clone();
        } catch (CloneNotSupportedException cnspe) {
            cnspe.printStackTrace();
        }
        return obj;
    }

    public Item getItem() {
        if (item == null) {
            item = new Item();
        }

        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Quantity getCostForMatching() {
        Quantity unitCost = new ReIMQuantity(getUnitCost());
        return unitCost.multiply(getAvailableToMatchQty());
    }

    public double getQtyMatched() {
        return qtyMatched;
    }

    public void setQtyMatched(double qtyMatched) {
        this.qtyMatched = qtyMatched;
    }

    public double getWeightReceived() {
        return weightReceived;
    }

    public void setWeightReceived(double weightReceived) {
        this.weightReceived = weightReceived;
    }

    public String getWeightReceivedUOM() {
        return weightReceivedUOM;
    }

    public void setWeightReceivedUOM(String weightReceivedUOM) {
        this.weightReceivedUOM = weightReceivedUOM;
    }
    
    /**
	 * @return the costMatched
	 */
	public boolean isCostMatched() {
		return costMatched;
	}

	/**
	 * @param costMatched the costMatched to set
	 */
	public void setCostMatched(boolean costMatched) {
		this.costMatched = costMatched;
	}
	
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		result = prime * result
				+ ((receiptId == null) ? 0 : receiptId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReceiptItem other = (ReceiptItem) obj;
		if (item == null) {
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		if (receiptId == null) {
			if (other.receiptId != null)
				return false;
		} else if (!receiptId.equals(other.receiptId))
			return false;
		return true;
	}
}
