package com.retek.reim.ui.invoiceMatch;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.services.matching.IDetailMatchService;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.beans.factory.annotation.Autowired;

import com.retek.merch.utils.ToleranceContainer;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.UserRole;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ReceiptService;
import com.retek.reim.services.ServiceFactory;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2 	21-Apr-2013	The items in the Detail Matching screen are cached from the previous manual group.
 *    1.3    14-May-2013   After performing the RCA, the Order and Receipt Unit cost was not refreshed in Detail Matching screen.
 */

public class DetailMatchBeginAction extends ReIMSecureAction {

    private IDetailMatchService detailMatchService;
    private IInvoiceDetailService invoiceDetailService;

    protected boolean getPermission() {
        if (ReIMUserContext.getUserRole().getInvoiceMatching().equalsIgnoreCase(UserRole.EDIT)
                || ReIMUserContext.getUserRole().getInvoiceMatching().equalsIgnoreCase(
                        UserRole.VIEW)) {
            return true;
        } else {
            return false;
        }
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        try {
            DetailMatchListForm detailMatchListForm = (DetailMatchListForm) form;
            SummaryMatchListForm summaryMatchListForm = (SummaryMatchListForm) request.getSession()
                    .getAttribute("SummaryMatchListForm");
            if (summaryMatchListForm.getMode().equalsIgnoreCase("EDIT"))
                detailMatchListForm.setMode(DetailMatchListForm.EDIT);
            else if (summaryMatchListForm.getMode().equalsIgnoreCase("E"))
                detailMatchListForm.setMode(summaryMatchListForm.getMode());

            if (summaryMatchListForm.getMode().equalsIgnoreCase("VIEW"))
                detailMatchListForm.setMode(DetailMatchListForm.VIEW);
            else if (summaryMatchListForm.getMode().equalsIgnoreCase("V"))
                detailMatchListForm.setMode(summaryMatchListForm.getMode());
            detailMatchListForm.setSupplierId(summaryMatchListForm.getSupplierId());
            detailMatchListForm.setSupplierName(summaryMatchListForm.getSupplierName());
            checkForViewAccessOnly(request, errors, detailMatchListForm);

            // Set the user role for invoices on the form.
            UserRole userRole = ReIMUserContext.getUserRole();
            if (userRole.getDocumentEntry().equalsIgnoreCase(ReIMConstants.NO)) {
                detailMatchListForm.setInvoiceEditPermissions(ReIMConstants.NO);
            }

            ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
            detailMatchListForm.setItemVPNLookupAllowed(systemOptions.isVpnItemLookup());

            Map unmatchedReceiptMap = summaryMatchListForm.getSelectedGroupReceiptMap();
            Map unmatchedInvoiceMap = summaryMatchListForm.getSelectedGroupInvoiceMap();
            // Set the currency code on the form
            String currencyCode = "";
            if (unmatchedInvoiceMap.size() > 0) {
                List invoices = new ArrayList(unmatchedInvoiceMap.values());
                MerchandiseDocument invoice = (MerchandiseDocument) invoices.get(0);
                currencyCode = invoice.getCurrencyCode();
            } else if (unmatchedReceiptMap.size() > 0) {
                List receipts = new ArrayList(unmatchedReceiptMap.values());
                Receipt receipt = (Receipt) receipts.get(0);
                currencyCode = ServiceFactory.getCurrencyService().getCurrencyCodeByOrderNo(
                        new Long(receipt.getOrderId()).longValue());
            } else {
                ReIMException newEx = new ReIMException(
                        "error.detail_match_begin_action.do_perform", Severity.ERROR,
                        new Exception(ReIMConstants.EMPTY_STRING), this);
                saveErrors(request, errors, newEx);
                return mapping.findForward("failure");
            }
            detailMatchListForm.setCurrencyCode(currencyCode);
            Collection invoices = unmatchedInvoiceMap.values();
            Iterator iterator = invoices.iterator();
            // Clear the invoice detail and rebuild because summary match
            // doesn't populate the details

            if ("false".equalsIgnoreCase((String) request.getSession().getAttribute(
                    "fromSummaryMatchScreen"))) {
                // Already have the information. Don't need to access it from
                // the database.
                detailMatchListForm = (DetailMatchListForm) request.getSession().getAttribute(
                        "DetailMatchListForm");
                // INVOICES
                DetailMatchItemsView[] discrepancyItemsList = detailMatchListForm
                        .getDiscrepancyItemsList();
                DetailMatchInvoiceView[] invoiceItemGroupList = detailMatchListForm
                        .getInvoiceItemGroupList();
                ArrayList tempInvoiceItemsArray = new ArrayList();
                DocumentItemInvoice[] invoiceItems = null;
                boolean isMatched = false;

                for (int i = 0; i < invoiceItemGroupList.length; i++) {
                    DetailMatchInvoiceView invoiceItem = invoiceItemGroupList[i];
                    isMatched = getInvoiceDetailService().isInvoiceLineMatched(invoiceItem);
                    // read invoice-item data from db .. details have changed
                    if (!isMatched) {
                        DocumentItemInvoice itemInvoice = getInvoiceDetailService()
                                .buildInvoiceLine(invoiceItem.getDocumentItem());
                        // BRN V1.3 Begin - removed
                        //	itemInvoice.setOrderUnitCost(invoiceItem.getDocumentItem()
                        //          .getOrderUnitCost());
                        // BRN V1.3 End
                        tempInvoiceItemsArray.add(itemInvoice);
                    }
                }
                detailMatchListForm.setInvoiceItemGroupList(new DetailMatchInvoiceView[0]);
                invoiceItems = (DocumentItemInvoice[]) tempInvoiceItemsArray
                        .toArray(new DocumentItemInvoice[tempInvoiceItemsArray.size()]);

                // RECEIPTS
                DetailMatchReceiptView[] receiptItemGroupList = detailMatchListForm
                        .getReceiptItemGroupList();

                ArrayList tempReceiptArray = new ArrayList();
                ReceiptItem[] receiptItems = null;
                ReceiptItem receiptItem = null;

                // BRN V1.3 Begin if item in the invoice was matched, the items in the receipt were not refreshed.
                // if (!isMatched) {
                    for (int i = 0; i < receiptItemGroupList.length; i++) {
                        // read receipt-item data from db .. details have
                        // changed
                        DetailMatchReceiptView receiptView = receiptItemGroupList[i];
                        receiptItem = ReceiptService.buildReceiptItem(receiptView.getReceiptItem().getReceipt(),
                                receiptView.getItemId());
                        
                        if (receiptItem != null)
                        	tempReceiptArray.add(receiptItem);
                    }

                    if (tempReceiptArray.size() > 0){
                    	receiptItems = (ReceiptItem[]) tempReceiptArray
                                .toArray(new ReceiptItem[tempReceiptArray.size()]);                    	
                    }
                    
                // }
                 // BRN V1.3 End    

                detailMatchListForm.setReceiptItemGroupList(new DetailMatchReceiptView[0]);
                Collection receipts = unmatchedReceiptMap.values();
                getDetailMatchService().validateResolvable(invoices, receipts);
                Map discrepancyItems = getDetailMatchService().rebuildDetailViews(
                        discrepancyItemsList, invoiceItems, receiptItems,
                        detailMatchListForm.getCurrencyCode(), detailMatchListForm);
                discrepancyItemsList = (DetailMatchItemsView[]) discrepancyItems.values().toArray(
                        new DetailMatchItemsView[discrepancyItems.size()]);
                detailMatchListForm.setDiscrepancyItemsList(discrepancyItemsList);

            } else {
                detailMatchListForm.setTolContainer(new ToleranceContainer());
                for (int i = 0; i < invoices.size(); i++) {
                    MerchandiseDocument invoice = (MerchandiseDocument) iterator.next();
                    invoice.setDocDetail(null);
                    getInvoiceDetailService().buildInvoiceLines(invoice);
                }

                Collection receipts = unmatchedReceiptMap.values();
                iterator = receipts.iterator();
                // Set the partially matched flag
                for (int i = 0; i < receipts.size(); i++) {
                    Receipt receipt = (Receipt) iterator.next();
                    receipt.setReceiptItems(null);
                    ReceiptService.buildReceiptItems(receipt);
                }

                getDetailMatchService().validateResolvable(invoices, receipts);

                // Call the service
                List list = getDetailMatchService()
                        .buildDetailViewsFromSummaryGroup(unmatchedInvoiceMap, unmatchedReceiptMap,
                                currencyCode, detailMatchListForm);
                HashMap tempMap = (HashMap) list.get(0);
                detailMatchListForm.setInBalanceItemsList((DetailMatchItemsView[]) tempMap.values()
                        .toArray(new DetailMatchItemsView[tempMap.values().size()]));
                tempMap = (HashMap) list.get(1);
                detailMatchListForm.setDiscrepancyItemsList((DetailMatchItemsView[]) tempMap
                        .values().toArray(new DetailMatchItemsView[tempMap.values().size()]));
            }
            // initialize the item grouping (bottom half of the screen)
            detailMatchListForm.resetItemGroupings();
            //  BRN Caching OLR V1.2  --  Begin
            // request.getSession().setAttribute("fromSummaryMatchScreen", "false");
            //  BRN Caching OLR V1.2  --  End
            return mapping.findForward("success");
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return mapping.findForward("failure");
        } catch (Exception e) {
            ReIMException newEx = new ReIMException("error.detail_match_begin_action.do_perform",
                    Severity.ERROR, e, this);
            saveErrors(request, errors, newEx);
            return mapping.findForward("failure");
        }
    }

    private void checkForViewAccessOnly(HttpServletRequest request, ActionErrors errors,
            DetailMatchListForm detailMatchListForm) {
        if (detailMatchListForm.getMode().equals(DetailMatchListForm.VIEW)) {
            errors.add("alert.screen_view_only_permission", new ActionError(
                    "alert.screen_view_only_permission", ReIMUserContext.getUsername()));
            saveErrors(request, errors);
        }
    }

    public IDetailMatchService getDetailMatchService() {
        return detailMatchService;
    }

    public void setDetailMatchService(IDetailMatchService detailMatchService) {
        this.detailMatchService = detailMatchService;
    }
    
    public IInvoiceDetailService getInvoiceDetailService() {
        return invoiceDetailService;
    }

    @Autowired
    public void setInvoiceDetailService(IInvoiceDetailService invoiceDetailService) {
        this.invoiceDetailService = invoiceDetailService;
    }
}
