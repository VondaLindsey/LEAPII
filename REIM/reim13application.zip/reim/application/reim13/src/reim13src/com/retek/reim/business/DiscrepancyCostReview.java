package com.retek.reim.business;

import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.services.ServiceFactory;

public class DiscrepancyCostReview {
    protected long docId;
    protected String externalDocId;
	protected String documentType;
    protected String documentTypeDesc;
    protected String department;
    protected String classId;
    protected String supplier;
    protected String supplierName;
    protected ReIMDate resolveByDate;
    protected String cashDiscount;
    protected ReIMDate routeDate;
    protected String reviewerGroup;
    protected String reviewerGroupName;
    protected String orderId;
    protected Location location;    
    protected String noOfLineExceptions;
    protected double totalDocumentAmount;
    protected String currency;
    protected String apReviewer;

    public DiscrepancyCostReview(long docId, String docType, String department, String classId,
            String supplier, ReIMDate resolveByDate, String cashDiscount, ReIMDate routeDate,
            String reviewerGroup, String orderId, Location location, String externalDocId, String noOfLineExceptions,
            double totalDocumentAmount, String currency, String apReviewer) {
        this.docId = docId;
        this.externalDocId = externalDocId;
        this.documentType = docType;
        this.department = department;
        this.classId = classId;
        this.supplier = supplier;
        this.resolveByDate = resolveByDate;
        this.cashDiscount = cashDiscount;
        this.routeDate = routeDate;
        this.reviewerGroup = reviewerGroup;
        this.orderId = orderId;
        this.location = location;
        this.noOfLineExceptions = noOfLineExceptions;
        this.totalDocumentAmount = totalDocumentAmount;
        this.currency = currency;
        this.apReviewer = apReviewer;
    }

    // Object Methods
    public String getDocumentTypeDesc() {
        return ServiceFactory.getDocumentService().getDocumentTypeDescription(documentType);
    }

    // Getter Methods
    public String getApReviewer() {
        return apReviewer;
    }

    public String getCashDiscount() {
        return cashDiscount;
    }

    public String getClassId() {
        return classId;
    }

    public String getCurrency() {
        return currency;
    }

    public String getDepartment() {
        return department;
    }

    public long getDocId() {
        return docId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public Location getLocation() {
        return location;
    }

    public String getNoOfLineExceptions() {
        return noOfLineExceptions;
    }

    public String getOrderId() {
        return orderId;
    }

    public ReIMDate getResolveByDate() {
        return resolveByDate;
    }

    public String getReviewerGroup() {
        return reviewerGroup;
    }

    public String getReviewerGroupName() {
        return reviewerGroupName;
    }

    public ReIMDate getRouteDate() {
        return routeDate;
    }

    public String getSupplier() {
        return supplier;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public double getTotalDocumentAmount() {
        return totalDocumentAmount;
    }

    // Setter Methods
    public void setApReviewer(String apReviewer) {
        this.apReviewer = apReviewer;
    }

    public void setCashDiscount(String cashDiscount) {
        this.cashDiscount = cashDiscount;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setDocId(long docId) {
        this.docId = docId;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void setDocumentTypeDesc(String documentTypeDesc) {
        this.documentTypeDesc = documentTypeDesc;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public void setNoOfLineExceptions(String noOfLineExceptions) {
        this.noOfLineExceptions = noOfLineExceptions;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public void setResolveByDate(ReIMDate resolveByDate) {
        this.resolveByDate = resolveByDate;
    }

    public void setReviewerGroup(String reviewerGroup) {
        this.reviewerGroup = reviewerGroup;
    }

    public void setReviewerGroupName(String reviewerGroupName) {
        this.reviewerGroupName = reviewerGroupName;
    }

    public void setRouteDate(ReIMDate routeDate) {
        this.routeDate = routeDate;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setTotalDocumentAmount(double totalDocumentAmount) {
        this.totalDocumentAmount = totalDocumentAmount;
    }
    
    public String getExternalDocId() {
		return externalDocId;
	}

	public void setExternalDocId(String externalDocId) {
		this.externalDocId = externalDocId;
	}
}
