package com.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;
import com.retek.reim.ui.lov.BusinessRoleLOV;
import com.retek.reim.ui.userRoleMaintenance.UserRoleMaintenanceForm;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		13-May-2013	Syed Qadri		Modification Change :Commented out the SELECT statement to use the new one. IMS Ticket # 160668 (Release 1549). This is for 
 * 		                                                         performance enhancement according Metalink Doc id 847827 applied Bug fix 8507757.
 * 										
 */

public class ImBusinessRolesAccessExt extends ImBusinessRolesAccess implements
        IImBusinessRolesAccessExt {
    public boolean checkBusinessRoleNameExists(String name) throws ReIMException {
        DALGenPreparedSQLFragment sql = new DALGenPreparedSQLFragment("upper("
                + businessRoleNameColumn + ")= upper(?)");
        sql.setString(1, name);
        if (read(sql, null, null, null) == null)
            return false;
        else
            return true;
    }

    /**
     * Used to populate an LOV with Business Roles with Cost or Quantity Review permissions set to
     * 'E'dit
     * 
     * @param reviewType:
     *            must be either "C"ost, or "Q"uantity
     * @param id:
     *            is a nullable parameter that can be passed to search by a specific business role
     *            id
     * @param reviewerGroup:
     *            a nullable parameter that is used in the cost and quantity discrepancy screens for
     *            re-routing to not show the current user's group.
     * @return BusinessRoleLOV[]
     */
    public BusinessRoleLOV[] selectDiscrepanciesReviewers(String reviewType, String id,
            String reviewerGroup) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            if (reviewType == null || reviewType.equals(ReIMConstants.EMPTY_STRING)) { throw new ReIMException(
                    "error.review_type_null", Severity.ERROR, this); }

            StringBuffer sql = new StringBuffer();
            sql.append("SELECT BUSINESS_ROLE_NAME,BUSINESS_ROLE_ID FROM IM_BUSINESS_ROLES ");
            // Check review type for C=cost discrepancy review or Q=quantity
            // discrepancy review
            if (reviewType.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)) {
                sql.append(" WHERE COST_DISCREPANCY = '");
                // Keep the search value the same as the jsp list value
                sql.append(UserRoleMaintenanceForm.EDIT);
                sql.append("' ");
            } else if (reviewType.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR)) {
                sql.append(" WHERE QTY_DISCREPANCY = '");
                // Keep the search value the same as the jsp list value
                sql.append(UserRoleMaintenanceForm.EDIT);
                sql.append("' ");
            }
            if (id != null) {
                sql.append(" AND BUSINESS_ROLE_ID = ?");
            }
            if (reviewerGroup != null && !reviewerGroup.equals(ReIMConstants.EMPTY_STRING)) {
                sql.append(" AND BUSINESS_ROLE_ID != ?");
            }
            sql.append(" ORDER BY BUSINESS_ROLE_NAME ");
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            if (id != null) {
                id.trim();
                stmt.setLong(1, Long.parseLong(id));
            }
            if (id != null
                    && (reviewerGroup != null && !reviewerGroup.equals(ReIMConstants.EMPTY_STRING))) {
                reviewerGroup.trim();
                stmt.setLong(2, Long.parseLong(reviewerGroup));
            } else if (id == null
                    && (reviewerGroup != null && !reviewerGroup.equals(ReIMConstants.EMPTY_STRING))) {
                reviewerGroup.trim();
                stmt.setLong(1, Long.parseLong(reviewerGroup));
            }
            rs = stmt.executeQuery();
            ArrayList roleIdList = new ArrayList();
            BusinessRoleLOV roleLOV = null;
            String roleId = null;
            String roleDesc = null;
            while (rs.next()) {
                roleId = rs.getString("BUSINESS_ROLE_ID");
                roleDesc = rs.getString("BUSINESS_ROLE_NAME");
                roleLOV = new BusinessRoleLOV(roleId, roleDesc);
                roleIdList.add(roleLOV);
            }
            if (roleIdList.size() > 0) {
                return (BusinessRoleLOV[]) roleIdList
                        .toArray(new BusinessRoleLOV[roleIdList.size()]);
            } else {
                return null;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_retrieve_business_roles", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_retrieve_business_roles",
                        Severity.ERROR, exception, this);
            }
        }
    }

    public int getBusRoleNameMaxByteLengths() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            int roleNameSize = 0;
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            
            // OLR V1.2 Inserted - Begin             
            // stmt = (OraclePreparedStatement) conn
            //			.prepareStatement("SELECT MAX(BUSINESS_ROLE_NAME) FROM IM_BUSINESS_ROLES ");
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT BUSINESS_ROLE_NAME FROM IM_BUSINESS_ROLES where rownum = 1 and BUSINESS_ROLE_NAME is not null ");
            // OLR V1.2 Inserted - End

            rs = stmt.executeQuery();
            if (rs.next()) {
                roleNameSize = (rs.getMetaData().getColumnDisplaySize(1));
            }
            return roleNameSize;

        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }
}
