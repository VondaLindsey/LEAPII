package com.retek.reim.services;

import java.util.List;
import java.util.Set;

import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.dao.IEdiRejectDocumentDao;
import oracle.retail.reim.data.dao.IEdiRejectDocumentDetailAllowDao;
import oracle.retail.reim.data.dao.IEdiRejectDocumentDetailDao;
import oracle.retail.reim.data.dao.IEdiRejectDocumentNonMerchDao;

import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.business.EdiDocumentValidationValues;
import com.retek.reim.business.EdiRejectDocument;
import com.retek.reim.business.EdiRejectDocumentDetail;
import com.retek.reim.business.Item;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.ui.ediRejectDocList.EdiRejectDocumentDisplay;
import com.retek.reim.ui.lov.ItemLOV;
import com.retek.reim.ui.lov.OrderLOV;
import com.retek.reim.ui.lov.SupplierLOV;

/**
 * @See oracle.retail.reim.services.IEdiRejectService
 */
@Deprecated
public interface IEdiRejectService {
    public EdiRejectDocumentDetail[] getEdiRejectDocumentDetails(String docId, String currencyCode)
            throws ReIMException;

    public EdiRejectDocumentDisplay[] getEdiRejectDocuments() throws ReIMException;

    public SupplierLOV[] selectSuppliers() throws ReIMException;

    public SupplierLOV[] selectSupplier(String supplierId) throws ReIMException;

    public ItemLOV[] selectItems(String supplierId) throws ReIMException;

    public ItemLOV[] selectItem(String supplierId, String itemId) throws ReIMException;

    public OrderLOV[] selectOrders(String supplierId) throws ReIMException;

    public OrderLOV[] selectOrder(String supplierId, String orderNo) throws ReIMException;

    public String lockEdiRejectDoc(long docId, String userId) throws ReIMException;

    public String getDocLockUserId(long docId) throws ReIMException;

    public void releaseEdiRejectDocLock(long docId) throws ReIMException;

    public EdiDocumentValidationValues replaceElementAndRevalidate(String supplierId,
            String replaceType, String oldValue, String newValue, String newItemSupplement,
            String userId) throws ReIMException;

    public List<EdiTransactionHeader> buildEdiDocumentsFromRejected(String[] documentIdList)
            throws ReIMException;

    public EdiDocumentValidationValues revalidate(String documentId, String extDocId,
            String docDate, String locationType, String locationId, String orderNo, String termId,
            String supplierId, Long docDetailId, Item item, boolean headerLevelError,
            String errorColumnId, String rejectReason, boolean allowDateBeforePostDatedDocDays)
            throws ReIMException;

    // public void updateRejectHead(long docId, String extDocId, ReIMDate docDate,
    // String locationType, String locationId, String orderNo, String termId,
    // String supplierId, String errorColumnId, String rejectReason) throws ReIMException;

    public void updateRejectDetail(long docId, Long docDetailId, Item item, String errorColumnId,
            Set<Tax> detailTaxes) throws ReIMException;

    public boolean isInvoiceDateWithinRange(String invoiceDate) throws ReIMException;

    public void insertForEdiRejectDocuments(EdiRejectDocument ediRejectDocument)
            throws ReIMException;

    public void updateForEdiRejectDocHeadAndDocDetail(EdiRejectDocument ediRejectDocument)
            throws ReIMException;

    public void deleteRejects(String[] docIds) throws ReIMException;

    public boolean massDeleteRejects(String orderNo, String userId) throws ReIMException;

    public void setEdiRejectService(oracle.retail.reim.services.IEdiRejectService ediRejectService);

    public void setEdiRejectDocumentDao(IEdiRejectDocumentDao ediRejectDocumentDao);

    public void setEdiRejectDocumentDetailAllowDao(
            IEdiRejectDocumentDetailAllowDao ediRejectDocumentDetailAllowDao);

    public void setEdiRejectDocumentDetailDao(IEdiRejectDocumentDetailDao ediRejectDocumentDetailDao);

    public void setEdiRejectDocumentNonMerchDao(
            IEdiRejectDocumentNonMerchDao ediRejectDocumentNonMerchDao);
    
    public oracle.retail.reim.services.IEdiRejectService getEdiRejectService();

}