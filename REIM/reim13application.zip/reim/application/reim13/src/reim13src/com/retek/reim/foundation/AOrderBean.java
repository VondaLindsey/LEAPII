package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.business.ExchangeType;
import oracle.retail.reim.business.RtvStatusInd;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.StringUtils;

import com.retek.reim.business.CurrencyRate;
import com.retek.reim.business.DiscrepancyCostReviewDetail;
import com.retek.reim.business.DiscrepancyQuantityReviewDetail;
import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.Order;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.document.OrderInvoiceTerms;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.db.ImCostDiscrepancyRow;
import com.retek.reim.db.ImDocHeadAccess;
import com.retek.reim.db.ImQtyDiscrepancyRow;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.translation.DataTranslationService;
import com.retek.reim.ui.lov.OrderLOV;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		22-Mar-2013	BNaik		BRN IMS135775:  ReIM: RCA not updating the ORDLOC and SHIPSKU correctly
 * 															Move the call to Auto Resolve to the trigger and remove from the Java code when RCA is performed.
 *    1.4		09-Apr-2013  BNaik 	    BRN IMS191135: Error: "An error occurred while reading cost discrepancy." on Detail Matching screen.
 *                                                  This error happens when resolving the discrepancy on the invoice and
 *                                                  receipt that belong to different locations under same SDC. This issue
 *                                                  specific to SMR customization.
 *                                                  E.g. Invoice doc_id = 9621753 is for store: 87
 *                                                  Shipment = 22323239 is for Bill_to_loc: 135
 *                                                  Both stores 87 and 135 are for same Default_wh = 9521
  *                                                  The invoice location is a store 87, the corresponding record from ORDLOC
 *                                                  must be retrieved based on the DEFAULT_WH from STORE for 87.   
 */


public abstract class AOrderBean {
    // Attributes from the table
    protected String orderNo;

    protected String supplier;

    protected String status;

    protected String orderBy = "";

    protected String supplierName;

    protected String currencyCode;

    protected String shipPayMethod;
    
    protected String supplierSite;

    // the dirty-bit flags for attributes
    protected boolean isOrderNoChanged;

    protected boolean isSupplierChanged;

    protected boolean isStatusChanged;

    protected boolean isSupplierNameChanged;

    protected boolean isCurrencyCodeChanged;

    protected boolean isShipPayMethodChanged;
    
    protected boolean isSupplierSiteChanged;

    public void setCurrencyCode(String newCurrencyCode) {
        if (newCurrencyCode.length() > 0) {
            currencyCode = newCurrencyCode;
            isCurrencyCodeChanged = true;
        }
    }
    
    public void setSupplierSite(String newSuppSite) {
        if(newSuppSite.length() > 0) {
            supplierSite = newSuppSite;
            isSupplierSiteChanged = true;
        }
    }

    public void setSupplier(String newSupp) {
        if (newSupp.length() > 0) {
            supplier = newSupp;
            isSupplierChanged = true;
        }
    }

    public void setSupplierName(String newSupplierName) {
        if (newSupplierName.length() > 0) {
            supplierName = newSupplierName;
            isSupplierNameChanged = true;
        }
    }

    public void setOrderNo(String newOrderNo) {
        if (newOrderNo.length() > 0) {
            orderNo = newOrderNo;
            isOrderNoChanged = true;
        }
    }

    /**
     * **Use the setStatus method ONLY if one specific status is desired. Otherwise both 'A'pproved
     * and 'C'losed will be selected.
     * 
     * In most cases this should not be set!
     */
    public void setStatus(String newStatus) {
        if (newStatus.length() > 0) {
            status = newStatus;
            isStatusChanged = true;
        }
    }

    public String sqlCommaList(HashMap map) {
        StringBuffer commaList = new StringBuffer();
        Set keys = map.keySet();
        Iterator iter = keys.iterator();
        while (iter.hasNext()) {
            commaList.append("'");
            commaList.append(iter.next());
            commaList.append("'");
            if (iter.hasNext()) {
                commaList.append(", ");
            }
        }
        return commaList.toString();
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = " order by " + orderBy;
    }

    public void setShipPayMethod(String newShipPayMethod) {
        if (newShipPayMethod.length() > 0) {
            shipPayMethod = newShipPayMethod;
            isShipPayMethodChanged = true;
        }
    }

    private static final String SELECT_FOR_SELECT_PO_LOCATION_INVOICES = "SELECT "
            // Potential hint: /*+ INDEX(DH IM_DOC_HEAD_I10) INDEX(OH
            // PK_ORDHEAD) */
            + "DH.ORDER_NO, DH.LOCATION, DH.LOC_TYPE, OH.SUPPLIER, DH.VENDOR, DH.DOC_ID, DH.EXT_DOC_ID, "
            + "DH.TERMS_DSCNT_PCT, DH.DOC_DATE, DH.TOTAL_COST, DH.TOTAL_QTY, DH.RESOLUTION_ADJUSTED_TOTAL_COST, "
            + "DH.RESOLUTION_ADJUSTED_TOTAL_QTY, DH.DUE_DATE, DH.STATUS, OH.CURRENCY_CODE ORDER_CURRENCY_CODE, "
            + "DH.CURRENCY_CODE INVOICE_CURRENCY_CODE, OH.EXCHANGE_RATE, DH.FREIGHT_TYPE, "
            + "TAXES.TAX_CODE, TAXES.TAX_RATE, TAXES.basis, TAXES.merch_ind ";

    private static final String FROM_FOR_SELECT_PO_LOCATION_INVOICES = "FROM IM_DOC_HEAD DH, "
            + "ORDHEAD OH, (SELECT IDV.DOC_ID, TAX_CODE, TAX_RATE, TAX_BASIS as basis, 1 as merch_ind "
            + "     FROM IM_DOC_TAX IDV UNION ALL SELECT "
            // This hint may be needed for performance INDEX(idnm
            // IM_DOC_NON_MERCH_I1) */
            + "          IDNM.DOC_ID, TAX_CODE, TAX_RATE, TAX_BASIS AS basis, 0 as merch_in "
            + "               FROM IM_DOC_NON_MERCH_TAX IDNM ) TAXES ";

    private static final String WHERE_FOR_SELECT_PO_LOCATION_INVOICES = "WHERE "
            + "DH.ORDER_NO = OH.ORDER_NO AND DH.ORDER_NO = ? AND DH.LOCATION = ? "
            + "AND DH.DOC_ID = TAXES.DOC_ID(+) AND (DH.STATUS = '" + Document.READY_FOR_MATCH
            + "' " + "OR DH.STATUS = '" + Document.UNRESOLVED_MATCH + "' OR DH.STATUS = '"
            + Document.MULTI_UNRESOLVED + "') " + " AND DH.HOLD_STATUS <> 'H'  AND DH.TYPE = '" + Document.MERCHANDISE_INVOICE
            + "' ";

    private static final String EXCLUDE_FOR_SELECT_PO_LOCATION_INVOICES = "AND NOT EXISTS"
            + "(SELECT 'X' FROM IM_MANUAL_GROUP_INVOICES MG WHERE DH.DOC_ID = MG.INVOICE_ID) ";

    private static final String ORDER_BY_FOR_SELECT_PO_LOCATION_INVOICES = "ORDER BY DH.DOC_ID ";

    public void selectPOLocationInvoices(POLocation poLoc) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer query = new StringBuffer(1000);
            query.append(SELECT_FOR_SELECT_PO_LOCATION_INVOICES);
            query.append(FROM_FOR_SELECT_PO_LOCATION_INVOICES);
            query.append(WHERE_FOR_SELECT_PO_LOCATION_INVOICES);
            query.append(EXCLUDE_FOR_SELECT_PO_LOCATION_INVOICES);
            query.append(ORDER_BY_FOR_SELECT_PO_LOCATION_INVOICES);

            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            stmt.setString(1, poLoc.getOrderNo());
            stmt.setString(2, poLoc.getLocation().getLocationId());
            rs = stmt.executeQuery();
            createPOLocationsForOnlineAutoMatchRS(rs, poLoc);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.ord_loc_bean.getPOLocationsForAutoMatch",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.ord_loc_bean.getPOLocationsForAutoMatch",
                        Severity.ERROR, e, this);
            }
        }
    }

    private void createPOLocationsForOnlineAutoMatchRS(ResultSet rs, POLocation poLocation)
            throws ReIMException {
        List<MerchandiseDocument> invoices = null;
        MerchandiseDocument[] invoicesArray = null;
        MerchandiseDocument invoice = null;

        try {
            boolean firstRecord = true;
            String orderNo = poLocation.getOrderNo();
            Location location = poLocation.getLocation();
            long currentDocId = -1;
            long previousDocId = -1;

            Set<Tax> merchTaxes = null;
            Set<Tax> nonMerchTaxes = null;

            while (rs.next()) {
                currentDocId = rs.getLong("DOC_ID");
                if (firstRecord) {
                    // Populate the PO/Location
                    Order order = poLocation.getOrder();
                    order.setSupplier(new Supplier());
                    order.getSupplier().setVendorId(rs.getString("SUPPLIER"));
                    order.setOrderCurrency(rs.getString("ORDER_CURRENCY_CODE"));
                    order.setOrderExchangeRate(new Double(rs.getDouble("EXCHANGE_RATE")));
                    location.setLocationType(rs.getString(ImDocHeadAccess.locTypeColumn));

                    invoices = new ArrayList<MerchandiseDocument>();

                    previousDocId = currentDocId;

                    invoice = createInvoice(rs, currentDocId, poLocation, orderNo);

                    merchTaxes = new HashSet<Tax>();
                    nonMerchTaxes = new HashSet<Tax>();

                    firstRecord = false;
                }

                if (currentDocId != previousDocId) {
                    invoice.setTaxes(merchTaxes);
                    invoice.setNonMerchTaxes(nonMerchTaxes);
                    invoices.add(invoice);

                    merchTaxes = new HashSet<Tax>();
                    nonMerchTaxes = new HashSet<Tax>();

                    invoice = createInvoice(rs, currentDocId, poLocation, orderNo);

                    addTaxes(rs, merchTaxes, nonMerchTaxes);

                    previousDocId = currentDocId;
                } else {
                    addTaxes(rs, merchTaxes, nonMerchTaxes);
                }
            }

            if (invoice != null) {
                invoice.setTaxes(merchTaxes);
                invoice.setNonMerchTaxes(nonMerchTaxes);
                invoices.add(invoice);
            }

            if (invoices != null && invoices.size() > 0) {
                invoicesArray = new MerchandiseDocument[invoices.size()];
                invoices.toArray(invoicesArray);
                poLocation.setInvoices(invoicesArray);
            }
        } catch (Exception e) {
            throw new ReIMException("error.ord_loc_bean.createPOLocationForAutoMatchRS",
                    Severity.ERROR, e, this);
        }
    }

    private void addTaxes(ResultSet rs, Set<Tax> merchTaxes, Set<Tax> nonMerchTaxes)
            throws Exception {
        String merchInd = rs.getString("merch_ind");
        if (merchInd != null) {
            Tax tax = new Tax(rs.getString("TAX_CODE"), rs.getDouble("TAX_RATE"));
            tax.setTaxBasis(rs.getDouble("basis"));
            if (merchInd.equals("1")) {
                merchTaxes.add(tax);
            } else {
                nonMerchTaxes.add(tax);
            }
        }
    }

    private MerchandiseDocument createInvoice(ResultSet rs, long docId, POLocation poLocation,
            String orderNo) throws SQLException {
        MerchandiseDocument invoice = new MerchandiseDocument();
        invoice.setDocId(docId);
        invoice.setOrderNo(orderNo);
        invoice.setLocation(poLocation.getLocation());
        invoice.setExtDocId(rs.getString(ImDocHeadAccess.extDocIdColumn));
        invoice.setVendor(new Supplier(rs.getString(ImDocHeadAccess.vendorColumn)));
        Vendor vendor = new Vendor();
        vendor.setVendorId(rs.getString("SUPPLIER"));
        invoice.setSupplierSite(vendor);
        invoice.setCurrencyCode(rs.getString("INVOICE_CURRENCY_CODE"));
        invoice.setTermsDscntPct(rs.getDouble(ImDocHeadAccess.termsDscntPctColumn));
        invoice.setTotalCost(rs.getDouble(ImDocHeadAccess.totalCostColumn));
        invoice.setTotalQty(rs.getDouble(ImDocHeadAccess.totalQtyColumn));
        invoice.setResolutionAdjustedTotalCost(rs
                .getDouble(ImDocHeadAccess.resolutionAdjustedTotalCostColumn));
        invoice.setResolutionAdjustedTotalQty(rs
                .getDouble(ImDocHeadAccess.resolutionAdjustedTotalQtyColumn));
        invoice.setDueDate(new ReIMDate(rs.getDate(ImDocHeadAccess.dueDateColumn)));
        invoice.setDocDate(new ReIMDate(rs.getDate(ImDocHeadAccess.docDateColumn)));
        invoice.setStatus(rs.getString(ImDocHeadAccess.statusColumn));
        invoice.setFreightType(rs.getString(ImDocHeadAccess.freightTypeColumn));
        invoice.setPoLocation(poLocation);

        return invoice;
    }

    protected String prependWhere = "";

    public OrderLOV[] select(boolean matchToLinkedSupplier, //
            boolean includeClosedOrders, String documentDate, //
            boolean useConsolidatedRate, //
            boolean includeRTVOrders, //
            boolean isSupplierSiteIndOn,boolean includeMerchOrders) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        
        StringBuffer mainSQL = new StringBuffer();
        StringBuffer merchOrderSQL = new StringBuffer();
        StringBuffer rtvOrderSQL = new StringBuffer();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            
            if (includeMerchOrders) {
                merchOrderSQL = createMerchOrderQuery(matchToLinkedSupplier,isSupplierSiteIndOn, includeClosedOrders);
            }

            if (includeRTVOrders) {
                rtvOrderSQL = createRtvOrderQuery(isSupplierSiteIndOn, matchToLinkedSupplier);
            }

            if (includeMerchOrders && includeRTVOrders) {
                mainSQL.append(merchOrderSQL);
                mainSQL.append(" UNION ");
                mainSQL.append(rtvOrderSQL);
                setOrderBy("ORDER_NO");
            } else if (includeMerchOrders) {
                mainSQL.append(merchOrderSQL);
            } else if (includeRTVOrders) {
                mainSQL.append(rtvOrderSQL);
            }

            mainSQL.append(orderBy);

            stmt = (OraclePreparedStatement) conn.prepareStatement(mainSQL.toString());
            
            if (includeRTVOrders) {
                Date reIMDate=ServiceFactory.getPeriodService().getVDate().getSQL_Date();

                if (documentDate == null) {
                    stmt.setDate(1,reIMDate);

                    if (matchToLinkedSupplier) {
                        stmt.setDate(2,reIMDate);
                    }
                }
            }

            rs = stmt.executeQuery();

            List<OrderLOV> dataList = new ArrayList<OrderLOV>(1);
            
            String exchangeRate = null;
            String currCode = null;
            Map<String, String> currCodes = new HashMap<String, String>();
            String userLang = ReIMUserContext.getUserLanguage();
            boolean translationRequired = DataTranslationService.isTranslationRequired(userLang);
            
            
            while (rs.next()) {
                currCode = rs.getString("CURRENCY_CODE");

                if (useConsolidatedRate) {
                    if (!StringUtils.isEmpty(currCode)) {
                        currCodes.put(currCode, exchangeRate);
                    }
                } else {
                    exchangeRate = ReIMI18NUtility.getNumberString(rs.getDouble("EXCHANGE_RATE"),10);
                }

                OrderLOV lov = new OrderLOV(rs.getString("ORDER_NO"),
                        rs.getString("SUPPLIER"),
                        translate(rs.getString("SUPPLIER_NAME"),
                            translationRequired, userLang),
                        rs.getString("TERMS") + " " +
                        rs.getString("TERMS_DESC"), currCode, exchangeRate,
                        rs.getString("SHIP_PAY_METHOD"));

                if (isSupplierSiteIndOn) {
                    lov.setDescription7(rs.getString("SUPP_SITE"));
                    lov.setDescription8(rs.getString("SUPP_SITE_NAME"));
                }

                dataList.add(lov);
            }

            if (useConsolidatedRate) {
                for (String currencyCode : currCodes.keySet()) {
                    ReIMDate docDate = StringUtils.isEmpty(documentDate) ? null
                                                                         : new ReIMDate(documentDate);
                    CurrencyRate currencyRate = ServiceFactory.getCurrencyService()
                                                              .getConsolidatedExchangeRate(currencyCode,
                            docDate);
                    exchangeRate = ReIMI18NUtility.getNumberString(currencyRate.getExchangeRate(),10);
                    currCodes.put(currencyCode, exchangeRate);
                }

                for (OrderLOV lov : dataList) {
                    lov.setDescription5(currCodes.get(lov.getDescription4()));
                }
            }
            
            OrderLOV[] data = new OrderLOV[dataList.size()];
            dataList.toArray(data);

            return data;
        } catch (Exception e) {
            throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
            }
        }
    }
    
    public boolean isRTV()throws ReIMException  {
        
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
            try {
                Connection conn = TransactionManagerFactory.getInstance().getConnection();
                 stmt = (OraclePreparedStatement)conn.prepareStatement("SELECT RTV_ORDER_NO from RTV_HEAD where RTV_ORDER_NO= ?");
                stmt.setString(1, orderNo);
                rs = stmt.executeQuery();
            if (rs.next())
            {
                return true;
            }
            else 
            {
                return false;
            }
            
            }
            catch (Exception e) {
                throw new ReIMException("Error.sql_error", Severity.ERROR, e,
                        this);
            }
            
            finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception e) {
                    throw new ReIMException("error.orderBean.selectLOV",
                            Severity.ERROR, e, this);
                }
        }
    }

    public OrderLOV[] select(boolean matchToLinkedSupplier, boolean includeClosedOrders,
            String documentDate, boolean useConsolidatedRate, boolean includeRTVOrders,boolean isSupplierSiteIndOn)
            throws ReIMException {
        return select(matchToLinkedSupplier, includeClosedOrders, documentDate,
                useConsolidatedRate, includeRTVOrders, isSupplierSiteIndOn, true);
    }
    
    public OrderLOV[] selectCrdNtAndCrdNtReqOrders(boolean matchToLinkedSupplier,
            boolean includeClosedOrders, String documentDate, boolean useConsolidatedRate,
            boolean includeCrdNtOrders, boolean includeCrdNtReqOrders, boolean isSupplierSiteIndOn)
            throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlMain = new StringBuffer();

            String descCol = " B.SUP_NAME ";

            String where = constructWhere(matchToLinkedSupplier, includeClosedOrders, isSupplierSiteIndOn);

            sqlMain = createCrdNtAndCrdNtReqOrderQuery(where, descCol, matchToLinkedSupplier,
                    includeCrdNtOrders, includeCrdNtReqOrders, isSupplierSiteIndOn);

            if (isRTV()){
                if (stmt != null){
                    stmt.close();
                    stmt = null;
                }
                StringBuffer sqlMain1 = new StringBuffer();
                sqlMain1
                .append("SELECT DISTINCT /*+ INDEX(A RTV_HEAD_I2) */ A.RTV_ORDER_NO ORDER_NO,A.SUPPLIER,B.SUP_NAME,null TERMS,null TERMS_CODE,null CURRENCY_CODE,NULL SHIP_PAY_METHOD,NULL EXCHANGE_RATE,NULL TERMS_DESC FROM SUPS B,RTV_HEAD A WHERE B.SUPPLIER = A.SUPPLIER AND A.STATUS_IND in (10,15)  ");
                
                    sqlMain1.append(" AND A.RTV_ORDER_NO=");
                    sqlMain1.append(orderNo);

            stmt = conn.createStatement();
                rs = stmt.executeQuery(sqlMain1.toString());
            }
                
        
            else{
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sqlMain.toString());
                }
            ArrayList dataList = new ArrayList(1);
            String exchangeRate = null;
            String currCode = null;
            Map currCodes = new HashMap();
            while (rs.next()) {
                currCode = rs.getString(6);
                if (useConsolidatedRate) {
                    // use consolidated exchange rate... cash currency codes for later database hit
                    if (currCode != null && currCode.equals(ReIMConstants.EMPTY_STRING) == false) {
                        currCodes.put(currCode, currCode);
                    }
                } else {
                    // get exchangeRate from the order
                    exchangeRate = rs.getString(8);
                }

                dataList.add(new OrderLOV(rs.getString(1), rs.getString(2), rs.getString(3), rs
                        .getString(4)
                        + " " + rs.getString(9), currCode, exchangeRate, rs.getString(7)));
            }

            if (useConsolidatedRate) {
                // change map value and make it equal to the exchage rate
                CurrencyRate rate = null;
                String currCodeAsKey = null;

                for (Iterator i = currCodes.keySet().iterator(); i.hasNext();) {
                    currCodeAsKey = (String) i.next();
                    if (documentDate != null
                            && documentDate.equals(ReIMConstants.EMPTY_STRING) == false) {
                        rate = ServiceFactory.getCurrencyService().getConsolidatedExchangeRate(
                                currCodeAsKey, new ReIMDate(documentDate));
                    } else {
                        rate = ServiceFactory.getCurrencyService().getConsolidatedExchangeRate(
                                currCodeAsKey, null);
                    }
                    if (rate != null) {
                        exchangeRate = rate.getExchangeRate().toString();
                        currCodes.put(currCodeAsKey, exchangeRate);
                        // replace value with the exchangeRate
                    }
                    rate = null;
                }

                // update the dataList objects with the correct consolidated exchangeRate
                int size = dataList.size();
                OrderLOV obj = null;
                String consolidatedExchangeRate = null;
                for (int j = 0; j < size; j++) {
                    obj = (OrderLOV) dataList.get(j);
                    consolidatedExchangeRate = (String) currCodes.get(obj.getDescription4());
                    // description4 holds the currency code
                    obj.setDescription5(consolidatedExchangeRate);
                }
            }

            int l = dataList.size();
            OrderLOV data[] = new OrderLOV[l];
            dataList.toArray(data);

            // do refactored data translation on supplier name
            String userLang = ReIMUserContext.getUserLanguage();
            if (data != null && DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setDescription2(DataTranslationService.getSupplierDesc(data[i]
                            .getDescription2(), userLang));
                }
            }
            return data;
        } catch (Exception e) {
            throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
            }
        }
    }

    private StringBuffer createCrdNtAndCrdNtReqOrderQuery(String constructWhere, String desc,
            boolean matchToLinkedSupplier, boolean includeCrdNtOrder, boolean includeCrdNtReqOrder,
            boolean isSupplierSiteIndOn) {
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT DISTINCT/*+ INDEX(A ORDHEAD_I2) */ A.ORDER_NO, ");
        if (isSupplierSiteIndOn) {
            sql.append(" B.SUPPLIER_PARENT,");
            sql.append(" C.SUP_NAME");
        } else {
            sql.append(" A.SUPPLIER, ");
            sql.append(desc);
        }
        sql
                .append(" , A.TERMS, T.TERMS_CODE, A.CURRENCY_CODE, A.SHIP_PAY_METHOD ,A.EXCHANGE_RATE, T.TERMS_DESC ");
        sql.append("  FROM ORDHEAD A, SUPS B, TERMS T ");

        if (isSupplierSiteIndOn) {
            sql.append(", SUPS C ");
        }

        String sqlPart1 = sql.toString();
        String sqlPart2 = "  WHERE B.SUPPLIER = A.SUPPLIER AND A.TERMS=T.TERMS AND T.ENABLED_FLAG='Y'";
        sql.append(sqlPart2);

        if (isSupplierSiteIndOn) {
            sql.append(" AND C.SUPPLIER = B.SUPPLIER_PARENT ");
        }

        sql.append(constructWhere);
        sqlPart2 = sqlPart2 + constructWhere;
        sql.append(constructUnion(sqlPart1, sqlPart2, matchToLinkedSupplier, isSupplierSiteIndOn));
        if (includeCrdNtOrder) {
            sql
                    .append(" AND A.ORDER_NO IN (SELECT ORDER_NO from IM_DOC_HEAD WHERE TYPE IN ('"
                            + Document.CREDIT_NOTE
                            + "')"
                            + "AND ((STATUS = 'POSTED' AND HOLD_STATUS IN( 'N','P')) OR (STATUS = 'APPRVE' AND (HOLD_STATUS IN ('H','R')))))");
        } else if (includeCrdNtReqOrder) {
            sql.append(" AND A.ORDER_NO IN (SELECT ORDER_NO from IM_DOC_HEAD where type in ('"
                    + Document.CREDIT_NOTE_REQUEST_TAX + "','" + Document.CREDIT_NOTE_REQUEST_PRICE
                    + "','" + Document.CREDIT_NOTE_REQUEST_QUANTITY + "') and STATUS='"
                    + Document.APPROVED + "')");
        }
        sql.append(orderBy);
        return sql;
    }

    private StringBuffer createOrderQuery(String constructWhere, String desc,
            boolean matchToLinkedSupplier, boolean includeRTVOrders, boolean isSupplierSiteIndOn) {
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT DISTINCT /*+ INDEX(A ORDHEAD_I2) */ A.ORDER_NO,");
        if(isSupplierSiteIndOn) {
            sql.append(" B.SUPPLIER SUPP_SITE,");
            sql.append(" B.SUP_NAME SUPP_SITE_NAME,");
            sql.append(" B.SUPPLIER_PARENT SUPPLIER,");
            sql.append(" C.SUP_NAME SUPPLIER_NAME");
            
        } 
        else {
            sql.append(" null SUPP_SITE,");
            sql.append(" null SUPP_SITE_NAME,");
            sql.append("A.SUPPLIER SUPPLIER, ");
            sql.append(desc + " SUPPLIER_NAME");
        }
        sql.append(",NULL DOC_DATE");
        sql
                .append(" , A.TERMS, T.TERMS_CODE, A.CURRENCY_CODE, A.SHIP_PAY_METHOD ,A.EXCHANGE_RATE, T.TERMS_DESC ");
        sql.append("  FROM ORDHEAD A, SUPS B, TERMS T ");
        if (isSupplierSiteIndOn) {
            sql.append(", SUPS C ");
        }
        String sqlPart1 = sql.toString();
        String sqlPart2 = "  WHERE B.SUPPLIER = A.SUPPLIER AND A.TERMS=T.TERMS AND T.ENABLED_FLAG='Y'";
        sql.append(sqlPart2);

        if (isSupplierSiteIndOn) {
            sql.append(" AND C.SUPPLIER = B.SUPPLIER_PARENT ");
        }

        sql.append(constructWhere);
        sqlPart2 = sqlPart2 + constructWhere;
        sql.append(constructUnion(sqlPart1, sqlPart2, matchToLinkedSupplier, isSupplierSiteIndOn));
        if (includeRTVOrders == false) sql.append(orderBy);

        return sql;
    }

    public OrderLOV[] selectReceivedOrders(boolean matchToLinkedSupplier,
            boolean includeClosedOrders, boolean isSupplierSiteIndOn) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            StringBuffer sqlMain = new StringBuffer();

            String descCol = " B.SUP_NAME ";

            String where = constructWhere(matchToLinkedSupplier, includeClosedOrders, isSupplierSiteIndOn);
            sqlMain = createReceivedOrdersQuery(where, descCol, matchToLinkedSupplier,
                    isSupplierSiteIndOn);

            sqlMain.append(orderBy);
            rs = stmt.executeQuery(sqlMain.toString());

            ArrayList dataList = new ArrayList(1);
            String extShipment;
            while (rs.next()) {
                extShipment = rs.getString(3);
                if (extShipment == null) {
                    extShipment = "";
                }
                dataList.add(new OrderLOV(rs.getLong(1) + "", rs.getLong(2) + "", extShipment));
            }

            int l = dataList.size();
            OrderLOV data[] = new OrderLOV[l];
            dataList.toArray(data);

            // do refactored data translation on supplier name
            String userLang = ReIMUserContext.getUserLanguage();
            if (data != null && DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setDescription2(DataTranslationService.getSupplierDesc(data[i]
                            .getDescription2(), userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("Error.sql_error", Severity.ERROR, e, this);
            }
        }
    }

    protected StringBuffer createReceivedOrdersQuery(String constructWhere, String descCol,
            boolean matchToLinkedSupplier, boolean isSupplierSiteIndOn) {
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT A.ORDER_NO, A.SUPPLIER, " + descCol + "   FROM ORDHEAD A, SUPS B ");

        if (isSupplierSiteIndOn) {
            sql.append(", SUPS C ");
        }

        String sqlPart1 = sql.toString();
        String sqlPart2 = "  WHERE A.SUPPLIER = B.SUPPLIER "
                + "       AND EXISTS (SELECT 'X' FROM SHIPMENT C "
                + "           WHERE C.ORDER_NO = A.ORDER_NO AND C.RECEIVE_DATE IS NOT NULL "
                + "                AND C.STATUS_CODE IN ('" 
                + Receipt.RECEIVED_STATUS + "',  '" + Receipt.UNMATCHED_STATUS + "', '" + Receipt.CLOSED_STATUS + "')"
                + "                AND NVL(C.INVC_MATCH_STATUS,'" + Receipt.UNMATCHED + "') ='"
                + Receipt.UNMATCHED + "')" + constructWhere;
        sql.append(sqlPart2);

        if (isSupplierSiteIndOn) {
            sql.append(" AND C.SUPPLIER = B.SUPPLIER_PARENT ");
        }

        sql.append(constructUnion(sqlPart1, sqlPart2, matchToLinkedSupplier, isSupplierSiteIndOn));

        return sql;
    }

    public String selectTerms(String orderNo) throws ReIMException {
        OraclePreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String terms = null;

            pstmt = (OraclePreparedStatement) conn
                    .prepareStatement("select TERMS from ORDHEAD where ORDER_NO=?");

            pstmt.clearParameters();
            pstmt.setString(1, orderNo);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                terms = rs.getString(1);
            }

            return terms;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("Error.sql_error", Severity.ERROR, e, this);
            }
        }
    }

    public Map selectCommentDescForOrders(String orderNoStringList) throws ReIMException {
        OraclePreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            Map commentResults = new HashMap();

            // Expect that orderNoStringList is a comma delimited list of order
            // numbers.
            String sql = "select ORDER_NO, COMMENT_DESC from ORDHEAD where ORDER_NO in ("
                    + orderNoStringList + ")";
            pstmt = (OraclePreparedStatement) conn.prepareStatement(sql);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                commentResults.put(rs.getString("ORDER_NO"), rs.getString("COMMENT_DESC"));
            }

            return commentResults;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("Error.sql_error", Severity.ERROR, e, this);
            }
        }
    }

    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes. Currently
    // the implementation of the where clause does not require use of isEmpty to
    // determine
    // if "AND" should be appended as there is always a WHERE specified. If
    // changed to be more dynamic, simply add "where 1=1 "
    // to avoid all the extra logic of isEmpty -- "AND" will always
    // be appended
    protected String constructWhere(boolean matchToLinkedSupplier, boolean includeClosedOrders,
            boolean isSupplierSiteIndOn) {
        StringBuffer where = new StringBuffer();
        if (prependWhere.length() > 0) {
            where.append(" AND ");
            where.append(prependWhere);
        }

        // check if currency code is passed in from the batch entry new header
        if (isCurrencyCodeChanged) {
            where.append(" AND A.CURRENCY_CODE='");
            where.append(currencyCode);
            where.append("'");
        }

        if (isStatusChanged) {
            where.append(" AND A.STATUS='");
            where.append(status);
            where.append("'");
        } else {
            // no status is specified or both Approved and Closed are desired.
            // Never show 'W'orksheet or 'S'ubmitted
            if (includeClosedOrders) {
                where.append(" AND A.STATUS in ('A','C') ");
            } else {
                where.append(" AND A.STATUS in ('A') ");
            }
        }

        if (isOrderNoChanged) {
            where.append(" AND A.ORDER_NO=");
            where.append(orderNo);
        }

        if (isSupplierNameChanged) {
            where.append(" AND B.SUP_NAME=");
            where.append(supplierName);
        }
        
        if(isSupplierSiteIndOn) {
            if(isSupplierSiteChanged) {
                if(supplierSite != null && !supplierSite.equals("")) {
                    where.append(" AND B.SUPPLIER=");
                    where.append(supplierSite);
                }
            }
        }

        // The complete WHERE clause is returned here
        if (where.length() != 0) {
            return where.toString();
        } else {
            return "";
        }
    }

    // The union is needed if the supplier is linked to other suppliers
    protected String constructUnion(String sqlPart1, String sqlPart2,
            boolean matchToLinkedSupplier, boolean isSupplierSiteIndOn) {
        StringBuffer union = new StringBuffer();

        if (isSupplierChanged) {
            if (isSupplierSiteIndOn) {
                union.append(" AND B.SUPPLIER_PARENT=");
                // matchToLinkedSupplier = false;
            } else {
                union.append("AND A.SUPPLIER=");
            }
            union.append(supplier);

            if (matchToLinkedSupplier) {
                if(isSupplierSiteIndOn ) {
                        union.append(" UNION ");
                        union.append(sqlPart1);
                        union.append(", IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 ");
                        union.append(sqlPart2);
                        union.append(" AND L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID=");
                        union.append(supplier);
                        union.append(" AND B.SUPPLIER_PARENT=L2.SUPPLIER_ID AND C.SUPPLIER = B.SUPPLIER_PARENT");
                } else{
                    union.append(" UNION ");
                    union.append(sqlPart1);
                    union.append(", IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 ");
                    union.append(sqlPart2);
                    union.append(" AND L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID=");
                    union.append(supplier);
                    union.append(" AND A.SUPPLIER=L2.SUPPLIER_ID");
                }
            }
        }

        // The complete WHERE clause is returned here
        if (union.length() != 0) {
            return union.toString();
        } else {
            return "";
        }
    }

    public boolean selectValidOrder(Long orderNo, String supplier) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
             Connection conn = TransactionManagerFactory.getInstance().getConnection();
             
         //    final String VALIDATE_ORDER_SUPP_SITE_ON_SQL  =  "SELECT /*+  index(s2, pk_sups) use_nl (s1,s2) */  'X' FROM ORDHEAD OH, SUPS S1, SUPS S2 WHERE OH.ORDER_NO = ? AND OH.STATUS IN ('A','C') AND (OH.SUPPLIER = ? OR OH.SUPPLIER IN (SELECT /*+  index(sups, SUPS_I9)*/ SUPPLIER FROM SUPS WHERE SUPPLIER_PARENT = ?) OR (S1.SUPPLIER = OH.SUPPLIER AND S2.SUPPLIER = ? AND S1.SUPPLIER_PARENT = S2.SUPPLIER_PARENT))";
             final String VALIDATE_ORDER_SUPP_SITE_ON_SQL  =  "SELECT /*+  ALL_ROWS  */  'X' FROM ORDHEAD OH, SUPS S1  WHERE OH.ORDER_NO = ? AND OH.STATUS IN ('A','C') AND (OH.SUPPLIER = ? OR OH.SUPPLIER IN (SELECT /*+  index(sups, SUPS_I9)*/ SUPPLIER FROM SUPS WHERE SUPPLIER_PARENT = ?) OR (S1.SUPPLIER = OH.SUPPLIER AND S1.SUPPLIER = ?  ))";
             
             final String VALIDATE_ORDER_SUPP_SITE_OFF_SQL  = "SELECT 'X' FROM ORDHEAD OH WHERE OH.ORDER_NO = ? AND OH.STATUS IN ('A','C') AND OH.SUPPLIER = ? ";

             boolean isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions().isSupplierSiteInd();
             
             String SQL = isSupplierSiteIndOn ? VALIDATE_ORDER_SUPP_SITE_ON_SQL : VALIDATE_ORDER_SUPP_SITE_OFF_SQL;
             
             stmt = (OraclePreparedStatement) conn.prepareStatement(SQL);
             
             Long supplierId = Long.valueOf(supplier);
             
             int counter = 1;
             stmt.setLong(counter++, orderNo);
             stmt.setLong(counter++, supplierId);
             if(isSupplierSiteIndOn) {
                 stmt.setLong(counter++, supplierId);
                 stmt.setLong(counter++, supplierId);
             }

             rs = stmt.executeQuery();

             if (rs.next()) {
                  return true;
             } else {
                  return false;
             }
         } catch (SQLException ex) {
             throw new ReIMException("error.ord_loc_bean.selectValidOrder",
                     Severity.ERROR, ex, this);
         } catch (Exception e) {
             throw new ReIMException("error.ord_loc_bean.selectValidOrder", Severity.ERROR, e,
                     this);
         } finally {
             try {
                 if (rs != null) {
                     rs.close();
                 }
                 if (stmt != null) {
                     stmt.close();
                 }
             } catch (Exception e) {
                 throw new ReIMException("error.ord_loc_bean.selectValidOrder", Severity.ERROR,
                         e, this);
             }
         }


    }

    public boolean selectValidOrderCheckingLinkedSuppliers(Long orderNo, String supplier)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Check the order/supplier combination first.
            if (selectValidOrder(orderNo, supplier)) return true;

            // If the order/supplier combination is not valid, then
            // look further if linked suppliers should be checked.
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            boolean isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService()
                    .getSystemOptions().isSupplierSiteInd();
            if (isSupplierSiteIndOn) {
                stmt = (OraclePreparedStatement) conn
                        .prepareStatement(" select oh.order_no "
                                + "   from ordhead oh, "
                                + "        im_supplier_options iso, "
                                + "        im_supplier_group_members ils1, im_supplier_group_members ils2, sups s "
                                + "  where oh.order_no = ? "
                                + "    and (oh.status = 'A' "
                                + "        or oh.status = 'C')"
                                + "    and oh.supplier = s.supplier and s.supplier_parent = ils2.supplier_id "
                                + "    and ils1.group_id = ils2.group_id "
                                + "    and ils1.supplier_id = iso.supplier "
                                + "    and iso.supplier = ? "
                                + "    and iso.match_rcpts_other_supps_ind = 'Y' ");

            } else {
                stmt = (OraclePreparedStatement) conn.prepareStatement(" select oh.order_no "
                        + "   from ordhead oh, " + "        im_supplier_options iso, "
                        + "        im_supplier_group_members ils1, im_supplier_group_members ils2 "
                        + "  where oh.order_no = ? " + "    and (oh.status = 'A' "
                        + "        or oh.status = 'C')" + "    and oh.supplier = ils2.supplier_id "
                        + "    and ils1.group_id = ils2.group_id "
                        + "    and ils1.supplier_id = iso.supplier " + "    and iso.supplier = ? "
                        + "    and iso.match_rcpts_other_supps_ind = 'Y' ");
            }
            stmt.setLong(1, orderNo.longValue());
            stmt.setLong(2, new Long(supplier).longValue());

            rs = stmt.executeQuery();
            if (rs.next())
                return true;
            else
                return false;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.order_bean.selectValidOrderCheckingLinkedSuppliers",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new ReIMException("error.order_bean.selectValidOrderCheckingLinkedSuppliers",
                        Severity.ERROR, e, this);
            }
        }
    }

    public boolean selectValidOrderLoc(String locType, Long location, Long orderNo)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        String store = "SELECT 'X' FROM V_IM_ORDLOC WHERE order_no = ? AND loc_type = ? AND location = ? ";
        String warehouse = "SELECT 'X' FROM V_IM_ORDLOC WHERE order_no = ? AND loc_type = ? AND location in (select wh from wh where physical_wh = ?)";

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (locType.equalsIgnoreCase("W")) {
                stmt = (OraclePreparedStatement) conn.prepareStatement(warehouse);
            } else {
                stmt = (OraclePreparedStatement) conn.prepareStatement(store);
            }
            stmt.setLong(1, orderNo.longValue());
            stmt.setString(2, locType);
            stmt.setLong(3, location.longValue());

            rs = stmt.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new ReIMException("error.ord_loc_bean.selectValidOrderLoc", Severity.ERROR, e,
                    this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.ord_loc_bean.selectValidOrderLoc", Severity.ERROR,
                        e, this);
            }
        }

    }

    /**
     * readDiscrepancyDetailsByPO will retrieve cost discrepancy information based on specified
     * criteria. Note: In most cases an order will be specified, but it may be NULL and is not
     * required. In most cases the item will be supplied by the supplier listed on the discrepancy,
     * but this is not required (due to link supplier functionality).
     * 
     * @return DiscrepancyCostReviewDetail[]
     */
    public DiscrepancyCostReviewDetail[] readDiscrepancyDetailsByPO(String orderNo, String docId,
            String locationId, String departmentID, String classID, String resolveByDate,
            String routingDate, String cashDiscount, String businessRoleId) throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            ReIMDate resByDate = new ReIMDate(resolveByDate);
            ReIMDate routDate = new ReIMDate(routingDate);

            StringBuffer sqlMain = new StringBuffer();
            String intlWhereClause = "";

            String descCol = " IM.ITEM_DESC DESC_UP ";

            if (docId != null) {
                intlWhereClause = " AND CD.DOC_ID = ? ";
            }
            intlWhereClause += " AND CD.BUSINESS_ROLE_ID = ?";

            sqlMain = createDiscrepancyDetailsQuery(descCol, intlWhereClause);
          
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlMain.toString());
            stmt.setString(1, orderNo);
            stmt.setString(2, orderNo);
            stmt.setString(3, locationId);
            stmt.setString(4, orderNo);
            stmt.setString(5, orderNo);
            stmt.setString(6, locationId);
            stmt.setString(7, locationId);
            stmt.setString(8, departmentID);
            stmt.setString(9, classID);
            stmt.setDate(10, resByDate.getSQL_Date());
            stmt.setDate(11, routDate.getSQL_Date());
            stmt.setString(12, cashDiscount);

            if (docId != null) {
                stmt.setString(13, docId);
                stmt.setString(14, businessRoleId);
                stmt.setString(15, orderNo);
                stmt.setString(16, orderNo);
                stmt.setString(17, locationId);
                stmt.setString(18, orderNo);
                stmt.setString(19, orderNo);
                stmt.setString(20, locationId);
                stmt.setString(21, locationId);
                stmt.setString(22, departmentID);
                stmt.setString(23, classID);
                stmt.setDate(24, resByDate.getSQL_Date());
                stmt.setDate(25, routDate.getSQL_Date());
                stmt.setString(26, cashDiscount);
                stmt.setString(27, docId);
                stmt.setString(28, businessRoleId);
                
                // Anil Potukuchi Begin
                stmt.setString(29, orderNo);
                stmt.setString(30, locationId);
                stmt.setString(31, orderNo);
                stmt.setString(32, orderNo);
                stmt.setString(33, locationId);
                stmt.setString(34, locationId);
                stmt.setString(35, departmentID);
                stmt.setString(36, classID);
                stmt.setDate(37, resByDate.getSQL_Date());
                stmt.setDate(38, routDate.getSQL_Date());
                stmt.setString(39, cashDiscount);
                stmt.setString(40, docId);
                stmt.setString(41, businessRoleId); 
       
                 // Anil Potukuchi End
                
            } else {
                stmt.setString(13, businessRoleId);
                stmt.setString(14, orderNo);
                stmt.setString(15, orderNo);
                stmt.setString(16, locationId);
                stmt.setString(17, orderNo);
                stmt.setString(18, orderNo);
                stmt.setString(19, locationId);
                stmt.setString(20, locationId);
                stmt.setString(21, departmentID);
                stmt.setString(22, classID);
                stmt.setDate(23, resByDate.getSQL_Date());
                stmt.setDate(24, routDate.getSQL_Date());
                stmt.setString(25, cashDiscount);
                stmt.setString(26, businessRoleId);
            }

            rs = stmt.executeQuery();

            DiscrepancyCostReviewDetail[] data = createCostReviewDetailFromRS(rs);

            // do refactored data translation on item description
            String userLang = ReIMUserContext.getUserLanguage();
            if (data != null && DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setItemDesc(DataTranslationService.getItemDesc(data[i].getItemDesc(),
                            userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.retrieving_qty_discrepancy_details_by_order",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_qty_discrepancy_details_by_order",
                        Severity.ERROR, e, this);
            }
        }
    }

    private StringBuffer createDiscrepancyDetailsQuery(String descCol, String intlWhereClause) {
        StringBuffer sql = new StringBuffer();

        sql.append(" SELECT DISTINCT CD.ITEM, ");
        sql.append(descCol);
        sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST_INIT, ");
        sql.append(" OS.REF_ITEM, CD.ITEM, IM.DESC_UP, ");
        sql.append("  OL.UNIT_COST, CD.DOC_UNIT_COST, ");
        sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE,");
        sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC,");
        sql
                .append(" OL.COST_SOURCE, SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID, CD.DOC_ID ");

        sql.append(" FROM IM_COST_DISCREPANCY CD, ITEM_MASTER IM, ");
        sql
                .append(" (SELECT wh.PHYSICAL_WH location,order_no,item,UNIT_COST_INIT,UNIT_COST,COST_SOURCE FROM v_im_ordloc ,wh  WHERE  loc_type = 'W' AND   wh= location and order_no = ? ) OL, ORDSKU OS, ITEM_SUPPLIER SI, WH W ,");
        sql
                .append(" (SELECT * FROM v_im_shipsku SK WHERE SK.SHIPMENT IN (SELECT SHIPMENT FROM SHIPMENT WHERE ORDER_NO=? and bill_to_loc=?)) SK ");
        sql.append(" WHERE (CD.ORDER_NO = ? OR ? IS NULL) ");
        sql.append(" AND (CD.LOCATION = ? OR ? IS NULL) ");
        sql.append(" AND CD.DEPT = ? ");
        sql.append(" AND CD.CLASS = ? ");
        sql.append(" AND TRUNC(CD.RESOLVE_BY_DATE) = ? ");
        sql.append(" AND TRUNC(CD.ROUTING_DATE) = ? ");
        sql.append(" AND CD.CASH_DSCNT_IND = ? ");
        sql.append(" AND CD.ITEM=IM.ITEM ");
        sql.append(" AND CD.ORDER_NO = OL.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OL.ITEM (+) ");
        sql.append(" AND CD.ITEM= SK.ITEM(+) ");
        sql.append(" AND CD.LOCATION = W.PHYSICAL_WH(+) ");
        sql.append(" AND CD.LOCATION = W.WH ");
        sql.append(" AND CD.LOCATION = OL.LOCATION(+) ");
        sql.append(" AND CD.ITEM = SI.ITEM (+) ");
        sql.append(" AND CD.SUPPLIER = SI.SUPPLIER (+) ");
        sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OS.ITEM (+) ");
        sql.append(intlWhereClause);

        sql.append(" UNION ALL ");
         sql.append(" SELECT DISTINCT CD.ITEM, ");
         sql.append(descCol);
         sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST_INIT, ");
         sql.append(" OS.REF_ITEM, CD.ITEM, IM.DESC_UP, ");
         sql.append("  OL.UNIT_COST, CD.DOC_UNIT_COST, ");
         sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE,");
         
         sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC,");
         sql
                 .append(" OL.COST_SOURCE, SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID, CD.DOC_ID ");

         sql.append(" FROM IM_COST_DISCREPANCY CD, ITEM_MASTER IM, ");
         
         
         sql.append(" (SELECT ol.item, ol.order_no,cost_source, unit_cost_init, unit_cost  FROM v_im_ordloc ol, SHIPMENT SH, STORE ST," +
         "(SELECT MAX(LOCATION) CARTON_LOC, SK.SHIPMENT SHIPMENT ,sk.item  FROM CARTON C, V_IM_SHIPSKU SK,shipment sh  " +
         "WHERE SK.CARTON IS NOT NULL  AND SK.CARTON = C.CARTON AND sh.order_no = ? AND sh.shipment = sk.shipment GROUP BY sk.shipment, sk.item )C " +
         "WHERE NVL(SH.BILL_TO_LOC,NVL(C.CARTON_LOC,NVL(SH.BILL_TO_LOC,OL.LOCATION))) = ST.STORE AND SH.SHIPMENT = C.SHIPMENT(+)  " +
         "AND ol.order_no = ? AND ol.order_no = sh.order_no(+) AND OL.LOC_TYPE='S' AND sh.bill_to_loc = ? AND ol.item = c.item) OL, ORDSKU OS, ITEM_SUPPLIER SI ,STORE S ");
         
         sql.append(" WHERE (CD.ORDER_NO = ? OR ? IS NULL) ");
         sql.append(" AND (CD.LOCATION = ? OR ? IS NULL) ");
         sql.append(" AND CD.DEPT = ? ");
         sql.append(" AND CD.CLASS = ? ");
         sql.append(" AND TRUNC(CD.RESOLVE_BY_DATE) = ? ");
         sql.append(" AND TRUNC(CD.ROUTING_DATE) = ? ");
         sql.append(" AND CD.CASH_DSCNT_IND = ? ");
         sql.append(" AND CD.ITEM=IM.ITEM ");
         sql.append(" AND CD.ORDER_NO = OL.ORDER_NO  ");
         sql.append(" AND CD.ITEM = OL.ITEM (+) ");
         sql.append(" AND CD.LOCATION=S.STORE ");
         sql.append(" AND CD.ITEM = SI.ITEM (+) ");
         sql.append(" AND CD.SUPPLIER = SI.SUPPLIER (+) ");
         sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
         sql.append(" AND CD.ITEM = OS.ITEM (+) ");
         sql.append(intlWhereClause);


        // ANIL POTUKUCHI
       sql.append(" UNION ALL ");
        sql.append(" SELECT DISTINCT CD.ITEM, ");
        sql.append(descCol);
        sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST_INIT, ");
        sql.append(" OS.REF_ITEM, CD.ITEM, IM.DESC_UP, ");
        sql.append("  OL.UNIT_COST, CD.DOC_UNIT_COST, ");
        sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE,");
        
        sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC,");
        sql
                .append(" OL.COST_SOURCE, SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID, CD.DOC_ID ");

        sql.append(" FROM IM_COST_DISCREPANCY CD, ITEM_MASTER IM, ");
        sql.append(" (SELECT OL.*, st.store  FROM V_IM_ORDLOC OL, SHIPMENT SH, WH WH , store st " +
        "WHERE case when ol.loc_type = 'W' and ol.location != 901 then ol.location else sh.bill_to_loc end = wh.wh  " +
        "AND OL.ORDER_NO = SH.ORDER_NO (+) AND ol.location = st.default_wh AND OL.LOC_TYPE='W') OL, ORDSKU OS, ITEM_SUPPLIER SI , sups sps, ");
        sql
        .append(" (SELECT * FROM SHIPSKU SK WHERE SK.SHIPMENT IN (SELECT SHIPMENT FROM SHIPMENT WHERE ORDER_NO=? and BILL_TO_LOC=?)) SK ");
        
        sql.append(" WHERE (CD.ORDER_NO = ? OR ? IS NULL) ");
        sql.append(" AND (CD.LOCATION = ? OR ? IS NULL) ");
        sql.append(" AND CD.DEPT = ? ");
        sql.append(" AND CD.CLASS = ? ");
        sql.append(" AND TRUNC(CD.RESOLVE_BY_DATE) = ? ");
        sql.append(" AND TRUNC(CD.ROUTING_DATE) = ? ");
        sql.append(" AND CD.CASH_DSCNT_IND = ? ");
        sql.append(" AND CD.ITEM=IM.ITEM ");
        sql.append(" AND CD.ORDER_NO = OL.ORDER_NO  ");
        sql.append(" AND CD.ITEM = OL.ITEM (+) ");
        sql.append(" AND CD.ITEM= SK.ITEM(+) ");
        sql.append(" AND CD.LOCATION=OL.STORE ");
        sql.append(" AND CD.ITEM = SI.ITEM (+) ");
        sql.append(" AND CD.SUPPLIER = sps.supplier_parent (+) ");
        sql.append(" AND sps.supplier = si.supplier ");
        sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OS.ITEM (+) ");
        sql.append(intlWhereClause); 
        
        return sql;
    }
    
    
    

    private DiscrepancyCostReviewDetail[] createCostReviewDetailFromRS(ResultSet rs)
            throws Exception {
        ArrayList detailReviews = new ArrayList();
        DiscrepancyCostReviewDetail costReviewDetailObj = null;
        while (rs.next()) {
            String unitCost = rs.getString("UNIT_COST");
            String unitCostInit = rs.getString("UNIT_COST_INIT");
            String resolutionCost = rs.getString("RESOLUTION_COST");
            String variance = rs.getString("VARIANCE");
            String variancePc = rs.getString("VARIANCE_PC");

            costReviewDetailObj = new DiscrepancyCostReviewDetail(
                    rs.getLong("COST_DISCREPANCY_ID"), rs.getString("ITEM"), rs
                            .getString("DESC_UP"), (unitCostInit != null ? new Double(unitCostInit)
                            : null), (unitCost != null ? new Double(unitCost) : null), rs
                            .getDouble("DOC_UNIT_COST"), (resolutionCost != null ? new Double(
                            resolutionCost) : null), (variance != null ? new Double(variance)
                            : null), (variancePc != null ? new Double(variancePc) : null), rs
                            .getString("COST_SOURCE"), rs.getString("REF_ITEM"), null, rs
                            .getString("VPN"), rs.getString("DEBIT_MEMO_REASON_CODE"), rs
                            .getString("CURRENCY_CODE"));
            costReviewDetailObj.setDocId(rs.getLong("DOC_ID"));
            detailReviews.add(costReviewDetailObj);
        }

        if (detailReviews.size() == 0) {
            return null;
        } else {
            return (DiscrepancyCostReviewDetail[]) detailReviews
                    .toArray(new DiscrepancyCostReviewDetail[detailReviews.size()]);
        }
    }

    private static final String GET_COMMENTS = "SELECT COMMENT_DESC FROM ORDHEAD WHERE ORDER_NO=?";

    public String getOrderComments(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String orderComments = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(GET_COMMENTS);
            stmt.setString(1, orderNo);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                orderComments = resultSet.getString("COMMENT_DESC");
            }

            return orderComments;
        } catch (Exception exception) {
            throw new ReIMException("error.error_retrieving_order_comments", Severity.ERROR,
                    exception, this, new String[] { String.valueOf(orderNo)});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.error_retrieving_order_comments", Severity.ERROR, e,
                        this, new String[] { String.valueOf(orderNo)});
            }
        }
    }

    private static final String GET_CURRENCY = "SELECT CURRENCY_CODE FROM ORDHEAD WHERE ORDER_NO=?";

    public String getCurrencyCode(long orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        String currencyCode = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(GET_CURRENCY);
            stmt.setLong(1, orderNo);
            resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                currencyCode = resultSet.getString("CURRENCY_CODE");
            }

            return currencyCode;
        } catch (Exception exception) {
            throw new ReIMException("error.error_retrieving_curr_code", Severity.ERROR, exception,
                    this, new String[] { String.valueOf(orderNo)});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.error_retrieving_curr_code", Severity.ERROR, e,
                        this, new String[] { String.valueOf(orderNo)});
            }
        }
    }

    public HashMap getAllTerms() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            // This query will get back invoice and order terms for all invoices
            // whose best terms
            // are not set yet. The invoices will either be matched, or if
            // unresolved match, all of
            // the invoice details should be both cost matched and qty matched
            // with no adjustment
            // pending.
            StringBuffer sql = new StringBuffer("SELECT /*+ FIRST_ROWS */ ");
            sql.append("ORDHEAD.ORDER_NO PO, ORDHEAD.TERMS POTERMS, ");
            sql.append("IM_DOC_HEAD.DOC_ID DOCID, IM_DOC_HEAD.TERMS DOCTERMS ");
            sql.append("FROM ORDHEAD, IM_DOC_HEAD ");
            sql.append("WHERE ORDHEAD.ORDER_NO = IM_DOC_HEAD.ORDER_NO ");
            sql.append("AND IM_DOC_HEAD.BEST_TERMS IS NULL ");
            sql.append("AND IM_DOC_HEAD.STATUS = '" + Document.MATCHED + "' ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            resultSet = stmt.executeQuery();

            HashMap terms = new HashMap();

            while (resultSet.next()) {
                OrderInvoiceTerms term = new OrderInvoiceTerms();
                term.setOrderNo(resultSet.getString("PO"));
                term.setOrderTerms(resultSet.getString("POTERMS"));
                String invoiceNo = resultSet.getString("DOCID");
                term.setInvoiceNo(invoiceNo);
                term.setInvoiceTerms(resultSet.getString("DOCTERMS"));
                terms.put(invoiceNo, term);
            }

            return terms;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_retrieve_current_terms", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.could_not_retrieve_current_terms", Severity.ERROR,
                        e, this);
            }
        }
    }

    public HashMap getTermsByOrder(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sql = new StringBuffer("SELECT /*+ FIRST_ROWS */ ");
            sql.append("ORDHEAD.ORDER_NO PO, ORDHEAD.TERMS POTERMS, ");
            sql.append("IM_DOC_HEAD.DOC_ID DOCID, IM_DOC_HEAD.TERMS DOCTERMS ");
            sql.append("FROM ORDHEAD, IM_DOC_HEAD ");
            sql.append("WHERE ORDHEAD.ORDER_NO = IM_DOC_HEAD.ORDER_NO ");
            sql.append("AND IM_DOC_HEAD.ORDER_NO = " + orderNo);

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            resultSet = stmt.executeQuery();

            HashMap terms = new HashMap();

            while (resultSet.next()) {
                OrderInvoiceTerms term = new OrderInvoiceTerms();
                term.setOrderNo(resultSet.getString("PO"));
                term.setOrderTerms(resultSet.getString("POTERMS"));
                String invoiceNo = resultSet.getString("DOCID");
                term.setInvoiceNo(invoiceNo);
                term.setInvoiceTerms(resultSet.getString("DOCTERMS"));
                terms.put(invoiceNo, term);
            }

            return terms;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_retrieve_current_terms", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.could_not_retrieve_current_terms", Severity.ERROR,
                        e, this);
            }
        }
    }

    private static final String GET_ER_CC_SPM = "SELECT CURRENCY_CODE, EXCHANGE_RATE, SHIP_PAY_METHOD FROM ORDHEAD WHERE ORDER_NO = ?";

    public Order getDocumentDefaultsFromOrderNo(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(GET_ER_CC_SPM);
            stmt.setLong(1, Long.parseLong(orderNo));
            resultSet = stmt.executeQuery();

            Order order = new Order();

            if (resultSet.next()) {
                order.setOrderCurrency(resultSet.getString("CURRENCY_CODE"));
                order.setOrderExchangeRate(new Double(resultSet.getDouble("EXCHANGE_RATE")));
                order.setShipPaymentMethod(resultSet.getString("SHIP_PAY_METHOD"));
                order.setOrderNo(orderNo);
            }

            return order;
        } catch (Exception exception) {
            throw new ReIMException("error.error_retrieving_curr_code", Severity.ERROR, exception,
                    this, new String[] { String.valueOf(orderNo)});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.error_retrieving_curr_code", Severity.ERROR, e,
                        this, new String[] { String.valueOf(orderNo)});
            }
        }

    }

    public ArrayList selectOrderItems(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT ITEM FROM ORDSKU WHERE ORDER_NO = ? UNION  SELECT ITEM FROM RTV_DETAIL WHERE RTV_ORDER_NO =?");
            stmt.setLong(1, Long.parseLong(orderNo));
            stmt.setLong(2, Long.parseLong(orderNo));
            resultSet = stmt.executeQuery();

            ArrayList skus = new ArrayList();

            while (resultSet.next()) {
                String sku = resultSet.getString("ITEM");
                skus.add(sku);
            }

            return skus;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_order_items", Severity.ERROR, exception,
                    this, new String[] { orderNo});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.cannot_retrieve_order_items.close_stmt_rs",
                        Severity.ERROR, e, this, new String[] { orderNo});
            }
        }
    }

    public Item[] selectSortedOrderItems(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        ArrayList itemList = new ArrayList();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT O.ITEM,I.DEPT,I.CLASS FROM ORDSKU O, ITEM_MASTER I WHERE O.ITEM = I.ITEM AND O.ORDER_NO = ? ORDER BY O.ITEM ");
            stmt.setLong(1, Long.parseLong(orderNo));
            resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Item item = new Item();
                item.setItemId(resultSet.getString("ITEM"));
                item.setItemDept(resultSet.getString("DEPT"));
                item.setItemClass(resultSet.getString("CLASS"));

                itemList.add(item);
            }

            return (Item[]) itemList.toArray(new Item[itemList.size()]);

        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_order_items", Severity.ERROR, exception,
                    this, new String[] { orderNo});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.cannot_retrieve_order_items.close_stmt_rs",
                        Severity.ERROR, e, this, new String[] { orderNo});
            }
        }
    }

    public DiscrepancyQuantityReviewDetail[] readQtyDiscrepancyDetailsByPO(String orderNo,
            String docId, String locationId, String resolveByDate, String apReviewer, long roleId,
            String privilege, String documentType) throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            ReIMDate resByDate = new ReIMDate(resolveByDate);

            String additionalWhereClause = null;

            if (ReIMConstants.USER.equals(privilege)) {
                additionalWhereClause = " AND EXISTS (SELECT 'X' FROM IM_QTY_DISCREPANCY_ROLE QDRO WHERE QDRO.QTY_DISCREPANCY_ID = QD.QTY_DISCREPANCY_ID AND QDRO.BUSINESS_ROLE_ID = ?) ";
            } else {
                additionalWhereClause = StringUtils.EMPTY;
            }

 
            StringBuffer sqlMain = createQtyReviewDetailsQuery(documentType, additionalWhereClause);
            
            
            if (documentType.equals(Document.MERCHANDISE_INVOICE)) {
                stmt = (OraclePreparedStatement) conn.prepareStatement(sqlMain.toString());

                stmt.setString(1, docId);
                stmt.setString(2, orderNo);
                stmt.setString(3, docId);
                stmt.setString(4, locationId);
                //stmt.setDate(5, resByDate.getSQL_Date());
                stmt.setString(5, apReviewer);

                if (privilege.equalsIgnoreCase(ReIMConstants.USER)) {
                    stmt.setLong(6, roleId);
                }
            } else // credit memo qty
            {
                stmt = (OraclePreparedStatement) conn.prepareStatement(sqlMain.toString());

                stmt.setString(1, docId);
                stmt.setString(2, orderNo);
                stmt.setString(3, orderNo);
                stmt.setString(4, docId);
                stmt.setString(5, locationId);
                stmt.setString(6, locationId);
                //stmt.setDate(7, resByDate.getSQL_Date());
                stmt.setString(7, apReviewer);

                if (privilege.equalsIgnoreCase(ReIMConstants.USER)) {
                    stmt.setLong(8, roleId);
                }
            }

            rs = stmt.executeQuery();

            DiscrepancyQuantityReviewDetail[] data = createQuantityReviewDetailFromRS(rs, docId);

            // do refactored data translation on item description and location
            // name
            String userLang = ReIMUserContext.getUserLanguage();
            if (data != null && DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    if (data[i].getItem() != null && data[i].getItem().getItemName() != null) {
                        data[i].getItem().setItemName(
                                DataTranslationService.getItemDesc(data[i].getItem().getItemName(),
                                        userLang));
                    }
                    if (data[i].getLocation() != null
                            && data[i].getLocation().getLocationName() != null) {
                        data[i].getLocation().setLocationName(
                                DataTranslationService.getLocationDesc(data[i].getLocation()
                                        .getLocationName(), userLang));
                    }
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.retrieving_qty_discrepancy_details_by_order",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_qty_discrepancy_details_by_order",
                        Severity.ERROR, e, this);
            }
        }
    }

    private StringBuffer createQtyReviewDetailsQuery(String docType, String additionalWhereClause) {
        StringBuffer orderSql = new StringBuffer();
        StringBuffer select = new StringBuffer();
        StringBuffer fromClause = new StringBuffer();
        StringBuffer whereClause = new StringBuffer();
        StringBuffer groupByAfter = new StringBuffer("");

        if (docType.equals(Document.MERCHANDISE_INVOICE)) {
            select.append(" SELECT DISTINCT QD.ITEM, ");
            select.append(" IM.ITEM_DESC ");
            select.append(" DESC_UP, ");
            select.append(" NVL(OL.TOTAL_QTY_ORDERED, 0) QTY_ORDERED, ");
            select.append(" QD.QTY_INVOICED, ");
            select.append(" NVL(QTY.QTY_RECEIVED,0) QTY_RECEIVED, ");
            select.append(" OS.REF_ITEM, ");
            select.append(" SI.VPN, ");
            select.append(" QD.QTY_DISCREPANCY_ID, ");
            select.append(" IM.ITEM_LEVEL, ");
            select.append(" IM.TRAN_LEVEL, ");
            select.append(" QD.DEBIT_MEMO_REASON_CODE, ");
            select.append(" QD.RESOLUTION_QTY, ");
            select.append(" QD.DOC_ID ");

            fromClause.append(" FROM IM_QTY_DISCREPANCY QD, ");
            fromClause.append(" ITEM_MASTER IM, ");
            fromClause.append(" V_IM_ORDLOC_STORES_PHYS_WH OL, ");
            fromClause.append(" ORDSKU OS, ");
            fromClause
                    .append(" (Select SI.item,"
                            + "nvl(L2.supplier_id,si.supplier) Supplier,"
                            + "SI.VPN from item_supplier si ,"
                            + "IM_SUPPLIER_GROUP_MEMBERS L1,"
                            + "IM_SUPPLIER_GROUP_MEMBERS L2 "
                            + "where  SI.supplier=L1.supplier_id(+)"
                            + " and L1.group_id=L2.group_id(+) and si.supplier in ( select supplier from IM_QTY_DISCREPANCY where doc_id=? )) SI, ");

            // Calculate the quantity received. For a discrepancy, there may be
            // no receipt against
            // the invoice line, in that case the qty
            // received is zero. If there is a receipt(s), it may be partially
            // matched. In that
            // case, only the unmatched portion is associated
            // with this discrepancy.
            fromClause.append("(SELECT /*+ ORDERED */"
                    + " SUM(SHP.QTY_RECEIVED) - NVL(MRI.QTY_MATCHED,0) QTY_RECEIVED,"
                    + " QD.QTY_DISCREPANCY_ID QTY_DISCREPANCY_ID" + " FROM"
                    + "  IM_QTY_DISCREPANCY_RECEIPT QR," + "  IM_QTY_DISCREPANCY QD,"
                    + "  v_im_shipsku SHP," + "  IM_PARTIALLY_MATCHED_RECEIPTS MRI"
                    + " WHERE QD.QTY_DISCREPANCY_ID = QR.QTY_DISCREPANCY_ID"
                    + "   AND QR.RECEIPT_ID = SHP.SHIPMENT" + "   AND QD.ITEM = SHP.ITEM"
                    + "   AND MRI.SHIPMENT (+) = SHP.SHIPMENT" + "   AND MRI.ITEM (+) = SHP.ITEM"
                    + " GROUP BY QD.QTY_DISCREPANCY_ID, MRI.QTY_MATCHED) QTY ");

            whereClause.append(" WHERE QD.ORDER_NO   = ? ");
            whereClause.append(" AND QD.DOC_ID       = ? ");
            whereClause.append(" AND QD.LOCATION     = ? ");
            //whereClause.append(" AND TRUNC(QD.RESOLVE_BY_DATE) = ? ");
            whereClause.append(" AND QD.AP_REVIEWER   = ? ");
            whereClause.append(" AND IM.ITEM          = QD.ITEM ");
            whereClause.append(" AND OL.ORDER_NO (+)  = QD.ORDER_NO ");
            whereClause.append(" AND OL.ITEM (+)      = QD.ITEM ");
            whereClause.append(" AND OL.LOCATION (+)  = QD.LOCATION ");
            whereClause.append(" AND SI.ITEM (+)         = QD.ITEM ");
            whereClause.append(" AND OS.ORDER_NO (+)  = QD.ORDER_NO ");
            whereClause.append(" AND OS.ITEM (+)      = QD.ITEM ");
            whereClause.append(" AND QD.QTY_DISCREPANCY_ID = QTY.QTY_DISCREPANCY_ID (+) ");
            whereClause.append(additionalWhereClause);
        } else // credit memo qty
        {
            select.append(" SELECT  QD.ITEM, ");
            select.append(" IM.ITEM_DESC ");
            select.append(" DESC_UP, OL.TOTAL_QTY_ORDERED QTY_ORDERED, ");
            select.append(" QD.QTY_INVOICED, ");
            select.append(" null QTY_RECEIVED, ");
            select.append(" OS.REF_ITEM, ");
            select.append(" SI.VPN, ");
            select.append(" QD.QTY_DISCREPANCY_ID, ");
            select.append(" IM.ITEM_LEVEL, ");
            select.append(" IM.TRAN_LEVEL, ");
            select.append(" QD.DEBIT_MEMO_REASON_CODE, ");
            select.append(" QD.RESOLUTION_QTY, ");
            select.append(" QD.DOC_ID ");

            fromClause.append(" FROM IM_QTY_DISCREPANCY QD, ");
            fromClause.append(" ITEM_MASTER IM, ");
            fromClause.append(" V_IM_ORDLOC_STORES_PHYS_WH OL, ");
            fromClause.append(" ORDSKU OS, ");
            fromClause
                    .append(" (Select SI.item,"
                            + "nvl(L2.supplier_id,si.supplier) Supplier,"
                            + "SI.VPN from item_supplier si ,"
                            + "IM_SUPPLIER_GROUP_MEMBERS L1,"
                            + "IM_SUPPLIER_GROUP_MEMBERS L2 "
                            + "where  SI.supplier=L1.supplier_id(+)"
                            + " and L1.group_id=L2.group_id(+) and si.supplier in ( select supplier from IM_QTY_DISCREPANCY where doc_id=? )) SI ");

            whereClause.append(" WHERE (QD.ORDER_NO   = ? OR ? IS NULL) ");
            whereClause.append(" AND QD.DOC_ID        = ? ");
            whereClause.append(" AND (QD.LOCATION     = ? OR ? IS NULL) ");
            //whereClause.append(" AND TRUNC(QD.RESOLVE_BY_DATE) = ? ");
            whereClause.append(" AND QD.AP_REVIEWER   = ? ");
            whereClause.append(" AND IM.ITEM          = QD.ITEM ");
            whereClause.append(" AND OL.ORDER_NO     (+) = QD.ORDER_NO ");
            whereClause.append(" AND OL.ITEM         (+) = QD.ITEM ");
            whereClause.append(" AND OL.LOCATION     (+) = QD.LOCATION ");
            whereClause.append(" AND SI.ITEM         (+) = QD.ITEM ");
            whereClause.append(" AND SI.SUPPLIER     (+) = QD.SUPPLIER ");
            whereClause.append(" AND OS.ORDER_NO     (+) = QD.ORDER_NO ");
            whereClause.append(" AND OS.ITEM         (+) = QD.ITEM ");
            whereClause.append(additionalWhereClause);

            groupByAfter.append(" GROUP BY QD.ITEM, ");
            groupByAfter.append(" IM.ITEM_DESC, ");
            groupByAfter.append(" OL.TOTAL_QTY_ORDERED, ");
            groupByAfter.append(" QD.QTY_INVOICED, ");
            groupByAfter.append(" null, ");
            groupByAfter.append(" OS.REF_ITEM, ");
            groupByAfter.append(" SI.VPN, ");
            groupByAfter.append(" QD.QTY_DISCREPANCY_ID, ");
            groupByAfter.append(" IM.ITEM_LEVEL, ");
            groupByAfter.append(" IM.TRAN_LEVEL, ");
            groupByAfter.append(" QD.DEBIT_MEMO_REASON_CODE, ");
            groupByAfter.append(" QD.RESOLUTION_QTY, ");
            groupByAfter.append(" QD.DOC_ID ");
        }

        orderSql.append(" ORDER BY QD.ITEM, ");
        orderSql.append(" DESC_UP, ");
        orderSql.append(" QTY_ORDERED, ");
        orderSql.append(" QD.QTY_INVOICED, ");
        orderSql.append(" QTY_RECEIVED, ");
        orderSql.append(" SI.VPN, ");
        orderSql.append(" QD.DEBIT_MEMO_REASON_CODE, ");
        orderSql.append(" QD.RESOLUTION_QTY, ");
        orderSql.append(" QD.DOC_ID ");

        return select.append(fromClause.toString()).append(whereClause.toString()).append(
                groupByAfter.toString()).append(orderSql.toString());
    }
    
    private DiscrepancyQuantityReviewDetail[] createQuantityReviewDetailFromRS(ResultSet rs,
            String docId) throws Exception {
        ArrayList quantityDiscrepancies = new ArrayList();
        int transactionLevel;
        int itemLevel;
        while (rs.next()) {
            DiscrepancyQuantityReviewDetail quantityDiscrepancy = new DiscrepancyQuantityReviewDetail();

            Item item = new Item();
            item.setItemId(rs.getString("ITEM"));
            item.setItemName(rs.getString("DESC_UP"));

            quantityDiscrepancy.setItem(item);

            // only set the Double value populated otherwise rs will return 0
            rs.getDouble("QTY_ORDERED");
            if (!rs.wasNull())
                quantityDiscrepancy.setQtyOrdered(new Double(rs.getDouble("QTY_ORDERED")));

            rs.getDouble("QTY_INVOICED");
            if (!rs.wasNull())
                quantityDiscrepancy.setQtyInvoiced(new Double(rs.getDouble("QTY_INVOICED")));

            rs.getDouble("QTY_RECEIVED");
            if (!rs.wasNull())
                quantityDiscrepancy.setTotalReceiptQty(new Double(rs.getDouble("QTY_RECEIVED")));

            rs.getDouble("RESOLUTION_QTY");
            if (!rs.wasNull())
                quantityDiscrepancy
                        .setResolutionQuantity(new Double(rs.getDouble("RESOLUTION_QTY")));

            transactionLevel = rs.getInt("TRAN_LEVEL");
            itemLevel = rs.getInt("ITEM_LEVEL");
            if (itemLevel > transactionLevel) {
                String refItem = rs.getString("REF_ITEM");
                quantityDiscrepancy.setOrderUPC((refItem != null ? refItem : item.getItemId()));
            } else {
              //  quantityDiscrepancy.setOrderUPC(item.getItemId());
            	// OLR SMR MOD Anil Potukuchi : Don't need to show item
            }

            quantityDiscrepancy.setVPN(rs.getString("VPN"));
            quantityDiscrepancy.setQtyDiscrepancyId(rs.getLong("QTY_DISCREPANCY_ID"));
            quantityDiscrepancy.setDebitMemoReasonCode(rs.getString("DEBIT_MEMO_REASON_CODE"));
            quantityDiscrepancy.setDocId(Long.parseLong(docId));

            quantityDiscrepancies.add(quantityDiscrepancy);
        }

        return (DiscrepancyQuantityReviewDetail[]) quantityDiscrepancies
                .toArray(new DiscrepancyQuantityReviewDetail[quantityDiscrepancies.size()]);
    }

    private static final String GET_CC_SUP = "SELECT CURRENCY_CODE, SUPPLIER FROM ORDHEAD WHERE ORDER_NO = ?";

    public Order getReceiptInfoFromOrderNo(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(GET_CC_SUP);
            stmt.setString(1, orderNo);
            resultSet = stmt.executeQuery();

            Order order = null;

            if (resultSet.next()) {
                order = new Order();
                order.setOrderCurrency(resultSet.getString("CURRENCY_CODE"));
                order.setSupplierId(resultSet.getString("SUPPLIER"));
                order.setOrderNo(orderNo);
            }

            return order;
        } catch (Exception exception) {
            throw new ReIMException("error.retrieving_curr_code_supplier", Severity.ERROR,
                    exception, this, new String[] { orderNo});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_curr_code_supplier.close_stmt_rs",
                        Severity.ERROR, e, this);
            }
        }

    }

    public ArrayList selectDiscrepenciesByItemCosts(String itemId, double orderCost,
            double invoiceCost,String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            String sqlQuery = "SELECT DISTINCT CD.COST_DISCREPANCY_ID,  CD.DOC_ID,  CD.ITEM "
                    + "FROM IM_COST_DISCREPANCY CD, v_im_ordloc OL " + "WHERE CD.ITEM = OL.ITEM "
                    + "AND CD.ORDER_NO = OL.ORDER_NO " 
                    + "AND CD.ORDER_NO =? "
                    + "AND CD.ITEM =? "
                    + "AND OL.UNIT_COST = ? " + "AND CD.DOC_UNIT_COST = ? " + "AND CD.DOC_TYPE = '"
                    + Document.MERCHANDISE_INVOICE + "' "
                    + "AND NOT EXISTS ( SELECT 1 FROM IM_RESOLUTION_ACTION RA "
                    + " WHERE RA.DOC_ID = CD.DOC_ID " + "   AND RA.ITEM   = ? "
                    + "   AND RA.ACTION IN (" + sqlCommaList(ReasonCode.COST_INVOICE_ACTIONS)
                    + ")) ";
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlQuery);
            stmt.setString(1, orderNo);
            stmt.setString(2, itemId);
            stmt.setDouble(3, orderCost);
            stmt.setDouble(4, invoiceCost);
            stmt.setString(5, itemId);

            resultSet = stmt.executeQuery();

            ArrayList discrepancies = new ArrayList();
            
            while (resultSet.next()) {
                StringBuffer discrepancy = new StringBuffer();
                discrepancy.append(resultSet.getString("COST_DISCREPANCY_ID"));
                discrepancy.append('^');
                discrepancy.append(resultSet.getLong("DOC_ID"));
                discrepancy.append('^');
                discrepancy.append(resultSet.getString("ITEM"));
                discrepancy.append('^');
                discrepancies.add(discrepancy);
            }

            return discrepancies;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_discrepancies_for_item", Severity.ERROR,
                    exception, this, new String[] { itemId});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException(
                        "error.cannot_retrieve_discrepancies_for_item.close_stmt_rs",
                        Severity.ERROR, e, this, new String[] { itemId});
            }
        }
    }

    public DiscrepancyCostReviewDetail[] readDiscrepancyDetailsByDiscrepancyId(long discrepancyId, boolean isSupplierSiteIndOn)
            throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlMain = new StringBuffer();

            String intlDesc = " IM.ITEM_DESC DESC_UP ";
            String intlFromClause = "";
            String intlWhereClause = "";

            sqlMain = createCostDiscrepancyDetailsQuery(intlDesc, intlFromClause, intlWhereClause, isSupplierSiteIndOn);
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlMain.toString());
            stmt.setLong(1, discrepancyId);
            stmt.setLong(2, discrepancyId);
            stmt.setLong(3, discrepancyId);
            // BRN OLR 135775 No need to bind as the query is modified.
            // BRN OLR 191135 - uncommented below line
           stmt.setLong(4, discrepancyId);
           // stmt.setLong(5, discrepancyId);

            rs = stmt.executeQuery();

            DiscrepancyCostReviewDetail[] data = createCostReviewDetailFromRS(rs);

            // do refactored data translation on item description and location
            // name
            String userLang = ReIMUserContext.getUserLanguage();
            if (data != null && DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setItemDesc(DataTranslationService.getItemDesc(data[i].getItemDesc(),
                            userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.retrieving_cost_discrepancy_details_by_discrepancy_id",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_cost_discrepancy_discrepancy_id",
                        Severity.ERROR, e, this);
            }
        }
    }

    private StringBuffer createCostDiscrepancyDetailsQuery(String intlDesc, String intlFromClause,
            String intlWhereClause, boolean isSupplierSiteIndOn) {
        StringBuffer sql = new StringBuffer();

        sql.append(" SELECT CD.DOC_ID, CD.ITEM,");
        sql.append(intlDesc); 
        sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST UNIT_COST_INIT, ");
        sql.append(" OL.UNIT_COST, CD.DOC_UNIT_COST, ");
        sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
        sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC, ");
        
        sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
        sql
                .append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
        sql.append(" FROM IM_COST_DISCREPANCY CD, ");
        sql.append(" ITEM_MASTER IM, ");
        sql.append(" ORDSKU OS, ");
        sql.append(" v_im_ordloc OL, ");
        sql.append(" ITEM_SUPPLIER SI ");
        sql.append(intlFromClause);
        sql.append(" WHERE CD.COST_DISCREPANCY_ID= ? ");
        sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OS.ITEM (+) ");
        sql.append(" AND CD.ORDER_NO = OL.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OL.ITEM (+) ");
        sql.append(" AND CD.LOCATION = OL.LOCATION (+) ");
        sql.append(" AND OL.LOC_TYPE = 'S' ");
        sql.append(" AND CD.ITEM = SI.ITEM (+) ");
        sql.append(" AND CD.SUPPLIER = SI.SUPPLIER (+) ");
        sql.append(" AND CD.ITEM = IM.ITEM ");
        sql.append(intlWhereClause);
        sql.append("UNION");
        sql.append(" SELECT CD.DOC_ID, CD.ITEM,");
        sql.append(intlDesc);
        sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST UNIT_COST_INIT, ");
        sql.append(" OL.UNIT_COST, CD.DOC_UNIT_COST, ");
        sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
        sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC, ");
        
        sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
        sql
                .append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
        sql.append(" FROM IM_COST_DISCREPANCY CD, ");
        sql.append(" ITEM_MASTER IM, ");
        sql.append(" ORDSKU OS, ");
        sql.append(" v_im_ordloc OL, ");
        sql.append(" ITEM_SUPPLIER SI, WH ");
        sql.append(intlFromClause);
        sql.append(" WHERE CD.COST_DISCREPANCY_ID= ? ");
        sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OS.ITEM (+) ");
        sql.append(" AND CD.ORDER_NO = OL.ORDER_NO (+) ");
        sql.append(" AND CD.ITEM = OL.ITEM (+) ");
        sql.append(" AND CD.LOCATION = WH.PHYSICAL_WH(+) ");
        sql.append(" AND WH.WH = OL.LOCATION ");
        sql.append(" AND OL.LOC_TYPE = 'W' ");
        sql.append(" AND CD.ITEM = SI.ITEM (+) ");
        sql.append(" AND CD.SUPPLIER = SI.SUPPLIER (+) ");
        sql.append(" AND CD.ITEM = IM.ITEM ");
        sql.append(intlWhereClause);
        
        sql.append("UNION");
        sql.append(" SELECT CD.DOC_ID, CD.ITEM,");
        sql.append(intlDesc);
        sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST UNIT_COST_INIT, ");
        sql.append(" OL.UNIT_COST  , CD.DOC_UNIT_COST, ");
        sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
        sql.append(" DECODE(OL.UNIT_COST, 0, 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC, ");
        sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
        sql
                .append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
        sql.append(" FROM IM_COST_DISCREPANCY CD, ");
        sql.append(" ITEM_MASTER IM, ");
        sql.append(" ORDSKU OS, ");
        sql.append(" v_im_ordloc OL, ");
        sql.append(" SHIPMENT SH, ");
        sql.append(" SHIPSKU SS, ");
        sql.append(" ITEM_SUPPLIER SI, WH, SUPS SP ");
        sql.append(intlFromClause);        
        sql.append(" WHERE CD.ORDER_NO = OS.ORDER_NO ");
        sql.append(" AND CD.ITEM = OS.ITEM ");
        sql.append(" AND CD.ORDER_NO = SH.ORDER_NO ");
        sql.append(" AND CD.LOCATION = SH.BILL_TO_LOC ");
        sql.append(" AND SH.SHIPMENT = SS.SHIPMENT ");
        sql.append(" AND SS.ITEM = CD.ITEM ");        
        sql.append(" AND WH.PHYSICAL_WH = SH.TO_LOC ");
        sql.append(" AND WH.WH = OL.LOCATION ");
        sql.append(" AND CD.ORDER_NO = OL.ORDER_NO ");
        sql.append(" AND CD.ITEM = OL.ITEM ");       
        sql.append(" AND OL.LOC_TYPE = 'W' ");
        sql.append(" AND CD.ITEM = SI.ITEM ");
        if(isSupplierSiteIndOn){
            sql.append(" AND CD.SUPPLIER = SP.SUPPLIER_PARENT ");
            sql.append(" AND SP.SUPPLIER = SI.SUPPLIER ");
        }
        else{
            sql.append(" AND CD.SUPPLIER = SI.SUPPLIER ");
        }
        sql.append(" AND CD.ITEM = IM.ITEM ");
        sql.append(" AND CD.COST_DISCREPANCY_ID= ?  ");
        sql.append(intlWhereClause);

        // BRN OLR 135775 Query was returning all locations from ORDLOC and inserted multiple records in Im_resolution_action for all SDCs.
        // that could result in incorrect RCA.
        
        // BRN OLR 191135 Begin - added to read the corresponding record from ORDLOC based on the DEFAULT_WH from STORE
        sql.append("UNION");
        sql.append (" SELECT distinct cd.doc_id, cd.item, im.item_desc desc_up, cd.currency_code,\n" + 
        "       ol.unit_cost unit_cost_init, ol.unit_cost, cd.doc_unit_cost,\n" + 
        "       ol.unit_cost - cd.doc_unit_cost VARIANCE,\n" + 
        "       DECODE (ol.unit_cost,\n" + 
        "               0, 100,\n" + 
        "               ((ol.unit_cost - cd.doc_unit_cost) / ol.unit_cost) * 100\n" + 
        "              ) variance_pc,\n" + 
        "       os.ref_item, ol.cost_source, si.vpn, cd.resolution_cost,\n" + 
        "       cd.debit_memo_reason_code, cd.cost_discrepancy_id\n" + 
        "  FROM im_cost_discrepancy cd,\n" + 
        "       item_master im,\n" + 
        "       ordsku os,\n" + 
        "       v_im_ordloc ol,\n" + 
        "       item_supplier si,\n" + 
        "       store st,\n" + 
        "       sups sp\n" + 
        " WHERE cd.order_no = os.order_no\n" + 
        "   AND cd.item = os.item\n" +
        "   AND cd.location = st.store\n" + 
        "   AND st.default_wh = ol.LOCATION\n" + 
        "   AND cd.order_no = ol.order_no\n"  + 
        "   AND not exists (select 1\n" + 
        "                              from shipment sh, shipsku ss \n" + 
        "                             where sh.order_no = ol.order_no\n" + 
        "                               and sh.bill_to_loc = cd.location \n" +
        "                               and ss.shipment = sh.shipment\n" + 
        "                               and ss.item = cd.item ) " +
        "   AND cd.item = ol.item\n" + 
        "   AND ol.loc_type = 'W'\n" + 
        "   AND cd.item = si.item\n" + 
        "   AND cd.supplier = sp.supplier_parent\n" + 
        "   AND sp.supplier = si.supplier\n" + 
        "   AND cd.item = im.item\n" + 
        "   AND cd.cost_discrepancy_id = ? ");   
        // BRN OLR 191135 End
//        sql.append(" SELECT distinct CD.DOC_ID, CD.ITEM,");
//        sql.append(intlDesc);
//        sql.append(", CD.CURRENCY_CODE, ss.unit_cost, ");
//        sql.append(" ss.unit_cost, CD.DOC_UNIT_COST, ");
//        sql.append(" ss.unit_cost - CD.DOC_UNIT_COST VARIANCE, ");
//        sql.append(" DECODE(ss.unit_cost, 0, 100, ((ss.unit_cost- CD.DOC_UNIT_COST)/ss.unit_cost)*100) VARIANCE_PC, ");
//        sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
//        sql.append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
//        sql.append(" FROM IM_COST_DISCREPANCY CD, ");
//        sql.append(" ITEM_MASTER IM, ");
//        sql.append(" ORDSKU OS, ");
//        sql.append(" v_im_ordloc OL, ");
//        sql.append(" SHIPMENT SH, ");
//        sql.append(" SHIPSKU SS, ");
//        sql.append(" ITEM_SUPPLIER SI, WH, SUPS SP ");
//        sql.append(intlFromClause);        
//        sql.append(" WHERE CD.ORDER_NO = OS.ORDER_NO ");
//        sql.append(" AND CD.ITEM = OS.ITEM ");
//        sql.append(" AND CD.ORDER_NO = SH.ORDER_NO ");
//        sql.append(" AND CD.LOCATION = SH.BILL_TO_LOC ");
//        sql.append(" AND SH.SHIPMENT = SS.SHIPMENT ");
//        sql.append("     AND ss.item not in (select icd.item from im_cost_discrepancy icd, shipsku ss, ordsku os, shipment shp\n" + 
//        "                                   where icd.cost_discrepancy_id = ? \n" + 
//        "                                      and icd.order_no = os.order_no\n" + 
//        "                                      and os.item = icd.item\n" + 
//        "                                      and shp.order_no = os.order_no\n" + 
//        "                                      and ss.shipment = shp.shipment) ");        
//        sql.append(" AND WH.PHYSICAL_WH = SH.TO_LOC ");
//        sql.append(" AND WH.WH = OL.LOCATION ");
//        sql.append(" AND CD.ORDER_NO = OL.ORDER_NO ");
//        sql.append(" AND CD.ITEM = OL.ITEM ");       
//        sql.append(" AND OL.LOC_TYPE = 'W' ");
//        sql.append(" AND ss.item = si.item ");
//        sql.append(" AND CD.ITEM = SI.ITEM ");
//        if(isSupplierSiteIndOn){
//            sql.append(" AND CD.SUPPLIER = SP.SUPPLIER_PARENT ");
//            sql.append(" AND SP.SUPPLIER = SI.SUPPLIER ");
//        }
//        else{
//            sql.append(" AND CD.SUPPLIER = SI.SUPPLIER ");
//        }
//        sql.append(" AND CD.ITEM = IM.ITEM ");
//        sql.append(" AND CD.COST_DISCREPANCY_ID= ? ");
//        sql.append(intlWhereClause);

        return sql;
    }

// Anil P added the following method


 private StringBuffer createCostDiscrepancyDetailsQuery(String intlDesc, String intlFromClause,
         String intlWhereClause, boolean isSupplierSiteIndOn, String  item) {
     StringBuffer sql = new StringBuffer();

     sql.append(" SELECT CD.DOC_ID, CD.ITEM,");
     sql.append(intlDesc);
     sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST UNIT_COST_INIT, ");
     sql.append(" OL.UNIT_COST , CD.DOC_UNIT_COST, ");
     sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
     sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC, ");
     
     sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
     sql
             .append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
     sql.append(" FROM IM_COST_DISCREPANCY CD, ");
     sql.append(" ITEM_MASTER IM, ");
     sql.append(" ORDSKU OS, ");
     sql.append(" v_im_ordloc OL, ");
     sql.append(" ITEM_SUPPLIER SI ");
     sql.append(intlFromClause);
     sql.append(" WHERE CD.COST_DISCREPANCY_ID= ? ");
     sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
     sql.append(" AND CD.ITEM = OS.ITEM (+) ");
     sql.append(" AND CD.ORDER_NO = OL.ORDER_NO (+) ");
     sql.append(" AND CD.ITEM = OL.ITEM (+) ");
     sql.append(" AND CD.LOCATION = OL.LOCATION (+) ");
     sql.append(" AND OL.LOC_TYPE = 'S' ");
     sql.append(" AND CD.ITEM = SI.ITEM (+) ");
     sql.append(" AND CD.SUPPLIER = SI.SUPPLIER (+) ");
     sql.append(" AND CD.ITEM = IM.ITEM ");
     sql.append(intlWhereClause);
     sql.append("UNION");
     sql.append(" SELECT CD.DOC_ID, CD.ITEM,");
     sql.append(intlDesc);
     sql.append(", CD.CURRENCY_CODE, OL.UNIT_COST UNIT_COST_INIT, ");
     sql.append(" OL.UNIT_COST, CD.DOC_UNIT_COST, ");
     sql.append(" OL.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
     sql.append(" DECODE (OL.UNIT_COST, 0 , 100, ((OL.UNIT_COST - CD.DOC_UNIT_COST)/OL.UNIT_COST)*100) VARIANCE_PC, ");
     
     sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
     sql
             .append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
     sql.append(" FROM IM_COST_DISCREPANCY CD, ");
     sql.append(" ITEM_MASTER IM, ");
     sql.append(" ORDSKU OS, ");
     sql.append(" v_im_ordloc OL, ");
     sql.append(" ITEM_SUPPLIER SI, WH ");
     sql.append(intlFromClause);
     sql.append(" WHERE CD.COST_DISCREPANCY_ID= ? ");
     sql.append(" AND CD.ORDER_NO = OS.ORDER_NO (+) ");
     sql.append(" AND CD.ITEM = OS.ITEM (+) ");
     sql.append(" AND CD.ORDER_NO = OL.ORDER_NO (+) ");
     sql.append(" AND CD.ITEM = OL.ITEM (+) ");
     sql.append(" AND CD.LOCATION = WH.PHYSICAL_WH(+) ");
     sql.append(" AND WH.WH = OL.LOCATION ");
     sql.append(" AND OL.LOC_TYPE = 'W' ");
     sql.append(" AND CD.ITEM = SI.ITEM (+) ");
     sql.append(" AND CD.SUPPLIER = SI.SUPPLIER (+) ");
     sql.append(" AND CD.ITEM = IM.ITEM ");
     sql.append(intlWhereClause);
     
     sql.append("UNION");
     sql.append(" SELECT CD.DOC_ID, CD.ITEM,");
     sql.append(intlDesc);
     sql.append(", CD.CURRENCY_CODE, SS.UNIT_COST UNIT_COST_INIT, ");
     sql.append(" SS.UNIT_COST , CD.DOC_UNIT_COST, ");
     sql.append(" SS.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
     sql.append(" DECODE(OL.UNIT_COST, 0, 100, ((SS.UNIT_COST - CD.DOC_UNIT_COST)/SS.UNIT_COST)*100) VARIANCE_PC, ");
     sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
     sql
             .append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
     sql.append(" FROM IM_COST_DISCREPANCY CD, ");
     sql.append(" ITEM_MASTER IM, ");
     sql.append(" ORDSKU OS, ");
     sql.append(" v_im_ordloc OL, ");
     sql.append(" SHIPMENT SH, ");
     sql.append(" SHIPSKU SS, ");
     sql.append(" ITEM_SUPPLIER SI, WH, SUPS SP ");
     sql.append(intlFromClause);        
     sql.append(" WHERE CD.ORDER_NO = OS.ORDER_NO ");
     sql.append(" AND CD.ITEM = OS.ITEM ");
     sql.append(" AND CD.ORDER_NO = SH.ORDER_NO ");
     sql.append(" AND CD.LOCATION = SH.BILL_TO_LOC ");
     sql.append(" AND SH.SHIPMENT = SS.SHIPMENT ");
     sql.append(" AND SS.ITEM = CD.ITEM ");        
     sql.append(" AND WH.PHYSICAL_WH = SH.TO_LOC ");
     sql.append(" AND WH.WH = OL.LOCATION ");
     sql.append(" AND CD.ORDER_NO = OL.ORDER_NO ");
     sql.append(" AND CD.ITEM = OL.ITEM ");       
     sql.append(" AND CD.ITEM = ? ");       
     sql.append(" AND OL.LOC_TYPE = 'W' ");
     sql.append(" AND CD.ITEM = SI.ITEM ");
     if(isSupplierSiteIndOn){
         sql.append(" AND CD.SUPPLIER = SP.SUPPLIER_PARENT ");
         sql.append(" AND SP.SUPPLIER = SI.SUPPLIER ");
     }
     else{
         sql.append(" AND CD.SUPPLIER = SI.SUPPLIER ");
     }
     sql.append(" AND CD.ITEM = IM.ITEM ");
     sql.append(" AND CD.COST_DISCREPANCY_ID= ? ");
     sql.append(intlWhereClause);

     // Anil P another Mod

     sql.append("UNION");
     sql.append(" SELECT distinct CD.DOC_ID, CD.ITEM,");
     sql.append(intlDesc);
     sql.append(", CD.CURRENCY_CODE, ol.UNIT_COST UNIT_COST_INIT, ");
     sql.append(" SS.unit_cost , CD.DOC_UNIT_COST, ");
     sql.append(" SS.unit_cost - CD.DOC_UNIT_COST VARIANCE, ");
     sql.append(" DECODE(ss.unit_cost, 0, 100, ((ss.unit_cost- CD.DOC_UNIT_COST)/ss.unit_cost)*100) VARIANCE_PC, ");
     sql.append(" OS.REF_ITEM, OL.COST_SOURCE, ");
     sql.append(" SI.VPN, CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
     sql.append(" FROM IM_COST_DISCREPANCY CD, ");
     sql.append(" ITEM_MASTER IM, ");
     sql.append(" ORDSKU OS, ");
     sql.append(" v_im_ordloc OL, ");
     sql.append(" SHIPMENT SH, ");
     sql.append(" SHIPSKU SS, ");
     sql.append(" ITEM_SUPPLIER SI, WH, SUPS SP ");
     sql.append(intlFromClause);        
     sql.append(" WHERE CD.ORDER_NO = OS.ORDER_NO ");
     sql.append(" AND CD.ITEM = OS.ITEM ");
     sql.append(" AND CD.ORDER_NO = SH.ORDER_NO ");
     sql.append(" AND CD.LOCATION = SH.BILL_TO_LOC ");
     sql.append(" AND SH.SHIPMENT = SS.SHIPMENT ");
     sql.append("     AND ss.item not in (select icd.item from im_cost_discrepancy icd, shipsku ss, ordsku os, shipment shp\n" + 
     "                                   where icd.cost_discrepancy_id = ? \n" + 
     "                                      and icd.order_no = os.order_no\n" + 
     "                                      and os.item = icd.item\n" + 
     "                                      and shp.order_no = os.order_no\n" + 
     "                                      and ss.shipment = shp.shipment) ");        
     sql.append(" AND WH.PHYSICAL_WH = SH.TO_LOC ");
     sql.append(" AND WH.WH = OL.LOCATION ");
     sql.append(" AND CD.ORDER_NO = OL.ORDER_NO ");
     sql.append(" AND CD.ITEM = OL.ITEM ");    
     sql.append(" AND CD.ITEM =? ");  
     sql.append(" AND SS.ITEM =? ");  
     sql.append(" AND OL.LOC_TYPE = 'W' ");
     sql.append(" AND CD.ITEM = SI.ITEM ");
     if(isSupplierSiteIndOn){
         sql.append(" AND CD.SUPPLIER = SP.SUPPLIER_PARENT ");
         sql.append(" AND SP.SUPPLIER = SI.SUPPLIER ");
     }
     else{
         sql.append(" AND CD.SUPPLIER = SI.SUPPLIER ");
     }
     sql.append(" AND CD.ITEM = IM.ITEM ");
     sql.append(" AND CD.COST_DISCREPANCY_ID= ? ");
     sql.append(intlWhereClause);
     
     sql.append("UNION");
     sql.append("          SELECT distinct cd.doc_id, cd.item, im.item_desc desc_up, cd.currency_code, ");
         sql.append("             ss.unit_cost UNIT_COST_init, ss.unit_cost, cd.doc_unit_cost,  ");
         sql.append("                   ss.unit_cost - cd.doc_unit_cost VARIANCE, ");
         sql.append("                   DECODE (ss.unit_cost, 0, 100, ((ss.unit_cost - cd.doc_unit_cost) / ss.unit_cost )* 100) variance_pc,");
         sql.append("                   null ref_item, 'NORM' cost_source, si.vpn, cd.resolution_cost,");
         sql.append("                cd.debit_memo_reason_code, cd.cost_discrepancy_id ");
         sql.append("           FROM im_cost_discrepancy cd, ");
         sql.append("                item_master im, ");
         sql.append("                shipment sh, ");
         sql.append("                shipsku ss, ");
         sql.append("                item_supplier si,  ");
         sql.append("                wh, ");
         sql.append("                sups sp ");
         sql.append("          WHERE cd.item = im.item ");
         sql.append("             AND ss.shipment = sh.shipment ");
         sql.append("             AND cd.order_no = sh.order_no ");
         sql.append("             AND cd.item = ss.item ");
         sql.append("             and not exists (select 1 from ordloc ");
         sql.append("                               where order_no = cd.order_no "); 
         sql.append("                                 and item  = cd.item ");
         sql.append("                                 and location in (select default_wh ");
         sql.append("                                                     from store ");
         sql.append("                                                    where store = cd.location)) ");
         sql.append("             AND si.item = cd.item  ");
         sql.append("             AND wh.physical_wh = sh.to_loc  ");
         sql.append("             AND cd.supplier = sp.supplier_parent ");
         sql.append("             AND sp.supplier = si.supplier   ");
         sql.append("             AND cd.cost_discrepancy_id = ?  ");
         
         //BNaik for Manual Group
         sql.append(" UNION ");
         sql.append(" SELECT DISTINCT CD.DOC_ID, CD.ITEM INVCITEM, ");
         sql.append(" IM.ITEM_DESC DESC_UP, CD.CURRENCY_CODE, ");
         sql.append(" SHIPITEM.UNIT_COST, SHIPITEM.UNIT_COST, CD.DOC_UNIT_COST, ");
         sql.append(" SHIPITEM.UNIT_COST - CD.DOC_UNIT_COST VARIANCE, ");
         sql.append(" DECODE (SHIPITEM.UNIT_COST, ");
         sql.append("    0, 100, ((SHIPITEM.UNIT_COST - CD.DOC_UNIT_COST) / SHIPITEM.UNIT_COST ) * 100 ");
         sql.append("    ) VARIANCE_PC, ");
         sql.append("   NULL REF_ITEM, 'NORM' COST_SOURCE, SI.VPN, CD.RESOLUTION_COST, ");
         sql.append("  CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID ");
         sql.append(" FROM IM_COST_DISCREPANCY CD, ");
         sql.append("  ITEM_MASTER IM, ");
         sql.append("  (SELECT SK.ITEM, SK.UNIT_COST FROM SHIPSKU SK,  SHIPMENT SH ");
         sql.append("  WHERE SK.SHIPMENT = SH.SHIPMENT ");
         sql.append("  AND SH.ORDER_NO = ?  ");
         sql.append("  AND SH.BILL_TO_LOC = ? ");
         sql.append("  AND SK.ITEM = ? )  SHIPITEM, ");
         sql.append("  ITEM_SUPPLIER SI, ");
         sql.append("  SUPS SP ");
         sql.append("WHERE CD.ITEM = IM.ITEM ");
         sql.append("  AND SI.ITEM = CD.ITEM ");
         sql.append("  AND CD.SUPPLIER = SP.SUPPLIER_PARENT ");
         sql.append("  AND SP.SUPPLIER = SI.SUPPLIER ");
         sql.append("  AND CD.COST_DISCREPANCY_ID = ?  ");

     return sql;
 }

    public Double getExchangeRate(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        Double currencyCode = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT EXCHANGE_RATE FROM ORDHEAD WHERE ORDER_NO = ? ");
            stmt.setString(1, orderNo);
            rs = stmt.executeQuery();

            if (rs.next()) {
                rs.getDouble("EXCHANGE_RATE");
                if (!rs.wasNull()) {
                    currencyCode = new Double(rs.getDouble("EXCHANGE_RATE"));
                }
            }

            return currencyCode;
        } catch (Exception exception) {
            throw new ReIMException("error.error_retrieving_exchange_rate", Severity.ERROR,
                    exception, this, new String[] { orderNo});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.error_retrieving_exchange_rate", Severity.ERROR, e,
                        this, new String[] { orderNo});
            }
        }
    }

    public String selectSupplier(String orderNo) throws ReIMException {
        OraclePreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String supplier = null;

            pstmt = (OraclePreparedStatement) conn
                    .prepareStatement("select SUPPLIER from ORDHEAD where ORDER_NO = ?");

            pstmt.clearParameters();
            pstmt.setString(1, orderNo);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                supplier = rs.getString(1);
            }

            return supplier;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("Error.sql_error", Severity.ERROR, e, this);
            }
        }
    }

    public OrderLOV[] selectOrderDefaults(boolean matchToLinkedSupplier,
            boolean includeClosedOrders, boolean isSupplierSiteIndOn) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        StringBuffer selectSQLOrderDefaults = new StringBuffer();
        selectSQLOrderDefaults.append("SELECT A.ORDER_NO, A.STATUS ");
        selectSQLOrderDefaults.append("from ORDHEAD A, SUPS B, TERMS T ");

        if (isSupplierSiteIndOn) {
            selectSQLOrderDefaults.append(", SUPS C ");
        }

        String sqlPart1 = selectSQLOrderDefaults.toString();
        String sqlPart2 = " where B.SUPPLIER = A.SUPPLIER AND A.TERMS=T.TERMS AND T.ENABLED_FLAG='Y' ";
        selectSQLOrderDefaults.append(sqlPart2);

        if (isSupplierSiteIndOn) {
            selectSQLOrderDefaults.append(" AND C.SUPPLIER = B.SUPPLIER_PARENT ");
        }

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            String where = constructWhere(matchToLinkedSupplier, includeClosedOrders, isSupplierSiteIndOn);
            selectSQLOrderDefaults.append(where);
            sqlPart2 = sqlPart2 + where;
            selectSQLOrderDefaults.append(constructUnion(sqlPart1, sqlPart2, matchToLinkedSupplier,
                    isSupplierSiteIndOn));
            selectSQLOrderDefaults.append(orderBy);

            String query = selectSQLOrderDefaults.toString();

            rs = stmt.executeQuery(query);

            ArrayList dataList = new ArrayList(1);

            while (rs.next()) {
                dataList.add(new OrderLOV(rs.getString(1), ServiceFactory.getOrderService()
                        .getOrderStatusDesc(rs.getString(2))));
            }

            int l = dataList.size();
            OrderLOV data[] = new OrderLOV[l];
            dataList.toArray(data);

            return data;
        } catch (Exception e) {
            throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
            }
        }
    }

    public String getShipPaymentMethod(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        String shipPaymentMethod = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT SHIP_PAY_METHOD FROM ORDHEAD WHERE ORDER_NO = ? ");
            stmt.setString(1, orderNo);
            rs = stmt.executeQuery();

            if (rs.next()) {
                rs.getString("SHIP_PAY_METHOD");
                if (!rs.wasNull()) {
                    shipPaymentMethod = rs.getString("SHIP_PAY_METHOD");
                }
            }

            return shipPaymentMethod;
        } catch (Exception exception) {
            throw new ReIMException("error.error_retrieving_ship_payment_method", Severity.ERROR,
                    exception, this, new String[] { orderNo});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.error_retrieving_ship_payment_method",
                        Severity.ERROR, e, this, new String[] { orderNo});
            }
        }
    }

    public StringBuffer createZeroDiscrepancyWhereClause(String tableName) {
        StringBuffer whereClause = new StringBuffer();
        if (tableName.equals(ReIMConstants.COST_DISCREPANCY_TBL)) {
            whereClause.append(" COST_DISCREPANCY_ID IN(SELECT  CD.COST_DISCREPANCY_ID ");
            whereClause.append(" FROM  IM_COST_DISCREPANCY CD, ITEM_MASTER IM, v_im_ordloc OL, ");
            whereClause.append(" ORDSKU OS,ITEM_SUPPLIER SI,WH W,IM_DOC_HEAD DH ");
            whereClause.append(" WHERE CD.ITEM=IM.ITEM ");
            whereClause.append(" AND CD.ORDER_NO = OL.ORDER_NO ");
            whereClause.append(" AND CD.ITEM = OL.ITEM ");
            whereClause.append(" AND CD.LOCATION = W.PHYSICAL_WH ");
            whereClause.append(" AND W.WH = OL.LOCATION ");
            whereClause.append(" AND OL.LOC_TYPE = 'W' ");
            whereClause.append(" AND CD.ITEM = SI.ITEM ");
            whereClause.append(" AND CD.SUPPLIER IN (SELECT NVL(SUPPLIER_PARENT,SUPPLIER) FROM SUPS WHERE SUPPLIER = SI.SUPPLIER) ");            
            whereClause.append(" AND CD.ORDER_NO = OS.ORDER_NO ");
            whereClause.append(" AND CD.ITEM = OS.ITEM ");
            whereClause.append(" AND CD.DOC_ID = DH.DOC_ID ");
            whereClause.append(" AND DH.TYPE = '" + Document.MERCHANDISE_INVOICE + "' ");
            whereClause.append(" AND OL.UNIT_COST = CD.DOC_UNIT_COST ");
            whereClause.append(" UNION ALL ");
            whereClause.append(" SELECT CD.COST_DISCREPANCY_ID ");
            whereClause.append(" FROM IM_COST_DISCREPANCY CD, ITEM_MASTER IM, v_im_ordloc OL, ");
            whereClause.append(" ORDSKU OS, ITEM_SUPPLIER SI,IM_DOC_HEAD DH ");
            whereClause.append(" WHERE CD.ITEM=IM.ITEM ");
            whereClause.append(" AND CD.ORDER_NO = OL.ORDER_NO ");
            whereClause.append(" AND CD.ITEM = OL.ITEM ");
            whereClause.append(" AND CD.LOCATION = OL.LOCATION ");
            whereClause.append(" AND OL.LOC_TYPE = 'S' ");
            whereClause.append(" AND CD.ITEM = SI.ITEM ");
            whereClause.append(" AND CD.SUPPLIER IN (SELECT NVL(SUPPLIER_PARENT,SUPPLIER) FROM SUPS WHERE SUPPLIER = SI.SUPPLIER) ");            
            whereClause.append(" AND CD.ORDER_NO = OS.ORDER_NO ");
            whereClause.append(" AND CD.ITEM = OS.ITEM ");
            whereClause.append(" AND CD.DOC_ID = DH.DOC_ID ");
            whereClause.append(" AND DH.TYPE = '" + Document.MERCHANDISE_INVOICE + "' ");
            whereClause.append(" AND OL.UNIT_COST = CD.DOC_UNIT_COST ) ");
        }
        if (tableName.equals(ReIMConstants.QTY_DISCREPANCY_TBL)) {
            whereClause.append(" QTY_DISCREPANCY_ID IN( SELECT QD.QTY_DISCREPANCY_ID ");
            whereClause
                    .append(" FROM IM_QTY_DISCREPANCY QD,ITEM_MASTER IM, IM_DOC_HEAD DH, V_IM_ORDLOC_STORES_PHYS_WH OL,ORDSKU OS,ITEM_SUPPLIER SI, ");
            whereClause
                    .append(" (SELECT SUM(SHP.QTY_RECEIVED) - NVL(MRI.QTY_MATCHED, 0) QTY_RECEIVED, ");
            whereClause.append("  QD.QTY_DISCREPANCY_ID QTY_DISCREPANCY_ID ");
            whereClause
                    .append(" FROM IM_QTY_DISCREPANCY_RECEIPT QR, IM_QTY_DISCREPANCY QD,v_im_shipsku SHP, ");
            whereClause.append(" IM_PARTIALLY_MATCHED_RECEIPTS MRI ");
            whereClause.append(" WHERE QD.QTY_DISCREPANCY_ID = QR.QTY_DISCREPANCY_ID ");
            whereClause.append(" AND QR.RECEIPT_ID = SHP.SHIPMENT ");
            whereClause.append(" AND QD.ITEM = SHP.ITEM ");
            whereClause.append(" AND MRI.SHIPMENT (+) = SHP.SHIPMENT ");
            whereClause.append(" AND MRI.ITEM (+) = SHP.ITEM ");
            whereClause.append(" GROUP BY QD.QTY_DISCREPANCY_ID, MRI.QTY_MATCHED) QTY ");
            whereClause.append("WHERE IM.ITEM          = QD.ITEM ");
            whereClause.append("AND OL.ORDER_NO   = QD.ORDER_NO ");
            whereClause.append("AND OL.ITEM      = QD.ITEM ");
            whereClause.append("AND OL.LOCATION   = QD.LOCATION ");
            whereClause.append("AND SI.ITEM          = QD.ITEM ");
            whereClause.append("AND QD.SUPPLIER IN (SELECT NVL(SUPPLIER_PARENT,SUPPLIER) FROM SUPS WHERE SUPPLIER = SI.SUPPLIER) ");
            whereClause.append("AND OS.ORDER_NO  = QD.ORDER_NO ");
            whereClause.append("AND OS.ITEM       = QD.ITEM ");
            whereClause.append("AND QD.DOC_ID        = DH.DOC_ID ");
            whereClause.append("AND DH.TYPE          = '" + Document.MERCHANDISE_INVOICE + "' ");
            whereClause.append("AND QD.QTY_DISCREPANCY_ID = QTY.QTY_DISCREPANCY_ID ");
            whereClause.append("AND QD.QTY_INVOICED = QTY.QTY_RECEIVED)");
            whereClause.append("ORDER BY DOC_ID");
        }
        return whereClause;
    }
    
    private static final String GET_ORDER_BY_SHIPMENT_SQL_STORE = " SELECT distinct oh.order_no, sp.bill_to_loc, st.store_name, sp.bill_to_loc_type"
            + "  FROM ordhead oh,"
            + "        store st,"
            + "        sups s,"
            + "        shipment sp"
            + " WHERE sp.bill_to_loc = st.store "
            + "   and sp.bill_to_loc_type = 'S'"
            + "   and oh.supplier = s.supplier    "
            + "   and oh.status in ('A','C')    "
            + "   and oh.order_no = sp.order_no   " 
            + "   and sp.receive_date is not null  "
            + "   and sp.status_code in ('R', 'U', 'C') ";


    private static final String GET_ORDER_BY_SHIPMENT_SQL_WH = " SELECT distinct oh.order_no, sp.bill_to_loc, w.wh_name, sp.bill_to_loc_type"
            + "  FROM ordhead oh,"
            + "        wh w,"
            + "        sups s,"
            + "        shipment sp"
            + " WHERE sp.bill_to_loc = w.wh"
            + "   and sp.bill_to_loc_type = 'W'"
            + "   and oh.supplier = s.supplier    "
            + "   and oh.status in ('A','C')    "
            + "   and oh.order_no = sp.order_no   " 
            + "   and sp.receive_date is not null  "
            + "   and sp.status_code in ('R', 'U', 'C')  ";
    

    public OrderLOV[] select(String supplierId, String receiptNumber, String locationId,
            String fromDate, String toDate , boolean isSupplierSiteIndOn) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        StringBuffer selectSQLbyStore = new StringBuffer(GET_ORDER_BY_SHIPMENT_SQL_STORE);
        StringBuffer selectSQLbyWh = new StringBuffer(GET_ORDER_BY_SHIPMENT_SQL_WH);
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            // setup sql details here...
            if (null != locationId && locationId.length() > 0) {
                selectSQLbyStore.append(" and sp.bill_to_loc = " + locationId);
                selectSQLbyWh.append(" and sp.bill_to_loc = " + locationId);
            }
            if (null != receiptNumber && receiptNumber.length() > 0) {
                selectSQLbyStore.append(" and sp.shipment like '" + receiptNumber + "' ");
                selectSQLbyWh.append(" and sp.shipment like '" + receiptNumber + "' ");
            }
            if (null != fromDate && fromDate.length() > 0) {
                selectSQLbyStore.append(" and sp.receive_date >= to_date('" + fromDate + "', '"
                        + ReIMDate.getDateFormatPattern() + "') ");
                selectSQLbyWh.append(" and sp.receive_date >= to_date('" + fromDate + "', '"
                        + ReIMDate.getDateFormatPattern() + "') ");
            }
            if (null != toDate && toDate.length() > 0) {
                selectSQLbyStore.append(" and sp.receive_date <= to_date('" + toDate + "', '"
                        + ReIMDate.getDateFormatPattern() + "') ");
                selectSQLbyWh.append(" and sp.receive_date <= to_date('" + toDate + "', '"
                        + ReIMDate.getDateFormatPattern() + "') ");
            }
            if (null != supplierId && supplierId.length() > 0) {
                selectSQLbyStore.append(" and (s.supplier = " + supplierId);
                if(isSupplierSiteIndOn)
                {
                    selectSQLbyStore.append(" or s.supplier in (select supplier from sups where supplier_parent = " + supplierId +" )");
                }
                selectSQLbyStore.append("       or" + "     s.supplier in (select sgm.supplier_id "
                        + "                      from im_supplier_group_members sgm, "
                        + "                           im_supplier_group_members sgm2 "
                        + "                     where sgm.group_id = sgm2.group_id "
                        + "                       and sgm2.supplier_id = " + supplierId + ")) ");

                selectSQLbyWh.append(" and (s.supplier = " + supplierId);
                if(isSupplierSiteIndOn)
                {
                    selectSQLbyWh.append(" or s.supplier in (select supplier from sups where supplier_parent = " + supplierId +" )");
                }
                selectSQLbyWh.append("      or" + "     s.supplier in (select sgm.supplier_id "
                        + "                      from im_supplier_group_members sgm, "
                        + "                           im_supplier_group_members sgm2 "
                        + "                     where sgm.group_id = sgm2.group_id "
                        + "                       and sgm2.supplier_id = " + supplierId + ")) ");
            }

            String query = selectSQLbyStore.toString() + " UNION " + selectSQLbyWh.toString();

            rs = stmt.executeQuery(query);

            ArrayList dataList = new ArrayList(1);

            while (rs.next()) {
                dataList.add(new OrderLOV(rs.getString(1), rs.getString(2), rs.getString(3), rs
                        .getString(4)));
            }

            int l = dataList.size();
            OrderLOV data[] = new OrderLOV[l];
            dataList.toArray(data);

            return data;
        } catch (Exception e) {
            throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.orderBean.selectLOV", Severity.ERROR, e, this);
            }
        }
    }

    /*
     * The method returns a list of cost or quantity discrepancy rows that have zero variance. The
     * discrepancies have been created by Automatch or online matching in ReIM. RCA and RUA are done
     * at RMS to create a zero variance. But the discrepancies in ReIM database are not updated.
     * This method returns such records.
     * 
     * @see com.retek.reim.foundation.AOrderBean#getZeroVarianceDiscrepancies(java.lang.String)
     */
    public ArrayList getZeroVarianceDiscrepancies(String type) throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;
        StringBuffer sql = new StringBuffer();
        ArrayList discrepancies = new ArrayList();

        if (type.equals(ReIMConstants.DISCREPANCY_TYPE_COST)) {
            sql.append("SELECT COST_DISCREPANCY_ID, DOC_ID, ITEM FROM ");
            sql.append(ReIMConstants.COST_DISCREPANCY_TBL);
            sql.append(" WHERE ");
            sql.append(createZeroDiscrepancyWhereClause(ReIMConstants.COST_DISCREPANCY_TBL));
        } else {
            sql.append("SELECT QTY_DISCREPANCY_ID, DOC_ID, ITEM FROM ");
            sql.append(ReIMConstants.QTY_DISCREPANCY_TBL);
            sql.append(" WHERE ");
            sql.append(createZeroDiscrepancyWhereClause(ReIMConstants.QTY_DISCREPANCY_TBL));
        }
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            rs = stmt.executeQuery();
            if (type.equals(ReIMConstants.DISCREPANCY_TYPE_COST)) {
                while (rs.next()) {
                    ImCostDiscrepancyRow row = new ImCostDiscrepancyRow();
                    row.setCostDiscrepancyId(rs.getLong(1));
                    row.setDocId(rs.getLong(2));
                    row.setItem(rs.getString(3));
                    discrepancies.add(row);
                }
            } else {
                while (rs.next()) {
                    ImQtyDiscrepancyRow row = new ImQtyDiscrepancyRow();
                    row.setQtyDiscrepancyId(rs.getLong(1));
                    row.setDocId(rs.getLong(2));
                    row.setItem(rs.getString(3));
                    discrepancies.add(row);
                }
            }
            return discrepancies;
        } catch (Exception e) {
            throw new ReIMException("error.retrieving_cost_discrepancy_details_by_order",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_cost_discrepancy_details_by_order",
                        Severity.ERROR, e, this);
            }
        }
    }

    public Item[] selectSortedOrderRTVItems(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;
        ArrayList itemList = new ArrayList();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT RD.ITEM, IM.DEPT, IM.CLASS FROM RTV_DETAIL RD, ITEM_MASTER IM WHERE RD.ITEM = IM.ITEM AND RD.RTV_ORDER_NO = ? ORDER BY RD.ITEM");
            stmt.setLong(1, Long.parseLong(orderNo));
            resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Item item = new Item();
                item.setItemId(resultSet.getString("ITEM"));
                item.setItemDept(resultSet.getString("DEPT"));
                item.setItemClass(resultSet.getString("CLASS"));

                itemList.add(item);
            }

            return (Item[]) itemList.toArray(new Item[itemList.size()]);

        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_order_items", Severity.ERROR, exception,
                    this, new String[] { orderNo});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.cannot_retrieve_order_items.close_stmt_rs",
                        Severity.ERROR, e, this, new String[] { orderNo});
            }
        }
    }

    public String selectVendor(String orderNo) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT SUPPLIER FROM ORDHEAD WHERE ORDER_NO = ? ");
            stmt.setLong(1, Long.parseLong(orderNo));
            resultSet = stmt.executeQuery();
            String supplier = null;

            while (resultSet.next()) {
                supplier = resultSet.getString("SUPPLIER");
            }

            return supplier;

        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_order_items", Severity.ERROR, exception,
                    this, new String[] { orderNo});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.cannot_retrieve_order_items.close_stmt_rs",
                        Severity.ERROR, e, this, new String[] { orderNo});
            }
        }
    }
    
    private StringBuffer createMerchOrderQuery(boolean matchToLinkedSupplier,
            boolean isSupplierSiteIndOn, boolean includeClosedOrders) {
            StringBuffer sql = new StringBuffer();

            String where = constructWhere(matchToLinkedSupplier,
                    includeClosedOrders, isSupplierSiteIndOn, false);

            sql.append(" SELECT DISTINCT /*+ INDEX(A ORDHEAD_I2) */ A.ORDER_NO, ");

            if (isSupplierSiteIndOn) {
                sql.append(" B.SUPPLIER SUPP_SITE, ");
                sql.append(" B.SUP_NAME SUPP_SITE_NAME, ");
                sql.append(" B.SUPPLIER_PARENT SUPPLIER, ");
                sql.append(" C.SUP_NAME SUPPLIER_NAME ");
            } else {
                sql.append(" A.SUPPLIER SUPPLIER, ");
                sql.append(" B.SUP_NAME SUPPLIER_NAME ");
            }
      
        sql.append(" , A.TERMS, T.TERMS_CODE, A.CURRENCY_CODE, A.SHIP_PAY_METHOD ,A.EXCHANGE_RATE, T.TERMS_DESC ");
        sql.append("  FROM ORDHEAD A, SUPS B, TERMS T ");
        if(isSupplierSiteIndOn){
            sql.append(", SUPS C ");
        }
        String sqlPart1 = sql.toString();
        String sqlPart2 = "  WHERE B.SUPPLIER = A.SUPPLIER AND A.TERMS=T.TERMS AND T.ENABLED_FLAG='Y'";
        sql.append(sqlPart2);
        
        if (isSupplierSiteIndOn) {
            sql.append(" AND C.SUPPLIER = B.SUPPLIER_PARENT ");
        }

        sql.append(where);
        sqlPart2 = sqlPart2 + where;
        sql.append(constructUnion(sqlPart1, sqlPart2, matchToLinkedSupplier,
                isSupplierSiteIndOn));

        return sql;
    }
    
    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes. Currently
    // the implementation of the where clause does not require use of isEmpty to
    // determine
    // if "AND" should be appended as there is always a WHERE specified. If
    // changed to be more dynamic, simply add "where 1=1 "
    // to avoid all the extra logic of isEmpty -- "AND" will always
    // be appended
    protected String constructWhere(boolean matchToLinkedSupplier, boolean includeClosedOrders, boolean isSupplierSiteIndOn, boolean includeRTVOrders) {
        StringBuffer where = new StringBuffer();
        if (prependWhere.length() > 0) {
            where.append(" AND ");
            where.append(prependWhere);
        }

        // check if currency code is passed in from the batch entry new header
        if (isCurrencyCodeChanged) {
            where.append(" AND A.CURRENCY_CODE='");
            where.append(currencyCode);
            where.append("'");
        }

        if (isStatusChanged) {
            where.append(" AND A.STATUS='");
            where.append(status);
            where.append("'");
        } else {
            if(!includeRTVOrders){
                // no status is specified or both Approved and Closed are desired.
                // Never show 'W'orksheet or 'S'ubmitted
                if (includeClosedOrders) {
                    where.append(" AND A.STATUS in ('A','C') ");
                } else {
                    where.append(" AND A.STATUS in ('A') ");
                }
            }
        }

        if (isOrderNoChanged) {
            if(includeRTVOrders){
                where.append(" AND A.RTV_ORDER_NO = ");
            } else {
                where.append(" AND A.ORDER_NO = ");
            }

            where.append(orderNo);
        }

        if (isSupplierNameChanged) {
            where.append(" AND B.SUP_NAME=");
            where.append(supplierName);
        }
        
        if(isSupplierSiteIndOn) {
            if(isSupplierSiteChanged) {
                if(!StringUtils.isEmpty(supplierSite)) {
                    where.append(" AND ( B.SUPPLIER=");
                    where.append(supplierSite);
                    where.append(" OR B.SUPPLIER_PARENT IN (SELECT  SUPPLIER_PARENT FROM SUPS S WHERE S.SUPPLIER =");
                    where.append(supplierSite);
                    where.append("))");
                }
            }
        }

        // The complete WHERE clause is returned here
        if (where.length() != 0) {
            return where.toString();
        } else {
            return "";
        }
    }
    
    /**
     * For RTV documents currency is determined by the supplier (for regular POs
     * it is determined by PO itself) and rate is determined by supplier
     * currency rate for the doc date (for regular POs it is determined by PO
     * itself)
     */
    private StringBuffer createRtvOrderQuery(boolean isSupplierSiteIndOn, boolean matchToLinkedSupplier) {
        StringBuffer sql = new StringBuffer();

        sql.append(
            " SELECT DISTINCT /*+ INDEX(A RTV_HEAD_I2) */ A.RTV_ORDER_NO ORDER_NO, "); 
        
        if (isSupplierSiteIndOn) {
            sql.append(" B.SUPPLIER SUPP_SITE, ");
            sql.append(" B.SUP_NAME SUPP_SITE_NAME, ");
            sql.append(" B.SUPPLIER_PARENT SUPPLIER, ");
            sql.append(" C.SUP_NAME SUPPLIER_NAME ");
        } else {
            sql.append(" A.SUPPLIER SUPPLIER, ");
            sql.append(" B.SUP_NAME SUPPLIER_NAME ");
        }
        sql.append(", NULL TERMS, NULL TERMS_CODE, ");
        if(isSupplierSiteIndOn){
            sql.append(" C.CURRENCY_CODE ");    
        }else{
            sql.append(" B.CURRENCY_CODE ");
        }        
        sql.append(", NULL SHIP_PAY_METHOD, CR.EXCHANGE_RATE, NULL TERMS_DESC ");
        
        sql.append(
            " FROM SUPS B, RTV_HEAD A, ( SELECT E.CURRENCY_CODE,E.EXCHANGE_RATE,E.EXCHANGE_TYPE,E.EFFECTIVE_DATE FROM CURRENCY_RATES E," +
            "( SELECT MAX(EFFECTIVE_DATE) EFFECTIVE_DATE,CURRENCY_CODE FROM CURRENCY_RATES WHERE EXCHANGE_TYPE='"+ExchangeType.CONSOLIDATION +
            "' AND EFFECTIVE_DATE<=? GROUP BY CURRENCY_CODE ) D " +
            "WHERE E.EXCHANGE_TYPE='"+ExchangeType.CONSOLIDATION+"' AND E.EFFECTIVE_DATE =D.EFFECTIVE_DATE  AND E.CURRENCY_CODE=D.CURRENCY_CODE )CR");
        if(isSupplierSiteIndOn){
            sql.append(", SUPS C ");
        }
        String sqlPart1 = sql.toString();
        
        String sqlPart2 = " WHERE B.SUPPLIER = A.SUPPLIER AND A.STATUS_IND in (" +
            RtvStatusInd.APPROVED.getCode() + "," +
            RtvStatusInd.SHIPPED.getCode() +
            ")  AND CR.CURRENCY_CODE = B.CURRENCY_CODE ";
        sql.append(sqlPart2);
        
        if (isSupplierSiteIndOn) {
            sql.append(" AND C.SUPPLIER = B.SUPPLIER_PARENT ");
        }

        String where = constructWhere(false, false, isSupplierSiteIndOn, true);
        sql.append(where);
        sqlPart2 = sqlPart2 + where;
        sql.append(constructUnion(sqlPart1, sqlPart2, matchToLinkedSupplier,
                isSupplierSiteIndOn));

        return sql;
    }
    
    private String translate(String text, boolean translationRequired,
            String userLang) throws ReIMException {
            if (!translationRequired) {
                return text;
            } else {
                return DataTranslationService.getSupplierDesc(text, userLang);
            }
        }
    
    public ArrayList selectDiscrepenciesByItemCostsApplyAll(String itemId, double orderCost,
            double invoiceCost) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            String sqlQuery = "SELECT DISTINCT CD.COST_DISCREPANCY_ID, CD.DOC_ID ,  CD.ITEM "
                    + "FROM IM_COST_DISCREPANCY CD, v_im_ordloc OL " + "WHERE CD.ITEM = OL.ITEM "
                    + "AND CD.ORDER_NO = OL.ORDER_NO "
                    + "AND CD.ITEM =? "
                    + "AND OL.UNIT_COST = ? " + "AND CD.DOC_UNIT_COST = ? " + "AND CD.DOC_TYPE = '"
                    + Document.MERCHANDISE_INVOICE + "' "
                    + "AND NOT EXISTS ( SELECT 1 FROM IM_RESOLUTION_ACTION RA "
                    + " WHERE RA.DOC_ID = CD.DOC_ID " + "   AND RA.ITEM   = ? "
                    + "   AND RA.ACTION IN (" + sqlCommaList(ReasonCode.COST_INVOICE_ACTIONS)
                    + ")) ";
            
            
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlQuery);
            stmt.setString(1, itemId);
            stmt.setDouble(2, orderCost);
            stmt.setDouble(3, invoiceCost);
            stmt.setString(4, itemId);


            resultSet = stmt.executeQuery();

            ArrayList discrepancies = new ArrayList();

            while (resultSet.next()) {

            	discrepancies.add(resultSet.getString("COST_DISCREPANCY_ID"));
                discrepancies.add(resultSet.getLong("DOC_ID"));
                discrepancies.add(resultSet.getString("ITEM"));
                
            }
  
            return discrepancies;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_discrepancies_for_item", Severity.ERROR,
                    exception, this, new String[] { itemId});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException(
                        "error.cannot_retrieve_discrepancies_for_item.close_stmt_rs",
                        Severity.ERROR, e, this, new String[] { itemId});
            }
        }
    }  
}
