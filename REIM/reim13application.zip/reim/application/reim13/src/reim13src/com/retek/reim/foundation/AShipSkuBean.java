package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.DatasourceProperties;
import oracle.retail.reim.utils.Severity;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.ReceiptWriteOff;
import com.retek.reim.db.ImReceiptItemPostingRow;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ReceiptService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.translation.DataTranslationService;
import com.retek.reim.ui.discrepancyResolution.QuantityReviewReceiptQuantities;
import com.retek.reim.ui.lov.ItemLOV;

/**
 * @See oracle.retail.reim.data.dao.impl.ShipSkuDao
 */

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		05-Feb-2014	BNaik		BRN IMS 187372:  ReIM: This is an issue with the query used to get the receipt write off
*													received quantity and the item appearing twice on the shipsku table..
 * 
 */

@Deprecated
public abstract class AShipSkuBean implements IShipSkuBean {
    public AShipSkuBean() {
    }

    public ReceiptItem readReceiptItem(String receiptId, String itemId) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer();
            whereClause.append(" SHIPMENT = ? AND ITEM = ?");

            DALGenPreparedSQLFragment statementFragment = new DALGenPreparedSQLFragment(whereClause
                    .toString());
            statementFragment.setLong(1, Long.parseLong(receiptId));
            statementFragment.setString(2, itemId);

            ReceiptItem[] results = readReceiptItems(statementFragment, null);

            if (results != null && results.length > 0) {
                return results[0];
            } else {
                return null;
            }
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.shipsku_bean.get_receipt_items", Severity.ERROR, e, this);
        }
    }

    public ReceiptItem[] readReceiptItems(String receiptId) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer();
            whereClause.append(" SHIPMENT = ?");

            DALGenPreparedSQLFragment statementFragment = new DALGenPreparedSQLFragment(whereClause
                    .toString());
            statementFragment.setString(1, receiptId);

            return readReceiptItems(statementFragment, null);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.shipsku_bean.get_receipt_items", Severity.ERROR, e, this);
        }
    }

    private ReceiptItem[] readReceiptItems(DALGenPreparedSQLFragment whereClause, String orderBy)
            throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs = null;

        try {
            ReceiptItem[] receiptItemArray = null;

            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT SHIPMENT, ITEM, SUM(QTY_RECEIVED) over (PARTITION BY SHIPMENT, ITEM) QTY_RECEIVED, UNIT_COST, SUM(QTY_MATCHED) over (PARTITION BY SHIPMENT, ITEM) QTY_MATCHED FROM V_IM_SHIPSKU");

            if (whereClause != null) {
                sqlText.append(" WHERE ");
                sqlText.append(whereClause.getSQLFragment());
            }            

            if (orderBy != null) {
                sqlText.append(" ORDER BY ");
                sqlText.append(orderBy);
            }

            String sqlTxt = sqlText.toString();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            if (whereClause != null) {
            whereClause.callSettersOnPreparedStatement(stmnt, 1);
            }
            rs = stmnt.executeQuery();

            ArrayList receiptItems = new ArrayList();

            while (rs.next()) {
                ReceiptItem receiptItem = new ReceiptItem();
                receiptItem.setReceiptId(String.valueOf(rs.getLong("SHIPMENT")));
                receiptItem.setItemId(rs.getString("ITEM"));
                receiptItem.setQtyReceived(rs.getDouble("QTY_RECEIVED"));
                receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));
                receiptItem.setCostMatched(ReceiptService.isCostMatched(receiptItem.getItemId(),
                        receiptItem.getReceiptId()));
                receiptItem.setQtyMatched(rs.getDouble("QTY_MATCHED"));

                receiptItems.add(receiptItem);
            }

            if (receiptItems.size() > 0) {
                // build a new array sized to the number of elements inserted
                // into the vector
                receiptItemArray = new ReceiptItem[receiptItems.size()];
                // copy the vector elements into the array
                receiptItems.toArray(receiptItemArray);
            }

            return receiptItemArray;
        } catch (Exception ex) {
            throw new ReIMException("error.shipsku_bean.get_receipt_items", Severity.ERROR, ex,
                    this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.shipsku_bean.get_receipt_items", Severity.ERROR, ex,
                        this);
            }
        }
    }

    private static String READ_RECEIPT_ITEMS_ADJ_PENDING = "SELECT /*+ FIRST_ROWS */ I.SHIPMENT, I.ITEM, SUM(I.QTY_RECEIVED) QTY_RECEIVED, RCA.ADJUSTED_UNIT_COST UNIT_COST, "
            + " (SUM(I.QTY_RECEIVED)  - NVL(PMR.QTY_MATCHED, 0)) AVAILABLE_TO_MATCH, NVL(S.INVC_MATCH_STATUS, '"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.STATUS_CODE"
            + "  FROM v_im_shipsku I, IM_RECEIVER_COST_ADJUST RCA, SHIPMENT S, IM_PARTIALLY_MATCHED_RECEIPTS PMR "
            + " WHERE S.SHIPMENT = I.SHIPMENT "
            + " AND S.ORDER_NO = RCA.ORDER_NO "
            + " AND S.BILL_TO_LOC = RCA.LOCATION "
            + " AND I.ITEM = RCA.ITEM"
            + " AND I.SHIPMENT = PMR.SHIPMENT(+)"
            + " AND S.INVC_MATCH_STATUS in ('U','P')"
            + " AND I.ITEM = PMR.ITEM(+)"
            + " AND S.SHIPMENT = ?"
            + " AND S.ORDER_NO = ?"
            + " AND S.BILL_TO_LOC = ?"
            + " GROUP BY I.ITEM, I.SHIPMENT, RCA.ADJUSTED_UNIT_COST, PMR.QTY_MATCHED, S.INVC_MATCH_STATUS, S.STATUS_CODE "
            + " UNION "
            + " SELECT /*+ FIRST_ROWS */ I.SHIPMENT, I.ITEM, SUM(I.QTY_RECEIVED) QTY_RECEIVED, I.UNIT_COST, "
            + " (SUM(I.QTY_RECEIVED)  - NVL(PMR.QTY_MATCHED, 0)) AVAILABLE_TO_MATCH, NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.STATUS_CODE "
            + "  FROM v_im_shipsku I, SHIPMENT S, IM_PARTIALLY_MATCHED_RECEIPTS PMR "
            + " WHERE I.SHIPMENT = ?"
            + " AND I.SHIPMENT = S.SHIPMENT"
            + " AND I.SHIPMENT = PMR.SHIPMENT(+)"
            + " AND S.INVC_MATCH_STATUS in ('U','P')"
            + " AND I.ITEM = PMR.ITEM(+)"
            + " AND NOT EXISTS (SELECT 'X' FROM IM_RECEIVER_COST_ADJUST RCA WHERE RCA.ORDER_NO = S.ORDER_NO AND RCA.LOCATION = S.BILL_TO_LOC AND RCA.ITEM = I.ITEM)"
            + " GROUP BY I.ITEM, I.SHIPMENT, I.UNIT_COST, PMR.QTY_MATCHED, S.INVC_MATCH_STATUS, S.STATUS_CODE ";

    public ReceiptItem[] getReceiptItemsAdjPending(String receiptId, String orderNo, String location)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            ReceiptItem[] receiptItemArray = null;

            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement(READ_RECEIPT_ITEMS_ADJ_PENDING);
            stmt.setString(1, receiptId);
            stmt.setString(2, orderNo);
            stmt.setString(3, location);
            stmt.setString(4, receiptId);

            rs = stmt.executeQuery();

            ArrayList receiptItems = new ArrayList();

            while (rs.next()) {
                double qtyReceived = rs.getDouble("QTY_RECEIVED");
                if (qtyReceived != Double.MIN_VALUE) {
                    ReceiptItem receiptItem = new ReceiptItem();
                    receiptItem.setReceiptId(String.valueOf(rs.getLong("SHIPMENT")));
                    receiptItem.setItemId(rs.getString("ITEM"));
                    receiptItem.setQtyReceived(rs.getDouble("QTY_RECEIVED"));
                    receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));
                    receiptItem.setCostMatched(ReceiptService.isCostMatched(
                            receiptItem.getItemId(), receiptItem.getReceiptId()));
                    receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH"));
                    if (receiptItem.getQtyReceived() != receiptItem.getAvailableToMatchQty())
                        receiptItem.setPartiallyMatched(true);
                    else
                        receiptItem.setPartiallyMatched(false);

                    String matchStatus = rs.getString("INVC_MATCH_STATUS");
                    String statusCode = rs.getString("STATUS_CODE");

                    if (matchStatus.equals(Receipt.UNMATCHED)
                            && (statusCode.equals(Receipt.RECEIVED_STATUS) || statusCode
                                    .equals(Receipt.UNMATCHED_STATUS))) {
                        receiptItem.setInvoiceMatchStatus(Receipt.UNMATCHED);
                    } else {
                        receiptItem.setInvoiceMatchStatus(Receipt.MATCHED);
                    }

                    receiptItems.add(receiptItem);
                }
            }

            if (receiptItems.size() > 0) {
                // build a new array sized to the number of elements inserted
                // into the vector
                receiptItemArray = new ReceiptItem[receiptItems.size()];
                // copy the vector elements into the array
                receiptItems.toArray(receiptItemArray);
            }

            return receiptItemArray;
        } catch (Exception ex) {
            throw new ReIMException("error.shipsku_bean.get_receipt_items_adj_pending",
                    Severity.ERROR, ex, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.shipsku_bean.get_receipt_items_adj_pending",
                        Severity.ERROR, ex, this);
            }
        }
    }

    private static String READ_RECEIPT_ITEM_ADJ_PENDING = "SELECT /*+ FIRST_ROWS */ I.SHIPMENT, I.ITEM, SUM(I.QTY_RECEIVED) QTY_RECEIVED, RCA.ADJUSTED_UNIT_COST UNIT_COST, "
            + " (SUM(I.QTY_RECEIVED)  - NVL(PMR.QTY_MATCHED, 0)) AVAILABLE_TO_MATCH, NVL(S.INVC_MATCH_STATUS, '"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.STATUS_CODE"
            + "  FROM v_im_shipsku I, IM_RECEIVER_COST_ADJUST RCA, SHIPMENT S, IM_PARTIALLY_MATCHED_RECEIPTS PMR"
            + " WHERE S.SHIPMENT = I.SHIPMENT "
            + " AND S.ORDER_NO = RCA.ORDER_NO "
            + " AND S.BILL_TO_LOC = RCA.LOCATION "
            + " AND I.ITEM = RCA.ITEM"
            + " AND I.SHIPMENT = PMR.SHIPMENT(+)"
            + " AND S.INVC_MATCH_STATUS in ('U','P')"
            + " AND I.ITEM = PMR.ITEM(+)"
            + " AND S.SHIPMENT = ?"
            + " AND S.ORDER_NO = ?"
            + " AND S.BILL_TO_LOC = ?"
            + " AND I.ITEM = ?"
            + " GROUP BY I.ITEM, I.SHIPMENT, RCA.ADJUSTED_UNIT_COST, PMR.QTY_MATCHED, S.INVC_MATCH_STATUS, S.STATUS_CODE "
            + " UNION "
            + " SELECT /*+ FIRST_ROWS */ I.SHIPMENT, I.ITEM, SUM(I.QTY_RECEIVED) QTY_RECEIVED, I.UNIT_COST, "
            + " (SUM(I.QTY_RECEIVED)  - NVL(PMR.QTY_MATCHED, 0)) AVAILABLE_TO_MATCH, NVL(S.INVC_MATCH_STATUS,'"
            + Receipt.UNMATCHED
            + "') INVC_MATCH_STATUS, S.STATUS_CODE "
            + "  FROM v_im_shipsku I, SHIPMENT S, IM_PARTIALLY_MATCHED_RECEIPTS PMR"
            + " WHERE I.SHIPMENT = ?"
            + " AND I.SHIPMENT = S.SHIPMENT"
            + " AND I.SHIPMENT = PMR.SHIPMENT(+)"
            + " AND S.INVC_MATCH_STATUS in ('U','P')"
            + " AND I.ITEM = PMR.ITEM(+)"
            + " AND I.ITEM = ?"
            + " AND NOT EXISTS (SELECT 'X' FROM IM_RECEIVER_COST_ADJUST RCA WHERE RCA.ORDER_NO = S.ORDER_NO AND RCA.LOCATION = S.BILL_TO_LOC AND RCA.ITEM = I.ITEM)"
            + " GROUP BY I.ITEM, I.SHIPMENT, I.UNIT_COST, PMR.QTY_MATCHED, S.INVC_MATCH_STATUS, S.STATUS_CODE ";

    public ReceiptItem getReceiptItemAdjPending(String receiptId, String orderNo, String location,
            String itemId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement(READ_RECEIPT_ITEM_ADJ_PENDING);
            stmt.setString(1, receiptId);
            stmt.setString(2, orderNo);
            stmt.setString(3, location);
            stmt.setString(4, itemId);
            stmt.setString(5, receiptId);
            stmt.setString(6, itemId);

            rs = stmt.executeQuery();

            ReceiptItem receiptItem = null;

            while (rs.next()) {
                double qtyReceived = rs.getDouble("QTY_RECEIVED");
                if (qtyReceived != Double.MIN_VALUE && qtyReceived > 0) {
                    receiptItem = new ReceiptItem();

                    receiptItem.setReceiptId(String.valueOf(rs.getLong("SHIPMENT")));
                    receiptItem.setItemId(rs.getString("ITEM"));
                    receiptItem.setQtyReceived(rs.getDouble("QTY_RECEIVED"));
                    receiptItem.setUnitCost(rs.getDouble("UNIT_COST"));
                    receiptItem.setCostMatched(ReceiptService.isCostMatched(
                            receiptItem.getItemId(), receiptItem.getReceiptId()));
                    receiptItem.setAvailableToMatchQty(rs.getDouble("AVAILABLE_TO_MATCH"));
                    if (receiptItem.getQtyReceived() != receiptItem.getAvailableToMatchQty())
                        receiptItem.setPartiallyMatched(true);
                    else
                        receiptItem.setPartiallyMatched(false);

                    String matchStatus = rs.getString("INVC_MATCH_STATUS");
                    String statusCode = rs.getString("STATUS_CODE");

                    if (matchStatus.equals(Receipt.UNMATCHED)
                            && (statusCode.equals(Receipt.RECEIVED_STATUS) || statusCode
                                    .equals(Receipt.UNMATCHED_STATUS))) {
                        receiptItem.setInvoiceMatchStatus(Receipt.UNMATCHED);
                    } else {
                        receiptItem.setInvoiceMatchStatus(Receipt.MATCHED);
                    }
                }
            }

            return receiptItem;
        } catch (Exception ex) {
            throw new ReIMException("error.shipsku_bean.get_receipt_item_adj_pending",
                    Severity.ERROR, ex, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.shipsku_bean.get_receipt_item_adj_pending",
                        Severity.ERROR, ex, this);
            }
        }
    }

    // This method returns all Receipt items for a specific order number.
    public ItemLOV[] selectReceiptItemsForOrder(String itemId, String itemDesc, String supplierId,
            String order, String includeLinkedSupps) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        if (supplierId == null) {
            includeLinkedSupps = "false";
        }

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            String userLang = ReIMUserContext.getUserLanguage();
            boolean translateDescs = DataTranslationService.isTranslationRequired(userLang);

            String sql = createReceiptItemsForOrderQuery(userLang, translateDescs, itemId,
                    itemDesc, supplierId, order, includeLinkedSupps);

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql);

            if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.TRUE) && (order != null)) {
                if (itemId == null) {
                    stmt.setString(1, supplierId);
                    stmt.setString(2, supplierId);
                    stmt.setString(3, order);
                } else {
                    stmt.setString(1, itemId);
                    stmt.setString(2, supplierId);
                    stmt.setString(3, supplierId);
                    stmt.setString(4, order);
                }

            } else if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.TRUE) && (order == null)) {
                if (itemId == null) {
                    stmt.setString(1, supplierId);
                    stmt.setString(2, supplierId);
                } else {
                    stmt.setString(1, itemId);
                    stmt.setString(2, supplierId);
                    stmt.setString(3, supplierId);
                }
            }

            else if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.FALSE)
                    && (supplierId != null) && (order != null)) {
                if (itemId == null) {
                    stmt.setString(1, supplierId);
                    stmt.setString(2, order);
                } else {
                    stmt.setString(1, itemId);
                    stmt.setString(2, supplierId);
                    stmt.setString(3, order);
                }

            }

            else if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.FALSE)
                    && (supplierId == null) && (order != null)) {
                if (itemId == null) {
                    stmt.setString(1, order);
                } else {
                    stmt.setString(1, itemId);
                    stmt.setString(2, order);
                }

            } else if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.FALSE)
                    && (supplierId != null) && (order == null)) {
                if (itemId == null) {
                    stmt.setString(1, supplierId);
                } else {
                    stmt.setString(1, itemId);
                    stmt.setString(2, supplierId);
                }
            } else if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.FALSE)
                    && (supplierId == null) && (order == null)) {
                if (itemId != null) {
                    stmt.setString(1, itemId);
                }
            }

            rs = stmt.executeQuery();
            ArrayList dataList = new ArrayList(1);

            while (rs.next()) {
                dataList.add(new ItemLOV(rs.getLong(1) + "", rs.getString(2)));
            }

            int l = dataList.size();
            ItemLOV data[] = new ItemLOV[l];
            dataList.toArray(data);

            return data;
        }

        catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("Error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("Error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }

    private String createReceiptItemsForOrderQuery(String userLang, boolean translateDescs,
            String itemId, String itemDesc, String supplierId, String order,
            String includeLinkedSupps) throws ReIMException {
        StringBuffer query = new StringBuffer();
        boolean isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
                .isSupplierSiteInd();
        if (!translateDescs) {
            query.append(" SELECT UNIQUE IM.ITEM, IM.ITEM_DESC DESC_UP ");
            query.append(" FROM ITEM_MASTER IM, SHIPMENT S, v_im_shipsku SK, ORDHEAD O ");
            if (isSupplierSiteIndOn) {
                query.append(",SUPS SUP");
            }
            query.append(" WHERE S.SHIPMENT = SK.SHIPMENT ");
            query.append(" AND S.STATUS_CODE in ('" + Receipt.RECEIVED_STATUS + "', '");
            query.append(Receipt.UNMATCHED_STATUS + "') ");
            query.append(" AND NVL(S.INVC_MATCH_STATUS,'" + Receipt.UNMATCHED + "') = '"
                    + Receipt.UNMATCHED + "' ");
            query.append(" AND SK.ITEM = IM.ITEM ");
            query.append(" AND O.ORDER_NO = S.ORDER_NO ");

            if (itemId == null) {
                query.append(" AND IM.DESC_UP LIKE UPPER('%" + itemDesc + "%') ");
            } else {
                query.append(" AND IM.ITEM = ? ");
            }
            if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.TRUE)) {
                if (isSupplierSiteIndOn) {
                    query
                            .append(" AND (O.SUPPLIER IN (SELECT SP.Supplier FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2, SUPS SP WHERE L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID = ? AND SP.SUPPLIER_PARENT = L2.SUPPLIER_ID) "
                                    + " OR O.SUPPLIER = SUP.SUPPLIER and SUP.SUPPLIER_PARENT = ? )");
                } else {
                    query
                            .append(" AND (O.SUPPLIER IN (SELECT L2.SUPPLIER_ID  FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 WHERE L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID = ?) "
                                    + " OR O.SUPPLIER = ? )");
                }
            }
            if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.FALSE) && (supplierId != null)) {
                if (isSupplierSiteIndOn) {
                    query.append(" AND O.SUPPLIER = SUP.SUPPLIER AND SUP.SUPPLIER_PARENT = ?");
                } else {
                    query.append(" AND O.SUPPLIER = ? ");
                }

            }
            if (order != null) {
                query.append(" AND O.ORDER_NO = ? ");
            }
        } else {
            query.append(" SELECT UNIQUE IM.ITEM, NVL(TL.TRANSLATED_VALUE,IM.ITEM_DESC) DESC_UP ");
            query
                    .append(" FROM ITEM_MASTER IM, SHIPMENT S, v_im_shipsku SK, ORDHEAD O ,TL_SHADOW TL");
            if (isSupplierSiteIndOn) {
                query.append(" ,SUPS SUP");
            }
            query.append(" WHERE S.SHIPMENT = SK.SHIPMENT ");
            query.append(" AND S.STATUS_CODE in ('" + Receipt.RECEIVED_STATUS + "', '");
            query.append(Receipt.UNMATCHED_STATUS + "') ");
            query.append(" AND NVL(S.INVC_MATCH_STATUS,'" + Receipt.UNMATCHED + "') = '"
                    + Receipt.UNMATCHED + "' ");
            query.append(" AND '" + userLang + "' = TL.LANG (+) AND IM.DESC_UP = TL.KEY (+) ");
            query.append(" AND SK.ITEM = IM.ITEM ");
            query.append(" AND O.ORDER_NO = S.ORDER_NO ");

            if (itemId == null) {
                query.append(" AND UPPER(NVL(TL.TRANSLATED_VALUE, IM.DESC_UP)) LIKE UPPER('%"
                        + itemDesc + "%')");
            } else {
                query.append(" AND IM.ITEM = ? ");
            }
            if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.TRUE)) {
                if (isSupplierSiteIndOn) {
                    query
                            .append(" AND (O.SUPPLIER IN (SELECT SP.Supplier FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2, SUPS SP WHERE L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID = ? AND SP.SUPPLIER_PARENT = L2.SUPPLIER_ID) "
                                    + " OR O.SUPPLIER = SUP.SUPPLIER and SUP.SUPPLIER_PARENT = ? )");
                } else {
                    query
                            .append(" AND (O.SUPPLIER IN (SELECT L2.SUPPLIER_ID  FROM IM_SUPPLIER_GROUP_MEMBERS L1, IM_SUPPLIER_GROUP_MEMBERS L2 WHERE L1.GROUP_ID = L2.GROUP_ID AND L1.SUPPLIER_ID = ?) "
                                    + " OR O.SUPPLIER = ? )");
                }
            }
            if (includeLinkedSupps.equalsIgnoreCase(ReIMConstants.FALSE) && (supplierId != null)) {
                if (isSupplierSiteIndOn) {
                    query.append(" AND O.SUPPLIER = SUP.SUPPLIER AND SUP.SUPPLIER_PARENT = ?");
                } else {
                    query.append(" AND O.SUPPLIER = ? ");
                }

            }
            if (order != null) {
                query.append(" AND O.ORDER_NO = ? ");
            }
        }

        query.append(" ORDER BY 2 ");

        String sql = query.toString();

        return sql;
    }

    /**
     * getTotalReceiptCostQty(ArrayList)
     * 
     * @param Receipt
     *            []
     * 
     * @return void
     * 
     *         The method will calculate the receipt totalUnitCosts by first calculating each
     *         receipt item's extended cost then summing the extended costs.
     * 
     *         extended cost = receipt item qty received * unit cost totalUnitCosts = sum(extended
     *         cost)
     * 
     *         The method will calculate the receipt totalQtyReceived, totalUnitCosts and
     *         totalQtyMatched by summing each receipt item's qty received, qty received multiplied
     *         by unit cost and qty matched respectively
     * 
     *         a receipt item is the same as RMS shipsku
     */
    public void getReceiptTotalCostAndQty(Receipt[] receipts) throws ReIMException {
        String sqlText = "SELECT ss.item ITEM, ss.qty_received QTY_RECEIVED, ss.unit_cost UNIT_COST, s.invc_match_status STATUS, nvl(pmr.qty_matched,0) QTY_MATCHED \n"
                + "FROM SHIPMENT S, v_im_shipsku SS, IM_PARTIALLY_MATCHED_RECEIPTS pmr \n"
                + "WHERE s.shipment = ? \n"
                + "  AND ss.shipment = s.shipment \n"
                + "  AND pmr.shipment(+)=ss.shipment \n"
                + "  AND pmr.item(+)=ss.item \n"
                + "ORDER BY ss.item \n";
        OraclePreparedStatement stmnt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlText);

            Receipt receipt = null;
            double qtyReceived = Double.MIN_VALUE;
            double unitCost = Double.MIN_VALUE;
            double qtyMatched = Double.MIN_VALUE;
            String currentItem = "";
            String previousItem = "";

            for (int i = 0; i < receipts.length; i++) {
                // Reset totals to zero for each Receipt
                double totalUnitCosts = 0;
                double totalQtyReceived = 0;
                double totalQtyMatched = 0;
                previousItem = "";

                receipt = receipts[i];
                stmnt.setString(1, receipt.getReceiptId());

                rs = stmnt.executeQuery();

                while (rs.next()) {
                    qtyReceived = rs.getDouble("QTY_RECEIVED");
                    unitCost = rs.getDouble("UNIT_COST");
                    currentItem = rs.getString("ITEM");

                    totalQtyReceived += qtyReceived;
                    totalUnitCosts += (qtyReceived * unitCost);

                    if (rs.getString("STATUS").equals(Receipt.MATCHED)) {
                        totalQtyMatched += qtyReceived;
                        previousItem = currentItem;
                    }

                    else if (!currentItem.equals(previousItem)) {
                        qtyMatched = rs.getDouble("QTY_MATCHED");
                        totalQtyMatched += qtyMatched;
                        previousItem = currentItem;
                    }
                }

                receipt.setTotalQtyReceived(totalQtyReceived);
                receipt.setTotalUnitCosts(totalUnitCosts);
                receipt.setTotalQtyMatched(totalQtyMatched);
            }

        } catch (Exception e) {
            throw new ReIMException("error.shipsku_bean.get_cost_and_qty", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.shipsku_bean.get_cost_and_qty", Severity.ERROR, ex,
                        this);
            }
        }
    }

    /**
     * getDiscrepancyReceiptQtySum(Long businessRoleId)
     * 
     * @param String
     *            , String, Long
     * 
     * @return HashMap
     * 
     *         This method is used in conjunction with ImQtyDiscrepancyAccessExt to return a list of
     *         the calculated quantities available from a receipt. The ReIMAddWhereClause contains
     *         an additional where clause involving ONLY ReIM columns and will be used only if the
     *         businessRoleId is not null. The ReIMCommonGroupOrder is contains the group by and
     *         order columns which involve ONLY ReIM columns. These ReIM variables are used as input
     *         variable to ensure the result set of this method will match the corresponding result
     *         set used in ImQtyDiscrepancyAccessExt.
     */
    public HashMap getDiscrepancyReceiptQtySum(String reimAddWhereClause,
            String reimCommonGroupOrder, Long businessRoleId, String docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            HashMap quantityReceivedSumList = new HashMap();

            if (businessRoleId == null && docId == null) {
                reimAddWhereClause = "";
            }

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(" SELECT /*+ all_rows cardinality (qd, 10)  */ SUM(SHP.QTY_RECEIVED) - NVL(MRI.QTY_MATCHED, 0) QTY_RECEIVED, QD.DOC_ID,  MIN(QD.RESOLVE_BY_DATE) RESOLVE_BY_DATE, "
                            + " QD.SUPPLIER,  QD.ORDER_NO,  QD.LOCATION,  QD.LOC_TYPE,  QD.AP_REVIEWER "
                            + " FROM IM_QTY_DISCREPANCY QD, "
                            + " IM_QTY_DISCREPANCY_RECEIPT QDR, "
                            + " v_im_shipsku SHP, "
                            + " IM_PARTIALLY_MATCHED_RECEIPTS MRI "
                            + " WHERE QDR.QTY_DISCREPANCY_ID (+) = QD.QTY_DISCREPANCY_ID "
                            + " AND MRI.SHIPMENT (+)           = SHP.SHIPMENT "
                            + " AND MRI.ITEM (+)               = SHP.ITEM "
                            + " AND QDR.RECEIPT_ID             = SHP.SHIPMENT "
                            + " AND QD.ITEM                    = SHP.ITEM "
                            + reimAddWhereClause
                            + " GROUP BY "
                            + reimCommonGroupOrder
                            + ", MRI.QTY_MATCHED "
                            + " ORDER BY " + reimCommonGroupOrder);

            if (businessRoleId != null) {
                stmt.setLong(1, businessRoleId.longValue());
                if (docId != null) {
                    stmt.setString(2, docId);
                }
            } else {
                if (docId != null) {
                    stmt.setString(1, docId);
                }
            }

            rs = stmt.executeQuery();

            while (rs.next()) {
                StringBuffer mapKey = new StringBuffer();
                mapKey.append(rs.getString("DOC_ID"));
                mapKey.append(new ReIMDate(rs.getDate("RESOLVE_BY_DATE")).toString());
                mapKey.append(rs.getString("SUPPLIER"));
                mapKey.append(rs.getString("ORDER_NO"));
                mapKey.append(rs.getString("LOCATION"));
                mapKey.append(rs.getString("LOC_TYPE"));
                mapKey.append(rs.getString("AP_REVIEWER"));

                quantityReceivedSumList.put(mapKey.toString(), new Double(rs
                        .getDouble("QTY_RECEIVED")));
            }
            return quantityReceivedSumList;
        } catch (Exception e) {
            throw new ReIMException("error.shipsku_bean.get_discrepancy_receipt_qty_sum",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException(
                        "error.shipsku_bean.get_discrepancy_receipt_qty_sum.close_stmt",
                        Severity.ERROR, ex, this);
            }
        }
    }

    public QuantityReviewReceiptQuantities[] getReceiptsForDiscrepancy(long qtyDiscrepancyId,
            String item) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList arrayList = new ArrayList();
        QuantityReviewReceiptQuantities quantityReviewReceiptQuantities;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT QDR.RECEIPT_ID, "
                    + "       SUM(SH.QTY_RECEIVED) - NVL(MRI.QTY_MATCHED, 0) QTY_RECEIVED "
                    + "  FROM IM_QTY_DISCREPANCY_RECEIPT QDR, " + "       v_im_shipsku SH, "
                    + "       IM_PARTIALLY_MATCHED_RECEIPTS MRI "
                    + " WHERE QDR.QTY_DISCREPANCY_ID = ? "
                    + "   AND QDR.RECEIPT_ID         = SH.SHIPMENT "
                    + "   AND SH.ITEM                = ? "
                    + "   AND MRI.SHIPMENT (+)       = SH.SHIPMENT "
                    + "   AND MRI.ITEM (+)           = SH.ITEM "
                    + " GROUP BY QDR.RECEIPT_ID, MRI.QTY_MATCHED " + " ORDER BY QDR.RECEIPT_ID");

            stmt.setLong(1, qtyDiscrepancyId);
            stmt.setString(2, item);

            rs = stmt.executeQuery();

            while (rs.next()) {
                quantityReviewReceiptQuantities = new QuantityReviewReceiptQuantities(rs
                        .getLong("RECEIPT_ID"), rs.getString("QTY_RECEIVED"));

                arrayList.add(quantityReviewReceiptQuantities);
            }

            if (arrayList.size() > 0)
                return (QuantityReviewReceiptQuantities[]) arrayList
                        .toArray(new QuantityReviewReceiptQuantities[arrayList.size()]);
            else
                return null;
        } catch (Exception exception) {
            throw new ReIMException("error.retrieving_receipts", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (SQLException exception) {
                throw new ReIMException("error.retrieving_receipts", Severity.ERROR, exception,
                        this);

            }
        }
    }

    // This method returns all Receipt items for a specific order number.
    public String validateUnmatchedReceiptItem(String itemId, String receiptId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sql = new StringBuffer();
            sql.append(" SELECT SK.ITEM FROM v_im_shipsku SK ");
            sql.append("  WHERE SK.ITEM = ? ");
            sql.append("    AND SK.SHIPMENT = ? ");
            sql.append("    AND NOT EXISTS (SELECT 'X' FROM IM_PARTIALLY_MATCHED_RECEIPTS MR ");
            sql.append("                     WHERE MR.ITEM = ? AND MR.SHIPMENT = ? ");
            sql
                    .append("                     AND MR.QTY_MATCHED >= (SELECT SUM(QTY_RECEIVED) FROM v_im_shipsku SS ");
            sql.append("                                               WHERE MR.SHIPMENT = SS.SHIPMENT ");
            sql.append("                                               AND MR.ITEM = SS.ITEM)) ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());

            stmt.setString(1, itemId);
            stmt.setLong(2, Long.parseLong(receiptId));
            stmt.setString(3, itemId);
            stmt.setLong(4, Long.parseLong(receiptId));

            rs = stmt.executeQuery();

            String item = null;

            if (rs.next()) {
                item = rs.getString(1);
            }

            return item;
        }

        catch (Exception e) {
            throw new ReIMException("Error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("Error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }

    public double getReceiptQty(String itemId, String receiptId) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmnt = (OraclePreparedStatement) conn.prepareStatement("SELECT SUM(QTY_RECEIVED)"
                    + " FROM v_im_shipsku WHERE SHIPMENT = ?" + " AND ITEM = ?");

            double qtyReceived = Double.MIN_VALUE;

            stmnt.setString(1, receiptId);
            stmnt.setString(2, itemId);

            rs = stmnt.executeQuery();

            if (rs.next()) {
                qtyReceived = rs.getDouble(1);
            }
            return qtyReceived;
        } catch (Exception e) {
            throw new ReIMException("error.get_qty_received", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.get_qty_received", Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * This method returns the available to match quantity on each receipt for the given item.
     * 
     * @param item
     *            Item to match
     * @param receipts
     *            Receipts for available quantity
     * @return TreeMap Ordered collection by receipt for available quantity by item
     * @throws ReIMException
     */
    public TreeMap<String, Double> getItemQuantityAvailable(String[] receipts, String item)
            throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();
            TreeMap<String, Double> quantityAvailable = new TreeMap<String, Double>();

            StringBuffer query = new StringBuffer(
                    "SELECT SUM(SHP.QTY_RECEIVED) - NVL(MRI.QTY_MATCHED, 0) QTY_AVAILABLE, SHP.SHIPMENT ");
            query.append(" FROM v_im_shipsku SHP, ");
            query.append(" IM_PARTIALLY_MATCHED_RECEIPTS MRI ");
            query.append(" WHERE MRI.SHIPMENT (+) = SHP.SHIPMENT ");
            query.append(" AND MRI.ITEM (+) = SHP.ITEM ");
            query.append(" AND SHP.ITEM = '");
            query.append(item);
            query.append("' AND SHP.SHIPMENT IN (");

            for (int i = 0; i < receipts.length; i++) {
                query.append(receipts[i]);

                if (i != receipts.length - 1) {
                    query.append(",");
                }
            }

            query.append(")");
            query.append(" GROUP BY SHP.SHIPMENT, MRI.QTY_MATCHED");
            rs = stmt.executeQuery(query.toString());

            while (rs.next()) {
                Double qtyAvailable = new Double(rs.getDouble("QTY_AVAILABLE"));

                quantityAvailable.put(Long.toString(rs.getLong("SHIPMENT")), qtyAvailable);
            }

            return quantityAvailable;
        } catch (Exception e) {
            throw new ReIMException("error.receipt_item_quantity_available", Severity.ERROR, e,
                    this, new String[] { item});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.receipt_item_quantity_available", Severity.ERROR,
                        ex, this, new String[] { item});
            }
        }
    }

    public double getAvailableToMatchQty(long receiptId, String itemId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT SUM(SK.QTY_RECEIVED) - NVL(M.QTY_MATCHED, 0)"
                            + " FROM v_im_shipsku SK, IM_PARTIALLY_MATCHED_RECEIPTS M"
                            + " WHERE SK.SHIPMENT = M.SHIPMENT (+)"
                            + "   AND SK.ITEM = M.ITEM (+) AND SK.SHIPMENT = " + receiptId
                            + "   AND SK.ITEM = '" + itemId + "'" + " GROUP BY M.QTY_MATCHED ");

            rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            } else {
                return Double.MIN_VALUE;
            }
        } catch (Exception e) {
            throw new ReIMException("error.cannot_get_available_to_match_qty", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (rs != null) rs.close();

                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new ReIMException("error.cannot_get_available_to_match_qty", Severity.ERROR,
                        e, this);
            }
        }
    }

    public HashMap<String, Double> getUnmatchedReceiptAmountsByShipmentId(
            ReceiptWriteOff[] receiptWriteOffs) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String schemaOwner = DatasourceProperties.schemaOwner; 
            StringBuffer selectClause = new StringBuffer();
            selectClause
            .append("SELECT SUM((QTY_RECEIVED*UNIT_COST) - NVL(M.QTY_MATCHED, 0)*UNIT_COST),"
                    + " SK.SHIPMENT "
                    // BRN V1.3 begin
                    + " FROM "
                    + " ( select ss.shipment, ss.item, max(ss.unit_cost) unit_cost, sum(nvl(ss.qty_received,0)) qty_received "
                    + "          from v_im_shipsku ss"
                    + "         group by ss.shipment, ss.item ) SK, "
                    + "      IM_PARTIALLY_MATCHED_RECEIPTS M, "
                    + "      SHIPMENT SH"
                    + " WHERE SK.SHIPMENT = SH.SHIPMENT "
                    + " AND SK.SHIPMENT = M.SHIPMENT  (+)  "
                    + " AND sh.status_code in ('R', 'U', 'C')  "
                    + " AND nvl(sh.invc_match_status, 'U') = 'U' " 
                    + " AND SK.ITEM = M.ITEM (+) "
                    + " AND SH.SHIPMENT IN( SELECT * FROM TABLE(CAST(? AS "+schemaOwner.toUpperCase() +".NUMBERLIST_TBL)))");
            		// BRN V1.3 end
            selectClause.append(" GROUP BY SK.SHIPMENT ");
            
            stmt = (OraclePreparedStatement) conn.prepareStatement(selectClause.toString());
            
            String[] receiptNumber = new String[receiptWriteOffs.length];
            
            for (int i = 0; i < receiptWriteOffs.length; i++)
            {
                receiptNumber[i] = Long.toString(receiptWriteOffs[i].getReceiptNumber());
            }
            
            ArrayDescriptor ad = ArrayDescriptor.createDescriptor(schemaOwner.toUpperCase()+".NUMBERLIST_TBL",conn);
            ARRAY array = new ARRAY(ad,conn,receiptNumber);
            
            ((OraclePreparedStatement)stmt).setARRAY(1, array);
            
            rs = stmt.executeQuery();
            HashMap unmatchedAmounts = new HashMap();

            while (rs.next()) {
                    unmatchedAmounts.put(rs.getString(2), new Double(rs.getDouble(1)));
            }

            return unmatchedAmounts;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_get_unmatched_amounts", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new ReIMException("error.cannot_get_unmatched_amounts", Severity.ERROR, e,
                        this);
            }
        }
    }

    public void lockReceiptGroup(Receipt[] receipts) throws ReIMException, SQLException {
        
        OraclePreparedStatement stmt = null;
        try {
            String schemaOwner = DatasourceProperties.schemaOwner;
            StringBuffer sql = new StringBuffer(
                    " SELECT 'x' " +
                    " FROM shipsku, " +
                    " ( SELECT /*+ cardinality (val 100) */ VALUE (val) ship " +
                    "       FROM TABLE (CAST (? AS " + schemaOwner.toUpperCase() + ".NUMBERLIST_TBL)) val) tbl" +
                    " WHERE tbl.ship = shipsku.shipment " +
                    " FOR UPDATE OF shipment NOWAIT");                  
            
            Connection conn = TransactionManagerFactory.getInstance().getConnection();                      
            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString()); 
            String[] receiptNumbers=new String[receipts.length];
            
            for (int i = 0; i < receipts.length; i++) 
            {
                receiptNumbers[i]=receipts[i].getReceiptId();
            }             
              
            //Define the ARRAY object to bind
            ArrayDescriptor ad = ArrayDescriptor.createDescriptor(schemaOwner.toUpperCase() + ".NUMBERLIST_TBL",conn);
            ARRAY array = new ARRAY(ad,conn,receiptNumbers);

            //Bind and execute
            ((OraclePreparedStatement)stmt).setARRAY(1,array);
            stmt.execute();       
        } catch (SQLException exception) {
            if (exception.getMessage().equals(
                    "ORA-00054: resource busy and acquire with NOWAIT specified\n")) {
                throw exception;
            } else {
                throw new ReIMException("error.shipsku_bean.lock", Severity.ERROR, exception, this);
            }
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception exception) {
                throw new ReIMException("error.shipsku_bean.lock", Severity.ERROR, exception, this);
            }
        }
    }
      
    public void updateShipskuQtyMatched(String receiptId, String ItemId, double qtymatched) throws ReIMException {
        OraclePreparedStatement stmnt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmnt = (OraclePreparedStatement) conn.prepareStatement("UPDATE SHIPSKU SET QTY_MATCHED=? WHERE SHIPMENT=? AND ITEM=? ");
            stmnt.setDouble(1,qtymatched);
            stmnt.setString(2, receiptId);
            stmnt.setString(3, ItemId);

            stmnt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.get_qty_received", Severity.ERROR, e, this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("error.get_qty_received", Severity.ERROR, ex, this);
            }
        }
        
    }
    
    private static final String READ_IM_INVOICE_DETAIL = "SELECT NVL(IM_INVOICE_DETAIL.RESOLUTION_ADJUSTED_QTY,0)+NVL(IM_INVOICE_DETAIL.QTY_VARIANCE_WITHIN_TOLERANCE,0) FROM IM_INVOICE_DETAIL WHERE IM_INVOICE_DETAIL.DOC_ID= ? AND IM_INVOICE_DETAIL.ITEM=?";

    private static final String UPDATE_SHIPSKU_ITEM = "UPDATE SHIPSKU SET QTY_MATCHED = ? WHERE SHIPMENT = ? AND ITEM = ?";
    
    /**
     * This method is used update the Shipsku records when an
     * invoice in unresolved or mulit-unresolved status and no discrepancies resolved is marked for
     * deletion.
     */
    public void removeOrUpdateShipskuQtyMatched(ImReceiptItemPostingRow[] iripRows) throws ReIMException {

    	OraclePreparedStatement readStmt = null;
        OraclePreparedStatement updateStmt = null;
        OraclePreparedStatement readStmtShipsku = null;
        ResultSet rs = null;
        ResultSet rsShipsku = null;
        
        String readShipsku="SELECT nvl(SHIPSKU.QTY_MATCHED,0) FROM SHIPSKU WHERE SHIPMENT = ? AND ITEM = ? ";
        
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            readStmtShipsku=(OraclePreparedStatement) conn
            .prepareStatement(readShipsku);
            updateStmt = (OraclePreparedStatement) conn
            .prepareStatement(UPDATE_SHIPSKU_ITEM);
            boolean updateInd = false;
            for (int i = 0; i < iripRows.length; i++) {
            	ImReceiptItemPostingRow receiptItem = (ImReceiptItemPostingRow)iripRows[i];
            	readStmtShipsku.setLong(1,receiptItem.getReceiptId());
            	readStmtShipsku.setString(2, receiptItem.getItemId());
            	rsShipsku = readStmtShipsku.executeQuery();
                    // update row
					if (rsShipsku.next()) {
						double matchQty = rsShipsku.getDouble(1);
						updateInd = true;
						updateStmt.setDouble(1, (matchQty - receiptItem.getQtyMatched()));
						updateStmt.setLong(2, receiptItem.getReceiptId());
						updateStmt.setString(3, receiptItem.getItemId());
						updateStmt.addBatch();
					}
            }
            if (updateInd) {
                updateStmt.executeBatch();
            }
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_remove_or_update_qty_matched", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (readStmtShipsku != null) {
                	readStmtShipsku.close();
                }
               
                if (updateStmt != null) {
                    updateStmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_update_qty_matched", Severity.ERROR,
                        exception, this);
            }
        }
    }
}
