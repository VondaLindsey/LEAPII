package com.retek.reim.ui.discrepancyResolution;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.retail.reim.services.IVarianceResolutionService;
import oracle.retail.reim.services.impl.VarianceResolutionService;
import oracle.retail.reim.services.ui.discrepancyResolution.IDiscrepancyResolutionUIService;
import oracle.retail.reim.services.ui.discrepancyResolution.IPriceReviewListUIService;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.beans.factory.annotation.Autowired;

import smr.retek.reim.db.SmrImDocHeadAccessExt;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.UserRole;
import com.retek.reim.business.document.Document;
import com.retek.reim.locking.LockingData;
import com.retek.reim.locking.TableRecordLockingService;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;

 /**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		05-Mar-2013	IMS135775:  BRN: RCA not updating the ORDLOC and SHIPSKU correctly
 * 															Move the call to Auto Resolve to the trigger and remove from the Java code when RCA is performed.
 *
 */
 
public class PriceReviewVarianceResolutionSaveAction extends ReIMSecureAction {

    private IVarianceResolutionService varianceResolutionService;
    private IPriceReviewListUIService priceReviewListUIService;
    private IDiscrepancyResolutionUIService discrepancyResolutionUIService;

    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        HttpSession session = request.getSession();
        PriceReviewListForm priceReviewListForm = (PriceReviewListForm) form;

        String failureMapping;
        if (priceReviewListForm.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
            failureMapping = "failureInvoice";
        } else {
            failureMapping = "failureDocument";
        }

        try {
            // Check if the user still has the document locked without a
            // timeout, and then reset the timeout
            String currentUserId = ReIMUserContext.getUsername();
            UserRole userRole = ReIMUserContext.getUserRole();
            // Removed the code that was made for substitution item

            String docId = priceReviewListForm.getDocId();
            String currentUserWithLock = ServiceFactory.getTableRecordLockingService()
                    .getUserIdLockingRecordOnTable(LockingData.DOC_HEAD_LOCK_TABLE,
                            Long.parseLong(docId));
            if (currentUserWithLock != null && currentUserWithLock.equals(currentUserId)) {
                TableRecordLockingService.refreshTimeStampOnLockTable(
                        LockingData.DOC_HEAD_LOCK_TABLE, Long.parseLong(docId));
            } else {
                saveErrors(request, errors, "alert.lock_expired");
                return mapping.findForward("failure");
            }

            String rerouteBusinessRoleId = getDiscrepancyResolutionUIService().rerouteActionExists(
                    priceReviewListForm.getResolutionDetails());
            boolean rerouteExists = (rerouteBusinessRoleId != null ? true : false);
            Resolution[] resolutions = getDiscrepancyResolutionUIService().createResolutions(
                    priceReviewListForm.getResolutionDetails());

            Document fullDocument = getVarianceResolutionService().getDocument(resolutions);
            String currencyCode = priceReviewListForm.getCurrency();

            double outstandingVariance = getPriceReviewListUIService()
                    .calculateOutstandingVariance(priceReviewListForm);

            boolean withinTolerance = false;
            if (priceReviewListForm.getVarianceResolutionLevel().equals(
                    PriceReviewListForm.RESOLUTION_TO_ZERO)) {
                // It is expected that for disputed credit memos,
                // withinTolerance will be true only
                // if the variance is resolved exactly to zero.
                if (outstandingVariance != 0) {
                    if (!rerouteExists) {
                        saveErrors(request, errors, "error.variance_not_to_zero");
                    }
                    withinTolerance = false;
                } else {
                    withinTolerance = true;
                }
            } else {
                // It is expected that for merchandise invoices, withinTolerance
                // will be true only
                // if the variance is resolved to within the appropriate
                // tolerance.
                double adjustedOrderOtherCost = ReIMMoney.parseCurrencyString(
                        priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue();
                double adjustedDocumentCost = ReIMMoney.parseCurrencyString(
                        priceReviewListForm.getDocCost(), currencyCode).doubleValue();
                double resolutionAmounts = getPriceReviewListUIService().calculateSumResolutions(
                        priceReviewListForm);

                if (priceReviewListForm.getSelectedCost().equals(PriceReviewListForm.ORDER_COST)) {
                    // Order cost was correct. Adjust the document cost.
                    adjustedDocumentCost = adjustedDocumentCost + resolutionAmounts;
                } else if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.INVOICE_COST)) {
                    // Document cost was correct. Adjust the order cost.
                    // Since variance here is calculated as order - invoice we
                    // want to subtract the resolution amounts
                    // Thus if the variance was negative (order cost < invoice)
                    // the resolutions
                    // will be added to the order because the resolutions have
                    // negative amount,
                    // if it is postive it will be subtracted. This way we can
                    // truely check variance within tolerance.

                    adjustedOrderOtherCost = adjustedOrderOtherCost - resolutionAmounts;
                } else // other cost was specified.
                {
                    // Other cost was specified. Adjust the document cost and
                    // order cost.
                    adjustedDocumentCost = adjustedDocumentCost + resolutionAmounts;
                    adjustedOrderOtherCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getOtherCost(), currencyCode).doubleValue();
                }

                if (fullDocument != null) {
                    withinTolerance = getVarianceResolutionService().isCostVarianceWithinTolerance(
                            outstandingVariance, adjustedDocumentCost, adjustedOrderOtherCost,
                            priceReviewListForm.getSelectedItem(), fullDocument);
                }
                if (!withinTolerance) {
                    if (VarianceResolutionService.isFullResolutionRequired(resolutions)) {
                        errors.add("error.unable_to_save_resolution", new ActionError(
                                "error.unable_to_save_resolution"));
                        saveErrors(request, errors);
                        return mapping.findForward(failureMapping);
                    } else if ((priceReviewListForm.getSaveAction().equals(
                            PriceReviewListForm.SAVE_ACTION_APPLY_ALL) && !rerouteExists)
                            || (priceReviewListForm.getResolutionDetails() != null
                                    && priceReviewListForm.getResolutionDetails().length != 1

                            && rerouteExists))

                    {
                        saveErrors(request, errors,
                                "error.resolution_apply_all_within_tolerance_required");
                        return mapping.findForward(failureMapping);
                    } else {
                        if (!rerouteExists) {
                            // If none of the actions include a reroute, display
                            // a message to the user that
                            // the discrepancy is only partially resolved
                            saveErrors(request, errors, "error.variance_not_within_tolerance");
                        }
                    }
                } else if (rerouteExists) {
                    // Don't allow rereoute if discrepancy has already been
                    // fully resolved.
                    saveErrors(request, errors, "error.no_reroute_when_variance_zero");
                    return mapping.findForward(failureMapping);
                }
            }
            String backPage = priceReviewListForm.getBackPage();
            boolean fromDetailMatch = false;
            if (backPage.equals("detailMatchBeginJSP")) {
                fromDetailMatch = true;
            }

            if (priceReviewListForm.getResolutionDetails() != null) {
                double resolutionCost;
                Double currentOrderCost = null;

                if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.CREDIT_MEMO_COST)) {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getDocCost(), currencyCode).doubleValue();
                } else if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.ORDER_COST)) {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue();
                    currentOrderCost = new Double(ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue());
                } else if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.INVOICE_COST)) {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getDocCost(), currencyCode).doubleValue();
                    currentOrderCost = new Double(ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue());
                } else // other cost
                {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getOtherCost(), currencyCode).doubleValue();
                    currentOrderCost = new Double(ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue());
                }

                if (priceReviewListForm.getReceipts() == null
                        || priceReviewListForm.getReceipts().size() == 0) {
                    Receipt[] receipts = ServiceFactory.getReceiptService()
                            .selectReceiptsFromInvoiceOrder(priceReviewListForm.getOrderId(),
                                    priceReviewListForm.getLocation(), false);
                    ArrayList receiptIds = new ArrayList(receipts.length);
                    for (int i = 0; i < receipts.length; i++) {
                        receiptIds.add(receipts[i].getReceiptId());
                    }
                    priceReviewListForm.setReceipts(receiptIds);
                }

                getVarianceResolutionService().saveSelectedResolutionsAndAmount(
                        resolutions,
                        fullDocument,
                        withinTolerance,
                        Long.parseLong(priceReviewListForm.getSelectedCostDiscrepancyId()),
                        Resolution.TYPE_COST,
                        resolutionCost,
                        priceReviewListForm.getSaveAction().equals(

                        PriceReviewListForm.SAVE_ACTION_APPLY_ALL),
                        currentOrderCost,
                        new Double(ReIMMoney.parseCurrencyString(priceReviewListForm.getDocCost(),
                                currencyCode).doubleValue()), outstandingVariance,
                        priceReviewListForm.getReceipts(), fromDetailMatch);
                priceReviewListForm.setReceipts(null);

            }

            String previousBusinessRoleId = priceReviewListForm.getBusinessRoleId();

            if (fromDetailMatch) {
                priceReviewListForm.setBackPage(ReIMConstants.EMPTY_STRING);
                if(priceReviewListForm.getSaveAction().equals(PriceReviewListForm.SAVE_ACTION_APPLY_ALL))
                {
                	request.getSession().setAttribute("fromSummaryMatchScreen", "true");
                }
                // BRN IMS135775 OLR V1.3 Removed below line.
                // updateOrdShipCost(priceReviewListForm.getOrderId(), priceReviewListForm.getLocation(), priceReviewListForm.getItem() );
                return mapping.findForward("detailMatch");
            } else // return to appropriate cost review screens
            {
                if (priceReviewListForm.getSaveAction().equals(
                        PriceReviewListForm.SAVE_ACTION_APPLY_ALL)) {
                    // Return to the cost review list screen by re-querying all
                    // of the
                    // discrepancies.
                	
					// BRN IMS135775 OLR V1.3 Removed below line.
                	// updateOrdShipCost(priceReviewListForm.getOrderId(), priceReviewListForm.getLocation(), priceReviewListForm.getItem() );
                    return mapping.findForward("successApplyAll");
                } else if (!withinTolerance && !rerouteExists) {
                    // Return to the cost review detail screen.
					
                	// BRN IMS135775 OLR V1.3 Removed below line.
                	// updateOrdShipCost(priceReviewListForm.getOrderId(), priceReviewListForm.getLocation(), priceReviewListForm.getItem() );
                    return mapping.findForward("successMore");
                } else if (priceReviewListForm.getPriceReviewDetail().length > 1) {
                    // There are additional PriceReviewDetail records for this
                    // PriceReview
                    // beyond the one that was either resolved within tolerance
                    // or rerouted.

                    boolean listRecordIncreased = false;
                    PriceReview newPriceReviewList = null;
                    StringBuffer currentDiscrepancyListRow = new StringBuffer();

                    // Get a unique key representing the correct PriceReview
                    // object partially resolved
                    currentDiscrepancyListRow.append(priceReviewListForm.getDepartment());
                    currentDiscrepancyListRow.append(priceReviewListForm.getClassId());
                    currentDiscrepancyListRow.append(priceReviewListForm.getSupplier());
                    currentDiscrepancyListRow.append(priceReviewListForm.getResolveByDate());
                    currentDiscrepancyListRow.append(priceReviewListForm.getRoutingDate());
                    currentDiscrepancyListRow.append(priceReviewListForm.getCashDiscount());
                    currentDiscrepancyListRow.append(priceReviewListForm.getDocId());

                    String currentDiscrepancyListRowReviewerRoleId = priceReviewListForm
                            .getBusinessRoleId();

                    StringBuffer discrepancyListRows = new StringBuffer();
                    for (int i = 0; i < priceReviewListForm.getPriceReviewList().length; i++) {
                        // Get a unique key for the current PriceReview object
                        // representing
                        // the pattern used for currentDiscrepancyListRow
                        discrepancyListRows = new StringBuffer();
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getDepartment());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getClassId());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getSupplier());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getResolveByDate());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getRouteDate());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getCashDiscount());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getDocId());

                        String discrepancyListRowsReviewerRoleId = priceReviewListForm
                                .getPriceReviewList()[i].getReviewerGroup();

                        if (currentDiscrepancyListRow.toString().equals(
                                discrepancyListRows.toString())) {
                            // The current PriceReview object from the list
                            // matches the PriceReview
                            // object partially resolved.
                            if (rerouteExists && userRole.getCostReview().equals(ReIMConstants.ALL)) {
                                if (rerouteBusinessRoleId.equals(discrepancyListRowsReviewerRoleId)) {
                                    // Increase the number of line exceptions
                                    // for the price review object.
                                    priceReviewListForm.getPriceReviewList()[i]
                                            .increaseNoOfLineExceptions();

                                    // This indicates that a new list record
                                    // will not need to be created since
                                    // the rerouted discrepancy fits within an
                                    // existing PriceReviewList.
                                    listRecordIncreased = true;
                                } else {
                                    // Decrease the number of line exceptions
                                    // for the price review object.

                                    // find where I came from....
                                    if (previousBusinessRoleId

                                    .equalsIgnoreCase(discrepancyListRowsReviewerRoleId)) {
                                        priceReviewListForm.getPriceReviewList()[i]

                                        .decreaseNoOfLineExceptions();

                                        // In case a new price review list
                                        // object needs to be created, this
                                        // would
                                        // be the object to base the new one on.
                                        newPriceReviewList = priceReviewListForm
                                                .getPriceReviewList()[i];
                                    }

                                }
                            } else if (currentDiscrepancyListRowReviewerRoleId
                                    .equals(discrepancyListRowsReviewerRoleId)) {
                                // Decrease the number of line exceptions for
                                // the price review object.
                                // Since no reroute or only user access, no list
                                // records will possibly be applied, so break
                                // out of the loop.
                                priceReviewListForm.getPriceReviewList()[i]
                                        .decreaseNoOfLineExceptions();
                                break;
                            }
                        }
                    }

                    if (rerouteExists) {
                        if (!listRecordIncreased
                                && userRole.getCostReview().equals(ReIMConstants.ALL)) {
                            // Since a reroute exists and this action did not
                            // already increase the number
                            // in the existing list and the user has all access,
                            // there is a need to add a new list record.
                            ArrayList priceReviewListArray = new ArrayList();
                            int length = priceReviewListForm.getPriceReviewList().length;
                            for (int i = 0; i < length; i++) {
                                priceReviewListArray
                                        .add(priceReviewListForm.getPriceReviewList()[i]);
                            }
                            newPriceReviewList = newPriceReviewList
                                    .copyForNewReviewerGroup(rerouteBusinessRoleId);
                            priceReviewListArray.add(newPriceReviewList);
                            priceReviewListForm.setPriceReviewList((PriceReview[])

                            priceReviewListArray.toArray(new

                            PriceReview[priceReviewListArray.size()]));
                        }
                    }
                    // BRN IMS135775 OLR V1.3 Removed below line.
                    // updateOrdShipCost(priceReviewListForm.getOrderId(), priceReviewListForm.getLocation(), priceReviewListForm.getItem() );
                    // Return to the cost review detail screen.
                    return mapping.findForward("successMore");
                } else {
                    // There are no other PriceReviewDetail records for this
                    // PriceReview
                    // beyond the one that was either resolved within tolerance
                    // or rerouted.

                    boolean listRecordIncreased = false;
                    PriceReview newPriceReviewList = null;

                    // Get a unique key representing the correct PriceReview
                    // object fully resolved
                    StringBuffer currentDiscrepancyListRow = new StringBuffer();

                    currentDiscrepancyListRow.append(priceReviewListForm.getDepartment());
                    currentDiscrepancyListRow.append(priceReviewListForm.getClassId());
                    currentDiscrepancyListRow.append(priceReviewListForm.getSupplier());
                    currentDiscrepancyListRow.append(priceReviewListForm.getResolveByDate());
                    currentDiscrepancyListRow.append(priceReviewListForm.getRoutingDate());
                    currentDiscrepancyListRow.append(priceReviewListForm.getCashDiscount());
                    currentDiscrepancyListRow.append(priceReviewListForm.getDocId());

                    StringBuffer discrepancyListRows = new StringBuffer();

                    ArrayList priceReviewListArray = new ArrayList();
                    for (int i = 0; i < priceReviewListForm.getPriceReviewList().length; i++) {
                        // Get a unique key for the current PriceReview object
                        // representing
                        // the pattern used for currentDiscrepancyListRow
                        discrepancyListRows = new StringBuffer();
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getDepartment());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getClassId());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getSupplier());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getResolveByDate());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getRouteDate());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getCashDiscount());
                        discrepancyListRows.append(priceReviewListForm.getPriceReviewList()[i]
                                .getDocId());

                        String discrepancyListRowsReviewerRoleId = priceReviewListForm
                                .getPriceReviewList()[i].getReviewerGroup();

                        if (currentDiscrepancyListRow.toString().equals(
                                discrepancyListRows.toString())) {
                            if (rerouteExists && userRole.getCostReview().equals(ReIMConstants.ALL)) {
                                if (rerouteBusinessRoleId.equals(discrepancyListRowsReviewerRoleId)) {
                                    // Increase the number of line exceptions
                                    // for the price review object.
                                    priceReviewListForm.getPriceReviewList()[i]
                                            .increaseNoOfLineExceptions();

                                    // This indicates that a new list record
                                    // will not need to be created since
                                    // the rerouted discrepancy fits within an
                                    // existing PriceReviewList.
                                    listRecordIncreased = true;

                                    // This object should remain in the list.
                                    priceReviewListArray.add(priceReviewListForm

                                    .getPriceReviewList()[i]);
                                } else {
                                    // find where I came from....
                                    if (previousBusinessRoleId

                                    .equalsIgnoreCase(discrepancyListRowsReviewerRoleId)) {
                                        // This object with the current reviewer
                                        // role will be removed from the list.

                                        // In case a new price review list
                                        // object needs to be created, this
                                        // would
                                        // be the object to base the new one on.
                                        newPriceReviewList = priceReviewListForm
                                                .getPriceReviewList()[i];
                                    } else {
                                        priceReviewListArray.add(priceReviewListForm

                                        .getPriceReviewList()[i]);
                                    }
                                }
                            } // else: This object with the current reviewer
                            // role will be removed from the list
                            // automatically.
                        } else {
                            // The current PriceReview object from the list does
                            // not match the PriceReview
                            // object fully resolved. This object should remain
                            // in the list. If processing
                            // does not reach this code, then the fully resolved
                            // object will be effectively
                            // removed from the list.
                            priceReviewListArray.add(priceReviewListForm.getPriceReviewList()[i]);
                        }
                    }

                    if (rerouteExists && userRole.getCostReview().equals(ReIMConstants.ALL)) {
                        if (!listRecordIncreased) {
                            // Since a reroute exists and this action did not
                            // already increase the number
                            // in the existing list, there is a need to add a
                            // new list record.
                            newPriceReviewList = newPriceReviewList
                                    .copyForNewReviewerGroup(rerouteBusinessRoleId);
                            priceReviewListArray.add(newPriceReviewList);
                        }
                    }

                    // verify that any lock for the document is released.
                    long[] lockedDocId = new long[1];
                    lockedDocId[0] = Long.parseLong(priceReviewListForm.getDocId());
                    ServiceFactory.getTableRecordLockingService().releaseLockOnRecordGroupForUser(
                            LockingData.DOC_HEAD_LOCK_TABLE, currentUserId, lockedDocId);

                    updateOrdShipCost(priceReviewListForm.getOrderId(), priceReviewListForm.getLocation(), priceReviewListForm.getItem() );
                    if (priceReviewListArray.size() > 0) {
                        priceReviewListForm.setPriceReviewList((PriceReview[]) priceReviewListArray
                                .toArray(new PriceReview[priceReviewListArray.size()]));

                        // Return to the cost review list screen which will
                        // display the revised list of PriceReview objects.
                        session.setAttribute("returningScreen", "returningScreen");
                        return mapping.findForward("successFull");
                    } else {
                        // Return to the invoice matching menu. No other cost
                        // discrepancies are available.
                        return mapping.findForward("successDone");
                    }
                }
            }
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return mapping.findForward(failureMapping);
        } catch (Exception e) {
            ReIMException newEx = new ReIMException("error.unable_to_save_variance_resolutions",
                    Severity.ERROR, e, this);
            saveErrors(request, errors, newEx);
            return mapping.findForward(failureMapping);
        }
    }

    private IVarianceResolutionService getVarianceResolutionService() {

        return varianceResolutionService;
    }
    private void updateOrdShipCost(String order_no, String location, String item_no) throws ReIMException{
        SmrImDocHeadAccessExt smr = new SmrImDocHeadAccessExt();
        smr.updateCostQty(order_no, location, item_no);
    }
    @Autowired
    public void setVarianceResolutionService(IVarianceResolutionService varianceResolutionService) {

        this.varianceResolutionService = varianceResolutionService;
    }

    private IPriceReviewListUIService getPriceReviewListUIService() {

        return priceReviewListUIService;
    }

    @Autowired
    public void setPriceReviewListUIService(IPriceReviewListUIService priceReviewListUIService) {

        this.priceReviewListUIService = priceReviewListUIService;
    }

    private IDiscrepancyResolutionUIService getDiscrepancyResolutionUIService() {

        return discrepancyResolutionUIService;
    }

    @Autowired
    public void setDiscrepancyResolutionUIService(
            IDiscrepancyResolutionUIService discrepancyResolutionUIService) {

        this.discrepancyResolutionUIService = discrepancyResolutionUIService;
    }
}
