package com.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		13-May-2013	Syed Qadri		Modification Change :Commented out the SELECT statement to use the new one. IMS Ticket # 160668 (Release 1549). This is for 
 * 		                                                         performance enhancement according Metalink Doc id 847827 applied Bug fix 8507757.
 * 										
 */
public class ImDocDetailCommentsAccessExt extends ImDocDetailCommentsAccess implements
        IImDocDetailCommentsAccessExt {
    /**
     * This method retrieves comments for a specified document, item, and reason code.
     * 
     * @return ImDocDetailCommentsRow[]
     * @param docId
     *            Invoice id
     * @param itemId
     *            Item id
     * @param reasonCode
     *            reason code ID
     * @throws ReIMException
     */
    public ImDocDetailCommentsRow[] getCommentsForDocItemReason(String commentDiscrepancyType,
            long docId, String itemId, String reasonCode) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer();
            whereClause.append(docIdColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(itemColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(reasonCodeIdColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(discrepancyTypeColumn);
            whereClause.append(" = ? ");

            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment(whereClause.toString());
            frag.setLong(1, docId);
            frag.setString(2, itemId);
            frag.setString(3, reasonCode);
            frag.setString(4, commentDiscrepancyType);

            String orderByClause = "CREATE_DATETIME DESC ";

            return read(frag, null, null, orderByClause);
        } catch (ReIMException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ReIMException("error.comment_unable_to_get", Severity.ERROR, ex, this);
        }
    }

    public ImDocDetailCommentsRow[] getCommentsForDocItem(String commentDiscrepancyType,
            long docId, String itemId) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer();
            whereClause.append(docIdColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(itemColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(discrepancyTypeColumn);
            whereClause.append(" = ? ");

            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment(whereClause.toString());
            frag.setLong(1, docId);
            frag.setString(2, itemId);
            frag.setString(3, commentDiscrepancyType);

            String orderByClause = "CREATE_DATETIME DESC ";

            return read(frag, null, null, orderByClause);
        } catch (ReIMException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ReIMException("error.comment_unable_to_get", Severity.ERROR, ex, this);
        }
    }

    public ImDocDetailCommentsRow[] getCommentsForDocItemDebitReason(String commentDiscrepancyType,
            long docId, String itemId, String debitReasonCode) throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer();
            whereClause.append(docIdColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(itemColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(discrepancyTypeColumn);
            whereClause.append(" = ? AND ");
            whereClause.append(debitReasonCodeColumn);
            whereClause.append(" = ? ");

            DALGenPreparedSQLFragment frag = new DALGenPreparedSQLFragment(whereClause.toString());
            frag.setLong(1, docId);
            frag.setString(2, itemId);
            frag.setString(3, commentDiscrepancyType);
            frag.setString(4, debitReasonCode);

            String orderByClause = "CREATE_DATETIME DESC ";

            return read(frag, null, null, orderByClause);
        } catch (ReIMException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ReIMException("error.comment_unable_to_get", Severity.ERROR, ex, this);
        }
    }

    public int getCommentsMaxByteLength() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            int commentsByteLength = 0;
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            // OLR V1.2 Inserted - Begin
            //   stmt = (OraclePreparedStatement) conn
            //           .prepareStatement("SELECT MAX(TEXT) FROM IM_DOC_DETAIL_COMMENTS ");
            stmt = (OraclePreparedStatement) conn
            		.prepareStatement("SELECT TEXT FROM IM_DOC_DETAIL_COMMENTS where rownum = 1 and TEXT is not null");
            // OLR V1.2 Inserted - End
            
            rs = stmt.executeQuery();
            if (rs.next()) {
                commentsByteLength = (rs.getMetaData().getColumnDisplaySize(1));
            }
            return commentsByteLength;
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }
}
