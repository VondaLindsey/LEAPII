package com.retek.reim.db;

import java.lang.reflect.Method;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.Vector;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleStatement;

import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;
import com.retek.reim.merch.utils.SQLSequence;

/**
 * Title: ImQtyDiscrepancyAccess Description: Data Access object for class ImQtyDiscrepancyRow
 * 
 * At the time of generation the table IM_QTY_DISCREPANCY had the following schema :
 * 
 * QTY_DISCREPANCY_ID NUMBER(10) NNPK(Seq) qtyDiscrepancyId,long DOC_ID NUMBER(10) NN docId,long
 * ITEM VARCHAR2(25) NN item,String DEBIT_MEMO_REASON_CODE VARCHAR2(6) debitMemoReasonCode,String
 * LOCATION NUMBER(10) location,long LOC_TYPE VARCHAR2(1) locType,String ORDER_NO NUMBER(8)
 * orderNo,int SUPPLIER NUMBER(10) NN supplier,long ROUTING_DATE DATE NN routingDate,Timestamp
 * RESOLVE_BY_DATE DATE NN resolveByDate,Timestamp QTY_INVOICED NUMBER(12,4) NN qtyInvoiced,double
 * AP_REVIEWER VARCHAR2(30) NN apReviewer,String DOC_TYPE VARCHAR2(6) NN docType,String
 * RESOLUTION_QTY NUMBER(12,4) resolutionQty,double
 * 
 * @author Retek Invoice Matching. Automatically generated from Oracle meta data.
 */

public class ImQtyDiscrepancyAccess implements IImQtyDiscrepancyAccess {
    // static strings useful for building SQL statements
    public static final String tableName = "IM_QTY_DISCREPANCY";

    public static final String qtyDiscrepancyIdColumn = "QTY_DISCREPANCY_ID";

    public static final String docIdColumn = "DOC_ID";

    public static final String itemColumn = "ITEM";

    public static final String debitMemoReasonCodeColumn = "DEBIT_MEMO_REASON_CODE";

    public static final String locationColumn = "LOCATION";

    public static final String locTypeColumn = "LOC_TYPE";

    public static final String orderNoColumn = "ORDER_NO";

    public static final String supplierColumn = "SUPPLIER";

    public static final String routingDateColumn = "ROUTING_DATE";

    public static final String resolveByDateColumn = "RESOLVE_BY_DATE";

    public static final String qtyInvoicedColumn = "QTY_INVOICED";

    public static final String apReviewerColumn = "AP_REVIEWER";

    public static final String docTypeColumn = "DOC_TYPE";

    public static final String resolutionQtyColumn = "RESOLUTION_QTY";

    public static final String[] columns = new String[] { qtyDiscrepancyIdColumn, docIdColumn,
            itemColumn, debitMemoReasonCodeColumn, locationColumn, locTypeColumn, orderNoColumn,
            supplierColumn, routingDateColumn, resolveByDateColumn, qtyInvoicedColumn,
            apReviewerColumn, docTypeColumn, resolutionQtyColumn};

    // NOTE: To change the following value please set
    // ImQtyDiscrepancyRow_BatchUpdateThreshold in dalgen.properties
    static final int BATCH_UPDATE_ROW_THRESHOLD = 2;

    static final int BATCH_INSERT_ROW_THRESHOLD = 2;

    static int ARRAY_PROCESS_SIZE = 1;
    static {
        // NOTE: To change the following value please set ARRAY_PROCESS_SIZE in
        // reim.properties
        ResourceBundle rb = ResourceBundle.getBundle("com.retek.reim.reim");
        ARRAY_PROCESS_SIZE = Integer.parseInt(rb.getString("ARRAY_PROCESS_SIZE"));
    }

    /**
     * Method: read. This method will return a single row from the DB using a Primary Key select.
     * 
     * @param qtyDiscrepancyId
     * @param noRowsFoundIsError
     *            When true, read() will throw an exception for no rows found (SQL 1403). When
     *            false, read() will return a null reference for no rows found.
     * @return ImQtyDiscrepancyRow
     */
    public ImQtyDiscrepancyRow read(long qtyDiscrepancyId, boolean noRowsFoundIsError)
            throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs1 = null;

        String tableQuery = "SELECT IM_QTY_DISCREPANCY.DOC_ID, IM_QTY_DISCREPANCY.ITEM, IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE, IM_QTY_DISCREPANCY.LOCATION, IM_QTY_DISCREPANCY.LOC_TYPE, IM_QTY_DISCREPANCY.ORDER_NO, IM_QTY_DISCREPANCY.SUPPLIER, IM_QTY_DISCREPANCY.ROUTING_DATE, IM_QTY_DISCREPANCY.RESOLVE_BY_DATE, IM_QTY_DISCREPANCY.QTY_INVOICED, IM_QTY_DISCREPANCY.AP_REVIEWER, IM_QTY_DISCREPANCY.DOC_TYPE, IM_QTY_DISCREPANCY.RESOLUTION_QTY FROM IM_QTY_DISCREPANCY WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
            stmnt.setLong(1, qtyDiscrepancyId);
            rs1 = stmnt.executeQuery();
            if (rs1.next()) {
                long location = rs1.getLong(4);
                if (rs1.wasNull()) {
                    location = (Long.MIN_VALUE);
                }
                int orderNo = rs1.getInt(6);
                if (rs1.wasNull()) {
                    orderNo = (Integer.MIN_VALUE);
                }
                double resolutionQty = rs1.getDouble(13);
                if (rs1.wasNull()) {
                    resolutionQty = (Double.MIN_VALUE);
                }
                ImQtyDiscrepancyRow businessObject = new ImQtyDiscrepancyRow(qtyDiscrepancyId, rs1
                        .getLong(1), rs1.getString(2), rs1.getString(3), location,
                        rs1.getString(5), orderNo, rs1.getLong(7), rs1.getTimestamp(8), rs1
                                .getTimestamp(9), rs1.getDouble(10), rs1.getString(11), rs1
                                .getString(12), resolutionQty);

                return (businessObject);
            } else {
                if (noRowsFoundIsError) {
                    Exception ex = new Exception();
                    String exMsg = "" + "Bind variable 1 type=long, value=" + qtyDiscrepancyId
                            + ";";
                    throw new ReIMException("DALGen.cannot_perform_single_select",
                            Severity.ERROR, ex, this, new String[] { tableQuery, exMsg});
                } else {
                    return null;
                }
            }
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variable 1 type=long, value=" + qtyDiscrepancyId + ";";
            throw new ReIMException("DALGen.cannot_perform_single_select", Severity.ERROR, ex,
                    this, new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: read. This method is the same as the normal single row read except that you do not
     * have to load all columns from the database. This may be useful when there is a vary large
     * number of columns on the database and performance is affected.
     * 
     * @see #read(long qtyDiscrepancyId, boolean noRowsFoundIsError)
     * 
     */
    public ImQtyDiscrepancyRow read(String columns[], long qtyDiscrepancyId,
            boolean noRowsFoundIsError) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs1 = null;
        StringBuffer sqlText = new StringBuffer();
        sqlText.append("SELECT IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID");
        // This is to handle table without PK
        sqlText.append(",");
        sqlText.append(columns[0]);
        for (int i = 1; i < columns.length; i++) {
            sqlText.append(",");
            sqlText.append("IM_QTY_DISCREPANCY.");
            sqlText.append(columns[i]);
        }
        sqlText.append(" FROM IM_QTY_DISCREPANCY WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID=?");

        String tableQuery = sqlText.toString();
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);

            stmnt.setLong(1, qtyDiscrepancyId);

            rs1 = stmnt.executeQuery();

            // check for valid ResultSet

            if (rs1.next()) {
                ImQtyDiscrepancyRow businessObject = new ImQtyDiscrepancyRow(qtyDiscrepancyId);
                for (int i = 0; i < columns.length; i++) {
                    Method m = (Method) reflectionPerformanceMap.get(columns[i]);
                    m.invoke(this, new Object[] { businessObject, rs1, new Integer(i + 1 + 1)});
                }

                return (businessObject);
            } else {
                if (noRowsFoundIsError) {
                    Exception ex = new Exception();
                    String exMsg = "" + "Bind variable 1 type=long, value=" + qtyDiscrepancyId
                            + ";";
                    throw new ReIMException("DALGen.cannot_perform_single_select",
                            Severity.ERROR, ex, this, new String[] { tableQuery, exMsg});
                } else {
                    return null;
                }
            }
        } catch (Exception ex) {
            String exMsg = "" + "Bind variable 1 type=long, value=" + qtyDiscrepancyId + ";";
            throw new ReIMException("DALGen.cannot_perform_single_select", Severity.ERROR, ex,
                    this, new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: create. This method will insert a single row on the database using a populated row
     * object. Note that any sequence values will be automatically fetched by this method. To
     * determine the value of a sequence after performing an insert, you may call the relevant
     * get..() method on the row.
     * 
     * @param newRow
     *            The populated row object to insert on the DB.
     */
    public void create(ImQtyDiscrepancyRow newRow) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String sqlTxt = "INSERT INTO IM_QTY_DISCREPANCY(QTY_DISCREPANCY_ID,DOC_ID,ITEM,DEBIT_MEMO_REASON_CODE,LOCATION,LOC_TYPE,ORDER_NO,SUPPLIER,ROUTING_DATE,RESOLVE_BY_DATE,QTY_INVOICED,AP_REVIEWER,DOC_TYPE,RESOLUTION_QTY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            long seqVal = getNextQtyDiscrepancyId();
            stmnt.setLong(1, seqVal);
            newRow.setQtyDiscrepancyId(seqVal);
            stmnt.setLong(2, newRow.getDocId());
            stmnt.setString(3, newRow.getItem());
            stmnt.setString(4, newRow.getDebitMemoReasonCode());
            long location = newRow.getLocation();
            if (location == Long.MIN_VALUE) {
                stmnt.setNull(5, Types.BIGINT);
            } else {
                stmnt.setLong(5, location);
            }
            stmnt.setString(6, newRow.getLocType());
            int orderNo = newRow.getOrderNo();
            if (orderNo == Integer.MIN_VALUE) {
                stmnt.setNull(7, Types.INTEGER);
            } else {
                stmnt.setInt(7, orderNo);
            }
            stmnt.setLong(8, newRow.getSupplier());
            stmnt.setTimestamp(9, newRow.getRoutingDate());
            stmnt.setTimestamp(10, newRow.getResolveByDate());
            stmnt.setDouble(11, newRow.getQtyInvoiced());
            stmnt.setString(12, newRow.getApReviewer());
            stmnt.setString(13, newRow.getDocType());
            double resolutionQty = newRow.getResolutionQty();
            if (resolutionQty == Double.MIN_VALUE) {
                stmnt.setNull(14, Types.DOUBLE);
            } else {
                stmnt.setDouble(14, resolutionQty);
            }
            stmnt.execute();
        } catch (SQLException ex) {
            String exMsg = getBindVariableDebugString(newRow, true);
            System.out.println("#Naveen###########Abort specific logging######starts here #####");
            System.out.println("############exMsg###########"+exMsg);
          	  if (newRow!=null) {
				System.out.print("--QtyDiscrepancyId-->"+ newRow.getQtyDiscrepancyId());
				System.out.print("--Doc_ID-->" + newRow.getDocId());
				System.out.print("--Item-->" + newRow.getItem());
				System.out.print("--DM_Reason-->"+ newRow.getDebitMemoReasonCode());
				System.out.print("--Location-->" + newRow.getLocation());
				System.out.print("--Loc Type-->" + newRow.getLocType());
				System.out.print("--Qty Invoice-->" + newRow.getQtyInvoiced());
				System.out.print("--Qty Resolve-->" + newRow.getResolutionQty());
				System.out.print("--Routing Date-->" + newRow.getRoutingDate());
				System.out.print("--AP Reviewer-->" + newRow.getApReviewer());
				System.out.println("..");
			}else{
				System.out.println("############ newRow is null###########");
			}
			System.out.println("#Naveen###########Abort specific logging######ends here #####"); 
            
            throw new ReIMException("DALGen.cannot_perform_insert", Severity.ERROR, ex, this,
                    new String[] { sqlTxt, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: create. This method will insert a multiple rows on the database using populated row
     * objects. Note that any sequence values will be automatically fetched by this method. To
     * determine the value of a sequence after performing an insert, you may call the relevant
     * get..() method on the row.
     * 
     * @param newRows
     *            An array of populated row objects to insert on the DB.
     */
    public void create(ImQtyDiscrepancyRow[] newRows) throws ReIMException {
        if (newRows.length <= BATCH_INSERT_ROW_THRESHOLD) {
            int arrayLen = newRows.length;
            for (int i = 0; i < arrayLen; i++) {
                this.create(newRows[i]);
            }
            return;
        }

        OraclePreparedStatement stmnt = null;
        String sqlTxt = "INSERT INTO IM_QTY_DISCREPANCY(QTY_DISCREPANCY_ID,DOC_ID,ITEM,DEBIT_MEMO_REASON_CODE,LOCATION,LOC_TYPE,ORDER_NO,SUPPLIER,ROUTING_DATE,RESOLVE_BY_DATE,QTY_INVOICED,AP_REVIEWER,DOC_TYPE,RESOLUTION_QTY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            long seqValQtyDiscrepancyId;
            long location;
            int orderNo;
            double resolutionQty;
            int arrayLen = newRows.length;
            int nbrLoops = 0;
            boolean arrayGreater = false;
            for (int i = 0; i < arrayLen; i++) {
                int record = 0;
                if (arrayGreater) {
                    stmnt.executeBatch();
                    stmnt.close();
                    i = 0;
                    arrayLen -= ARRAY_PROCESS_SIZE;
                    arrayGreater = false;
                    stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
                }
                if (arrayLen > ARRAY_PROCESS_SIZE) {
                    arrayGreater = true;
                    for (int x = 0; x < ARRAY_PROCESS_SIZE; x++) {
                        record = x + (nbrLoops * ARRAY_PROCESS_SIZE);
                        seqValQtyDiscrepancyId = getNextQtyDiscrepancyId();
                        stmnt.setLong(1, seqValQtyDiscrepancyId);
                        newRows[record].setQtyDiscrepancyId(seqValQtyDiscrepancyId);
                        stmnt.setLong(2, newRows[record].getDocId());
                        stmnt.setString(3, newRows[record].getItem());
                        stmnt.setString(4, newRows[record].getDebitMemoReasonCode());
                        location = newRows[record].getLocation();
                        if (location == Long.MIN_VALUE) {
                            stmnt.setNull(5, Types.BIGINT);
                        } else {
                            stmnt.setLong(5, location);
                        }
                        stmnt.setString(6, newRows[record].getLocType());
                        orderNo = newRows[record].getOrderNo();
                        if (orderNo == Integer.MIN_VALUE) {
                            stmnt.setNull(7, Types.INTEGER);
                        } else {
                            stmnt.setInt(7, orderNo);
                        }
                        stmnt.setLong(8, newRows[record].getSupplier());
                        stmnt.setTimestamp(9, newRows[record].getRoutingDate());
                        stmnt.setTimestamp(10, newRows[record].getResolveByDate());
                        stmnt.setDouble(11, newRows[record].getQtyInvoiced());
                        stmnt.setString(12, newRows[record].getApReviewer());
                        stmnt.setString(13, newRows[record].getDocType());
                        resolutionQty = newRows[record].getResolutionQty();
                        if (resolutionQty == Double.MIN_VALUE) {
                            stmnt.setNull(14, Types.DOUBLE);
                        } else {
                            stmnt.setDouble(14, resolutionQty);
                        }
                        stmnt.addBatch();
                    }
                    nbrLoops += 1;
                } else {
                    record = i + (nbrLoops * ARRAY_PROCESS_SIZE);
                    seqValQtyDiscrepancyId = getNextQtyDiscrepancyId();
                    stmnt.setLong(1, seqValQtyDiscrepancyId);
                    newRows[record].setQtyDiscrepancyId(seqValQtyDiscrepancyId);
                    stmnt.setLong(2, newRows[record].getDocId());
                    stmnt.setString(3, newRows[record].getItem());
                    stmnt.setString(4, newRows[record].getDebitMemoReasonCode());
                    location = newRows[record].getLocation();
                    if (location == Long.MIN_VALUE) {
                        stmnt.setNull(5, Types.BIGINT);
                    } else {
                        stmnt.setLong(5, location);
                    }
                    stmnt.setString(6, newRows[record].getLocType());
                    orderNo = newRows[record].getOrderNo();
                    if (orderNo == Integer.MIN_VALUE) {
                        stmnt.setNull(7, Types.INTEGER);
                    } else {
                        stmnt.setInt(7, orderNo);
                    }
                    stmnt.setLong(8, newRows[record].getSupplier());
                    stmnt.setTimestamp(9, newRows[record].getRoutingDate());
                    stmnt.setTimestamp(10, newRows[record].getResolveByDate());
                    stmnt.setDouble(11, newRows[record].getQtyInvoiced());
                    stmnt.setString(12, newRows[record].getApReviewer());
                    stmnt.setString(13, newRows[record].getDocType());
                    resolutionQty = newRows[record].getResolutionQty();
                    if (resolutionQty == Double.MIN_VALUE) {
                        stmnt.setNull(14, Types.DOUBLE);
                    } else {
                        stmnt.setDouble(14, resolutionQty);
                    }
                    stmnt.addBatch();
                }
            }
            stmnt.executeBatch();
        } catch (BatchUpdateException ex1) {
            int failedRowIndex = ex1.getUpdateCounts().length; // as per JDBC
            // 2.0 API
            // standard
            String exMsg = "(unable to determine which batch row caused the error)";
            if (failedRowIndex < newRows.length) {
                exMsg = getBindVariableDebugString(newRows[failedRowIndex], true);
            }
            System.out.println("#Naveen###########Abort specific logging######starts here #####");
            System.out.println("############failedRowIndex###########"+failedRowIndex);
            System.out.println("############ exMsg###########"+ exMsg);
            for (ImQtyDiscrepancyRow iqrr : newRows){
         	   
         	  System.out.print("--QtyDiscrepancyId-->"+iqrr.getQtyDiscrepancyId()); 
         	  System.out.print("--Doc_ID-->"+iqrr.getDocId());
         	  System.out.print("--Item-->"+iqrr.getItem());
         	  System.out.print("--DM_Reason-->"+iqrr.getDebitMemoReasonCode());
         	  System.out.print("--Location-->"+iqrr.getLocation());
         	  System.out.print("--Loc Type-->"+iqrr.getLocType());
         	  System.out.print("--Qty Invoice-->"+iqrr.getQtyInvoiced());
         	  System.out.print("--Qty Resolve-->"+iqrr.getResolutionQty());
         	  System.out.print("--Routing Date-->"+iqrr.getRoutingDate());
         	  System.out.print("--AP Reviewer-->"+iqrr.getApReviewer());
         	  System.out.println("..");
            }
            
            System.out.println("#Naveen###########Abort specific logging######ends here #####"); 
            
             throw new ReIMException("DALGen.cannot_perform_insert", Severity.ERROR, ex1, this,
                     new String[] { sqlTxt, exMsg});
         } catch (SQLException ex) {
             String exMsg = "(unable to determine which batch row caused the error)";
             System.out.println("#Naveen###########Abort specific logging######starts here #####");
             System.out.println("############ exMsg###########"+ exMsg);
             for (ImQtyDiscrepancyRow iqrr : newRows){
          	   
          	  System.out.print("--QtyDiscrepancyId-->"+iqrr.getQtyDiscrepancyId()); 
          	  System.out.print("--Doc_ID-->"+iqrr.getDocId());
          	  System.out.print("--Item-->"+iqrr.getItem());
          	  System.out.print("--DM_Reason-->"+iqrr.getDebitMemoReasonCode());
          	  System.out.print("--Location-->"+iqrr.getLocation());
          	  System.out.print("--Loc Type-->"+iqrr.getLocType());
          	  System.out.print("--Qty Invoice-->"+iqrr.getQtyInvoiced());
          	  System.out.print("--Qty Resolve-->"+iqrr.getResolutionQty());
          	  System.out.print("--Routing Date-->"+iqrr.getRoutingDate());
          	  System.out.print("--AP Reviewer-->"+iqrr.getApReviewer());
          	  System.out.println("..");
             }
             
             System.out.println("#Naveen###########Abort specific logging######ends here #####");
            
            
            throw new ReIMException("DALGen.cannot_perform_insert", Severity.ERROR, ex, this,
                    new String[] { sqlTxt, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: read. This method reads multiple rows from the database using a WHERE clause. Note:
     * Please use the prepared SQL version of this method if possible.
     * 
     * @param whereClause
     *            SQL Fragment that will be used to perform the select. You do not need to include
     *            'SELECT', the table column names, 'FROM' or 'WHERE' within the SQL string as this
     *            is added by this method. Use a null value to select all rows from a table.
     * @param additionalTables
     *            A comma seperated list of additional tables. This allows you SQL expression to
     *            join to other tables as part of the selection criteria - this may be more
     *            efficient than using an IN() statment. Use a null value if there are no additional
     *            tables.
     * @param sqlHint
     *            This parameter can be used if necessary to tune the performance of a particular
     *            SQL statement. tables as part of the selection criteria - this may be moer
     *            efficient than using an IN() statment. Use a null value if no hint is required.
     * @param orderBy
     *            This parameter can be used to specify a comma seperated list of column names for
     *            ordering the result set. You may also use normal SQL extensions such as ASC, DESC.
     *            Use a null value if no ordering is required.
     * @return ImQtyDiscrepancyRow[] If no rows are returned from the database the return value will
     *         be null.
     */
    public ImQtyDiscrepancyRow[] read(String whereClause, String additionalTables, String sqlHint,
            String orderBy) throws ReIMException {
        OracleStatement stmnt = null;
        ResultSet rs1 = null;
        String sqlTxt = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer sqlText = new StringBuffer("SELECT ");
            if (sqlHint != null) {
                sqlText.append(sqlHint);
                sqlText.append(" ");
            }
            sqlText
                    .append("IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID,IM_QTY_DISCREPANCY.DOC_ID,IM_QTY_DISCREPANCY.ITEM,IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE,IM_QTY_DISCREPANCY.LOCATION,IM_QTY_DISCREPANCY.LOC_TYPE,IM_QTY_DISCREPANCY.ORDER_NO,IM_QTY_DISCREPANCY.SUPPLIER,IM_QTY_DISCREPANCY.ROUTING_DATE,IM_QTY_DISCREPANCY.RESOLVE_BY_DATE,IM_QTY_DISCREPANCY.QTY_INVOICED,IM_QTY_DISCREPANCY.AP_REVIEWER,IM_QTY_DISCREPANCY.DOC_TYPE,IM_QTY_DISCREPANCY.RESOLUTION_QTY FROM IM_QTY_DISCREPANCY");
            if (additionalTables != null) {
                sqlText.append(",");
                sqlText.append(additionalTables);
            }
            if (whereClause != null) {
                sqlText.append(" WHERE ");
                sqlText.append(whereClause);
            }
            if (orderBy != null) {
                sqlText.append(" ORDER BY ");
                sqlText.append(orderBy);
            }
            sqlTxt = sqlText.toString();
            stmnt = (OracleStatement) conn.createStatement();
            rs1 = stmnt.executeQuery(sqlTxt);
            Vector businessObjectsVector = new Vector();
            ImQtyDiscrepancyRow businessObjectArray[] = null;
            // check for valid ResultSet
            while (rs1.next()) {
                long location = rs1.getLong(5);
                if (rs1.wasNull()) {
                    location = Long.MIN_VALUE;
                }
                int orderNo = rs1.getInt(7);
                if (rs1.wasNull()) {
                    orderNo = Integer.MIN_VALUE;
                }
                double resolutionQty = rs1.getDouble(14);
                if (rs1.wasNull()) {
                    resolutionQty = Double.MIN_VALUE;
                }
                businessObjectsVector.addElement(new ImQtyDiscrepancyRow(rs1.getLong(1), rs1
                        .getLong(2), rs1.getString(3), rs1.getString(4), location,
                        rs1.getString(6), orderNo, rs1.getLong(8), rs1.getTimestamp(9), rs1
                                .getTimestamp(10), rs1.getDouble(11), rs1.getString(12), rs1
                                .getString(13), resolutionQty));
            }
            if (businessObjectsVector.size() > 0) {
                businessObjectArray = new ImQtyDiscrepancyRow[businessObjectsVector.size()];
                businessObjectsVector.copyInto(businessObjectArray);
                return businessObjectArray;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            throw new ReIMException("DALGen.cannot_perform_bulk_select", Severity.ERROR, ex,
                    this, new String[] { sqlTxt, new String(" (no bind variables) ")});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: read. This method reads multiple rows from the database using a prepared WHERE
     * clause.
     * 
     * @param whereClause
     *            Prepared SQL Fragment that will be used to perform the select. You do not need to
     *            include 'SELECT', the table column names, 'FROM' or 'WHERE' within the SQL string
     *            as this is added by this method. Use a null value to select all rows from a table.
     * @param additionalTables
     *            A comma seperated list of additional tables. This allows you SQL expression to
     *            join to other tables as part of the selection criteria - this may be more
     *            efficient than using an IN() statment. Use a null value if there are no additional
     *            tables.
     * @param sqlHint
     *            This parameter can be used if necessary to tune the performance of a particular
     *            SQL statement. tables as part of the selection criteria - this may be moer
     *            efficient than using an IN() statment. Use a null value if no hint is required.
     * @param orderBy
     *            This parameter can be used to specify a comma seperated list of column names for
     *            ordering the result set. You may also use normal SQL extensions such as ASC, DESC.
     *            Use a null value if no ordering is required.
     * @return ImQtyDiscrepancyRow[] If no rows are returned from the database the return value will
     *         be null.
     * 
     * @see com.retek.rss.utils.DALGenPreparedSQLFragment
     */
    public ImQtyDiscrepancyRow[] read(DALGenPreparedSQLFragment whereClause,
            String additionalTables, String sqlHint, String orderBy) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs1 = null;
        String sqlTxt = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer sqlText = new StringBuffer("SELECT ");
            if (sqlHint != null) {
                sqlText.append(sqlHint);
                sqlText.append(" ");
            }
            sqlText
                    .append("IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID,IM_QTY_DISCREPANCY.DOC_ID,IM_QTY_DISCREPANCY.ITEM,IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE,IM_QTY_DISCREPANCY.LOCATION,IM_QTY_DISCREPANCY.LOC_TYPE,IM_QTY_DISCREPANCY.ORDER_NO,IM_QTY_DISCREPANCY.SUPPLIER,IM_QTY_DISCREPANCY.ROUTING_DATE,IM_QTY_DISCREPANCY.RESOLVE_BY_DATE,IM_QTY_DISCREPANCY.QTY_INVOICED,IM_QTY_DISCREPANCY.AP_REVIEWER,IM_QTY_DISCREPANCY.DOC_TYPE,IM_QTY_DISCREPANCY.RESOLUTION_QTY FROM IM_QTY_DISCREPANCY");
            if (additionalTables != null) {
                sqlText.append(",");
                sqlText.append(additionalTables);
            }
            if (whereClause != null) {
                sqlText.append(" WHERE ");
                sqlText.append(whereClause.getSQLFragment());
            }
            if (orderBy != null) {
                sqlText.append(" ORDER BY ");
                sqlText.append(orderBy);
            }
            sqlTxt = sqlText.toString();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
            if (whereClause != null) {
                whereClause.callSettersOnPreparedStatement(stmnt, 1);
            }
            rs1 = stmnt.executeQuery();
            Vector businessObjectsVector = new Vector();
            ImQtyDiscrepancyRow businessObjectArray[] = null;
            // check for valid ResultSet
            while (rs1.next()) {
                long location = rs1.getLong(5);
                if (rs1.wasNull()) {
                    location = Long.MIN_VALUE;
                }
                int orderNo = rs1.getInt(7);
                if (rs1.wasNull()) {
                    orderNo = Integer.MIN_VALUE;
                }
                double resolutionQty = rs1.getDouble(14);
                if (rs1.wasNull()) {
                    resolutionQty = Double.MIN_VALUE;
                }
                businessObjectsVector.addElement(new ImQtyDiscrepancyRow(rs1.getLong(1), rs1
                        .getLong(2), rs1.getString(3), rs1.getString(4), location,
                        rs1.getString(6), orderNo, rs1.getLong(8), rs1.getTimestamp(9), rs1
                                .getTimestamp(10), rs1.getDouble(11), rs1.getString(12), rs1
                                .getString(13), resolutionQty));
            }
            if (businessObjectsVector.size() > 0) {
                businessObjectArray = new ImQtyDiscrepancyRow[businessObjectsVector.size()];
                businessObjectsVector.copyInto(businessObjectArray);
                return businessObjectArray;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            throw new ReIMException("DALGen.cannot_perform_bulk_select", Severity.ERROR, ex,
                    this, new String[] { sqlTxt, whereClause.getSQLParametersAsText()});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: update. This method updates a single row on the database using the primary key.
     * 
     * @param rowToUpdate
     *            Note that the primary key and at least one other attribute must be populated.
     * 
     */
    public void update(ImQtyDiscrepancyRow rowToUpdate) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String tableQuery = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (rowToUpdate.isFullyPopulated()) {
                tableQuery = "UPDATE IM_QTY_DISCREPANCY SET IM_QTY_DISCREPANCY.DOC_ID = ?, IM_QTY_DISCREPANCY.ITEM = ?, IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE = ?, IM_QTY_DISCREPANCY.LOCATION = ?, IM_QTY_DISCREPANCY.LOC_TYPE = ?, IM_QTY_DISCREPANCY.ORDER_NO = ?, IM_QTY_DISCREPANCY.SUPPLIER = ?, IM_QTY_DISCREPANCY.ROUTING_DATE = ?, IM_QTY_DISCREPANCY.RESOLVE_BY_DATE = ?, IM_QTY_DISCREPANCY.QTY_INVOICED = ?, IM_QTY_DISCREPANCY.AP_REVIEWER = ?, IM_QTY_DISCREPANCY.DOC_TYPE = ?, IM_QTY_DISCREPANCY.RESOLUTION_QTY = ? WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?";
                stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                stmnt.setLong(1, rowToUpdate.getDocId());
                stmnt.setString(2, rowToUpdate.getItem());
                stmnt.setString(3, rowToUpdate.getDebitMemoReasonCode());
                long location = rowToUpdate.getLocation();
                if (location == (Long.MIN_VALUE)) {
                    stmnt.setNull(4, Types.BIGINT);
                } else {
                    stmnt.setLong(4, location);
                }
                stmnt.setString(5, rowToUpdate.getLocType());
                int orderNo = rowToUpdate.getOrderNo();
                if (orderNo == (Integer.MIN_VALUE)) {
                    stmnt.setNull(6, Types.INTEGER);
                } else {
                    stmnt.setInt(6, orderNo);
                }
                stmnt.setLong(7, rowToUpdate.getSupplier());
                stmnt.setTimestamp(8, rowToUpdate.getRoutingDate());
                stmnt.setTimestamp(9, rowToUpdate.getResolveByDate());
                stmnt.setDouble(10, rowToUpdate.getQtyInvoiced());
                stmnt.setString(11, rowToUpdate.getApReviewer());
                stmnt.setString(12, rowToUpdate.getDocType());
                double resolutionQty = rowToUpdate.getResolutionQty();
                if (resolutionQty == (Double.MIN_VALUE)) {
                    stmnt.setNull(13, Types.DOUBLE);
                } else {
                    stmnt.setDouble(13, resolutionQty);
                }
                stmnt.setLong(14, rowToUpdate.getQtyDiscrepancyId());
            } else {
                StringBuffer sqlText = new StringBuffer("UPDATE IM_QTY_DISCREPANCY SET ");
                String comma = "";
                if (rowToUpdate.docIdIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.DOC_ID=?");
                    comma = ",";
                }
                if (rowToUpdate.itemIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.ITEM=?");
                    comma = ",";
                }
                if (rowToUpdate.debitMemoReasonCodeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE=?");
                    comma = ",";
                }
                if (rowToUpdate.locationIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.LOCATION=?");
                    comma = ",";
                }
                if (rowToUpdate.locTypeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.LOC_TYPE=?");
                    comma = ",";
                }
                if (rowToUpdate.orderNoIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.ORDER_NO=?");
                    comma = ",";
                }
                if (rowToUpdate.supplierIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.SUPPLIER=?");
                    comma = ",";
                }
                if (rowToUpdate.routingDateIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.ROUTING_DATE=?");
                    comma = ",";
                }
                if (rowToUpdate.resolveByDateIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.RESOLVE_BY_DATE=?");
                    comma = ",";
                }
                if (rowToUpdate.qtyInvoicedIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.QTY_INVOICED=?");
                    comma = ",";
                }
                if (rowToUpdate.apReviewerIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.AP_REVIEWER=?");
                    comma = ",";
                }
                if (rowToUpdate.docTypeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.DOC_TYPE=?");
                    comma = ",";
                }
                if (rowToUpdate.resolutionQtyIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.RESOLUTION_QTY=?");
                    comma = ",";
                }
                sqlText.append(" WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?");
                tableQuery = sqlText.toString();
                stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                int idx = 1;
                if (rowToUpdate.docIdIsPopulated()) {
                    stmnt.setLong(idx++, rowToUpdate.getDocId());
                }
                if (rowToUpdate.itemIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getItem());
                }
                if (rowToUpdate.debitMemoReasonCodeIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getDebitMemoReasonCode());
                }
                if (rowToUpdate.locationIsPopulated()) {
                    long location = rowToUpdate.getLocation();
                    if (location == (Long.MIN_VALUE)) {
                        stmnt.setNull(idx++, Types.BIGINT);
                    } else {
                        stmnt.setLong(idx++, location);
                    }
                }
                if (rowToUpdate.locTypeIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getLocType());
                }
                if (rowToUpdate.orderNoIsPopulated()) {
                    int orderNo = rowToUpdate.getOrderNo();
                    if (orderNo == (Integer.MIN_VALUE)) {
                        stmnt.setNull(idx++, Types.INTEGER);
                    } else {
                        stmnt.setInt(idx++, orderNo);
                    }
                }
                if (rowToUpdate.supplierIsPopulated()) {
                    stmnt.setLong(idx++, rowToUpdate.getSupplier());
                }
                if (rowToUpdate.routingDateIsPopulated()) {
                    stmnt.setTimestamp(idx++, rowToUpdate.getRoutingDate());
                }
                if (rowToUpdate.resolveByDateIsPopulated()) {
                    stmnt.setTimestamp(idx++, rowToUpdate.getResolveByDate());
                }
                if (rowToUpdate.qtyInvoicedIsPopulated()) {
                    stmnt.setDouble(idx++, rowToUpdate.getQtyInvoiced());
                }
                if (rowToUpdate.apReviewerIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getApReviewer());
                }
                if (rowToUpdate.docTypeIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getDocType());
                }
                if (rowToUpdate.resolutionQtyIsPopulated()) {
                    double resolutionQty = rowToUpdate.getResolutionQty();
                    if (resolutionQty == (Double.MIN_VALUE)) {
                        stmnt.setNull(idx++, Types.DOUBLE);
                    } else {
                        stmnt.setDouble(idx++, resolutionQty);
                    }
                }
                stmnt.setLong(idx++, rowToUpdate.getQtyDiscrepancyId());
            }

            stmnt.executeUpdate();
        } catch (SQLException ex) {
            String exMsg = getBindVariableDebugString(rowToUpdate, false);
            throw new ReIMException("DALGen.cannot_perform_update", Severity.ERROR, ex, this,
                    new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: update. This method updates an array of rows on the database using the primary key of
     * each row.
     * 
     * @param rowsToUpdate
     *            An array of row objects. Each object must have the primary key populated and at
     *            least one other attribute.
     * 
     */
    public void update(ImQtyDiscrepancyRow[] rowsToUpdate) throws ReIMException {
        if (rowsToUpdate.length <= BATCH_UPDATE_ROW_THRESHOLD) {
            int arrayLen = rowsToUpdate.length;
            for (int i = 0; i < arrayLen; i++) {
                this.update(rowsToUpdate[i]);
            }
            return;
        }
        OraclePreparedStatement stmnt = null;
        String tableQuery = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            long location;
            int orderNo;
            double resolutionQty;
            // NOTE : The population status of the first row will be assumed to
            // be exactly the same as the rest
            // NOTE : Mixing different objects with different fields populated
            // is NOT currently supported.
            if (rowsToUpdate[0].isFullyPopulated()) {
                tableQuery = "UPDATE IM_QTY_DISCREPANCY SET IM_QTY_DISCREPANCY.DOC_ID = ?, IM_QTY_DISCREPANCY.ITEM = ?, IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE = ?, IM_QTY_DISCREPANCY.LOCATION = ?, IM_QTY_DISCREPANCY.LOC_TYPE = ?, IM_QTY_DISCREPANCY.ORDER_NO = ?, IM_QTY_DISCREPANCY.SUPPLIER = ?, IM_QTY_DISCREPANCY.ROUTING_DATE = ?, IM_QTY_DISCREPANCY.RESOLVE_BY_DATE = ?, IM_QTY_DISCREPANCY.QTY_INVOICED = ?, IM_QTY_DISCREPANCY.AP_REVIEWER = ?, IM_QTY_DISCREPANCY.DOC_TYPE = ?, IM_QTY_DISCREPANCY.RESOLUTION_QTY = ? WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?";
                stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                int arrayLen = rowsToUpdate.length;
                int nbrLoops = 0;
                boolean arrayGreater = false;
                for (int i = 0; i < arrayLen; i++) {
                    int record = 0;
                    if (arrayGreater) {
                        stmnt.executeBatch();
                        stmnt.close();
                        i = 0;
                        arrayLen -= ARRAY_PROCESS_SIZE;
                        arrayGreater = false;
                        stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                    }
                    if (arrayLen > ARRAY_PROCESS_SIZE) {
                        arrayGreater = true;
                        for (int x = 0; x < ARRAY_PROCESS_SIZE; x++) {
                            record = x + (nbrLoops * ARRAY_PROCESS_SIZE);
                            stmnt.setLong(1, rowsToUpdate[record].getDocId());
                            stmnt.setString(2, rowsToUpdate[record].getItem());
                            stmnt.setString(3, rowsToUpdate[record].getDebitMemoReasonCode());
                            location = rowsToUpdate[record].getLocation();
                            if (location == (Long.MIN_VALUE)) {
                                stmnt.setNull(4, Types.BIGINT);
                            } else {
                                stmnt.setLong(4, location);
                            }
                            stmnt.setString(5, rowsToUpdate[record].getLocType());
                            orderNo = rowsToUpdate[record].getOrderNo();
                            if (orderNo == (Integer.MIN_VALUE)) {
                                stmnt.setNull(6, Types.INTEGER);
                            } else {
                                stmnt.setInt(6, orderNo);
                            }
                            stmnt.setLong(7, rowsToUpdate[record].getSupplier());
                            stmnt.setTimestamp(8, rowsToUpdate[record].getRoutingDate());
                            stmnt.setTimestamp(9, rowsToUpdate[record].getResolveByDate());
                            stmnt.setDouble(10, rowsToUpdate[record].getQtyInvoiced());
                            stmnt.setString(11, rowsToUpdate[record].getApReviewer());
                            stmnt.setString(12, rowsToUpdate[record].getDocType());
                            resolutionQty = rowsToUpdate[record].getResolutionQty();
                            if (resolutionQty == (Double.MIN_VALUE)) {
                                stmnt.setNull(13, Types.DOUBLE);
                            } else {
                                stmnt.setDouble(13, resolutionQty);
                            }
                            stmnt.setLong(14, rowsToUpdate[record].getQtyDiscrepancyId());
                            stmnt.addBatch();
                        }
                        nbrLoops += 1;
                    } else {
                        record = i + (nbrLoops * ARRAY_PROCESS_SIZE);
                        stmnt.setLong(1, rowsToUpdate[record].getDocId());
                        stmnt.setString(2, rowsToUpdate[record].getItem());
                        stmnt.setString(3, rowsToUpdate[record].getDebitMemoReasonCode());
                        location = rowsToUpdate[record].getLocation();
                        if (location == (Long.MIN_VALUE)) {
                            stmnt.setNull(4, Types.BIGINT);
                        } else {
                            stmnt.setLong(4, location);
                        }
                        stmnt.setString(5, rowsToUpdate[record].getLocType());
                        orderNo = rowsToUpdate[record].getOrderNo();
                        if (orderNo == (Integer.MIN_VALUE)) {
                            stmnt.setNull(6, Types.INTEGER);
                        } else {
                            stmnt.setInt(6, orderNo);
                        }
                        stmnt.setLong(7, rowsToUpdate[record].getSupplier());
                        stmnt.setTimestamp(8, rowsToUpdate[record].getRoutingDate());
                        stmnt.setTimestamp(9, rowsToUpdate[record].getResolveByDate());
                        stmnt.setDouble(10, rowsToUpdate[record].getQtyInvoiced());
                        stmnt.setString(11, rowsToUpdate[record].getApReviewer());
                        stmnt.setString(12, rowsToUpdate[record].getDocType());
                        resolutionQty = rowsToUpdate[record].getResolutionQty();
                        if (resolutionQty == (Double.MIN_VALUE)) {
                            stmnt.setNull(13, Types.DOUBLE);
                        } else {
                            stmnt.setDouble(13, resolutionQty);
                        }
                        stmnt.setLong(14, rowsToUpdate[record].getQtyDiscrepancyId());
                        stmnt.addBatch();
                    }
                }
            } else {
                StringBuffer sqlText = new StringBuffer("UPDATE IM_QTY_DISCREPANCY SET ");
                String comma = "";
                if (rowsToUpdate[0].docIdIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.DOC_ID=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].itemIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.ITEM=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].debitMemoReasonCodeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.DEBIT_MEMO_REASON_CODE=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].locationIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.LOCATION=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].locTypeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.LOC_TYPE=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].orderNoIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.ORDER_NO=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].supplierIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.SUPPLIER=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].routingDateIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.ROUTING_DATE=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].resolveByDateIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.RESOLVE_BY_DATE=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].qtyInvoicedIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.QTY_INVOICED=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].apReviewerIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.AP_REVIEWER=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].docTypeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.DOC_TYPE=?");
                    comma = ",";
                }
                if (rowsToUpdate[0].resolutionQtyIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_QTY_DISCREPANCY.RESOLUTION_QTY=?");
                    comma = ",";
                }
                sqlText.append(" WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?");
                tableQuery = sqlText.toString();
                stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                int arrayLen = rowsToUpdate.length;
                int idx;
                int nbrLoops = 0;
                boolean arrayGreater = false;
                for (int i = 0; i < arrayLen; i++) {
                    int record = 0;
                    if (arrayGreater) {
                        stmnt.executeBatch();
                        stmnt.close();
                        i = 0;
                        arrayLen -= ARRAY_PROCESS_SIZE;
                        arrayGreater = false;
                        stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                    }
                    if (arrayLen > ARRAY_PROCESS_SIZE) {
                        arrayGreater = true;
                        for (int x = 0; x < ARRAY_PROCESS_SIZE; x++) {
                            idx = 1;
                            record = x + (nbrLoops * ARRAY_PROCESS_SIZE);
                            if (rowsToUpdate[record].docIdIsPopulated()) {
                                stmnt.setLong(idx++, rowsToUpdate[record].getDocId());
                            }
                            if (rowsToUpdate[record].itemIsPopulated()) {
                                stmnt.setString(idx++, rowsToUpdate[record].getItem());
                            }
                            if (rowsToUpdate[record].debitMemoReasonCodeIsPopulated()) {
                                stmnt.setString(idx++, rowsToUpdate[record]
                                        .getDebitMemoReasonCode());
                            }
                            if (rowsToUpdate[record].locationIsPopulated()) {
                                location = rowsToUpdate[record].getLocation();
                                if (location == (Long.MIN_VALUE)) {
                                    stmnt.setNull(idx++, Types.BIGINT);
                                } else {
                                    stmnt.setLong(idx++, location);
                                }
                            }
                            if (rowsToUpdate[record].locTypeIsPopulated()) {
                                stmnt.setString(idx++, rowsToUpdate[record].getLocType());
                            }
                            if (rowsToUpdate[record].orderNoIsPopulated()) {
                                orderNo = rowsToUpdate[record].getOrderNo();
                                if (orderNo == (Integer.MIN_VALUE)) {
                                    stmnt.setNull(idx++, Types.INTEGER);
                                } else {
                                    stmnt.setInt(idx++, orderNo);
                                }
                            }
                            if (rowsToUpdate[record].supplierIsPopulated()) {
                                stmnt.setLong(idx++, rowsToUpdate[record].getSupplier());
                            }
                            if (rowsToUpdate[record].routingDateIsPopulated()) {
                                stmnt.setTimestamp(idx++, rowsToUpdate[record].getRoutingDate());
                            }
                            if (rowsToUpdate[record].resolveByDateIsPopulated()) {
                                stmnt.setTimestamp(idx++, rowsToUpdate[record].getResolveByDate());
                            }
                            if (rowsToUpdate[record].qtyInvoicedIsPopulated()) {
                                stmnt.setDouble(idx++, rowsToUpdate[record].getQtyInvoiced());
                            }
                            if (rowsToUpdate[record].apReviewerIsPopulated()) {
                                stmnt.setString(idx++, rowsToUpdate[record].getApReviewer());
                            }
                            if (rowsToUpdate[record].docTypeIsPopulated()) {
                                stmnt.setString(idx++, rowsToUpdate[record].getDocType());
                            }
                            if (rowsToUpdate[record].resolutionQtyIsPopulated()) {
                                resolutionQty = rowsToUpdate[record].getResolutionQty();
                                if (resolutionQty == (Double.MIN_VALUE)) {
                                    stmnt.setNull(idx++, Types.DOUBLE);
                                } else {
                                    stmnt.setDouble(idx++, resolutionQty);
                                }
                            }
                            stmnt.setLong(idx++, rowsToUpdate[record].getQtyDiscrepancyId());
                            stmnt.addBatch();
                        }
                        nbrLoops += 1;
                    } else {
                        idx = 1;
                        record = i + (nbrLoops * ARRAY_PROCESS_SIZE);
                        if (rowsToUpdate[record].docIdIsPopulated()) {
                            stmnt.setLong(idx++, rowsToUpdate[record].getDocId());
                        }
                        if (rowsToUpdate[record].itemIsPopulated()) {
                            stmnt.setString(idx++, rowsToUpdate[record].getItem());
                        }
                        if (rowsToUpdate[record].debitMemoReasonCodeIsPopulated()) {
                            stmnt.setString(idx++, rowsToUpdate[record].getDebitMemoReasonCode());
                        }
                        if (rowsToUpdate[record].locationIsPopulated()) {
                            location = rowsToUpdate[record].getLocation();
                            if (location == (Long.MIN_VALUE)) {
                                stmnt.setNull(idx++, Types.BIGINT);
                            } else {
                                stmnt.setLong(idx++, location);
                            }
                        }
                        if (rowsToUpdate[record].locTypeIsPopulated()) {
                            stmnt.setString(idx++, rowsToUpdate[record].getLocType());
                        }
                        if (rowsToUpdate[record].orderNoIsPopulated()) {
                            orderNo = rowsToUpdate[record].getOrderNo();
                            if (orderNo == (Integer.MIN_VALUE)) {
                                stmnt.setNull(idx++, Types.INTEGER);
                            } else {
                                stmnt.setInt(idx++, orderNo);
                            }
                        }
                        if (rowsToUpdate[record].supplierIsPopulated()) {
                            stmnt.setLong(idx++, rowsToUpdate[record].getSupplier());
                        }
                        if (rowsToUpdate[record].routingDateIsPopulated()) {
                            stmnt.setTimestamp(idx++, rowsToUpdate[record].getRoutingDate());
                        }
                        if (rowsToUpdate[record].resolveByDateIsPopulated()) {
                            stmnt.setTimestamp(idx++, rowsToUpdate[record].getResolveByDate());
                        }
                        if (rowsToUpdate[record].qtyInvoicedIsPopulated()) {
                            stmnt.setDouble(idx++, rowsToUpdate[record].getQtyInvoiced());
                        }
                        if (rowsToUpdate[record].apReviewerIsPopulated()) {
                            stmnt.setString(idx++, rowsToUpdate[record].getApReviewer());
                        }
                        if (rowsToUpdate[record].docTypeIsPopulated()) {
                            stmnt.setString(idx++, rowsToUpdate[record].getDocType());
                        }
                        if (rowsToUpdate[record].resolutionQtyIsPopulated()) {
                            resolutionQty = rowsToUpdate[record].getResolutionQty();
                            if (resolutionQty == (Double.MIN_VALUE)) {
                                stmnt.setNull(idx++, Types.DOUBLE);
                            } else {
                                stmnt.setDouble(idx++, resolutionQty);
                            }
                        }
                        stmnt.setLong(idx++, rowsToUpdate[record].getQtyDiscrepancyId());
                        stmnt.addBatch();
                    }
                }
            }
            stmnt.executeBatch();
        } catch (BatchUpdateException ex1) {
            int failedRowIndex = ex1.getUpdateCounts().length; // as per JDBC
            // 2.0 API
            // standard
            String exMsg = "(unable to determine which batch row caused the error)";
            if (failedRowIndex < rowsToUpdate.length) {
                exMsg = getBindVariableDebugString(rowsToUpdate[failedRowIndex], false);
            }
            throw new ReIMException("DALGen.cannot_perform_update", Severity.ERROR, ex1, this,
                    new String[] { tableQuery, exMsg});
        } catch (SQLException ex) {
            String exMsg = "(unable to determine which batch row caused the error)";
            throw new ReIMException("DALGen.cannot_perform_update", Severity.ERROR, ex, this,
                    new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    public long getNextQtyDiscrepancyId() throws ReIMException {
        Connection conn = TransactionManagerFactory.getInstance().getConnection();
        SQLSequence seq = new SQLSequence();
        return seq.getNextValue("IM_QTY_DISCREPANCY_SEQ", conn);
    }

    /**
     * Method: delete. This method deletes a single row from the database using the primary key.
     * 
     * @param qtyDiscrepancyId
     * 
     */
    public void delete(long qtyDiscrepancyId) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String tableQuery = "DELETE FROM IM_QTY_DISCREPANCY WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
            stmnt.setLong(1, qtyDiscrepancyId);
            stmnt.execute();
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variable 1 type=long, value=" + qtyDiscrepancyId + ";";
            throw new ReIMException("DALGen.cannot_perform_delete", Severity.ERROR, ex, this,
                    new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * Method: delete. This method deletes a single row from the database using the primary key.
     * 
     * @param rowToDelete
     *            Note that the primary key must be populated.
     * 
     */
    public void delete(ImQtyDiscrepancyRow rowToDelete) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String tableQuery = "DELETE FROM IM_QTY_DISCREPANCY WHERE IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID = ?";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
            stmnt.setLong(1, rowToDelete.getQtyDiscrepancyId());
            stmnt.execute();
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variable 1 type=long, value="
                    + rowToDelete.getQtyDiscrepancyId() + ";";
            throw new ReIMException("DALGen.cannot_perform_delete", Severity.ERROR, ex, this,
                    new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    protected void setColumnDOC_ID(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setDocId(rs.getLong(idx.intValue()));
    }

    protected void setColumnITEM(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setItem(rs.getString(idx.intValue()));
    }

    protected void setColumnDEBIT_MEMO_REASON_CODE(ImQtyDiscrepancyRow obj, ResultSet rs,
            Integer idx) throws SQLException {
        obj.setDebitMemoReasonCode(rs.getString(idx.intValue()));
    }

    protected void setColumnLOCATION(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        long location = rs.getLong(idx.intValue());
        if (rs.wasNull()) {
            location = Long.MIN_VALUE;
        } else {
            obj.setLocation(location);
        }
    }

    protected void setColumnLOC_TYPE(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setLocType(rs.getString(idx.intValue()));
    }

    protected void setColumnORDER_NO(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        int orderNo = rs.getInt(idx.intValue());
        if (rs.wasNull()) {
            orderNo = Integer.MIN_VALUE;
        } else {
            obj.setOrderNo(orderNo);
        }
    }

    protected void setColumnSUPPLIER(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setSupplier(rs.getLong(idx.intValue()));
    }

    protected void setColumnROUTING_DATE(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setRoutingDate(rs.getTimestamp(idx.intValue()));
    }

    protected void setColumnRESOLVE_BY_DATE(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setResolveByDate(rs.getTimestamp(idx.intValue()));
    }

    protected void setColumnQTY_INVOICED(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setQtyInvoiced(rs.getDouble(idx.intValue()));
    }

    protected void setColumnAP_REVIEWER(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setApReviewer(rs.getString(idx.intValue()));
    }

    protected void setColumnDOC_TYPE(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        obj.setDocType(rs.getString(idx.intValue()));
    }

    protected void setColumnRESOLUTION_QTY(ImQtyDiscrepancyRow obj, ResultSet rs, Integer idx)
            throws SQLException {
        double resolutionQty = rs.getDouble(idx.intValue());
        if (rs.wasNull()) {
            resolutionQty = Double.MIN_VALUE;
        } else {
            obj.setResolutionQty(resolutionQty);
        }
    }

    /**
     * Method: read. This method is the same as the normal multiple row read except that you do not
     * have to load all columns from the database. This may be useful when there is a vary large
     * number of columns on the database and performance is affected.
     * 
     * @see #read(String whereClause, String additionalTables, String sqlHint, String orderBy)
     * 
     */
    public ImQtyDiscrepancyRow[] read(String columns[], String whereClause,
            String additionalTables, String sqlHint, String orderBy) throws ReIMException {
        Statement stmnt = null;
        ResultSet rs1 = null;
        String sqlTxt = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            StringBuffer sqlText = new StringBuffer("SELECT ");
            if (sqlHint != null) {
                sqlText.append(sqlHint);
                sqlText.append(" ");
            }
            sqlText.append("IM_QTY_DISCREPANCY.QTY_DISCREPANCY_ID");
            // This is to handle table without PK
            sqlText.append(",");
            sqlText.append(columns[0]);
            for (int i = 1; i < columns.length; i++) {
                sqlText.append(", ");
                sqlText.append(columns[i]);
            }
            sqlText.append(" FROM IM_QTY_DISCREPANCY ");
            if (additionalTables != null) {
                sqlText.append(",");
                sqlText.append(additionalTables);
            }
            if (whereClause != null) {
                sqlText.append(" WHERE ");
                sqlText.append(whereClause);
            }
            if (orderBy != null) {
                sqlText.append(" ORDER BY ");
                sqlText.append(orderBy);
            }
            sqlTxt = sqlText.toString();
            stmnt = conn.createStatement();
            rs1 = stmnt.executeQuery(sqlTxt);
            Vector businessObjectsVector = new Vector();
            ImQtyDiscrepancyRow businessObjectArray[] = null;
            while (rs1.next()) {
                ImQtyDiscrepancyRow rowObj = new ImQtyDiscrepancyRow(rs1.getLong(1));
                for (int i = 0; i < columns.length; i++) {
                    Method m = (Method) reflectionPerformanceMap.get(columns[i]);
                    m.invoke(this, new Object[] { rowObj, rs1, new Integer(i + 1 + 1)});
                }
                businessObjectsVector.addElement(rowObj);
            }
            if (businessObjectsVector.size() > 0) {
                businessObjectArray = new ImQtyDiscrepancyRow[businessObjectsVector.size()];
                businessObjectsVector.copyInto(businessObjectArray);
                return businessObjectArray;
            } else {
                return null;
            }
        } catch (Exception ex) {
            throw new ReIMException("DALGen.cannot_perform_bulk_select", Severity.ERROR, ex,
                    this, new String[] { sqlTxt, new String(" (no bind variables) ")});
        } finally {
            try {
                if (rs1 != null) {
                    rs1.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    static Hashtable reflectionPerformanceMap;

    static {
        reflectionPerformanceMap = new Hashtable();
        Method[] methods = ImQtyDiscrepancyAccess.class.getDeclaredMethods();
        for (int i = 0; i < methods.length; i++) {
            Method m = methods[i];
            String methodName = m.getName();
            if (methodName.startsWith("setColumn")) {
                m.setAccessible(true);
                reflectionPerformanceMap.put(methodName.substring(9), m);
            }
        }
    }

    private String getBindVariableDebugString(ImQtyDiscrepancyRow row, boolean insertMode)
            throws ReIMException {
        StringBuffer debugText = new StringBuffer();
        int idx = 1;
        if (insertMode) {
            debugText.append("Bind variable " + idx + " type=long, value="
                    + row.getQtyDiscrepancyId() + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=long, value=" + row.getDocId() + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=String, value=" + row.getItem() + ";");
            idx++;
            if (row.isDebitMemoReasonCodeNull()) {
                debugText.append("Bind variable " + idx + " type=String, value=NULL;");
            } else {
                debugText.append("Bind variable " + idx + " type=String, value="
                        + row.getDebitMemoReasonCode() + ";");
            }
            idx++;
            if (row.isLocationNull()) {
                debugText.append("Bind variable " + idx + " type=long, value=NULL;");
            } else {
                debugText.append("Bind variable " + idx + " type=long, value=" + row.getLocation()
                        + ";");
            }
            idx++;
            if (row.isLocTypeNull()) {
                debugText.append("Bind variable " + idx + " type=String, value=NULL;");
            } else {
                debugText.append("Bind variable " + idx + " type=String, value=" + row.getLocType()
                        + ";");
            }
            idx++;
            if (row.isOrderNoNull()) {
                debugText.append("Bind variable " + idx + " type=int, value=NULL;");
            } else {
                debugText.append("Bind variable " + idx + " type=int, value=" + row.getOrderNo()
                        + ";");
            }
            idx++;
            debugText.append("Bind variable " + idx + " type=long, value=" + row.getSupplier()
                    + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=Timestamp, value="
                    + row.getRoutingDate() + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=Timestamp, value="
                    + row.getResolveByDate() + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=double, value=" + row.getQtyInvoiced()
                    + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=String, value=" + row.getApReviewer()
                    + ";");
            idx++;
            debugText.append("Bind variable " + idx + " type=String, value=" + row.getDocType()
                    + ";");
            idx++;
            if (row.isResolutionQtyNull()) {
                debugText.append("Bind variable " + idx + " type=double, value=NULL;");
            } else {
                debugText.append("Bind variable " + idx + " type=double, value="
                        + row.getResolutionQty() + ";");
            }
            idx++;
        } else {
            if (row.docIdIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=long, value=" + row.getDocId()
                        + ";");
                idx++;
            }
            if (row.itemIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=String, value=" + row.getItem()
                        + ";");
                idx++;
            }
            if (row.debitMemoReasonCodeIsPopulated()) {
                if (row.isDebitMemoReasonCodeNull()) {
                    debugText.append("Bind variable " + idx + " type=String, value=NULL;");
                } else {
                    debugText.append("Bind variable " + idx + " type=String, value="
                            + row.getDebitMemoReasonCode() + ";");
                }
                idx++;
            }
            if (row.locationIsPopulated()) {
                if (row.isLocationNull()) {
                    debugText.append("Bind variable " + idx + " type=long, value=NULL;");
                } else {
                    debugText.append("Bind variable " + idx + " type=long, value="
                            + row.getLocation() + ";");
                }
                idx++;
            }
            if (row.locTypeIsPopulated()) {
                if (row.isLocTypeNull()) {
                    debugText.append("Bind variable " + idx + " type=String, value=NULL;");
                } else {
                    debugText.append("Bind variable " + idx + " type=String, value="
                            + row.getLocType() + ";");
                }
                idx++;
            }
            if (row.orderNoIsPopulated()) {
                if (row.isOrderNoNull()) {
                    debugText.append("Bind variable " + idx + " type=int, value=NULL;");
                } else {
                    debugText.append("Bind variable " + idx + " type=int, value="
                            + row.getOrderNo() + ";");
                }
                idx++;
            }
            if (row.supplierIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=long, value=" + row.getSupplier()
                        + ";");
                idx++;
            }
            if (row.routingDateIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=Timestamp, value="
                        + row.getRoutingDate() + ";");
                idx++;
            }
            if (row.resolveByDateIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=Timestamp, value="
                        + row.getResolveByDate() + ";");
                idx++;
            }
            if (row.qtyInvoicedIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=double, value="
                        + row.getQtyInvoiced() + ";");
                idx++;
            }
            if (row.apReviewerIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=String, value="
                        + row.getApReviewer() + ";");
                idx++;
            }
            if (row.docTypeIsPopulated()) {
                debugText.append("Bind variable " + idx + " type=String, value=" + row.getDocType()
                        + ";");
                idx++;
            }
            if (row.resolutionQtyIsPopulated()) {
                if (row.isResolutionQtyNull()) {
                    debugText.append("Bind variable " + idx + " type=double, value=NULL;");
                } else {
                    debugText.append("Bind variable " + idx + " type=double, value="
                            + row.getResolutionQty() + ";");
                }
                idx++;
            }
            debugText.append("Bind variable " + idx + " type=long, value="
                    + row.getQtyDiscrepancyId() + ";");
            idx++;
        }
        return debugText.toString();
    }

}
