package com.retek.reim.ui.invoiceMatch;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.services.matching.IDetailMatchService;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.business.ReceiptItem;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.services.ReceiptService;

public class DetailMatchSplitReceiptAction extends ReIMSecureAction {

    private IDetailMatchService detailMatchService;

    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        DetailMatchListForm detailMatchListForm = (DetailMatchListForm) form;
        try {
            DetailMatchItemsView[] discrepancyItemsList = detailMatchListForm
                    .getDiscrepancyItemsList();
            String selectedDetailMatchReceiptViewHashCode = detailMatchListForm
                    .getSelectedReceipts();
            DetailMatchReceiptView[] receiptItemGroupList = detailMatchListForm
                    .getReceiptItemGroupList();
            ReceiptItem receiptItemToMoveUp = new ReceiptItem();

            double remainingQty = 0;
            // Find the selected receipt
            if (selectedDetailMatchReceiptViewHashCode != null) {
                for (int j = 0; j < receiptItemGroupList.length; j++) {
                    if (selectedDetailMatchReceiptViewHashCode.equals(Integer
                            .toString(receiptItemGroupList[j].hashCode()))) {
                        remainingQty = new Double(detailMatchListForm
                                .getSplitReceiptQtyToSplitOff()).doubleValue();
                        
                        double qtyForMatch = receiptItemGroupList[j].getReceiptItem()
                                .getAvailableToMatchQty()
                                - remainingQty;
                        
                        receiptItemGroupList[j].getReceiptItem().setCostMatched(
                                ReceiptService.isCostMatched(receiptItemGroupList[j]
                                        .getReceiptItem().getItemId(), receiptItemGroupList[j]
                                        .getReceiptItem().getReceiptId()));                                                
                        receiptItemGroupList[j].getReceiptItem()
                        		.setAvailableToMatchQty(qtyForMatch);
                        
                        //BRN-Split Receipt Fix to store IM_RESOLUTION_ACTION in case of split receipt detail match
                        receiptItemGroupList[j].getReceiptItem()
                				.setQtyMatched(receiptItemGroupList[j].getReceiptItem().getQtyReceived() - qtyForMatch);
                        
                        receiptItemToMoveUp = (ReceiptItem) receiptItemGroupList[j]
                                .getReceiptItem().clone();
                        receiptItemToMoveUp.setAvailableToMatchQty(remainingQty);
                        ReceiptItem[] receiptItems = { receiptItemToMoveUp};
                        Map discrepancyItems = getDetailMatchService().rebuildDetailViews(
                                discrepancyItemsList, null, receiptItems,
                                detailMatchListForm.getCurrencyCode(), detailMatchListForm);
                        DetailMatchItemsView[] discrepancyItemsArray = (DetailMatchItemsView[]) discrepancyItems
                                .values()
                                .toArray(new DetailMatchItemsView[discrepancyItems.size()]);
                        detailMatchListForm.setDiscrepancyItemsList(discrepancyItemsArray);
                        detailMatchListForm.resetVariances();
                    }
                }
            }

            // Remove the receipt items with 0 available to match quantity.
            ArrayList tempList = new ArrayList();
            for (int ii = 0; ii < receiptItemGroupList.length; ii++) {
                double availableToMatchQty = receiptItemGroupList[ii].getReceiptItem()
                        .getAvailableToMatchQty();
                if (availableToMatchQty > 0) {
                    tempList.add(receiptItemGroupList[ii]);
                }
            }
            receiptItemGroupList = (DetailMatchReceiptView[]) tempList
                    .toArray(new DetailMatchReceiptView[tempList.size()]);
            detailMatchListForm.setReceiptItemGroupList(receiptItemGroupList);

            if (receiptItemToMoveUp == null) {
                ReIMException newEx = new ReIMException(
                        "error.detail_match_split_receipt_action.do_perform", Severity.DEBUG,
                        new Exception(ReIMConstants.EMPTY_STRING), this);
                saveErrors(request, errors, newEx);
                return mapping.findForward("failure");
            }
            return mapping.findForward("success");
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return (mapping.findForward("failure"));
        } catch (Exception e) {
            ReIMException newEx = new ReIMException(
                    "error.detail_match_split_receipt_action.do_perform", Severity.ERROR, e, this);
            saveErrors(request, errors, newEx);
            return mapping.findForward("failure");
        }
    }

    public IDetailMatchService getDetailMatchService() {
        return detailMatchService;
    }

    public void setDetailMatchService(IDetailMatchService detailMatchService) {
        this.detailMatchService = detailMatchService;
    }
}
