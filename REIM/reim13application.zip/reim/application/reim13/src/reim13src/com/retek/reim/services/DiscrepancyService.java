package com.retek.reim.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import oracle.retail.reim.business.MerchandiseInvoiceQuantityDiscrepancy;
import oracle.retail.reim.business.document.DiscrepancyDocReference;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.DiscrepancyCostReviewDetail;
import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.UserRole;
import com.retek.reim.business.UserRoleClass;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.ImCostDiscrepancyAccess;
import com.retek.reim.db.ImCostDiscrepancyAccessExt;
import com.retek.reim.db.ImCostDiscrepancyCNRAccessExt;
import com.retek.reim.db.ImCostDiscrepancyHistAccess;
import com.retek.reim.db.ImCostDiscrepancyHistRow;
import com.retek.reim.db.ImCostDiscrepancyRow;
import com.retek.reim.db.ImDocHeadAccess;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.db.ImInvoiceDetailAccessExt;
import com.retek.reim.db.ImQtyDiscrepancyAccess;
import com.retek.reim.db.ImQtyDiscrepancyAccessExt;
import com.retek.reim.db.ImQtyDiscrepancyHistAccess;
import com.retek.reim.db.ImQtyDiscrepancyHistRow;
import com.retek.reim.db.ImQtyDiscrepancyReceiptAccess;
import com.retek.reim.db.ImQtyDiscrepancyReceiptAccessExt;
import com.retek.reim.db.ImQtyDiscrepancyReceiptHisAccess;
import com.retek.reim.db.ImQtyDiscrepancyReceiptHisRow;
import com.retek.reim.db.ImQtyDiscrepancyReceiptRow;
import com.retek.reim.db.ImQtyDiscrepancyRoleAccess;
import com.retek.reim.db.ImQtyDiscrepancyRoleAccessExt;
import com.retek.reim.db.ImQtyDiscrepancyRoleHistAccess;
import com.retek.reim.db.ImQtyDiscrepancyRoleHistRow;
import com.retek.reim.db.ImQtyDiscrepancyRoleRow;
import com.retek.reim.db.ImQtyDiscrepancyRow;
import com.retek.reim.db.ImResolutionActionAccessExt;
import com.retek.reim.foundation.AItemBean;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.ui.discrepancyResolution.PriceReviewDetail;

public class DiscrepancyService implements IDiscrepancyService {
    public ReIMDate calculateDiscrepancyResolveByDate(ReIMDate docDueDate,
            ReIMSystemOptions systemOptions, ReIMDate vDate, String discrepancyType)
            throws ReIMException {
        int resolutionDays = 0;
        if (discrepancyType.equals(ReIMConstants.DISCREPANCY_TYPE_COST_ABBR)) {
            resolutionDays = systemOptions.getCostResolutionDueDays();
        } else if (discrepancyType.equals(ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR)) {
            resolutionDays = systemOptions.getQtyResolutionDueDays();
        } else if (discrepancyType.equals(ReIMConstants.DISCREPANCY_TYPE_TAX_ABBR)) {
            resolutionDays = systemOptions.getTaxResolutionDueDays();
        }

        ReIMDate resolveDate = new ReIMDate(vDate);
        // need to create a new object to avoid advancing vdate
        resolveDate.addDays(resolutionDays);

        // resolveDate must be less than the dueDate
        if (!resolveDate.beforeDate(docDueDate)) {
            // A new ReIMDate is needed to avoid modifying the true doc due
            // date.
            ReIMDate dayBeforeDueDate = new ReIMDate(docDueDate);
            dayBeforeDueDate.addDays(-1);
            resolveDate = dayBeforeDueDate;
        }

        return resolveDate;
    }

    public void migrateCostDiscrepancyToHistory(Resolution resolution) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImCostDiscrepancyAccessExt access = new ImCostDiscrepancyAccessExt();
            ImCostDiscrepancyRow row = access.readDiscrepancyByDocumentItem(resolution.getDocId(),
                    resolution.getDiscrepancyItemId());

            if (row == null) { // i.e. this is not a cost discrepancy...
                return;
            }

            // Since DOC_ID and ITEM are unique on the table, only 1 row is
            // returned
            ImCostDiscrepancyHistRow historyRow = new ImCostDiscrepancyHistRow(row
                    .getCostDiscrepancyId());
            populateCostDiscrepancyRowHistory(historyRow, row);

            ImCostDiscrepancyHistAccess historyAccess = new ImCostDiscrepancyHistAccess();
            historyAccess.create(historyRow);

            // delete resolved discrepancy

            // first delete child in im_cost_discrepancy_cnr table.
            ImCostDiscrepancyCNRAccessExt CNRAccess = new ImCostDiscrepancyCNRAccessExt();
            CNRAccess.deleteByDiscrepancy(row.getCostDiscrepancyId());

            access.delete(row);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(
                    "error.discrepancy_service.migrate_resolved_cost_discrepancy_to_history",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void migrateCostDiscrepancyToHistory(long discrepancyId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ImCostDiscrepancyAccess access = new ImCostDiscrepancyAccess();
            ImCostDiscrepancyRow row = access.read(discrepancyId, true);

            if (row == null) { // i.e. this is not a cost discrepancy...
                return;
            }

            // Since DOC_ID and ITEM are unique on the table, only 1 row is
            // returned
            ImCostDiscrepancyHistRow historyRow = new ImCostDiscrepancyHistRow(discrepancyId);
            populateCostDiscrepancyRowHistory(historyRow, row);

            ImCostDiscrepancyHistAccess historyAccess = new ImCostDiscrepancyHistAccess();
            historyAccess.create(historyRow);

            // delete resolved discrepancy
            access.delete(row);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(
                    "error.discrepancy_service.migrate_resolved_cost_discrepancy_to_history",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void migrateQuantityDiscrepancyToHistory(long qtyDiscId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            MerchandiseInvoiceQuantityDiscrepancy quantityDiscrepancy = new MerchandiseInvoiceQuantityDiscrepancy();
            populateQuantityDiscrepancy(quantityDiscrepancy, qtyDiscId);

            persistQuantityDiscrepancyHistory(quantityDiscrepancy);
            persistQuantityDiscrepancyReceiptHistory(quantityDiscrepancy.getSupportingDocRefs());
            persistQuantityDiscrepancyRoleHistory(qtyDiscId, quantityDiscrepancy.getUserRoles());

            deleteQuantityDiscrepancy(qtyDiscId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(
                    "error.discrepancy_service.migrate_resolved_quantity_discrepancy_to_history",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private static void populateCostDiscrepancyRowHistory(ImCostDiscrepancyHistRow historyRow,
            ImCostDiscrepancyRow row) throws Exception {
        historyRow.setDocId(row.getDocId());
        historyRow.setDocType(row.getDocType());
        historyRow.setItem(row.getItem());
        historyRow.setDebitMemoReasonCode(row.getDebitMemoReasonCode());
        historyRow.setLocation(row.getLocation());
        historyRow.setLocType(row.getLocType());
        historyRow.setOrderNo(row.getOrderNo());
        historyRow.setSupplier(row.getSupplier());
        historyRow.setCurrencyCode(row.getCurrencyCode());
        historyRow.setRoutingDate(row.getRoutingDate());
        historyRow.setResolveByDate(row.getResolveByDate());
        historyRow.setDocUnitCost(row.getDocUnitCost());
        historyRow.setDocTotalCost(row.getDocTotalCost());
        historyRow.setDept(row.getDept());
        historyRow.set_class(row.get_class());
        historyRow.setBusinessRoleId(row.getBusinessRoleId());
        historyRow.setCashDscntInd(row.getCashDscntInd());
        historyRow.setApReviewer(row.getApReviewer());
        historyRow.setResolutionDate(ServiceFactory.getPeriodService().getScreenVDate()
                .getTimestamp());
    }

    private static void populateQuantityDiscrepancy(
            MerchandiseInvoiceQuantityDiscrepancy quantityDiscrepancy, long id) throws Exception {
        ImQtyDiscrepancyReceiptAccessExt rcptAccess = new ImQtyDiscrepancyReceiptAccessExt();
        ImQtyDiscrepancyRoleAccessExt roleAccess = new ImQtyDiscrepancyRoleAccessExt();
        ImQtyDiscrepancyAccess access = new ImQtyDiscrepancyAccess();

        mapRowToQuantityDiscrepancy(access.read(id, true), quantityDiscrepancy);

        quantityDiscrepancy.setSupportingDocsRefs(rcptAccess.readByDiscrepancyId(id));

        String whereClause = ImQtyDiscrepancyRoleAccess.qtyDiscrepancyIdColumn
                + ReIMConstants.EQUALS + id;
        quantityDiscrepancy.setUserRoles(getUserRoles(roleAccess
                .read(whereClause, null, null, null)));
    }

    private static List<UserRole> getUserRoles(ImQtyDiscrepancyRoleRow[] rows) {
        List<UserRole> userRoles = new ArrayList<UserRole>();
        for (ImQtyDiscrepancyRoleRow row : rows) {
            userRoles.add(new UserRole(row.getBusinessRoleId()));
        }
        return userRoles;
    }

    private static void mapRowToQuantityDiscrepancy(ImQtyDiscrepancyRow row,
            MerchandiseInvoiceQuantityDiscrepancy quantityDiscrepancy) throws Exception {
        quantityDiscrepancy.setDiscrepancyId(row.getQtyDiscrepancyId());
        quantityDiscrepancy.setDiscrepantDocId(row.getDocId());
        quantityDiscrepancy.setItemId(row.getItem());
        ReasonCode reasonCode = null;
        String reasonCodeId = row.getDebitMemoReasonCode();
        if (!StringUtils.isEmpty(row.getDebitMemoReasonCode())) {
            reasonCode = new ReasonCode();
            String reasonAction = ServiceFactory.getReasonCodesService().getReasonCodeAction(reasonCodeId);
            if(reasonAction != null){
                reasonCode.setReasonCodeId(reasonCodeId);
                reasonCode.setReasonAction(reasonAction);
                quantityDiscrepancy.setDebitMemoReasonCode(reasonCode);
            } else {
                throw new ReIMException("error.cannot_get_reason_codes", Severity.ERROR,
                		DiscrepancyService.class);
            }
        } 
        quantityDiscrepancy.setDebitMemoReasonCode(reasonCode);
        Location location = null;
        if (row.getLocType() != null) {
            location = new Location("" + row.getLocation(), null, row.getLocType());
        }
        quantityDiscrepancy.setLocation(location);
        quantityDiscrepancy.setOrderNo(row.getOrderNo());
        quantityDiscrepancy.setSupplierId(row.getSupplier());
        quantityDiscrepancy.setRoutingDate(new ReIMDate(row.getRoutingDate()));
        quantityDiscrepancy.setResolveByDate(new ReIMDate(row.getResolveByDate()));
        quantityDiscrepancy.setDiscrepantDocQty(row.getQtyInvoiced());
        quantityDiscrepancy.setApReviewer(row.getApReviewer());
    }

    private static void persistQuantityDiscrepancyHistory(
            MerchandiseInvoiceQuantityDiscrepancy quantityDiscrepancy) throws ReIMException {
        ImQtyDiscrepancyHistRow historyRow = new ImQtyDiscrepancyHistRow(quantityDiscrepancy
                .getDiscrepancyId());
        historyRow.setDocId(quantityDiscrepancy.getDiscrepantDocId());
        historyRow.setItem(quantityDiscrepancy.getItemId());
        if (quantityDiscrepancy.getDebitMemoReasonCode()!=null){
        	historyRow.setDebitMemoReasonCode(quantityDiscrepancy.getDebitMemoReasonCode()
        			.getReasonCodeId());
        }
        else{
        	historyRow.setDebitMemoReasonCodeToNull();
        }
        if (quantityDiscrepancy.getLocation() != null) {
            historyRow.setLocation(Long
                    .parseLong(quantityDiscrepancy.getLocation().getLocationId()));
            historyRow.setLocType(quantityDiscrepancy.getLocation().getLocationType());
        } else {
            historyRow.setLocationToNull();
            historyRow.setLocTypeToNull();
        }
        historyRow.setOrderNo(quantityDiscrepancy.getOrderNo());
        historyRow.setSupplier(quantityDiscrepancy.getSupplierId());
        historyRow.setRoutingDate(quantityDiscrepancy.getRoutingDate().getTimestamp());
        historyRow.setResolveByDate(quantityDiscrepancy.getResolveByDate().getTimestamp());
        historyRow.setQtyInvoiced(quantityDiscrepancy.getDiscrepantDocQty());
        historyRow.setApReviewer(quantityDiscrepancy.getApReviewer());
        historyRow.setResolutionDate(ServiceFactory.getPeriodService().getScreenVDate()
                .getTimestamp());

        ImQtyDiscrepancyHistAccess historyAccess = new ImQtyDiscrepancyHistAccess();
        historyAccess.create(historyRow);
    }

    private static void persistQuantityDiscrepancyReceiptHistory(
            List<DiscrepancyDocReference> supportingDocsRefs) throws ReIMException {

        ImQtyDiscrepancyReceiptHisAccess historyAccess = new ImQtyDiscrepancyReceiptHisAccess();
        for (DiscrepancyDocReference supportingDocsRef : supportingDocsRefs) {
            ImQtyDiscrepancyReceiptHisRow historyRow = new ImQtyDiscrepancyReceiptHisRow(
                    supportingDocsRef.getDiscrepancyId(), supportingDocsRef.getDocReference()
                            .toLong());
            historyAccess.create(historyRow);
        }
    }

    private static void persistQuantityDiscrepancyRoleHistory(long discrepancyId,
            List<UserRole> userRoles) throws ReIMException {
        ImQtyDiscrepancyRoleHistRow historyRow = null;
        ImQtyDiscrepancyRoleHistAccess historyAccess = new ImQtyDiscrepancyRoleHistAccess();

        if (userRoles != null) {
            for (UserRole userRole : userRoles) {
                historyRow = new ImQtyDiscrepancyRoleHistRow(discrepancyId, userRole
                        .getBusinessRoleId(), ServiceFactory.getPeriodService().getScreenVDate()
                        .getTimestamp());
                historyAccess.create(historyRow);
            }
        }
    }

    public void deleteQuantityDiscrepancy(long id) throws ReIMException {
        DaoFactory.getImQtyDiscrepancyReceiptAccessExt().deleteByDiscrepancy(id);
        DaoFactory.getImQtyDiscrepancyRoleAccessExt().deleteByDiscrepancy(id);
        DaoFactory.getImQtyDiscrepancyAccessExt().delete(id);
    }

    public long getQtyDiscrepancyIdForItemDocId(String item, String docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            DALGenPreparedSQLFragment stmt = new DALGenPreparedSQLFragment(
                    "DOC_ID = ? AND ITEM = ?");
            ImQtyDiscrepancyAccess qtyDisAccess = new ImQtyDiscrepancyAccess();
            stmt.setString(1, docId);
            stmt.setString(2, item);
            ImQtyDiscrepancyRow[] qtyRow = qtyDisAccess.read(stmt, null, null, null);

            if (qtyRow != null)
                return qtyRow[0].getQtyDiscrepancyId();
            else
                return -1;
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(
                    "error.discrepancy_service.get_discrepancy_id_for_item_doc_id",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }
    
	public long getCostDiscrepancyIdForItemDocId(String item, String docId) throws ReIMException {
		try {
			TransactionManagerFactory.getInstance().start();

			long costDiscrepancyId = -1;

			DALGenPreparedSQLFragment fragment = new DALGenPreparedSQLFragment(
				"DOC_ID = ? AND ITEM = ?");

			fragment.setString(1, docId);
			fragment.setString(2, item);
			
			ImCostDiscrepancyAccess costDisAccess = new ImCostDiscrepancyAccess();

			ImCostDiscrepancyRow[] costDiscrepancyRows = costDisAccess
				.read(fragment, null, null, null);

			if (!ArrayUtils.isEmpty(costDiscrepancyRows)) {
				costDiscrepancyId = costDiscrepancyRows[0].getCostDiscrepancyId();
	}

	return costDiscrepancyId;
} catch (ReIMException e) {
	TransactionManagerFactory.getInstance().rollback();
	throw e;
} catch (Exception e) {
	TransactionManagerFactory.getInstance().rollback();
	throw new ReIMException(
			"error.discrepancy_service.get_discrepancy_id_for_item_doc_id",
			Severity.ERROR, e, DiscrepancyService.class);
} finally {
	TransactionManagerFactory.getInstance().end();
}
}
    
	public void deleteQuantityDiscrepancyById(long discId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            deleteQuantityDiscrepancy(discId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.deleteQuantityDiscrepancyById",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public long doDeleteAndCreateCostDiscrepancy(DocumentItemInvoice invoiceItem)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            long docId = invoiceItem.getDocId();
            String itemId = invoiceItem.getItem().getItemId();
            String supplierId = invoiceItem.getDocument().getVendor().getVendorId();
            doDeleteCostDiscrepancy(invoiceItem);

            ImCostDiscrepancyRow rowsd = new ImCostDiscrepancyRow();
            rowsd.setDocId(docId);
            rowsd.setItem(itemId);
            rowsd.setDebitMemoReasonCodeToNull();
            rowsd.setLocation(Long.parseLong(invoiceItem.getDocument().getLocation()
                    .getLocationId()));
            rowsd.setLocType(invoiceItem.getDocument().getLocation().getLocationType());
            rowsd.setOrderNo(Integer.parseInt(invoiceItem.getDocument().getOrderNo()));
            String vendorId = invoiceItem.getDocument().getVendor().getVendorId();
            rowsd.setSupplier(Long.parseLong(vendorId));
            rowsd.setCurrencyCode(invoiceItem.getDocument().getCurrencyCode());
            rowsd.setRoutingDate(ServiceFactory.getPeriodService().getScreenVDate().getTimestamp());
            ReIMDate docDueDate = invoiceItem.getDocument().getDueDate();
            ReIMDate vDate = ServiceFactory.getPeriodService().getScreenVDate();
            rowsd.setResolveByDate(ServiceFactory.getDiscrepancyService()
                    .calculateDiscrepancyResolveByDate(docDueDate,
                            ReIMUserContext.getSystemOptions(), vDate,
                            ReIMConstants.DISCREPANCY_TYPE_COST_ABBR).getTimestamp());
            rowsd.setDocUnitCost(invoiceItem.getResolutionAdjustedUnitCost());
            rowsd.setDocTotalCost(invoiceItem.getDocument().getTotalCost().doubleValue());
            Item item = invoiceItem.getItem();
            AItemBean itemBean = (AItemBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AItemBean);
            itemBean.setDepartmentClassForItem(item);
            rowsd.setDept(Integer.parseInt(item.getItemDept()));
            rowsd.set_class(Integer.parseInt(item.getItemClass()));
            UserRoleClass userRoleclass = UserRoleService.getUserRoleClass(itemId);
            if (userRoleclass == null) {
                TransactionManagerFactory.getInstance().rollback();
                throw new ReIMException(
                        "error.discrepancy_service.delete_and_create_cost_discrepancy.user_role_class_not_found",
                        Severity.DEBUG,
                        new Exception(
                                "error.discrepancy_service.delete_and_create_cost_discrepancy.user_role_class_not_found"),
                        DiscrepancyService.class);
            }

            rowsd.setBusinessRoleId(userRoleclass.getBusinessRole().getBusinessRoleId());
            if ((invoiceItem.getDocument().getTermsDscntPct().doubleValue()) > 0.0) {
                rowsd.setCashDscntInd(ReIMConstants.YES);
            } else {
                rowsd.setCashDscntInd(ReIMConstants.NO);
            }
            rowsd.setApReviewer(ServiceFactory.getSupplierOptionsService()
                    .getApReviewerBySupplierId(supplierId));
            rowsd.setDocType(Document.MERCHANDISE_INVOICE);
            rowsd.setResolutionCost(0);

            ImCostDiscrepancyAccess access = new ImCostDiscrepancyAccess();
            access.create(rowsd);

            ImDocHeadAccess headAccess = new ImDocHeadAccess();
            ImDocHeadRow row = new ImDocHeadRow();
            row.setDocId(docId);
            row.setDetailMatched(ReIMConstants.YES);
            row.setStatus(MerchandiseDocument.UNRESOLVED_MATCH);
            row.setLastDatetime(new ReIMDate().getTimestamp());
            row.setLastUpdateId(ReIMUserContext.getUsername());
            headAccess.update(row);

            return rowsd.getCostDiscrepancyId();
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.delete_and_create_cost_discrepancy",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

    }

    public void doDeleteCostDiscrepancy(DocumentItemInvoice invoiceItem) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            long docId = invoiceItem.getDocId();
            String itemId = invoiceItem.getItem().getItemId();
            DocumentItemInvoice[] oneInvoiceItem = { invoiceItem};
            ImResolutionActionAccessExt accessExt = new ImResolutionActionAccessExt();
            accessExt.deletePartialCostResolutions(oneInvoiceItem);
            deleteCostDiscrepancyByDocItemId(docId, itemId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.delete_cost_discrepancy",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

    }

   public double getQtyDisc (String docId, String orderNo, String loc, String item ) throws ReIMException {
    try {
        TransactionManagerFactory.getInstance().start();
         ImInvoiceDetailAccessExt accessExt = new ImInvoiceDetailAccessExt();
         return accessExt.getQtyDisc(docId, orderNo, loc, item); 

    } catch (ReIMException e) {
        TransactionManagerFactory.getInstance().rollback();
        throw e;
    } catch (Exception e) {
        TransactionManagerFactory.getInstance().rollback();
        throw new ReIMException("error.discrepancy_service.delete_cost_discrepancy",
                Severity.ERROR, e, DiscrepancyService.class);
    } finally {
        TransactionManagerFactory.getInstance().end();
    }

    }
    
    public double getCostDisc (String docId, String orderNo, String loc, String item ) throws ReIMException {
     try {
         TransactionManagerFactory.getInstance().start();
          ImInvoiceDetailAccessExt accessExt = new ImInvoiceDetailAccessExt();
          return accessExt.getCostDisc(docId, orderNo, loc, item); 

     } catch (ReIMException e) {
         TransactionManagerFactory.getInstance().rollback();
         throw e;
     } catch (Exception e) {
         TransactionManagerFactory.getInstance().rollback();
         throw new ReIMException("error.discrepancy_service.delete_cost_discrepancy",
                 Severity.ERROR, e, DiscrepancyService.class);
     } finally {
         TransactionManagerFactory.getInstance().end();
     }

  }
    public long doDeleteAndCreateQtyDiscrepancy(DocumentItemInvoice invoiceItem,
            ReceiptItem[] receiptItems) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            long docId = invoiceItem.getDocId();
            String itemId = invoiceItem.getItem().getItemId();
            DocumentItemInvoice[] oneInvoiceItem = { invoiceItem};
            ImResolutionActionAccessExt accessExt = new ImResolutionActionAccessExt();
            accessExt.deletePartialQtyResolutions(oneInvoiceItem);
            long oldDiscrepancyId = ServiceFactory.getDiscrepancyService()
                    .getQtyDiscrepancyIdForItemDocId(itemId, String.valueOf(docId));
            if (oldDiscrepancyId != -1) {
                ServiceFactory.getDiscrepancyService().deleteQuantityDiscrepancyById(
                        oldDiscrepancyId);
            }

            ImQtyDiscrepancyRow rowsd = new ImQtyDiscrepancyRow();
            rowsd.setDocId(docId);
            rowsd.setItem(itemId);
            rowsd.setDebitMemoReasonCodeToNull();
            rowsd.setLocation(Long.parseLong(invoiceItem.getDocument().getLocation()
                    .getLocationId()));
            rowsd.setLocType(invoiceItem.getDocument().getLocation().getLocationType());
            rowsd.setOrderNo(Integer.parseInt(invoiceItem.getDocument().getOrderNo()));
            String vendorId = invoiceItem.getDocument().getVendor().getVendorId();
            rowsd.setSupplier(Long.parseLong(vendorId));
            rowsd.setRoutingDate(ServiceFactory.getPeriodService().getScreenVDate().getTimestamp());
            ReIMDate docDueDate = invoiceItem.getDocument().getDueDate();
            ReIMDate vDate = ServiceFactory.getPeriodService().getScreenVDate();
            rowsd.setResolveByDate(ServiceFactory.getDiscrepancyService()
                    .calculateDiscrepancyResolveByDate(docDueDate,
                            ReIMUserContext.getSystemOptions(), vDate,
                            ReIMConstants.DISCREPANCY_TYPE_QUANTITY_ABBR).getTimestamp());
            rowsd.setQtyInvoiced(invoiceItem.getResolutionAdjustedQtyInvoiced());
            rowsd.setApReviewer(ServiceFactory.getSupplierOptionsService()
                    .getApReviewerBySupplierId(vendorId));
            rowsd.setDocType(Document.MERCHANDISE_INVOICE);
            rowsd.setResolutionQty(0);

            Long[] roleIds = UserRoleService.getUserRoleId(invoiceItem.getDocument().getLocation()
                    .getLocationId());
            if (roleIds == null || roleIds.length == 0) { throw new ReIMException(
                    "error.business_role_must_be_setup_for_location", Severity.DEBUG, null,
                    DiscrepancyService.class, new String[] { invoiceItem.getDocument()
                            .getLocation().getLocationId()}); }

            // populating IM_QTY_DISCREPANCY table
            ImQtyDiscrepancyAccess qdAccess = new ImQtyDiscrepancyAccess();
            qdAccess.create(rowsd);
            long qtyDiscrepancyId = rowsd.getQtyDiscrepancyId();

            // populating IM_QTY_DISCREPANCY_ROLE table
            ImQtyDiscrepancyRoleRow[] qdRoleRow = new ImQtyDiscrepancyRoleRow[roleIds.length];
            ImQtyDiscrepancyRoleAccess qdRoleAccess = new ImQtyDiscrepancyRoleAccess();
            for (int i = 0; i < roleIds.length; i++) {
                ImQtyDiscrepancyRoleRow qdRoleRow1 = new ImQtyDiscrepancyRoleRow(qtyDiscrepancyId,
                        roleIds[i].longValue());
                qdRoleRow[i] = qdRoleRow1;
            }
            qdRoleAccess.create(qdRoleRow);

            // populating IM_QTY_DISCREPANCY_RECEIPT table
            ImQtyDiscrepancyReceiptAccess qdReceiptAccess = new ImQtyDiscrepancyReceiptAccess();
            ImQtyDiscrepancyReceiptRow[] qdReceiptRow = new ImQtyDiscrepancyReceiptRow[receiptItems.length];
            for (int i = 0; i < receiptItems.length; i++) {
                ImQtyDiscrepancyReceiptRow qdReceiptRow1 = new ImQtyDiscrepancyReceiptRow(
                        qtyDiscrepancyId, Long.parseLong(receiptItems[i].getReceipt()
                                .getReceiptId()));
                qdReceiptRow[i] = qdReceiptRow1;
            }
            qdReceiptAccess.create(qdReceiptRow);

            ImDocHeadAccess headAccess = new ImDocHeadAccess();
            ImDocHeadRow row = new ImDocHeadRow();
            row.setDocId(docId);
            row.setDetailMatched(ReIMConstants.YES);
            row.setStatus(MerchandiseDocument.UNRESOLVED_MATCH);
            row.setLastDatetime(new ReIMDate().getTimestamp());
            row.setLastUpdateId(ReIMUserContext.getUsername());
            headAccess.update(row);

            return qtyDiscrepancyId;
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.delete_and_create_cost_discrepancy",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }

    }

    public void deleteCostDiscrepancyByDocItemId(long docId, String itemId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImCostDiscrepancyAccessExt accessExt = new ImCostDiscrepancyAccessExt();
            accessExt.deleteCostDiscrepanciesByDocIdAndItemId(docId, itemId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.deleteCostDiscrepancyById",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void deleteCostDiscrepancyById(long[] discrepancyIds) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            DaoFactory.getImCostDiscrepancyAccessExt()
                    .deleteCostDiscrepancyByDiscId(discrepancyIds);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.deleteCostDiscrepancyById",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public PriceReviewDetail readCostDiscrepancyById(long id) throws ReIMException {
        try {
        	boolean isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
            .isSupplierSiteInd();
            TransactionManagerFactory.getInstance().start();
            AOrderBean orderBean = (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);
            DiscrepancyCostReviewDetail[] discrepancyCostReviewDetails = orderBean
                    .readDiscrepancyDetailsByDiscrepancyId(id,isSupplierSiteIndOn);
            PriceReviewDetail priceReviewDetail = new PriceReviewDetail(
                    discrepancyCostReviewDetails[0]);
            return priceReviewDetail;
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.readCostDiscrepancyById",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void deleteQtyAndCostDiscrepanciesByDocId(long[] docIds) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            long docId = 0;
            for (int i = 0; i < docIds.length; i++) {
                docId = docIds[i];
                // Quantity discrepancies
                long[] qtyDiscrepancyIds = getQtyDiscrepancyIdsForDocId(docId);
                if (qtyDiscrepancyIds != null && qtyDiscrepancyIds.length != 0) {
                    for (int j = 0; j < qtyDiscrepancyIds.length; j++) {
                        deleteQuantityDiscrepancy(qtyDiscrepancyIds[j]);
                    }
                }
                // Cost discrepancies
                long[] costDiscrepancyIds = getCostDiscrepancyIdsForDocId(docId);
                if (costDiscrepancyIds != null && costDiscrepancyIds.length != 0) {
                    deleteCostDiscrepancyById(costDiscrepancyIds);
                }
            }
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(
                    "error.discrepancy_service.delete_qty_and_cost_discrepancies_by_doc_id",
                    Severity.ERROR, e, DiscrepancyService.class, new String[] { docIds + ""});
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private long[] getQtyDiscrepancyIdsForDocId(long docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            DALGenPreparedSQLFragment stmt = new DALGenPreparedSQLFragment("DOC_ID = ? ");
            stmt.setLong(1, docId);
            ImQtyDiscrepancyRow[] qtyRow = DaoFactory.getImQtyDiscrepancyAccessExt().read(stmt,
                    null, null, null);

            if (qtyRow != null) {
                long[] qtyDiscrepancyIds = new long[qtyRow.length];
                for (int i = 0; i < qtyRow.length; i++) {
                    qtyDiscrepancyIds[i] = qtyRow[i].getQtyDiscrepancyId();
                }
                return qtyDiscrepancyIds;
            } else {
                long[] noQtyDiscrepancies = new long[0];
                return noQtyDiscrepancies;
            }

        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.get_discrepancy_ids_for_doc_id",
                    Severity.ERROR, e, DiscrepancyService.class, new String[] { docId + ""});
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private long[] getCostDiscrepancyIdsForDocId(long docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            DALGenPreparedSQLFragment stmt = new DALGenPreparedSQLFragment("DOC_ID = ? ");
            stmt.setLong(1, docId);
            ImCostDiscrepancyRow[] costRow = DaoFactory.getImCostDiscrepancyAccessExt().read(stmt,
                    null, null, null);

            if (costRow != null) {
                long[] costDiscrepancyIds = new long[costRow.length];
                for (int i = 0; i < costRow.length; i++) {
                    costDiscrepancyIds[i] = costRow[i].getCostDiscrepancyId();
                }
                return costDiscrepancyIds;
            } else {
                return null;
            }

        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.get_discrepancy_ids_for_doc_id",
                    Severity.ERROR, e, DiscrepancyService.class, new String[] { docId + ""});
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public void deleteDiscrepanciesAndResolutions(MerchandiseDocument[] invoices)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImResolutionActionAccessExt resAccessExt = new ImResolutionActionAccessExt();
            resAccessExt.deletePartialResolutions(invoices);
            ImCostDiscrepancyAccessExt accessExt = new ImCostDiscrepancyAccessExt();
            accessExt.deleteCostDiscrepancies(invoices);

            List discrepancies = null;
            String docId = null;
            for (int j = 0; j < invoices.length; j++) {
                docId = new Long(invoices[j].getDocId()).toString();
                discrepancies = getQtyDiscrepanciesForDocId(docId);
                if (discrepancies.size() > 0) {
                    deleteQuantityDiscrepancies(discrepancies);
                }
                discrepancies = getCostDiscrepanciesForDocId(docId);
                if (discrepancies.size() > 0) {
                    deleteCostDiscrepancies(discrepancies);
                }
            }
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException(
                    "error.discrepancy_service.delete_discrepancies_and_resolutions",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public List getQtyDiscrepanciesForDocId(String docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImQtyDiscrepancyAccessExt qtyDisAccess = new ImQtyDiscrepancyAccessExt();
            return qtyDisAccess.getQtyDiscrepanciesForDocId(docId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.readQtyDiscrepancyById",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private void deleteQuantityDiscrepancies(List discrepancies) throws ReIMException {
        for (Iterator idIter = discrepancies.iterator(); idIter.hasNext();) {
            DiscrepancyVo discrepancyVo = (DiscrepancyVo) idIter.next();
            deleteQuantityDiscrepancy(discrepancyVo.getDiscrepancyId());
        }
    }

    public List getCostDiscrepanciesForDocId(String docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            ImCostDiscrepancyAccessExt costDisAccess = new ImCostDiscrepancyAccessExt();
            return costDisAccess.getCostDiscrepanciesForDocId(docId);
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.discrepancy_service.readCostDiscrepancyById",
                    Severity.ERROR, e, DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private void deleteCostDiscrepancies(List discrepancyVos) throws ReIMException {
        long[] discrepancyIds = new long[discrepancyVos.size()];
        int i = 0;
        for (Iterator voIter = discrepancyVos.iterator(); voIter.hasNext();) {
            discrepancyIds[i++] = ((DiscrepancyVo) voIter.next()).getDiscrepancyId();
        }
        ImCostDiscrepancyAccessExt costDisAccess = new ImCostDiscrepancyAccessExt();
        costDisAccess.deleteCostDiscrepancyByDiscId(discrepancyIds);
    }

    public List getResolutionsForDocId(String docId) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            List resolutions = null;
            ImResolutionActionAccessExt resAccessExt = new ImResolutionActionAccessExt();
            resolutions = resAccessExt.getResolutionActionsForDocument(docId);
            return resolutions;
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw e;
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.cannot_retrieve_resolution_actions", Severity.ERROR, e,
                    DiscrepancyService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }


}
