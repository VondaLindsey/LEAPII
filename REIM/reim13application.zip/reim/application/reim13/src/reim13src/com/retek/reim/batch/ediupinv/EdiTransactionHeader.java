package com.retek.reim.batch.ediupinv;

import static oracle.retail.reim.business.EdiValidationResult.FAILURE_REJECT_FILE;
import static oracle.retail.reim.business.EdiValidationResult.FAILURE_REJECT_TABLES;
import static oracle.retail.reim.business.EdiValidationResult.VALIDATION_SUCCESS;

import java.util.HashSet;
import java.util.Set;

import oracle.retail.reim.business.EdiItemSource;
import oracle.retail.reim.business.EdiValidationResult;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.VendorType;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.NumberUtils;
import oracle.retail.reim.utils.PatternMatchingUtils;
import oracle.retail.reim.utils.ReimProperties;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.StringUtils;

import EDU.oswego.cs.dl.util.concurrent.Puttable;

import com.ibm.icu.math.BigDecimal;
import com.retek.merch.utils.ApplicationContext;
import com.retek.merch.utils.RetekException;
import com.retek.merch.utils.UserContext;
import com.retek.reim.batch.BatchUtils;
import com.retek.reim.batch.ediupinv.threading.EdiTransactionUploadReporter;
import com.retek.reim.business.EdiRejectDocument;
import com.retek.reim.business.EdiRejectReasons;
import com.retek.reim.business.Location;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.SupplierGroup;
import com.retek.reim.business.SupplierOptions;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.foundation.rms12.PartnerBean;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.merch.utils.threads.ThreadedProcess;
import com.retek.reim.services.EdiTransactionHeaderValidationService;
import com.retek.reim.services.LocationService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.UIFieldValidationService;
import oracle.retail.reim.business.MerchType;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.1	07-Apr-2015	 Naveen J	ME 426347  426347-EDI - EZCOM 810/856 Duplication Issue 
 * 
 */

/**
 * Holds an entire EDI transaction consisting of a transaction header (THEAD), an array of details
 * (TDETL), an array of non-merch records (TNMRC), and a transaction tail (TTAIL). Additionally,
 * each detail record may contain an array of allowance records (TALLW).
 * <p>
 * A transaction is the unit of work used by the EDI upload batch program and also by the EDI reject
 * gui interface. Transactions are also referred to as documents in ReIM.
 */
public class EdiTransactionHeader extends ThreadedProcess implements EDIConstants, Runnable {
    private String recordDescriptor;
    private long lineID;
    private long transactionNumber;
    private String documentType;
    private String vendorDocumentNumber;
    private String vendorType;
    private String vendorID = null;
    private String supplierSiteID = null;
    private boolean supplierSiteEnabled = false;
    private ReIMDate vendorDocumentDate;
    private Long orderNumber = null;
    private Long location = null;
    private String locationType;
    private String terms;
    private Double termsDiscountPercentage = null;
    private ReIMDate dueDate;
    private String paymentMethod;
    private String currencyCode;
    private Double exchangeRate = null;
    private BigDecimal totalCost = new BigDecimal(0);
    private BigDecimal totalQuantity = new BigDecimal(0);
    private BigDecimal totalDiscount = new BigDecimal(0);
    private BigDecimal totalTaxAmount = new BigDecimal(0);
    private String freightType;
    private String manuallyPaidInd;
    private String multiLocation;
    private String merchType;
    private Long dealId = null;
    private String dealApprovalInd;
    private String rtvInd;

    private String customDocumentReference1;
    private String customDocumentReference2;
    private String customDocumentReference3;
    private String customDocumentReference4;
    private Long crossReferenceDocumentNumber = null;
    private String originalRecord;
    private Long documentId = null;
    // boolean to indicate whether the edi file has supplier site or supplier
    private boolean fileSupplierSiteInd;
    // EdiDownload variables
    private String invoiceNumber;
    private boolean isEdiDownload = false;

    // Each transaction can have multiple details and/or non-merch details
    private EdiNonMerchDetail[] ediNonMerchDetailList = null;
    private EdiTransactionDetail[] ediTransactionDetailList = null;
    private EDIHeaderTax[] ediTaxDetailList = null;

    private BigDecimal detailControlTotalCostSum = new BigDecimal(0);
    private BigDecimal detailControlTotalQuantitySum = new BigDecimal(0);

    private BigDecimal totalTaxAmountFromDetails = new BigDecimal(0);
    private BigDecimal totalTaxAmountFromTTAXS = new BigDecimal(0);

    private EdiTransactionTail ediTransactionTail = null;

    private boolean transactionValid = true;

    private String errorCode = null;

    private String invoiceNumberRegularExpression = null;

    private String errorColumnId = null;
    private String rejectReason = null;
    private Long rejectedDocDetailId = null;

    private final Puttable backgroundQueue;
    private String[] ediUploadArgs = null;
    private EdiDocBulk ediDocBulk = null;
    private String groupId = null;

    private final String SUPPLIER_NEW = "S";

    public final String CREDIT_NOTE_REQUEST_PRICE = "CNRC";
    public final String CREDIT_NOTE_REQUEST_QUANTITY = "CNRQ";
    public final String DEBIT_MEMO_PRICE = "DBMC"; // Price changed to cost
    public final String DEBIT_MEMO_QUANTITY = "DBMQ";

    private EdiTransactionUploadReporter uploadReporter = null;
    
    private String supplierIdInFile=null;
    private String documentSupplierParent=null;
    private String orderSupplierParent=null;

    // SPring autowired service.
    // private IEdiDocumentService ediDocumentService;

    /**
     * Default constructor. Creates a transaction header with default values.
     */
    public EdiTransactionHeader() {
        backgroundQueue = null;
    }

    /**
     * Constructor used by the EDI reject user interface. Creates a transaction (document) which is
     * to be sent through validation again.
     * 
     * @param documentId
     *            distinct ID created by the system
     * @param documentType
     *            type of document (merch, non-merch, credit note, etc.)
     * @param vendorDocumentNumber
     *            document number sent by the vendor. Vendor document numbers must be distinct per
     *            vendor.
     * @param vendorType
     *            either supplier or partner
     * @param vendorID
     *            distinct ID for this vendor in the ReIM system
     * @param vendorDocumentDate
     *            date this document was created
     * @param orderNumber
     *            merchandising system order number for this
     * @param location
     *            ReIM location number identifier
     * @param locationType
     *            either 'S'tore or 'W'arehouse
     * @param terms
     *            payment terms for the document
     * @param termsDiscountPercentage
     *            percentage of the total cost which may be deducted if payed within the terms due
     *            date
     * @param dueDate
     *            date that payment is expected
     * @param paymentMethod
     *            manner in which payment will be made
     * @param currencyCode
     *            currency in which this document is written
     * @param exchangeRate
     *            percentage multiplier used when currencyCode is not the base currency
     * @param totalCost
     *            sum of all costs on this document
     * @param totalQuantity
     *            sum of quantities on this document
     * @param totalDiscount
     *            discount applied to this document
     * @param freightType
     *            method of shippment
     * @param manuallyPaidInd
     *            Y/N indicator specifying if this document has been paid
     * @param multiLocation
     *            Y/N indicator specifying if this invoice is for many locations
     * @param customDocumentReference1
     *            used for client customization
     * @param customDocumentReference2
     *            used for client customization
     * @param customDocumentReference3
     *            used for client customization
     * @param customDocumentReference4
     *            used for client customization
     * @param crossReferenceDocumentNumber
     *            if this document is a credit note, this indicates the document it is crediting
     * @param ediNonMerchDetailList
     *            array of non-merchandise details
     * @param ediTransactionDetailList
     *            array of transaction details which may contain an array of allowances
     * @throws ReIMException
     */
    public EdiTransactionHeader(Long documentId, String documentType, String vendorDocumentNumber,
            String vendorType, String vendorID, ReIMDate vendorDocumentDate, Long orderNumber,
            Long location, String locationType, String terms, Double termsDiscountPercentage,
            ReIMDate dueDate, String paymentMethod, String currencyCode, Double exchangeRate,
            double totalCost, double totalQuantity, double totalDiscount, String freightType,
            String paidInd, String multiLocation, String merchType, Long dealId,
            String dealApprovalInd, String rtvInd, String customDocumentReference1,
            String customDocumentReference2, String customDocumentReference3,
            String customDocumentReference4, Long crossReferenceDocumentNumber,
            EdiNonMerchDetail[] ediNonMerchDetailList,
            EdiTransactionDetail[] ediTransactionDetailList, long newGroupId) {
        this.documentId = documentId;
        this.documentType = documentType;
        this.vendorDocumentNumber = vendorDocumentNumber;
        this.vendorType = vendorType;
        this.vendorID = vendorID;
        this.vendorDocumentDate = vendorDocumentDate;
        this.orderNumber = orderNumber;
        this.location = location;
        this.locationType = locationType;
        this.terms = terms;
        this.termsDiscountPercentage = termsDiscountPercentage;
        this.dueDate = dueDate;
        this.paymentMethod = paymentMethod;
        this.currencyCode = currencyCode;
        this.exchangeRate = exchangeRate;
        this.totalCost = new BigDecimal(totalCost);
        this.totalCost = this.totalCost.setScale(4, BigDecimal.ROUND_HALF_UP);
        this.totalQuantity = new BigDecimal(totalQuantity);
        if (!this.totalQuantity.toString().equals(this.totalQuantity.toBigInteger().toString())) {
            this.totalQuantity = this.totalQuantity.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
        }
        this.totalDiscount = new BigDecimal(totalDiscount);
        this.totalDiscount = this.totalDiscount.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
        this.freightType = freightType;
        this.manuallyPaidInd = paidInd;
        this.multiLocation = multiLocation;
        this.merchType = merchType;
        this.dealId = dealId;
        this.rtvInd = rtvInd;
        this.dealApprovalInd = dealApprovalInd;
        this.customDocumentReference1 = customDocumentReference1;
        this.customDocumentReference2 = customDocumentReference2;
        this.customDocumentReference3 = customDocumentReference3;
        this.customDocumentReference4 = customDocumentReference4;
        this.crossReferenceDocumentNumber = crossReferenceDocumentNumber;
        this.ediNonMerchDetailList = ediNonMerchDetailList;
        this.ediTransactionDetailList = ediTransactionDetailList;
        backgroundQueue = null;
        if (newGroupId == Long.MIN_VALUE) {
            this.groupId = null;
        } else {
            this.groupId = String.valueOf(groupId);
        }

    }

    public EdiTransactionHeader(Long documentId, String documentType, String vendorDocumentNumber,
            String vendorType, String vendorID, ReIMDate vendorDocumentDate, Long orderNumber,
            Long location, String locationType, String terms, Double termsDiscountPercentage,
            ReIMDate dueDate, String paymentMethod, String currencyCode, Double exchangeRate,
            double totalCost, double totalQuantity, double totalDiscount, String freightType,
            String paidInd, String multiLocation, String merchType, Long dealId,
            String dealApprovalInd, String rtvInd, String customDocumentReference1,
            String customDocumentReference2, String customDocumentReference3,
            String customDocumentReference4, Long crossReferenceDocumentNumber,
            EdiNonMerchDetail[] ediNonMerchDetailList,
            EdiTransactionDetail[] ediTransactionDetailList, long newGroupId, String supplierSiteID) {

        this(documentId, documentType, vendorDocumentNumber, vendorType, vendorID,
                vendorDocumentDate, orderNumber, location, locationType, terms,
                termsDiscountPercentage, dueDate, paymentMethod, currencyCode, exchangeRate,
                totalCost, totalQuantity, totalDiscount, freightType, paidInd, multiLocation,
                merchType, dealId, dealApprovalInd, rtvInd, customDocumentReference1,
                customDocumentReference2, customDocumentReference3, customDocumentReference4,
                crossReferenceDocumentNumber, ediNonMerchDetailList, ediTransactionDetailList,
                newGroupId);

        this.supplierSiteID = supplierSiteID;

    }

    /**
     * Constructor used by the EDI upload program. Receives a record created from one line of the
     * EDI flat file. Parses the string contained in the record into the object variables and
     * validates the data types. Any validation errors will result in this transaction being written
     * to the error file.
     * 
     * @param ediRecord
     *            object created when EDI upload program reads one line from the EDI file
     * @param transactionCounter
     *            number indicating which transaction this is expected to be, used for validation
     * @throws ReIMException
     */
    public EdiTransactionHeader(EdiRecord ediRecord, Puttable b, String[] args,
            EdiDocBulk ediDocBulk) throws ReIMException {
        // Local strings to hold data until parsing of numbers
        String transactionNumberString;
        String vendorDocumentDateString;
        String orderNumberString;
        String locationString;
        String dueDateString;
        String exchangeRateString;
        String totalCostString;
        String totalTaxAmountString;
        String totalQuantityString;
        String totalDiscountString;
        String crossReferenceDocumentNumberString;
        String dealIdString;
        String totalCostSignInd, totalTaxAmountSignInd, totalQtySignInd, totalDiscountSignInd;
        // Fetch values from record
        this.recordDescriptor = ediRecord.getRecordDescriptor();
        this.lineID = ediRecord.getLineID();

        // Parse the rest of the record
        transactionNumberString = ediRecord.takeFromRecord(LEN_TRANSACTION_NUMBER).trim();
        this.documentType = ediRecord.takeFromRecord(LEN_DOCUMENT_TYPE).trim();
        if (this.documentType.equals(DEBIT_MEMO_PRICE)) {
            this.documentType = Document.DEBIT_MEMO_PRICE;
        } else if (this.documentType.equals(DEBIT_MEMO_QUANTITY)) {
            this.documentType = Document.DEBIT_MEMO_QUANTITY;
        } else if (this.documentType.equals(CREDIT_NOTE_REQUEST_PRICE)) {
            this.documentType = Document.CREDIT_NOTE_REQUEST_PRICE;
        } else if (this.documentType.equals(CREDIT_NOTE_REQUEST_QUANTITY)) {
            this.documentType = Document.CREDIT_NOTE_REQUEST_QUANTITY;
        }
        this.vendorDocumentNumber = ediRecord.takeFromRecord(LEN_VENDOR_DOCUMENT_NUMBER).trim()
                .toUpperCase(UserContext.getLocale());
        this.groupId = ediRecord.takeFromRecord(LEN_GROUP_ID).trim().toUpperCase(
                UserContext.getLocale());
        this.vendorType = ediRecord.takeFromRecord(LEN_VENDOR_TYPE).trim();
        // the compilant with RMS data
        if (this.vendorType.equals(SUPPLIER_NEW)) {
            this.vendorType = Vendor.SUPPLIER;
        }

        // Strip the leading zeros before inserting the vendor ID.
        String tempVendorId = ediRecord.takeFromRecord(LEN_VENDOR_ID).trim();
        this.supplierIdInFile=tempVendorId;

        vendorDocumentDateString = ediRecord.takeFromRecord(LEN_DATE).trim();
        orderNumberString = ediRecord.takeFromRecord(LEN_ORDER_NUMBER).trim();
        locationString = ediRecord.takeFromRecord(LEN_LOCATION).trim();
        this.locationType = ediRecord.takeFromRecord(LEN_LOCATION_TYPE).trim();
        this.terms = ediRecord.takeFromRecord(LEN_TERMS).trim();
        dueDateString = ediRecord.takeFromRecord(LEN_DATE).trim();
        this.paymentMethod = ediRecord.takeFromRecord(LEN_PAYMENT_METHOD).trim();
        this.currencyCode = ediRecord.takeFromRecord(LEN_CURRENCY_CODE).trim();
        exchangeRateString = ediRecord.takeFromRecord(LEN_EXCHANGE_RATE).trim();
        totalCostSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalCostString = ediRecord.takeFromRecord(LEN_COST).trim();

        totalTaxAmountSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalTaxAmountString = ediRecord.takeFromRecord(LEN_TAX_AMOUNT).trim();

        totalQtySignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalQuantityString = ediRecord.takeFromRecord(LEN_QUANTITY).trim();
        totalDiscountSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalDiscountString = ediRecord.takeFromRecord(LEN_TOTAL_DISCOUNT).trim();
        this.freightType = ediRecord.takeFromRecord(LEN_FREIGHT_TYPE).trim();
        this.manuallyPaidInd = ediRecord.takeFromRecord(LEN_IND).trim();
        this.multiLocation = ediRecord.takeFromRecord(LEN_IND).trim();
        this.merchType = ediRecord.takeFromRecord(LEN_IND).trim();
        dealIdString = ediRecord.takeFromRecord(LEN_DEAL_ID).trim();
        this.dealApprovalInd = ediRecord.takeFromRecord(LEN_IND).trim();
        this.rtvInd = ediRecord.takeFromRecord(LEN_IND).trim();
        this.customDocumentReference1 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        this.customDocumentReference2 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        this.customDocumentReference3 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        this.customDocumentReference4 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        crossReferenceDocumentNumberString = ediRecord.takeFromRecord(
                LEN_CROSS_REFERENCE_DOCUMENT_NUMBER).trim();

        this.originalRecord = ediRecord.getOriginalRecord();

        backgroundQueue = b;
        ediUploadArgs = args;
        this.ediDocBulk = ediDocBulk;

        invoiceNumberRegularExpression = ReimProperties.DOCUMENT_NUMBER_VALIDATION_REGEXPR;

        // Pre-validation transformation to handle RMS 10 style consignment
        // indication
        if (nullSafeEquals(merchType, ReIMConstants.YES)) {
            this.merchType = ReIMConstants.MERCH_TYPE_CONSIGNMENT;
        } else if (nullSafeEquals(merchType, ReIMConstants.NO)) {
            this.merchType = null;
        } 

        // Validation
        
        // Order Number
        if (orderNumberString.length() > 0) {
            try {
                this.orderNumber = new Long(orderNumberString);
            } catch (NumberFormatException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, orderNumberString,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                        this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

//      Vendor ID
        try {
        	long vendorId = Long.parseLong(tempVendorId);
        	this.vendorID = Long.toString(vendorId);
        	boolean isSupplierSiteIndOn = false;
        	String supplierParent = null;

        	isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
        	.isSupplierSiteInd();
        	if (vendorType.equalsIgnoreCase(Document.SUPPLIER) && isSupplierSiteIndOn) {
        		supplierParent = ServiceFactory.getVendorService().getSupplierParent(this.vendorID);
        		
        		if(supplierParent!=null)
        		{
        			this.supplierSiteID = this.vendorID;
        			this.vendorID = supplierParent;
        		}

        		if( vendorID == null)
        		{
        			
        			 String key = "error.batch.invalid_field";
        	            String field = ReIMI18NUtility.getMessage("batch.field.vendor_id");
        	            String[] parameters = new String[] { field, tempVendorId,
        	                    String.valueOf(this.lineID),String.valueOf(this.orderNumber),this.vendorDocumentNumber};
        	            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
        	            
        			this.transactionValid = false;

        		}

        	}
        }
        catch (Exception e) {

        	this.vendorID=null;
        	String key = "error.batch.invalid_number_format";
        	String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, tempVendorId,
        			String.valueOf(this.lineID),String.valueOf(this.orderNumber),
        			this.vendorDocumentNumber};
        	Logger.errorKey(EdiTransactionHeader.class, key, parameters);
        	this.transactionValid = false;

        }
        
        // No validation for Transaction Number at this point - should
        // have been taken care of during inital file sweep.
        try {
            this.transactionNumber = Long.parseLong(transactionNumberString);
        } catch (Exception e) {
            // this would have been caught in the initial file sweep, but just
            // to be safe....
            String key = "error.batch.invalid_number_format";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, transactionNumberString,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // Document Type
        if (this.documentType.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.document_type");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // Vendor Document Number
        if (this.vendorDocumentNumber.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // vendor document number must not have leading zero's
        else if (!validNoLeadingZeroString(this.vendorDocumentNumber)) {
            String key = "error.batch.no_leading_zero";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    this.vendorDocumentNumber, String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        /*
         * Vendor document number will be validated against the regular expression defined in
         * reim.properties. If the property is not specified system will validate for alpha-numeric
         * characters.
         */
        else if (!validateWithPatternString(this.vendorDocumentNumber,
                invoiceNumberRegularExpression)) {
            String key = "error.batch.alpha_numeric_special_characters_defined_only";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
            String allowedCharacters = invoiceNumberRegularExpression != null ? invoiceNumberRegularExpression
                    : PatternMatchingUtils.ALPHA_NUMERIC_CHARACTERS;
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field, allowedCharacters,
                    this.vendorDocumentNumber, String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }
        // groupId or batchId
        if (StringUtils.isNotBlank(groupId)) {
            try {
                Long groupIdLong = new Long(groupId);
            } catch (NumberFormatException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, groupId,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }
        // Vendor Type
        if (this.vendorType.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_type");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // Vendor Document Date
        if (vendorDocumentDateString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_date");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.vendorDocumentDate = BatchUtils.getDate(vendorDocumentDateString);
            } catch (ReIMException e) {
                String key = "error.batch.invalid_date_format";
                String[] parameters = new String[] { String.valueOf(LEN_DATE),
                        vendorDocumentDateString, String.valueOf(this.lineID),
                        String.valueOf(this.orderNumber), this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Location
        if (locationString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("label.location");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.location = new Long(locationString);
            } catch (NumberFormatException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, locationString,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                        this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }

            if (this.locationType.length() == 0) {
                String key = "error.batch.location_type_not_null_when_location_not_null";
                String[] parameters = new String[] { String.valueOf(this.lineID),
                        String.valueOf(this.orderNumber), this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Terms
        // No file format validation needed at this point.

        // Due Date
        if (dueDateString.length() > 0) {
            try {
                this.dueDate = BatchUtils.getDate(dueDateString);
            } catch (ReIMException e) {
                String key = "error.batch.invalid_date_format";
                String[] parameters = new String[] { String.valueOf(LEN_DATE), dueDateString,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                        this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Payment Method
        // No file format validation needed at this point.

        // Currency Code
        if (this.currencyCode.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.currency_code");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // Exchange Rate
        if (exchangeRateString.length() > 0) {
            try {
                this.exchangeRate = new Double(BatchUtils.getDouble(exchangeRateString, PRECISION4));
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, exchangeRateString,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                        this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        } else // get exchange rate from order if one is provided, otherwise
        // get from currency_rates
        {
            if (this.orderNumber == null) {
                this.exchangeRate = new Double(ServiceFactory.getDocumentService().getExchangeRate(
                        null, this.currencyCode, this.vendorDocumentDate));
            } else {
                this.exchangeRate = new Double(ServiceFactory.getDocumentService().getExchangeRate(
                        this.orderNumber.toString(), this.currencyCode, this.vendorDocumentDate));
            }
        }

        // Total Cost
        if (totalCostString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.total_cost");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.setTotalCost(BatchUtils.getDouble(totalCostString, PRECISION4));
                if (this.totalCost.doubleValue() == 0
                        && !this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
                    String key = "error.batch.field_not_zero";
                    String field = ReIMI18NUtility.getMessage("batch.field.total_cost");
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                            String.valueOf(this.lineID)};
                    Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                    this.transactionValid = false;
                }
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalCostString,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                        this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }
        // Total CostSign Indicator
        if (totalCostSignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else if (!totalCostSignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalCostSignInd.equals(EDIConstants.MINUS_SIGN)) {
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, totalCostSignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.NEGATIVE_SIGN
        else if (totalCostSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalCost = this.totalCost.negate();
        }

        // Total Tax Amount
        if (totalTaxAmountString.length() == 0) {
            this.totalTaxAmount = new BigDecimal(0);
            this.transactionValid = true;
        } else {
            try {
                this.setTotalTaxAmount(BatchUtils.getDouble(totalTaxAmountString, PRECISION4));
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalTaxAmountString,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Total TaxAmountSign Indicator
        if (totalTaxAmountSignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else if (!totalTaxAmountSignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalTaxAmountSignInd.equals(EDIConstants.MINUS_SIGN)) {
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, totalCostSignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.NEGATIVE_SIGN
        else if (totalTaxAmountSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalTaxAmount = this.totalTaxAmount.negate();
        }

        SupplierGroup supplierGroup = null;
        if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
            // Total Quantity: if it is null and total header quantity indicator
            // is checked, invalid
            try {
                Long.parseLong(this.vendorID);
                supplierGroup = ServiceFactory.getSupplierGroupService().getSupplierGroup(
                        this.vendorID);
            } catch (NumberFormatException e) {
                supplierGroup = null;
            }
        }

        boolean totalHeaderQtyReqInd = supplierGroup != null ? supplierGroup
                .isTotalHeaderQuantityRequired() : ReimProperties.DOCUMENT_HEADER_QUANTITY_REQUIRED;

        double totalQty = 0;
        try {
            if (totalQuantityString.length() != 0) {
                totalQty = BatchUtils.getDouble(totalQuantityString, PRECISION4);
            }
        } catch (ReIMException e) {
            String key = "error.batch.invalid_number_format";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalQuantityString,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }
        if ((totalQuantityString.length() == 0 || (totalQty == 0)) && totalHeaderQtyReqInd
                && (!this.documentType.equals(Document.NON_MERCHANDISE_INVOICE))) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.total_quantity");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else {
            this.setTotalQuantity(totalQty);
        }
        // Total Qty Sign Indicator
        if (totalQtySignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else if (!totalQtySignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalQtySignInd.equals(EDIConstants.MINUS_SIGN)) {
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, totalQtySignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.MINUS_SIGN
        else if (totalQtySignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalQuantity = this.totalQuantity.negate();
        }

        // Total Discount
        if (totalDiscountString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.total_discount");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.setTotalDiscount(BatchUtils.getDouble(totalDiscountString, PRECISION4));
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalDiscountString,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Total Discount Sign Indicator
        if (totalDiscountSignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        } else if (!totalDiscountSignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalDiscountSignInd.equals(EDIConstants.MINUS_SIGN)) {
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, totalDiscountSignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.NEGATIVE_SIGN
        else if (totalDiscountSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalDiscount = this.totalDiscount.negate();
        }

        // Freight Type
        // No file format validation needed at this point.

        // Paid Indicator
        if (this.manuallyPaidInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.paid_ind");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // multiLocation indicator
        if (this.multiLocation.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.multi_loc");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // deal id
        if (dealIdString.length() > 0) {
            try {
                this.dealId = new Long(dealIdString);
            } catch (NumberFormatException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, dealIdString,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // rtv ind
        if (this.rtvInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.rtv_ind");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
        }

        // Custom Document Reference 1
        // No file format validation needed at this point.

        // Custom Document Reference 2
        // No file format validation needed at this point.

        // Custom Document Reference 3
        // No file format validation needed at this point.

        // Custom Document Reference 4
        // No file format validation needed at this point.

        // Cross Reference Document Number
        if (crossReferenceDocumentNumberString.length() > 0) {
            try {
                Long number = new Long(crossReferenceDocumentNumberString);
                if (number.longValue() > 0) {
                    this.crossReferenceDocumentNumber = number;
                }

            } catch (NumberFormatException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                        crossReferenceDocumentNumberString, String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
            }

            try {
                long crossRefNum = Long.parseLong(crossReferenceDocumentNumberString);
                TransactionManagerFactory.getInstance().start();
                if (DaoFactory.getImDocHeadAccessExt().read(crossRefNum) == null) {
                    String key = "error.batch.no_doc_head_records_for_the_given_cross_ref_doc_num";
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                            crossReferenceDocumentNumberString, String.valueOf(this.lineID),
                            String.valueOf(this.vendorDocumentNumber)};
                    Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                    this.transactionValid = false;
                }
            } finally {
                TransactionManagerFactory.getInstance().end();
            }
        }

        // set this for the possibility of a rejection - the value
        // is truly invalid, but will be used for processing only.
        // when the insert/update happens, a real value will be created.
        this.documentId = Long.valueOf(this.transactionNumber);
    }

    /**
     * Method used to write this transaction as a flat record for the reject file.
     * 
     * @return all object variables concatenated into one string
     */
    public String createFlatRecord() {
        String record = "";

        record += BatchUtils.createFlatField(recordDescriptor, LEN_RECORD_DESCRIPTOR, NOPAD);
        record += BatchUtils.createFlatField(Long.valueOf(lineID), LEN_LINE_ID, PAD);
        record += BatchUtils.createFlatField(Long.valueOf(transactionNumber), LEN_TRANSACTION_NUMBER,
                PAD);
        if (isEdiDownload) {
            if (documentType.equals(Document.DEBIT_MEMO_PRICE)) {
                documentType = DEBIT_MEMO_PRICE;
            } else if (documentType.equals(Document.DEBIT_MEMO_QUANTITY)) {
                documentType = DEBIT_MEMO_QUANTITY;
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)) {
                documentType = CREDIT_NOTE_REQUEST_PRICE;
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                documentType = CREDIT_NOTE_REQUEST_QUANTITY;
            }
        }

        record += BatchUtils.createFlatField(documentType, LEN_DOCUMENT_TYPE, NOPAD);
        record += BatchUtils.createFlatField(vendorDocumentNumber + "", LEN_VENDOR_DOCUMENT_NUMBER,
                NOPAD);
        record += BatchUtils.createFlatField(groupId + "", LEN_GROUP_ID, NOPAD);
        if (isEdiDownload)
            record += BatchUtils.createFlatField(invoiceNumber, LEN_INVOICE_NUMBER, NOPAD);
        if (!isEdiDownload)
            record += BatchUtils.createFlatField(vendorType, LEN_VENDOR_TYPE, NOPAD);
        record += BatchUtils.createFlatField(vendorID, LEN_VENDOR_ID, NOPAD);
        record += BatchUtils.createFlatField(vendorDocumentDate.getBatchDateFormat(), LEN_DATE,
                NOPAD);
        record += BatchUtils.createFlatField(orderNumber, LEN_ORDER_NUMBER, NOPAD);
        record += BatchUtils.createFlatField(location, LEN_LOCATION, NOPAD);
        record += BatchUtils.createFlatField(locationType, LEN_LOCATION_TYPE, NOPAD);
        record += BatchUtils.createFlatField(terms, LEN_TERMS, NOPAD);
        record += BatchUtils.createFlatField(dueDate.getBatchDateFormat(), LEN_DATE, NOPAD);
        if (!isEdiDownload)
            record += BatchUtils.createFlatField(paymentMethod, LEN_PAYMENT_METHOD, NOPAD);
        record += BatchUtils.createFlatField(currencyCode, LEN_CURRENCY_CODE, NOPAD);
        record += BatchUtils.createFlatField(exchangeRate, LEN_EXCHANGE_RATE, PAD);
        record += BatchUtils.createFlatField(totalCost.doubleValue() > 0 ? EDIConstants.PLUS_SIGN
                : EDIConstants.MINUS_SIGN, LEN_IND, NOPAD);

        long totCost = Long.parseLong(totalCost.toString().substring(0,
                totalCost.toString().indexOf("."))
                + totalCost.toString().substring(totalCost.toString().indexOf(".") + 1));
        if (totCost < 0) {
            totCost *= -1;
        }

        record += BatchUtils.createFlatField(new BigDecimal(totCost), LEN_COST, PAD);

        record += BatchUtils
                .createFlatField(totalTaxAmount.doubleValue() > 0 ? EDIConstants.PLUS_SIGN
                        : EDIConstants.MINUS_SIGN, LEN_IND, NOPAD);
        record += BatchUtils.createFlatField(new Double(Math.abs(totalTaxAmount.doubleValue())),
                LEN_COST, PAD);
        record += BatchUtils.createFlatField(
                totalQuantity.doubleValue() > 0 ? EDIConstants.PLUS_SIGN : EDIConstants.MINUS_SIGN,
                LEN_IND, NOPAD);
        record += BatchUtils.createFlatField(new Double(Math.abs(totalQuantity.doubleValue())),
                LEN_QUANTITY, PAD);
        if (!isEdiDownload) {
            record += BatchUtils.createFlatField(
                    totalDiscount.doubleValue() > 0 ? EDIConstants.PLUS_SIGN
                            : EDIConstants.MINUS_SIGN, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(new Double(Math.abs(totalDiscount.doubleValue())),
                    LEN_TOTAL_DISCOUNT, PAD);
            record += BatchUtils.createFlatField(freightType, LEN_FREIGHT_TYPE, NOPAD);
            record += BatchUtils.createFlatField(manuallyPaidInd, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(multiLocation, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(merchType, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(dealId, LEN_DEAL_ID, PAD);
            record += BatchUtils.createFlatField(dealApprovalInd, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(rtvInd, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference1,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference2,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference3,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference4,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(crossReferenceDocumentNumber,
                    LEN_CROSS_REFERENCE_DOCUMENT_NUMBER, NOPAD);
        }

        return record;
    }

    /**
     * Method used to write the original transaction data with new line number and transaction
     * number. This is so that the reject file is numbered correctly and will pass validation.
     * 
     * @return original transaction line with new line and transaction numbers
     */
    public String renumberedRecord(long lineNumber, long tranNumber) {
        return (this.recordDescriptor
                + BatchUtils.createFlatField(Long.valueOf(lineNumber), LEN_LINE_ID, PAD)
                + BatchUtils.createFlatField(Long.valueOf(tranNumber), LEN_TRANSACTION_NUMBER, PAD) + originalRecord
                .substring(LEN_RECORD_DESCRIPTOR + LEN_LINE_ID + LEN_TRANSACTION_NUMBER));
    }

    public void run() {
        try {
            BatchUtils.start(EdiTransactionHeader.class, ediUploadArgs);
            Logger.info(EdiTransactionHeader.class, "transaction: " + this.transactionNumber);
            TransactionManagerFactory.getInstance().start();
            validateForUpload(true);
        } catch (ReIMException e) {
            uploadReporter.setSuccessfulTermination(false);

            try {
                backgroundQueue.put(this);
                TransactionManagerFactory.getInstance().rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } catch (Throwable t) {
            uploadReporter.setSuccessfulTermination(false);

            try {
                backgroundQueue.put(this);
                TransactionManagerFactory.getInstance().rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            t.printStackTrace();
        } finally {
            try {
                TransactionManagerFactory.getInstance().end();
            } catch (Exception e) {
                uploadReporter.setSuccessfulTermination(false);
                Logger.error(EdiTransactionHeader.class, e);
                try {
                    backgroundQueue.put(this);
                } catch (Exception ex) {
                    Logger.error(EdiTransactionHeader.class, ex);
                }
            }
        }
    }

    public EdiValidationResult validateForRetry(boolean allowDateBeforePostDatedDocDays)
            throws ReIMException {
        EdiValidationResult validateForRetryResult = VALIDATION_SUCCESS;

        if (this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
            validateForRetryResult = validateMerchandiseInvoiceDocument(false,
                    allowDateBeforePostDatedDocDays);
        } else {
            // should *never* get here, but we know how things can go....
            throw new ReIMException("error.edi.retry.doc_type_must_be_merch", Severity.FATAL, this);
        }

        if (validateForRetryResult.isSuccess()) {
            // add this to the good tables.....
            if (isMultiLocation()) {
                ServiceFactory.getParentInvoiceService().insertForMultiLocationInvoices(this);
            } else {
                ediDocBulk = new EdiDocBulk();
                ediDocBulk.setMaxDocumentCount(1);
                ServiceFactory.getEdiDocumentService().createEdiDocuments(this, ediDocBulk,
                            true);
                }

            // and remove the rejects that are now good...
            ServiceFactory.getEdiRejectService().deleteRejects(
                    new String[] { String.valueOf(this.documentId)});
        } else {
            // otherwise, create a reject document
            EdiRejectDocument ediRejectDocument = EdiTransactionHeaderValidationService
                    .createEdiRejectDocAndDetails(this, this.errorColumnId, this.rejectReason,
                            this.rejectedDocDetailId);

            // Update the existing records.
            ServiceFactory.getEdiRejectService().updateForEdiRejectDocHeadAndDocDetail(
                    ediRejectDocument);
        }

        return validateForRetryResult;
    }

    public void validateForUpload(boolean checkForFileRejections) throws ReIMException {

    	EdiValidationResult validationForUploadResult = VALIDATION_SUCCESS;

    	if (!this.isTransactionValid()) {
    		validationForUploadResult = FAILURE_REJECT_FILE;
    	}

    	validationForUploadResult = validateDocumentType(validationForUploadResult);

    	validationForUploadResult = validateVendorType(validationForUploadResult);

    	validationForUploadResult = validateDocument(validationForUploadResult, checkForFileRejections);

    	validationForUploadResult = validateUniqueVendorDocNumberPerFile(validationForUploadResult);

    	if(validationForUploadResult.isFailure()) {

    		//whenever we are dealing with vendor other than a supplier, any
    		// rejection must go to the reject file.
    		if (!this.vendorType.equals(Vendor.SUPPLIER)) {
    			validationForUploadResult = FAILURE_REJECT_FILE;
    		}

    		//if we are dealing with vendor other than a supplier, any rejection must go to the reject file.
    		//else if merch type is 'C' or rtv_ind is yes, any rejection must go to the reject file.

    		if (VendorType.isPartner(this.vendorType)) {
    			validationForUploadResult = FAILURE_REJECT_FILE;

    		} 
    		else if (MerchType.isConsignment(this.merchType) || (Affirm.check(this.rtvInd))) {
    			validationForUploadResult = FAILURE_REJECT_FILE;
    		}

    		// if we need to reject back to file, add this to the background queue
    		// else if we need to reject to the db, create the necessary object and pass into service
    		if (validationForUploadResult.getRejection().isFileBound()) {

    			addTransactionToQueue();

    			uploadReporter.setTransactionsRejectedToFile(true);
    		} else if (validationForUploadResult.getRejection().isTablesBound()) {

    			EdiRejectDocument ediRejectDocument = EdiTransactionHeaderValidationService
    			.createEdiRejectDocAndDetails(this, this.errorColumnId, this.rejectReason,
    					this.rejectedDocDetailId);

    			ServiceFactory.getEdiRejectService().insertForEdiRejectDocuments(ediRejectDocument);

    			uploadReporter.setTransactionsRejectedToDatabase(true);
    		}
    	}

    	// otherwise, this is completely valid and we can pass it into the
    	// service for insertion

    	else {
    		if (Affirm.check(this.multiLocation)) {
    			if (!ServiceFactory.getParentInvoiceService().checkForDuplicateExtDocId(
    					this.vendorDocumentNumber, this.vendorID)) {

    				ServiceFactory.getParentInvoiceService().insertForMultiLocationInvoices(this);

    			} else {
    				Logger.errorKey(EdiTransactionHeader.class,
    						"error.batch.vendor_doc_number_duplicate", new String[] {
    					EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentNumber,
    					String.valueOf(this.lineID+""),new String(this.orderNumber+""),new String(this.vendorDocumentNumber+"")});                    				

    				addTransactionToQueue();

    				uploadReporter.setTransactionsRejectedToFile(true);
    				uploadReporter.setTransactionsRejectedToDatabase(false);
    			}
    		} else {
    			ServiceFactory.getEdiDocumentService().createEdiDocuments(this, ediDocBulk, false);
    		}

    	}

    }

    protected void addTransactionToQueue() throws ReIMException {
        try {
            backgroundQueue.put(this);
        } catch (Throwable e) {
            throw new ReIMException("error.batch.unexpected_threading_error",
                    Severity.FATAL, this);
        }
    }
    
    protected EdiValidationResult validateDocument(EdiValidationResult previousValidation, boolean checkForFileRejections) throws ReIMException {

    	  EdiValidationResult currentValidation = previousValidation;
    	  
    	if (currentValidation.isSuccess()) {
            // validate the doc/transaction based on the doc type..
            // validate merch invoices
            if (this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
            	currentValidation = validateMerchandiseInvoiceDocument(
                        checkForFileRejections, false);

            	currentValidation = redirectValidation(currentValidation);
            }
            // validate non merch invoices
            else if (this.documentType.equals(Document.NON_MERCHANDISE_INVOICE)) {
            	currentValidation = validateNonMerchandiseInvoiceDocument(checkForFileRejections);
            }
            // validate credit notes
            else if (this.documentType.equals(Document.CREDIT_NOTE)) {
            	currentValidation = validateCreditNoteDocument(checkForFileRejections);

            	currentValidation = redirectValidation(currentValidation);
            }
            // validate debit memo (cost or quantity)
            else if (this.documentType.equals(Document.DEBIT_MEMO_PRICE)
                    || this.documentType.equals(Document.DEBIT_MEMO_QUANTITY)) {
            	currentValidation = validateDebitMemoDocument(checkForFileRejections);

            	currentValidation = redirectValidation(currentValidation);
            }
            // validate credit memo cost
            else if (this.documentType.equals(Document.CREDIT_MEMO_PRICE)) {
            	currentValidation = validateCreditMemoCostDocument(checkForFileRejections);

            	currentValidation = redirectValidation(currentValidation);
            }
            // validate crdit note requests (cost or quantity)
            else if (this.documentType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)
                    || this.documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
            	currentValidation = validateCreditNoteRequestDocument(checkForFileRejections);

            	currentValidation = redirectValidation(currentValidation);
            }
        }
    	
    	 return currentValidation;
    }

    protected EdiValidationResult validateVendorType(EdiValidationResult previousValidation) {
    	
        
        EdiValidationResult currentValidation = previousValidation;
        
        if(previousValidation.isSuccess()) {
        	
            boolean validVendorType = true;
            
            VendorType type = null;
            try {
                type = VendorType.fromCode(this.vendorType);
            } catch (Exception e) {
                validVendorType = false;
            }
            
            if(type!= null && type.isMerchSupplierLevel()) {
                validVendorType = false;    
            }
            
            if(!validVendorType) {
                String fieldName = ReIMI18NUtility.getMessage("label.vendor_type");
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                        fieldName, this.vendorType, String.valueOf(this.lineID)});
                
                currentValidation = FAILURE_REJECT_FILE;
            }
        
        
        }
        return currentValidation;
    
        
    
    }

	protected EdiValidationResult validateDocumentType(EdiValidationResult previousValidation) {
        
        EdiValidationResult currentValidation = previousValidation;
        
        if(previousValidation.isSuccess()) {
            if(!EDI_DOCUMENT_TYPES.contains(this.documentType)) {
                String fieldName = ReIMI18NUtility.getMessage("label.document_type");
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                        fieldName, this.documentType, String.valueOf(this.lineID)});
                
                currentValidation = FAILURE_REJECT_FILE;
            }
        }
        
        return currentValidation;
    }

	protected EdiValidationResult validateUniqueVendorDocNumberPerFile(EdiValidationResult previousValidation) throws ReIMException {
        
        EdiValidationResult currentValidation = previousValidation;
        
        if(previousValidation.isSuccess()) {            
            if(getEdiDocBulk().isDuplicateDocument(getDocumentType(), getVendor(), getVendorDocumentNumber())) {
                Logger.errorKey(EdiTransactionHeader.class,
                        "error.batch.vendor_doc_number_duplicate",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME,
                                this.vendorDocumentNumber,
                                String.valueOf(this.lineID + ""),
                                new String(this.orderNumber + ""),
                                new String(this.vendorDocumentNumber + "") });
                
                currentValidation = FAILURE_REJECT_FILE;
            }
        }
        
        return currentValidation;
    }
    
    public Vendor getVendor() throws ReIMException {
        Vendor vendor = ServiceFactory.getVendorService().getDocumentVendor(getVendorID(), VendorType.fromCode(getVendorType()));
        return vendor;
    }

	private EdiValidationResult redirectValidation(EdiValidationResult result) throws ReIMException {
        if (result.isFailure() && result.getRejection().isTablesBound()) {
            for (int i = 0; i < ediTransactionDetailList.length; i++) {
                EdiTransactionDetail detail = ediTransactionDetailList[i];
                if (!detail.getItem().equals("") && detail.isItemPassedFromFile()
                        && !ServiceFactory.getItemService().isValidItem(detail.getItem())) {
                    result = FAILURE_REJECT_FILE;
                    break;
                }
            }
        }
        return result;
    }

    public EdiValidationResult validateMerchandiseInvoiceDocument(boolean checkForFileRejections,
            boolean allowDateBeforePostDatedDocDays) throws ReIMException {
        // merch docs must come from a supplier and only a supplier
        if (checkForFileRejections) {
            if (!this.vendorType.equals(Vendor.SUPPLIER)) {
                Logger.errorKey(EdiTransactionHeader.class,
                        "error.batch.invalid_merch_doc_partner", new String[] { String
                                .valueOf(this.lineID)});
                return FAILURE_REJECT_FILE;
            }
        }

        // Do general file rejection validation
        if (checkForFileRejections) {
            EdiValidationResult validationResult = this.validateForFileRejection();
            if (validationResult.isFailure()) return validationResult;
        }

        // do general document validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections,
                allowDateBeforePostDatedDocDays);

    }

    public EdiValidationResult validateNonMerchandiseInvoiceDocument(boolean checkForFileRejections)
            throws ReIMException {

        /**
         * If the location is �-999999999� then the default location is fetched from the properties.
         */
        if (this.location != null && this.location.longValue() == EdiUploadProperties.NO_LOCATION) {
            this.location = EdiUploadProperties.DEFAULT_LOCATION;
            if (LocationService.validStore(this.location))
                this.locationType = Location.STORE;
            else if (LocationService.validWarehouse(this.location))
                this.locationType = Location.WAREHOUSE;
        }

        // non merch docs must have TNMRC records associated with them
        if (this.ediNonMerchDetailList == null || this.ediNonMerchDetailList.length == 0) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.non_merch_records_must_exist_for_non_merch_invoice",
                    new String[] { String.valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        // Do general file rejection validation
        if (checkForFileRejections) {
            EdiValidationResult fileRejectionValidationResult = validateForFileRejection();
            if (fileRejectionValidationResult.isFailure()) { return fileRejectionValidationResult; }
        }

        // non merch docs must have a total qty of zero (0)
        if (this.totalQuantity.doubleValue() != 0) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.non_merch_doc_must_have_total_qty_zero", new String[] { String
                            .valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        // non merch docs cannot have any TDETL records
        if (this.ediTransactionDetailList != null && this.ediTransactionDetailList.length != 0) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.non_merch_doc_cannot_have_detail_records", new String[] { String
                            .valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        // do general document validation
        EdiValidationResult nonFileRejectValidationResult = this
                .validateWithPrimaryRejectionToTables(checkForFileRejections, false);

        // non merch docs can only be good (inserted into the 'valid' document
        // tables...
        if (nonFileRejectValidationResult.isFailure()) {
            return nonFileRejectValidationResult;
        }
        // or they get rejected to file.
        else {
            return VALIDATION_SUCCESS;
        }
    }

    public EdiValidationResult validateCreditNoteDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only an initial upload will get here.

        EdiValidationResult creditNoteValidationResult = VALIDATION_SUCCESS;

        // Credit notes not associated with supplier, manufacturer, distributor,
        // or wholesaler must
        // not have detail information
        String vendorType = this.vendorType;
        if (!vendorType.equals(Vendor.SUPPLIER) && !vendorType.equals(Vendor.MERCH_SUPP_LEV_1)
                && !vendorType.equals(Vendor.MERCH_SUPP_LEV_2)
                && !vendorType.equals(Vendor.MERCH_SUPP_LEV_3)) {
            if (this.ediTransactionDetailList.length > 0) {
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.no_detail_information",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME, vendorType,
                                String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                String.valueOf(this.vendorDocumentNumber + "")});
                return FAILURE_REJECT_FILE;
            }
        }

        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // credit note documents must have a negative total cost value
        if (this.totalCost.doubleValue() >= 0) {
            Logger
                    .errorKey(EdiTransactionHeader.class,
                            "error.batch.credit_note_doc_total_cost_must_be_negative",
                            new String[] { String.valueOf(this.lineID),
                                    String.valueOf(this.vendorDocumentNumber)});
            return FAILURE_REJECT_FILE;
        }

        // credit note documents that have details must not have
        // any allowances and thus a total allowance of zero
        if (this.ediTransactionDetailList != null && this.ediTransactionDetailList.length > 0) {
            int listLength = this.ediTransactionDetailList.length;

            for (int i = 0; i < listLength; i++) {
                if (this.ediTransactionDetailList[i].getTotalAllowance() != 0
                        || (this.ediTransactionDetailList[i].getEdiDetailAllowanceList() != null && this.ediTransactionDetailList[i]
                                .getEdiDetailAllowanceList().length != 0)) {
                    Logger
                            .errorKey(
                                    EdiTransactionHeader.class,
                                    "error.batch.credit_note_doc_total_allowance_must_be_zero_with_no_tallw_recs",
                                    new String[] { EDI_UPLOAD_PROGRAM_NAME,
                                            String.valueOf(this.lineID),
                                            String.valueOf(this.orderNumber + ""),
                                            String.valueOf(this.vendorDocumentNumber + "")});
                    return FAILURE_REJECT_FILE;
                }
            }
        }

        // non merch records associated with a credit note need to have a
        // negative amt value
        if (this.ediNonMerchDetailList != null && this.ediNonMerchDetailList.length > 0) {
            int listLength = this.ediNonMerchDetailList.length;

            for (int i = 0; i < listLength; i++) {
                EdiValidationResult validationResult = this.ediNonMerchDetailList[i]
                        .validateForCreditNote();
                if (validationResult.isFailure()) { return validationResult; }
            }
        }

        // do general document validation
        creditNoteValidationResult = this.validateWithPrimaryRejectionToTables(
                checkForFileRejections, false);

        // credit notes can only be good (inserted into the 'valid' document
        // tables)...
        if (creditNoteValidationResult.isFailure()) {
            return FAILURE_REJECT_FILE;
        }
        // or they get rejected to file.
        else {
            return VALIDATION_SUCCESS;
        }
    }

    public EdiValidationResult validateCreditNoteRequestDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only
        // an initial upload will get here.
        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // do general document(table) validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections, false);
    }

    public EdiValidationResult validateDebitMemoDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only
        // an initial upload will get here.
        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // must have a negative total cost value
        if (this.totalCost.doubleValue() >= 0) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.debit_memo_doc_total_cost_must_be_negative", new String[] {
                            EDI_UPLOAD_PROGRAM_NAME, this.totalCost.toString(),
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});
            return FAILURE_REJECT_FILE;
        }

        // do general document(table) validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections, false);
    }

    public EdiValidationResult validateCreditMemoCostDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only
        // an initial upload will get here.
        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // do general document(table) validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections, false);
    }

    public EdiValidationResult validateForFileRejection() throws ReIMException {
        SupplierGroup supplierGroup = null;
        // String vendorId = null;

        if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
            // Total Quantity: if it is null and total header quantity indicator
            // is checked, invalid
            try {
                Long.parseLong(this.vendorID);
                supplierGroup = ServiceFactory.getSupplierGroupService().getSupplierGroup(
                        this.vendorID);
            } catch (NumberFormatException e) {
                supplierGroup = null;
            }
        }

        setSupplierSiteEnabled(ServiceFactory.getSystemOptionsService().getSystemOptions()
                .isSupplierSiteInd());
        String fieldName = "";
        ReIMSystemOptions systemOptions = ServiceFactory.getReIMSystemOptionsService().select();
        // validate Order no.
        // If the vendor is a supplier, and the document type is not
        // non-merchandise invoice, order number must be provided
        if (this.vendorType.equals(Vendor.SUPPLIER) && this.orderNumber == null
                && (!this.documentType.equals(Document.NON_MERCHANDISE_INVOICE))) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.order_no_required_for_merch_inv", new String[] {
                            EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        // reject to file if order/RTV order number exists and vendor type is
        // NOT a supplier
        if (!this.vendorType.equals(Vendor.SUPPLIER) && this.orderNumber != null) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.order_no_must_be_null_when_not_a_supplier", new String[] {
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});
            return FAILURE_REJECT_FILE;
        }

        if (!this.locationType.equals(Location.WAREHOUSE)
                && !this.locationType.equals(Location.STORE)) {
            String field = ReIMI18NUtility.getMessage("batch.field.location_type");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    field, String.valueOf(this.location), String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber + "")});
            return FAILURE_REJECT_FILE;
        }

        if (this.dueDate != null && this.dueDate.before(this.vendorDocumentDate)) {
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.due_date_invalid",
                    new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentDate.toString(),
                            this.dueDate.toString(), String.valueOf(this.lineID),
                            String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});
            return FAILURE_REJECT_FILE;
        }

        if (!ServiceFactory.getCurrencyService().validateCurrency(this.currencyCode)) {
            fieldName = ReIMI18NUtility.getMessage("label.currency_code");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.currencyCode, String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber + "")});
            return FAILURE_REJECT_FILE;
        }

        // verify that the invoice currency matches the order's currency
        // if an order is given
        // now defensive as CurrencyService.getCurrencyCodeByOrder can
        // return a null if the order number is invalid but we still
        // want to import the it
        if (this.orderNumber != null) {
            String curr = "";
            if (this.rtvInd.equals("Y")) {
                String vendorId = ServiceFactory.getRtvService().getVendorFromOrder(
                        this.orderNumber.toString());
                curr = ServiceFactory.getCurrencyService().getCurrencyCodeByVendor(this.vendorType,
                        vendorId);
            } else {
                curr = ServiceFactory.getCurrencyService().getCurrencyCodeByOrderNo(
                        this.orderNumber.longValue());
            }

            if (curr != null) // is the order # valid?
            {
                if (this.orderNumber != null && !curr.equals(this.currencyCode)) {
                    Logger.errorKey(EdiTransactionHeader.class,
                            "error.batch.invoice_currency_code_not_match_order", new String[] {
                                    this.currencyCode, this.orderNumber.toString(),
                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                    String.valueOf(this.vendorDocumentNumber + "")});
                    return FAILURE_REJECT_FILE;
                }
            }
        }

        if (this.freightType != null
                && !this.freightType.equals(ReIMConstants.EMPTY_STRING)
                && !ServiceFactory.getCodeDetailService().checkValidCode(this.freightType,
                        Document.FREIGHT_TYPES_CODE))
            if (!ServiceFactory.getCodeDetailService().checkValidCode(this.freightType,
                    Document.FREIGHT_TYPES_CODE)) {
                fieldName = ReIMI18NUtility.getMessage("label.freight_type");
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                        new String[] { fieldName, this.freightType, String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""),
                    String.valueOf(this.vendorDocumentNumber)});
                return FAILURE_REJECT_FILE;
            }

        if (!EDIConstants.YES_NO_INDICATORS.contains(manuallyPaidInd)) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.paid_ind");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.manuallyPaidInd, String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber)});
            return FAILURE_REJECT_FILE;
        }

        if (!EDIConstants.YES_NO_INDICATORS.contains(multiLocation)) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.multi_loc");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.multiLocation, String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber)});
            return FAILURE_REJECT_FILE;
        }

        if (this.multiLocation.equals(ReIMConstants.YES)
                && (nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT))) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.multi_loc");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.multiLocation, String.valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        if (!EDIConstants.EDI_MERCH_TYPES.contains(merchType)
                && (merchType != null && merchType.length() != 0)) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.merch_type");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.merchType, String.valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        if (!EDIConstants.YES_NO_INDICATORS.contains(rtvInd)) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.rtv_ind");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.rtvInd, String.valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        // validate non merch detail
        if (this.ediNonMerchDetailList != null && this.ediNonMerchDetailList.length != 0) {
            int listLength = ediNonMerchDetailList.length;

            for (int i = 0; i < listLength; i++) {
                Set<Tax> ediNonMerchTaxes = ediNonMerchDetailList[i].getEdiNonMerchTaxes();

                if (ediNonMerchDetailList[i].validateWithPrimaryRejectionToFile(this).isFailure()) { return FAILURE_REJECT_FILE; }

                this.setDetailControlTotalCostSum(this.detailControlTotalCostSum.add(
                        new BigDecimal(ediNonMerchDetailList[i].getNonMerchandiseAmount()))
                        .doubleValue());
                // getting multiple taxes for the document
                for (Tax ediNonMerchTax : ediNonMerchTaxes) {

                    this.setTotalTaxAmountFromDetails(this.totalTaxAmountFromDetails
                            .add(
                                    new BigDecimal((ediNonMerchDetailList[i]
                                            .getNonMerchandiseAmount() * ediNonMerchTax
                                            .getTaxRate()) / 100.0)).doubleValue());
                }

            }
        }

        // validate tax detail
        if (this.ediTaxDetailList != null && this.ediTaxDetailList.length != 0) {
            int listLength = ediTaxDetailList.length;

            for (int i = 0; i < listLength; i++) {

                this.setTotalTaxAmountFromTTAXS(this.totalTaxAmountFromTTAXS.add(
                        new BigDecimal((ediTaxDetailList[i].getTaxBasis() * ediTaxDetailList[i]
                                .getTaxRate()) / 100.0)).doubleValue());

            }
        }

        if (this.vendorType.equals(Vendor.SUPPLIER)) {
            // if dealing with a supplier, the vendorID has to be completely
            // numeric
            try {
                Long.parseLong(this.vendorID);
            } catch (NumberFormatException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorID,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR;
                return FAILURE_REJECT_TABLES;
            }
        }

        // If the vendor is different than the one in the order, reject the
        // invoice.
        /*
         * Should be un-commented when the supplier site fix if forward ported from 13.0.2
         */
        if (this.orderNumber != null) {

            /*
             * vendorId corresponding to the order would be supplier in SupplierSite OFF and
             * supplier site in SupplierSite ON.
             */
            String orderVendor = null;
            if (!this.rtvInd.equalsIgnoreCase(Affirm.YES_IND)) {
                orderVendor = ServiceFactory.getOrderService().getVendorFromOrder(
                        this.orderNumber.toString());
                fieldName = ReIMI18NUtility.getMessage("label.order_number");
            } else if (this.rtvInd.equalsIgnoreCase(Affirm.YES_IND)) {
                orderVendor = ServiceFactory.getRtvService().getVendorFromOrder(
                        this.orderNumber.toString());
                fieldName = ReIMI18NUtility.getMessage("label.rtv_order_no");
            }
            
            if(orderVendor == null){
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                        fieldName, this.orderNumber.toString(), String.valueOf(this.lineID),
                        String.valueOf(this.orderNumber), this.vendorDocumentNumber});
                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ORDER_NO;
                this.rejectReason = EdiRejectReasons.INVALID_ORDER_NO;
                return FAILURE_REJECT_TABLES;
            }

        }
        boolean totalHeaderQtyReqInd = supplierGroup != null ? supplierGroup
                .isTotalHeaderQuantityRequired() : ReimProperties.DOCUMENT_HEADER_QUANTITY_REQUIRED;

        if (ediTransactionDetailList != null && this.ediTransactionDetailList.length != 0) {
            Set<String> itemSet = new HashSet<String>();
            int listLength = this.ediTransactionDetailList.length;

            boolean isItemSupplied = false;

            BigDecimal originalUnitCost = new BigDecimal(0);
            BigDecimal originalDocumentQuantity = new BigDecimal(0);

            for (int i = 0; i < listLength; i++) {
                if (!ediTransactionDetailList[i].getItem().equals("")) isItemSupplied = true;
                EdiValidationResult validationResult = ediTransactionDetailList[i]
                        .validateWithPrimaryRejectionToFile(this.vendorType, this.vendorID,
                                this.location, this.documentType, this);
                if (validationResult.isFailure()) { return validationResult; }

                // Check for duplicate items for the document. If the item is
                // duplicated, then this
                // item is invalid. If the item is not duplicated, add it to the
                // hashset for future
                // item duplication checks.
                String itemId = ediTransactionDetailList[i].getItem();
                if (this.getMerchType() == null || this.getMerchType().equals("")
                        || !nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {

                    if (itemId != null && !itemId.equals("")) {
                        if (isItemSupplied && itemSet.contains(itemId)) {
                        // temp change done by naveen
                        	/*Logger
                                    .errorKey(EdiTransactionHeader.class,
                                            "error.batch.duplicate_item", new String[] {
                                                    EDI_UPLOAD_PROGRAM_NAME,
                                                    ediTransactionDetailList[i].getItem(),
                                                    String.valueOf(ediTransactionDetailList[i]
                                                            .getLineID())});
                            return FAILURE_REJECT_FILE;*/
                        //temp change done by naveen
                        } else {
                            itemSet.add(ediTransactionDetailList[i].getItem());
                        }
                    }
                }

                // Maintain the sum of costs and quantities for comparison with
                // the control total for the entire document.
                originalUnitCost = new BigDecimal(ediTransactionDetailList[i].getOriginalUnitCost());
                originalUnitCost = originalUnitCost.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
                originalDocumentQuantity = new BigDecimal(ediTransactionDetailList[i]
                        .getOriginalDocumentQuantity());
                originalDocumentQuantity = originalDocumentQuantity.setScale(PRECISION4,
                        BigDecimal.ROUND_HALF_UP);
                this.setDetailControlTotalCostSum(this.detailControlTotalCostSum.add(
                        originalUnitCost.multiply(originalDocumentQuantity)).doubleValue());
                this.setDetailControlTotalQuantitySum(this.detailControlTotalQuantitySum.add(
                        originalDocumentQuantity).doubleValue());

                for (Tax ediItemTax : ediTransactionDetailList[i].getEdiItemTaxes()) {
                    this.setTotalTaxAmountFromDetails(this.totalTaxAmountFromDetails.add(
                            (new BigDecimal(ediTransactionDetailList[i]
                                    .getOriginalDocumentQuantity()
                                    * ediTransactionDetailList[i].getOriginalUnitCost()
                                    * ediItemTax.getTaxRate() / 100.0))).doubleValue());
                }

                // go through allowance inside the detail
                if (this.ediTransactionDetailList[i].getEdiDetailAllowanceList() != null
                        && this.ediTransactionDetailList[i].getEdiDetailAllowanceList().length != 0) {
                    EdiDetailAllowance[] allowanceList = this.ediTransactionDetailList[i]
                            .getEdiDetailAllowanceList();

                    for (int j = 0; j < allowanceList.length; j++) {
                        Set<Tax> allowanceTaxes = allowanceList[j].getEdiItemAllowanceTaxes();
                        for (Tax edItemAllowanceTax : allowanceTaxes) {
                            this
                                    .setTotalTaxAmountFromDetails(this.totalTaxAmountFromDetails
                                            .add(
                                                    new BigDecimal(
                                                            (allowanceList[j].getAllowanceAmount() * edItemAllowanceTax
                                                                    .getTaxRate()) / 100.0))
                                            .doubleValue());
                        }

                    }

                }

            } // end loop through transaction details
        } else {
            // Details required for zero dollar merchandise invoices
            if (this.documentType.equals(Document.MERCHANDISE_INVOICE)
                    && this.totalCost.doubleValue() == 0) {
                fieldName = "error.batch.zero_dollar_invoice_details_required";
                Logger.errorKey(EdiTransactionHeader.class, fieldName, new String[] {
                        EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID)});
                return FAILURE_REJECT_FILE;
            }
        }
        // Moved areValuesWithinTolerance method to NumberUtils class
        // verify the sum of costs from TDETL and TNMRC match with THEAD
        if (!NumberUtils.areValuesWithinTolerance(this.totalCost, this.detailControlTotalCostSum,
                systemOptions.getCalcTolerance(), systemOptions.getCalcToleranceInd())) {
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.total_costs_not_match",
                    new String[] { String.valueOf(this.totalCost),
                            String.valueOf(this.detailControlTotalCostSum),
                            String.valueOf(this.lineID)});
            return FAILURE_REJECT_FILE;
        }

        // Verify if the Total Quantity is a whole number or not
        if (ReIMUserContext.getQuantityDecimalsAllowed() == 0
                && !this.totalQuantity.toString().equals(
                        this.totalQuantity.toBigInteger().toString())) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.total_quantity");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.quantity_eaches",
                    new String[] { fieldName, this.totalQuantity.toString(),
                            String.valueOf(this.lineID), fieldName});

            return FAILURE_REJECT_FILE;
        }

        if (totalHeaderQtyReqInd
                && !NumberUtils.areValuesWithinTolerance(this.totalQuantity,
                        this.detailControlTotalQuantitySum, systemOptions.getCalcTolerance(),
                        systemOptions.getCalcToleranceInd())) {
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.total_qtys_not_match",
                    new String[] { String.valueOf(this.totalQuantity),
                            String.valueOf(this.detailControlTotalQuantitySum),
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});
            return FAILURE_REJECT_FILE;
        }

        // The below checks don't follow the file-rejection/table-rejection
        // break up completely....
        // These checks go both ways - the possibility of rejecting to tables at
        // this point is needed
        // to completely validate possible file-rejection stuff....

        Vendor vendor = ServiceFactory.getVendorService().getVendor(this.vendorType, this.vendorID);
        
        if (vendor.getVendorId() != null && vendor.getVendorId().equals(this.vendorID)) {
            String vendorDocNumber=null;
            String extDoc =ServiceFactory.getDocumentService().getDocumentIdPrefix(this.documentType);
            if (extDoc != null) {
                vendorDocNumber=(extDoc + this.vendorDocumentNumber);
            } else {
                vendorDocNumber= this.vendorDocumentNumber;
            }
            
            // version 1.1 Changes done by Naveen J
        	//--------------Internal Patch---------------starts----------
            //old code starts
          /*  if (vendorDocNumber.equalsIgnoreCase(ServiceFactory.getDocumentService().getExtDocIdByVendor(
                    this.vendorType, this.vendorID, vendorDocNumber))) { */
            //old code ends 
           //new code starts
            String vendorDocNumberFromDb=ServiceFactory.getDocumentService().getExtDocIdByVendor(this.vendorType, this.vendorID, vendorDocNumber);
            if (vendorDocNumber.trim().equalsIgnoreCase(
            		vendorDocNumberFromDb!= null ? vendorDocNumberFromDb.trim():vendorDocNumberFromDb)) {
            //new code ends	
                fieldName = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
                Logger.errorKey(EdiTransactionHeader.class,
                        "error.batch.vendor_doc_number_duplicate", new String[] {
                                EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentNumber,
                                String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                String.valueOf(this.vendorDocumentNumber + "")});
                return FAILURE_REJECT_FILE;
            } else {
                this.vendorDocumentNumber = this.vendorDocumentNumber.toUpperCase(UserContext
                        .getLocale());
            }
        }
        // the vendor number passed in is not valid for the system, this
        // trasaction will be
        // rejected to the database to allow the user to enter the correct
        // vendor number.
        // This means that the vendor document number has not been validated yet
        // - this will be
        // taken care of by the 'retry' logic before it actually does the retry.
        else {
            fieldName = ReIMI18NUtility.getMessage("batch.field.vendor_id");
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.vendorID, String.valueOf(this.lineID),
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                    String.valueOf(this.vendorDocumentNumber + "")});

            if (this.vendorType.equals(Vendor.SUPPLIER)) {
                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR;

                return FAILURE_REJECT_TABLES;
            } else {
                return FAILURE_REJECT_FILE;
            }
        }

        /*
         * Code is commented to fix the integration defect 75. Order Number received in the EDI file
         * can be null for the non-merchandise invoice sent from RMS. So, there is a possibility of
         * NullPointerException. Moreover, vendorId populated using the commented statement is used
         * only inside the next 'if' block and hence moving the statement inside the 'if' block
         * which has the check for (orderNumber != null). vendorId =
         * ServiceFactory.getOrderService().getVendorFromOrder(this.orderNumber.toString());
         */

        // If (RTV) order number is not null and RTV flag is 'Y', validate it
        // for the vendor
        if (this.orderNumber != null && this.rtvInd.equals(ReIMConstants.YES)) {
            // vendorId =
            // ServiceFactory.getOrderService().getVendorFromOrder(this.orderNumber.toString());
            // if
            // (!ServiceFactory.getRtvService().validateRtvOrderCheckingLinkedSuppliers(
            // this.orderNumber, vendorId)) {
            /*
             * Once the fix is done in RMS, this.vendorID will always have supplier_parent value.
             * validateRtvOrderCheckingLinkedSuppliers method checks whether matching record exist
             * in RTV_HEAD table for RTV_ORDER_NO and SUPPLIER_PARENT which is not true in case of
             * supplier site indicator ON environment.
             * 
             * For example in the supplier site environment RTV_HEAD table (Supplier will be the
             * supplier site) @@@@@@@@@@@@@@@@@@@@@@@ @ RTV_ORDER_NO/SUPPLIER@ @ 1560006/2900
             * 
             * @@@@@@@@@@@@@@@@@@@@@@@@
             * 
             * this.VendorID is 8000 (supplier parent). validateRtvOrderCheckingLinkedSuppliers will
             * check for the entry (1560006/8000) (RTV_ORDER_NO/SUPPLIER) in RTV_HEAD table and
             * hence the validation fails.
             */
            if (!ServiceFactory.getRtvService().validateRtvOrderCheckingLinkedSuppliers(
                    this.orderNumber, this.vendorID)) {
                fieldName = ReIMI18NUtility.getMessage("label.rtv_order_no");
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                        new String[] { fieldName, this.orderNumber.toString(),
                                String.valueOf(this.lineID)});

                return FAILURE_REJECT_FILE;
            }

            // validate location. Order/Location combination must exist on
            // ordloc
            if (!ServiceFactory.getRtvService().validateOrderLoc(this.location, this.orderNumber)) {
                fieldName = ReIMI18NUtility.getMessage("label.order_location");
                String locType = null;
                if (this.locationType.equals(Location.STORE))
                    locType = ReIMI18NUtility.getMessage("label.store");
                else
                    locType = ReIMI18NUtility.getMessage("label.warehouse");
                Logger.errorKey(EdiTransactionHeader.class,
                        "error.batch.invalid_rtv_order_location", new String[] {
                                EDI_UPLOAD_PROGRAM_NAME, locType, this.location.toString(),
                                this.orderNumber.toString(), String.valueOf(this.lineID)});

                return FAILURE_REJECT_FILE;
            }
        } // end if (orderNumber != null)

        // }

        // ********************************************************************************
        // Thead.Total TAx Amount = total tax from TDETL + total tax from TNMRC
        // + total tax from TALLW
        // Thead.Total TAX Amount = sum(TTAXS.TAX rate * TTAXS.cost at this TAX
        // code)
        // ********************************************************************************
        totalTaxAmount.setScale(4, BigDecimal.ROUND_HALF_UP);
        totalTaxAmountFromTTAXS.setScale(4, BigDecimal.ROUND_HALF_UP);
        if (!NumberUtils.areValuesWithinTolerance(totalTaxAmount, totalTaxAmountFromTTAXS,
                systemOptions.getCalcTolerance(), systemOptions.getCalcToleranceInd())
                && systemOptions.isProcessTaxes()) {
            Logger.errorKey(EdiTransactionHeader.class,
                    "error.batch.header_tax_amount_does_not_match_tax_breakdown");
            return FAILURE_REJECT_FILE;
        }

        this.totalTaxAmount = this.totalTaxAmount.setScale(4, BigDecimal.ROUND_HALF_UP);

        if (!NumberUtils.areValuesWithinTolerance(this.totalTaxAmount,
                this.totalTaxAmountFromDetails, systemOptions.getCalcTolerance(), systemOptions
                        .getCalcToleranceInd())) {
            Logger.errorKey(EdiTransactionHeader.class, "error.batch.total_tax_amount_not_match");
            return FAILURE_REJECT_FILE;
        }

        return VALIDATION_SUCCESS;
    }

    private boolean validateLinkedSupplier(String supplierIdInFile, String orderVendor, SupplierGroup supplierGroup) throws ReIMException {
		
    	boolean vendorSameGroup = false;

        
        //in case this.vendorID represents supplier parent supplierParentForDocVendor will be null
        String supplierParentForDocVendor = ServiceFactory.getVendorService().getSupplierParent(supplierIdInFile);
        
        String supplierParentForOrderVendor = ServiceFactory.getVendorService().getSupplierParent(orderVendor);
        
//      get the supplier option for the vendor
        boolean matchToLinkedSupplier = false;
        
        //If supplierParentForDocVendor is null then the parent supplier is provided in EDI record else supplier site is provided.
        
        if (!StringUtils.isBlank(supplierParentForDocVendor)) 
        {
        	documentSupplierParent=supplierParentForDocVendor;
        	
        	 setFileSupplierSiteInd(true);
             setSupplierSiteID(supplierIdInFile);
        }
        else
        {
        	documentSupplierParent=	supplierIdInFile;
        	
        	setFileSupplierSiteInd(false);
            setSupplierSiteID(null);
        }

        //If supplierParentForOrderVendor is null then the order is on parent supplier else order is on  supplier site.
        
        if(!StringUtils.isBlank(supplierParentForOrderVendor))
    	{
        	orderSupplierParent=supplierParentForOrderVendor;
    	}
        else
        {
        	orderSupplierParent=orderVendor;
        }
        
        /*  
         * If the Supplier in EDI is not same as order supplier but belong to the Same group as of order supplier and 
         * if the "Match invoices to Receipts from other Suppliers" for Supplier in EDI file is 'Y', 
         * then we can create the Invoice for EDI Supplier even if the Order is on differnt supplier.
         * 
         *  */
   	
    	
    	//check if the supplier belong to the same supplier group.
    	if(!documentSupplierParent.equals(orderSupplierParent))
    	{
             
             if (supplierGroup != null && supplierGroup.getSuppliers() != null) {
                 for (String supplier : supplierGroup.getSupplierIds()) {
                     if (supplier != null && supplier.equalsIgnoreCase(orderSupplierParent)) {
                         vendorSameGroup = true;
                         break;
                     }
                 }
             }
             
             if(vendorSameGroup)
             {
            	 SupplierOptions supplierOptions = ServiceFactory.getSupplierOptionsService().select(documentSupplierParent);

            	 if (supplierOptions != null) {
            		 matchToLinkedSupplier = supplierOptions.isMatchInvoicesToRcpts();
            	 }
            	 
            	 if(!matchToLinkedSupplier)
             	{
             		vendorSameGroup=false;
             	}
            	 
             }
    	}
    	else
    	{
    		vendorSameGroup=true;
    	}
       
    	
    
		return vendorSameGroup;
	}

	public EdiValidationResult validateTaxWithPrimaryRejectionToFile() throws ReIMException {

        // ***********************************************************************************
        // validate if system_option.tax = on && not import doc && TTAXS = null
        // --> reject to file
        // ***********************************************************************************
        try {
            EdiValidationResult ediValidationResult = null;
            BigDecimal totalCostIncTaxes = this.totalCost.add(this.totalTaxAmount);
            long locTaxRegion = -1L;

            if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
                locTaxRegion = DaoFactory.getLocationBean().getTaxRegion(
                        String.valueOf(this.location));

                long supplierTaxRegion = -1L;

                supplierTaxRegion = DaoFactory.getSupplierBean().getTaxRegion(this.vendorID);

                if ((locTaxRegion == supplierTaxRegion)
                        && ReIMSystemOptions.getInstance().isProcessTaxes()) {
                    if (this.ediTaxDetailList == null || this.ediTaxDetailList.length == 0) {
                        Logger.errorKey(EdiTransactionHeader.class,
                                "error.batch.tax_detail_is_required");
                        return FAILURE_REJECT_FILE;
                    }
                }
            } else {
                locTaxRegion = DaoFactory.getLocationBean().getTaxRegion(
                        String.valueOf(this.location));
                long partnerTaxRegion = -1L;

                PartnerBean partnerBean = new PartnerBean();
                partnerTaxRegion = partnerBean.getPartnerTaxRegion(this.vendorID);
                if ((locTaxRegion == partnerTaxRegion)
                        && ReIMSystemOptions.getInstance().isProcessTaxes()) {
                    if (this.ediTaxDetailList == null || this.ediTaxDetailList.length == 0) {
                        Logger.errorKey(EdiTransactionHeader.class,
                                "error.batch.tax_detail_is_required");
                        return FAILURE_REJECT_FILE;
                    }
                }
            }

            NonMerchandiseDocument[] nonMerchandiseDocs = null;
            Tax[] taxes = null;
            DocumentItem[] docItems = null;

            if (this.ediNonMerchDetailList != null && this.ediNonMerchDetailList.length > 0) {
                int nonMerchListLength = this.ediNonMerchDetailList.length;
                nonMerchandiseDocs = new NonMerchandiseDocument[nonMerchListLength];
                for (int k = 0; k < nonMerchListLength; k++) {
                    ediValidationResult = this.ediNonMerchDetailList[k]
                            .validateTaxWithPrimaryRejectionToFile(this);
                    if (ediValidationResult.isFailure()) { return FAILURE_REJECT_FILE; }
                    NonMerchandiseDocument nonMerchDoc = new NonMerchandiseDocument();
                    nonMerchDoc.setNonMerchCode(this.ediNonMerchDetailList[k]
                            .getNonMerchandiseCode());
                    double nonMerchAmount = this.ediNonMerchDetailList[k].getNonMerchandiseAmount();
                    nonMerchDoc.setNonMerchAmt(nonMerchAmount);
                    Set<Tax> ediNonMerchTaxes = this.ediNonMerchDetailList[k].getEdiNonMerchTaxes();
                    for (Tax ediNonMerchTax : ediNonMerchTaxes) {
                        nonMerchDoc.addNonMerchTax(new Tax(ediNonMerchTax.getTaxCode(),
                                ediNonMerchTax.getTaxRate(), nonMerchAmount));
                        ediNonMerchTax.setTaxBasis(nonMerchAmount);
                    }
                    nonMerchandiseDocs[k] = nonMerchDoc;
                }
            }

            if (this.ediTaxDetailList != null && this.ediTaxDetailList.length > 0) {
                int taxsLength = this.ediTaxDetailList.length;
                taxes = new Tax[taxsLength];

                for (int m = 0; m < taxsLength; m++) {
                    ediValidationResult = this.ediTaxDetailList[m]
                            .validateTaxWithPrimaryRejectionToFile(this);
                    if (ediValidationResult.isFailure()) { return FAILURE_REJECT_FILE; }
                    Tax tax = new Tax(this.ediTaxDetailList[m].getTaxCode(),
                            this.ediTaxDetailList[m].getTaxRate());
                    tax.setTaxBasis(this.ediTaxDetailList[m].getTaxBasis());
                    taxes[m] = tax;
                }

            }
            if (this.ediTransactionDetailList != null && this.ediTransactionDetailList.length > 0) {
                int detailLength = this.ediTransactionDetailList.length;
                docItems = new DocumentItem[detailLength];
                for (int n = 0; n < detailLength; n++) {
                    DocumentItem docItem = new DocumentItem();
                    docItem.setUnitCost(this.ediTransactionDetailList[n].getOriginalUnitCost());
                    docItem.setQty(this.ediTransactionDetailList[n].getOriginalDocumentQuantity());
                    Set<Tax> ediItemTaxes = this.ediTransactionDetailList[n].getEdiItemTaxes();
                    docItem.setTaxes(ediItemTaxes);
                    // /
                    docItems[n] = docItem;
                }
            }
            int orderNo = 0;
            if (this.orderNumber != null) {
                orderNo = this.orderNumber.intValue();
            }
            long locId = 0;
            if (this.location != null) {
                locId = this.location.longValue();
            }
            if (ReIMSystemOptions.getInstance().isProcessTaxes()
                    && vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
            	
            	String vendor= this.vendorID; 

            	
                if (this.supplierSiteEnabled && this.supplierSiteID != null && this.supplierSiteID.length() != 0 && !vendor.equalsIgnoreCase(this.supplierIdInFile)) {
                	
                	vendor=this.supplierIdInFile;
    			}
                
                ServiceFactory.getTaxService().validateTaxTotals(this.totalCost.doubleValue(),
                        this.totalTaxAmount.doubleValue(), totalCostIncTaxes.doubleValue(),
                        nonMerchandiseDocs, taxes, orderNo, locId, docItems, vendor, false,
                        this.documentType, vendorType);
            }
            if (this.ediTransactionDetailList != null) {
                for (EdiTransactionDetail ediTransactionDetail : this.ediTransactionDetailList) {
                    ediValidationResult = ediTransactionDetail
                            .validateTaxWithPrimaryRejectionToFile(vendorType, this.vendorID,
                                    location, documentType, this);
                    if (ediValidationResult.isFailure()) { return FAILURE_REJECT_FILE; }
                    EdiDetailAllowance[] ediDetailAllowances = ediTransactionDetail
                            .getEdiDetailAllowanceList();
                    if (ediDetailAllowances != null) {
                        for (EdiDetailAllowance ediDetailAllowance : ediDetailAllowances) {
                            ediValidationResult = ediDetailAllowance
                                    .validateTaxWithPrimaryRejectionToFile(this);
                            if (ediValidationResult.isFailure()) { return FAILURE_REJECT_FILE; }
                        }
                    }
                }
            }

        } catch (Exception e) {
            return FAILURE_REJECT_FILE;
        }
        return VALIDATION_SUCCESS;

    }

    // this method is actually conducting table reject transaction validation.
    public EdiValidationResult validateWithPrimaryRejectionToTables(boolean checkForFileRejections,
            boolean allowDateBeforePostDatedDocDays) throws ReIMException {
        String fieldName = null;
        String defaultVendorTerms = null;
        String vendorId = null;
        Object[] termValidationResults = new Object[3];
        int postDatedDocDays = EdiTransactionHeaderValidationService.getPostDatedDocDays();

        ReIMDate vDate = new ReIMDate();
        if (ApplicationContext.isBatchApplication()) {
            vDate = ServiceFactory.getPeriodService().getVDate();
        } else {
            vDate = ServiceFactory.getPeriodService().getScreenVDate();
        }
        ReIMDate validMinDate = new ReIMDate(vDate.addDays(-postDatedDocDays, vDate));

        // this validation happens in the validateForFileRejection method (call
        // to
        // VendorService.getVendor() and Long.parseLong(this.vendorID) ), but
        // needs
        // to happen here as well for 'retrying' a document through the gui.
        if (this.vendorType.equals(Vendor.SUPPLIER)) {
            try {
                Long.parseLong(this.vendorID);
            } catch (NumberFormatException e) {
                if (checkForFileRejections) {
                    String key = "error.batch.invalid_number_format";
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorID,
                            String.valueOf(this.lineID)};
                    Logger.errorKey(EdiTransactionHeader.class, key, parameters);
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR;

                return FAILURE_REJECT_TABLES;
            }

            if (this.orderNumber != null) {
                // vendorId =
                // ServiceFactory.getOrderService().getVendorFromOrder(
                // this.orderNumber.toString());
                // ValidateVendorId returns default terms which are required for
                // all
                // vendors and this value is saved for defaulting purposes
                if (isSupplierSiteEnabled() && StringUtils.isNotBlank(this.supplierSiteID)) {
                    defaultVendorTerms = ServiceFactory.getVendorService().getVendor(
                            this.vendorType, this.supplierSiteID).getVendorTerms();
                } else {
                    defaultVendorTerms = ServiceFactory.getVendorService().getVendor(
                            this.vendorType, this.vendorID).getVendorTerms();
                }

                if (defaultVendorTerms == null) {
                    if (checkForFileRejections) {
                        fieldName = ReIMI18NUtility.getMessage("batch.field.vendor_id");
                        Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                                new String[] { fieldName, this.vendorID,
                                        String.valueOf(this.lineID), String.valueOf(this.lineID),
                                        String.valueOf(this.orderNumber + ""),
                                        String.valueOf(this.vendorDocumentNumber + "")});
                    }

                    this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                    this.rejectReason = EdiRejectReasons.INVALID_VENDOR;

                    return FAILURE_REJECT_TABLES;
                }
            }
            
            
            /*
             * vendorId corresponding to the order would be supplier in SupplierSite OFF and
             * supplier site in SupplierSite ON.
             */
            String orderVendor = null;
            if (!this.rtvInd.equalsIgnoreCase(Affirm.YES_IND)) {
                orderVendor = ServiceFactory.getOrderService().getVendorFromOrder(
                        this.orderNumber.toString());
                fieldName = ReIMI18NUtility.getMessage("label.order_number");
            } else if (this.rtvInd.equalsIgnoreCase(Affirm.YES_IND)) {
                orderVendor = ServiceFactory.getRtvService().getVendorFromOrder(
                        this.orderNumber.toString());
                fieldName = ReIMI18NUtility.getMessage("label.rtv_order_no");
            }
            
            SupplierGroup supplierGroup = null;

            if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
                // Total Quantity: if it is null and total header quantity indicator
                // is checked, invalid
                try {
                    supplierGroup = ServiceFactory.getSupplierGroupService().getSupplierGroup(
                            this.vendorID);
                } catch (NumberFormatException e) {
                    supplierGroup = null;
                }
            }
            
            if(StringUtils.isEmpty(this.supplierIdInFile) )
            {
            	this.supplierIdInFile=this.vendorID;
            }
            
            if (!this.validateLinkedSupplier(this.supplierIdInFile,orderVendor,supplierGroup)) {
                String key = "error.batch.vendor_different_than_in_order";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, this.supplierIdInFile,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber.toString()),
                        this.vendorDocumentNumber};
                Logger.errorKey(EdiTransactionHeader.class, key, parameters);

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR_FOR_ORDER;
                return FAILURE_REJECT_TABLES;
            }
        }
        /*
         * Validate terms. If terms are not specified, they should be defaulted from the vendor.
         * Valid terms must exist from the merchandising application All fields required by us and
         * not required in file upload need to be defaulted in before we begin business validation.
         * If not edi reject records will not be valid.
         */
        if (this.terms == null || this.terms.trim().length() == 0) {
            this.terms = defaultVendorTerms;
        }

        // validTerm will validate the term ID and also get the default terms
        // percentage.
        termValidationResults = EdiTransactionHeaderValidationService.validateTerm(this.terms);
        if (!((Boolean) termValidationResults[0]).booleanValue()) {
            if (checkForFileRejections) {
                fieldName = ReIMI18NUtility.getMessage("label.terms");
                Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                        new String[] { fieldName, this.terms, String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""),
                    String.valueOf(this.vendorDocumentNumber + "")});
            }

            this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_TERMS;
            this.rejectReason = EdiRejectReasons.INVALID_TERMS;

            return FAILURE_REJECT_TABLES;
        }

        // [1] is the defualt term discount percentage
        this.termsDiscountPercentage = (Double) termValidationResults[1];

        // check vendor document date: (vDate - postDatedDocDays) <
        // vendorDocumentdate < vDate
        if (!EdiTransactionHeaderValidationService.validateVendorDocumentDate(
                this.vendorDocumentDate, vDate, validMinDate)) {
            boolean invDateEarlier = ServiceFactory.getInvoiceMaintenanceService()
                    .checkInvoiceDateBeforePostDatedDocDays(this.vendorDocumentDate, vDate);
            if (!(allowDateBeforePostDatedDocDays && invDateEarlier)) {
                if (checkForFileRejections) {
                    Logger
                            .errorKey(EdiTransactionHeader.class, "error.batch.invalid_doc_date",
                                    new String[] { EDI_UPLOAD_PROGRAM_NAME,
                                            String.valueOf(validMinDate), String.valueOf(vDate),
                                            String.valueOf(this.vendorDocumentDate)});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_DOC_DATE;
                this.rejectReason = EdiRejectReasons.INVALID_DATE;

                return FAILURE_REJECT_TABLES;
            }
        }
        
        if (this.dueDate == null) {
            try {
                this.dueDate = new ReIMDate(ServiceFactory.getTermsService().calculateTermsDueDate(
                        this.vendorDocumentDate.toString(), this.terms, vDate));
            } catch (RetekException e) {
                throw new ReIMException("error.cannot_compute_due_date", Severity.FATAL, this);
            }
        }

        String supplierDefaultInd = null;
        try {
            supplierDefaultInd = DaoFactory.getSupplierBean()
                    .getSupplierFinalDestInd(this.vendorID);
        } catch (Exception e) {
            throw new ReIMException(e);
        }

        // check that the loc/loc type combo is valid....
        if (this.locationType.equals(Location.STORE)) {
            if (LocationService.validStore(this.location) == false) {
                if (checkForFileRejections) {
                    String key = ReIMI18NUtility.getMessage("batch.field.store");
                    Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                            new String[] { key, String.valueOf(this.location),
                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                    String.valueOf(this.vendorDocumentNumber + "")});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_LOCATION;
                this.rejectReason = EdiRejectReasons.INVALID_LOCATION;

                return FAILURE_REJECT_TABLES;
            }
        } else if (this.locationType.equals(Location.WAREHOUSE)) {
            if (LocationService.validWarehouse(this.location) == false) {
                if (checkForFileRejections) {
                    String key = ReIMI18NUtility.getMessage("batch.field.warehouse");
                    Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                            new String[] { key, String.valueOf(this.location),
                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                    String.valueOf(this.vendorDocumentNumber + "")});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_LOCATION;
                this.rejectReason = EdiRejectReasons.INVALID_LOCATION;

                return FAILURE_REJECT_TABLES;
            }
        }

        // If order number is not null, validate it for the vendor
        if (this.orderNumber != null
                && (this.rtvInd == null || this.rtvInd.equals(ReIMConstants.NO))) {
            vendorId = ServiceFactory.getOrderService().getVendorFromOrder(
                    this.orderNumber.toString());
            // order number exists but is not valid for the supplieror the
            // supplier's linked suppliers
            if (vendorId == null
                    || !ServiceFactory.getOrderService().validateOrderCheckingLinkedSuppliers(
                            this.orderNumber, vendorId)) {
                if (checkForFileRejections) {
                    fieldName = ReIMI18NUtility.getMessage("label.order_number");
                    Logger.errorKey(EdiTransactionHeader.class, "error.batch.invalid_field",
                            new String[] { fieldName, this.orderNumber.toString(),
                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                    String.valueOf(this.vendorDocumentNumber + "")});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ORDER_NO;
                this.rejectReason = EdiRejectReasons.INVALID_ORDER_NO_FOR_SUPPLIER;

                return FAILURE_REJECT_TABLES;
            }

            // validate location. Order/Location combination must exist on
            // ordloc
            if (!nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT)
                    && "N".equalsIgnoreCase(supplierDefaultInd)
                    && !ServiceFactory.getOrderService().validateOrderLoc(this.locationType,
                            this.location, this.orderNumber)) {
                if (checkForFileRejections) {
                    fieldName = ReIMI18NUtility.getMessage("label.order_location");
                    String locType = null;
                    if (this.locationType.equals(Location.STORE))
                        locType = ReIMI18NUtility.getMessage("label.store");
                    else
                        locType = ReIMI18NUtility.getMessage("label.warehouse");
                    Logger.errorKey(EdiTransactionHeader.class,
                            "error.batch.invalid_order_location", new String[] {
                                    EDI_UPLOAD_PROGRAM_NAME, locType, this.location.toString(),
                                    this.orderNumber.toString(), String.valueOf(this.lineID)});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_LOCATION;
                this.rejectReason = EdiRejectReasons.INVALID_ORDER_NO_FOR_LOCATION;

                return FAILURE_REJECT_TABLES;
            }
        } // end if (orderNumber != null)

        // Exchange Rate - no business-level validation at this point.
        // Control total cost - no business-level validation at this point.
        // Control total quantity - no business-level validation at this point.
        // Total discount - no business-level validation at this point.
        // Custom Document Reference 1 - no business-level validation at this
        // point.
        // Custom Document Reference 2 - no business-level validation at this
        // point.
        // Custom Document Reference 3 - no business-level validation at this
        // point.
        // Custom Document Reference 4 - no business-level validation at this
        // point.

        if (ediTransactionDetailList != null && ediTransactionDetailList.length != 0) {
            Set<String> itemSet = new HashSet<String>();
            int listLength = ediTransactionDetailList.length;

            for (int i = 0; i < listLength; i++) {
                if (ediTransactionDetailList[i].validateWithPrimaryRejectionToTables(this,
                        checkForFileRejections).isFailure()) {
                    // the errorColumnId, rejectReason and rejectedDocDetailId
                    // were set in the detail,
                    // so we can just return here.
                    return FAILURE_REJECT_TABLES;
                }

                // Check for duplicate items for the document. If the item is
                // duplicated, then this
                // item is invalid. If the item is not duplicated, add it to the
                // hashset for future
                // item duplication checks.
                if (this.merchType == null || this.merchType.equals("")
                        || !nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {

                    String itemToCheck = ediTransactionDetailList[i].getItem();
                    EdiItemSource itemSource = ediTransactionDetailList[i].getEdiItemSource();
                    if (itemSet.contains(itemToCheck)) {

                        String errorMsg = "";
                        String errorReason = "";
                        String errorColumnId = "";

                        if (itemSource.equals(EdiItemSource.UPC)) {
                            errorMsg = "error.batch.duplicate_upc";
                            errorReason = EdiRejectReasons.INVALID_UPC_DUPLICATE;
                            errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
                        } else { // VPN
                            errorMsg = "error.batch.duplicate_vpn";
                            errorReason = EdiRejectReasons.INVALID_VPN_DUPLICATE;
                            errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VPN;
                        }

                        if (checkForFileRejections) {
                            Logger.errorKey(EdiTransactionHeader.class, errorMsg, new String[] {
                                    EDI_UPLOAD_PROGRAM_NAME, ediTransactionDetailList[i].getUpc(),
                                    String.valueOf(ediTransactionDetailList[i].getLineID())});

                        }

                        this.errorColumnId = errorColumnId;
                        this.rejectReason = errorReason;
                        this.rejectedDocDetailId = ediTransactionDetailList[i].getDocDetailId();
                        return FAILURE_REJECT_FILE;
                    } else {
                        itemSet.add(ediTransactionDetailList[i].getItem());
                    }
                }

                else {
                    if (!itemSet.contains(ediTransactionDetailList[i].getItem()))
                        itemSet.add(ediTransactionDetailList[i].getItem());
                }

            }
            EdiTransactionDetail.setItemSet(new HashSet());
        }

        if (checkForFileRejections) {
            EdiValidationResult taxValidationResult = validateTaxWithPrimaryRejectionToFile();
            if (taxValidationResult.isFailure()) { return FAILURE_REJECT_FILE; }
        }
        return VALIDATION_SUCCESS;
    }

    private boolean validateWithPatternString(String validateString, String pattern) {
        return PatternMatchingUtils.matches(
                pattern == null ? PatternMatchingUtils.ALPHA_NUMERIC_PATTERN : pattern,
                validateString, true);
    }

    private boolean validNoLeadingZeroString(String s) {
        if (s.charAt(0) == '0') {
            if (UIFieldValidationService.isLeadingZeroInvoiceNumberAllowed())
                return true;
            else
                return false;
        } else {
            return true;
        }
    }

    /*
     * This method checks whether the vendor line corresponds to a supplier or a supplier site. This
     * scenario happens only in Supplier Site ON. If the vendor line is supplier, corresponding
     * supplier site has to be fetched and set for supplierSite. If the vendor line is supplier
     * site, corresponding supplier parent has to be fetched and set for vendor.
     */
/*    protected void checkVendorOrSupplierSite(String vendorId) throws ReIMException {
        String vendorFromOrder = ServiceFactory.getVendorService().getSupplierParent(vendorId);

    }*/

    public long getLineID() {
        return lineID;
    }

    public String getRecordDescriptor() {
        return recordDescriptor;
    }

    public long getTransactionNumber() {
        return transactionNumber;
    }

    public double getTotalCost() {
        return totalCost.doubleValue();
    }

    public double getTotalQuantity() {
        return totalQuantity.doubleValue();
    }

    public Long getCrossReferenceDocumentNumber() {
        return crossReferenceDocumentNumber;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public String getCustomDocumentReference1() {
        return customDocumentReference1;
    }

    public String getCustomDocumentReference2() {
        return customDocumentReference2;
    }

    public String getCustomDocumentReference3() {
        return customDocumentReference3;
    }

    public String getCustomDocumentReference4() {
        return customDocumentReference4;
    }

    public String getDocumentType() {
        return documentType;
    }

    public ReIMDate getDueDate() {
        return dueDate;
    }

    public Double getExchangeRate() {
        return exchangeRate;
    }

    public String getFreightType() {
        return freightType;
    }

    public String getManuallyPaidInd() {
        return manuallyPaidInd;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getTerms() {
        return terms;
    }

    public Double getTermsDiscountPercentage() {
        return termsDiscountPercentage;
    }

    public double getTotalDiscount() {
        return totalDiscount.doubleValue();
    }

    public ReIMDate getVendorDocumentDate() {
        return vendorDocumentDate;
    }

    public String getVendorDocumentNumber() {
        return vendorDocumentNumber;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getVendorType() {
        return vendorType;
    }

    public Long getLocation() {
        return location;
    }

    public String getLocationType() {
        return locationType;
    }

    public Long getOrderNumber() {
        return orderNumber;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public EdiNonMerchDetail[] getEdiNonMerchDetailList() {
        return ediNonMerchDetailList;
    }

    public EdiTransactionDetail[] getEdiTransactionDetailList() {
        return ediTransactionDetailList;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setTotalCost(double controlTotalCost) {
        this.totalCost = new BigDecimal(controlTotalCost);
        this.totalCost = this.totalCost.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
    }

    public void setTotalQuantity(double controlTotalQuantity) {
        this.totalQuantity = new BigDecimal(controlTotalQuantity);
        if (!this.totalQuantity.toString().equals(this.totalQuantity.toBigInteger().toString())) {
            this.totalQuantity = this.totalQuantity.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
        }
    }

    public void setCrossReferenceDocumentNumber(Long crossReferenceDocumentNumber) {
        this.crossReferenceDocumentNumber = crossReferenceDocumentNumber;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public void setCustomDocumentReference1(String customDocumentReference1) {
        this.customDocumentReference1 = customDocumentReference1;
    }

    public void setCustomDocumentReference2(String customDocumentReference2) {
        this.customDocumentReference2 = customDocumentReference2;
    }

    public void setCustomDocumentReference3(String customDocumentReference3) {
        this.customDocumentReference3 = customDocumentReference3;
    }

    public void setCustomDocumentReference4(String customDocumentReference4) {
        this.customDocumentReference4 = customDocumentReference4;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void setDueDate(ReIMDate dueDate) {
        this.dueDate = dueDate;
    }

    public void setExchangeRate(Double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public void setFreightType(String freightTerms) {
        this.freightType = freightTerms;
    }

    public void setManuallyPaidInd(String manuallyPaidInd) {
        this.manuallyPaidInd = manuallyPaidInd;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public void setTermsDiscountPercentage(Double termsDiscountPercentage) {
        this.termsDiscountPercentage = termsDiscountPercentage;
    }

    public void setTotalDiscount(double totalDiscount) {
        this.totalDiscount = new BigDecimal(totalDiscount);
        this.totalDiscount = this.totalDiscount.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
    }

    public void setVendorDocumentDate(ReIMDate vendorDocumentDate) {
        this.vendorDocumentDate = vendorDocumentDate;
    }

    public void setVendorDocumentNumber(String vendorDocumentNumber) {
        this.vendorDocumentNumber = vendorDocumentNumber;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public void setVendorType(String vendorType) {
        this.vendorType = vendorType;
    }

    public void setLocation(Long location) {
        this.location = location;
    }

    public void setLocationType(String locationType) {
        this.locationType = locationType;
    }

    public void setOrderNumber(Long orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setLineID(long lineID) {
        this.lineID = lineID;
    }

    public void setRecordDescriptor(String recordDescriptor) {
        this.recordDescriptor = recordDescriptor;
    }

    public void setTransactionNumber(long transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public void setEdiNonMerchDetailList(EdiNonMerchDetail[] ediNonMerchDetailList) {
        this.ediNonMerchDetailList = ediNonMerchDetailList;
    }

    public void setEdiTransactionDetailList(EdiTransactionDetail[] ediTransactionDetailList) {
        this.ediTransactionDetailList = ediTransactionDetailList;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public double getDetailControlTotalCostSum() {
        return detailControlTotalCostSum.doubleValue();
    }

    public double getDetailControlTotalQuantitySum() {
        return detailControlTotalQuantitySum.doubleValue();
    }

    public void setDetailControlTotalCostSum(double detailControlTotalCostSum) {
        this.detailControlTotalCostSum = new BigDecimal(detailControlTotalCostSum);
        this.detailControlTotalCostSum = this.detailControlTotalCostSum.setScale(4,
                BigDecimal.ROUND_HALF_UP);
    }

    public void setDetailControlTotalQuantitySum(double detailControlTotalQuantitySum) {
        this.detailControlTotalQuantitySum = new BigDecimal(detailControlTotalQuantitySum);
        this.detailControlTotalQuantitySum = this.detailControlTotalQuantitySum.setScale(
                PRECISION4, BigDecimal.ROUND_HALF_UP);
    }

    public void setOrignalRecord(String record) {
        this.originalRecord = record;
    }

    public String getOriginalRecord() {
        return originalRecord;
    }

    public boolean isTransactionValid() {
        return transactionValid;
    }

    public void setTransactionValid(boolean transactionValid) {
        this.transactionValid = transactionValid;
    }

    public EdiTransactionTail getEdiTransactionTail() {
        return ediTransactionTail;
    }

    public void setEdiTransactionTail(EdiTransactionTail ediTransactionTail) {
        this.ediTransactionTail = ediTransactionTail;
    }

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public String getMultiLocation() {
        return multiLocation;
    }

    public void setMultiLocation(String multiLocation) {
        this.multiLocation = multiLocation;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public boolean getIsEdiDownload() {
        return isEdiDownload;
    }

    public void setIsEdiDownload(boolean isEdiDownload) {
        this.isEdiDownload = isEdiDownload;
    }

    public String getErrorColumnId() {
        return errorColumnId;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setErrorColumnId(String errorColumnId) {
        this.errorColumnId = errorColumnId;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public Long getRejectedDocDetailId() {
        return rejectedDocDetailId;
    }

    public void setRejectedDocDetailId(Long rejectedDocDetailId) {
        this.rejectedDocDetailId = rejectedDocDetailId;
    }

    public String getMerchType() {
        return this.merchType;
    }

    public Long getDealId() {
        return this.dealId;
    }

    public String getRtvInd() {
        return this.rtvInd;
    }

    public void setMerchType(String merchType) {
        this.merchType = merchType;
    }

    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    public void setRtvInd(String rtvInd) {
        this.rtvInd = rtvInd;
    }

    public String getDealApprovalInd() {
        return this.dealApprovalInd;
    }

    public void setDealApprovalInd(String dealApprovalInd) {
        this.dealApprovalInd = dealApprovalInd;
    }

    public double getTotalTaxAmount() {
        return this.totalTaxAmount.doubleValue();
    }

    public void setTotalTaxAmount(double totalTaxAmount) {
        this.totalTaxAmount = new BigDecimal(totalTaxAmount);
        this.totalTaxAmount = this.totalTaxAmount.setScale(4, BigDecimal.ROUND_HALF_UP);
    }

    public EDIHeaderTax[] getEDIHeaderTaxList() {
        return this.ediTaxDetailList;
    }

    public void setEDIHeaderTaxList(EDIHeaderTax[] details) {
        this.ediTaxDetailList = details;
    }

    public double getTotalTaxAmountFromDetails() {
        return this.totalTaxAmountFromDetails.doubleValue();
    }

    public void setTotalTaxAmountFromDetails(double totalTaxAmountFromDetails) {
        this.totalTaxAmountFromDetails = new BigDecimal(totalTaxAmountFromDetails);
        this.totalTaxAmountFromDetails = this.totalTaxAmountFromDetails.setScale(4,
                BigDecimal.ROUND_HALF_UP);
    }

    public double getTotalTaxAmountFromTTAXS() {
        return this.totalTaxAmountFromTTAXS.doubleValue();
    }

    public void setTotalTaxAmountFromTTAXS(double totalTaxAmountFromTTAXS) {
        this.totalTaxAmountFromTTAXS = new BigDecimal(totalTaxAmountFromTTAXS);
        this.totalTaxAmountFromTTAXS = this.totalTaxAmountFromTTAXS.setScale(4,
                BigDecimal.ROUND_HALF_UP);
    }

    private boolean nullSafeEquals(Object obj1, Object obj2) {
        if (obj1 == null || obj2 == null) { return obj1 == obj2; }
        return obj1.equals(obj2);
    }

    public void setUploadReporter(EdiTransactionUploadReporter uploadReporter) {
        this.uploadReporter = uploadReporter;
    }

    private boolean isMultiLocation() {
        return this.multiLocation.equalsIgnoreCase(ReIMConstants.YES);
    }

    public String getSupplierSiteID() {
        return supplierSiteID;
    }

    public void setSupplierSiteID(String supplierSiteID) {
        this.supplierSiteID = supplierSiteID;
    }

    public boolean isSupplierSiteEnabled() {
        return supplierSiteEnabled;
    }

    public void setSupplierSiteEnabled(boolean supplierSiteEnabled) {
        this.supplierSiteEnabled = supplierSiteEnabled;
    }

    public boolean isFileSupplierSiteInd() {
        return fileSupplierSiteInd;
    }

    public void setFileSupplierSiteInd(boolean fileSupplierSiteInd) {
        this.fileSupplierSiteInd = fileSupplierSiteInd;
    }

    public EdiDocBulk getEdiDocBulk() {
        return this.ediDocBulk;
    }
    
    public void setEdiDocBulk(EdiDocBulk ediDocBulk) {
        this.ediDocBulk = ediDocBulk;
    }

	public String getSupplierIdInFile() {
		return supplierIdInFile;
	}

	public void setSupplierIdInFile(String supplierIdInFile) {
		this.supplierIdInFile = supplierIdInFile;
	}

	public String getDocumentSupplierParent() {
		return documentSupplierParent;
	}

	public void setDocumentSupplierParent(String documentSupplierParent) {
		this.documentSupplierParent = documentSupplierParent;
	}

	public String getOrderSupplierParent() {
		return orderSupplierParent;
	}

	public void setOrderSupplierParent(String orderSupplierParent) {
		this.orderSupplierParent = orderSupplierParent;
	}

}
