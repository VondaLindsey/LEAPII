package com.retek.reim.merch.utils;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Locale;

import oracle.retail.reim.utils.Severity;

import com.ibm.icu.text.DecimalFormat;
import com.ibm.icu.text.NumberFormat;
import com.ibm.icu.util.Currency;
import com.retek.merch.utils.Money;
import com.retek.merch.utils.RetekException;
import com.retek.reim.db.ImCurrencyLocaleRow;
import com.retek.reim.services.I18NService;

public class ReIMMoney extends Money implements Serializable {
    // Changed Code to ajust for 2 Decimals Places. This change also needs to take place in the database IM_CURRENCY_LOCALE : CURRENCY_COST to 2 : Syed Qadri
    private static int MAX_FRACTION_DIGITS_DEFAULT = 2;

    public ReIMMoney(String amt) {
        super(amt.trim());
    }

    public ReIMMoney(double amt) {
        super(amt);
    }

    public static String getCurrencyString(Number number, Locale locale) {
        NumberFormat format = NumberFormat.getCurrencyInstance(locale);
        return format.format(number.doubleValue());
    }

    public static String getCurrencyString(double number, Locale locale) throws ReIMException {
        NumberFormat format = getCurrencyFormat(null, locale);
        return format.format(number);
    }

    public static String getCurrencyString(long number, Locale locale) throws ReIMException {
        NumberFormat format = getCurrencyFormat(null, locale);
        return format.format(number);
    }

    public static String getCurrencyStringEuro(Number number, Locale locale) throws ReIMException {
        NumberFormat format = getCurrencyFormat(null, locale);
        return format.format(number);
    }

    public static String getCurrencyStringEuro(long number, Locale locale) throws ReIMException {
        NumberFormat format = getCurrencyFormat(null, locale);
        return format.format(number);
    }

    public static String getCurrencyStringEuro(double number, Locale locale) throws ReIMException {
        NumberFormat format = getCurrencyFormat(null, locale);
        return format.format(number);
    }

    public static Number parseCurrencyStringEuro(String text) throws ReIMException {
        try {
            if (ReIMI18NUtility.isParseableNumberString(text)) {
                // Use this if currency not entered
                return new Money(ReIMI18NUtility.parseNumberString(text).doubleValue());
            } else {
                NumberFormat format = ReIMI18NUtility.getCurrencyFormatEuro();
                return new Money(format.parse(text).toString());

            }
        } catch (RetekException e) {
            throw new ReIMException(e);
        } catch (ParseException ex) {
            throw new ReIMException("I18NUtility.parse_exception", Severity.ERROR, ex,
                    ReIMMoney.class, new String[] { text});
        } catch (Exception ex) {
            throw new ReIMException("I18NUtility.parse_unknown", Severity.ERROR, ex,
                    ReIMMoney.class, new String[] { text});
        }
    }

    public String getRetailString() throws ReIMException {
        return getRetailString(doubleValue());
    }

    public String getCostString() throws ReIMException {
        return getCostString(doubleValue());
    }

    public ReIMMoney subtract(ReIMMoney money) {
        return new ReIMMoney((super.subtract(money)).doubleValue());
    }

    public static String getCostString(double cost) throws ReIMException {

        return ReIMMoney.getCostString(cost, null);
    }

    public static String getCostString(double cost, String currencyCode) throws ReIMException {

        return ReIMMoney.getCostString(cost, currencyCode, null);
    }

    public static String getCostString(double cost, String currencyCode, String costType)
            throws ReIMException {

        if (currencyCode == null || currencyCode.trim().length() == 0) {
            currencyCode = ReIMUserContext.getPrimaryCurrency().getCurrencyCode();
        }

        ImCurrencyLocaleRow aRow = getImCurrencyLocaleRow(currencyCode);
        Locale locale = getDefaultCurrencyLocale();
        Currency currency = Currency.getInstance(currencyCode);

        /*
         * We are supressing the currency symbol from being displayed. To change this, switch the 2
         * lines of code below these comments. We are supressing the symbol due to the
         * unpredictability of how the symbol will be presented in the gui. The ability to print the
         * currency symbol instead of the currency code is dependent on the Java 2 Runtime
         * Environment (J2RE) localization level. Some runtime vendors may provide localized
         * currency symbols for many or all currencies. The Sun Microsystems runtime provides only a
         * few. The Euro symbol, for example, is provided for those Western European locales that
         * will use the Euro currency by default or by other necessity in 2002. NumberFormat objects
         * for other locales do not retrieve a localized symbol for foreign currencies. In that
         * situation, the format object will simply use the foreign currency code. We can show that
         * behavior by printing a Euro currency amount using an en_US NumberFormat.
         * 
         * Example: Amount of 1234.00 euros.
         * 
         * en_GB NumberFormat: �1.234,00 en_US NumberFormat: EUR1,234.00
         * 
         * note, this example is only for Sun's JRE 1.4. Other vendor's JREs or version levels may
         * produce different results. J. Nemanich.
         */

        DecimalFormat format = (DecimalFormat) DecimalFormat.getInstance(locale);
        format.setCurrency(currency);
        format.setNegativePrefix("(");
        format.setNegativeSuffix(")");
        if (costType != null && costType.equals(ReIMConstants.UNIT_COST)) {
            format.setMaximumFractionDigits(MAX_FRACTION_DIGITS_DEFAULT);
        } else { // Total Cost
            format.setMaximumFractionDigits(aRow.getCurrencyCostDec());
        }
        format.setMinimumFractionDigits(aRow.getCurrencyCostDec());
        return format.format(cost);
    }

    public static String getRetailString(double cost) throws ReIMException {
        return ReIMMoney.getRetailString(cost, null);
    }

    public static String getRetailString(double cost, String currencyCode) throws ReIMException {

        ImCurrencyLocaleRow aRow = null;
        if (currencyCode == null || currencyCode.trim().length() == 0) {
            aRow = ReIMUserContext.getPrimaryCurrency();
        } else {
            aRow = getImCurrencyLocaleRow(currencyCode);
        }

        Locale locale = getDefaultCurrencyLocale();

        NumberFormat format = NumberFormat.getCurrencyInstance(locale);
        format.setMinimumFractionDigits(aRow.getCurrencyRtlDec());
        return format.format(cost);
    }

    public static Money parseCurrencyString(String text) throws ReIMException {
        return ReIMMoney.parseCurrencyString(text, null);
    }

    public static Money parseCurrencyString(String text, String currencyCode) throws ReIMException {
        try {
            Locale locale = getDefaultCurrencyLocale();

            if (ReIMI18NUtility.isParseableNumberString(text, locale)) {
                // Use this if currency not entered
                return new Money(ReIMI18NUtility.parseNumberString(text, locale).doubleValue());
            } else {

                Number number = ReIMI18NUtility.parseCurrencyString(text, locale, currencyCode);
                if (number == null) { return new Money("0"); }
                return new Money(ReIMI18NUtility.parseCurrencyString(text, locale, currencyCode)
                        .toString());
            }
        } catch (ReIMException ex) {
            throw new ReIMException("I18NUtility.parse_exception", Severity.ERROR, ex,
                    ReIMMoney.class, new String[] { text});
        }
    }

    private static ImCurrencyLocaleRow getImCurrencyLocaleRow(String currencyCode)
            throws ReIMException {
        ImCurrencyLocaleRow aRow;
        if (currencyCode == null || currencyCode.length() == 0) {
            aRow = ReIMUserContext.getPrimaryCurrency();
        } else {
            aRow = I18NService.getCurrencyLocale(currencyCode);
        }
        return aRow;
    }

    public static Locale getDefaultCurrencyLocale() {
        return ReIMUserContext.getLocale();
    }

    private static int getMaximumFractionDigits(String currencyCode) throws ReIMException {
        ImCurrencyLocaleRow aRow = getImCurrencyLocaleRow(currencyCode);
        if (aRow != null) {
            return aRow.getCurrencyCostDec();
        } else {
            return MAX_FRACTION_DIGITS_DEFAULT;
        }
    }

    private static NumberFormat getCurrencyFormat(String currencyCode, Locale locale)
            throws ReIMException {
        NumberFormat format = null;
        int maxFractionDigits = MAX_FRACTION_DIGITS_DEFAULT;
        if (locale == null) {
            locale = getDefaultCurrencyLocale();
        }
        format = NumberFormat.getCurrencyInstance(locale);
        if (currencyCode != null) {
            Currency currency = Currency.getInstance(currencyCode);
            format.setCurrency(currency);
            maxFractionDigits = getMaximumFractionDigits(currencyCode);
        }
        format.setMaximumFractionDigits(maxFractionDigits);
        return format;
    }
}
