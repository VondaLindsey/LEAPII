package com.retek.reim.business.match;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import oracle.retail.reim.utils.Severity;

import com.retek.merch.utils.Quantity;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.foundation.AShipmentBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMQuantity;

/**
 * -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		20-Jun-2013	BNaik		Reverting the Oracle Bug 6955602 fix because it allows summary matching on the receipt 
 *    including the quantities of the receipt item that had been already resolved with another invoice.                                           									
 */

public class OnlineReceiptLevel implements ReceiptGroup {
    private Receipt receipt;

    public OnlineReceiptLevel() {
    }

    public OnlineReceiptLevel(Receipt receipt) {
        this.receipt = receipt;
    }

    /**
     * Returns the cost.
     * 
     * @return double
     */
    public Quantity getCost() throws ReIMException {
        try {
            Quantity totalCost = new Quantity(0);
            Map receiptItems = receipt.getReceiptItems();

            Collection receipts = receiptItems.values();

            for (Iterator i = receipts.iterator(); i.hasNext();) {
                ReceiptItem receiptItem = (ReceiptItem) i.next();
                ReIMQuantity unitCost = new ReIMQuantity(receiptItem.getUnitCost());

                totalCost = totalCost.add(unitCost.multiply(receiptItem.getQtyReceived()));
            }

            return totalCost;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_total_receipt_cost", Severity.ERROR, e, this);
        }
    }

    /**
     * Returns the qty.
     * 
     * @return double
     */
    public Quantity getQty() throws ReIMException {
        try {
            Quantity totalQty = new Quantity(0);
            Map receiptItems = receipt.getReceiptItems();

            Collection receipts = receiptItems.values();

            for (Iterator i = receipts.iterator(); i.hasNext();) {
                ReceiptItem receiptItem = (ReceiptItem) i.next();
                totalQty = totalQty.add(receiptItem.getQtyReceived());
            }

            return totalQty;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_total_receipt_qty", Severity.ERROR, e, this);
        }
    }

    public Quantity getAvailableToMatchQty() throws ReIMException {
        try {
            Quantity totalQty = new Quantity(0);
            Map receiptItems = receipt.getReceiptItems();
            /* BRN V 1.2 Begin - removed
            AShipmentBean bean = (AShipmentBean) ReIMBeanFactory
            .getBean(ReIMBeanFactory.AShipmentBean);
            BRN V 1.2 End */
            
            Collection receipts = receiptItems.values();

            for (Iterator i = receipts.iterator(); i.hasNext();) {
                ReceiptItem receiptItem = (ReceiptItem) i.next();
                /* BRN V 1.2 Begin - removed
                long itemId=Long.parseLong(receiptItem.getItemId());
                long shipment=Long.parseLong(receiptItem.getReceiptId());
                if(receiptItem.getAvailableToMatchQty()<=0 && !bean.isCostMatched(itemId,shipment)){
                	totalQty = totalQty.add(receiptItem.getQtyReceived());
                }else{
                totalQty = totalQty.add(receiptItem.getAvailableToMatchQty());
                }
                BRN V 1.2 End */
                //BRN V 1.2 Begin - added 
                totalQty = totalQty.add(receiptItem.getAvailableToMatchQty());
                //BRN V 1.2 End
            }

            return totalQty;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_total_receipt_qty", Severity.ERROR, e, this);
        }
    }

    public Quantity getAvailableToMatchCost() throws ReIMException {
        try {
            Quantity totalCost = new Quantity(0);
            Map receiptItems = receipt.getReceiptItems();

            Collection receipts = receiptItems.values();
            /* BRN V 1.2 - Begin - removed  
            AShipmentBean bean = (AShipmentBean) ReIMBeanFactory
            .getBean(ReIMBeanFactory.AShipmentBean);
            */

            for (Iterator i = receipts.iterator(); i.hasNext();) {
                ReceiptItem receiptItem = (ReceiptItem) i.next();
                /* BRN V 1.2 - Begin - removed
                long itemId=Long.parseLong(receiptItem.getItemId());
                long shipment=Long.parseLong(receiptItem.getReceiptId());
                ReIMQuantity unitCost = new ReIMQuantity(receiptItem.getUnitCost());
                if(receiptItem.getAvailableToMatchQty()<=0 && !bean.isCostMatched(itemId,shipment)){
                	totalCost = totalCost.add(unitCost.multiply(receiptItem.getQtyReceived()));
                }else{
                totalCost = totalCost.add(unitCost.multiply(receiptItem.getAvailableToMatchQty()));
                }
                BRN V 1.2 End */
            
            	//BRN V 1.2 Begin - added
	            ReIMQuantity unitCost = new ReIMQuantity(receiptItem.getUnitCost());
	            totalCost = totalCost.add(unitCost.multiply(receiptItem.getAvailableToMatchQty()));
            	//BRN V 1.2 End 
            
            }

            return totalCost;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_total_receipt_cost", Severity.ERROR, e, this);
        }
    }

    public void updateInvoiceMatchStatus(String status) throws ReIMException {
        receipt.setInvoiceMatchStatus(status);
    }

    /**
     * Returns the receipt.
     * 
     * @return Receipt
     */
    public Receipt getReceipt() {
        return receipt;
    }

    /**
     * Sets the receipt.
     * 
     * @param receipt
     *            The receipt to set
     */
    public void setReceipt(Receipt receipt) {
        this.receipt = receipt;
    }

    public Receipt[] getReceipts() throws ReIMException {
        return null;
    }

}
