package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.POLocation;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.lov.LocationLOV;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		22-Mar-2013	BNaik		BRN IMS135775:  ReIM: RCA not updating the ORDLOC and SHIPSKU correctly
 * 															Move the call to Auto Resolve to the trigger and remove from the Java code when RCA is performed.
 * 										
 */

@Deprecated
public abstract class AOrderLocationBean {
    protected final String LOC_CODE_TYPE = "LOC";
    protected final String STORE_CODE = "S";
    protected final String WH_CODE = "W";

    // Attributes from the table
    protected String storeId;
    protected String storeName;
    protected String whId;
    protected String whName;
    protected String orderNo;
    protected String orderBy;
    protected String supplierId;
    protected boolean isMerch;

    // the dirty-bit flags for attributes
    protected boolean isStoreIdChanged;
    protected boolean isStoreNameChanged;
    protected boolean isWhIdChanged;
    protected boolean isWhNameChanged;
    protected boolean isOrderNoChanged;

    public void setStoreId(String newStoreId) {
        if (newStoreId.length() > 0) {
            storeId = newStoreId;
            isStoreIdChanged = true;
        }
    }

    public void setStoreName(String newStoreName) {
        if (newStoreName.length() > 0) {
            storeName = newStoreName;
            isStoreNameChanged = true;
        }
    }

    public void setWhId(String newWhId) {
        if (newWhId.length() > 0) {
            whId = newWhId;
            isWhIdChanged = true;
        }
    }

    public void setWhName(String newWhName) {
        if (newWhName.length() > 0) {
            whName = newWhName;
            isWhNameChanged = true;
        }
    }

    public void setOrderNo(String newOrderNo) {
        if (newOrderNo.length() > 0) {
            orderNo = newOrderNo;
            isOrderNoChanged = true;
        }
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = " order by " + orderBy;
    }

    public boolean isMerch() {
        return isMerch;
    }

    public void setMerch(boolean isMerch) {
        this.isMerch = isMerch;
    }

    public void setSupplierId(String supplierId) {
        if (supplierId.length() > 0) {
            this.supplierId = supplierId;
        }
    }

    public String[] getPOItemLocationForWH(String orderNo, String location, String itemId)
            throws ReIMException {

        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // build query string
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            List<String> locations = new ArrayList<String>();
            StringBuffer query = new StringBuffer();
            // BRN V1.3 OLR 135775 Incorrect value shown in the Cost Selection screen for PO unit cost.
            query
                    .append("SELECT DISTINCT L.LOCATION FROM v_im_ordloc L, WH W WHERE  W.WH = L.LOCATION AND  L.ORDER_NO = ? AND  W.PHYSICAL_WH = ? AND L.ITEM = ?");
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            stmt.setLong(1, Long.parseLong(orderNo.trim()));
            stmt.setLong(2, Long.parseLong(location));
            stmt.setString(3, itemId.trim());

            // execute query
            rs = stmt.executeQuery();

            while (rs.next()) {
                locations.add(rs.getString(1));
            }
            String[] locationsArray = (String[]) locations.toArray(new String[locations.size()]);
            return locationsArray;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                        exception, this);

            }
        }
    }

    // This LOV query returns all locations on orders if order is not specified,
    // and returns all locations on a given order if order is specified.
    // In terms of warehouse, only physical warehouse should be returned.
    public LocationLOV[] select() throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            // retrieve the store, warehouse location type from codes table
            ACodeDetailTransBean codeDetailBean = (ACodeDetailTransBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.ACodeDetailTransBean);
            String stCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.STORE_CODE);
            String whCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.WH_CODE);

            // construct a query for store
            StringBuffer stQuery = new StringBuffer().append(
                    " SELECT ST.STORE ID, ST.STORE_NAME Name, '").append(stCodeDesc).append(
                    "' Type ").append(" FROM STORE ST ").append(
                    " WHERE ST.STOCKHOLDING_IND = 'Y' AND ((ST.STORE IN (SELECT OL.LOCATION ")
                    .append(" FROM v_im_ordloc OL ").append(" WHERE OL.LOCATION = ST.STORE ")
                    .append(constructStoreWhere("OL"));
                    

            // unless this is a merchandise invoice, locations not on v_im_ordloc may
            // be valid
            if ((this.orderNo == null || this.orderNo.trim().length() < 1) && !this.isMerch) {
                if (storeId != null) {
                    stQuery
                            .append(
                                    " OR (NOT EXISTS(SELECT 'X' FROM v_im_ordloc WHERE LOCATION = ST.STORE)")
                            .append(" AND ST.STORE = ").append(storeId).append(")");
                } else {
                    stQuery
                            .append(" OR (NOT EXISTS(SELECT 'X' FROM v_im_ordloc WHERE LOCATION = ST.STORE))");
                }
            }

            stQuery.append(")");
            
            

            // construct a query for warehouse
            // this will roll up virtual warehouses to their physical warehouses
            StringBuffer whQuery = new StringBuffer().append(
                    " SELECT DISTINCT WH.WH ID, WH.WH_NAME Name, '").append(whCodeDesc).append(
                    "' Type ").append(" FROM WH WH, ").append("      WH WH2 ").append(
                    " WHERE WH.WH = WH2.PHYSICAL_WH ").append(
                    " AND ((WH2.WH IN (SELECT OL.LOCATION ").append(" FROM v_im_ordloc OL ")
                    .append(" WHERE OL.LOCATION = WH2.WH ").append(constructWhWhere("OL"));
                    

            // unless this is a merchandise invoice, locations not on v_im_ordloc may
            // be valid
            if ((this.orderNo == null || this.orderNo.trim().length() < 1) && !this.isMerch) {
                if (whId != null) {
                    whQuery.append(
                            " OR (NOT EXISTS(SELECT 'X' FROM v_im_ordloc WHERE LOCATION = WH2.WH)")
                            .append(" AND WH2.WH = ").append(whId).append(")");
                } else {
                    whQuery
                            .append(" OR (NOT EXISTS(SELECT 'X' FROM v_im_ordloc WHERE LOCATION = WH2.WH))");
                }
            }

            whQuery.append(")");
            
            
            if (orderBy == null) orderBy = "";

            rs = stmt.executeQuery(stQuery.toString() + " UNION ALL " + whQuery.toString()
                     + orderBy);
            
            ArrayList dataList = new ArrayList();

            boolean rtvOrder=true;
            while (rs.next())
            {
                dataList.add(new LocationLOV(rs.getLong(1) + "", rs.getString(2), rs.getString(3)));
                rtvOrder=false;
                
            }
            
            //if result set is empty for non rtv orders, look for non rtv orders
            if(rtvOrder)
            {
            	
                StringBuffer rtvStQuery = new StringBuffer().append(
                " SELECT ST.STORE ID, ST.STORE_NAME Name, '").append(stCodeDesc).append(
                "' Type ").append(" FROM STORE ST ").append(
                " WHERE ST.STOCKHOLDING_IND = 'Y' AND ST.STORE IN (SELECT R.STORE FROM RTV_HEAD R  WHERE  RTV_ORDER_NO=").append(orderNo);
                rtvStQuery.append(")");
            	
            	  // construct a query for warehouse
                // this will roll up virtual warehouses to their physical warehouses
                StringBuffer rtvwhQuery = new StringBuffer().append(
                        " SELECT DISTINCT WH.WH ID, WH.WH_NAME Name, '").append(whCodeDesc).append(
                        "' Type ").append(" FROM WH WH, ").append("      WH WH2 ").append(
                        " WHERE WH.WH = WH2.PHYSICAL_WH ").append(
                        " AND WH2.WH IN (SELECT R.WH FROM RTV_HEAD R  WHERE  RTV_ORDER_NO=").append(orderNo);
                
                rtvwhQuery.append(")");
                
                rs = stmt.executeQuery(rtvStQuery.toString() + " UNION ALL " + rtvwhQuery.toString()
                        + orderBy);
               
                        
               while (rs.next())
               {
                   dataList.add(new LocationLOV(rs.getLong(1) + "", rs.getString(2), rs.getString(3)));
                                     
               }
            }
            
            

            int l = dataList.size();
            LocationLOV data[] = new LocationLOV[l];
            dataList.toArray(data);

            String userLang = ReIMUserContext.getUserLanguage();
            if (com.retek.reim.translation.DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setDescription(com.retek.reim.translation.DataTranslationService
                            .getLocationDesc(data[i].getDescription(), userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("Error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }
    
    
    

    // This LOV query returns all locations on orders that have been received
    // and have a status of 'U'nmatched.
    // If order is specified it only returns locations for that order.
    // In terms of warehouse, only physical warehouse should be returned.
    public LocationLOV[] selectReceivedOrderLocations() throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            // retrieve the store, warehouse location type from codes table
            ACodeDetailTransBean codeDetailBean = (ACodeDetailTransBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.ACodeDetailTransBean);
            String stCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.STORE_CODE);
            String whCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.WH_CODE);

            StringBuffer stQuery = new StringBuffer().append(
                    " SELECT ST.STORE ID, ST.STORE_NAME Name, '").append(stCodeDesc).append(
                    "' Type ").append(" FROM STORE ST ").append(
                    " WHERE (ST.STORE IN (SELECT SH.BILL_TO_LOC ").append(" FROM SHIPMENT SH ").append(
                    " WHERE SH.BILL_TO_LOC = ST.STORE AND SH.RECEIVE_DATE IS NOT NULL ").append(" AND SH.STATUS_CODE in ('R', 'U', 'C') ")
                    .append(
                            "                   AND NVL(SH.INVC_MATCH_STATUS,'" + Receipt.UNMATCHED
                                    + "') ='" + Receipt.UNMATCHED + "' ").append(
                            constructStoreWhere("SH"));

            // construct a query for warehouse
            StringBuffer whQuery = new StringBuffer().append(
                    " SELECT DISTINCT WH.WH ID, WH.WH_NAME Name, '").append(whCodeDesc).append(
                    "' Type ").append(" FROM WH WH ").append(" WHERE (WH.WH IN (SELECT SH.BILL_TO_LOC ")
                    .append(" FROM SHIPMENT SH ").append(" WHERE SH.BILL_TO_LOC = WH.WH  AND SH.RECEIVE_DATE IS NOT NULL ").append(
                            " AND SH.STATUS_CODE in ('R', 'U', 'C') ").append(
                            "                   AND NVL(SH.INVC_MATCH_STATUS,'" + Receipt.UNMATCHED
                                    + "') ='" + Receipt.UNMATCHED + "' ").append(
                            constructWhWhere("SH"));

            if (orderBy == null) orderBy = "";

            rs = stmt.executeQuery(stQuery.toString() + " UNION ALL " + whQuery.toString()
                    + orderBy);
            ArrayList dataList = new ArrayList(1);

            while (rs.next())
                dataList.add(new LocationLOV(rs.getLong(1) + "", rs.getString(2), rs.getString(3)));

            int l = dataList.size();
            LocationLOV data[] = new LocationLOV[l];
            dataList.toArray(data);

            String userLang = ReIMUserContext.getUserLanguage();
            if (com.retek.reim.translation.DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setDescription(com.retek.reim.translation.DataTranslationService
                            .getLocationDesc(data[i].getDescription(), userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.order_location_bean.select_received_order_locations",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("Error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }

    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes.
    // The joinWith variable determines which table the order_no is
    // selected from -- SH = shipment, OL = v_im_ordloc.
    protected String constructStoreWhere(String joinWith) {
        StringBuffer where = new StringBuffer(40);

        // This part must be done before the next append which closes the
        // sub-query
        if (isOrderNoChanged)
            where.append(" AND ").append(joinWith).append(".ORDER_NO=").append(orderNo);

        // for closing the sub-query
        where.append(") ");

        if (isStoreIdChanged) where.append(" AND ST.STORE=").append(storeId);

        if (isStoreNameChanged) where.append(" AND ST.STORE_NAME='").append(storeName).append("'");

        where.append(") ");

        return where.toString();
    }

    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes.
    // The joinWith variable determines which table the order_no is
    // selected from -- SH = shipment, OL = v_im_ordloc.
    protected String constructWhWhere(String joinWith) {
        StringBuffer where = new StringBuffer(40);

        // This part must be done before the next append which closes the
        // sub-query
        if (isOrderNoChanged)
            where.append(" AND ").append(joinWith).append(".ORDER_NO=").append(orderNo);

        // for closing the sub-query
        where.append(") ");

        if (isWhIdChanged) where.append(" AND WH.WH=").append(whId);

        if (isWhNameChanged) where.append(" AND WH.WH_NAME='").append(whName).append("'");

        where.append(") ");

        return where.toString();
    }

// ANIL POTUKUCHI
    protected String constructAllocWhere() {
        StringBuffer where = new StringBuffer(40);

        if (isStoreIdChanged) where.append(" AND to_loc= ").append(storeId);

        return where.toString();
    }

    protected String constructShipWhere() {
        StringBuffer where = new StringBuffer(40);

        if (isStoreIdChanged) where.append(" AND bill_to_loc= ").append(storeId);

        return where.toString();
    }
    
    // private static final String GET_POITEMLOCS_BY_ORDER_LOCATION = "SELECT ITEM, UNIT_COST"
    // + " FROM V_IM_ORDLOC_STORES_PHYS_WH " + " WHERE ORDER_NO = ?" + " AND LOCATION = ?";

    // public HashMap<String, POItemLocation> getPOItemLocationsByOrderLocation(String orderNo,
    // Location location) throws ReIMException {
    // OraclePreparedStatement stmt = null;
    // ResultSet rs = null;
    //
    // try {
    // HashMap<String, POItemLocation> poItemLocations = new HashMap<String, POItemLocation>();
    //
    // Connection conn = TransactionManagerFactory.getInstance().getConnection();
    // stmt = (OraclePreparedStatement) conn
    // .prepareStatement(GET_POITEMLOCS_BY_ORDER_LOCATION);
    //
    // stmt.setLong(1, Long.parseLong(orderNo.trim()));
    // stmt.setLong(2, Long.parseLong(location.getLocationId()));
    //
    // // execute query
    // rs = stmt.executeQuery();
    //
    // String itemId = null;
    //
    // // create po item location objects
    // while (rs.next()) {
    // itemId = rs.getString(1);
    //
    // POItemLocation poItemLocation = new POItemLocation();
    // poItemLocation.setItem(new Item());
    // poItemLocation.getItem().setItemId(itemId);
    // poItemLocation.setLocation(location);
    // poItemLocation.setUnitCost(rs.getDouble(2));
    //
    // poItemLocations.put(itemId, poItemLocation);
    // }
    //
    // return poItemLocations;
    // } catch (Exception exception) {
    // throw new ReIMException("error.cannot_retrieve_po_item_locations", Severity.ERROR,
    // exception, this);
    // } finally {
    // try {
    // if (rs != null) {
    // rs.close();
    // }
    // if (stmt != null) {
    // stmt.close();
    // }
    // } catch (SQLException exception) {
    // throw new ReIMException("error.cannot_retrieve_po_item_locations", Severity.ERROR,
    // exception, this);
    //
    // }
    // }
    // }
    //
    public POItemLocation getPOItemLocation(String orderNo, Location location, String itemId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // build query string
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer query = new StringBuffer();
            query.append("SELECT DISTINCT L.UNIT_COST, S.ORIGIN_COUNTRY_ID, L.UNIT_COST UNIT_COST_INIT");
            query.append(" FROM v_im_ordloc L, ORDSKU S, WH W");
            query.append(" WHERE L.ORDER_NO = ?");
            query.append(" AND W.PHYSICAL_WH = ?");
            query.append(" AND L.ITEM = ?");
            query.append(" AND L.ORDER_NO = S.ORDER_NO");
            query.append(" AND L.ITEM = S.ITEM");
            query.append(" AND L.LOCATION = W.WH");
            query.append(" UNION ALL ");
            query.append("SELECT L.UNIT_COST, S.ORIGIN_COUNTRY_ID, L.UNIT_COST UNIT_COST_INIT");
            query.append(" FROM v_im_ordloc L, ORDSKU S, STORE ST");
            query.append(" WHERE L.ORDER_NO = ?");
            query.append(" AND L.LOCATION = ?");
            query.append(" AND L.LOCATION = ST.STORE");
            query.append(" AND L.ITEM = ?");
            query.append(" AND L.ORDER_NO = S.ORDER_NO");
            query.append(" AND L.ITEM = S.ITEM");
            query.append(" UNION ALL ");
            query.append(" SELECT DISTINCT L.UNIT_COST, S.ORIGIN_COUNTRY_ID, L.UNIT_COST UNIT_COST_INIT");
            query.append(" FROM v_im_ordloc l, ORDSKU S, WH WH, SHIPMENT SH");
            query.append(" WHERE L.ORDER_NO = ?");
            query.append(" AND SH.BILL_TO_LOC = ?");
            query.append(" AND L.LOCATION = WH.WH");
            query.append(" AND WH.PHYSICAL_WH = SH.TO_LOC");
            query.append(" AND L.LOC_TYPE = 'W'");
            query.append(" AND L.ITEM = ?");
            query.append(" AND sh.order_no = s.order_no ");
            query.append(" AND L.ORDER_NO = S.ORDER_NO");
            query.append(" AND L.ITEM = S.ITEM");         
            query.append(" UNION ALL ");
            query.append(" SELECT DISTINCT l.unit_cost, s.origin_country_id, l.unit_cost unit_cost_init  ");
            query.append("   FROM v_im_ordloc l, ordsku s , store st  ");
            query.append("  WHERE l.order_no = ?    ");
            query.append("    AND l.loc_type = 'W'   ");
            query.append("    AND l.item = ?     ");
            query.append("    AND st.default_wh = l.location ");
            query.append("    AND st.store = ?  ");
            query.append("    AND l.order_no = s.order_no   ");
            query.append("    AND l.item = s.item    ");
            query.append("    AND NOT EXISTS (     ");
            query.append("             SELECT 'x'    ");
            query.append("               FROM  shipment sh , shipsku ss, wh wh   ");
            query.append("              WHERE sh.bill_to_loc = ?    ");
            query.append("                AND l.LOCATION = wh.wh    ");
            query.append("                AND wh.physical_wh = sh.to_loc   ");
            query.append("                AND ss.item = l.item    ");
            query.append("                AND sh.order_no = l.order_no   ");
            query.append("                AND sh.shipment = ss.shipment    ");
            query.append("                AND l.item = ss.item)   ");
            query.append(" UNION  ");
            query.append("          SELECT DISTINCT iid.unit_cost, iscl.origin_country_id, iid.unit_cost unit_cost_init ");
            query.append("            FROM im_doc_head idh, im_invoice_detail iid, item_supp_country_loc iscl ");
            query.append("           WHERE idh.order_no = ? ");
            query.append("             AND idh.location = ? ");
            query.append("             AND idh.doc_id = iid.doc_id  ");
            query.append("             AND iid.item = iscl.item  ");
            query.append("             AND idh.location = iscl.loc  ");
            query.append("             AND iid.item = ? ");
            query.append("             AND iscl.item = iid.item  ");
            query.append("             AND iscl.supplier = idh.supplier_site_id  ");
            query.append("             AND NOT EXISTS (  ");
            query.append("                    SELECT 'x'  ");
            query.append("                      FROM  shipment sh , shipsku ss  ");
            query.append("                     WHERE sh.bill_to_loc = idh.location  ");
            query.append("                       AND ss.item = iid.item  ");
            query.append("                       AND sh.order_no = idh.order_no ");
            query.append("                       AND sh.shipment = ss.shipment  ");
            query.append("                       AND iid.item = ss.item)     ");     
            
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());

            stmt.setLong(1, Long.parseLong(orderNo.trim()));
            stmt.setLong(2, Long.parseLong(location.getLocationId()));
            stmt.setString(3, itemId.trim());
            stmt.setLong(4, Long.parseLong(orderNo.trim()));
            stmt.setLong(5, Long.parseLong(location.getLocationId()));
            stmt.setString(6, itemId.trim());
            stmt.setLong(7, Long.parseLong(orderNo.trim()));
            stmt.setLong(8, Long.parseLong(location.getLocationId()));
            stmt.setString(9, itemId.trim());
            stmt.setLong(10, Long.parseLong(orderNo.trim()));
            stmt.setString(11, itemId.trim());
            stmt.setLong(12, Long.parseLong(location.getLocationId()));
            stmt.setLong(13, Long.parseLong(location.getLocationId()));
            stmt.setLong(14, Long.parseLong(orderNo.trim()));
            stmt.setLong(15, Long.parseLong(location.getLocationId()));
            stmt.setString(16, itemId.trim());
 
            // execute query
            rs = stmt.executeQuery();

            // create po item location objects
            POItemLocation poItemLocation = null;
            if (rs.next()) {
                poItemLocation = new POItemLocation();
                poItemLocation.setItem(new Item());
                poItemLocation.setOrderId(orderNo);
                poItemLocation.getItem().setItemId(itemId);
                poItemLocation.setLocation(location);
                poItemLocation.setUnitCost(rs.getDouble(1));
                poItemLocation.setOriginCountry(rs.getString(2));
                poItemLocation.setUnitCostInit(rs.getDouble(3));
            }

            return poItemLocation;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                        exception, this);

            }
        }
    }
    
    public List<POItemLocation> getPOItemLocations(String orderNo, Location location, String itemId)
    throws ReIMException{
    	OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // build query string
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer query = new StringBuffer();
            query.append("SELECT DISTINCT L.UNIT_COST, S.ORIGIN_COUNTRY_ID, L.UNIT_COST_INIT");
            query.append(" FROM ORDLOC L, ORDSKU S");
            query.append(" WHERE L.ORDER_NO = ?");
            query.append(" AND L.ITEM = ?");
            query.append(" AND L.ORDER_NO = S.ORDER_NO");
            query.append(" AND L.ITEM = S.ITEM");

            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());

            stmt.setLong(1, Long.parseLong(orderNo.trim()));
            stmt.setString(2, itemId.trim());
            
            

            // execute query
            rs = stmt.executeQuery();

            // create po item location objects
            List<POItemLocation> poItemLocations = new ArrayList<POItemLocation>();
            POItemLocation poItemLocation = null;
            while (rs.next()) {
                poItemLocation = new POItemLocation();
                poItemLocation.setItem(new Item());
                poItemLocation.getItem().setItemId(itemId);
                poItemLocation.setLocation(location);
                poItemLocation.setUnitCost(rs.getDouble(1));
                poItemLocation.setOriginCountry(rs.getString(2));
                poItemLocation.setUnitCostInit(rs.getDouble(3));
                poItemLocations.add(poItemLocation);
            }

            return poItemLocations;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                        exception, this);

            }
        }
    }

    public POItemLocation getPOItemLocationForAutoMatch(String orderNo, Location location,
            String itemId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // build query string
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT UNIT_COST"
                    + " FROM V_IM_ORDLOC_STORES_PHYS_WH " + "WHERE ORDER_NO = ?"
                    + "  AND LOCATION = ?" + "  AND ITEM = ?");

            stmt.setLong(1, Long.parseLong(orderNo));
            stmt.setLong(2, Long.parseLong(location.getLocationId()));
            stmt.setString(3, itemId);

            rs = stmt.executeQuery();

            // create po item location objects
            POItemLocation poItemLocation = null;
            if (rs.next()) {
                poItemLocation = new POItemLocation();
                poItemLocation.setItem(new Item());
                poItemLocation.getItem().setItemId(itemId);
                poItemLocation.setLocation(location);
                poItemLocation.setUnitCost(rs.getDouble(1));
            }

            return poItemLocation;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                        exception, this);

            }
        }
    }

    private static final String GET_RANDOM_DEPT = "SELECT /*+ index(im, pk_item_master) */  DEPT "
            + "FROM V_IM_ORDLOC_STORES_PHYS_WH O, ITEM_MASTER IM" + " WHERE O.ITEM = IM.ITEM "
            + " AND O.ORDER_NO = ? " + " AND O.LOCATION = ?";

    public String getRandomOrderLocationDepartment(POLocation poLocation) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String randomDepartment = null;
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement(GET_RANDOM_DEPT);

            stmt.setLong(1, Long.parseLong(poLocation.getOrder().getOrderNo()));
            stmt.setLong(2, Long.parseLong(poLocation.getLocation().getLocationId()));
            rs = stmt.executeQuery();

            if (rs.next()) {
                randomDepartment = String.valueOf(rs.getLong(1));
            }

            return randomDepartment;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_get_random_department_for_order_location",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_get_random_department_for_order_location",
                        Severity.ERROR, exception, this);
            }
        }
    }
    
    public double checkForEntryInImPartiallyMatchedReceipts(String ReceiptID,
			String ItemID) throws ReIMException {
		OraclePreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			Connection conn = TransactionManagerFactory.getInstance()
					.getConnection();
			stmt = (OraclePreparedStatement) conn
					.prepareStatement(""
							+ "SELECT QTY_MATCHED FROM IM_PARTIALLY_MATCHED_RECEIPTS WHERE SHIPMENT = ? AND ITEM=?");
			String qty_matched = "";
			stmt.setString(1, ReceiptID);
			stmt.setString(2, ItemID);
			rs = stmt.executeQuery();
			if (rs != null && rs.next()) {
				qty_matched = rs.getString("QTY_MATCHED");
				return Double.parseDouble(qty_matched);
			} else {
				return 0;
			}
		} catch (Exception e) {
			throw new ReIMException("error occoured in database connection",
					Severity.ERROR, e, this);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception e) {
				throw new ReIMException("connection already closed",
						Severity.ERROR, e, this);
			}
		}
	}


    public double calculateVarianceWithinTolerance(long invoiceId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            double variance = Double.MIN_VALUE;

            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT (SUM(D.COST_VARIANCE_WITHIN_TOLERANCE * D.RESOLUTION_ADJUSTED_QTY)"
                            + " + SUM(D.QTY_VARIANCE_WITHIN_TOLERANCE * OL.UNIT_COST)) "
                            + " FROM IM_INVOICE_DETAIL D, IM_DOC_HEAD H, V_IM_ORDLOC_STORES_PHYS_WH OL "
                            + " WHERE D.DOC_ID = H.DOC_ID "
                            + " AND H.ORDER_NO = OL.ORDER_NO "
                            + " AND D.ITEM = OL.ITEM "
                            + " AND H.LOC_TYPE = OL.LOC_TYPE "
                            + " AND H.LOCATION = OL.LOCATION" + " AND H.DOC_ID = ?");

            stmt.setLong(1, invoiceId);

            rs = stmt.executeQuery();

            if (rs.next()) {
                variance = rs.getDouble(1);
            }

            return variance;
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_calculate_variance_within_tolerance",
                    Severity.ERROR, e, this, new String[] { String.valueOf(invoiceId)});
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.unable_to_calculate_variance_within_tolerance",
                        Severity.ERROR, e, this, new String[] { String.valueOf(invoiceId)});
            }
        }
    }

    private final String INIT_UNIT_COST_SQL = "SELECT UNIT_COST_INIT FROM v_im_ordloc WHERE ORDER_NO = ? AND ITEM = ? AND LOCATION = ? ";

    public void getUnitCostInit(DocumentItem[] documentItems) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement(INIT_UNIT_COST_SQL);

            String orderNo = documentItems[0].getDocument().getOrderNo();
            String locationId = documentItems[0].getDocument().getLocation().getLocationId();
            if (orderNo == null || locationId ==null)
            {
            	throw new ReIMException(
                        "error.cannot_get_init_unit_cost_for_order_location_item", Severity.DEBUG, this);
            }
            for (int i = 0; i < documentItems.length; i++) {
            	if (!documentItems[i].getDocument().getOrderNo().equals(orderNo) || !documentItems[i].getDocument().getLocation().getLocationId().equals(locationId) )
            	{
            		throw new ReIMException(
                            "error.cannot_get_init_unit_cost_for_order_location_item", Severity.DEBUG, this);
            	}
                stmt.setLong(1, Long.parseLong(orderNo));
                stmt.setString(2, documentItems[i].getItemId());
                stmt.setLong(3, Long.parseLong(locationId));
                rs = stmt.executeQuery();

                if (rs.next()) {
                    documentItems[i].setInitialUnitCost(rs.getDouble("unit_cost_init"));
                }
                else
                {
                	AItemSuppCountryBean itemSuppCountryBean = (AItemSuppCountryBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AItemSuppCountryBean);
                	documentItems[i].setInitialUnitCost(itemSuppCountryBean.getItemSupplierCost(
                			documentItems[i].getItemId(), Long.parseLong(orderNo), locationId));
                }
            }
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_get_init_unit_cost_for_order_location_item",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_get_init_unit_cost_for_order_location_item",
                        Severity.ERROR, exception, this);
            }
        }

    }

    public String getPOLocationByOrderAndItem(String orderNo, String itemId, String locId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // build query string
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            String loc = null;
            StringBuffer query = new StringBuffer();
            query
                    .append("SELECT DISTINCT L.LOCATION FROM ORDLOC L WHERE L.LOCATION IN (SELECT WH FROM WH WHERE PHYSICAL_WH = ?) AND L.LOC_TYPE='W' AND L.ORDER_NO = ? AND L.ITEM = ?");
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            stmt.setString(1, locId.trim());
            stmt.setLong(2, Long.parseLong(orderNo.trim()));
            stmt.setString(3, itemId.trim());

            // execute query
            rs = stmt.executeQuery();

            while (rs.next()) {
                loc = rs.getString(1);
            }

            return loc;
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_retrieve_po_item_location", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_retrieve_po_location_by_orderno_and_item",
                        Severity.ERROR, exception, this);

            }
        }
    }

    // This LOV query returns all locations on orders if order is not specified,
    // and returns all locations on a given order if order is specified.
    // In terms of warehouse, only physical warehouse should be returned.
    // If there are any allocation locations for the order this method will return those locations
    // too.
    public LocationLOV[] selectOnlyLocFromOrder() throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            // retrieve the store, warehouse location type from codes table
            ACodeDetailTransBean codeDetailBean = (ACodeDetailTransBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.ACodeDetailTransBean);
            String stCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.STORE_CODE);
            String whCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.WH_CODE);

            // construct a query for store
            StringBuffer stQuery = new StringBuffer().append(
                    " SELECT ST.STORE ID, ST.STORE_NAME Name, '").append(stCodeDesc).append(
                    "' Type ").append(" FROM STORE ST ")
                    .append(" WHERE ST.STOCKHOLDING_IND = 'Y' ").append(
                            " AND ((ST.STORE IN (SELECT OL.LOCATION ").append(" FROM ORDLOC OL ")
                    .append(" WHERE OL.LOCATION = ST.STORE ").append(constructStoreWhere("OL"));

            // Unless this is a merchandise invoice, locations not on ordloc may
            // be valid
            if ((this.orderNo == null || this.orderNo.trim().length() < 1) && !this.isMerch) {
                if (storeId != null) {
                    stQuery.append(" OR (NOT EXISTS(SELECT 'X' FROM ORDLOC ").append(
                            " WHERE LOCATION = ST.STORE)").append(" AND ST.STORE = ").append(
                            storeId).append(")");
                } else {
                    stQuery.append(" OR (NOT EXISTS(SELECT 'X' FROM ORDLOC ").append(
                            " WHERE LOCATION = ST.STORE))");
                }
            }

            stQuery.append(")");

            // Construct a query for warehouse
            // this will roll up virtual warehouses to their physical warehouses
            StringBuffer whQuery = new StringBuffer().append(
                    " SELECT DISTINCT WH.WH ID, WH.WH_NAME Name, '").append(whCodeDesc).append(
                    "' Type ").append(" FROM WH WH, ").append(" WH WH2 ").append(
                    " WHERE WH.WH = WH2.PHYSICAL_WH ").append(
                    " AND ((WH2.WH IN (SELECT OL.LOCATION ").append(" FROM ORDLOC OL ").append(
                    " WHERE OL.LOCATION = WH2.WH ").append(constructWhWhere("OL"));

            // unless this is a merchandise invoice, locations not on ordloc may
            // be valid
            if ((this.orderNo == null || this.orderNo.trim().length() < 1) && !this.isMerch) {
                if (whId != null) {
                    whQuery.append(" OR (NOT EXISTS(SELECT 'X' FROM ORDLOC ").append(
                            " WHERE LOCATION = WH2.WH)").append(" AND WH2.WH = ").append(whId)
                            .append(")");
                } else {
                    whQuery.append(" OR (NOT EXISTS(SELECT 'X' FROM ORDLOC ").append(
                            " WHERE LOCATION = WH2.WH))");
                }
            }

            whQuery.append(")");

            // This query will give the allocation locations
         //   String allocStoreQuery = "SELECT ST.STORE ID , ST.STORE_NAME Name, '" + stCodeDesc
         //           + "' Type FROM STORE ST WHERE STORE IN "
         //           + "(SELECT TO_LOC FROM ALLOC_DETAIL WHERE ALLOC_NO IN "
         //           + "(SELECT ALLOC_NO FROM ALLOC_HEADER WHERE ORDER_NO = " + orderNo
         //           + " OR ORDER_NO IN (SELECT ALLOC_NO FROM ALLOC_HEADER WHERE ORDER_NO = "
         //           + orderNo + ")) AND TO_LOC_TYPE = 'S')";
         // ANIL POTUKUCHI

       //   String allocStoreQuery = "SELECT ST.STORE ID , ST.STORE_NAME Name, '" + stCodeDesc
       //           + "' Type FROM STORE ST WHERE STORE IN "
       //           + "(SELECT TO_LOC FROM ALLOC_DETAIL WHERE ALLOC_NO IN "
       //           + "(SELECT ALLOC_NO FROM ALLOC_HEADER WHERE ORDER_NO = " + orderNo
       //           + " ) AND TO_LOC_TYPE = 'S')" ;
                  
            StringBuffer allocStoreQuery = new StringBuffer().append(
                    " SELECT ST.STORE ID , ST.STORE_NAME Name, '").append(stCodeDesc).append(
                    "' Type ").append(" FROM STORE ST WHERE STORE IN ").append(
                    " (SELECT TO_LOC FROM ALLOC_DETAIL WHERE ALLOC_NO IN ").append(
                    " (SELECT ALLOC_NO FROM ALLOC_HEADER WHERE ORDER_NO = ").append(orderNo).append(
                    " ) AND TO_LOC_TYPE = 'S' ").append( constructAllocWhere()).append(" )");          
            
            // Anil P -- Added the below for ship loc
            StringBuffer shipStoreQuery = new StringBuffer().append(
                    " SELECT ST.STORE ID , ST.STORE_NAME Name, '").append(stCodeDesc).append(
                    "' Type ").append(" FROM STORE ST WHERE ST.STORE IN ( ").append(
                    " SELECT sh.bill_to_loc ").append(
                    "  FROM shipment sh ").append(
                    "   WHERE sh.bill_to_loc = st.STORE ").append(
                     " AND sh.receive_date IS NOT NULL ").append(
                    "  AND sh.order_no  = ").append(orderNo).append(
                    "  AND sh.status_code IN ('R', 'U', 'C') ").append(
                    "  AND NVL (sh.invc_match_status, 'U') = 'U' ").append( constructShipWhere()).append(" )");  
            
            if (orderBy == null) orderBy = "";

//            rs = stmt.executeQuery(stQuery.toString() + " UNION ALL" + whQuery.toString()
//                    + " UNION " + allocStoreQuery.toString() + orderBy);

            rs = stmt.executeQuery(stQuery.toString() + " UNION ALL" + whQuery.toString()
                    + " UNION " + allocStoreQuery.toString() + " UNION " + shipStoreQuery.toString() + orderBy);
            
            ArrayList<LocationLOV> dataList = new ArrayList<LocationLOV>();

            while (rs.next())
                dataList.add(new LocationLOV(rs.getLong(1) + "", rs.getString(2), rs.getString(3)));

            int l = dataList.size();
            LocationLOV data[] = new LocationLOV[l];
            dataList.toArray(data);

            String userLang = ReIMUserContext.getUserLanguage();
            if (com.retek.reim.translation.DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setDescription(com.retek.reim.translation.DataTranslationService
                            .getLocationDesc(data[i].getDescription(), userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }
}