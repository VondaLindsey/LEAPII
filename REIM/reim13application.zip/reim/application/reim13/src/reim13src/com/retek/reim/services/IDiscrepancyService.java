package com.retek.reim.services;

import java.util.List;
import com.retek.reim.ui.discrepancyResolution.PriceReviewDetail;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.db.ImCostDiscrepancyHistRow;
import com.retek.reim.db.ImQtyDiscrepancyHistRow;

public interface IDiscrepancyService {

    public ReIMDate calculateDiscrepancyResolveByDate(ReIMDate docDueDate,
            ReIMSystemOptions systemOptions, ReIMDate vDate, String discrepancyType)
            throws ReIMException;

    public void migrateCostDiscrepancyToHistory(long discrepancyId) throws ReIMException;

    public void migrateCostDiscrepancyToHistory(Resolution resolution) throws ReIMException;

    public void migrateQuantityDiscrepancyToHistory(long qtyDiscId) throws ReIMException;

    public void deleteQuantityDiscrepancy(long id) throws ReIMException;

    public long getQtyDiscrepancyIdForItemDocId(String item, String docId) throws ReIMException;
    
    public long getCostDiscrepancyIdForItemDocId(String item, String docId) throws ReIMException;

    public void deleteQuantityDiscrepancyById(long discId) throws ReIMException;

    public long doDeleteAndCreateCostDiscrepancy(DocumentItemInvoice invoiceItem)
            throws ReIMException;

    public void doDeleteCostDiscrepancy(DocumentItemInvoice invoiceItem) throws ReIMException;

    public void deleteCostDiscrepancyByDocItemId(long docId, String itemId) throws ReIMException;

    public long doDeleteAndCreateQtyDiscrepancy(DocumentItemInvoice invoiceItem,
            ReceiptItem[] receiptItems) throws ReIMException;

    public PriceReviewDetail readCostDiscrepancyById(long id) throws ReIMException;

    public void deleteQtyAndCostDiscrepanciesByDocId(long[] docIds) throws ReIMException;

    public void deleteDiscrepanciesAndResolutions(MerchandiseDocument[] invoices)
            throws ReIMException;

    public List getQtyDiscrepanciesForDocId(String docId) throws ReIMException;

    public List getCostDiscrepanciesForDocId(String docId) throws ReIMException;

    public List getResolutionsForDocId(String docId) throws ReIMException;
    public double getQtyDisc (String docId, String orderNo, String loc, String item ) throws ReIMException;
    
    public double getCostDisc (String docId, String orderNo, String loc, String item ) throws ReIMException;
    


}