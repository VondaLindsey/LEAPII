package com.retek.reim.business;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.merch.utils.ReIMDate;

public class Order {
    public static final String DEAL_COST_SOURCE = "DEAL";

    private String orderNo;
    private Supplier supplier;
    private String supplierId;
    private String orderCurrency;
    private Double orderExchangeRate;
    private String shipPaymentMethod;
    private ReIMDate writtenDate;

    public Order() {
    }

    public Order(String orderNo) {
        this.orderNo = orderNo;
    }

    public Order(String orderNo, Supplier supplier) {
        this.orderNo = orderNo;
        this.supplier = supplier;
    }
    
    public Order(String orderNo, String supplierId, String orderCurrency) {
        this.orderNo = orderNo;
        this.supplierId = supplierId;
        this.orderCurrency = orderCurrency;
    }

    public Order(String orderNo, Supplier supplier, String orderCurrency) {
        this.orderNo = orderNo;
        this.supplier = supplier;
        this.orderCurrency = orderCurrency;
    }

    public Order(String orderNo, String orderCurrency) {
        this.orderNo = orderNo;
        this.orderCurrency = orderCurrency;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public void setSupplierId(String supplier) {
        this.supplierId = supplier;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public String getOrderCurrency() {
        return orderCurrency;
    }

    public void setOrderCurrency(String orderCurrency) {
        this.orderCurrency = orderCurrency;
    }

    public ReIMDate getWrittenDate() {
        return writtenDate;
    }

    public void setWrittenDate(ReIMDate writtenDate) {
        this.writtenDate = writtenDate;
    }

    public Double getOrderExchangeRate() {
        return orderExchangeRate;
    }

    public void setOrderExchangeRate(Double orderExchangeRate) {
        this.orderExchangeRate = orderExchangeRate;
    }

    public String getShipPaymentMethod() {
        return shipPaymentMethod;
    }

    public void setShipPaymentMethod(String shipPaymentMethod) {
        this.shipPaymentMethod = shipPaymentMethod;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((orderNo == null) ? 0 : orderNo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        final Order other = (Order) obj;
        if (orderNo == null) {
            if (other.orderNo != null) return false;
        } else if (!orderNo.equals(other.orderNo)) return false;
        return true;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
