package com.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.business.DiscrepancyCostReview;
import com.retek.reim.business.DiscrepancyCostReviewDetail;
import com.retek.reim.business.Location;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;
import com.retek.reim.services.DiscrepancyService;
import com.retek.reim.services.DiscrepancyVo;

public class ImCostDiscrepancyAccessExt extends ImCostDiscrepancyAccess implements
        IImCostDiscrepancyAccessExt {
    private static final String DELETE_COST_DISCREPANCIES_BY_INVOICE = "DELETE FROM IM_COST_DISCREPANCY "
            + " WHERE DOC_ID = ? ";

    /**
     * Method: delete. This method deletes a single row from the database using the primary key.
     * 
     * @param costDiscrepancyId
     * 
     */
    public void deleteCostDiscrepancyByDiscId(long[] costDiscrepancyIds) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String tableQuery = "DELETE FROM IM_COST_DISCREPANCY WHERE IM_COST_DISCREPANCY.COST_DISCREPANCY_ID = ?";
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
            for (int i = 0; i < costDiscrepancyIds.length; i++) {
                stmnt.setLong(1, costDiscrepancyIds[i]);
                stmnt.addBatch();
            }
            stmnt.executeBatch();
            // stmnt.executeUpdate();
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variable 1 type=long, value=" + costDiscrepancyIds + ";";
            throw new ReIMException("DALGen.cannot_perform_delete", Severity.ERROR, ex, this,
                    new String[] { tableQuery, exMsg});
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    public void deleteCostDiscrepancies(MerchandiseDocument[] invoices) throws ReIMException {
        OraclePreparedStatement stmnt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmnt = (OraclePreparedStatement) conn
                    .prepareStatement(DELETE_COST_DISCREPANCIES_BY_INVOICE);

            int invoiceLength = invoices.length;
            for (int i = 0; i < invoiceLength; i++) {
                stmnt.setLong(1, invoices[i].getDocId());
                stmnt.addBatch();
            }
            stmnt.executeBatch();
        } catch (SQLException exception) {
            throw new ReIMException("error.cannot_delete_cost_discrepancies", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_delete_cost_discrepancies",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private static final String DELETE_COST_DISCREPANCY_BY_DOC_AND_ITEM_ID = "DELETE FROM IM_COST_DISCREPANCY WHERE DOC_ID = ? AND ITEM = ?";

    public void deleteCostDiscrepanciesByDocIdAndItemId(long docId, String itemId)
            throws ReIMException {
        String deleteStr1 = "DELETE FROM IM_COST_DISCREPANCY_CNR WHERE COST_DISCREPANCY_ID = (SELECT COST_DISCREPANCY_ID FROM "
                + "IM_COST_DISCREPANCY WHERE DOC_ID = ? AND ITEM = ?)";
        String deleteStr2 = "DELETE FROM IM_COST_DISCREPANCY_CNR_HIST WHERE COST_DISCREPANCY_ID = (SELECT COST_DISCREPANCY_ID FROM "
                + "IM_COST_DISCREPANCY WHERE DOC_ID = ? AND ITEM = ?)";
        OraclePreparedStatement stmnt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmnt = (OraclePreparedStatement) conn.prepareStatement(deleteStr1);

            stmnt.setLong(1, docId);
            stmnt.setString(2, itemId);
            stmnt.executeUpdate();

            stmnt = (OraclePreparedStatement) conn.prepareStatement(deleteStr2);

            stmnt.setLong(1, docId);
            stmnt.setString(2, itemId);
            stmnt.executeUpdate();

            stmnt = (OraclePreparedStatement) conn
                    .prepareStatement(DELETE_COST_DISCREPANCY_BY_DOC_AND_ITEM_ID);

            stmnt.setLong(1, docId);
            stmnt.setString(2, itemId);
            stmnt.executeUpdate();
        } catch (SQLException exception) {
            throw new ReIMException("error.cannot_delete_cost_discrepancies", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_delete_cost_discrepancies",
                        Severity.ERROR, exception, this);
            }
        }
    }

    /**
     * readDiscrepanciesByRole method reads cost discrepancies based on passed in roleId and
     * priviledge
     * 
     * @param roleId,
     *            priviledge
     * 
     * @return DiscrepancyCostReview[]
     * 
     * @throws ReIMException
     * 
     */
    public DiscrepancyCostReview[] readDiscrepanciesByRole(long roleId, String priviledge)
            throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer whereClause = new StringBuffer(" ");

            if (priviledge != null && priviledge.trim().length() > 0) {
                if (priviledge.equalsIgnoreCase(ReIMConstants.USER)) {
                    whereClause.append("  AND COST.BUSINESS_ROLE_ID = ?");
                } else if (priviledge.equalsIgnoreCase(ReIMConstants.ALL)) {
                    // no additional restrictions;
                } else {
                    // It'll never get here. But just being defensive.
                    return null;
                }
            }

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT "
                            + "       COST.LOCATION, COST.LOC_TYPE, COST.ORDER_NO, COST.SUPPLIER, COST.CURRENCY_CODE, "
                            + "       COST.ROUTING_DATE, COST.RESOLVE_BY_DATE, "
                            + "       COST.DOC_TOTAL_COST, COST.DEPT, COST.CLASS, COST.BUSINESS_ROLE_ID, COST.AP_REVIEWER,"
                            + "       COST.CASH_DSCNT_IND, COUNT(*) ITEM_COUNT, COST.DOC_ID, COST.DOC_TYPE, DOC.EXT_DOC_ID "
                            + "  FROM IM_COST_DISCREPANCY COST, IM_DOC_HEAD DOC "
                            // We don't want discrepancies generated by credit
                            // note matching to show up on this review list
                            + "  WHERE DOC.DOC_ID = COST.DOC_ID " 
                            + "  AND DOC.STATUS <> 'DELETE' AND DOC.TYPE <> 'CRDNT' "                            
                            + whereClause.toString()
                            + " "
                            + " GROUP BY DOC.EXT_DOC_ID, COST.LOCATION, COST.LOC_TYPE, COST.ORDER_NO, COST.SUPPLIER, COST.CURRENCY_CODE,"
                            + "       COST.ROUTING_DATE, COST.RESOLVE_BY_DATE, "
                            + "       COST.DEPT, COST.CLASS, COST.BUSINESS_ROLE_ID, COST.AP_REVIEWER,"
                            + "       COST.CASH_DSCNT_IND, COST.DOC_ID, COST.DOC_TYPE, COST.DOC_TOTAL_COST");

            if (priviledge.equalsIgnoreCase(ReIMConstants.USER)) {
                stmt.setLong(1, roleId);
            }
            rs = stmt.executeQuery();

            return createCostReviewFromRS(rs);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.retrieving_cost_discrepancies_by_role",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_cost_discrepancies_by_role",
                        Severity.ERROR, e, this);
            }
        }
    }

    private DiscrepancyCostReview[] createCostReviewFromRS(ResultSet rs) throws Exception {
        ArrayList dpReviews = new ArrayList();
        DiscrepancyCostReview costReviewObj = null;
        Location location = null;

        while (rs.next()) {
            double cost = rs.getDouble("DOC_TOTAL_COST");
            String currencyCode = rs.getString("CURRENCY_CODE");
            location = new Location();
            location.setLocationId(rs.getString("LOCATION"));
            location.setLocationType(rs.getString("LOC_TYPE"));

            costReviewObj = new DiscrepancyCostReview(rs.getLong("DOC_ID"), rs
                    .getString("DOC_TYPE"), rs.getString("DEPT"), rs.getString("CLASS"), rs
                    .getString("SUPPLIER"), new ReIMDate(rs.getDate("RESOLVE_BY_DATE")), rs
                    .getString("CASH_DSCNT_IND"), new ReIMDate(rs.getDate("ROUTING_DATE")), rs
                    .getString("BUSINESS_ROLE_ID"), rs.getString("ORDER_NO"), location, rs.getString("EXT_DOC_ID"),
                    rs.getString("ITEM_COUNT"), cost, currencyCode, rs.getString("AP_REVIEWER"));

            dpReviews.add(costReviewObj);
        }

        if (dpReviews.size() == 0) {
            return null;
        } else {
            return (DiscrepancyCostReview[]) dpReviews.toArray(new DiscrepancyCostReview[dpReviews
                    .size()]);
        }
    }

    public boolean costDiscrepancyExists(String docId, String itemId) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        ResultSet rs = null;
        String COST_DISCREPANCY_EXISTS = "SELECT 'P' FROM IM_COST_DISCREPANCY WHERE DOC_ID = ?";

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            if (null != itemId) {
                COST_DISCREPANCY_EXISTS = COST_DISCREPANCY_EXISTS + " AND ITEM = ?";
            }
            stmnt = (OraclePreparedStatement) conn.prepareStatement(COST_DISCREPANCY_EXISTS);
            stmnt.setString(1, docId);
            if (null != itemId) {
                stmnt.setString(2, itemId);
            }
            rs = stmnt.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }

    public ImCostDiscrepancyRow readDiscrepancyByDocumentItem(long docId, String itemId)
            throws ReIMException {
        try {
            StringBuffer whereClause = new StringBuffer("DOC_ID = ? AND ITEM = ?");

            DALGenPreparedSQLFragment stmnt = new DALGenPreparedSQLFragment(whereClause.toString());
            stmnt.setLong(1, docId);
            stmnt.setString(2, itemId);

            ImCostDiscrepancyRow[] rows = super.read(stmnt, null, null, null);

            if (rows == null) {
                // cost discrepancy not found for the document item
                return null;
            }

            // Since DOC_ID and ITEM are unique on the table, only 1 row should
            // be returned
            return rows[0];
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.retrieving_cost_discrepancies_by_document_item",
                    Severity.ERROR, e, this);
        }
    }

    /**
     * readDiscrepancyDetailsByDiscrepancyId method reads cost discrepancies based on passed in
     * discrepancy id
     * 
     * @param discrepancyId
     * 
     * @return DiscrepancyCostReviewDetail[]
     * 
     * @throws ReIMException
     * 
     */
    public DiscrepancyCostReviewDetail[] readDiscrepancyDetailsByDiscrepancyId(long discrepancyId)
            throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sql = new StringBuffer();

            sql.append(" SELECT CD.DOC_ID, CD.COST_DISCREPANCY_ID, CD.ITEM , CD.CURRENCY_CODE,");
            sql.append(" DD.ADJUSTED_UNIT_COST,  DD.ADJUSTED_UNIT_COST, CD.DOC_UNIT_COST,");
            sql.append(" DD.ADJUSTED_UNIT_COST - CD.DOC_UNIT_COST VARIANCE,");
            sql
                    .append(" ((DD.ADJUSTED_UNIT_COST - CD.DOC_UNIT_COST)/DD.ADJUSTED_UNIT_COST)*100 VARIANCE_PCT,");
            sql.append(" CD.RESOLUTION_COST, CD.DEBIT_MEMO_REASON_CODE, CD.COST_DISCREPANCY_ID");
            sql
                    .append(" FROM IM_COST_DISCREPANCY CD,  IM_COST_DISCREPANCY_CNR CDCNR, IM_DOC_DETAIL_REASON_CODES DD");
            sql.append(" WHERE CD.COST_DISCREPANCY_ID = ? AND");
            sql.append(" CDCNR.COST_DISCREPANCY_ID = CD.COST_DISCREPANCY_ID AND");
            sql.append(" DD.DOC_ID = CDCNR.CREDIT_NOTE_REQUEST_ID AND");
            sql.append(" DD.ITEM = CD.ITEM");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setLong(1, discrepancyId);

            rs = stmt.executeQuery();

            ArrayList detailReviews = new ArrayList();
            DiscrepancyCostReviewDetail costReviewDetailObj = null;
            while (rs.next()) {
                costReviewDetailObj = new DiscrepancyCostReviewDetail(
                        discrepancyId,
                        rs.getString("ITEM"),
                        "", // Item desc
                        // not
                        // needed
                        new Double(rs.getDouble("ADJUSTED_UNIT_COST")), new Double(rs
                                .getDouble("ADJUSTED_UNIT_COST")), rs.getDouble("DOC_UNIT_COST"),
                        new Double(rs.getString("RESOLUTION_COST")), new Double(rs
                                .getString("VARIANCE")), new Double(rs.getString("VARIANCE_PCT")),
                        "", // COST_SOURCE
                        "", // REF_ITEM
                        null, "", // VPN
                        rs.getString("DEBIT_MEMO_REASON_CODE"), rs.getString("CURRENCY_CODE"));
                costReviewDetailObj.setDocId(rs.getLong("DOC_ID"));
                detailReviews.add(costReviewDetailObj);
            }

            if (detailReviews.size() == 0) {
                return null;
            } else {
                return (DiscrepancyCostReviewDetail[]) detailReviews
                        .toArray(new DiscrepancyCostReviewDetail[detailReviews.size()]);
            }

        } catch (Exception e) {
            throw new ReIMException("error.retrieving_cost_discrepancy_details_by_discrepancy_id",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException("error.retrieving_cost_discrepancy_discrepancy_id",
                        Severity.ERROR, e, this);
            }
        }
    }

    public List getCostDiscrepanciesForDocId(String docId) throws ReIMException {
        try {
            DALGenPreparedSQLFragment stmt = new DALGenPreparedSQLFragment("DOC_ID = ?");
            ImCostDiscrepancyAccess costDisAccess = new ImCostDiscrepancyAccess();
            stmt.setString(1, docId);
            ImCostDiscrepancyRow[] costRow = costDisAccess.read(stmt, null, null, null);

            List discrepancies = new ArrayList();
            if (costRow != null && costRow.length > 0) {
                for (int i = 0; i < costRow.length; i++) {
                    discrepancies.add(transform(costRow[i]));
                }
            }
            return discrepancies;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException(
                    "error.im_qty_discrepancy_access_ext.read_discrepancy_ids_for_doc_id",
                    Severity.ERROR, e, DiscrepancyService.class);
        }
    }

    private DiscrepancyVo transform(ImCostDiscrepancyRow row) throws ReIMException {
        return new DiscrepancyVo(ReIMConstants.DISCREPANCY_TYPE_COST, row.getCostDiscrepancyId(),
                row.getDocType(), row.getDocId(), row.getItem(), row.getOrderNo());
    }
}
