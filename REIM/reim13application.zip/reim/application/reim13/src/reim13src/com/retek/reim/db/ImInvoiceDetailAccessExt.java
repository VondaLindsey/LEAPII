package com.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.business.TaxType;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.Location;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.TaxDiscrepancyDetail;
import com.retek.reim.business.VatDiscrepancy;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.merch.utils.DALGenPreparedSQLFragment;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;

public class ImInvoiceDetailAccessExt extends ImInvoiceDetailAccess implements
        IImInvoiceDetailAccessExt {
    // public ImInvoiceDetailRow[] readByLastUpdateId(String updateId) throws
    // ReIMException {
    // try {
    // StringBuffer whereClause = new StringBuffer("LAST_UPDATE_ID = ?");
    //
    // DALGenPreparedSQLFragment stmnt = new
    // DALGenPreparedSQLFragment(whereClause.toString());
    //
    // stmnt.setString(1, updateId);
    //
    // return super.read(stmnt, null, null, null);
    // } catch (ReIMException e) {
    // throw e;
    // } catch (Exception e) {
    // throw new ReIMException("ImDocDetailAccessExt.readByLastUpdateId",
    // Severity.ERROR, e,
    // this);
    // }
    // }

    public HashMap<String, String> getDetailExistenceForInvoices(String docIdsWhereClause)
            throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();
            HashMap<String, String> detailsExist = new HashMap<String, String>();

            StringBuffer sql = new StringBuffer();

            sql
                    .append("SELECT DOC_ID FROM IM_INVOICE_DETAIL WHERE DOC_ID IN( SELECT /*+ index(dh, im_doc_head_i1) */ dh.doc_id FROM im_doc_head dh ");

            sql.append(docIdsWhereClause);
            sql.append(")");

            rs = stmt.executeQuery(sql.toString());

            while (rs.next()) {
                String docId = String.valueOf(rs.getLong("DOC_ID"));
                detailsExist.put(docId, docId);
            }

            return detailsExist;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_identify_detail_existence", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.could_not_identify_detail_existence",
                        Severity.ERROR, exception, this);
            }
        }
    }

    public HashMap<String, String> getDetailExistenceForInvoice(String docId) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();
            HashMap<String, String> detailsExist = new HashMap<String, String>();

            StringBuffer sql = new StringBuffer("SELECT 'x' FROM IM_INVOICE_DETAIL WHERE DOC_ID =")
                    .append(docId);

            rs = stmt.executeQuery(sql.toString());

            if (rs.next()) {
                detailsExist.put(docId, docId);
            }

            return detailsExist;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_identify_detail_existence", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.could_not_identify_detail_existence",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private static final String DETAILS_EXISTS = "SELECT 1 FROM IM_INVOICE_DETAIL WHERE DOC_ID = ?";

    public boolean detailsExistforInvoice(String docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(DETAILS_EXISTS);
            stmt.setString(1, docId);

            rs = stmt.executeQuery();
            if (rs.next()) { return true; }

            return false;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_identify_detail_existence", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.could_not_identify_detail_existence",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private static final String DETAILS_EXIST_FOR_ALL_INVOICES_PART1 = "SELECT DOC_ID FROM IM_DOC_HEAD WHERE "
            + "DOC_ID NOT IN (SELECT DISTINCT DOC_ID FROM IM_INVOICE_DETAIL WHERE ";

    private static final String DETAILS_EXIST_FOR_ALL_INVOICES_PART2 = ") AND (";

    private static final String DETAILS_EXIST_FOR_ALL_INVOICES_PART3 = ")";

    public boolean detailsExistForAllInvoices(final MerchandiseDocument[] invoices)
            throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            ArrayList docIdsWithoutDetails = new ArrayList();
            // isDetailsExist is not set on the invoices when it is called from
            // online match.
            String[] docIds = new String[invoices.length];
            for (int i = 0; i < invoices.length; i++) {
                docIds[i] = Long.toString(invoices[i].getDocId());
            }

            StringBuffer sqlText = new StringBuffer(1000);
            sqlText.append(DETAILS_EXIST_FOR_ALL_INVOICES_PART1);

            String docIdText = createDocIdSqlStatement(docIds);

            sqlText.append(docIdText);
            sqlText.append(DETAILS_EXIST_FOR_ALL_INVOICES_PART2);
            sqlText.append(docIdText);
            sqlText.append(DETAILS_EXIST_FOR_ALL_INVOICES_PART3);

            rs = stmt.executeQuery(sqlText.toString());
            while (rs.next()) {
                docIdsWithoutDetails.add(rs.getString(1));
            }

            for (int i = 0; i < invoices.length; i++) {
                docIds[i] = Long.toString(invoices[i].getDocId());
                if (docIdsWithoutDetails.contains(docIds[i])) {
                    invoices[i].setDetailsExist(false);
                } else {
                    invoices[i].setDetailsExist(true);
                }
            }

            if (docIdsWithoutDetails.size() > 0) return false;

            return true;
        } catch (Exception exception) {
            throw new ReIMException("error.could_not_identify_detail_existence", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.could_not_identify_detail_existence",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private String createDocIdSqlStatement(String[] docIds) {
        StringBuffer docText = new StringBuffer(500);

        for (int i = 0; i < docIds.length; i++) {
            docText.append("DOC_ID=");
            docText.append(docIds[i]);

            if (i != docIds.length - 1) {
                docText.append(" OR ");
            }
        }

        return docText.toString();
    }

    // public boolean itemExistsforDocument(long docId, String itemId) throws
    // ReIMException {
    // OraclePreparedStatement stmt = null;
    // ResultSet rs = null;
    //
    // try {
    // Connection conn =
    // TransactionManagerFactory.getInstance().getConnection();
    // String sqlTxt = DETAILS_EXISTS + " and item = ?";
    // stmt = (OraclePreparedStatement) conn.prepareStatement(sqlTxt);
    // stmt.setLong(1, docId);
    // stmt.setString(2, itemId);
    //
    // rs = stmt.executeQuery();
    // if (rs.next()) { return true; }
    //
    // return false;
    // } catch (Exception exception) {
    // throw new ReIMException("error.could_not_identify_detail_existence",
    // Severity.ERROR,
    // exception, this);
    // } finally {
    // try {
    // if (rs != null) {
    // rs.close();
    // }
    // if (stmt != null) {
    // stmt.close();
    // }
    // } catch (SQLException exception) {
    // throw new ReIMException("error.could_not_identify_detail_existence",
    // Severity.ERROR, exception, this);
    // }
    // }
    // }

    public ImInvoiceDetailRow[] readDetailsByDocId(Long docId) {
        try {
            String whereClause = " DOC_ID = ?";

            DALGenPreparedSQLFragment stmnt = new DALGenPreparedSQLFragment(whereClause);

            stmnt.setLong(1, docId.longValue());

            // the read(..) method can return null if no matches found..
            return super.read(stmnt, null, null, null);
        } catch (Exception e) {
            throw new DataAccessException(new ReIMException("ImDocDetailAccessExt.readByDocId",
                    Severity.ERROR, e, this));
        }
    }

    public ImInvoiceDetailRow[] readDetailsByDocIdAndItem(Long docId, String itemId)
            throws ReIMException {
        try {
            String whereClause = " DOC_ID = ? AND ITEM = ?";

            DALGenPreparedSQLFragment stmnt = new DALGenPreparedSQLFragment(whereClause);

            stmnt.setLong(1, docId.longValue());
            stmnt.setString(2, itemId);

            return super.read(stmnt, null, null, null);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("ImDocDetailAccessExt.readDetailsByDocIdAndItem",
                    Severity.ERROR, e, this);
        }
    }

    /**
     * readInvoiceItemsAndReceiptByDocId: This method returns the shipment associated with the order
     * on the invoice, the items and their quantity. Needed when an invoice in unresolved or
     * multi-unresolved status and no discrepancies have been resolved has been marked for deletion.
     * 
     * @return HashMap
     * @throws ReIMException
     */
    public HashMap readInvoiceItemsAndReceiptByDocId(long docId) throws ReIMException {
        OraclePreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            HashMap receiptItems = new HashMap();
            StringBuffer sql = new StringBuffer(
            "SELECT d.item, irip.receipt_id, d.invoice_qty FROM ");
    sql
            .append(" im_invoice_detail d, im_rcpt_item_posting_invoice iripi, im_receipt_item_posting irip ");
    sql
            .append(" WHERE d.item = irip.item_id and d.doc_id = iripi.doc_id and iripi.seq_no = irip.seq_no AND iripi.doc_id = ? ");

            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            statement = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            statement.setLong(1, docId);

            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                ReceiptItem receiptItem = new ReceiptItem();
                receiptItem.setItemId(resultSet.getString(1));
                receiptItem.setReceiptId(resultSet.getString(2));
                Double invoiceQty = new Double(resultSet.getDouble(3));

                receiptItems.put(receiptItem, invoiceQty);
            }

            return receiptItems;

        } catch (SQLException ex) {
            throw new ReIMException("ImDocDetailAccessExt.readInvoiceItemsAndReceiptByDocId",
                    Severity.ERROR, ex, this, new String[] { docId + ""});
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("ImDocDetailAccessExt.readInvoiceItemsAndReceiptByDocId",
                        Severity.ERROR, ex, this, new String[] { docId + ""});
            }
        }
    }

    public void deleteItemsPerInvoice(long docId, List itemIds) throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            StringBuffer sb = new StringBuffer();
            int size = itemIds.size();
            for (int i = 0; i < size; i++) {
                sb.append("(item = ");
                sb.append((String) itemIds.get(i));
                sb.append(") ");
                if (i != size - 1) {
                    sb.append("OR ");
                }
            }

            stmt.executeUpdate("delete from IM_INVOICE_DETAIL where doc_id= " + docId + " and ("
                    + sb.toString() + ")");
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_delete_invoice_items", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_delete_invoice_items", Severity.ERROR,
                        exception, this);

            }
        }
    }

    private static final String UPDATE_INVOICE_LINE_STATUS_BY_DOC = "UPDATE IM_INVOICE_DETAIL "
            + " SET STATUS = ?, COST_MATCHED = ?, QTY_MATCHED = ?, LAST_UPDATE_DATETIME = ?, LAST_UPDATE_ID = ? "
            + " WHERE DOC_ID = ? ";

    // Since only merchandise document will have detail lines, this method takes
    // in a merchandise document
    public void updateInvoiceLineStatusToMatched(MerchandiseDocument[] invoices, String userId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            // set all invoice lines status to be updated to the invoices'
            // status
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(UPDATE_INVOICE_LINE_STATUS_BY_DOC);

            MerchandiseDocument invoice = null;

            int invoicesLength = invoices.length;
            for (int i = 0; i < invoicesLength; i++) {
                invoice = invoices[i];

                stmt.setString(1, DocumentItemInvoice.MATCHED);
                stmt.setString(2, ReIMConstants.YES); // set to be cost
                // matched
                stmt.setString(3, ReIMConstants.YES); // set to be qty matched
                stmt.setTimestamp(4, new ReIMDate().getTimestamp());
                stmt.setString(5, userId);
                stmt.setLong(6, invoice.getDocId());
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (Exception exception) {
            throw new ReIMException("error.cannot_update_invoice_line_status", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_update_invoice_line_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    private static final String SELECT_INVOICE_ITEM_STATUS = "SELECT DISTINCT STATUS FROM IM_INVOICE_DETAIL WHERE DOC_ID = ?";

    public boolean checkInvoiceItemStatus(long docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        boolean returnVar = false;

        try {
            // set all invoice lines status to be updated to the invoices'
            // status
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_INVOICE_ITEM_STATUS);
            stmt.setLong(1, docId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                if (rs.getString(1).equals(DocumentItemInvoice.MATCHED)) {
                    returnVar = true;
                }
                if (rs.next()) {
                    returnVar = false;
                }
            }
            return returnVar;

        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invoice_item_status", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_invoice_item_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    private static final String SELECT_INVOICE_INVOICE_ITEM_STATUS = "SELECT DISTINCT STATUS FROM IM_INVOICE_DETAIL WHERE DOC_ID = ? AND ITEM = ?";

    public boolean checkInvoiceItemStatus(long docId, String itemId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        boolean returnVar = false;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(SELECT_INVOICE_INVOICE_ITEM_STATUS);
            stmt.setLong(1, docId);
            stmt.setString(2, itemId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                if (rs.getString(1).equals(DocumentItemInvoice.MATCHED)) {
                    returnVar = true;
                } else {
                    returnVar = false;
                }
            }
            return returnVar;

        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_invoice_item_status", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_invoice_item_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    private static final String UPDATE_INVOICE_LINE_STATUS_BY_DOC_ITEM = "UPDATE IM_INVOICE_DETAIL "
            + " SET STATUS = ? "
            + " ,COST_MATCHED = ? "
            + " ,QTY_MATCHED = ? "
            + " ,COST_VARIANCE_WITHIN_TOLERANCE = ? "
            + " ,QTY_VARIANCE_WITHIN_TOLERANCE = ? "
            + " ,LAST_UPDATE_DATETIME = ? "
            + " ,LAST_UPDATE_ID = ? "
            + " WHERE DOC_ID = ? "
            + " AND ITEM = ? ";

    public void updateInvoiceLineStatus(DocumentItemInvoice[] invoiceLines, String userId)
            throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            // set all invoice lines status to be updated to the invoices'
            // status
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(UPDATE_INVOICE_LINE_STATUS_BY_DOC_ITEM);

            DocumentItemInvoice invoiceLine = null;

            int invoiceLinesLength = invoiceLines.length;
            for (int i = 0; i < invoiceLinesLength; i++) {
                invoiceLine = invoiceLines[i];

                stmt.setString(1, invoiceLine.getStatus());
                stmt.setString(2, invoiceLine.getCostMatched() ? ReIMConstants.YES
                        : ReIMConstants.NO);
                stmt.setString(3, invoiceLine.getQtyMatched() ? ReIMConstants.YES
                        : ReIMConstants.NO);
                if (invoiceLine.getCostVarianceWithinTolerance() == null) {
                    stmt.setNull(4, java.sql.Types.DOUBLE);
                } else {
                    stmt.setDouble(4, invoiceLine.getCostVarianceWithinTolerance().doubleValue());
                }
                if (invoiceLine.getQtyVarianceWithinTolerance() == null) {
                    stmt.setNull(5, java.sql.Types.DOUBLE);
                } else {
                    stmt.setDouble(5, invoiceLine.getQtyVarianceWithinTolerance().doubleValue());
                }
                stmt.setTimestamp(6, new ReIMDate().getTimestamp());
                stmt.setString(7, userId);
                stmt.setLong(8, invoiceLine.getDocument().getDocId());
                stmt.setString(9, invoiceLine.getItem().getItemId());
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_invoice_line_status", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.cannot_update_invoice_line_status", Severity.ERROR,
                        exception, this);
            }
        }
    }

    private static final String DETAILS_MATCHED = "SELECT 1 FROM IM_INVOICE_DETAIL"
            + " WHERE DOC_ID = ? AND (QTY_MATCHED = 'Y' OR STATUS = '"
            + DocumentItemInvoice.MATCHED + "')";

    public boolean detailsMatched(String docId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(DETAILS_MATCHED);
            stmt.setString(1, docId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new ReIMException("error.detailsMatched", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.detailsMatched", Severity.ERROR, exception, this);
            }
        }
    }

    public void updateQtyVarianceWithinTolerance(long qtyDiscrepancyId,
            double qtyVarianceWithinTolerance) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement("UPDATE IM_INVOICE_DETAIL D"
                    + " SET QTY_VARIANCE_WITHIN_TOLERANCE = ?," + " LAST_UPDATE_DATETIME = ?,"
                    + " LAST_UPDATE_ID = ?" + " WHERE 'X' IN (SELECT 'X'"
                    + "                FROM IM_QTY_DISCREPANCY Q"
                    + "               WHERE Q.DOC_ID = D.DOC_ID"
                    + "                 AND Q.ITEM = D.ITEM"
                    + "                 AND Q.QTY_DISCREPANCY_ID = ?)");

            stmt.setDouble(1, qtyVarianceWithinTolerance);
            stmt.setTimestamp(2, new ReIMDate().getTimestamp());
            stmt.setString(3, ReIMUserContext.getUsername());
            stmt.setLong(4, qtyDiscrepancyId);

            stmt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_qty_variance_within_tolerance",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_qty_variance_within_tolerance",
                        Severity.ERROR, e, this);
            }
        }
    }

    public void updateCostVarianceWithinTolerance(long costDiscrepancyId,
            double costVarianceWithinTolerance) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement("UPDATE IM_INVOICE_DETAIL D"
                    + " SET COST_VARIANCE_WITHIN_TOLERANCE = ?,  " + " LAST_UPDATE_ID = ?,  "
                    + " LAST_UPDATE_DATETIME = ?  " + " WHERE 'X' IN (SELECT 'X'"
                    + "                FROM IM_COST_DISCREPANCY C"
                    + "               WHERE C.DOC_ID = D.DOC_ID"
                    + "                 AND C.ITEM = D.ITEM"
                    + "                 AND C.COST_DISCREPANCY_ID = ?)");

            stmt.setDouble(1, costVarianceWithinTolerance);
            stmt.setString(2, ReIMUserContext.getUsername());
            stmt.setTimestamp(3, new ReIMDate().getTimestamp());
            stmt.setLong(4, costDiscrepancyId);

            stmt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                        Severity.ERROR, e, this);
            }
        }
    }
    
    private static final String UPDATE_LINE_QTY_MATCHED = "UPDATE IM_INVOICE_DETAIL SET QTY_MATCHED = 'Y' WHERE doc_id = ? AND ITEM = ?";
    
    public void updateLineQtyMatched(long docId, String itemId ) throws ReIMException {
        OraclePreparedStatement stmt = null;
        
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_LINE_QTY_MATCHED);
            stmt.setLong(1, docId);
            stmt.setString(2, itemId);
            
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_lines_to_cost_matched", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_lines_to_cost_matched",
                        Severity.ERROR, e, this);
            }
        }
    }
    
    private static final String UPDATE_LINE_COST_MATCHED = "UPDATE IM_INVOICE_DETAIL SET COST_MATCHED = 'Y' WHERE doc_id = ? AND ITEM = ?";
    
    public void updateLineCostMatched(long docId, String itemId ) throws ReIMException {
        OraclePreparedStatement stmt = null;
        
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_LINE_COST_MATCHED);
            stmt.setLong(1, docId);
            stmt.setString(2, itemId);
            
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_lines_to_cost_matched", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_lines_to_cost_matched",
                        Severity.ERROR, e, this);
            }
        }
    }
    
    private static final String UPDATE_LINE_TO_SPECIFIED_STATUS = "UPDATE IM_INVOICE_DETAIL SET STATUS = ? WHERE DOC_ID = ? AND ITEM = ?";
    
    public void updateLineStatus(long docId, String itemId, String status ) throws ReIMException {
        OraclePreparedStatement stmt = null;
        
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_LINE_TO_SPECIFIED_STATUS);
            stmt.setString(1, status);
            stmt.setLong(2, docId);
            stmt.setString(3, itemId);
            
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_lines_to_cost_matched", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_lines_to_cost_matched",
                        Severity.ERROR, e, this);
            }
        }
    }

    private static final String UPDATE_LINE_TO_COST_MATCH = "UPDATE IM_INVOICE_DETAIL SET COST_MATCHED = ?, LAST_UPDATE_DATETIME = ?, LAST_UPDATE_ID=? WHERE DOC_ID = ? AND ITEM = ?";

    public void updateLinesToCostMatched(Set keySet) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement(UPDATE_LINE_TO_COST_MATCH);
            String docId = null;
            String itemId = null;
            for (Iterator iter = keySet.iterator(); iter.hasNext();) {
                String key = (String) iter.next();
                int splitString = key.indexOf("+");
                docId = key.substring(0, splitString);
                itemId = key.substring(splitString + 1, key.length());
                stmt.setString(1, ReIMConstants.YES);
                stmt.setTimestamp(2, new ReIMDate().getTimestamp());
                stmt.setString(3, ReIMUserContext.getUsername());
                stmt.setString(4, docId);
                stmt.setString(5, itemId);
                stmt.addBatch();
            }

            stmt.executeBatch();
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_lines_to_cost_matched", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_lines_to_cost_matched",
                        Severity.ERROR, e, this);
            }
        }
    }

    /*
     * Checks whether both the Invoice line item is both quantity and cost matched. If so the status
     * of the record has to changed to "M"-matched.
     * 
     * @param Document ID and Item
     */
    public boolean qtyAndCostMatched(long docId, String item) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        StringBuffer sqlText = new StringBuffer(
                "SELECT 'X' FROM IM_INVOICE_DETAIL ID, IM_DOC_HEAD DH ");
        sqlText.append("WHERE DH.DOC_ID = ID.DOC_ID ");
        sqlText.append("AND ID.DOC_ID = ? ");
        sqlText.append("AND ID.ITEM = ? ");
        sqlText.append("AND (DH.STATUS = '" + Document.MATCHED + "' OR (DH.STATUS = '"
                + Document.UNRESOLVED_MATCH + "' ");
        sqlText.append("AND NOT EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL D ");
        sqlText.append("WHERE DH.DOC_ID = D.DOC_ID AND  D.ITEM = ? AND (D.COST_MATCHED = 'N' ");
        sqlText.append("OR D.QTY_MATCHED = 'N' OR D.ADJUSTMENT_PENDING = 'Y' )))) ");

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());
            stmt.setLong(1, docId);
            stmt.setString(2, item);
            stmt.setString(3, item);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return true;
            } else
                return false;

        } catch (Exception e) {
            throw new ReIMException("error.cannot_serach_for_status_update", Severity.ERROR, e,
                    this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_lines_to_cost_matched",
                        Severity.ERROR, e, this);
            }
        }
    }

    private List buildVatDiscrepancies(ResultSet rs) throws SQLException {
        List vatDiscrepancies = new ArrayList();
        VatDiscrepancy currentVatDiscrepancy = null;
        while (rs.next()) {
            currentVatDiscrepancy = new VatDiscrepancy(new Long(rs.getLong(1)), rs.getString(2),
                    new Location(rs.getString(3), rs.getString(4), rs.getString(5)), rs
                            .getString(6), rs.getDouble(7), rs.getString(8), new ReIMDate(rs
                            .getDate(9)), rs.getString(10), rs.getString(11), new ReIMDate(rs
                            .getDate(12)), rs.getString(13), rs.getString(14));
            vatDiscrepancies.add(currentVatDiscrepancy);
        }
        return vatDiscrepancies;
    }

    protected static final String SELECT_VAT_DISCREPANCIES_STORE = " SELECT DH.DOC_ID,"
            + "\n\t 	   DH.TYPE," + "\n\t 	   DH.LOCATION,"
            + "\n\t 	   S.STORE_NAME LOCATION_NAME," + "\n\t 	   DH.LOC_TYPE,"
            + "\n\t 	   DH.CURRENCY_CODE," + "\n\t 	   DH.TOTAL_COST," + "\n\t 	   DH.ORDER_NO,"
            + "\n\t 	   DH.TAX_DISC_CREATE_DATE," + "\n\t 	   DH.VENDOR," + "\n\t 	   SP.SUP_NAME,"
            + "\n\t 	   DH.DUE_DATE," + "\n\t 	   COUNT(ID.ITEM)," + "\n\t 	   DH.EXT_DOC_ID"
            + "\n\t      FROM IM_DOC_HEAD DH," + "\n\t   	   IM_INVOICE_DETAIL ID,"
            + "\n\t 	   SUPS SP," + "\n\t    	   STORE S" + "\n\t  WHERE DH.DOC_ID = ID.DOC_ID (+)"
            + "\n\t    AND DH.VENDOR_TYPE = 'SUPP'" + "\n\t    AND DH.VENDOR = SP.SUPPLIER"
            + "\n\t    AND DH.LOC_TYPE = '" + ReIMConstants.STORE + "'"
            + "\n\t    AND DH.LOCATION = S.STORE" + "\n\t    AND ID.TAX_DISCREPANCY_IND (+) = 'Y'";

    protected static final String GROUP_BY_VAT_DISCREPANCIES_STORE = " \n GROUP BY DH.DOC_ID,"
            + " \n \t  	 DH.TYPE," + "  \n \t    	 DH.LOCATION," + "  \n \t    	 S.STORE_NAME,"
            + "  \n \t    	 DH.LOC_TYPE," + "  \n \t    	 DH.CURRENCY_CODE,"
            + "  \n \t    	 DH.TOTAL_COST," + "  \n \t    	 DH.ORDER_NO,"
            + "  \n \t       DH.TAX_DISC_CREATE_DATE," + "  \n \t    	 DH.VENDOR,"
            + "  \n \t 	 	 SP.SUP_NAME, " + "  \n\t 	   DH.DUE_DATE," + "  \n \t 	 	 DH.EXT_DOC_ID";

    protected static final String SELECT_VAT_DISCREPANCIES_WH = " SELECT DH.DOC_ID,"
            + "\n\t 	   DH.TYPE," + "\n\t 	   DH.LOCATION," + "\n\t 	   W.WH_NAME LOCATION_NAME,"
            + "\n\t 	   DH.LOC_TYPE," + "\n\t 	   DH.CURRENCY_CODE," + "\n\t 	   DH.TOTAL_COST,"
            + "\n\t 	   DH.ORDER_NO," + "\n\t 	   DH.TAX_DISC_CREATE_DATE," + "\n\t 	   DH.VENDOR,"
            + "\n\t 	   SP.SUP_NAME," + "\n\t 	   DH.DUE_DATE," + "\n\t 	   COUNT(ID.ITEM),"
            + "\n\t 	   DH.EXT_DOC_ID" + "\n\t      FROM IM_DOC_HEAD DH,"
            + "\n\t   	   IM_INVOICE_DETAIL ID," + "\n\t 	   SUPS SP," + "\n\t    	   WH W"
            + "\n\t  WHERE DH.DOC_ID = ID.DOC_ID (+)" + "\n\t    AND DH.VENDOR_TYPE = 'SUPP'"
            + "\n\t    AND DH.VENDOR = SP.SUPPLIER" + "\n\t    AND DH.LOC_TYPE = '"
            + ReIMConstants.WH + "'" + "\n\t    AND DH.LOCATION = W.WH"
            + "\n\t    AND ID.TAX_DISCREPANCY_IND (+) = 'Y'";

    protected static final String GROUP_BY_VAT_DISCREPANCIES_WH = " \n GROUP BY DH.DOC_ID,"
            + " \n \t  	 DH.TYPE," + "  \n \t    	 DH.LOCATION," + "  \n \t    	 W.WH_NAME,"
            + "  \n \t    	 DH.LOC_TYPE," + "  \n \t    	 DH.CURRENCY_CODE,"
            + "  \n \t    	 DH.TOTAL_COST," + "  \n \t    	 DH.ORDER_NO,"
            + "  \n \t       DH.TAX_DISC_CREATE_DATE," + "  \n \t    	 DH.VENDOR,"
            + "  \n \t 	 	 SP.SUP_NAME, " + "  \n\t 	   DH.DUE_DATE," + "  \n \t 	 	 DH.EXT_DOC_ID";

    private static final String WHERE_VAT_DISCREPANCIES = "\n\t and DH.STATUS = '"
            + Document.TAX_DISCREPANCY + "'";

    public VatDiscrepancy[] getTaxDiscrepancies() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // set all invoice lines status to be updated to the invoices'
            // status
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_VAT_DISCREPANCIES_STORE
                    + WHERE_VAT_DISCREPANCIES + GROUP_BY_VAT_DISCREPANCIES_STORE + "\n UNION \n"
                    + SELECT_VAT_DISCREPANCIES_WH + WHERE_VAT_DISCREPANCIES
                    + GROUP_BY_VAT_DISCREPANCIES_WH);
            rs = stmt.executeQuery();
            List vatDiscrepancies = buildVatDiscrepancies(rs);

            return (VatDiscrepancy[]) vatDiscrepancies.toArray(new VatDiscrepancy[vatDiscrepancies
                    .size()]);

        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_vat_discrepancies", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_vat_discrepancies", Severity.ERROR,
                        exception, this);
            }
        }
    }

    private List buildTaxDiscrepancyDetails(ResultSet rs) throws SQLException {
        ArrayList vatDiscrepancyDetails = new ArrayList();
        TaxDiscrepancyDetail currentVatDiscrepancyDetail = null;
        while (rs.next()) {
            currentVatDiscrepancyDetail = new TaxDiscrepancyDetail(rs.getString(1),
                    rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs
                            .getString(6), rs.getString(7), rs.getString(8));
            vatDiscrepancyDetails.add(currentVatDiscrepancyDetail);
        }
        return vatDiscrepancyDetails;
    }

    protected static final String RESOLVED_VAT_DISCREPANCY_SQL = "select tax_discrepancy_ind from IM_INVOICE_DETAIL where doc_id = ? and tax_discrepancy_ind = '"
            + ReIMConstants.YES + "'";

    public boolean doTaxDiscrepanciesExist(String docId) throws ReIMException {
        // select all details for the document id and see if any have a
        // tax_discrepancy_ind = 'Y'
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(RESOLVED_VAT_DISCREPANCY_SQL);
            stmt.setLong(1, Long.parseLong(docId));
            rs = stmt.executeQuery();
            boolean vatDiscrepanciesFound = false;
            if (rs.next()) {
                if (ReIMConstants.YES.equalsIgnoreCase(rs.getString(1))) {
                    vatDiscrepanciesFound = true;
                }
            }
            return vatDiscrepanciesFound;
        } catch (Exception exception) {
            throw new ReIMException("error.failed_to_get_vat_discrepancy_details", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.failed_to_get_vat_discrepancy_details",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private static final String QTY_DISC = " select case when (iid.unit_cost - ss.unit_cost) = 0 then\n" + 
    "       (iid.unit_cost * iid.invoice_qty- ss.unit_cost * ss.qty_received ) \n" + 
    "       when (iid.invoice_qty  - ss.qty_received) < 0 then\n" + 
    "        -1 * abs(iid.unit_cost * iid.invoice_qty- ss.unit_cost * ss.qty_received ) \n" + 
    "        else (iid.unit_cost * iid.invoice_qty- ss.unit_cost * ss.qty_received ) \n" + 
    "       end eff_qty\n" + 
    "    from im_invoice_detail iid,\n" + 
    "         im_doc_head idh,\n" + 
    "         shipment sh,\n" + 
    "         shipsku ss\n" + 
    "   where iid.doc_id = idh.doc_id \n" + 
    "     and idh.doc_id = ? \n" + 
    "     and idh.order_no = ?\n" + 
    "     and sh.order_no = idh.order_no\n" + 
    "     and sh.bill_to_loc = idh.location\n" + 
    "     and ss.shipment = sh.shipment\n" + 
    "     and ss.item = iid.item\n" + 
    "     and idh.location = ?\n" + 
    "     and iid.item = ? ";
    
    public double getQtyDisc (String docId, String orderNo, String loc, String item ) throws ReIMException {
       
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(QTY_DISC);
            
            stmt.setString(1, docId);
            stmt.setString(2, orderNo);
            stmt.setString(3, loc);
            stmt.setString(4, item);

            rs = stmt.executeQuery();
            
            while (rs.next()) {
                double effQty = rs.getDouble("EFF_QTY");
                
               return effQty;
            }
            return 0;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                        Severity.ERROR, e, this);
            }
        }
    }
    
    private static final String COST_DISC = " select case when (iid.invoice_qty - ss.qty_received) = 0 then\n" + 
    "       ( (iid.unit_cost * iid.invoice_qty) - (ss.unit_cost * ss.qty_received )) \n" + 
    "       when (iid.unit_cost  - ss.unit_cost) < 0 then\n" + 
    "        -1 * abs(iid.unit_cost * iid.invoice_qty- ss.unit_cost * ss.qty_received ) \n" + 
    "        else (iid.unit_cost * iid.invoice_qty- ss.unit_cost * ss.qty_received ) \n" + 
    "       end eff_cost\n" + 
    "    from im_invoice_detail iid,\n" + 
    "         im_doc_head idh,\n" + 
    "         shipment sh,\n" + 
    "         shipsku  ss  \n" + 
//    "         shipsku AS OF TIMESTAMP TO_TIMESTAMP('2012-08-01 03:01:00', 'YYYY-MM-DD HH24:MI:SS') ss  \n" +
    "   where iid.doc_id = idh.doc_id\n" + 
    "     and idh.doc_id = ? \n" + 
    "     and idh.order_no = ?\n" + 
    "     and sh.order_no = idh.order_no\n" + 
    "     and sh.bill_to_loc = idh.location\n" + 
    "     and ss.shipment = sh.shipment\n" + 
    "     and ss.item = iid.item\n" + 
    "     and idh.location = ?\n" + 
    "     and iid.item = ? ";
    
    public double getCostDisc (String docId, String orderNo, String loc, String item ) throws ReIMException {
       
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        double effCost = 0.0;
        String effCost2 ;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(COST_DISC);
            
            stmt.setString(1, docId);
            stmt.setString(2, orderNo);
            stmt.setString(3, loc);
            stmt.setString(4, item);

            rs = stmt.executeQuery();
            
            while (rs.next()) {
            	effCost = rs.getDouble("EFF_COST");
            	effCost2 = rs.getString ("EFF_COST");
                
               return rs.getDouble("EFF_COST");
            }
            return 0;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                        Severity.ERROR, e, this);
            }
        }
    }
    
    public boolean areTaxDiscrepanciesExist(String docId) throws ReIMException {
        return this.doTaxDiscrepanciesExist(docId);
    }

    public VatDiscrepancy[] getVatDiscrepancies() throws ReIMException {
        // TODO Auto-generated method stub
        return null;
    }

}
