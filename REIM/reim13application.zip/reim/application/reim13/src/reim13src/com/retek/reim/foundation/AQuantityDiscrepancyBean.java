package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.business.DiscrepancyQuantityReview;
import com.retek.reim.business.Location;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;

public abstract class AQuantityDiscrepancyBean {
    private static final String COMMON_GROUP_ORDER = " QD.DOC_ID,\n " 
            + " QD.SUPPLIER, \n" + " QD.ORDER_NO,\n " + " QD.LOCATION, \n" + " QD.LOC_TYPE, \n"
            + " QD.AP_REVIEWER\n ";

    /**
     * getQuantityDiscrepancies method will return an array of DiscrepancyQuantityReview objects to
     * be used/parsed at the middle tier. This will pretty much grab everything that is needed for
     * the UI layer to display in one SQL statement other than the actual discrepant quantity.
     * 
     * @param roleId
     *            the role associated with the user
     * @param privilege
     *            the privelege that user has (ALL or USER)
     * 
     * @return DiscrepanyQuantityReview[] an array of business objects to be turned into UI objects
     * 
     * @throws ReIMException
     */

    public DiscrepancyQuantityReview[] getQuantityDiscrepancies(long roleId, String privilege,
            String docId) throws ReIMException {
        ResultSet rs = null;
        OraclePreparedStatement stmt = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            String additionalWhereClause = "";
            String whereClauseToBePassedOn = "";
            boolean docIdPopulated = false;

            if (privilege != null && privilege.trim().length() > 0) {
                if (privilege.equalsIgnoreCase(ReIMConstants.USER)) {
                    additionalWhereClause += " AND QDRO.BUSINESS_ROLE_ID = ? ";
                    whereClauseToBePassedOn = " AND EXISTS (SELECT 'x' "
                            + " FROM IM_QTY_DISCREPANCY_ROLE QDRO "
                            + " WHERE QDRO.QTY_DISCREPANCY_ID = QD.QTY_DISCREPANCY_ID "
                            + " AND QDRO.BUSINESS_ROLE_ID = ?) ";
                }
            }

            if (docId != null) {
                additionalWhereClause += " AND DH.DOC_ID = ? ";
                whereClauseToBePassedOn += " AND QD.DOC_ID = ? ";
                docIdPopulated = true;
            }

            StringBuffer buffer = new StringBuffer();
            buffer.append("SELECT /*+ all_rows index(dh, pk_im_doc_head) use_nl ( qd, dh)  use_nl (dh, qty) cardinality (qd, 10) */ QD.DOC_ID,\n");
            buffer.append("       MIN(QD.RESOLVE_BY_DATE) RESOLVE_BY_DATE,\n");
            buffer.append("    QD.SUPPLIER,\n");
            buffer.append("       S.SUP_NAME,\n");
            buffer.append("    QD.LOCATION,\n");
            buffer.append("    QD.LOC_TYPE,\n");
            buffer.append("    QD.ORDER_NO,\n");
            buffer.append("    DH.FREIGHT_TYPE,\n");
            buffer.append("    DH.EXT_DOC_ID,\n");
            buffer.append("    SUM(QD.QTY_INVOICED) QTY_INVOICED,\n");
            buffer.append("    SUM(NVL(QTY.QTY_RECEIVED,0)) QTY_RECEIVED,\n");
            buffer.append("    DH.DOC_DATE,\n");
            buffer.append("    DH.TOTAL_COST,\n");
            buffer.append("    DH.CURRENCY_CODE,\n");
            buffer.append("    QD.AP_REVIEWER,\n");
            buffer.append("    DH.TYPE,\n");
            buffer.append("    QDRO.BUSINESS_ROLE_ID,\n");
            buffer.append("    BR.BUSINESS_ROLE_NAME,\n");
            buffer.append("    DH.TOTAL_QTY, \n");
            buffer.append("    NVL(MTCH.MATCH_QTY,0) QTY_MATCHED  \n");
            buffer.append("  FROM IM_QTY_DISCREPANCY QD,\n");
            buffer.append("       IM_DOC_HEAD DH,\n");
            buffer.append("    IM_BUSINESS_ROLES BR,\n");
            buffer.append("       IM_QTY_DISCREPANCY_ROLE QDRO,\n");
            buffer.append("    SUPS S,\n");
            buffer
                    .append("      (SELECT /*+ use_nl (qd, qr)  index( qd, PK_IM_QTY_DISCREPANCY ) cardinality(qd,10) */ SUM(SHP.QTY_RECEIVED) - NVL(MRI.QTY_MATCHED, 0) QTY_RECEIVED,\n");
            buffer.append("            QD.QTY_DISCREPANCY_ID QTY_DISCREPANCY_ID\n");
            buffer.append("          FROM  IM_QTY_DISCREPANCY_RECEIPT QR,\n");
            buffer.append("             IM_QTY_DISCREPANCY QD,  \n");
            buffer.append("             v_im_shipsku SHP,  \n");
            buffer.append("             IM_PARTIALLY_MATCHED_RECEIPTS MRI\n");
            buffer.append("         WHERE  QD.QTY_DISCREPANCY_ID = QR.QTY_DISCREPANCY_ID\n");
            buffer.append("           AND  QR.RECEIPT_ID = SHP.SHIPMENT   \n");
            buffer.append("        AND  QD.ITEM = SHP.ITEM     \n");
            buffer.append("        AND  MRI.SHIPMENT (+) = SHP.SHIPMENT   \n");
            buffer.append("        AND  MRI.ITEM (+) = SHP.ITEM   \n");
            buffer.append("      GROUP BY QD.QTY_DISCREPANCY_ID, \n");
            buffer.append("               MRI.QTY_MATCHED) QTY,      \n");
            buffer.append("    (SELECT /*+ index(ID, PK_IM_INVOICE_DETAIL)  */\n");
            buffer.append("            SUM(ID.INVOICE_QTY) MATCH_QTY,  \n");
            buffer.append("            ID.DOC_ID  \n");
            buffer.append("       FROM IM_INVOICE_DETAIL ID,\n");
            buffer.append("            IM_QTY_DISCREPANCY QD\n");
            buffer
                    .append("        WHERE id.doc_id in (select distinct doc_id from im_qty_discrepancy)\n");
            buffer.append("        AND (ID.STATUS = 'MTCH' OR ID.QTY_MATCHED = 'Y')     \n");
            buffer.append("        and id.doc_id = qd.doc_id \n");
          //  buffer.append("        and qd.item is null\n");
            buffer.append("        and id.item = qd.item      \n");
            buffer.append("      GROUP BY ID.DOC_ID) MTCH\n");
            buffer.append("  WHERE QD.DOC_ID = DH.DOC_ID    \n");
            buffer.append("    AND DH.STATUS != 'DELETE'\n");
            buffer.append("    AND BR.BUSINESS_ROLE_ID = QDRO.BUSINESS_ROLE_ID    \n");
            buffer.append(" AND S.SUPPLIER = DH.VENDOR    \n");
            buffer.append(" AND DH.VENDOR_TYPE = 'SUPP'   \n");
            buffer.append(" AND QDRO.QTY_DISCREPANCY_ID = QD.QTY_DISCREPANCY_ID    \n");
            buffer.append(" AND QD.QTY_DISCREPANCY_ID = QTY.QTY_DISCREPANCY_ID (+)    \n");
            buffer.append(" AND QD.DOC_ID = MTCH.DOC_ID (+)  \n");
            buffer.append(additionalWhereClause);
            buffer.append("\n GROUP BY \n");
            buffer.append(COMMON_GROUP_ORDER);
            buffer.append(",\n          QDRO.BUSINESS_ROLE_ID, \n");
            buffer.append("         BR.BUSINESS_ROLE_NAME, \n");
            buffer.append("         DH.EXT_DOC_ID, \n");
            buffer.append("         DH.FREIGHT_TYPE, \n");
            buffer.append("         DH.DOC_DATE, \n");
            buffer.append("         DH.TOTAL_COST, \n");
            buffer.append("         DH.CURRENCY_CODE, \n");
            buffer.append("         DH.TYPE, \n");
            buffer.append("         S.SUP_NAME, \n");
            buffer.append("         DH.TOTAL_QTY, \n");
            buffer.append("         MTCH.MATCH_QTY \n");
            buffer.append("  ORDER BY 1, 2, 3, 4, 6, 13, 15, 16\n");
            stmt = (OraclePreparedStatement) conn.prepareStatement(buffer.toString());

            if (privilege.equalsIgnoreCase(ReIMConstants.USER)) {
                stmt.setLong(1, roleId);
                if (docIdPopulated) {
                    stmt.setString(2, docId);
                }
            } else {
                if (docIdPopulated) {
                    stmt.setString(1, docId);
                }
            }

            rs = stmt.executeQuery();

            AShipSkuBean shipSkuBean = (AShipSkuBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.AShipSkuBean);
            HashMap receiptQuantities = shipSkuBean
                    .getDiscrepancyReceiptQtySum(whereClauseToBePassedOn, COMMON_GROUP_ORDER,
                            (privilege.equalsIgnoreCase(ReIMConstants.USER) ? Long.valueOf(roleId)
                                    : null), docId);

            ArrayList dqReviews = new ArrayList();
            DiscrepancyQuantityReview discrepancyQtyReviewObj = null;
            Location location = null;

            HashMap reviewerGroups = null;

            StringBuffer orderNoStringList = new StringBuffer();
            String listSeparator = ", ";
            String previousDocId = "";

            reviewerGroups = new HashMap();

            while (rs.next()) {
                if (!previousDocId.equals(rs.getString("DOC_ID"))) {
                    previousDocId = rs.getString("DOC_ID");

                    // finish creating the previous object and add to the list
                    if (!rs.isFirst()) {
                        discrepancyQtyReviewObj.setReviewerGroups(reviewerGroups);
                        dqReviews.add(discrepancyQtyReviewObj);
                        reviewerGroups = new HashMap();
                    }

                    // and then start clean.
                    location = null;
                    rs.getString("LOCATION");

                    if (!rs.wasNull()) {
                        location = new Location();
                        location.setLocationId(rs.getString("LOCATION"));
                        location.setLocationType(rs.getString("LOC_TYPE"));
                    }

                    ReIMDate date = new ReIMDate(rs.getDate("RESOLVE_BY_DATE"));

                    discrepancyQtyReviewObj = new DiscrepancyQuantityReview();
                    discrepancyQtyReviewObj.setResolveByDate(date);
                    discrepancyQtyReviewObj.setSupplier(rs.getString("SUPPLIER"));
                    discrepancyQtyReviewObj.setSupplierName(rs.getString("SUP_NAME"));

                    discrepancyQtyReviewObj.setDocId(rs.getLong("DOC_ID"));
                    discrepancyQtyReviewObj.setDocumentType(rs.getString("TYPE"));
                    discrepancyQtyReviewObj.setLocation(location);
                    discrepancyQtyReviewObj.setOrderId(rs.getString("ORDER_NO"));
                    discrepancyQtyReviewObj.setFreightPaymentType(rs.getString("FREIGHT_TYPE"));
                    discrepancyQtyReviewObj.setExternalDocId(rs.getString("EXT_DOC_ID"));
                    discrepancyQtyReviewObj.setDocumentDate(new ReIMDate(rs.getDate("DOC_DATE")));
                    discrepancyQtyReviewObj.setTotalDocumentAmount(rs.getDouble("TOTAL_COST"));
                    discrepancyQtyReviewObj.setCurrencyCode(rs.getString("CURRENCY_CODE"));
                    discrepancyQtyReviewObj.setOrderComments(null);
                    // comments ind
                    discrepancyQtyReviewObj.setApReviewer(rs.getString("AP_REVIEWER"));

                    if (orderNoStringList.length() > 0) {
                        orderNoStringList.append(listSeparator);
                    }
                    orderNoStringList.append(discrepancyQtyReviewObj.getOrderId());

                    Double qty;
                    StringBuffer mapKey = new StringBuffer();
                    mapKey.append(discrepancyQtyReviewObj.getDocId());
                    mapKey.append(discrepancyQtyReviewObj.getResolveByDate().toString());
                    mapKey.append(discrepancyQtyReviewObj.getSupplier());
                    if (discrepancyQtyReviewObj.getOrderId() != null) {
                        mapKey.append(discrepancyQtyReviewObj.getOrderId());
                    }
                    if (discrepancyQtyReviewObj.getLocation() != null) {
                        mapKey.append(discrepancyQtyReviewObj.getLocation().getLocationId());
                        mapKey.append(discrepancyQtyReviewObj.getLocation().getLocationType());
                    }
                    mapKey.append(discrepancyQtyReviewObj.getApReviewer());

                    if (privilege.equals(ReIMConstants.ALL)) {
                        qty = new Double(rs.getDouble("QTY_RECEIVED")
                                - (rs.getDouble("QTY_INVOICED") - rs.getDouble("QTY_MATCHED")));
                    } else {
                        if (receiptQuantities.containsKey(mapKey.toString())) {
                            qty = new Double(((Double) receiptQuantities.get(mapKey.toString()))
                                    .doubleValue()
                                    - rs.getDouble("QTY_INVOICED"));
                        } else {
                            qty = new Double(rs.getDouble("QTY_RECEIVED")
                                    - rs.getDouble("QTY_INVOICED"));
                        }
                    }
                    discrepancyQtyReviewObj.setQuantityDifference(qty);
                }

                reviewerGroups.put(Long.valueOf(rs.getLong("BUSINESS_ROLE_ID")), rs
                        .getString("BUSINESS_ROLE_NAME"));
            }

            if (discrepancyQtyReviewObj == null) { return null; }
            discrepancyQtyReviewObj.setReviewerGroups(reviewerGroups);
            dqReviews.add(discrepancyQtyReviewObj);

            return (DiscrepancyQuantityReview[]) dqReviews
                    .toArray(new DiscrepancyQuantityReview[dqReviews.size()]);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException(
                    "error.im_qty_discrepancy_access_ext.read_discrepancies_by_role",
                    Severity.ERROR, e, this);
        }

        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new ReIMException(
                        "error.im_qty_discrepancy_access_ext.read_discrepancies_by_role.close_stmt_rs",
                        Severity.ERROR, e, this);
            }
        }
    }
}
