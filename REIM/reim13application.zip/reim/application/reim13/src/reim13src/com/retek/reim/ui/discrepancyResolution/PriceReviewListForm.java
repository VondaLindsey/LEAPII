package com.retek.reim.ui.discrepancyResolution;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import oracle.retail.reim.utils.Affirm;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.document.Document;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.I18NService;
import com.retek.reim.services.ServiceFactory;

public class PriceReviewListForm extends ActionForm {
    private static final String UNCALCULATED = ReIMI18NUtility.getWidget("label.uncalculated");

    private PriceReview[] priceReviewList;
    private PriceReviewDetail[] priceReviewDetail;
    // parameters for both review list details and cost selection
    private String docId, orderId, locationName, location, currency, refDocId;
    // referenced by jsp so do not remove

    // Deal header data
    DealDetailView[] dealDetails = null;
    private double totalDiscountValue;
    private String totalDiscountValueFormatted = UNCALCULATED;
    private double supplierCostUOP;
    private String supplierCostUOPFormatted = UNCALCULATED;
    private double projectedOrderCostUOP;
    private String projectedOrderCostUOPFormatted = UNCALCULATED;
    private String originCountryId;
    private String item;

    // parameters for review list details
    private String department, deptName, classId, className, supplier, supplierName;
    private String resolveByDate, documentType, routingDate, cashDiscount;

    // parameters for Price review list cost Selection
    private String currentOrdCost, docCost, resolutionCost, selectedItem, selectedItemDesc,
            selectedDebitMemoReasonCode, selectedCostDiscrepancyId;

    private String selectedCost;
    private String otherCost = "";
    private String permission = "NONE";

    public static final String ORDER_COST = "ORDER";
    public static final String INVOICE_COST = "INVOICE";
    public static final String OTHER_COST = "OTHER";
    public static final String CREDIT_MEMO_COST = "CREDIT";

    public static final String RESOLUTION_WITHIN_TOLERANCE = "TOLERANCE";
    public static final String RESOLUTION_TO_ZERO = "ZERO";

    public static final String SAVE_ACTION_OK = "OK";
    public static final String SAVE_ACTION_APPLY_ALL = "APPLY_ALL";

    // parameters for price review variance resolution
    private double costVariance;
    private double outstandingCostVariance;
    private String costVarianceFormatted = UNCALCULATED;
    private String outstandingCostVarianceFormatted = UNCALCULATED;
    private String externalDocId = null;
    private String refExternalDocId = null;
    private String refDocumentType = null;
    private String saveAction = SAVE_ACTION_OK;
    private String businessRoleId = "";
    private ArrayList receipts = null;

    private String reasonCodeLOV = null;
    private String reasonCodeLOVDesc = null;
    private String reasonCodeLOVActionDesc = null;
    private String reasonCodeLOVAction = null;
    private String applyAmount = null;
    private String costRoleLOV = null;
    private String costRoleLOVDesc = null;
    private String commentRequired = null;
    private String commentsExist = ReIMConstants.NO;
    private String hintComment = null;
    private VarianceResolution[] resolutionDetails = null;
    private String varianceIsZeroOrReroute = null;
    private String deletedRecs = null;

    private String backPage = "";
    public boolean reloadPage = true;

    public void reset(ActionMapping mapping, HttpServletRequest request) {
        super.reset(mapping, request);
    }

    public void resetVarianceApplyFields() {
        this.reasonCodeLOV = null;
        this.reasonCodeLOVDesc = null;
        this.reasonCodeLOVAction = null;
        this.reasonCodeLOVActionDesc = null;
        this.commentRequired = null;
        this.commentsExist = ReIMConstants.NO;
        this.hintComment = null;
        this.applyAmount = null;
        this.costRoleLOV = null;
        this.costRoleLOVDesc = null;
        this.saveAction = SAVE_ACTION_OK;
    }

    public void resetVarianceResolutions() {
        resetVarianceApplyFields();
        this.resolutionDetails = null;
        this.deletedRecs = null;
    }

    // ********************************************************************************************************
    // Getter and Setter Methods

    public PriceReview[] getPriceReviewList() {
        return priceReviewList;
    }

    public void setPriceReviewList(PriceReview[] priceReviewList) {
        this.priceReviewList = priceReviewList;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public PriceReviewDetail[] getPriceReviewDetail() {
        return priceReviewDetail;
    }

    public void setPriceReviewDetail(PriceReviewDetail[] priceReviewDetail) {
        this.priceReviewDetail = priceReviewDetail;
    }

    public String getClassName() {
        return className;
    }

    public String getCurrency() {
        return currency;
    }

    public String getDeptName() {
        return deptName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public String getDocumentTypeDesc() {
        return ServiceFactory.getDocumentService().getDocumentTypeDescription(documentType);
    }

    public String getLocation() {
        return location;
    }

    public String getResolveByDate() {
        return resolveByDate;
    }

    public String getSupplier() {
        return supplier;
    }

    public String getOtherCost() {
        return otherCost;
    }

    public String getSelectedCost() {
        return selectedCost;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setResolveByDate(String resolveByDate) {
        this.resolveByDate = resolveByDate;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public void setOtherCost(String otherCost) {
        this.otherCost = otherCost;
    }

    public void setSelectedCost(String selectedCost) {
        this.selectedCost = selectedCost;
    }

    public String getClassId() {
        return classId;
    }

    public String getDepartment() {
        return department;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLocationName() {
        return locationName;
    }

    public String getDecodedLocationName() throws ReIMException {
        if (StringUtils.isNotEmpty(locationName)) {
            return I18NService.decodeString(locationName);
        } else {
            return locationName;
        }
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public void setSelectedItem(String item) {
        this.selectedItem = item;
    }

    public String getCurrentOrdCost() {
        return currentOrdCost;
    }

    public String getDocCost() {
        return docCost;
    }

    public String getResolutionCost() {
        return resolutionCost;
    }

    public void setCurrentOrdCost(String currentOrdCost) {
        this.currentOrdCost = currentOrdCost;
    }

    public void setDocCost(String docCost) {
        this.docCost = docCost;
    }

    public void setResolutionCost(String resolutionCost) {
        this.resolutionCost = resolutionCost;
    }

    public String getSelectedItem() {
        return selectedItem;
    }

    public String getSelectedItemDesc() {
        return selectedItemDesc;
    }

    public void setSelectedItemDesc(String selectedItemDesc) {
        this.selectedItemDesc = selectedItemDesc;
    }

    public String getDecodedSupplierName() throws ReIMException {
        if (StringUtils.isNotEmpty(supplierName)) {
            return I18NService.decodeString(supplierName);
        } else {
            return supplierName;
        }
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getCashDiscount() {
        return cashDiscount;
    }

    public String getRoutingDate() {
        return routingDate;
    }

    public void setCashDiscount(String cashDiscount) {
        this.cashDiscount = cashDiscount;
    }

    public void setRoutingDate(String routingDate) {
        this.routingDate = routingDate;
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public String getReasonCodeLOV() {
        return reasonCodeLOV;
    }

    public void setReasonCodeLOV(String reasonCodeLOV) {
        this.reasonCodeLOV = reasonCodeLOV;
    }

    public String getReasonCodeLOVDesc() {
        return reasonCodeLOVDesc;
    }

    public void setReasonCodeLOVDesc(String reasonCodeLOVDesc) {
        this.reasonCodeLOVDesc = reasonCodeLOVDesc;
    }

    public String getReasonCodeLOVActionDesc() {
        return reasonCodeLOVActionDesc;
    }

    public void setReasonCodeLOVActionDesc(String reasonCodeLOVActionDesc) {
        this.reasonCodeLOVActionDesc = reasonCodeLOVActionDesc;
    }

    public String getApplyAmount() {
        return applyAmount;
    }

    public void setApplyAmount(String applyAmount) {
        this.applyAmount = applyAmount;
    }

    public VarianceResolution[] getResolutionDetails() {
        return resolutionDetails;
    }

    public void setResolutionDetails(VarianceResolution[] resolutionDetails) {
        this.resolutionDetails = resolutionDetails;
    }

    public boolean checkDupReasonCodes() {
        VarianceResolution[] resolutionList = getResolutionDetails();
        int resolutionListLength = (resolutionList != null ? resolutionList.length : 0);
        if (resolutionListLength > 0) {
            for (int i = 0; i < resolutionListLength; i++) {
                if (this.reasonCodeLOV.equalsIgnoreCase(resolutionList[i].getReasonCode()))
                    return true;
            }
        }
        return false;
    }

    public String getDeletedRecs() {
        return deletedRecs;
    }

    public void setDeletedRecs(String deletedRecs) {
        this.deletedRecs = deletedRecs;
    }

    public DealDetailView[] getDealDetails() {
        return dealDetails;
    }

    public void setDealDetails(DealDetailView[] dealDetails) {
        this.dealDetails = dealDetails;
    }

    public double getTotalDiscountValue() {
        return totalDiscountValue;
    }

    public void setTotalDiscountValue(double totalDiscountValue) {
        this.totalDiscountValue = totalDiscountValue;
        this.totalDiscountValueFormatted = UNCALCULATED;
    }

    public double getSupplierCostUOP() {
        return supplierCostUOP;
    }

    public void setSupplierCostUOP(double supplierCostUOP) {
        this.supplierCostUOP = supplierCostUOP;
        this.supplierCostUOPFormatted = UNCALCULATED;
    }

    public double getProjectedOrderCostUOP() {
        return projectedOrderCostUOP;
    }

    public void setProjectedOrderCostUOP(double projectedOrderCostUOP) {
        this.projectedOrderCostUOP = projectedOrderCostUOP;
    }

    public String getOriginCountryId() {
        return originCountryId;
    }

    public void setOriginCountryId(String originCountryId) {
        this.originCountryId = originCountryId;
    }

    public String getReasonCodeLOVAction() {
        return reasonCodeLOVAction;
    }

    public void setReasonCodeLOVAction(String reasonCodeLOVAction) {
        this.reasonCodeLOVAction = reasonCodeLOVAction;
    }

    public String getCommentRequired() {
        return commentRequired;
    }

    public String getCommentsExist() {
        return commentsExist;
    }

    public void setCommentRequired(String commentRequired) {
        this.commentRequired = commentRequired;
    }

    public void setCommentsExist(String commentsExist) {
        this.commentsExist = commentsExist;
    }

    public String getHintComment() {
        return hintComment;
    }

    public void setHintComment(String hintComment) {
        this.hintComment = hintComment;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getVarianceResolutionLevel() {
        if (documentType.equals(Document.MERCHANDISE_INVOICE)) {
            return RESOLUTION_WITHIN_TOLERANCE;
        } else {
            return RESOLUTION_TO_ZERO;
        }
    }

    public String getReasonCodeType() {
        return ReasonCode.COST_DISCREPANCY;
    }

    public double getCostVariance() {
        return costVariance;
    }

    public String getCostVarianceFormatted() {
        return costVarianceFormatted;
    }

    public double getOutstandingCostVariance() {
        return outstandingCostVariance;
    }

    public String getOutstandingCostVarianceFormatted() {
        return outstandingCostVarianceFormatted;
    }

    public void setCostVariance(double costVariance) {
        this.costVariance = costVariance;
        setCostVarianceFormatted(UNCALCULATED);
    }

    public void setCostVarianceFormatted(String costVarianceFormatted) {
        this.costVarianceFormatted = costVarianceFormatted;
    }

    public void setOutstandingCostVariance(double outstandingCostVariance) {
        this.outstandingCostVariance = outstandingCostVariance;
        setOutstandingCostVarianceFormatted(UNCALCULATED);
    }

    public void setOutstandingCostVarianceFormatted(String outstandingCostVarianceFormatted) {
        this.outstandingCostVarianceFormatted = outstandingCostVarianceFormatted;
    }

    public String getSupplierCostUOPFormatted() {
        return supplierCostUOPFormatted;
    }

    public void setSupplierCostUOPFormatted(String supplierCostUOPFormatted) {
        this.supplierCostUOPFormatted = supplierCostUOPFormatted;
    }

    public String getProjectedOrderCostUOPFormatted() {
        return projectedOrderCostUOPFormatted;
    }

    public void setProjectedOrderCostUOPFormatted(String projectedOrderCostUOPFormatted) {
        this.projectedOrderCostUOPFormatted = projectedOrderCostUOPFormatted;
    }

    public String getTotalDiscountValueFormatted() {
        return totalDiscountValueFormatted;
    }

    public void setTotalDiscountValueFormatted(String totalDiscountValueFormatted) {
        this.totalDiscountValueFormatted = totalDiscountValueFormatted;
    }

    public String getCostRoleLOV() {
        return costRoleLOV;
    }

    public void setCostRoleLOV(String costRoleLOV) {
        this.costRoleLOV = costRoleLOV;
    }

    public String getReviewerGroup() {
        return new Long(ReIMUserContext.getUserRole().getBusinessRoleId()).toString();
    }

    public String getExternalDocId() {
        return externalDocId;
    }

    public String getRefDocumentType() {
        return refDocumentType;
    }

    public String getRefDocumentTypeDesc() {
        if (refDocumentType != null) {
            return ServiceFactory.getDocumentService().getDocumentTypeDescription(refDocumentType);
        } else {
            return "";
        }
    }

    public String getRefExternalDocId() {
        if (refExternalDocId != null) {
            return refExternalDocId;
        } else {
            return "";
        }
    }

    public String getSaveAction() {
        return saveAction;
    }

    public void setExternalDocId(String externalDocId) {
        this.externalDocId = externalDocId;
    }

    public void setRefDocumentType(String refDocumentType) {
        this.refDocumentType = refDocumentType;
    }

    public void setRefExternalDocId(String refExternalDocId) {
        this.refExternalDocId = refExternalDocId;
    }

    public String getSelectedDebitMemoReasonCode() {
        return selectedDebitMemoReasonCode;
    }

    public void setSelectedDebitMemoReasonCode(String selectedDebitMemoReasonCode) {
        this.selectedDebitMemoReasonCode = selectedDebitMemoReasonCode;
    }

    public String getSelectedCostDiscrepancyId() {
        return selectedCostDiscrepancyId;
    }

    public void setSelectedCostDiscrepancyId(String selectedCostDiscrepancyId) {
        this.selectedCostDiscrepancyId = selectedCostDiscrepancyId;
    }

    public String getBackPage() {
        return backPage;
    }

    public void setBackPage(String backPage) {
        this.backPage = backPage;
    }

    public String getCostRoleLOVDesc() {
        return costRoleLOVDesc;
    }

    public void setCostRoleLOVDesc(String costRoleLOVDesc) {
        this.costRoleLOVDesc = costRoleLOVDesc;
    }

    public void setSaveAction(String saveAction) {
        this.saveAction = saveAction;
    }

    public String getRefDocId() {
        return refDocId;
    }

    public void setRefDocId(String refDocId) {
        this.refDocId = refDocId;
    }

    public boolean isReloadPage() {
        return reloadPage;
    }

    public void setReloadPage(boolean b) {
        reloadPage = b;
    }

    public String getVarianceIsZeroOrReroute() {
        return varianceIsZeroOrReroute;
    }

    public void setVarianceIsZeroOrReroute(boolean rerouteActionExists) {
        if (this.outstandingCostVariance == 0 || rerouteActionExists) {
            this.varianceIsZeroOrReroute = Affirm.YES_IND;
        } else {
            this.varianceIsZeroOrReroute = Affirm.NO_IND;
        }
    }

    public String getVarianceSign() {
        return (outstandingCostVariance >= 0 ? ReIMConstants.POSITIVE : ReIMConstants.NEGATIVE);
    }

    public String getBusinessRoleId() {
        return businessRoleId;
    }

    public void setBusinessRoleId(String string) {
        businessRoleId = string;
    }

    public ArrayList getReceipts() {
        return receipts;
    }

    public void setReceipts(ArrayList list) {
        receipts = list;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getItem() {
        return item;
    }
}