package com.retek.reim.ui.discrepancyResolution;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.services.IVarianceResolutionService;
import oracle.retail.reim.services.ui.discrepancyResolution.IDiscrepancyResolutionUIService;
import oracle.retail.reim.services.ui.discrepancyResolution.IQuantityReviewListUIService;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.beans.factory.annotation.Autowired;

import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ResolutionMerchandiseInvoice;
import com.retek.reim.business.document.Document;
import com.retek.reim.locking.LockingData;
import com.retek.reim.locking.TableRecordLockingService;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.comments.CommentsForm;

public class QuantityReviewVarianceResolutionApplyAction extends ReIMSecureAction {

    private IQuantityReviewListUIService quantityReviewListUIService;
    private IVarianceResolutionService varianceResolutionService;
    private IDiscrepancyResolutionUIService discrepancyResolutionUIService;

    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        QuantityReviewListForm quantityReviewListForm = (QuantityReviewListForm) form;
        CommentsForm commentsForm = (CommentsForm) request.getSession()
                .getAttribute("commentsForm");
        String successMapping;
        String failureMapping;
        if (quantityReviewListForm.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
            successMapping = "successInvoice";
            failureMapping = "failureInvoice";
        } else {
            successMapping = "successDocument";
            failureMapping = "failureDocument";
        }

        try {
            // Check if the user still has the document locked without a
            // timeout, and then reset the
            // timeout
            String currentUserId = ReIMUserContext.getUsername();
            String docId = quantityReviewListForm.getDocId();
            String currentUserWithLock = ServiceFactory.getTableRecordLockingService()
                    .getUserIdLockingRecordOnTable(LockingData.DOC_HEAD_LOCK_TABLE,
                            Long.parseLong(docId));
            if (currentUserWithLock != null && currentUserWithLock.equals(currentUserId)) {
                TableRecordLockingService.refreshTimeStampOnLockTable(
                        LockingData.DOC_HEAD_LOCK_TABLE, Long.parseLong(docId));
            } else {
                saveErrors(request, errors, "alert.lock_expired");
                return mapping.findForward("failure");
            }

            // Check if the user still has the receipts locked without a
            // timeout, and then reset the
            // timeouts
            String[] receiptIds = quantityReviewListForm.getReceipts();
            for (int i = 0; i < receiptIds.length; i++) {
                currentUserWithLock = ServiceFactory.getTableRecordLockingService()
                        .getUserIdLockingRecordOnTable(LockingData.RECEIPT_LOCK_TABLE,
                                Long.parseLong(receiptIds[i]));
                if (currentUserWithLock != null && currentUserWithLock.equals(currentUserId)) {
                    TableRecordLockingService.refreshTimeStampOnLockTable(
                            LockingData.RECEIPT_LOCK_TABLE, Long.parseLong(receiptIds[i]));
                } else if (currentUserWithLock == null) {
                       currentUserWithLock = ServiceFactory.getTableRecordLockingService()
                                               .lockTableRecordForUser(LockingData.RECEIPT_LOCK_TABLE, currentUserId,
                                                       Long.parseLong(receiptIds[i]));
                         if (currentUserWithLock == null || !currentUserWithLock.equals(currentUserId)) {
                                            errors.add("error.receipt_locked_by_user", new ActionError(
                                                    "error.receipt_locked_by_user", receiptIds[i], currentUserWithLock));
                                            saveErrors(request, errors);
                                           
                                        }
                }
               else {
                    saveErrors(request, errors, "alert.lock_expired");
                    return mapping.findForward("failure");
                }
            }

            VarianceResolution[] previousResolutionList = quantityReviewListForm
                    .getResolutionDetails();

            Double applyAmount = null;
            String applyAmountFormatted = null;
            boolean gotoSplitReceipt = false;

            if (!quantityReviewListForm.getReasonCodeLOVAction().equals(
                    ReasonCode.REROUTE_QUANTITY_DISCREPANCY)) {
                // Check for split receipt...First time through there is no
                // amount (cannot be
                // entered on that screen).
                // For that first time through for split receipt the split
                // receipt screen will come
                // up. The OK
                // on split receipt calls this action again, having set the
                // resolution amount.
                // Second time through for split receipt there is an amount, and
                // the normal apply
                // logic will be used.
                if (quantityReviewListForm.getReasonCodeLOVAction().equals(
                        ResolutionMerchandiseInvoice.SR)) {
                    // If the reason code action is split receipt, then go to
                    // the split receipt
                    // screen
                    applyAmountFormatted = quantityReviewListForm.getApplyAmount();

                    if (applyAmountFormatted == null || applyAmountFormatted.length() == 0) {
                        gotoSplitReceipt = true;
                    }
                }

                if (gotoSplitReceipt == false) {
                    try {
                        applyAmount = new Double(ReIMQuantity.parseNumberString(
                                quantityReviewListForm.getApplyAmount()).doubleValue());
                    } catch (ReIMException e) {
                        saveErrors(request, errors, e);
                        return mapping.findForward(failureMapping);
                    }

                    applyAmountFormatted = getVarianceResolutionService().formatAmount(
                            applyAmount.doubleValue(), Resolution.TYPE_QUANTITY, null);
                }
            } else {
                if (previousResolutionList != null
                        && getDiscrepancyResolutionUIService().rerouteActionExists(
                                previousResolutionList) != null) {
                    saveErrors(request, errors, "error.reroute_already_applied");
                    return mapping.findForward(failureMapping);
                }
                applyAmountFormatted = "";
            }

            if (quantityReviewListForm.getReasonCodeLOVAction().equals(
                    ReasonCode.RECEIVER_UNIT_ADJUSTMENT)) {
                if (quantityReviewListForm.getSelectedReceipt() == null
                        || quantityReviewListForm.getSelectedReceipt().length() == 0) {
                    saveErrors(request, errors, "alert.please_enter_receipt");
                    return mapping.findForward(failureMapping);
                }
                double currentQty = getVarianceResolutionService().getReceiverAdjustmentCurrentQty(
                        quantityReviewListForm.getSelectedReceipt(),
                        quantityReviewListForm.getItem()).doubleValue();
                if ((currentQty - applyAmount.doubleValue()) < 0) {
                    errors.add("error.receipt_adjustment_to_negative_number", new ActionError(
                            "error.receipt_adjustment_to_negative_number", String
                                    .valueOf(currentQty)));
                    saveErrors(request, errors);
                    return mapping.findForward(failureMapping);
                }

                double otherAdjustedQty = 0;
                VarianceResolution[] appliedResoutions = quantityReviewListForm
                        .getResolutionDetails();
                if (appliedResoutions != null) {
                    // Search through all of the applied resolutions. If any
                    // resolutions exist for
                    // either split receipt or
                    // receiver unit adjustment and for the specific receipt
                    // this action is working
                    // with, then the actual
                    // quantity available needs to consider these existing
                    // pending adjustments.
                    for (int i = 0; i < appliedResoutions.length; i++) {
                        if ((appliedResoutions[i].getAction().equals(ReasonCode.SPLIT_RECEIPT) || appliedResoutions[i]
                                .getAction().equals(ReasonCode.RECEIVER_UNIT_ADJUSTMENT))
                                && (appliedResoutions[i].getReceiptId().equals(
                                        quantityReviewListForm.getSelectedReceipt()) || appliedResoutions[i]
                                        .getReceiptItems()[0].getReceiptId().equals(
                                        quantityReviewListForm.getSelectedReceipt()))) {
                            otherAdjustedQty = otherAdjustedQty
                                    + appliedResoutions[i].getAdjustedAmount().doubleValue();
                        }
                    }
                }

                // Return an error if the receiver unit adjustment is attempting
                // to adjust the
                // receipt's quantity to be
                // less than what has already been allocated for this
                // resolution.
                if (currentQty - applyAmount.doubleValue() - otherAdjustedQty < 0) {
                    errors.add("error.receipt_adjustment_to_negative_number", new ActionError(
                            "error.receipt_adjustment_to_negative_number", String
                                    .valueOf((currentQty - otherAdjustedQty))));
                    saveErrors(request, errors);
                    return mapping.findForward(failureMapping);
                }
            }

            if (quantityReviewListForm.checkDupReasonCodes()) {
                errors.add("error.duplicate_reason_code", new ActionError(
                        "error.duplicate_reason_code", quantityReviewListForm.getReasonCodeLOV()));
                saveErrors(request, errors);
                return mapping.findForward(failureMapping);
            }

            if (quantityReviewListForm.getCommentRequired().equals(ReIMConstants.YES)
                    && (commentsForm == null || commentsForm.getComments() == null || commentsForm
                            .getComments().length == 0)) {
                saveErrors(request, errors, "alert.comment_required");
                return mapping.findForward(failureMapping);
            }

            // If the reason code action is match invoice to receipt, then go to
            // the match invoice
            // to receipt screen
            if (quantityReviewListForm.getReasonCodeLOVAction().equals(
                    ResolutionMerchandiseInvoice.MR)) { return mapping
                    .findForward("matchInvoiceToReceipt"); }

            if (gotoSplitReceipt == true) {
                if (applyAmountFormatted == null || applyAmountFormatted.length() == 0) {
                    request.getSession().setAttribute("quantityReviewListForm",
                            quantityReviewListForm);
                    request.getSession().setAttribute("splitReceiptSource",
                            "QuantityReviewListForm");
                    return mapping.findForward("splitReceipt");
                }
            }

            int previousResolutionListLength = (previousResolutionList != null ? previousResolutionList.length
                    : 0);
            ArrayList newResolutionList = new ArrayList();

            for (int i = 0; i < previousResolutionListLength; i++) {
                newResolutionList.add(previousResolutionList[i]);
            }

            // create the variance resolution
            VarianceResolution varianceResolution = getQuantityReviewListUIService()
                    .applyQuantityVarianceResolution(quantityReviewListForm, applyAmount,
                            applyAmountFormatted, commentsForm);

            if (quantityReviewListForm.getReasonCodeLOVAction().equals(
                    ResolutionMerchandiseInvoice.SR)) {
                varianceResolution.setReceiptItems(new ReceiptItem[] { quantityReviewListForm
                        .getSplitReceiptItem()});
            }

            // add it to any existing resolutions
            newResolutionList.add(varianceResolution);

            quantityReviewListForm.setResolutionDetails((VarianceResolution[]) newResolutionList
                    .toArray(new VarianceResolution[newResolutionList.size()]));
            quantityReviewListForm.resetVarianceApplyFields();

            if (commentsForm != null) {
                // clean up and remove any existing comments
                request.getSession().removeAttribute("commentsForm");
            }

            getQuantityReviewListUIService().setVarianceValues(quantityReviewListForm);
            quantityReviewListForm.setVarianceIsZeroOrReroute(getDiscrepancyResolutionUIService()
                    .rerouteActionExists(quantityReviewListForm.getResolutionDetails()) != null);

            return mapping.findForward(successMapping);
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return mapping.findForward(failureMapping);
        } catch (Exception e) {
            ReIMException exception = new ReIMException("error.unable_to_apply_resolution",
                    Severity.ERROR, e, this);
            saveErrors(request, errors, exception);
            return (mapping.findForward(failureMapping));
        }
    }

    private IQuantityReviewListUIService getQuantityReviewListUIService() {

        return quantityReviewListUIService;
    }

    @Autowired
    public void setQuantityReviewListUIService(
            IQuantityReviewListUIService quantityReviewListUIService) {

        this.quantityReviewListUIService = quantityReviewListUIService;
    }

    private IVarianceResolutionService getVarianceResolutionService() {

        return varianceResolutionService;
    }

    @Autowired
    public void setVarianceResolutionService(IVarianceResolutionService varianceResolutionService) {

        this.varianceResolutionService = varianceResolutionService;
    }

    private IDiscrepancyResolutionUIService getDiscrepancyResolutionUIService() {

        return discrepancyResolutionUIService;
    }

    @Autowired
    public void setDiscrepancyResolutionUIService(
            IDiscrepancyResolutionUIService discrepancyResolutionUIService) {

        this.discrepancyResolutionUIService = discrepancyResolutionUIService;
    }
}
