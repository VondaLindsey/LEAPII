package com.retek.reim.ui.invoiceMaintenance;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.business.*;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.tax.VendorTaxes;
import oracle.retail.reim.services.IInvoiceDetailService;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.ObjectUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.business.InvoiceView;
import com.retek.reim.business.Item;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.UserRole;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.locking.LockingData;
import com.retek.reim.locking.LockingUtils;
import com.retek.reim.merch.utils.ReIMAttributeManager;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMPageCodes;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.nonMerchandiseEntry.NonMerchandiseDocumentDisplay;
import com.retek.reim.ui.utils.IdValuePair;

public final class InvoiceMaintenanceDetailAction extends ReIMSecureAction {
    protected boolean getPermission() {
        try {
            UserRole userRole = ReIMUserContext.getUserRole();

            if (userRole.getInvoiceEntry().equalsIgnoreCase(UserRole.EDIT)
                    || userRole.getInvoiceEntry().equalsIgnoreCase(UserRole.VIEW)
                    || userRole.getInvoiceEntry().equalsIgnoreCase(UserRole.MODIFY)) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            return false;
        }
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();

        try {
            InvoiceMaintenanceDetailForm detailForm = (InvoiceMaintenanceDetailForm) form;
            InvoiceMaintenanceHeaderForm headerForm = (InvoiceMaintenanceHeaderForm) request
                    .getSession().getAttribute("invoiceMaintenanceHeaderForm");
            InvoiceView iv = (InvoiceView) request.getSession().getAttribute("iv");
            String supplier = headerForm.getVendorLOV();
            String invoiceDate = headerForm.getInvoiceDate();
            ReIMDate invDate = null;
            try{
            	invDate = new ReIMDate(invoiceDate);
            }
            catch(Exception ex){
            	 saveErrors(request, errors, "Invalid.invoice_date");
            	  return (mapping.findForward("failure"));
            }
            if (!userStillHasLock(request, errors, headerForm)) { return mapping
                    .findForward("unauthorized_access"); }

            if (iv == null) {
                // create it and save it in the session --this will only happen
                // when in view mode
                iv = new InvoiceView(headerForm);
                ReIMAttributeManager.setAttribute(ReIMPageCodes.INVOICE_VIEW, "iv", iv);
            }

            if (headerForm.getMode().equals(MaintenanceForm.NEW)) {
                NonMerchandiseDocumentDisplay[] docNonMerchList = null;
                if (request.getSession().getAttribute("docNonMerchList") != null) {
                    docNonMerchList = (NonMerchandiseDocumentDisplay[]) request.getSession()
                            .getAttribute("docNonMerchList");
                }

                NonMerchandiseDocument[] nonMerchCosts = ServiceFactory
                        .getInvoiceMaintenanceService().getNonMerchDocArray(docNonMerchList);

                if (nonMerchCosts != null) {
                    iv.setNonMerchandiseDocuments(nonMerchCosts);
                }
            }

            if (headerForm.isTaxEnabled() && headerForm.getMode().equals(MaintenanceForm.NEW)) {
                headerForm.setEnteredTotalCostIncTaxDouble(ReIMMoney
                        .parseCurrencyString(headerForm.getEnteredTotalCostIncTax(),
                                headerForm.getCurrencyCode().trim()).doubleValue());
                Tax[] taxes = (Tax[]) request.getSession().getAttribute("documentTaxes");
                iv.setTaxes(taxes);
                iv.setEnteredTotalCostIncTax(headerForm.getEnteredTotalCostIncTaxDouble());
                iv.setTotalTaxAmount(ReIMMoney.parseCurrencyString(headerForm.getTotalTaxAmount(),
                        headerForm.getCurrencyCode().trim()).doubleValue());

                if (!ReIMSystemOptions.getInstance().isDefaultHeaderTaxFromDetails())
                    ServiceFactory.getTaxService().validateTaxTotals(iv);
            }

            ItemIdentifier itemIdentifier = (ItemIdentifier) ObjectUtils.defaultIfNull(
                    ItemIdentifier.getItemIdentifier(detailForm.getItemIdentifier()),
                    ItemIdentifier.ID);

            // We need to refresh details on the form from the session only if the request came from
            // the header screen.
            // If the requests came from refreshing the screen via browser "Refresh" button or via
            // form submit due to change of the item radio button, no refresh should be done. The
            // parameter is defined
            // in struts-config.xml as URL request parameter
            boolean requestFromHeader = false;
            String requestFromInvHeaderParam = request.getParameter("requestFromInvHeader");
            if (requestFromInvHeaderParam != null) {
                requestFromHeader = Boolean.valueOf(requestFromInvHeaderParam);
            }

            detailForm.reset();
            setValues(detailForm, headerForm, iv, request, requestFromHeader);

            request.getSession().setAttribute("location", headerForm.getLocLOV());

            if (detailForm.isTaxEnabled()) {
            	 List<VendorTaxes>vendorTaxList = ServiceFactory.getTaxService().getVendorTaxes(invDate, supplier, VendorType.fromCode(headerForm.getVendorTypeSelect()));
                 Set<Tax>vendorTaxSet = new HashSet<Tax>();
                 for(VendorTaxes vendorTaxes : vendorTaxList){
                 	vendorTaxSet.addAll(vendorTaxes.getTaxes());
                 }
                 Tax[] taxes =(Tax[]) vendorTaxSet.toArray(new Tax[vendorTaxSet.size()]);
                 
                detailForm.setTaxes(taxes);
                detailForm.setDisplayTaxes(getTaxIDValuePairs(taxes));
            }

            detailForm.setItemIdentifier(itemIdentifier.name());
            request.getSession().setAttribute("itemIdentifier", itemIdentifier);
            ReIMSystemOptions systemOptions = ReIMSystemOptions.getInstance();

            return (mapping.findForward("success"));
        } catch (ReIMException e) {
            request.getSession().removeAttribute("iv");
            saveErrors(request, errors, e);
            return (mapping.findForward("failure"));
        } catch (Exception e) {
            request.getSession().removeAttribute("iv");
            ReIMException exception = new ReIMException("error.inv_maint_hdr_detail_action",
                    Severity.ERROR, e, this);
            saveErrors(request, errors, exception);
            return (mapping.findForward("failure"));
        }
    }

    private boolean userStillHasLock(HttpServletRequest request, ActionErrors errors,
            InvoiceMaintenanceHeaderForm headerForm) throws ReIMException, Exception {
        if (headerForm.getMode().equals(MaintenanceForm.EDIT)) {
            String userId = ReIMUserContext.getUsername();
            long documentId = ReIMI18NUtility.parseNumberString(headerForm.getDocId()).longValue();
            if (!LockingUtils.isUserAuthorized(LockingData.DOC_HEAD_LOCK_TABLE, userId, documentId)) {
                saveErrors(request, errors, "alert.lock_expired");
                return false;
            }
        }

        return true;
    }

    public void setValues(InvoiceMaintenanceDetailForm detailForm,
            InvoiceMaintenanceHeaderForm headerForm, InvoiceView iv, HttpServletRequest request,
            boolean requestFromHeader) throws ReIMException {
        String extInvoiceNo = headerForm.getInvoiceNumber();
        String invoice = headerForm.getDocId();
        String docType = headerForm.getDocumentType();
        double totalCost = ReIMMoney.parseCurrencyString(headerForm.getTotalMerchandiseCost(),
                headerForm.getCurrencyCode()).doubleValue();
        Double qty = new Double(0);
        if (headerForm.getInvoiceQty() != null
                && !headerForm.getInvoiceQty().equals(ReIMConstants.EMPTY_STRING)) {
            qty = new Double(ReIMQuantity.parseNumberString(headerForm.getInvoiceQty())
                    .doubleValue());
        }
        double totalQty = qty.doubleValue();
        Receipt[] receipts = ServiceFactory.getReceiptService().selectReceiptsFromInvoiceOrder(
                headerForm.getOrderLOV(), headerForm.getLocLOV(), true);
        detailForm.setOrderNo(headerForm.getOrderLOV());
        detailForm.setLocation(headerForm.getLocLOV());
        detailForm.setInvoiceReceipts(receipts);
        detailForm.setExtDocId(extInvoiceNo);
        detailForm.setInvoiceId(invoice);
        detailForm.setSupplier(headerForm.getVendorLOV());
        detailForm.setSupplierDesc(headerForm.getVendorLOVDesc());
        detailForm.setCurrencyCode(headerForm.getCurrencyCode());
        detailForm.setTotalInvMerchCost(totalCost);
        detailForm.setTotalInvQty(totalQty);
        detailForm.setFormattedTotalInvMerchCost(ReIMMoney.getCostString(totalCost, headerForm
                .getCurrencyCode()));
        detailForm.setDocumentType(docType);
        detailForm.setTaxEnabled(headerForm.isTaxEnabled());
        detailForm.setTotalHeaderQuantityRequired(headerForm.isTotalHeaderQuantityRequired());
        // The invoice view object in session has the state of the items when
        // the detail screen was
        // last entered and ok was pressed.
        DocumentItemInvoice[] items = iv.getInvoiceItemDetails();
        // if user has not entered the screen in this invoice/session, get the
        // items.
        if (items == null) {
            if (headerForm.getMode().equals(MaintenanceForm.NEW)) {
                items = new DocumentItemInvoice[0];
            } else {
                // if user has not entered the screen in this invoice/session or
                // user can only view details, get the items.
               IInvoiceDetailService invoiceDetailService = ServiceFactory.getInvoiceDetailService();
                items = invoiceDetailService.getInvoiceItemsByInvoiceId(invoice, detailForm
                        .getCurrencyCode());
            }
        } // Set mode based on invoice status, if items are attached,
        // and what mode the user intended to see.
        String detailsMode = getDetailsMode(headerForm.getMode(),
                headerForm.getInvoiceStatusCode(), headerForm.isHeaderOnlyUnresolvedEditMode(),
                items.length, headerForm.isDetailsVisited());
        detailForm.setMode(detailsMode);
        if (!detailsMode.equals(MaintenanceForm.VIEW)) {
            // we only want to save the details when user can edit invoice
            // details.
            iv.setInvoiceItemDetails(items);
            // We need a new copy of the items in session because we do not want
            // any references to each other.
            // We want any updates/deletes/inserts to be completely on the form
            // and not effect the session
            // items until user hits ok.
            if (requestFromHeader) {
                cloneItemsAndSetOnForm(items, detailForm);
            }
        } else {
            // If we are not able to edit the details, especially when editing
            // an unresolved or multi-unresolved
            // invoice we don't want to save them on the invoiceView object.
            // This is just precautionary measures to
            // double ensure that the resolution adjusted amounts are not
            // updated when user hits ok on header screen
            detailForm.setInvoiceDetails(items);
        }

        ArrayList orderItems = ServiceFactory.getOrderService().getOrderItems(
                headerForm.getOrderLOV());
        ArrayList itemObjects = new ArrayList();
        for (int i = 0; i < orderItems.size(); i++) {
            Item item = new Item();
            item.setItemId((String) orderItems.get(i));
            itemObjects.add(item);
        }
        
        // The defaulting items from PO was disabled. With this change, we are enabling it even for cross-dock PO 
        /* String finalDestInd = ServiceFactory.getReceiptService().
         isCrossDockReceipt(headerForm.getOrderLOV(), headerForm.getVendorLOV(), 
         headerForm.getLocLOV()); */
        
        // The below check is not required because the Location LOV on the header screen has already validated the location versus the PO. 
        /* boolean isInvLocExistOnPO = ServiceFactory.getOrderService().validateOrderLoc(iv.getLocationType(), new Long(iv.getLocationId()), new Long(iv.getOrderNo())); */
        
		/* if(!isInvLocExistOnPO && finalDestInd.equals("N")) {
		 		finalDestInd = "Y";
		 } */
        
        //Hard coding the below to keep the changes minimum for enabling the "Default items from Order"
        detailForm.setFinalDestInd("N");        

        detailForm.setOrderItems(itemObjects);
        detailForm.setItemLength(itemObjects.size());
        detailForm.setAddOrUpdateEnabler(MaintenanceForm.ADD_ITEM_BUTTON);
        request.getSession().setAttribute("orderItems", orderItems);
        ReIMAttributeManager.setAttribute(ReIMPageCodes.INVOICE_MAINTENANCE_DETAIL,
                "invoiceMaintenanceDetailForm", detailForm);
        ReIMSystemOptions systemOptions = ReIMUserContext.getSystemOptions();
        detailForm.setItemVPNLookupAllowed(systemOptions.isVpnItemLookup());
    }

    private static void cloneItemsAndSetOnForm(DocumentItemInvoice[] items,
            InvoiceMaintenanceDetailForm detailForm) throws ReIMException {
        DocumentItemInvoice[] docItemClones = null;
        if (items != null) {
            int length = items.length;
            docItemClones = new DocumentItemInvoice[length];
            for (int i = 0; i < length; i++) {
                DocumentItemInvoice sessionItem = items[i];
                DocumentItemInvoice sessionItemCopy = new DocumentItemInvoice();
                String itemId = sessionItem.getItem().getItemId();
                Item item = new Item();
                item.setItemId(itemId);
                item.setItemName(sessionItem.getItem().getItemName());
                item.setVpn(sessionItem.getItem().getVpn());
                sessionItemCopy.setItem(item);
                sessionItemCopy.setDocId(sessionItem.getDocId());
                sessionItemCopy.setQty(sessionItem.getQty());
                sessionItemCopy.setUnitCost(sessionItem.getUnitCost());
                sessionItemCopy.setCurrencyCode(sessionItem.getCurrencyCode());
                sessionItemCopy.setInitialUnitCost(sessionItem.getInitialUnitCost());
                sessionItemCopy.setTaxDiscrepancyResolved(sessionItem.isTaxDiscrepancyResolved());
                sessionItemCopy.setTaxes(sessionItem.getTaxes());
                sessionItemCopy.setUnitFreight(sessionItem.getUnitFreight());
                sessionItemCopy.setUnitMRP(sessionItem.getUnitMRP());
                sessionItemCopy.setUnitRetail(sessionItem.getUnitRetail());
                sessionItemCopy.setAdjustmentPending(sessionItem.getAdjustmentPending());

                docItemClones[i] = sessionItemCopy;
            }
        }

        detailForm.setInvoiceDetails(docItemClones);
    }

    /**
     * Method returns invoiceMode unless the user is trying to edit an Unresolved or
     * Multi-Unresolved invoice. In that case the user cannot edit any existing details. However, if
     * no details exist for an invoice the user can enter Details. If the user has entered the
     * details in this session (detailsVisited) then they can also modify them.
     * 
     * @param String
     *            invoiceMode
     * @param String
     *            invoiceStatus
     * @param int itemCount
     * @return String
     */
    private static String getDetailsMode(String invoiceMode, String invoiceStatus,
            boolean unresolvedEditMode, int itemCount, boolean detailsVisited) {
        String mode = invoiceMode;
        if (invoiceMode.equals(MaintenanceForm.EDIT)
                && itemCount > 0
                && (invoiceStatus.equals(Document.UNRESOLVED_MATCH) || invoiceStatus
                        .equals(Document.MULTI_UNRESOLVED)) && !detailsVisited) {
            // In english: if the user is trying to edit existing items on an
            // unresolved/multi-unresolved invoice
            // and the details have not been entered in this session (i.e they
            // are committed on the db) then
            // user can only view, no update/adds or deletes. (This is because
            // items have gone through matching and
            // (most importantly) we don't know what kind of discrepancy
            // resolution has been done or what qty's are matched to which
            // receipts etc.)
            // Since all items are saved in session we cannot go strictly on
            // itemCount we must also check
            // detailsVisited, which would be false if user was previously only
            // allowed to View existing details.
            mode = MaintenanceForm.VIEW;
        }

        if ((invoiceMode.equals(MaintenanceForm.EDIT) && itemCount == 0) || unresolvedEditMode) {
            mode = MaintenanceForm.EDIT;
        }

        return mode;
    }

    private IdValuePair[] getTaxIDValuePairs(Tax[] taxes) {
        IdValuePair[] taxCodesAndRates = new IdValuePair[taxes.length];
        String id;
        String value;
        for (int i = 0; i < taxes.length; i++) {
            id = taxes[i].getTaxCode();
            value = taxes[i].getTaxCode() + " - " + taxes[i].getTaxRate();
            taxCodesAndRates[i] = new IdValuePair(id, value);
        }

        return taxCodesAndRates;
    }
}
