package com.retek.reim.business.match;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import oracle.retail.reim.utils.Severity;

import com.retek.merch.utils.Quantity;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.foundation.AShipmentBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMQuantity;

/**
 * -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		20-Jun-2013	BNaik		Reverting the Oracle Bug 6955602 fix because it allows summary matching on the receipt 
 *    including the quantities of the receipt item that had been already resolved with another invoice.                                           									
 */

public class ReceiptLevel implements ReceiptGroup {
    private Receipt receipt;

    public ReceiptLevel() {
    }

    public ReceiptLevel(Receipt receipt) {
        this.receipt = receipt;
    }

    /**
     * Returns the cost.
     * 
     * @return double
     */
    public Quantity getCost() throws ReIMException {
        try {
            Quantity totalCost = new Quantity(0);
            Map receiptItems = receipt.getReceiptItems();

            Collection receipts = receiptItems.values();
            /* BRN V 1.2 Begin - Removed
            AShipmentBean bean = (AShipmentBean) ReIMBeanFactory
            .getBean(ReIMBeanFactory.AShipmentBean);
            
            BRN V 1.2 End */
            
            for (Iterator i = receipts.iterator(); i.hasNext();) {
                ReceiptItem receiptItem = (ReceiptItem) i.next();
                /* BRN V 1.2 Begin - Removed
                long itemId=Long.parseLong(receiptItem.getItemId());
                long shipment=Long.parseLong(receiptItem.getReceiptId());
                ReIMQuantity unitCost = new ReIMQuantity(receiptItem.getUnitCost());
                if(receiptItem
                        .getAvailableToMatchQty()<=0 && !bean.isCostMatched(itemId,shipment)){
                	totalCost = totalCost.add(unitCost.multiply(receiptItem
                            .getQtyReceived()));
                }else{
                totalCost = totalCost.add(unitCost.multiply(receiptItem
                        .getAvailableToMatchQty()));
                }
                BRN V 1.2 End */
                
                // BRN V 1.2 Begin - Added 
                ReIMQuantity unitCost = new ReIMQuantity(receiptItem.getUnitCost());
                totalCost = totalCost.add(unitCost.multiply(receiptItem.getAvailableToMatchQty()));
                // BRN V 1.2 End
            }

            return totalCost;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_total_receipt_cost", Severity.ERROR, e, this);
        }
    }

    /**
     * Returns the qty.
     * 
     * @return double
     */
    public Quantity getQty() throws ReIMException {
        try {
            Quantity totalQty = new Quantity(0);
            Map receiptItems = receipt.getReceiptItems();

            Collection receipts = receiptItems.values();
            
            for (Iterator i = receipts.iterator(); i.hasNext();) {
                ReceiptItem receiptItem = (ReceiptItem) i.next();
                /* BRN 1.2 Begin - Removed
                if (receiptItem.getAvailableToMatchQty() <= 0
						&& receiptItem.isCostMatched()) {
					totalQty = totalQty.add(receiptItem.getQtyReceived());
				} else {
					totalQty = totalQty.add(receiptItem
							.getAvailableToMatchQty());
				}
				BRN 1.2 End */
                
                // BRN 1.2 Begin - Added
                totalQty = totalQty.add(receiptItem.getAvailableToMatchQty());
                // BRN 1.2 End
            }

            return totalQty;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_total_receipt_qty", Severity.ERROR, e, this);
        }
    }

    public void updateInvoiceMatchStatus(String status) {
        receipt.setInvoiceMatchStatus(status);
    }

    /**
     * Returns the receipt.
     * 
     * @return Receipt
     */
    public Receipt getReceipt() {
        return receipt;
    }

    /**
     * Sets the receipt.
     * 
     * @param receipt
     *            The receipt to set
     */
    public void setReceipt(Receipt receipt) {
        this.receipt = receipt;
    }

    // There is only one receipt in a receipt level group
    public Receipt[] getReceipts() {
        return new Receipt[] { receipt};
    }
}
