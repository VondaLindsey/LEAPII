package com.retek.reim.ui.invoiceMaintenance;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.ReimProperties;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.business.POLocation;
import com.retek.reim.business.SupplierGroup;
import com.retek.reim.business.Term;
import com.retek.reim.business.UserRole;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.merch.utils.ReIMAttributeManager;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMPageCodes;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3		14-May-2013	BNaik		BRN EDI Invoices should not be allowed to be edited.
 *     If any of the items are either matched or discrepancy routed(DETAIL_MATCHED='Y'), then the invoice will be in VIEW mode 
 * 		and cannot be edited. If not, the items can be edited in ready-for-match, unresolved match, and multi-unresolved invoices, and tax discrepancy status.
 * 										
 */

@SuppressWarnings("deprecation")
public class InvoiceMaintenanceHeaderEditViewAction extends ReIMSecureAction {

    protected boolean getPermission() {
        try {
            UserRole userRole = ReIMUserContext.getUserRole();

            if (userRole.getInvoiceEntry().equalsIgnoreCase(UserRole.EDIT)
                    || userRole.getInvoiceEntry().equalsIgnoreCase(UserRole.VIEW)
                    || userRole.getInvoiceEntry().equalsIgnoreCase(UserRole.MODIFY)) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            return false;
        }
    }

    private boolean fromOtherScreen(InvoiceMaintenanceHeaderForm headerForm) {
        return headerForm.getIsFromSummaryMatchList()
                || headerForm.getIsFromSummaryMatchListGrouping()
                || (headerForm.isFromDetailMatch()) || headerForm.isFromTaxDiscrepancyList();
    }

    protected ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {

        ActionErrors errors = new ActionErrors();
        ActionForward actionForward = mapping.findForward("success");

        InvoiceMaintenanceHeaderForm headerForm = (InvoiceMaintenanceHeaderForm) form;
        InvoiceAdvancedSearchResultForm advForm = (InvoiceAdvancedSearchResultForm) request
                .getSession().getAttribute("invoiceAdvSearchResultForm");
        InvoiceAdvSearchForm advSearchForm = (InvoiceAdvSearchForm) request.getSession()
                .getAttribute("InvoiceAdvSearchForm");
        Term supplierTerms = null;
        String supplierTermsId = null;

        try {
            // first remove all session objects
            ServiceFactory.getInvoiceMaintenanceService().removeSharedObjects();
            if(ReIMUserContext.getSystemOptions().isSupplierSiteEnabled()) {
                headerForm.setSupplierSiteEnabled(true);
                headerForm.setAlwaysShowSupplierSite(ReimProperties.ALWAYS_SHOW_SUPPLIER_SITE);
            }
            else
            {
            	headerForm.setSupplierSiteEnabled(false);
                headerForm.setAlwaysShowSupplierSite("false");
            }

            // get parameter docId from the previous page
            String docId = null;
            if (request.getParameter("selectedDocId") != null) {
                docId = request.getParameter("selectedDocId");
            } else {
                ReIMException exception = new ReIMException("error.fail_to_obtain_doc_id",
                        Severity.ERROR, this);
                saveErrors(request, errors, exception);

                return mapping.findForward("failure");
            }

            if ((request.getParameter("fromSummaryMatchList") != null && request.getParameter(
                    "fromSummaryMatchList").equalsIgnoreCase(ReIMConstants.TRUE))) {
                headerForm.setFromSummaryMatchList(true);
            }

            if ((request.getParameter("fromSummaryMatchListGrouping") != null && request
                    .getParameter("fromSummaryMatchListGrouping").equalsIgnoreCase(
                            ReIMConstants.TRUE))) {
                headerForm.setFromSummaryMatchListGrouping(true);
            }

            if (request.getParameter("fromDetailMatchFlag") != null
                    && request.getParameter("fromDetailMatchFlag").equalsIgnoreCase(
                            ReIMConstants.TRUE)) {
                headerForm.setFromDetailMatch(true);
            }

            if (request.getParameter("fromTaxDiscrepancyList") != null
                    && request.getParameter("fromTaxDiscrepancyList").equalsIgnoreCase(
                            ReIMConstants.TRUE)) {
                headerForm.setFromTaxDiscrepancyList(true);
            }
            Document myDoc = null;

            if (fromOtherScreen(headerForm)) {
                myDoc = ServiceFactory.getDocumentService()
                        .getDocHeadByDocId(Long.parseLong(docId));
            } else {
                myDoc = advForm.getDocumentForDocId(Long.parseLong(docId));
            }

            ServiceFactory.getDocumentService().populateDocHeadInfo(myDoc);
            myDoc.setDocDetail(ServiceFactory.getDocumentService().getDocDetails(docId));

            headerForm.resetForm();

            headerForm.setReleasePermission(Affirm.check(ReIMUserContext.getUserRole()
                    .getRemoveHold()));
            headerForm.setHoldStatus(myDoc.getHoldStatus());
            headerForm.setDocId(docId);
            headerForm.setDocumentType(myDoc.getType());
            headerForm.setDocumentTypeDesc(ServiceFactory.getDocumentService()
                    .getDocumentTypeDescription(myDoc.getType()));
            headerForm.setInvoiceNumber(myDoc.getExtDocId());
            // display ext_doc_id as the invoice number
            headerForm.setInvoiceStatus(ServiceFactory.getDocumentService()
                    .getDocumentStatusDescription(myDoc.getStatus()));
            headerForm.setInvoiceStatusCode(myDoc.getStatus());
            headerForm.setInvoiceDate(myDoc.getDocDateAsString());

            headerForm.setVendorTypeSelect(myDoc.getVendor().getVendorTypeCode());
            headerForm.setVendorLOV(myDoc.getVendor().getVendorId());
            headerForm.setVendorLOVDesc(myDoc.getVendor().getVendorName());
            headerForm.setConsignmentInvoice(myDoc.isConsignmentInd());
            headerForm.setDirectStoreDelieveryInd(myDoc.isDirectStoreDelieveryInd());
            headerForm.setEvaluatedReceiptSettlementInd(myDoc.isEvaluatedReceiptSettlementInd());

            if (headerForm.getVendorLOVDesc() == null) {
                headerForm.setVendorLOVDesc(ServiceFactory.getVendorService().getVendorDesc(
                        headerForm.getVendorLOV(), myDoc.getVendorType()));
            }
            headerForm.setSupplierSiteLOV(myDoc.getSupplierSiteId());
            if(myDoc.getSupplierSiteId() != null && !myDoc.getSupplierSiteId().equals("")) {
                headerForm.setSupplierSiteLOVDesc(ServiceFactory.getSupplierService()
                    .getSupplierDesc(myDoc.getSupplierSiteId()));
            } else {
                headerForm.setSupplierSiteLOVDesc(null);
            }
            headerForm.setCurrencyCode(myDoc.getCurrencyCode());
            headerForm.setExchangeRate(myDoc.getExchangeRate().toString());

            headerForm.setInvoiceTermsLOV(myDoc.getTerms());
            headerForm.setInvoiceTermsLOVDesc(ServiceFactory.getTermsService().getTermsDescription(
                    myDoc.getTerms()));

            double totalAllowancesDouble = 0.0; // default to 0
            if (myDoc.getType().equals(Document.MERCHANDISE_INVOICE)) {
                totalAllowancesDouble = ServiceFactory.getDocumentService().getTotalAllowances(
                        headerForm.getDocId());
                headerForm.setApprovalDate(ServiceFactory.getDocumentService()
                        .getMatchDateByDocumentId(headerForm.getDocId()));

            } else {
                headerForm.setApprovalDate(ServiceFactory.getDocumentService()
                        .getApprovalDateByDocumentId(headerForm.getDocId()));
            }

            String termsId = myDoc.getBestTerms();
            Term term = null;
            if ((termsId != null) && (!termsId.equals(ReIMConstants.EMPTY_STRING))) {
                term = ServiceFactory.getTermsService().getTerms(termsId);
            }
            headerForm.setBestTerms(term == null ? ReIMConstants.EMPTY_STRING : term
                    .getTermDescription());

            String bestTermsSource = ServiceFactory.getDocumentService().getBestTermsSource(
                    myDoc.getBestTermsSource());
            headerForm.setBestTermsSource(bestTermsSource == null ? ReIMConstants.EMPTY_STRING
                    : bestTermsSource);

            headerForm.setBestTermsDate(myDoc.getBestTermsDate() == null ? null : myDoc
                    .getBestTermsDate().getDisplayString());

            String bestTermsDateSource = ServiceFactory.getDocumentService()
                    .getBestTermsDateSource(myDoc.getBestTermsDateSource());
            headerForm
                    .setBestTermsDateSource(bestTermsDateSource == null ? ReIMConstants.EMPTY_STRING
                            : bestTermsDateSource);

            headerForm.setTotalAllowances(ReIMMoney.getCostString(totalAllowancesDouble, headerForm
                    .getCurrencyCode()));

            if (headerForm.getOrderLOV() == null || headerForm.getOrderLOV().length() == 0) {
                if (myDoc.getPoLocation() != null) {
                    POLocation poLoc = myDoc.getPoLocation();
                    // non-merch invoice must have a loc
                    if (myDoc.getPoLocation().getLocation() != null) {
                        headerForm.setLocLOV(poLoc.getLocation().getLocationId());
                        headerForm.setLocLOVDesc(poLoc.getLocation().getLocationName());
                        headerForm.setLocLOVDesc2(poLoc.getLocation().getLocationType());
                    }

                    if (poLoc.getOrder() != null) {
                        headerForm.setOrderLOV(poLoc.getOrderNo());
                    }
                } else if (fromOtherScreen(headerForm)) {
                    headerForm.setOrderLOV(request.getParameter("selectedOrderNo"));
                    headerForm.setLocLOV(myDoc.getLocation().getLocationId());
                    headerForm.setLocLOVDesc(myDoc.getLocation().getLocationName());
                    headerForm.setLocLOVDesc2(myDoc.getLocation().getLocationType());
                }
            }

            if (headerForm.getLocLOVDesc() == null
                    || headerForm.getLocLOVDesc().trim().length() < 1) {
                headerForm.setLocLOVDesc(ServiceFactory.getLocationService()
                        .getLocationDescription(new Long(headerForm.getLocLOV()).longValue()));
            }

            if (myDoc.getVendor() != null
                    && myDoc.getVendor().getVendorTypeCode().equals(Vendor.SUPPLIER)) {
                supplierTermsId = ServiceFactory.getSupplierService().getTerms(
                        myDoc.getVendor().getVendorId());
                supplierTerms = ServiceFactory.getTermsService().getTerms(supplierTermsId);
                headerForm.setSupplierTerms(supplierTermsId + "  "
                        + supplierTerms.getTermDescription());
                SupplierGroup supplierGroup = ServiceFactory.getSupplierGroupService()
                        .getSupplierGroup(myDoc.getVendor().getVendorId());
                if (supplierGroup != null) {
                    headerForm.setMatchTotalQuantity(supplierGroup.isMatchTotalQuantity());
                    headerForm.setTotalHeaderQuantityRequired(supplierGroup
                            .isTotalHeaderQuantityRequired());
                }
            }

            if (headerForm.getOrderLOV() != null && headerForm.getOrderLOV().length() > 0) {
                String orderTermsId = ServiceFactory.getOrderService().getOrderTerms(
                        headerForm.getOrderLOV());
                Term orderTerms = ServiceFactory.getTermsService().getTerms(orderTermsId);
                headerForm.setOrderTerms(orderTermsId + "  " + orderTerms.getTermDescription());
            }
            //Fix for defect 1066.Setting order terms in case of nonmerchandise invoice without 
            //order number populated
            else{
            	headerForm.setOrderTerms(supplierTermsId + "  "
                        + supplierTerms.getTermDescription());
            }

            headerForm.setEdiInvoice(myDoc.isEdiUploadInd());
            headerForm.setPrePaid(myDoc.isPrePaidInd());
            headerForm.setIsManuallyPaid(myDoc.isManuallyPaidInd() ? "true" : "false");

            if (myDoc.getDocDetail() != null && myDoc.getDocDetail().isEmpty() == false) {
                headerForm.setDetailsAttached(true);
            } else {
                headerForm.setDetailsAttached(false);
            }

            headerForm.populateFreightTypeOptions();
            headerForm.populatePaymentMethodOptions();
            headerForm.populateVendorTypeOptions();

            headerForm.setDueDate(myDoc.getDueDateAsString()); // TODO: date
            // format
            headerForm.setFreightType(myDoc.getFreightType());
            headerForm.setPaymentMethod(myDoc.getPaymentMethod());

            headerForm.setCustomDocRef1(myDoc.getCustomDocRef1());
            headerForm.setCustomDocRef2(myDoc.getCustomDocRef2());
            headerForm.setCustomDocRef3(myDoc.getCustomDocRef3());
            headerForm.setCustomDocRef4(myDoc.getCustomDocRef4());
            if (null != myDoc.getGroupId()) {
                headerForm.setGroupId(myDoc.getGroupId().toString());
            } else {
                headerForm.setGroupId("");
            }
            // get the user's security setting
            String mode = null;

            if (fromOtherScreen(headerForm)) {
                String invoiceEntryMode = ReIMUserContext.getUserRole().getInvoiceEntry();
                String invoiceMatchingMode = ReIMUserContext.getUserRole().getInvoiceMatching();

                if (invoiceEntryMode.equalsIgnoreCase(ReIMConstants.VIEW)) {
                    if (invoiceMatchingMode.equalsIgnoreCase(ReIMConstants.EDIT)) {
                        mode = MaintenanceForm.EDIT;
                    } else {
                        mode = MaintenanceForm.VIEW;
                    }
                } else if (invoiceEntryMode.equalsIgnoreCase(ReIMConstants.EDIT)
                        || invoiceEntryMode.equalsIgnoreCase(ReIMConstants.MODIFY)) {
                    mode = MaintenanceForm.EDIT;
                } else if (invoiceEntryMode.equalsIgnoreCase(ReIMConstants.NONE)) {
                    saveErrors(request, errors, "alert.screen_none_permission");
                    return (mapping.findForward("failure"));
                }
            } else {
                mode = getPageMode(advSearchForm.getActionType());
            }

            if (mode.equals(MaintenanceForm.EDIT)) {
                // try to lock the record
                String userId = ReIMUserContext.getUsername();
                String lockUserId = ServiceFactory.getDocumentService().lockDocumentForUser(
                        Long.parseLong(docId), userId);

                if (!userId.equalsIgnoreCase(lockUserId)) {
                    // The record is locked by another user
                    // set mode to view only and inform the user
                    mode = MaintenanceForm.VIEW;
                    errors.add("alert.document.locked", new ActionError("alert.document.locked",
                            lockUserId));
                    saveErrors(request, errors);
                }
            } else // View mode
            {
                if (fromOtherScreen(headerForm)) {
                    if (mode.equals(MaintenanceForm.VIEW)) {
                        // if the user chose the action edit, but has view only
                        // access
                        // display a view only message on header screen

                        errors.add("alert.screen_view_only_permission", new ActionError(
                                "alert.screen_view_only_permission"));
                        saveErrors(request, errors);
                    }
                } else {
                    if (advSearchForm.getActionType().equals(MaintenanceForm.EDIT)) {
                        // if the user chose the action edit, but has view only
                        // access
                        // display a view only message on header screen

                        errors.add("alert.screen_view_only_permission", new ActionError(
                                "alert.screen_view_only_permission"));
                        saveErrors(request, errors);
                    }
                }
            }

            if (!myDoc.getStatus().equals(Document.READY_FOR_MATCH)
                    && !myDoc.getStatus().equals(Document.TAX_DISCREPANCY)) {
                if (mode.equals(MaintenanceForm.EDIT)
                        && !headerForm.isDetailsAttached()
                        && (myDoc.getStatus().equals(Document.UNRESOLVED_MATCH) || myDoc
                                .getStatus().equals(Document.MULTI_UNRESOLVED))) {
                    headerForm.setHeaderOnlyUnresolvedEditMode(true);
                    if (headerForm.isPrePaid()) {
                        mode = MaintenanceForm.VIEW;
                    }
                } else {
                    if ((myDoc.getStatus().equals(Document.UNRESOLVED_MATCH)) && (mode.equals(MaintenanceForm.EDIT))) {
                        headerForm.setHeaderOnlyUnresolvedEditMode(true);
                        mode = MaintenanceForm.EDIT;
                    }
                    else {
                        

                   headerForm.setHeaderOnlyUnresolvedEditMode(false);
//                     headerForm.setHeaderOnlyUnresolvedEditMode(true);
                    mode = MaintenanceForm.VIEW;
                    }
                }
            }

            // The total costs, total qty, totalCostIncTax, nonMerchCost will be
            // enabled for merchandise invoices
            // until the status of the invoice is Ready for Match.
            if (myDoc.getType().equals(Document.MERCHANDISE_INVOICE)
                    && mode.equals(MaintenanceForm.EDIT)) {
                headerForm.setTotalCostInputEnabler(true);
                headerForm.setTotalCostIncTaxInputEnabler(true);
            }
            
            // BRN V1.3 Begin - Inserted
            if(myDoc.isEdiUploadInd()){
            	headerForm.setHeaderOnlyUnresolvedEditMode(false);
            	mode = MaintenanceForm.VIEW;
            	
            } else if (ServiceFactory.getDocumentService().getDetailMatchedByDocId(docId).equalsIgnoreCase(ReIMConstants.YES)) {
            	headerForm.setHeaderOnlyUnresolvedEditMode(false);
            	mode = MaintenanceForm.VIEW;
            }
            // BRN V1.3 End
            // Set the page mode --Edit or view
            headerForm.setMode(mode);

            ReIMMoney totalNonMerchCostMoney = ServiceFactory.getNonMerchandiseDocumentService()
                    .getTotalNonMerchCost(Long.parseLong(docId));
            ReIMMoney totalCostMoney = new ReIMMoney(myDoc.getTotalCost().doubleValue());
            ReIMMoney totalMerchCostMoney = totalCostMoney.subtract(totalNonMerchCostMoney);

            headerForm.setTotalNonMerchCost(ReIMMoney.getCostString(totalNonMerchCostMoney
                    .doubleValue(), headerForm.getCurrencyCode()));
            headerForm.setTotalCost(ReIMMoney.getCostString(totalCostMoney.doubleValue(),
                    headerForm.getCurrencyCode()));
            headerForm.setTotalMerchandiseCost(ReIMMoney.getCostString(totalMerchCostMoney
                    .doubleValue(), headerForm.getCurrencyCode()));

            if (ReIMUserContext.getSystemOptions().isProcessTaxes()) {
                headerForm.setTaxEnabled(true);
                headerForm.setTaxValidationType(ReIMUserContext.getSystemOptions()

                        .getTaxValidationType().toString());
                Tax[] taxes = ServiceFactory.getDocumentService().getDocumentTaxes(

                        Long.parseLong(docId), headerForm.getCurrencyCode());
                double totalTaxAmount = ServiceFactory.getTaxService().getTotalTaxAmount(taxes);
                headerForm.setTotalTaxAmount(ReIMMoney.getCostString(totalTaxAmount, headerForm
                        .getCurrencyCode()));
                headerForm.setTotalTaxAmountDouble(totalTaxAmount);
                headerForm.setEnteredTotalCostIncTax(myDoc.getTotalCostIncTaxAsString());
                headerForm.setTaxes(taxes);
                List<NonMerchandiseDocument>nonMerchandiseList = ServiceFactory.getNonMerchandiseEntryService()
                		.read(myDoc.getDocId());
                headerForm.setNonMerchandiseDocuments(nonMerchandiseList.toArray(new NonMerchandiseDocument[nonMerchandiseList.size()]));
            } else {
                headerForm.setTaxEnabled(false);
                headerForm.setTotalTaxAmount(ReIMMoney.getCostString(0, headerForm
                        .getCurrencyCode()));
                headerForm.setEnteredTotalCostIncTax(headerForm.getTotalCost());
                headerForm.setTotalTaxAmountDouble(0);
            }

            Double invoiceQtyDouble = new Double(myDoc.getTotalQty().doubleValue());
            headerForm
                    .setInvoiceQty(ReIMQuantity.getQuantityString(invoiceQtyDouble.doubleValue()));

            ReIMAttributeManager.setAttribute(ReIMPageCodes.INVOICE_MAINTENANCE_HEADER,
                    "freightTypeOptions", headerForm.getFreightTypeOptions());
            ReIMAttributeManager.setAttribute(ReIMPageCodes.INVOICE_MAINTENANCE_HEADER,
                    "paymentMethodOptions", headerForm.getPaymentMethodOptions());
            ReIMAttributeManager.setAttribute(ReIMPageCodes.INVOICE_MAINTENANCE_HEADER,
                    "vendorTypeOptions", headerForm.getVendorTypeOptions());
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            actionForward = mapping.findForward("failure");
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.unable_to_load_invoice_header_maintenence_edit_view_mode",
                    Severity.ERROR, e, this);
            saveErrors(request, errors, exception);
            actionForward = mapping.findForward("failure");
        }

        return actionForward;
    }

    // Developer Note this screen is only to be used
    // for Invoices (Merch and Non-Merch)
    // Security for documents does not apply here
    private String getPageMode(String currentActionType) {

        UserRole userRole = ReIMUserContext.getUserRole();
        String pageMode = MaintenanceForm.VIEW;

        String permission = userRole.getInvoiceEntry();

        if (permission.equalsIgnoreCase(UserRole.VIEW)) // view only
        {
            pageMode = MaintenanceForm.VIEW;
        } else if (permission.equalsIgnoreCase(UserRole.EDIT)
                || permission.equalsIgnoreCase(UserRole.MODIFY)) // edit
        {

            if (currentActionType.equals(MaintenanceForm.EDIT)) {
                // set to edit if security permissions are edit
                // and the user picked actionType "EDIT"
                pageMode = MaintenanceForm.EDIT;
            } else {
                // otherwise the user chose View
                pageMode = MaintenanceForm.VIEW;
            }

        }

        return pageMode;
    }
}
