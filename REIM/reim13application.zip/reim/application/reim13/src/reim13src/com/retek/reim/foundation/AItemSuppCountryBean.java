package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.data.dao.impl.ItemSupCountryDao;

/**
 * @Deprecated Use {@link ItemSupCountryDao}
 *
 */
@Deprecated
public abstract class AItemSuppCountryBean {
    public double getItemSupplierUnitCost(String item, long supplier, String location,
            String country) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        double unitCost = Double.MIN_VALUE;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            if (item == null || country == null || supplier == Double.MIN_VALUE) { throw new ReIMException(
                    "error.item_supp_country.parameters_not_null", Severity.DEBUG, this); }

            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(" SELECT UNIT_COST FROM V_IM_ITEM_SUPP_COUNTRY_LOC "
                            + " WHERE ITEM = ? " + " AND SUPPLIER = ? " + " AND LOC = ? "
                            + " AND ORIGIN_COUNTRY_ID = ?");

            stmt.setString(1, item);
            stmt.setLong(2, supplier);
            stmt.setLong(3, Long.parseLong(location));
            stmt.setString(4, country);
            rs = stmt.executeQuery();

            if (rs.next()) {
                unitCost = rs.getDouble("UNIT_COST");
            }

            return unitCost;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception exception) {
            throw new ReIMException("error.item_supp_country.get_unit_cost", Severity.ERROR,
                    exception, this, new String[] { item, Long.toString(supplier), country});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.item_supp_country.get_unit_cost",
                        Severity.ERROR, exception, this, new String[] { item,
                                Long.toString(supplier), country});
            }
        }

    }
    
    public double getItemSupplierCost(String item, long orderNo, String location ) throws ReIMException {
    	{
    		OraclePreparedStatement stmt = null;
            ResultSet rs = null;
            double unitCost = 0;

            try {
                Connection conn = TransactionManagerFactory.getInstance().getConnection();

                if (item == null || orderNo ==Double.MIN_VALUE ) { throw new ReIMException(
                        "error.item_supp_country.parameters_not_null", Severity.DEBUG, this); }

                stmt = (OraclePreparedStatement) conn
                        .prepareStatement(" SELECT ISCL.ITEM , ISCL.UNIT_COST   FROM ITEM_SUPP_COUNTRY_LOC ISCL , ORDSKU OS , ORDHEAD OH , " +
                        		"( SELECT OL.LOCATION, ol.order_no FROM ORDLOC OL WHERE OL.LOC_TYPE = 'S' AND OL.LOCATION = ? AND OL.ORDER_NO = ? " +
                        		" UNION SELECT WH.WH, ol.order_no FROM ORDLOC OL , WH  WHERE OL.LOC_TYPE = 'W' AND WH.PHYSICAL_WH = ? AND OL.LOCATION = WH.WH" +
                        		" AND OL.ORDER_NO = ? AND ROWNUM < 2 ) OL  WHERE OS.ORDER_NO = OH.ORDER_NO AND ISCL.ITEM = ? " +
                        		" AND ISCL.SUPPLIER = OH.SUPPLIER AND OS.ORDER_NO = OH.ORDER_NO AND oh.order_no = ol.order_no AND ISCL.LOC = OL.LOCATION AND " +
                        		" ISCL.ORIGIN_COUNTRY_ID = OS.ORIGIN_COUNTRY_ID AND ROWNUM < 2 order by ISCL.item ");

                stmt.setLong(1, Long.parseLong(location));
                stmt.setLong(2, orderNo);
                stmt.setLong(3, Long.parseLong(location));
                stmt.setLong(4, orderNo);
                stmt.setString(5, item);
                
                rs = stmt.executeQuery();

                if (rs.next()) {
                    unitCost = rs.getDouble("UNIT_COST");
                }

                return unitCost;
            } catch (ReIMException e) {
                throw e;
            } catch (Exception exception) {
                throw new ReIMException("error.item_supp_country.get_unit_cost", Severity.ERROR,
                        exception, this, new String[] { item,  Long.toString(orderNo)});
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (SQLException exception) {
                    throw new ReIMException("error.item_supp_country.get_unit_cost",
                            Severity.ERROR, exception, this, new String[] { item,
                                    Long.toString(orderNo)});
                }
            }
    	}
    }
    
    
    
}
