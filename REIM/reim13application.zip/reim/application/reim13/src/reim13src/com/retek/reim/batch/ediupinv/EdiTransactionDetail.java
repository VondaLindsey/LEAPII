package com.retek.reim.batch.ediupinv;

import static oracle.retail.reim.business.EdiValidationResult.FAILURE_REJECT_FILE;
import static oracle.retail.reim.business.EdiValidationResult.FAILURE_REJECT_TABLES;
import static oracle.retail.reim.business.EdiValidationResult.VALIDATION_SUCCESS;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.business.EdiItemSource;
import oracle.retail.reim.business.EdiValidationResult;
import oracle.retail.reim.business.ItemSupplier;
import oracle.retail.reim.business.SupplierSource;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.VendorType;
import oracle.retail.reim.business.VpnSupplier;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.tax.TaxRule;
import oracle.retail.reim.business.tax.VendorTaxes;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Logger;

import org.apache.commons.lang.StringUtils;

import com.retek.merch.utils.RetekException;
import com.retek.reim.batch.BatchUtils;
import com.retek.reim.business.EdiRejectReasons;
import com.retek.reim.business.Item;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.business.vendor.Supplier;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.services.ServiceFactory;

import smr.retek.reim.services.SmrDocumentService;
public class EdiTransactionDetail implements EDIConstants {
    private String recordDescriptor = null;
    private long lineID;
    private long transactionNumber;
    private String item = StringUtils.EMPTY;
    private String upc = StringUtils.EMPTY;
    private Long upcSupp = null;
    private String vpn = StringUtils.EMPTY;
    private double originalDocumentQuantity;
    private double originalUnitCost;
    // private String originalTaxCode;
    // private double originalTaxRate;
    // removed tax code ,taxrate fields from
    // EDITransactionDetail object.Added ediItemTaxes
    // for holding the document taxes and systemTaxes
    // for holding the system taxes for he item under
    // consideration
    private Set<Tax> ediItemTaxes = new HashSet<Tax>();
    private Set<Tax> systemTaxes = new HashSet<Tax>();
    private boolean shouldBeAudited = false;
    // boolean which indicates whether item is having tax
    // discrepancy or not
    private boolean isTaxDiscrepant;
    private double totalAllowance;
    private String originalRecord = null;
    private Long docId = null;
    private Long docDetailId = null;
    private String supplierId = null;
    private EdiItemSource ediItemSource;

    // EdiDownload variables
    private String comments;
    private String reasonCode;
    private String reasonCodeDesc;
    private double discrepantQty;
    private double discrepantCost;
    private boolean isEdiDownload = false;

    // Each detail may have multiple allowances
    private EdiDetailAllowance[] ediDetailAllowanceList = null;
    private double totalAllowanceSum;
    private boolean transactionValid = true;
    private static Set itemSet;

    public EdiTransactionDetail() {
    }

    // This constructor is used when the object is built from a row on the database
    public EdiTransactionDetail(Long docId, String supplierId, Long docDetailId, String upc,
            String itemSupp, String vpn, double originalDocumentQuantity, double originalUnitCost) {
        this.docId = docId;
        this.supplierId = supplierId;
        this.docDetailId = docDetailId;

        this.upc = upc;
        // Fix for defect 382.Converting itemLevelName to itemLevel
        this.upcSupp = itemSupp != null ? mapItemSupplementToLineLevel(itemSupp) : new Long(0);
        this.vpn = vpn;

        this.originalDocumentQuantity = originalDocumentQuantity;
        this.originalUnitCost = originalUnitCost;

        if (!StringUtils.isEmpty(this.vpn)) {
            this.ediItemSource = EdiItemSource.VPN;
        } else if (!StringUtils.isEmpty(this.upc)) {
            this.ediItemSource = EdiItemSource.UPC;
        }

    }

    // This constructor is used when the object is built from a row on the imported file
    public EdiTransactionDetail(EdiRecord ediRecord, EdiTransactionHeader ediTransactionHeader)
            throws ReIMException {
    	
    	 // Validation
        ReIMSystemOptions systemOptions = ServiceFactory.getReIMSystemOptionsService().select();
        boolean isTaxOn = systemOptions.isProcessTaxes();
    	
        this.supplierId = ediTransactionHeader.getVendorID();

        // Local strings to hold data until parsing of numbers
        String transactionNumberString;
        String upcSuppString;
        String origDocQtySignInd;
        String originalDocumentQuantityString;
        String origUnitCostSignInd;
        String originalUnitCostString;
        String originalTaxRateString;
        String allowanceSignInd;
        String totalAllowanceString;
        String originalTaxCode;
        // Fetch values from record
        this.recordDescriptor = ediRecord.getRecordDescriptor();
        this.lineID = ediRecord.getLineID();

        // Parse the rest of the record
        transactionNumberString = ediRecord.takeFromRecord(LEN_TRANSACTION_NUMBER).trim();
        this.upc = ediRecord.takeFromRecord(LEN_ITEM).trim();
        upcSuppString = ediRecord.takeFromRecord(LEN_ITEM_SUPP).trim();
        this.item = ediRecord.takeFromRecord(LEN_ITEM).trim();
        if (this.item.length() != 0) {
            this.ediItemSource = EdiItemSource.ITEM_ID;
        }
        this.vpn = ediRecord.takeFromRecord(LEN_VPN).trim();
        origDocQtySignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        originalDocumentQuantityString = ediRecord.takeFromRecord(LEN_QUANTITY).trim();
        origUnitCostSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        originalUnitCostString = ediRecord.takeFromRecord(LEN_COST).trim();

        originalTaxCode = ediRecord.takeFromRecord(LEN_TAX_CODE).trim();
        originalTaxRateString = ediRecord.takeFromRecord(LEN_TAX_RATE).trim();
        
        if (isTaxOn) {
        Tax ediItemTax = new Tax();
        TaxRule taxRule = new TaxRule(originalTaxCode, BatchUtils.getDouble(originalTaxRateString,
                PRECISION10));
        ediItemTax.setTaxRule(taxRule);
        this.ediItemTaxes.add(ediItemTax);
        }

        allowanceSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalAllowanceString = ediRecord.takeFromRecord(LEN_AMOUNT).trim();
        this.originalRecord = ediRecord.getOriginalRecord();

        if (!StringUtils.isEmpty(this.item)) {
            this.ediItemSource = EdiItemSource.ITEM_ID;
        } else if (!StringUtils.isEmpty(this.upc)) {
            this.ediItemSource = EdiItemSource.UPC;
        } else if (!StringUtils.isEmpty(this.vpn)) {
            this.ediItemSource = EdiItemSource.VPN;
        }


        // Transaction Number
        try {
            this.transactionNumber = Long.parseLong(transactionNumberString);
        } catch (NumberFormatException nfe) {
            // this would have been caught in the initial file sweep, but just to be safe....
            String key = "error.batch.invalid_number_format";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, transactionNumberString,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }
        // UPC and Item

        if (StringUtils.isEmpty(this.upc) && StringUtils.isEmpty(this.item)
                && StringUtils.isEmpty(this.vpn)) {
            String key = "error.batch.upc_or_item_or_vpn_must_be_specified";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }

        if (!StringUtils.isEmpty(this.upc) && !StringUtils.isEmpty(this.item)
                || !StringUtils.isEmpty(this.item) && !StringUtils.isEmpty(this.vpn)
                || !StringUtils.isEmpty(this.upc) && !StringUtils.isEmpty(this.vpn)) {
            String key = "error.batch.cannot_specify_more_than_single_item_identifier";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }

        // Item and UPC supplement
        if (upcSuppString.length() != 0 && this.item.length() != 0) {
            String key = "error.batch.upc_supp_cannot_exist_with_item";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }

        // VPN and UPC supplement
        if (upcSuppString.length() != 0 && this.vpn.length() != 0) {
            String key = "error.batch.upc_supp_cannot_exist_with_vpn";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }

        // UPC supplement
        if (upcSuppString.length() > 0) {
            try {
                this.upcSupp = new Long(upcSuppString);
            } catch (NumberFormatException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, upcSuppString,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionDetail.class, key, parameters);
                this.transactionValid = false;
            }
        } else { // if no upcSupp, set value to 0 as it is required to read a valid item.
            this.upcSupp = new Long(0);
        }

        // Original Document Quantity
        if (originalDocumentQuantityString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.original_document_quantity");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.originalDocumentQuantity = BatchUtils.getDouble(
                        originalDocumentQuantityString, PRECISION4);
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                        originalDocumentQuantityString, String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionDetail.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Sign Indicator
        if (origDocQtySignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else if (!origDocQtySignInd.equals(EDIConstants.PLUS_SIGN)
                && !origDocQtySignInd.equals(EDIConstants.MINUS_SIGN)) {
            // field_not_null
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, origDocQtySignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if it is
        // EDIConstants.MINUS_SIGN
        else if (origDocQtySignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.originalDocumentQuantity = -this.originalDocumentQuantity;
        }

        // Original Unit Cost
        if (originalUnitCostString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.original_unit_cost");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.originalUnitCost = BatchUtils.getDouble(originalUnitCostString, PRECISION4);
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                        originalUnitCostString, String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionDetail.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // cost and qty cannot both be zero
        if (this.originalUnitCost == 0 && this.originalDocumentQuantity == 0) {
            String key = "error.batch.both_fields_cannot_equal_zero";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }

        // Sign Indicator for original unit cost
        if (origUnitCostSignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else if (!origUnitCostSignInd.equals(EDIConstants.PLUS_SIGN)
                && !origUnitCostSignInd.equals(EDIConstants.MINUS_SIGN)) {
            // field_not_null
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, origUnitCostSignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if it is
        // EDIConstants.MINUS_SIGN
        else if (origUnitCostSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.originalUnitCost = -this.originalUnitCost;
        }

        // TODO:Setting the tax basis based on cost
        // Need to change once file format changes
        for (Tax tax : this.ediItemTaxes) {
            tax.setTaxBasis(this.originalUnitCost * this.originalDocumentQuantity);
        }

        // check if the suplier tax region and location tax region is same.
        boolean isSameTaxRegion = isSameTaxRegionForSuppAndLoc(
                ediTransactionHeader.getVendorType(), ediTransactionHeader.getLocation(),
                ediTransactionHeader.getVendorID());

        // original tax code
        if (originalTaxCode.length() == 0 && isTaxOn && isSameTaxRegion) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.original_tax_code");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }
        double originalTaxRate = 0.0;
        // original tax rate (Double)
        if (originalTaxRateString.length() == 0 && isTaxOn) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.original_tax_rate");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else if (originalTaxRateString.length() == 0 && !isTaxOn) {
            originalTaxRate = 0.0;
        } else {
            try {
                originalTaxRate = BatchUtils.getDouble(originalTaxRateString, PRECISION10);
            } catch (ReIMException nfe) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                        originalTaxRateString, String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionDetail.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Total Allowance
        if (totalAllowanceString.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.total_allowance");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else {
            try {
                this.totalAllowance = BatchUtils.getDouble(totalAllowanceString, PRECISION4);
            } catch (ReIMException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalAllowanceString,
                        String.valueOf(this.lineID)};
                Logger.errorKey(EdiTransactionDetail.class, key, parameters);
                this.transactionValid = false;
            }
        }

        // Sign Indicator
        if (allowanceSignInd.length() == 0) {
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        } else if (!allowanceSignInd.equals(EDIConstants.PLUS_SIGN)
                && !allowanceSignInd.equals(EDIConstants.MINUS_SIGN)) {
            // field_not_null
            String key = "error.batch.invalid_field";
            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
            String[] parameters = new String[] { field, allowanceSignInd,
                    String.valueOf(this.lineID)};
            Logger.errorKey(EdiTransactionDetail.class, key, parameters);
            this.transactionValid = false;
        }
        // We are not going to store the sign indicator, so negate the amount if it is
        // EDIConstants.MINUS_SIGN
        else if (allowanceSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalAllowance = -this.totalAllowance;
        }

        // set these for the possibility of a rejection - the values
        // are truly invalid, but will be used for processing only.
        // when the insert/update happens, real values will be created.
        this.docId = new Long(this.transactionNumber);
        this.docDetailId = new Long(this.lineID);
    }

    public String createFlatRecord() {
        String record = "";

        record += BatchUtils.createFlatField(recordDescriptor, LEN_RECORD_DESCRIPTOR, NOPAD);
        record += BatchUtils.createFlatField(new Long(lineID), LEN_LINE_ID, PAD);
        record += BatchUtils.createFlatField(new Long(transactionNumber), LEN_TRANSACTION_NUMBER,
                PAD);
        if (!isEdiDownload) {
            record += BatchUtils.createFlatField(upc, LEN_ITEM, NOPAD);
            record += BatchUtils.createFlatField(upcSupp, LEN_ITEM_SUPP, NOPAD);
            record += BatchUtils.createFlatField(item, LEN_ITEM, NOPAD);
            record += BatchUtils.createFlatField(vpn, LEN_VPN, NOPAD);
            record += BatchUtils.createFlatField(
                    (originalDocumentQuantity < 0 ? EDIConstants.MINUS_SIGN
                            : EDIConstants.PLUS_SIGN), LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(new Double(Math.abs(originalDocumentQuantity)),
                    LEN_QUANTITY, PAD);
            record += BatchUtils.createFlatField((originalUnitCost < 0 ? EDIConstants.MINUS_SIGN
                    : EDIConstants.PLUS_SIGN), LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(new Double(Math.abs(originalUnitCost)), LEN_COST,
                    PAD);
            // tax info.Iterating multiple taxes and
            // writing to file
            for (Tax ediItemTax : ediItemTaxes) {
                record += BatchUtils.createFlatField(ediItemTax.getTaxCode(), LEN_TAX_CODE, NOPAD);
                record += BatchUtils.createFlatField(new Double(ediItemTax.getTaxRate()),
                        LEN_TAX_RATE, PAD, PRECISION10);
            }

            record += BatchUtils.createFlatField((totalAllowance < 0 ? EDIConstants.MINUS_SIGN
                    : EDIConstants.PLUS_SIGN), LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(new Double(Math.abs(totalAllowance)), LEN_AMOUNT,
                    PAD);
        } else {
            record += BatchUtils.createFlatField(item, LEN_ITEM, NOPAD);
            record += BatchUtils.createFlatField(upc, LEN_ITEM, NOPAD);
            record += BatchUtils.createFlatField(upcSupp, LEN_ITEM_SUPP, NOPAD);
            record += BatchUtils.createFlatField(vpn, LEN_VPN, NOPAD);
            record += BatchUtils.createFlatField(comments, LEN_REASON_COMMENTS, NOPAD);
            record += BatchUtils.createFlatField(reasonCode, LEN_REASON_CODE, NOPAD);
            record += BatchUtils
                    .createFlatField(reasonCodeDesc, LEN_REASON_CODE_DESCRIPTION, NOPAD);
            record += BatchUtils.createFlatField((discrepantQty < 0 ? EDIConstants.MINUS_SIGN
                    : EDIConstants.PLUS_SIGN), LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(new Double(Math.abs(discrepantQty)), LEN_QUANTITY,
                    PAD);
            record += BatchUtils.createFlatField((discrepantCost < 0 ? EDIConstants.MINUS_SIGN
                    : EDIConstants.PLUS_SIGN), LEN_IND, NOPAD);
            record += BatchUtils.createFlatFieldExp(new Double(Math.abs(discrepantCost)), LEN_COST,
                    PAD);
            // tax info
            for (Tax ediItemTax : ediItemTaxes) {
                record += BatchUtils.createFlatField(ediItemTax.getTaxCode(), LEN_TAX_CODE, NOPAD);
                record += BatchUtils.createFlatField(new Double(ediItemTax.getTaxRate()),
                        LEN_TAX_RATE, PAD, PRECISION10);
            }

        }

        return record;
    }

    public String renumberedRecord(long lineNumber, long tranNumber) {
        return (this.recordDescriptor
                + BatchUtils.createFlatField(new Long(lineNumber), LEN_LINE_ID, PAD)
                + BatchUtils.createFlatField(new Long(tranNumber), LEN_TRANSACTION_NUMBER, PAD) + originalRecord
                .substring(LEN_RECORD_DESCRIPTOR + LEN_LINE_ID + LEN_TRANSACTION_NUMBER));
    }

    public EdiValidationResult validateTaxWithPrimaryRejectionToFile(String vendorType,
            String vendorId, Long location, String documentType,
            EdiTransactionHeader ediTransactionHeader) throws ReIMException {

        ReIMSystemOptions systemOptions = ServiceFactory.getReIMSystemOptionsService().select();
        boolean isTaxOn = systemOptions.isProcessTaxes();

        try {
            // check if the suplier tax region and location tax region is same.
            boolean isSameTaxRegion = isSameTaxRegionForSuppAndLoc(vendorType, location, vendorId);
            // if tax discrepancy is found and tax validation type is system
            // then reject to file.If tax discrepant and tax validation type
            // is vendor then the record need to audited.If tax discrepant and validation
            // type is reconcile then document will be in TAXDIS status and im_tax_discrepancy rows
            // will be written for the document.
            if (isTaxOn && isSameTaxRegion) {
                DocumentItem documentItem = getDocumentItem(ediTransactionHeader, vendorId,
                        vendorType);

                this.isTaxDiscrepant = ServiceFactory.getTaxService().validateItemTaxes(
                        documentItem, location, this.systemTaxes,ediTransactionHeader.getVendorDocumentDate());
                // verify passed in tax versus system tax.
                ArrayList<Tax> ediItemTaxList = new ArrayList<Tax>(this.ediItemTaxes);
                ArrayList<Tax> systemTaxList = new ArrayList<Tax>(systemTaxes);
                if (isTaxDiscrepant && ReIMSystemOptions.getInstance().isAlwaysTrustRetailerTax()) {
                    Date vendorDocumentDate = ediTransactionHeader.getVendorDocumentDate()
                            .getCalendar().getTime();
                    ;
                    Tax[] taxes = getAllValidTaxes(vendorDocumentDate, vendorId, vendorType);
                    // Verify the passed in tax code and rate match an existing
                    // tax code and rate
                    boolean taxRateMatched = false;
                    boolean taxCodeMatched = false;
                    String fieldName = null;
                    String fieldValue = null;
                    for (int j = 0; j < ediItemTaxList.size() && j < systemTaxList.size(); j++) {
                        Tax ediItemTax = ediItemTaxList.get(j);
                        Tax systemTax = systemTaxList.get(j);
                        for (int i = 0; i < taxes.length; i++) {
                            if (ediItemTax.getTaxCode().equals(taxes[i].getTaxCode())) {
                                if (ediItemTax.getTaxRate().doubleValue() == taxes[i].getTaxRate()
                                        .doubleValue())
                                    taxRateMatched = true;
                                // tax rates did not match for tax code.
                                else {
                                    fieldName = ReIMI18NUtility
                                            .getMessage("batch.field.original_tax_rate");
                                    fieldValue = ediItemTax.getTaxRate() + "";
                                }
                                taxCodeMatched = true;
                                break;
                            }
                        }
                        if (!taxCodeMatched) {
                            fieldName = ReIMI18NUtility.getMessage("batch.field.original_tax_code");
                            fieldValue = ediItemTax.getTaxCode();
                        }
                        if (!taxCodeMatched || !taxRateMatched) {
                            Logger.errorKey(EdiTransactionDetail.class,
                                    "error.batch.invalid_field", new String[] { fieldName,
                                            fieldValue, String.valueOf(this.lineID)});
                            return FAILURE_REJECT_FILE;
                        }
                        // If the tax code and rate are valid, but they do not match the sysytem tax
                        // for
                        // the
                        // item/location/date, and tax processing is system tax, then reject the
                        // file.
                        if (systemOptions.isAlwaysTrustRetailerTax()) {
                            Logger.errorKey(EdiTransactionDetail.class,
                                    "error.batch.tax_not_match_system", new String[] {
                                            ediItemTax.getTaxCode(), ediItemTax.getTaxRate() + "",
                                            systemTax.getTaxCode(), systemTax.getTaxRate() + "",
                                            String.valueOf(this.lineID)});
                            return FAILURE_REJECT_FILE;
                        }

                    }

                } else if (isTaxDiscrepant
                        && ReIMSystemOptions.getInstance().isAlwaysTrustVendorTax()) {
                    this.shouldBeAudited = true;
                }
            }
        } catch (RetekException e) {
            throw new ReIMException(e);
        }
        return VALIDATION_SUCCESS;
    }

    public EdiValidationResult validateWithPrimaryRejectionToFile(String vendorType,
            String vendorId, Long location, String documentType,
            EdiTransactionHeader ediTransactionHeader) throws ReIMException {
        ReIMSystemOptions systemOptions = ServiceFactory.getReIMSystemOptionsService().select();
        boolean isVpnItemLookup = systemOptions.isVpnItemLookup();
        if (this.ediItemSource == null) {
            this.ediItemSource = EdiItemSource.ITEM_ID;
        }
        if (this.ediItemSource.equals(EdiItemSource.ITEM_ID) && !StringUtils.isEmpty(this.item)) {
            if (!ServiceFactory.getItemService().isValidItem(this.item)) {
                Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_item",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME, this.item,
                                String.valueOf(this.lineID)});
                return FAILURE_REJECT_FILE;
            }

            // as such documents come from RMS they will never come with VPN as item identifier,
            // only item ID
            if (!documentType.equals(Document.MERCHANDISE_INVOICE)) {
                if (documentType.equals(Document.DEBIT_MEMO_QUANTITY)
                        || documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                    String[] reasonCodes = ServiceFactory.getReasonCodesService()
                            .getTaxReasonCodesForCodeType(ReIMConstants.DISCREPANCY_TYPE_RTV_ABBR);
                    if (reasonCodes == null || reasonCodes.length <= 0) {
                        Logger.errorKey(EdiTransactionDetail.class,
                                "error.batch.no_reasonCode_defined", new String[] {
                                        EDI_UPLOAD_PROGRAM_NAME, this.item,
                                        String.valueOf(this.lineID)});
                        return FAILURE_REJECT_FILE;
                    }
                    this.reasonCode = reasonCodes[0];

                } else {
                    // It should never come here, because the EDI files can be only either Debit
                    // Memo Quantity or Credit Note Request Quantity for RTV orders.
                }
            }
        } // if item.length() > 0

        if (this.ediItemSource.equals(EdiItemSource.VPN) && !StringUtils.isEmpty(this.vpn)) {
            // Accept VPN as item identifier only if the system setting allow so
            if (!isVpnItemLookup) {
                Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_item_identifier",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID)});
                return FAILURE_REJECT_FILE;
            }
        }

        if (this.ediDetailAllowanceList != null && this.ediDetailAllowanceList.length != 0) {
            int ediDetailAllowanceLength = ediDetailAllowanceList.length;
            for (int i = 0; i < ediDetailAllowanceLength; i++) {
                EdiValidationResult allowanceValidationResult = ediDetailAllowanceList[i]
                        .validateWithPrimaryRejectionToFile(ediTransactionHeader);
                if (allowanceValidationResult.isFailure()) { return allowanceValidationResult; }

                // Maintain the sum of the allowances for the current TDETL
                this.totalAllowanceSum = this.totalAllowanceSum
                        + ediDetailAllowanceList[i].getAllowanceAmount();

            }

            // check allowance sum
            if (this.totalAllowanceSum != this.totalAllowance) {
                Logger
                        .errorKey(EdiTransactionDetail.class,
                                "error.batch.total_allowances_not_match", new String[] {
                                        String.valueOf(this.totalAllowance),
                                        String.valueOf(this.totalAllowanceSum),
                                        String.valueOf(this.lineID)});
                return FAILURE_REJECT_FILE;
            }

        }

        List<String> itemsByVpn = null;
        if (getEdiItemSource().equals(EdiItemSource.VPN)) {
        		itemsByVpn = ServiceFactory.getItemSupplierService().getItemsByVpnSupplier(
                        new VpnSupplier(this.vpn, ediTransactionHeader.getVendorID()));
            if (itemsByVpn == null || itemsByVpn.isEmpty()) {
                Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_vpn_supplier",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME, vpn, this.supplierId.toString(),
                                String.valueOf(this.lineID)});

                return FAILURE_REJECT_FILE;
            }

            // if we have more than a single item with the same VPN in the context of a
            // single supplier
            if (itemsByVpn.size() > 1) {
                Logger.errorKey(EdiTransactionDetail.class, "error.batch.duplicate_vpn",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME, vpn,
                                ediTransactionHeader.getVendorID().toString(),
                                String.valueOf(this.lineID)});

                ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_VPN);
                ediTransactionHeader.setRejectReason(EdiRejectReasons.INVALID_NON_UNIQUE_ITEM_VPN);
                ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                return FAILURE_REJECT_TABLES;
            }
        }

        return VALIDATION_SUCCESS;
    }

    public EdiValidationResult validateWithPrimaryRejectionToTables(
            EdiTransactionHeader ediTransactionHeader, boolean checkForFileRejections)
            throws ReIMException {
        itemSet = new HashSet<Object>();
        String item = null;
        String vendorId = null;

        if (!StringUtils.isEmpty(this.vpn)) {
            vendorId = ServiceFactory.getOrderService().getVendorFromOrder(
                    ediTransactionHeader.getOrderNumber().toString());

            List<String> listOfItems = null;

            if (!StringUtils.isEmpty(this.upc)) {
                // This will be only in the case when revalidating item selected from duplicate VPN
                // item mapping
                // In this case the item is treated as UPC
                listOfItems = new ArrayList<String>();
                listOfItems.add(this.upc);
            } else {
                listOfItems = ServiceFactory.getItemSupplierService().getItemsByVpn(this.vpn);
            }

            if (!listOfItems.isEmpty()) {
                // if we have more than a single item with the same VPN in the context of a single
                // supplier
                if (listOfItems.size() > 1) {
                    if (checkForFileRejections) {
                        Logger.errorKey(EdiTransactionDetail.class, "error.batch.duplicate_vpn",
                                new String[] { EDI_UPLOAD_PROGRAM_NAME, vpn,
                                        ediTransactionHeader.getVendorID().toString(),
                                        String.valueOf(this.lineID)});
                    }

                    ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_VPN);
                    ediTransactionHeader
                            .setRejectReason(EdiRejectReasons.INVALID_NON_UNIQUE_ITEM_VPN);
                    ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                    return FAILURE_REJECT_TABLES;
                }
                item = listOfItems.get(0);

                if (ediTransactionHeader.getVendorType().equals(Vendor.SUPPLIER)
                        && !isValidItemSupplierOrLinkedSupplier(new ItemSupplier(new Item(item),
                                new Supplier(vendorId, SupplierSource.ORDER)))) {
                    if (checkForFileRejections) {
                        Logger.errorKey(EdiTransactionDetail.class,
                                "error.batch.invalid_vpn_supplier", new String[] {
                                        EDI_UPLOAD_PROGRAM_NAME, vpn,
                                        ediTransactionHeader.getVendorID().toString(),
                                        String.valueOf(this.lineID)});
                    }

                    ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_VPN);
                    ediTransactionHeader.setRejectReason(EdiRejectReasons.INVALID_VPN_FOR_SUPPLIER);
                    ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                    return FAILURE_REJECT_TABLES;
                }

                if (!ediTransactionHeader.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
                    if (ediTransactionHeader.getDocumentType().equals(Document.DEBIT_MEMO_QUANTITY)
                            || ediTransactionHeader.getDocumentType().equals(
                                    Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                        String[] reasonCodes = ServiceFactory.getReasonCodesService()
                                .getTaxReasonCodesForCodeType(
                                        ReIMConstants.DISCREPANCY_TYPE_RTV_ABBR);
                        if (reasonCodes == null || reasonCodes.length <= 0) {
                            Logger.errorKey(EdiTransactionDetail.class,
                                    "error.batch.no_reasonCode_defined", new String[] {
                                            EDI_UPLOAD_PROGRAM_NAME, this.item,
                                            String.valueOf(this.lineID)});
                            return FAILURE_REJECT_FILE;
                        }
                        this.reasonCode = reasonCodes[0];

                    }
                }
                this.item = item;
                this.ediItemSource = EdiItemSource.VPN;
            } else {
                if (checkForFileRejections) {
                    Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_vpn",
                            new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vpn,
                                    String.valueOf(this.lineID)});
                }

                ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_VPN);
                ediTransactionHeader.setRejectReason(EdiRejectReasons.INVALID_VPN);
                ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                return FAILURE_REJECT_TABLES;
            }
        } else if (!StringUtils.isEmpty(this.upc)) {
            // this will solve issues with 10.0 not using a upc supp
            if (this.upcSupp == null) {
                this.upcSupp = new Long(0);
            }
            vendorId = ServiceFactory.getOrderService().getVendorFromOrder(
                    ediTransactionHeader.getOrderNumber().toString());
//            item = ServiceFactory.getItemService().validUpc(this.upc, this.upcSupp);
            item = SmrDocumentService.validUpc(this.getUpc(), Long.valueOf(ediTransactionHeader.getVendorID()));
            if (item != null) {

                if (ediTransactionHeader.getVendorType().equals(Vendor.SUPPLIER)
                        && !isValidItemSupplierOrLinkedSupplier(new ItemSupplier(new Item(item),
                                new Supplier(vendorId, SupplierSource.ORDER)))) {
                    if (checkForFileRejections) {
                        Logger.errorKey(EdiTransactionDetail.class,
                                "error.batch.invalid_upc_supplier", new String[] {
                                        EDI_UPLOAD_PROGRAM_NAME, upc,
                                        ediTransactionHeader.getVendorID().toString(),
                                        String.valueOf(this.lineID)});
                    }

                    ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_ITEM);
                    ediTransactionHeader.setRejectReason(EdiRejectReasons.INVALID_UPC_FOR_SUPPLIER);
                    ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                    return FAILURE_REJECT_TABLES;
                }

                if (!ediTransactionHeader.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
                    if (ediTransactionHeader.getDocumentType().equals(Document.DEBIT_MEMO_QUANTITY)
                            || ediTransactionHeader.getDocumentType().equals(
                                    Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                        String[] reasonCodes = ServiceFactory.getReasonCodesService()
                                .getTaxReasonCodesForCodeType(
                                        ReIMConstants.DISCREPANCY_TYPE_RTV_ABBR);
                        if (reasonCodes == null || reasonCodes.length <= 0) {
                            Logger.errorKey(EdiTransactionDetail.class,
                                    "error.batch.no_reasonCode_defined", new String[] {
                                            EDI_UPLOAD_PROGRAM_NAME, this.item,
                                            String.valueOf(this.lineID)});
                            return FAILURE_REJECT_FILE;
                        }
                        this.reasonCode = reasonCodes[0];

                    }
                }
                this.item = item;
                this.ediItemSource = EdiItemSource.UPC;
            } else {
                if (checkForFileRejections) {
                    Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_upc",
                            new String[] { EDI_UPLOAD_PROGRAM_NAME, this.upc,
                                    String.valueOf(this.lineID)});
                }

                ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_ITEM);
                ediTransactionHeader.setRejectReason(EdiRejectReasons.INVALID_UPC);
                ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                return FAILURE_REJECT_TABLES;
            }
        } else if (!StringUtils.isEmpty(this.item)) {
            Supplier supplier = null;
            if (ediTransactionHeader.isSupplierSiteEnabled() && ediTransactionHeader.getSupplierSiteID() != null ) {
                supplier = new Supplier(ediTransactionHeader.getSupplierSiteID(),
                        SupplierSource.DOCUMENT);
            } else {
                supplier = new Supplier(ediTransactionHeader.getDocumentSupplierParent(), SupplierSource.DOCUMENT);
            }
            if (ServiceFactory.getItemService().isValidItem(this.item)) {
                if (ediTransactionHeader.getVendorType().equals(Vendor.SUPPLIER)
                        && !isValidItemSupplierOrLinkedSupplier(new ItemSupplier(
                                new Item(this.item), supplier))) {
                    if (checkForFileRejections) {
                        Logger.errorKey(EdiTransactionDetail.class,
                                "error.batch.invalid_item_supplier", new String[] {
                                        EDI_UPLOAD_PROGRAM_NAME, this.item,
                                        ediTransactionHeader.getVendorID().toString(),
                                        String.valueOf(this.lineID)});
                    }

                    ediTransactionHeader.setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_ITEM);
                    ediTransactionHeader
                            .setRejectReason(EdiRejectReasons.INVALID_ITEM_FOR_SUPPLIER);
                    ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);

                    return FAILURE_REJECT_TABLES;
                }
                if (ediTransactionHeader.getMerchType() != null) {
                    if (!ediTransactionHeader.getMerchType().equals(
                            ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {
                        if (!isItemOnTheOrder(this.item, ediTransactionHeader)) {
                            if (checkForFileRejections) {
                                Logger.errorKey(EdiTransactionDetail.class,
                                        "error.batch.item_not_on_the_order", new String[] {
                                                EDI_UPLOAD_PROGRAM_NAME, this.item,
                                                ediTransactionHeader.getOrderNumber().toString(),
                                                String.valueOf(this.lineID)});
                            }
                            ediTransactionHeader
                                    .setErrorColumnId(EdiRejectReasons.ERROR_COLUMN_ID_ITEM);
                            ediTransactionHeader
                                    .setRejectReason(EdiRejectReasons.ITEM_NOT_ON_THE_ORDER);
                            ediTransactionHeader.setRejectedDocDetailId(this.docDetailId);
                            return FAILURE_REJECT_TABLES;
                        }
                    }
                }

                if (!ediTransactionHeader.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
                    if (ediTransactionHeader.getDocumentType().equals(Document.DEBIT_MEMO_QUANTITY)
                            || ediTransactionHeader.getDocumentType().equals(
                                    Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                        String[] reasonCodes = ServiceFactory.getReasonCodesService()
                                .getTaxReasonCodesForCodeType(
                                        ReIMConstants.DISCREPANCY_TYPE_RTV_ABBR);
                        if (reasonCodes == null || reasonCodes.length <= 0) {
                            Logger.errorKey(EdiTransactionDetail.class,
                                    "error.batch.no_reasonCode_defined", new String[] {
                                            EDI_UPLOAD_PROGRAM_NAME, this.item,
                                            String.valueOf(this.lineID)});
                            return FAILURE_REJECT_FILE;
                        }
                        this.reasonCode = reasonCodes[0];

                    }
                }
            }
        }

        // Original Document Quanity - no business-level validation at this
        // point.
        // Original Unit Cost - no business-level validation at this point.

        return VALIDATION_SUCCESS;
    }

    private boolean isValidItemSupplierOrLinkedSupplier(ItemSupplier itemSupplier)
            throws ReIMException {
        boolean isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
                .isSupplierSiteInd();

        List<Supplier> supplierList = new ArrayList<Supplier>();

        // Determine the parent supplier if supplier site is on.
        // Based on the parent supplier determine the group and all related parent suppliers
        // and their supplier sites.
        if (isSupplierSiteIndOn) {
            Supplier parentSupplier = new Supplier(ServiceFactory.getVendorService()
                    .getSupplierParent(itemSupplier.getSupplier().getVendorId()));

            if (null == parentSupplier.getVendorId()) {
                supplierList = ServiceFactory.getSupplierGroupService()
                        .getSupplierGroupSupplierSites(itemSupplier.getSupplier().getVendorId());
            } else {
                supplierList = ServiceFactory.getSupplierGroupService()
                        .getSupplierGroupSupplierSites(parentSupplier.getVendorId());
            }
        }

        if (!supplierList.isEmpty()) {
            return ServiceFactory.getItemSupplierService().isValidItemSupplier(
                    itemSupplier.getItem(), supplierList, isSupplierSiteIndOn);
        } else {
            return ServiceFactory.getItemSupplierService().isValidItemSupplier(itemSupplier,
                    isSupplierSiteIndOn);
        }
    }

    // check if the suplier tax region and location tax region is same.
    private boolean isSameTaxRegionForSuppAndLoc(String vendorType, Long locationId, String vendorId)
            throws ReIMException {
        long locTaxRegion = -1L;
        long supplierTaxRegion = -1L;
        try {
            if (vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
                TransactionManagerFactory.getInstance().start();
                locTaxRegion = DaoFactory.getLocationBean()
                        .getTaxRegion(String.valueOf(locationId));
                supplierTaxRegion = DaoFactory.getSupplierBean().getTaxRegion(vendorId);
                TransactionManagerFactory.getInstance().end();
            }
            if (locTaxRegion == supplierTaxRegion) {
                return true;
            } else {
                return false;
            }
        } catch (RetekException e) {
            throw new ReIMException(e);
        }
    }

    private boolean isItemOnTheOrder(String itemId, EdiTransactionHeader ediTransactionHeader)
            throws ReIMException {
        String orderNo = ediTransactionHeader.getOrderNumber().toString();
        if (orderNo != null && ediTransactionHeader.getRtvInd().equals(ReIMConstants.YES)) {
            Item[] orderItems = ServiceFactory.getOrderService().getSortedOrderRTVItems(orderNo);
            for (int i = 0; i < orderItems.length; i++) {
                String rtvItemId = orderItems[i].getItemId();
                if (rtvItemId.equals(itemId)) { return true; }
            }
        } else if (orderNo != null) {
            ArrayList orderItems = ServiceFactory.getOrderService().getOrderItems(orderNo);
            String[] itemIds = (String[]) orderItems.toArray(new String[orderItems.size()]);

            for (int i = 0; i < itemIds.length; i++) {
                if (itemIds[i].equals(itemId)) { return true; }
            }
        }
        return false;
    }

    public long getLineID() {
        return lineID;
    }

    public String getRecordDescriptor() {
        return recordDescriptor;
    }

    public String getItem() {
        return item;
    }

    public double getOriginalDocumentQuantity() {
        return originalDocumentQuantity;
    }

    public double getOriginalUnitCost() {
        return originalUnitCost;
    }

    public Long getUpcSupp() {
        return upcSupp;
    }

    public long getTransactionNumber() {
        return transactionNumber;
    }

    public void setLineID(long lineID) {
        this.lineID = lineID;
    }

    public void setRecordDescriptor(String recordDescriptor) {
        this.recordDescriptor = recordDescriptor;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setOriginalDocumentQuantity(double originalDocumentQuantity) {
        this.originalDocumentQuantity = originalDocumentQuantity;
    }

    public void setOriginalUnitCost(double originalUnitCost) {
        this.originalUnitCost = originalUnitCost;
    }

    public void setUpcSupp(Long upcSupp) {
        this.upcSupp = upcSupp;
    }

    public void setTransactionNumber(long transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public String getOriginalRecord() {
        return originalRecord;
    }

    public boolean isTransactionValid() {
        return transactionValid;
    }

    public void setTransactionValid(boolean transactionValid) {
        this.transactionValid = transactionValid;
    }

    public double getDetailTotalAllowanceSum() {
        return totalAllowanceSum;
    }

    public EdiDetailAllowance[] getEdiDetailAllowanceList() {
        return ediDetailAllowanceList;
    }

    public double getTotalAllowance() {
        return totalAllowance;
    }

    public void setDetailTotalAllowanceSum(double detailTotalAllowanceSum) {
        this.totalAllowanceSum = detailTotalAllowanceSum;
    }

    public void setEdiDetailAllowanceList(EdiDetailAllowance[] ediDetailAllowanceList) {
        this.ediDetailAllowanceList = ediDetailAllowanceList;
    }

    public void setOriginalRecord(String originalRecord) {
        this.originalRecord = originalRecord;
    }

    public void setTotalAllowance(double totalAllowance) {
        this.totalAllowance = totalAllowance;
    }

    public double getTotalAllowanceSum() {
        return totalAllowanceSum;
    }

    public void setTotalAllowanceSum(double totalAllowanceSum) {
        this.totalAllowanceSum = totalAllowanceSum;
    }

    public Long getDocDetailId() {
        return docDetailId;
    }

    public Long getDocId() {
        return docId;
    }

    public void setDocDetailId(Long docDetailId) {
        this.docDetailId = docDetailId;
    }

    public void setDocId(Long docId) {
        this.docId = docId;
    }

    public String getComments() {
        return comments;
    }

    public double getDiscrepantCost() {
        return discrepantCost;
    }

    public double getDiscrepantQty() {
        return discrepantQty;
    }

    public String getReasonCode() {
        return reasonCode;
    }

    public String getReasonCodeDesc() {
        return reasonCodeDesc;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public void setDiscrepantCost(double discrepantCost) {
        this.discrepantCost = discrepantCost;
    }

    public void setDiscrepantQty(double discrepantQty) {
        this.discrepantQty = discrepantQty;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public void setReasonCodeDesc(String reasonCodeDesc) {
        this.reasonCodeDesc = reasonCodeDesc;
    }

    public boolean getIsEdiDownload() {
        return isEdiDownload;
    }

    public void setIsEdiDownload(boolean isEdiDownload) {
        this.isEdiDownload = isEdiDownload;
    }

    public String getVpn() {
        return vpn;
    }

    public void setVpn(String vpn) {
        this.vpn = vpn;
    }

    public static Set getItemSet() {
        return itemSet;
    }

    public static void setItemSet(Set inputItemSet) {
        itemSet = inputItemSet;
    }

    public boolean isItemPassedFromFile() {
        return ediItemSource.equals(EdiItemSource.ITEM_ID);
    }

    public boolean isToBeAudited() {
        return this.shouldBeAudited;
    }

    public void setShouldBeAudited(boolean shouldBeAudited) {
        this.shouldBeAudited = shouldBeAudited;
    }

    public EdiItemSource getEdiItemSource() {
        return ediItemSource;
    }

    public void setEdiItemSource(EdiItemSource source) {
        this.ediItemSource = source;
    }

    // getAllValidTaxes takes in the document date and supplier
    // for retrieving the taxes applicable for the supplier
    private Tax[] getAllValidTaxes(Date docDate, String supplier, String vendorType)
            throws RetekException {
        List<VendorTaxes> vendorTaxes = ServiceFactory.getTaxService().getVendorTaxes(docDate,
                supplier, VendorType.fromCode(vendorType));
        Set<Tax> taxList = new HashSet<Tax>();
        for (VendorTaxes vendorTax : vendorTaxes) {
            taxList.addAll(vendorTax.getTaxes());
        }
        return taxList.toArray(new Tax[taxList.size()]);
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    private String getItemBySource(List<String> itemsByVpn) throws ReIMException {
        if (getEdiItemSource().equals(EdiItemSource.ITEM_ID)) {
            return this.item;
        } else if (getEdiItemSource().equals(EdiItemSource.UPC)) {
            return this.upc;
        } else {// item is defined by VPN
            return itemsByVpn.get(0);
        }
    }

    private DocumentItem getDocumentItem(EdiTransactionHeader ediTransactionHeader,
            String vendorId, String vendorType) {
        DocumentItem documentItem = new DocumentItem();
        documentItem.setTaxes(this.ediItemTaxes);
        documentItem.setUnitCost(this.originalUnitCost);
        documentItem.setItem(new Item(this.item));
        documentItem.getDocument().setOrderNo(ediTransactionHeader.getOrderNumber());
        documentItem.getDocument().setVendor(new Vendor(vendorId, VendorType.fromCode(vendorType)));
        documentItem.setQty(this.getOriginalDocumentQuantity());
        return documentItem;
    }

    private Long mapItemSupplementToLineLevel(String itemSupplement) {
        Map<String, Long> itemSupplementMap = new HashMap<String, Long>();
        itemSupplementMap.put(ReIMI18NUtility.getWidget("label.item_level_1_name"), 1l);
        itemSupplementMap.put(ReIMI18NUtility.getWidget("label.item_level_2_name"), 2l);
        itemSupplementMap.put(ReIMI18NUtility.getWidget("label.item_level_3_name"), 3l);
        if (itemSupplementMap.containsKey(itemSupplement))
            return itemSupplementMap.get(itemSupplement);
        else {
            return 0l;
        }
    }

    public Set<Tax> getEdiItemTaxes() {
        return ediItemTaxes;
    }

    public void setEdiItemTaxes(Set<Tax> ediItemTaxes) {
        this.ediItemTaxes = ediItemTaxes;
    }

    public void addEdiItemTax(Tax ediItemTax) {
        this.ediItemTaxes.add(ediItemTax);
    }

    public Set<Tax> getSystemTaxes() {
        return systemTaxes;
    }

    public void setSystemTaxes(Set<Tax> systemTaxes) {
        this.systemTaxes = systemTaxes;
    }

    public boolean isTaxDiscrepant() {
        return isTaxDiscrepant;
    }

    public void setTaxDiscrepant(boolean isTaxDiscrepant) {
        this.isTaxDiscrepant = isTaxDiscrepant;
    }
}