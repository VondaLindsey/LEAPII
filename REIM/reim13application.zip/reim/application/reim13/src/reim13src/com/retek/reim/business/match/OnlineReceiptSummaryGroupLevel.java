package com.retek.reim.business.match;

import java.util.Iterator;
import java.util.Map;

import oracle.retail.reim.utils.Severity;

import com.retek.merch.utils.Quantity;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.foundation.AShipmentBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.services.matching.AutoMatchService;

/**
 * -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		20-Jun-2013	BNaik		Reverting the Oracle Bug 6955602 fix because it allows summary matching on the receipt 
 *    including the quantities of the receipt item that had been already resolved with another invoice.                                           									
 */

public class OnlineReceiptSummaryGroupLevel implements ReceiptGroup {
    private Receipt[] receipts;

    public OnlineReceiptSummaryGroupLevel() {
    }

    public OnlineReceiptSummaryGroupLevel(Receipt[] receipts) {
        this.receipts = receipts;
    }

    public Quantity getCost() throws ReIMException {
        Quantity totalCost = new Quantity(0);
        try {
            ReIMQuantity unitCost = null;

            // loop through receipts and receiptItems to get the total cost
            Receipt receipt = null;
            Map receiptItems = null;
            ReceiptItem receiptItem = null;

            int receiptsLength = receipts.length;
            for (int i = 0; i < receiptsLength; i++) {
                receipt = receipts[i];
                receiptItems = receipt.getReceiptItems();
                Iterator j = receiptItems.values().iterator();
                /* BRN V 1.2 Begin - removed
                AShipmentBean bean = (AShipmentBean) ReIMBeanFactory
                .getBean(ReIMBeanFactory.AShipmentBean);
                BRN V 1.2 End */
                while (j.hasNext()) {
                    receiptItem = (ReceiptItem) j.next();
                    unitCost = new ReIMQuantity(receiptItem.getUnitCost());
                    
                    /* BRN V 1.2 Begin - removed
                    long itemId=Long.parseLong(receiptItem.getItemId());
                    long shipment=Long.parseLong(receiptItem.getReceiptId());
                    if(receiptItem
                            .getAvailableToMatchQty()<=0 && !bean.isCostMatched(itemId,shipment)){
                    	totalCost = totalCost.add(unitCost.multiply(receiptItem
                                .getQtyReceived()));
                    }else{
                    totalCost = totalCost.add(unitCost.multiply(receiptItem
                            .getAvailableToMatchQty()));
                    }
                    BRN V 1.2 End */
                    
                    // BRN V 1.2 Begin - added
                    totalCost = totalCost.add(unitCost.multiply(receiptItem
                    		.getAvailableToMatchQty()));
                    // BRN V 1.2 End
                }
            }
        } catch (Exception e) {
            ReIMException exception = new ReIMException("error.cannot_get_total_cost_for_receipts",
                    Severity.WARN, e, AutoMatchService.class);
            throw exception;
        }
        return totalCost;
    }

    public Quantity getQty() throws ReIMException {
        Quantity totalQty = new Quantity(0);
        try {
            // loop through receipts and receiptItems to get the total cost
            Map receiptItems = null;
            ReceiptItem receiptItem = null;

            int receiptsLength = receipts.length;
            
            /* BRN V 1.2 Begin - removed
            AShipmentBean bean = (AShipmentBean) ReIMBeanFactory
            .getBean(ReIMBeanFactory.AShipmentBean);
            BRN V 1.2 End */ 
            
            for (int i = 0; i < receiptsLength; i++) {
                receiptItems = receipts[i].getReceiptItems();
                Iterator j = receiptItems.values().iterator();

                while (j.hasNext()) {
                    receiptItem = (ReceiptItem) j.next();
                    
                    /* BRN V 1.2 Begin - removed
                    long itemId=Long.parseLong(receiptItem.getItemId());
                    long shipment=Long.parseLong(receiptItem.getReceiptId());
                    if(receiptItem.getAvailableToMatchQty()<=0 && !bean.isCostMatched(itemId,shipment) ){
                    totalQty = totalQty.add(receiptItem.getQtyReceived());
                    }else{
                    	totalQty = totalQty.add(receiptItem.getAvailableToMatchQty());
                    }
                    BRN V 1.2 End */
                    
                    // BRN V 1.2 Begin - added
                    totalQty = totalQty.add(receiptItem.getAvailableToMatchQty());
                    // BRN V 1.2 End
                }
            }
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.cannot_get_total_quantity_for_receipts", Severity.WARN, e,
                    AutoMatchService.class);
            throw exception;
        }
        return totalQty;
    }

    public void updateInvoiceMatchStatus(String status) throws ReIMException {
        try {
            int receiptsLength = receipts.length;
            for (int i = 0; i < receiptsLength; i++) {
                receipts[i].setInvoiceMatchStatus(status);
            }
        } catch (Exception e) {
            throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR, e,
                    this);
        }
    }

    public Receipt[] getReceipts() throws ReIMException {
        return receipts;
    }

    /**
     * Sets the receipts.
     * 
     * @param receipts
     *            The receipts to set
     */
    public void setReceipts(Receipt[] receipts) {
        this.receipts = receipts;
    }

}
