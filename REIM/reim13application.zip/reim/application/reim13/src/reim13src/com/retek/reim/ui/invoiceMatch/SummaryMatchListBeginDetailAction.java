package com.retek.reim.ui.invoiceMatch;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.services.matching.ISummaryMatchService;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.services.ServiceFactory;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2 	21-Apr-2013	The items in the Detail Matching screen are cached from the previous manual group.
 *
 *
 */
public class SummaryMatchListBeginDetailAction extends ReIMSecureAction {

    private ISummaryMatchService summaryMatchService;

    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        try {
            SummaryMatchListForm summaryMatchListForm = (SummaryMatchListForm) request.getSession()
                    .getAttribute("SummaryMatchListForm");

            // Save the summary match groups if changed.
            // Determine if the source is a manual or auto group.
            if (summaryMatchListForm.getIsFormChanged()) {
                if (summaryMatchListForm.getManualGroupId() != null
                        && !summaryMatchListForm.getManualGroupId().equals(
                                ReIMConstants.EMPTY_STRING)) {
                    // Check the manual group for invoices and receipts.
                    if (summaryMatchListForm.getSelectedGroupInvoiceMap().size() > 0) {
                        getSummaryMatchService().saveManualGroup(
                                summaryMatchListForm);
                    } else {
                        saveErrors(request, errors, "alert.invoices_must_exist");
                        return mapping.findForward("failure");
                    }
                } else {
                    // Check the auto group for invoices and receipts, if neither exist no
                   // saving is required since the auto group will be regenerated upon success.
                    if (summaryMatchListForm.getSelectedGroupInvoiceMap().size() > 0) {
                          getSummaryMatchService().saveAutoGroup(summaryMatchListForm);
                        if (summaryMatchListForm.getManualGroupId() != null
                                && !summaryMatchListForm.getManualGroupId().equals(
                                        ReIMConstants.EMPTY_STRING)) {
                        	getSummaryMatchService().saveManualGroup(
                                    summaryMatchListForm);
                        	request.getSession().setAttribute("fromGroupType", "manual");
                        }
                    } else {
                        saveErrors(request, errors, "alert.invoices_must_exist");
                        return mapping.findForward("failure");
                    }
                }
             }

            // Check that details exist for the invoices.
            InvoiceSummaryView[] invoicesView = summaryMatchListForm.getSelectedGroupInvoiceList();
            if (invoicesView == null) {
                saveErrors(request, errors, "alert.invoices_must_exist");
                return mapping.findForward("failure");
            }
            for (int i = 0; i < invoicesView.length; i++) {
                if (!invoicesView[i].isDetailsExist()) {
                    errors.add("alert.invoice_details_required", new ActionError(
                            "alert.invoice_details_required", invoicesView[i].getInvoice()
                                    .getInvoice().getExtDocId()));
                    saveErrors(request, errors);
                    return mapping.findForward("failure");
                }
            }
            
            //  BRN Caching OLR V1.2 - Begin
            request.getSession().setAttribute("fromSummaryMatchScreen", "true");
            //  BRN Caching OLR V1.2 - End
            return mapping.findForward("success");
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return mapping.findForward("failure");
        } catch (Exception e) {
            ReIMException newEx = new ReIMException(
                    "error.summary_match_list_begin_detail_action.do_perform", Severity.ERROR, e,
                    this);
            saveErrors(request, errors, newEx);
            return mapping.findForward("failure");
        }
    }

    public ISummaryMatchService getSummaryMatchService() {
        return summaryMatchService;
    }

    public void setSummaryMatchService(ISummaryMatchService summaryMatchService) {
        this.summaryMatchService = summaryMatchService;
    }

}
