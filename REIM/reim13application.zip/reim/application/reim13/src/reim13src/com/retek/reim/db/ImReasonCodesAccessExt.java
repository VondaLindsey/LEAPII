package com.retek.reim.db;

import java.sql.*;
import java.util.*;

import org.springframework.util.*;

import oracle.jdbc.*;
import oracle.retail.reim.data.*;
import oracle.retail.reim.utils.*;

import com.retek.reim.business.*;
import com.retek.reim.business.document.*;
import com.retek.reim.merch.utils.*;
import com.retek.reim.ui.discrepancyResolution.*;

/**
 *  -- Modification History
 * -- Version Date      Developer   Issue Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		13-May-2013	Syed Qadri		Modification Change :Commented out the SELECT statement to use the new one. IMS Ticket # 160668 (Release 1549). This is for 
 * 		                                                         performance enhancement according Metalink Doc id 847827 applied Bug fix 8507757.
 * 										
 */

public class ImReasonCodesAccessExt extends ImReasonCodesAccess implements IImReasonCodesAccessExt {
    /**
     * Retrieves a list of reason codes and related information regarding the reason code. The user
     * may optionally restrict the list by passing in a reason code type (cost/quantity), document
     * type and/or passing in a specific reason code ID to be used for validation purposes.
     * 
     * The method does NOT return reason codes that are in deleted status. a
     * 
     * @param businessRoleId,
     *            role ID of the current user
     * @param id
     *            ID of the specific reason code to lookup
     * @param reasonCodeType
     *            the type of reason code cost/quantity
     * @param documentType
     *            the type of a document
     * 
     * @return ImReasonCodesRow[]
     * 
     * @throws ReIMException
     */
    public ImReasonCodesRow[] getReasonCodes(long businessRoleId, String id, String reasonCodeType,
            String documentType,Map<String,String> actionListMap ) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<ImReasonCodesRow> arrayList = new ArrayList<ImReasonCodesRow>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT RC.REASON_CODE_ID, RC.REASON_CODE_DESC, RC.ACTION, RC.COMMENT_REQUIRED_IND, RC.HINT_COMMENT, RC.DELETE_IND ");
            sqlText.append("  FROM IM_REASON_CODES RC,IM_BUSINESS_ROLES_REASON_CODES BR");
            sqlText.append(" WHERE RC.REASON_CODE_ID = BR.REASON_CODE_ID ");
            sqlText.append("   AND BR.BUSINESS_ROLE_ID = ? ");
            sqlText.append("   AND RC.DELETE_IND = 'N' ");

            // Specific reason code id is not required, but if known restrict by
            // the id.
            if (id != null) {
                sqlText.append(" AND RC.REASON_CODE_ID = Upper(?)");
            }

            // Specific reason code type is not required, but if known restrict
            // by the type.
            if (reasonCodeType != null) {
                sqlText.append("   AND RC.REASON_CODE_TYPE = ? ");
                // Specific document type is not required, but if known restrict
                // by the document
                // type and reason code type.
                if (documentType != null && actionListMap != null ){
                        sqlText.append(" AND ACTION IN ( ");
                        sqlText.append(sqlCommaList(actionListMap));
                        sqlText.append(") ");
                }
            }
            sqlText.append(" ORDER BY RC.REASON_CODE_DESC ");
            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());
            stmt.setLong(1, businessRoleId);
            if (id != null) {
                stmt.setString(2, id);
            }
            if (reasonCodeType != null) {
                stmt.setString((id == null ? 2 : 3), reasonCodeType);
            }

            rs = stmt.executeQuery();

            // check for valid ResultSet
            ImReasonCodesRow aRow = null;
            String reasonCode = null;
            String reasonDesc = null;
            String action = null;
            String commentRequiredInd = null;
            String hintComment = null;
            String deleteInd = null;
            while (rs.next()) {
                reasonCode = rs.getString("REASON_CODE_ID");
                reasonDesc = rs.getString("REASON_CODE_DESC");
                action = rs.getString("ACTION");
                commentRequiredInd = rs.getString("COMMENT_REQUIRED_IND");
                hintComment = rs.getString("HINT_COMMENT");
                deleteInd = rs.getString("DELETE_IND");
                aRow = new ImReasonCodesRow(null, reasonCode, reasonDesc, action,
                        commentRequiredInd, hintComment, deleteInd);
                arrayList.add(aRow);
            }

            if (arrayList.size() > 0) {
                return (ImReasonCodesRow[]) arrayList
                        .toArray(new ImReasonCodesRow[arrayList.size()]);
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.reason_codes_service.get_reason_codes",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);
            }
        }
    }
  
    public List<ImReasonCodesRow> getReasonCodes(long businessRoleId, String reasonCodeType,
            String reasonCodeAction) throws ReIMException {

        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        List<ImReasonCodesRow> reasonCodes = new ArrayList<ImReasonCodesRow>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT RC.REASON_CODE_ID, RC.REASON_CODE_DESC, RC.ACTION, RC.COMMENT_REQUIRED_IND, RC.HINT_COMMENT, RC.DELETE_IND ");
            sqlText.append("  FROM IM_REASON_CODES RC,IM_BUSINESS_ROLES_REASON_CODES BR");
            sqlText.append(" WHERE RC.REASON_CODE_ID = BR.REASON_CODE_ID ");
            sqlText.append("   AND BR.BUSINESS_ROLE_ID = ? ");
            sqlText.append("   AND RC.DELETE_IND = 'N' ");
            sqlText.append("   AND RC.REASON_CODE_TYPE = ? ");
            sqlText.append("   AND RC.ACTION = ? ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());

            stmt.setLong(1, businessRoleId);
            stmt.setString(2, reasonCodeType);
            stmt.setString(3, reasonCodeAction);

            rs = stmt.executeQuery();

            while (rs.next()) {
                String reasonCode = rs.getString("REASON_CODE_ID");
                String reasonDesc = rs.getString("REASON_CODE_DESC");
                String action = rs.getString("ACTION");
                String commentRequiredInd = rs.getString("COMMENT_REQUIRED_IND");
                String hintComment = rs.getString("HINT_COMMENT");
                String deleteInd = rs.getString("DELETE_IND");
                ImReasonCodesRow aRow = new ImReasonCodesRow(null, reasonCode, reasonDesc, action,
                        commentRequiredInd, hintComment, deleteInd);
                reasonCodes.add(aRow);
            }

            return reasonCodes;

        } catch (Exception exception) {
            throw new ReIMException("error.reason_codes_service.get_reason_codes", Severity.ERROR,
                    exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);
            }
        }
    }

    private HashMap<String, String> getActionListMapForQtyDiscrepancy(String documentType,
            String varianceSign, boolean selectedCostQuantityIsOther, String receiptsExist,
            HashMap<String, String> actionListMap, String selectedCostQuantity) {
        // Include only actions related to cost discrepancies
        if (documentType.equals(Document.MERCHANDISE_INVOICE)) {
            actionListMap = getQtyActionListMapforInvoice(varianceSign,
                    selectedCostQuantityIsOther, receiptsExist, selectedCostQuantity);
        } else if (documentType.equals(Document.CREDIT_NOTE)) {
            if (varianceSign != null && varianceSign.equals(ReIMConstants.POSITIVE)) {
                actionListMap = ReasonCode.QUANTITY_CRDNT_POSITIVE_ACTIONS;
            } else if (varianceSign != null
                    && varianceSign.equals(ReIMConstants.NEGATIVE)) {
                actionListMap = ReasonCode.QUANTITY_CRDNT_NEGATIVE_ACTIONS;
            }
        } else {
            // Include only actions for non invoice documents
            actionListMap = ReasonCode.QUANTITY_NON_INVOICE_ACTIONS;
        }
        return actionListMap;
    }

    private HashMap<String, String> getQtyActionListMapforInvoice(String varianceSign,
            boolean selectedCostQuantityIsOther, String receiptsExist, String selectedCostQuantity) {
        HashMap<String, String> actionListMap;
        // Include only actions related to cost
        // discrepancies
        if (receiptsExist != null && receiptsExist.equals(ReIMConstants.YES)) {
            actionListMap = getQtyActionListMapWhenReceiptExists(varianceSign,
                    selectedCostQuantityIsOther,selectedCostQuantity );
        } else {
            actionListMap = getQtyActionListMapWhenReceiptDoNotExists(varianceSign,
                    selectedCostQuantityIsOther);
        }
        return actionListMap;
    }

    private HashMap<String, String> getQtyActionListMapWhenReceiptDoNotExists(String varianceSign,
            boolean selectedCostQuantityIsOther) {
        // Include only actions where reciepts do not
        // exist
        if (selectedCostQuantityIsOther) {
            // Include actions regardless of variance
            // sign
            return ReasonCode.QUANTITY_INVOICE_NO_RECEIPT_ACTIONS;
        } else if (varianceSign != null
                && varianceSign.equals(ReIMConstants.POSITIVE)) {
            // Include actions appropriate only for when
            // the variance is
            // greater than or equal to zero
            return ReasonCode.QUANTITY_INVOICE_NO_RECEIPT_POSITIVE_ACTIONS;
        } else if (varianceSign != null
                && varianceSign.equals(ReIMConstants.NEGATIVE)) {
            // Include actions appropriate only for when
            // the variance is
            // less than zero
            return  ReasonCode.QUANTITY_INVOICE_NO_RECEIPT_NEGATIVE_ACTIONS;
        } else {
            // Include actions regardless of variance
            // sign
            return ReasonCode.QUANTITY_INVOICE_NO_RECEIPT_ACTIONS;
        }
    }

    private HashMap<String, String> getQtyActionListMapWhenReceiptExists(String varianceSign,
            boolean selectedCostQuantityIsOther, String selectedCostQuantity) {
        // Include only actions where reciepts exist
        if (selectedCostQuantityIsOther) {
            // Include actions regardless of variance
            // sign
            return ReasonCode.QUANTITY_INVOICE_ACTIONS;
        } else if (varianceSign != null
                && varianceSign.equals(ReIMConstants.POSITIVE)) {
            return getQtyActionListMapForPostiveVariance(selectedCostQuantity);
        } else if (varianceSign != null
                && varianceSign.equals(ReIMConstants.NEGATIVE)) {
            return getQtyActionListMapForNegativeVariance(selectedCostQuantity);
        } else {
            // Include actions regardless of variance
            // sign
            return ReasonCode.QUANTITY_INVOICE_ACTIONS;
        }
    }

    private HashMap<String, String> getQtyActionListMapForNegativeVariance(String selectedCostQuantity) {
        // Include actions appropriate only for when
        // the variance is
        // less than zero
        if(null!=selectedCostQuantity && selectedCostQuantity.equalsIgnoreCase(ReIMConstants.INVOICE_QUANTITY)){
            return ReasonCode.QUANTITY_INVOICE_NEGATIVE_ACTIONS;
        }
        else if(null!=selectedCostQuantity && selectedCostQuantity.equalsIgnoreCase(ReIMConstants.RECEIPT_QUANTITY)){
            return ReasonCode.QUANTITY_RECEIPT_NEGATIVE_ACTIONS;
        }       
        return null;
    }

    private HashMap<String, String> getQtyActionListMapForPostiveVariance(String selectedCostQuantity) {
        // Include actions appropriate only for when
        // the variance is
        // greater than or equal to zero
        if(null!=selectedCostQuantity && selectedCostQuantity.equalsIgnoreCase(ReIMConstants.INVOICE_QUANTITY)){
            return ReasonCode.QUANTITY_INVOICE_POSITIVE_ACTIONS;
        }
        else if(null!=selectedCostQuantity && selectedCostQuantity.equalsIgnoreCase(ReIMConstants.RECEIPT_QUANTITY)){
            return ReasonCode.QUANTITY_RECEIPT_POSITIVE_ACTIONS;
        }       
        return null;
    }

    private HashMap<String, String> getActionListMapForCostDiscrepancy(String documentType, String varianceSign,
            boolean selectedCostQuantityIsOther, String selectedCostQuantity) {
        // Include only actions related to cost discrepancies
        if (documentType.equals(Document.MERCHANDISE_INVOICE)) {
            // Include only actions for merchandise invoices
            if (selectedCostQuantityIsOther) {               
                // Include actions regardless of variance sign
                return getCostInvoiceActions();
            } 
            if (varianceSign != null
                    && varianceSign.equals(ReIMConstants.POSITIVE)) {
                return getCostPositiveVarianceActionListMap(selectedCostQuantity);                
            } 
            if (varianceSign != null
                    && varianceSign.equals(ReIMConstants.NEGATIVE)) {
                return getCostNegativeVarianceActionListMap(selectedCostQuantity);
                
            } else {
                // Include actions regardless of variance sign
               // return ReasonCode.COST_INVOICE_ACTIONS;
                return getCostInvoiceActions();
            }
        } else if (documentType.equals(Document.CREDIT_NOTE)) {
            if (varianceSign != null && varianceSign.equals(ReIMConstants.POSITIVE)) {
                return ReasonCode.COST_CRDNT_POSITIVE_ACTIONS;
            } else if (varianceSign != null
                    && varianceSign.equals(ReIMConstants.NEGATIVE)) {
                return ReasonCode.COST_CRDNT_NEGATIVE_ACTIONS;
            }
        } else {
            // Include only actions for non invoice documents
            return ReasonCode.COST_NON_INVOICE_ACTIONS;
        }
        return null;
    }

    private HashMap<String, String> getCostInvoiceActions() {
        return ReasonCode.COST_INVOICE_ACTIONS;
    }

    private HashMap<String, String> getCostNegativeVarianceActionListMap(String selectedCostQuantity) {
        // Include actions appropriate only for when the
        // variance is less
        // than zero
        if(null!=selectedCostQuantity && selectedCostQuantity.length()>0 && selectedCostQuantity.equalsIgnoreCase(PriceReviewListForm.ORDER_COST)){
           // Invoice Cost > Order Cost when order is chosen
            return ReasonCode.COST_ORDER_NEGATIVE_ACTIONS;
           
        }else if(null!=selectedCostQuantity && selectedCostQuantity.length()>0 && selectedCostQuantity.equalsIgnoreCase(PriceReviewListForm.INVOICE_COST)){
           //Invoice Cost > Order Cost when invoice is chosen
           return ReasonCode.COST_INVOICE_NEGATIVE_ACTIONS;
           
        }
        return null;
    }

    private HashMap<String, String> getCostPositiveVarianceActionListMap(String selectedCostQuantity) { 
        // Include actions appropriate only for when the
        // variance is greater
        // than or equal to zero
        if(null!=selectedCostQuantity && selectedCostQuantity.length()>0 && selectedCostQuantity.equalsIgnoreCase(PriceReviewListForm.ORDER_COST)){
           return ReasonCode.COST_ORDER_POSITIVE_ACTIONS;
        }else if(null!=selectedCostQuantity && selectedCostQuantity.length()>0 && selectedCostQuantity.equalsIgnoreCase(PriceReviewListForm.INVOICE_COST)){
            return ReasonCode.COST_INVOICE_POSITIVE_ACTIONS;
        }
        return null;
    }

    /**
     * The method does not return reason codes that are in deleted status.
     * 
     * @param actionCode
     * @param id
     * @return ImReasonCodesRow[]
     * @throws ReIMException
     */
    public ImReasonCodesRow[] getReasonCodesByAction(String actionCode, String id)
            throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<ImReasonCodesRow> arrayList = new ArrayList<ImReasonCodesRow>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT RC.REASON_CODE_ID, RC.REASON_CODE_DESC, RC.REASON_CODE_TYPE, RC.COMMENT_REQUIRED_IND, RC.HINT_COMMENT, RC.DELETE_IND ");
            sqlText.append("  FROM IM_REASON_CODES RC");
            sqlText.append(" WHERE RC.ACTION = ? ");
            sqlText.append(" AND RC.DELETE_IND = 'N' ");
            if (id != null) {
                sqlText.append(" AND REASON_CODE_ID = Upper(?)");
            }
            sqlText.append(" ORDER BY RC.REASON_CODE_DESC ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());

            stmt.setString(1, actionCode);
            if (id != null) {
                stmt.setString(2, id);
            }

            rs = stmt.executeQuery();

            // check for valid ResultSet
            ImReasonCodesRow aRow = null;
            String reasonCode = null;
            String reasonDesc = null;
            String reasonType = null;
            String commentRequiredInd = null;
            String hintComment = null;
            String deleteInd = null;

            while (rs.next()) {
                reasonCode = rs.getString("REASON_CODE_ID");
                reasonDesc = rs.getString("REASON_CODE_DESC");
                reasonType = rs.getString("REASON_CODE_TYPE");
                commentRequiredInd = rs.getString("COMMENT_REQUIRED_IND");
                hintComment = rs.getString("HINT_COMMENT");
                deleteInd = rs.getString("DELETE_IND");
                aRow = new ImReasonCodesRow(reasonType, reasonCode, reasonDesc, actionCode,
                        commentRequiredInd, hintComment, deleteInd);
                arrayList.add(aRow);
            }

            if (arrayList.size() > 0) {
                return (ImReasonCodesRow[]) arrayList
                        .toArray(new ImReasonCodesRow[arrayList.size()]);
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.reason_codes_service.get_reason_codes_by_action",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);

            }
        }
    }

    /**
     * The method does not return reason codes that are in deleted status.
     * 
     * @param actionCode
     * @param id
     * @return ImReasonCodesRow[]
     * @throws ReIMException
     */
    public ImReasonCodesRow[] getReasonCodesByAction(long businessRoleId, String actionCode,
            String id) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<ImReasonCodesRow> arrayList = new ArrayList<ImReasonCodesRow>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT RC.REASON_CODE_ID, RC.REASON_CODE_DESC, RC.REASON_CODE_TYPE, RC.COMMENT_REQUIRED_IND, RC.HINT_COMMENT, RC.DELETE_IND ");
            sqlText.append(" FROM IM_REASON_CODES RC, IM_BUSINESS_ROLES_REASON_CODES BR");
            sqlText.append(" WHERE RC.REASON_CODE_ID = BR.REASON_CODE_ID ");
            sqlText.append("   AND BR.BUSINESS_ROLE_ID = ? ");
            sqlText.append("   AND RC.ACTION = ? ");
            sqlText.append("   AND RC.DELETE_IND = 'N' ");
            if (id != null) {
                sqlText.append(" AND RC.REASON_CODE_ID = Upper(?)");
            }
            sqlText.append(" ORDER BY RC.REASON_CODE_DESC ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());

            stmt.setLong(1, businessRoleId);
            stmt.setString(2, actionCode);
            if (id != null) {
                stmt.setString(3, id);
            }

            rs = stmt.executeQuery();

            // check for valid ResultSet
            ImReasonCodesRow aRow = null;
            String reasonCode = null;
            String reasonDesc = null;
            String reasonType = null;
            String commentRequiredInd = null;
            String hintComment = null;
            String deleteInd = null;

            while (rs.next()) {
                reasonCode = rs.getString("REASON_CODE_ID");
                reasonDesc = rs.getString("REASON_CODE_DESC");
                reasonType = rs.getString("REASON_CODE_TYPE");
                commentRequiredInd = rs.getString("COMMENT_REQUIRED_IND");
                hintComment = rs.getString("HINT_COMMENT");
                deleteInd = rs.getString("DELETE_IND");
                aRow = new ImReasonCodesRow(reasonType, reasonCode, reasonDesc, actionCode,
                        commentRequiredInd, hintComment, deleteInd);
                arrayList.add(aRow);
            }

            if (arrayList.size() > 0) {
                return (ImReasonCodesRow[]) arrayList
                        .toArray(new ImReasonCodesRow[arrayList.size()]);
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.reason_codes_service.get_reason_codes_by_action",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);

            }
        }
    }

    /**
     * This method will get all existing reason codes that can have / require gl information to be
     * entered if the parameter has a null value. If the parameter has a value, validation occurs
     * that that reason code is valid and does require gl information.
     * 
     * The method does not return reason codes that are in deleted status.
     * 
     * @param reasonCodeId
     *            distinct ID for a reason code (optional parameter)
     * @return an array of rows from the IM_REASON_CODES table
     * @throws ReIMException
     */

    public ImReasonCodesRow[] getGLReasonCodes(String reasonCodeId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<ImReasonCodesRow> arrayList = new ArrayList<ImReasonCodesRow>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sqlText = new StringBuffer(
                    "SELECT REASON_CODE_ID, REASON_CODE_DESC, ACTION, COMMENT_REQUIRED_IND, HINT_COMMENT, REASON_CODE_TYPE, DELETE_IND");
            sqlText.append(" FROM IM_REASON_CODES");

            // build a where clause to include specificaclly reason codes which
            // use actions that can
            // have
            // GL account distributions
            sqlText.append(" WHERE ACTION IN ( ");
            sqlText.append(sqlCommaList(ReasonCode.ACTIONS_REQUIRING_GL));
            sqlText.append(") ");
            sqlText.append(" AND DELETE_IND = 'N' ");

            if (reasonCodeId != null) {
                sqlText.append(" AND REASON_CODE_ID = '");
                sqlText.append(reasonCodeId);
                sqlText.append("' ");
            }

            sqlText.append(" ORDER BY UPPER(REASON_CODE_DESC) ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sqlText.toString());
            rs = stmt.executeQuery();

            // check for valid ResultSet
            ImReasonCodesRow aRow = null;
            String reasonCode = null;
            String reasonDesc = null;
            String action = null;
            String commentRequiredInd = null;
            String hintComment = null;
            String reasonCodeType = null;
            String deleteInd = null;

            while (rs.next()) {
                reasonCode = rs.getString("REASON_CODE_ID");
                reasonDesc = rs.getString("REASON_CODE_DESC");
                action = rs.getString("ACTION");
                commentRequiredInd = rs.getString("COMMENT_REQUIRED_IND");
                hintComment = rs.getString("HINT_COMMENT");
                reasonCodeType = rs.getString("REASON_CODE_TYPE");
                deleteInd = rs.getString("DELETE_IND");

                aRow = new ImReasonCodesRow(reasonCodeType, reasonCode, reasonDesc, action,
                        commentRequiredInd, hintComment, deleteInd);
                arrayList.add(aRow);
            }

            if (arrayList.size() > 0) {
                return (ImReasonCodesRow[]) arrayList
                        .toArray(new ImReasonCodesRow[arrayList.size()]);
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.reason_codes_service.get_gl_reason_codes",
                    Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_gl_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);

            }
        }
    }

    /**
     * Method: update. This method updates a single row on the database using the primary key.
     * 
     * @param rowToUpdate
     *            Note that the primary key and at least one other attribute must be populated.
     * 
     */
    public void updateRTV(ImReasonCodesRow rowToUpdate) throws ReIMException {
        OraclePreparedStatement stmnt = null;
        String tableQuery = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (rowToUpdate.isFullyPopulated()) {

                tableQuery = "UPDATE IM_REASON_CODES SET IM_REASON_CODES.REASON_CODE_ID = ?, IM_REASON_CODES.REASON_CODE_DESC = ?, IM_REASON_CODES.ACTION = ?, IM_REASON_CODES.COMMENT_REQUIRED_IND = ?, IM_REASON_CODES.HINT_COMMENT = ? WHERE IM_REASON_CODES.REASON_CODE_TYPE = ? and  IM_REASON_CODES.DELETE_IND = ?";
                stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                stmnt.setString(1, rowToUpdate.getReasonCodeId());
                stmnt.setString(2, rowToUpdate.getReasonCodeDesc());
                stmnt.setString(3, rowToUpdate.getAction());
                stmnt.setString(4, rowToUpdate.getCommentRequiredInd());
                stmnt.setString(5, rowToUpdate.getHintComment());
                stmnt.setString(6, rowToUpdate.getReasonCodeType());
                stmnt.setString(7, rowToUpdate.getDeleteInd());

            } else {
                StringBuffer sqlText = new StringBuffer("UPDATE IM_REASON_CODES SET ");
                String comma = "";
                if (rowToUpdate.reasonCodeTypeIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_REASON_CODES.REASON_CODE_TYPE=?");
                    comma = ",";
                }
                if (rowToUpdate.reasonCodeDescIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_REASON_CODES.REASON_CODE_DESC=?");
                    comma = ",";
                }
                if (rowToUpdate.actionIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_REASON_CODES.ACTION=?");
                    comma = ",";
                }
                if (rowToUpdate.commentRequiredIndIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_REASON_CODES.COMMENT_REQUIRED_IND=?");
                    comma = ",";
                }
                if (rowToUpdate.hintCommentIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_REASON_CODES.HINT_COMMENT=?");
                    comma = ",";
                }
                if (rowToUpdate.deleteIndIsPopulated()) {
                    sqlText.append(comma);
                    sqlText.append("IM_REASON_CODES.DELETE_IND=?");
                    comma = ",";
                }
                sqlText.append(" WHERE IM_REASON_CODES.REASON_CODE_ID = ?");
                tableQuery = sqlText.toString();
                stmnt = (OraclePreparedStatement) conn.prepareStatement(tableQuery);
                int idx = 1;
                if (rowToUpdate.reasonCodeTypeIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getReasonCodeId());
                }
                if (rowToUpdate.reasonCodeDescIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getReasonCodeDesc());
                }
                if (rowToUpdate.actionIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getAction());
                }
                if (rowToUpdate.commentRequiredIndIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getCommentRequiredInd());
                }
                if (rowToUpdate.hintCommentIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getHintComment());
                }
                if (rowToUpdate.deleteIndIsPopulated()) {
                    stmnt.setString(idx++, rowToUpdate.getDeleteInd());
                }
                stmnt.setString(idx++, rowToUpdate.getReasonCodeType());
            }

            stmnt.executeUpdate();
        } catch (SQLException ex) {
            throw new ReIMException("DALGen.cannot_perform_update", Severity.ERROR, ex, this);
        } finally {
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex, this);
            }
        }
    }

    /**
     * The method returns reason codes assoctiated with tax discrepencies. It does not return reason
     * codes that are in deleted status.
     * 
     * @param reasonCodeActionTypes
     * @return ImReasonCodesRow[]
     * @throws ReIMException
     */
    public ImReasonCodesRow[] getTaxReasonCodesForReasonCodeActionTypes(long businessRoleId, String[] reasonCodeActionTypes)
            throws ReIMException {
        ImReasonCodesRow[] imReasonCodesRows = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
        	StringBuffer sqlText = new StringBuffer();
        	sqlText.append("SELECT RC.REASON_CODE_ID      , ");
        	sqlText.append("       RC.REASON_CODE_DESC    , ");
        	sqlText.append("       RC.ACTION              , ");
        	sqlText.append("       RC.COMMENT_REQUIRED_IND, ");
        	sqlText.append("       RC.HINT_COMMENT        , ");
        	sqlText.append("       RC.REASON_CODE_TYPE    , ");
        	sqlText.append("       RC.DELETE_IND ");
        	sqlText.append("FROM   IM_REASON_CODES RC, ");
        	sqlText.append("       IM_BUSINESS_ROLES_REASON_CODES BR ");
        	sqlText.append("WHERE  RC.REASON_CODE_ID   = BR.REASON_CODE_ID ");
        	sqlText.append("AND    BR.BUSINESS_ROLE_ID = " + businessRoleId + " ");
        	sqlText.append("AND    RC.DELETE_IND       ='N'");

            sqlText.append("AND ACTION IN (");
            for (int i = 0; i < reasonCodeActionTypes.length; i++) {
                sqlText.append("'");
                sqlText.append(reasonCodeActionTypes[i]);
                sqlText.append("'");

                if (i < reasonCodeActionTypes.length - 1) {
                    sqlText.append(", ");
                }
            }

            sqlText.append(") ");
            sqlText.append("ORDER BY REASON_CODE_DESC");

            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            statement = conn.createStatement();
            resultSet = statement.executeQuery(sqlText.toString());

            imReasonCodesRows = buildImReasonCodesRowArray(resultSet);

        } catch (SQLException sqlEx) {
            throw new ReIMException("error.reason_codes_service.get_reason_codes",
                    Severity.ERROR, sqlEx, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);
            }
        }

        return imReasonCodesRows;
    }

    /**
     * The method returns reason codes assoctiated with tax discrepencies. It does not return reason
     * codes that are in deleted status.
     * 
     * @param reasonCodeActionTypes
     * @return ImReasonCodesRow[]
     * @throws ReIMException
     */
    public ImReasonCodesRow[] getTaxReasonCodesByCodeType(String reasonCodeType)
            throws ReIMException {
        ImReasonCodesRow[] imReasonCodesRows = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            StringBuffer sqlText = new StringBuffer(500);
            sqlText.append("SELECT REASON_CODE_ID, ");
            sqlText.append("REASON_CODE_DESC, ");
            sqlText.append("ACTION, ");
            sqlText.append("COMMENT_REQUIRED_IND, ");
            sqlText.append("HINT_COMMENT, ");
            sqlText.append("REASON_CODE_TYPE, ");
            sqlText.append("DELETE_IND ");
            sqlText.append("FROM IM_REASON_CODES ");
            sqlText.append("WHERE DELETE_IND='N' ");
            sqlText.append("AND REASON_CODE_TYPE = '");
            sqlText.append(reasonCodeType);
            sqlText.append("' ORDER BY REASON_CODE_DESC");

            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            statement = conn.createStatement();
            resultSet = statement.executeQuery(sqlText.toString());

            imReasonCodesRows = buildImReasonCodesRowArray(resultSet);

        } catch (SQLException sqlEx) {
            throw new ReIMException("error.reason_codes_service.get_reason_codes",
                    Severity.ERROR, sqlEx, this);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException(
                        "error.reason_codes_service.get_reason_codes.close_rs_stmt",
                        Severity.ERROR, exception, this);
            }
        }

        return imReasonCodesRows;
    }

    private ImReasonCodesRow[] buildImReasonCodesRowArray(ResultSet resultSet) throws SQLException {
        ArrayList<ImReasonCodesRow> rows = new ArrayList<ImReasonCodesRow>();
        while (resultSet.next()) {
            String reasonCode = resultSet.getString("REASON_CODE_ID");
            String reasonDesc = resultSet.getString("REASON_CODE_DESC");
            String action = resultSet.getString("ACTION");
            String commentRequiredInd = resultSet.getString("COMMENT_REQUIRED_IND");
            String hintComment = resultSet.getString("HINT_COMMENT");
            String reasonCodeType = resultSet.getString("REASON_CODE_TYPE");
            String deleteInd = resultSet.getString("DELETE_IND");

            ImReasonCodesRow aRow = new ImReasonCodesRow(reasonCodeType, reasonCode, reasonDesc,
                    action, commentRequiredInd, hintComment, deleteInd);
            rows.add(aRow);
        }

        if (rows.size() > 0) {
            return (ImReasonCodesRow[]) rows.toArray(new ImReasonCodesRow[rows.size()]);
        } else {
            return null;
        }
    }

    private String sqlCommaList(Map<String,String> map) {
        StringBuffer commaList = new StringBuffer();
        Set<String> keys = map.keySet();
        Iterator<String> iter = keys.iterator();
        while (iter.hasNext()) {
            commaList.append("'");
            commaList.append(iter.next());
            commaList.append("'");
            if (iter.hasNext()) {
                commaList.append(", ");
            }
        }
        return commaList.toString();
    }

    public ByteLengths getReasonCodeMaxByteLengths() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            ByteLengths reasonCodeByteLengths = new ByteLengths();
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            
            // OLR V1.2 Inserted - Start
            //   stmt = (OraclePreparedStatement) conn
            //           .prepareStatement("SELECT MAX(REASON_CODE_ID), MAX(REASON_CODE_DESC) FROM IM_REASON_CODES");
               stmt = (OraclePreparedStatement) conn
                       .prepareStatement("SELECT REASON_CODE_ID, REASON_CODE_DESC FROM IM_REASON_CODES where rownum = 1 and REASON_CODE_ID is not null and REASON_CODE_DESC is not null ");
            // OLR V1.2 Inserted - End
            
            rs = stmt.executeQuery();
            if (rs.next()) {
                reasonCodeByteLengths.setReasonCodeIdSize(rs.getMetaData().getColumnDisplaySize(1));
                reasonCodeByteLengths.setReasonCodeDescSize(rs.getMetaData()
                        .getColumnDisplaySize(2));
            }
            return reasonCodeByteLengths;

        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }

    public String[] getReasonCodeTBDIds() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<String> arrayList = new ArrayList<String>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT REASON_CODE_ID FROM IM_REASON_CODES WHERE "
                            + ImReasonCodesAccess.deleteIndColumn + ReIMConstants.EQUALS + "'"
                            + ReIMConstants.YES + "'");
            rs = stmt.executeQuery();
            while (rs.next()) {
                arrayList.add(rs.getString("REASON_CODE_ID"));
            }
            if (arrayList.size() > 0) {
                return (String[]) arrayList.toArray(new String[arrayList.size()]);
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }
    
    public List<String> getReasonCodeIds() throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<String> arrayList = new ArrayList<String>();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement("SELECT REASON_CODE_ID FROM IM_REASON_CODES WHERE "
                            + ImReasonCodesAccess.deleteIndColumn + ReIMConstants.EQUALS + "'"
                            + ReIMConstants.NO + "' ORDER BY REASON_CODE_ID");
            rs = stmt.executeQuery();
            while (rs.next()) {
                arrayList.add(rs.getString("REASON_CODE_ID"));
            }
            if (arrayList.size() > 0) {
                return arrayList;
            } else {
                return null;
            }
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
            }
        }
    }
    
    
      
}
