package com.retek.reim.ui.invoiceMatch;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.services.matching.IDetailMatchService;
import oracle.retail.reim.services.matching.ISummaryMatchService;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.ArrayUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.beans.factory.annotation.Autowired;

import com.retek.reim.business.UserRole;
import com.retek.reim.business.document.Document;
import com.retek.reim.locking.LockingData;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;

import smr.retek.reim.db.SmrImDocHeadAccessExt;

/**
 * BRN IMS135775 
 * This Struts action is called from the Details Matching screen. When this action is called, it
 * will wrap up any outstanding in balance items and remove their entries from the appropriate
 * display fields.
 *  
 *  -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.3	05-Mar-2013	IMS135775:  ReIM: RCA not updating the ORDLOC and SHIPSKU correctly
 * 															Move the call to Auto Resolve to the trigger and remove from the Java code when RCA is performed.
 *
 * @author Oracle Retail Invoice Matching
 *
 */
public class DetailMatchCloseAction extends ReIMSecureAction {

    private IDetailMatchService detailMatchService;
    private ISummaryMatchService summaryMatchService;

    protected boolean getPermission() {

        final String roleName = ReIMUserContext.getUserRole().getInvoiceMatching();

        return (roleName.equalsIgnoreCase(UserRole.EDIT) || roleName
                .equalsIgnoreCase(UserRole.VIEW));

    }

    public ActionForward doPerform(final ActionMapping mapping, final ActionForm form,
            final HttpServletRequest request, final HttpServletResponse response) {

        final ActionErrors errors = new ActionErrors();
        SummaryMatchListForm summaryMatchListForm = null;
        try {
            final DetailMatchListForm detailMatchListForm = (DetailMatchListForm) form;

            summaryMatchListForm = (SummaryMatchListForm) request.getSession().getAttribute(
                    "SummaryMatchListForm");

            // The next four declarations represent the data in the four
            // Detail Matching screen windows / tabs.
            final DetailMatchItemsView[] discrepancyItems = detailMatchListForm
                    .getDiscrepancyItemsList();

            final DetailMatchItemsView[] inBalanceItems = detailMatchListForm
                    .getInBalanceItemsList();

            final DetailMatchInvoiceView[] invoiceItemGroup = detailMatchListForm
                    .getInvoiceItemGroupList();

            final DetailMatchReceiptView[] receiptItemGroup = detailMatchListForm
                    .getReceiptItemGroupList();

            final boolean editMode = detailMatchListForm.getMode().equals(DetailMatchListForm.EDIT);

            request.setAttribute("selectedSupplierId", detailMatchListForm.getSupplierId());

            // BRN Fixed the error: "Unable to save the summary match group" on Summary Match List after visiting Detail Matching screen
            if (editMode && ArrayUtils.isEmpty(discrepancyItems)
                    && ArrayUtils.isEmpty(invoiceItemGroup) && ArrayUtils.isEmpty(receiptItemGroup)) {

                // This means all invoices,receipts in group are matched.
                ServiceFactory.getSummaryMatchService().removeMatchedGroupedFromList(
                        summaryMatchListForm);

                // Set this variable so that summary matching is not
                // required and matched groups are not shown.
                summaryMatchListForm.setFromDetailMatching(true);
            }

            if (editMode && ArrayUtils.isEmpty(invoiceItemGroup)
                    && (!ArrayUtils.isEmpty(inBalanceItems))) {

                boolean discrepantInvoicesRemain = false;
                for (int i = 0; i < discrepancyItems.length; i++) {

                    // If there is a discrepancy, break out of the loop.
                    if (!ArrayUtils.isEmpty(discrepancyItems[i].getInvoiceItems())) {
                        discrepantInvoicesRemain = true;
                        break;
                    }
                }
                if (discrepantInvoicesRemain == false) {
                    // There are not discrepancies left, lets save the in
                    // balance items.
                    getDetailMatchService().persistInBalanceMatches(inBalanceItems,
                            ReIMUserContext.getUsername());
                }
            }
            // Determine where to go depending on if there are more items yet to
            // be resolved.
            if (ArrayUtils.isEmpty(discrepancyItems) && ArrayUtils.isEmpty(invoiceItemGroup)
                    && ArrayUtils.isEmpty(receiptItemGroup)) {
                return mapping.findForward("success");
            } else {
                String forward = "success";
                for (int ii = 0; ii < discrepancyItems.length; ii++) {
                    if (!ArrayUtils.isEmpty(discrepancyItems[ii].getInvoiceItems())) {
                        getSummaryMatchService().updateSummaryMatchListFormGroupingTotals(
                                summaryMatchListForm);
                        forward = "items_remain";
                        break;
                    }
                }
				
				//  BRN IMS135775 OLR V1.3 - begin				                
                // if ( summaryMatchListForm.getSelectedGroupInvoiceList().length != 0 && receiptItemGroup.length != 0 ) {
                //	updateOrdShipCost(summaryMatchListForm.getSelectedGroupInvoiceList()[0].getOrderNo(),
                //          summaryMatchListForm.getSelectedGroupInvoiceList()[0].getLocationNo(),
                //           receiptItemGroup[0].getItemId());
                //   }
				//  BRN IMS135775 OLR V1.3 - end
                return mapping.findForward(forward);
            }

        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return mapping.findForward("failure");
        } catch (Exception e) {
            saveErrors(request, errors, new ReIMException(
                    "error.detail_match_close_action.do_perform", Severity.ERROR, e, this));
            return mapping.findForward("failure");
        } finally {
            try {
                verifyAndReleaseLocksOnInvoices(summaryMatchListForm);
            } catch (ReIMException e) {
                saveErrors(request, errors, e);
                return mapping.findForward("failure");
            }
        }
    }
    private void updateOrdShipCost(String order_no, String location, String item_no) throws ReIMException{
        SmrImDocHeadAccessExt smr = new SmrImDocHeadAccessExt();
        smr.updateCostQty(order_no, location, item_no);
    }

    /**
     * This method verifies the invoices locked by the user on summaryMatchListForm are matched or
     * not. Matched invoices will be unlocked for the user.
     *
     * @param summaryMatchListForm
     * @throws ReIMException
     */
    private void verifyAndReleaseLocksOnInvoices(SummaryMatchListForm summaryMatchListForm)
            throws ReIMException {
        String userName = ReIMUserContext.getUsername();
        String[] invoiceIdArray = (String[]) summaryMatchListForm.getInvoicesLockedByUser()
                .toArray(new String[summaryMatchListForm.getInvoicesLockedByUser().size()]);

        ArrayList matchedInvoices = new ArrayList();
        for (int i = 0; invoiceIdArray != null && i < invoiceIdArray.length; i++) {
            Document invoice = ServiceFactory.getDocumentService().getDocHeadByDocId(
                    Long.parseLong(invoiceIdArray[i]));
            if (invoice.getStatus().equalsIgnoreCase(Document.MATCHED)) {
                matchedInvoices.add(invoiceIdArray[i]);
            }
        }

        long[] matchedInvoiceids = new long[matchedInvoices.size()];
        for (int i = 0; i < matchedInvoices.size(); i++) {
            matchedInvoiceids[i] = Long.parseLong((String) matchedInvoices.get(i));
        }
        if (matchedInvoiceids.length > 0) {
            ServiceFactory.getTableRecordLockingService().releaseLockOnRecordGroupForUser(
                    LockingData.DOC_HEAD_LOCK_TABLE, userName, matchedInvoiceids);
        }
    }

    public IDetailMatchService getDetailMatchService() {
        return detailMatchService;
    }

    public void setDetailMatchService(IDetailMatchService detailMatchService) {
        this.detailMatchService = detailMatchService;
    }

    public ISummaryMatchService getSummaryMatchService() {
        return summaryMatchService;
    }

    @Autowired
    public void setSummaryMatchService(ISummaryMatchService summaryMatchService) {
        this.summaryMatchService = summaryMatchService;
    }
}
