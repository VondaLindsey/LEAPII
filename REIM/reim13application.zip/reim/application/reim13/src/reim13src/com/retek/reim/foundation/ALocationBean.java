package com.retek.reim.foundation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.business.Location;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.translation.DataTranslationService;
import com.retek.reim.ui.lov.LocationLOV;

abstract public class ALocationBean {
    protected final String LOC_CODE_TYPE = "LOC";

    protected final String STORE_CODE = "S";

    protected final String WH_CODE = "W";

    // Attributes from the table
    protected String storeId;

    protected String storeName;

    protected String whId;

    protected String whName;

    protected String orderBy;

    // the dirty-bit flags for attributes
    protected boolean isStoreIdChanged;

    protected boolean isStoreNameChanged;

    protected boolean isWhIdChanged;

    protected boolean isWhNameChanged;

    public void setStoreId(String newStoreId) {
        if (newStoreId.length() > 0) {
            storeId = newStoreId;
            isStoreIdChanged = true;
        }
    }

    public void setStoreName(String newStoreName) {
        if (newStoreName.length() > 0) {
            storeName = newStoreName;
            isStoreNameChanged = true;
        }
    }

    public void setWhId(String newWhId) {
        if (newWhId.length() > 0) {
            whId = newWhId;
            isWhIdChanged = true;
        }
    }

    public void setWhName(String newWhName) {
        if (newWhName.length() > 0) {
            whName = newWhName;
            isWhNameChanged = true;
        }
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = " order by " + orderBy;
    }

    protected String SELECT_ALL_LOCATIONS_SQL = " SELECT 'S' LOC_TYPE, STORE LOC_ID, STORE_NAME LOC_NAME FROM STORE WHERE STOCKHOLDING_IND='Y'"
            + " UNION ALL "
            + " SELECT 'W' LOC_TYPE, WH LOC_ID, WH_NAME LOC_NAME FROM WH WHERE WH = PHYSICAL_WH";

    protected String SELECT_LOCATION_FOR_LOCATION_SQL = " SELECT 'S' LOC_TYPE, STORE LOC_ID, STORE_NAME LOC_NAME FROM STORE  WHERE STOCKHOLDING_IND='Y' AND STORE = ? "
            + " UNION ALL "
            + " SELECT 'W' LOC_TYPE, WH LOC_ID, WH_NAME LOC_NAME FROM WH WHERE WH = PHYSICAL_WH AND WH = ? ";

	private boolean isFromDyanmicMappingLocationForm = false;

    // This LOV query returns all stores and physical warehouses in the system.
    public LocationLOV[] select() throws ReIMException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = conn.createStatement();

            // retrieve the store, warehouse location type from codes table
            ACodeDetailTransBean codeDetailBean = (ACodeDetailTransBean) ReIMBeanFactory
                    .getBean(ReIMBeanFactory.ACodeDetailTransBean);
            String stCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.STORE_CODE);
            String whCodeDesc = codeDetailBean.getCodeDetailDescription(this.LOC_CODE_TYPE,
                    this.WH_CODE);

            String stQuery = "SELECT B.STORE ID, B.STORE_NAME Name, '" + stCodeDesc
                    + "' Type FROM STORE B ";
            String storeWhere = constructStoreWhere();

            String whQuery = "SELECT WH ID, WH_NAME Name, '" + whCodeDesc
                    + "' Type FROM WH B WHERE B.WH = B.PHYSICAL_WH ";
            String whWhere = constructWhWhere();

            String importerQuery;
            String importerWhere;
            if (isFromDyanmicMappingLocationForm) {
            	importerQuery = "SELECT WH ID, WH_NAME Name, '" + whCodeDesc
                + "' Type FROM WH B WHERE B.ORG_ENTITY_TYPE = 'M' " +
                		" AND B.WH <> B.PHYSICAL_WH ";
            	importerWhere = constructWhWhere();
            } else {
            	importerQuery = "";
            	importerWhere = "";
            }

            if (orderBy == null) {
                orderBy = "";
            }

            if (!isFromDyanmicMappingLocationForm)
          	  rs = stmt.executeQuery(stQuery + storeWhere + " Union " + whQuery + whWhere+ orderBy);  
              else
            
              rs = stmt.executeQuery(stQuery + storeWhere + " Union " + whQuery + whWhere + " Union " + importerQuery + importerWhere + orderBy);

            ArrayList dataList = new ArrayList(1);

            while (rs.next()) {
                dataList.add(new LocationLOV(Long.toString(rs.getLong(1)), rs.getString(2), rs
                        .getString(3)));
            }

            int l = dataList.size();
            LocationLOV data[] = new LocationLOV[l];
            dataList.toArray(data);

            String userLang = ReIMUserContext.getUserLanguage();
            if (com.retek.reim.translation.DataTranslationService.isTranslationRequired(userLang)) {
                for (int i = 0; i < data.length; ++i) {
                    data[i].setDescription(com.retek.reim.translation.DataTranslationService
                            .getLocationDesc(data[i].getDescription(), userLang));
                }
            }

            return data;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.sql_error", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("Error.sql_error",
                        Severity.ERROR, e, this);
            }
        }
    }

    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes. Again, the
    // attribute isNotEmpty is set to true if there is already an attribute in
    // the string
    private String constructStoreWhere() {
        StringBuffer where = new StringBuffer(40);
        // main query does not contain a where clause initially

        where.append(" WHERE STOCKHOLDING_IND='Y' ");

        if (isStoreIdChanged) {
            where.append(" AND ");
            where.append("B.STORE=");
            where.append(storeId);
        }

        if (isStoreNameChanged) {
            where.append(" AND ");
            where.append("B.STORE_NAME=");
            where.append("'");
            where.append(storeName);
            where.append("'");
        }

        // The complete WHERE clause is returned here
        return where.toString();
    } // end of storeWhereConstruct

    // The WHERE clause is constructed according to the values of the
    // attributes that was set using the XXXXSelected attributes. Again, the
    // attribute isNotEmpty is set to true if there is already an attribute in
    // the string
    private String constructWhWhere() {
        StringBuffer where = new StringBuffer(40);
        // main where clause contains a where clause already

        if (isWhIdChanged) {
            where.append(" AND ");
            where.append("B.WH=");
            where.append(whId);
        }

        if (isWhNameChanged) {
            where.append(" AND ");
            where.append("B.WH_NAME=");
            where.append("'");
            where.append(whName);
            where.append("'");
        }

        // The complete WHERE clause is returned here
        return where.toString();

    } // end of whWhereConstruct

    public String selectStoreDesc(long loc) throws ReIMException {
        Location location = readStore(String.valueOf(loc));

        if (location != null)
            return location.getLocationName();
        else
            return null;
    }

    public String selectWhDesc(long loc) throws ReIMException {
        Location location = readWarehouse(String.valueOf(loc));

        if (location != null)
            return location.getLocationName();
        else
            return null;
    }

    public Location readLocation(String locationId) throws ReIMException {
        Location location = readStore(locationId);

        if (location == null) {
            location = readWarehouse(locationId);
        }

        return location;
    }

    public HashMap readLocations(Set locationIds) throws ReIMException {
        HashMap locations = readStores(locationIds);

        if (locationIds.size() != locations.entrySet().size()) {
            HashMap warehouses = new HashMap();

            for (Iterator i = locationIds.iterator(); i.hasNext();) {
                String id = (String) i.next();

                if (!locations.containsKey(id)) {
                    warehouses.put(id, id);
                }
            }

            HashMap warehouseLocations = readWarehouses(warehouses.keySet());
            locations.putAll(warehouseLocations);
        }

        return locations;
    }

    public HashMap readLocations(Set locationIds, String docIdsWhereClause) throws ReIMException {
        HashMap locations = readStores(docIdsWhereClause);

        if (locationIds.size() != locations.entrySet().size()) {
            HashMap warehouseLocations = readWarehouses(docIdsWhereClause);
            locations.putAll(warehouseLocations);
        }

        return locations;
    }

    public Location readWarehouse(String locationId) throws ReIMException {
        Location location = null;
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        String whQuery = new StringBuffer(
                "SELECT WH.WH, WH.WH_NAME FROM WH WH WHERE WH.WH = (SELECT PHYSICAL_WH FROM WH WHERE WH.WH = ?)")
                .toString();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(whQuery);
            stmt.setString(1, locationId);

            rs = stmt.executeQuery();

            while (rs.next()) {
                location = new Location();
                location.setLocationId(String.valueOf(rs.getLong("WH")));
                String locName = rs.getString("WH_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(Location.WAREHOUSE);
            }

            return location;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public boolean isValidWarehouse(String locationId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        String whQuery = new StringBuffer(
                "SELECT WH.WH, WH.WH_NAME FROM WH WH WHERE WH.WH = (SELECT PHYSICAL_WH FROM WH WHERE WH.WH = ?)")
                .toString();

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(whQuery);
            stmt.setString(1, locationId);

            rs = stmt.executeQuery();

            while (rs.next()) {
                return true;
            }

            return false;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public boolean isValidStore(String locationId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

           /* StringBuffer sql = new StringBuffer("SELECT STORE, STORE_NAME FROM STORE ")
                    .append(" WHERE STORE = ? AND STOCKHOLDING_IND='Y' "); */
          
          // Code Change Syed Qadri per IMS Ticket # 134563. This is to include Stores from table WH_ATTRIBUTES.
           // Note this query doesn�t return 940, 9401 or 9402 warehouse
           // Invoices for this warehouse should never be received or processed into ReIM
           // ups_district  = 1 is stand-alone
           // ups_district = 2  is SDC  - this would be future if SMR moves to SDC summary invoices
           // wh_attributes will have less than 10 records � it will only increase if SMR opens another warehouse
            StringBuffer sql = new StringBuffer("SELECT STORE, STORE_NAME FROM STORE ")
                                            .append(" WHERE STORE = ? AND STOCKHOLDING_IND='Y' ")
                                            .append(" UNION ")
                                            .append("SELECT DISTINCT TO_NUMBER(SUBSTR(WH,1,3)) STORE, NULL FROM WH_ATTRIBUTES ")
                                            .append(" WHERE WH = ? AND ups_district in (1,2)");
                                                                

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setString(1, locationId);
            stmt.setString(2, locationId);
            rs = stmt.executeQuery();

            if (rs.next()) { return true; }
            return false;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public Location readStore(String locationId) throws ReIMException {
        Location location = null;
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            StringBuffer sql = new StringBuffer("SELECT STORE, STORE_NAME FROM STORE ")
                    .append(" WHERE STORE = ? AND STOCKHOLDING_IND='Y' ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(sql.toString());
            stmt.setString(1, locationId);

            rs = stmt.executeQuery();

            while (rs.next()) {
                location = new Location();
                location.setLocationId(String.valueOf(rs.getLong(1)));
                String locName = rs.getString("STORE_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(Location.STORE);
            }

            return location;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public HashMap readStores(Set locationIds) throws ReIMException {
        Location location = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            // Format all the location IDs
            HashMap locations = new HashMap();

            StringBuffer storeQuery = new StringBuffer(
                    "SELECT STORE, STORE_NAME FROM STORE WHERE STORE IN (");

            int size = locationIds.size();

            for (Iterator i = locationIds.iterator(); i.hasNext();) {
                storeQuery.append((String) i.next());

                if (--size > 0) {
                    storeQuery.append(",");
                }
            }
            storeQuery.append(")");

            stmt = conn.createStatement();
            rs = stmt.executeQuery(storeQuery.toString());

            while (rs.next()) {
                location = new Location();
                location.setLocationId(String.valueOf(rs.getLong("STORE")));
                String locName = rs.getString("STORE_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(Location.STORE);
                locations.put(location.getLocationId(), location);
            }

            return locations;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public HashMap readStores(String docIdsWhereClause) throws ReIMException {
        Location location = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            HashMap locations = new HashMap();

            StringBuffer storeQuery = new StringBuffer(
                    "SELECT STORE, STORE_NAME FROM STORE WHERE STOCKHOLDING_IND='Y' AND STORE IN (");

            storeQuery
                    .append("SELECT /*+ index(dh,im_doc_head_i1) */ dh.location FROM im_doc_head dh");
            storeQuery.append(docIdsWhereClause);
            storeQuery.append(")");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(storeQuery.toString());

            while (rs.next()) {
                location = new Location();
                location.setLocationId(String.valueOf(rs.getLong("STORE")));
                String locName = rs.getString("STORE_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(Location.STORE);
                locations.put(location.getLocationId(), location);
            }

            return locations;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public HashMap readWarehouses(Set locationIds) throws ReIMException {
        Location location = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            HashMap locations = new HashMap();

            StringBuffer whQuery = new StringBuffer(
                    "SELECT WH.WH, WH.WH_NAME FROM WH WH WHERE WH.WH = PHYSICAL_WH AND WH.WH IN (");

            int size = locationIds.size();

            for (Iterator i = locationIds.iterator(); i.hasNext();) {
                whQuery.append((String) i.next());

                if (--size > 0) {
                    whQuery.append(",");
                }
            }

            whQuery.append(")");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(whQuery.toString());

            while (rs.next()) {
                location = new Location();
                location.setLocationId(String.valueOf(rs.getLong("WH")));
                String locName = rs.getString("WH_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(Location.WAREHOUSE);
                locations.put(location.getLocationId(), location);
            }

            return locations;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public HashMap readWarehouses(String docIdsWhereClause) throws ReIMException {
        Location location = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            HashMap locations = new HashMap();

            StringBuffer whQuery = new StringBuffer("SELECT WH, WH_NAME FROM WH, (");

            whQuery.append("SELECT distinct dh.location FROM im_doc_head dh ");

            whQuery.append(docIdsWhereClause);

            whQuery.append(") dhi ");

            whQuery.append(" WHERE WH = PHYSICAL_WH AND wh.wh = dhi.LOCATION ");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(whQuery.toString());

            while (rs.next()) {
                location = new Location();
                location.setLocationId(String.valueOf(rs.getLong("WH")));
                String locName = rs.getString("WH_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(Location.WAREHOUSE);
                locations.put(location.getLocationId(), location);
            }

            return locations;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public Location[] readLocationsArray(String locationId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;

        ArrayList LocationList = new ArrayList();
        Location location = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (locationId != null) {
                stmt = (OraclePreparedStatement) conn
                        .prepareStatement(SELECT_LOCATION_FOR_LOCATION_SQL);
                stmt.setString(1, locationId);
                stmt.setString(2, locationId);
            } else {
                stmt = (OraclePreparedStatement) conn.prepareStatement(SELECT_ALL_LOCATIONS_SQL);
            }

            rs = stmt.executeQuery();
            while (rs.next()) {
                location = new Location();
                location.setLocationId(rs.getString("LOC_ID"));
                String locName = rs.getString("LOC_NAME");

                // data translation if required
                String userLang = ReIMUserContext.getUserLanguage();
                if (locName != null && DataTranslationService.isTranslationRequired(userLang)) {
                    locName = DataTranslationService.getLocationDesc(locName, userLang);
                }

                location.setLocationName(locName);
                location.setLocationType(rs.getString("LOC_TYPE"));

                LocationList.add(location);
            }
            return (Location[]) LocationList.toArray(new Location[LocationList.size()]);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    private static final String SELECT_VAT_REGION_FOR_LOCATION_SQL = " select s.vat_region"
            + "  from store s " + " where store = ?" + " union" + " select w.vat_region"
            + "  from wh w " + " where wh = ?";

    public long getTaxRegion(String locationId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(SELECT_VAT_REGION_FOR_LOCATION_SQL);
            stmt.setString(1, locationId);
            stmt.setString(2, locationId);

            rs = stmt.executeQuery();
            long vatRegion = 0l;

            if (rs.next()) {
                vatRegion = rs.getLong("VAT_REGION");
            }
            return vatRegion;
        } catch (Exception e) {
            throw new ReIMException("error.location_bean", Severity.ERROR, e, this);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception e) {
                throw new com.retek.reim.merch.utils.ReIMException("error.location_bean",
                        Severity.ERROR, e, this);
            }
        }
    }

    public String getLocationType(String locId) throws ReIMException {
        Location loc = readLocation(locId);
        return loc.getLocationType();
    }
    
    public void setFromDynamicMappingLocationForm() {
    	isFromDyanmicMappingLocationForm = true;
    }
}
