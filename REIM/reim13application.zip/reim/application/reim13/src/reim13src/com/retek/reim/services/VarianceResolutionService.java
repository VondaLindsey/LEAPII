package com.retek.reim.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.merch.utils.Money;
import com.retek.merch.utils.Quantity;
import com.retek.merch.utils.RetekException;
import com.retek.reim.RMSInterface.AShipmentAPI;
import com.retek.reim.business.Comment;
import com.retek.reim.business.Item;
import com.retek.reim.business.Location;
import com.retek.reim.business.POItemLocation;
import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ResolutionCreditNote;
import com.retek.reim.business.ResolutionDisputedCreditMemo;
import com.retek.reim.business.ResolutionMerchandiseInvoice;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.business.document.MerchandiseDocument;
import com.retek.reim.business.match.InvoiceLineLevel;
import com.retek.reim.business.match.Match;
import com.retek.reim.business.match.ReceiptDetailSummaryLevel;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.IImDocDetailCommentsAccessExt;
import com.retek.reim.db.IImInvoiceDetailAccessExt;
import com.retek.reim.db.IImResolutionActionAccessExt;
import com.retek.reim.db.IImReversalResolutionActionAccessExt;
import com.retek.reim.db.ImCostDiscrepancyAccess;
import com.retek.reim.db.ImCostDiscrepancyAccessExt;
import com.retek.reim.db.ImCostDiscrepancyRow;
import com.retek.reim.db.ImDocDetailCommentsRow;
import com.retek.reim.db.ImDocHeadAccess;
import com.retek.reim.db.ImDocHeadAccessExt;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.db.ImInvoiceDetailRow;
import com.retek.reim.db.ImPartiallyMatchedReceiptsAccessExt;
import com.retek.reim.db.ImPartiallyMatchedReceiptsRow;
import com.retek.reim.db.ImQtyDiscrepancyAccess;
import com.retek.reim.db.ImQtyDiscrepancyReceiptAccessExt;
import com.retek.reim.db.ImQtyDiscrepancyReceiptRow;
import com.retek.reim.db.ImQtyDiscrepancyRoleAccess;
import com.retek.reim.db.ImQtyDiscrepancyRoleAccessExt;
import com.retek.reim.db.ImQtyDiscrepancyRoleRow;
import com.retek.reim.db.ImQtyDiscrepancyRow;
import com.retek.reim.db.ImRcptItemPostingInvoiceAccess;
import com.retek.reim.db.ImRcptItemPostingInvoiceRow;
import com.retek.reim.db.ImReceiptItemPostingAccessExt;
import com.retek.reim.db.ImReceiptItemPostingRow;
import com.retek.reim.db.ImReceiverCostAdjustRow;
import com.retek.reim.db.ImResolutionActionRow;
import com.retek.reim.db.ImReversalResolutionActionRow;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.foundation.AOrderLocationBean;
import com.retek.reim.foundation.AShipSkuBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.matching.MatchHistoryService;
import com.retek.reim.ui.discrepancyResolution.VarianceResolution;

/**
 * This service provides system actions for each type of discrepancy resolution chosen.
 * 
 * CBC (Debit Memo Cost) Create resolution action row. CBQ (Debit Memo Quantity) Create resolution
 * action row. CMC (Credit Memo Cost) Create resolution action row. CMQ (Credit Memo Quantity)
 * Create resolution action row. DD (Deny Dispute) Update status ACDS (Approve Credit in Disputed
 * Status) Update status DWO (Discrepancy Write-Off) TBD MR (Match to Receipt) TBD RCA (Receiver
 * Cost Adjustment Order and Receipt Only) Create resolution action row. Create receiver cost
 * adjustment row. RCAS (Receiver Cost Adjustment Order/Receipt/Supplier Cost) Create resolution
 * action row. Create receiver cost adjustment row. RCD (Reroute Cost Discrepancy) Update group
 * designation. RQD (Reroute Quantity Discrepancy) Update group designation. RUA (Receiver Unit
 * Adjustment) Create resolution action row. Create receiver unit adjustment row. SR (Split Receipt)
 * Create resolution action row.
 */

/**
 * -- Modification History
 * -- Version Date      Developer   Issue     Description
 * ======= ========= =========== ========= ========================================================
 *    1.2		20-Jun-2013	BNaik		Record to be inserted in Im_partially_matched_receipts table for cost resolution AND if
 *    the quantity is matched at this time.                                           									
 */

/**
 * Use {@link oracle.retail.reim.services.impl.VarianceResolutionService}
 */
@Deprecated
public class VarianceResolutionService implements IVarianceResolutionService {

    public static final String VARIANCE_WITHIN_TOLERANCE = "WITHIN_TOLERANCE";
    public boolean rcaIndicator = false;
    public String rcaItemId = null;

    /**
     * This method changes the reviewer group for cost discrepancy reroute actions.
     * 
     * @param resolution
     *            Current resolution
     * @throws ReIMException
     */
    // TODO: Tamseela. Once this whole service is migrated to the new
    // <oracle.retail..> package this method should be private
    /* private */public static void changeCostDiscrepancyReviewGroup(Resolution resolution)
            throws ReIMException {
        ImCostDiscrepancyAccessExt access = new ImCostDiscrepancyAccessExt();
        ImCostDiscrepancyRow row = access.readDiscrepancyByDocumentItem(resolution.getDocId(),
                resolution.getDiscrepancyItemId());

        row.setBusinessRoleId(resolution.getRerouteBusinessRoleId().longValue());
        access.update(row);
    }

    /**
     * This method changes the reviewer group for quantity discrepancy reroute actions.
     * 
     * @param resolution
     *            Current resolution
     * @throws ReIMException
     */
    // TODO: Tamseela. Once this whole service is migrated to the new
    // <oracle.retail..> package this method should be private
    /* private */public static void changeQuantityDiscrepancyReviewGroup(Resolution resolution)
            throws ReIMException {
        ImQtyDiscrepancyRoleAccess roleAccess = new ImQtyDiscrepancyRoleAccess();
        ImQtyDiscrepancyRoleAccessExt roleAccessExt = new ImQtyDiscrepancyRoleAccessExt();
        long qtyDiscId = resolution.getQtyDiscrepancyId().longValue();
        long newBusinessRoleId = resolution.getRerouteBusinessRoleId().longValue();

        // check to see if the new business role id already has access to this
        // qty discrepancy...
        ImQtyDiscrepancyRoleRow[] roleRow = roleAccessExt.read(qtyDiscId, newBusinessRoleId);

        if (roleRow == null || roleRow.length == 0) { // if new role id has
            // not been added for
            // this qtyDiscrepancy, then add it.
            ImQtyDiscrepancyRoleRow newRow = new ImQtyDiscrepancyRoleRow(qtyDiscId,
                    newBusinessRoleId);
            roleAccess.create(newRow);
        } else { // if the new business role id already had access... don't
            // need to do anything
        }

        // in either case, remove the original role id
        long originalBusinessRoleId = ReIMUserContext.getUserRole().getBusinessRoleId();
        roleAccess.delete(resolution.getQtyDiscrepancyId().longValue(), originalBusinessRoleId);
    }

    private static ArrayList produceCostAdjustmentRows(String order_no, String location,
            String supplier_no, Resolution resolution, Document document, String action,
            String receiptId) throws ReIMException {

        String[] locations = new String[1];
        locations[0] = location;

        AOrderLocationBean orderLocationBean = (AOrderLocationBean) ReIMBeanFactory
                .getBean(ReIMBeanFactory.AOrderLocationBean);

        if (document.getLocation().getLocationType().equals(Document.WAREHOUSE)) {
            locations = orderLocationBean.getPOItemLocationForWH(order_no, location, resolution
                    .getDiscrepancyItemId());
        }

        ArrayList costAdjustRows = new ArrayList();
        for (int i = 0; i < locations.length; i++) {
            ImReceiverCostAdjustRow costRow = new ImReceiverCostAdjustRow(Integer
                    .parseInt(order_no), resolution.getDiscrepancyItemId(), Long
                    .parseLong(locations[i]));

            Quantity newUnitcost = getReceiverAdjustmentNewCost(document, resolution);

            costRow.setAdjustedUnitCost(newUnitcost.doubleValue());
            costRow.setCurrencyCode(document.getCurrencyCode());
            costRow.setNullableFieldsToNull();
            costRow.setReasonCode(resolution.getReasonCode());
            costRow.setUserId(ReIMUserContext.getUsername());
            if (receiptId == null) {
                costRow.setShipment(-1);
            } else {
                costRow.setShipment(new Long(receiptId).longValue());
            }

            if (action.equals(ResolutionMerchandiseInvoice.RCA)) {
                costRow.setType("POR");
            } else {
                costRow.setType("PORS");
            }
            costRow.setSupplier(Long.parseLong(supplier_no));
            costAdjustRows.add(costRow);
        }
        return costAdjustRows;
    }

    /**
     * This method returns the new cost for a receiver adjustment by adding the diff from the
     * resolution.
     * 
     * @return New cost after receiver adjustment is applied
     * @param document
     *            Document associated with resolution
     * @param resolution
     *            Current receiver adjustment resolution
     * @throws ReIMException
     */
    private static Quantity getReceiverAdjustmentNewCost(Document document, Resolution resolution)
            throws ReIMException {
        // determine NEW cost from diff
        Location loc = new Location();
        loc.setLocationId(document.getLocation().getLocationId());
        AOrderLocationBean ordLoc = (AOrderLocationBean) ReIMBeanFactory
                .getBean(ReIMBeanFactory.AOrderLocationBean);
        POItemLocation itemLoc = ordLoc.getPOItemLocation(document.getOrderNo(), loc, resolution
                .getDiscrepancyItemId());

        Quantity orderUnitCost = new Quantity(itemLoc.getUnitCost());
        return orderUnitCost.add(-resolution.getAdjustedCost().doubleValue());
    }

    /**
     * This method creates resolution comment rows to be added to the database.
     * 
     * @param comments
     *            Resolution comments
     * @param resolutionCommentRows
     *            Collection of resolution comment rows to be added to the database
     */
    public ArrayList buildDocumentDetailCommentRows(Comment[] comments) {
        ArrayList resolutionCommentRows = new ArrayList();
        for (int i = 0; i < comments.length; i++) {
            ImDocDetailCommentsRow row = new ImDocDetailCommentsRow();

            row.setCommentType(comments[i].getCommentType());
            row.setCreateId(comments[i].getCreateId());
            row.setCreateDatetime(comments[i].getCreateDateTime().getTimestamp());
            row.setDocId(comments[i].getDocId().longValue());
            row.setText(comments[i].getText());
            row.setItem(comments[i].getItemId());
            row.setReasonCodeId(comments[i].getReasonCode());
            row.setDiscrepancyType(comments[i].getDiscrepancyType());
            if (comments[i].getDebitReasonCode() != null) {
                row.setDebitReasonCode(comments[i].getDebitReasonCode());
            } else {
                row.setDebitReasonCodeToNull();
            }
            resolutionCommentRows.add(row);
        }
        return resolutionCommentRows;
    }

    /**
     * This method adds resolution comment rows to the database.
     * 
     * @param resolutionCommentRows
     *            Collection of resolution comment rows populated by createResolutionCommentRows.
     * @throws ReIMException
     */
    public void saveResolutionCommentRows(List resolutionCommentRows) throws ReIMException {
        IImDocDetailCommentsAccessExt access = DaoFactory.getImDocDetailCommentsAccessExt();
        access.create((ImDocDetailCommentsRow[]) resolutionCommentRows
                .toArray(new ImDocDetailCommentsRow[resolutionCommentRows.size()]));
    }

    /**
     * This method is called once all quantity and cost discrepancies for a line item have been
     * resolved. It updates both im_invoice_detail and im_doc_head for extended cost and unit cost.
     * For the extended cost the adjusted cost is only applied to the original quantity on the
     * receipt (the only portion for which the cost change is in effect, any new quantity in
     * quantity discrepancy is multiplied by this new cost). This method also sets the line item
     * cost status to matched.
     * 
     * @param docDetail
     *            New im_invoice_detail record for updates
     * @param docHead
     *            New im_doc_head record for updates
     * @param existingDocDetail
     *            Existing doc_detail row to obtain original quantity.
     * @param resolutions
     *            All current resolutions for this item
     */
    public void performResolutionAdjustedCostUpdate(ImResolutionActionRow[] resolutions,
            long origDocId, String itemId, ArrayList receiptIds, boolean fromDetailMatch,
            String currencyCode) throws ReIMException {

        IImInvoiceDetailAccessExt detailAccess = DaoFactory.getImInvoiceDetailAccessExt();
        ImInvoiceDetailRow existingDocDetail = detailAccess.read(origDocId, itemId, true);

        //
        Quantity totalLineUnitCostChange = new Quantity(0.0);

        if (resolutions != null) {
            int length = resolutions.length;

            for (int i = 0; i < length; i++) {
                ImResolutionActionRow resolution = resolutions[i];

                // Do not adjust the doc costs for Receiver cost
                // adjustments--i.e leave cost = 0.0
                if (!resolution.getAction().equals(ResolutionMerchandiseInvoice.RCA)
                        && !resolution.getAction().equals(ResolutionMerchandiseInvoice.RCAS)) {
                    Quantity unitCost = new Quantity(resolution.getUnitCost());

                    if (unitCost != null) {
                        // Add all unit cost changes for all resolutions for
                        // this line
                        totalLineUnitCostChange = totalLineUnitCostChange.add(unitCost
                                .doubleValue());
                    }
                }
            }
        }

        // THE ENTERED ADJUSTED COST IS A DIFFERENCE

        ImDocHeadAccessExt docHeadAccess;
        ImDocHeadRow row;

        if (totalLineUnitCostChange.doubleValue() != 0) {
            long docId = resolutions[0].getDocId();

            // Retrieve existing adjusted unit cost for this line
            double existingDetailUnitCost = existingDocDetail.getResolutionAdjustedUnitCost();

            // Add existing adjusted cost to total of resolution adjusted costs
            Quantity newDetailUnitCost = totalLineUnitCostChange.add(existingDetailUnitCost);

            // Save total to doc detail
            existingDocDetail.setResolutionAdjustedUnitCost(newDetailUnitCost.doubleValue());

            // Create extended cost from product of resolution adjusted quantity
            // and adjusted cost
            Quantity totalLineExtendedCostChange = totalLineUnitCostChange
                    .multiply(existingDocDetail.getResolutionAdjustedQty());

            // Add adjusted extended cost to existing extended cost on doc head
            docHeadAccess = new ImDocHeadAccessExt();
            double totalCost = docHeadAccess.readResolutionAdjustedTotalCost(docId).doubleValue();

            Quantity newTotalCost = totalLineExtendedCostChange.add(totalCost);

            // Save extended cost to doc head
            row = new ImDocHeadRow(docId);
            row.setResolutionAdjustedTotalCost(newTotalCost.doubleValue());
            row.setLastDatetime(new ReIMDate().getTimestamp());
            row.setLastUpdateId(ReIMUserContext.getUsername());
            docHeadAccess.update(row);
        }

        // Only set cost_matched to yes if the invoice status is not ready for
        // match and cost
        // pre-matched.
        docHeadAccess = new ImDocHeadAccessExt();
        row = docHeadAccess.read(resolutions[0].getDocId(), false);
        if (row != null && !row.getStatus().equals(Document.READY_FOR_MATCH)
                || !row.getCostPreMatch().equals(ReIMConstants.YES)) {
            existingDocDetail.setCostMatched(ReIMConstants.YES);
        }

        if (ReIMConstants.YES.equals(existingDocDetail.getQtyMatched())) {
            existingDocDetail.setStatus(DocumentItemInvoice.MATCHED);
        }

        detailAccess.update(existingDocDetail);
        
        if (existingDocDetail.getStatus().equals(DocumentItemInvoice.MATCHED)) {
			persistSuccessfulDetailLevelMatches(existingDocDetail, receiptIds);
		}

        if (existingDocDetail.getStatus().equals(DocumentItemInvoice.MATCHED)) {
            long docId = existingDocDetail.getDocId();
            MerchandiseDocument invoice = (MerchandiseDocument) ServiceFactory.getDocumentService()
                    .getDocHeadByDocId(docId);
            ServiceFactory.getInvoiceDetailService().buildInvoiceLines(invoice);
            ServiceFactory.getMatchStatusService().checkMatchedStatus(invoice);
            
            if(receiptIds.size() > 0 ){
            	
            	createReceiptItemPosting(receiptIds, itemId, existingDocDetail, docId, null);
            	// BRN V 1.2 Begin
            	// createPartiallyMatchedReceiptRow(receiptIds, itemId);
            	updatePartiallyMatchedReceipts(receiptIds, itemId, Long.toString(row.getOrderNo()),
                        Long.toString(row.getLocation()));
            	// BRN V 1.2 End
            }

            if (invoice.getStatus().equals(Document.MATCHED)) {
                ImDocHeadAccess headAccess = new ImDocHeadAccess();
                ImDocHeadRow updateHeadRow = new ImDocHeadRow();
                updateHeadRow.setDocId(docId);
                updateHeadRow.setStatus(Document.MATCHED);
                updateHeadRow.setMatchDate(ServiceFactory.getPeriodService().getScreenVDate()
                        .getTimestamp());
                updateHeadRow.setMatchId(ReIMUserContext.getUsername());
                updateHeadRow.setLastDatetime(new ReIMDate().getTimestamp());
                updateHeadRow.setLastUpdateId(ReIMUserContext.getUsername());
                headAccess.update(updateHeadRow);
                
                updateReceiptsForMatched(receiptIds, itemId, Long.toString(row.getOrderNo()), Long
                        .toString(row.getLocation()));
            } else {
                if (fromDetailMatch) {
                    updateReceiptsForMatched(receiptIds, itemId, Long.toString(row.getOrderNo()),
                            Long.toString(row.getLocation()));
                } else {
                    updateReceiptItemsQtyMatched(Long.toString(row.getOrderNo()), Long.toString(row
                            .getLocation()));
                }

            }
        }
    }

    protected void updateReceiptsForNonMatched(List receiptIds, String itemId, String orderId,
            String locId) throws ReIMException {        
        updateReceiptItemsQtyMatched(orderId, locId);
    }

    public void updatePartiallyMatchedReceipts(List receiptIds, String itemId, String orderId,
            String locId) throws ReIMException {
        ReceiptItem[] receiptItems = getReceiptItems(receiptIds, itemId, orderId, locId);
        // Create or update the IM_PARTIALLY_MATCHED_RECEIPTS rows
        ImPartiallyMatchedReceiptsAccessExt recAccessExt = new ImPartiallyMatchedReceiptsAccessExt();
        recAccessExt.updateReceiptItemStatus(receiptItems);
    }

    private ReceiptItem[] getReceiptItems(List receiptIds, String itemId, String orderId,
            String locId) throws ReIMException {
        ReceiptItem[] receiptItems = ReceiptService.buildReceiptItems(receiptIds, orderId, locId,
                itemId);
        return receiptItems;
    }

    private void updateReceiptItemsQtyMatched(String orderNo, String locationId)
            throws ReIMException {
        // Update the receipt items by the qty matched
        Receipt[] updateReceipts = ServiceFactory.getReceiptService()
                .selectReceiptsFromInvoiceOrder(orderNo, locationId, true);
        AShipSkuBean shipSku = (AShipSkuBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipSkuBean);
        
        if (updateReceipts != null) {
			for (Receipt updateReceipt : updateReceipts) {
				ReceiptItem[] receiptItems;
				try {
					receiptItems = shipSku.readReceiptItems(
							updateReceipt.getReceiptId());
				} catch (RetekException e) {
					throw new ReIMException(e);
				}
				if (receiptItems != null) {
					for (ReceiptItem receiptItem : receiptItems) {
						updateReceipt.putReceiptItem(receiptItem.getItemId(),
								receiptItem);
					}
				}
			}        
        AShipmentAPI api = (AShipmentAPI) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipmentAPI);
        api.updateReceiptInvoiceQtyMatched(updateReceipts, false);
        }
    }
        
    /**
     * Method: createPartiallyMatchedReceiptRow. This function is called only during cost
     * descrepancy resolution through detail match. This function creates or updates a row in the
     * IM_PARTIALLY_MATCHED_RECEIPTS.
     * 
     * @param receiptIds
     *            input receiptIds list.
     * @param itemId
     *            input itemId
     * @throws ReIMException
     */
    private void createPartiallyMatchedReceiptRow(List receiptIds, String itemId)
            throws ReIMException {
        ImPartiallyMatchedReceiptsAccessExt receiptItemAccess = new ImPartiallyMatchedReceiptsAccessExt();
        ImReceiptItemPostingAccessExt receiptAccess = new ImReceiptItemPostingAccessExt();
        ArrayList creates = new ArrayList();
        ArrayList updates = new ArrayList();
        
        if (receiptIds != null) {
        	Iterator receiptIdsIter = receiptIds.iterator();
        	while (receiptIdsIter.hasNext()) {
        		String receiptId = (String) receiptIdsIter.next();

        		double qtyToPost = receiptAccess.getTotalMatchedQty(receiptId, itemId);
        		if (qtyToPost == 0) {
        			continue;
        		}
        		// Determine whether the receipt item already exists on
        		// IM_PARTIALLY_MATCHED_RECEIPTS or not.
        		// If it doesn't then add to creates i.e. new entry.
        		// Else add to updates already existing entry.
        		ImPartiallyMatchedReceiptsRow receiptItemRow = receiptItemAccess.read(Long
        				.parseLong(receiptId), itemId, false);
        		if (receiptItemRow == null) {
        			receiptItemRow = new ImPartiallyMatchedReceiptsRow(Long.parseLong(receiptId),
        					itemId);
        			receiptItemRow.setQtyMatched(qtyToPost);
        			creates.add(receiptItemRow);
        		} else {
        			receiptItemRow.setQtyMatched(qtyToPost);
        			updates.add(receiptItemRow);
        		}
        	}
        }

        // create new IM_PARTIALLY_MATCHED_RECEIPTS rows.
        if (!creates.isEmpty()) {
            ImPartiallyMatchedReceiptsRow[] receiptRows = new ImPartiallyMatchedReceiptsRow[creates
                    .size()];
            receiptRows = (ImPartiallyMatchedReceiptsRow[]) creates.toArray(receiptRows);
            receiptItemAccess.create(receiptRows);
        }

        // update existing IM_PARTIALLY_MATCHED_RECEIPTS rows.
        if (!updates.isEmpty()) {
            ImPartiallyMatchedReceiptsRow[] receiptRows = new ImPartiallyMatchedReceiptsRow[updates
                    .size()];
            receiptRows = (ImPartiallyMatchedReceiptsRow[]) updates.toArray(receiptRows);
            receiptItemAccess.update(receiptRows);
        }
    }

    protected void createReceiptItemPosting(ArrayList receiptIds, String itemId,
            ImInvoiceDetailRow existingDocDetail, long docId,
            ImPartiallyMatchedReceiptsRow[] matchedItemReceipts) throws ReIMException {
        ArrayList negativeQtyReceipts = new ArrayList();
        ArrayList positiveQtyReceipts = new ArrayList();

        if (matchedItemReceipts == null || matchedItemReceipts.length <= 0) {
            // Divide receipts into two groups - those with negative quantities and those with
            // positive quantities.
        	if (receiptIds != null) {
        		for (Iterator receiptIdIter = receiptIds.iterator(); receiptIdIter.hasNext();) {
        			String receiptId = (String) receiptIdIter.next();

        			ImPartiallyMatchedReceiptsAccessExt recAccessExt = new ImPartiallyMatchedReceiptsAccessExt();
        			ImPartiallyMatchedReceiptsRow matchedReceiptItem = null;
        			matchedReceiptItem = recAccessExt.read(Long.valueOf(receiptId), itemId, false);
        			double matchedQty = 0.0;
        			if (matchedReceiptItem == null) {
        				matchedQty = ServiceFactory.getReceiptService().calculateAvailableToMatchQty(
        						receiptId, itemId);
        			} else {
        				matchedQty = matchedReceiptItem.getQtyMatched();
        			}
        			ReceiptQty receiptQty = new ReceiptQty(receiptId,
        					getReceivedQty(receiptId, itemId), matchedQty);
        			if (receiptQty.getQtyReceived() < 0) {
        				negativeQtyReceipts.add(receiptQty);
        			} else {
        				positiveQtyReceipts.add(receiptQty);
        			}
        		}
        	}
        } else {
            // Divide receipts into two groups - those with negative quantities and those with
            // positive quantities.
            for (int i = 0; i < matchedItemReceipts.length; i++) {
                String receiptId = String.valueOf(matchedItemReceipts[i].getShipment());
                double matchedQty = matchedItemReceipts[i].getQtyMatched();
                ReceiptQty receiptQty = new ReceiptQty(receiptId,
                        getReceivedQty(receiptId, itemId), matchedQty);
                if (receiptQty.getQtyReceived() < 0) {
                    negativeQtyReceipts.add(receiptQty);
                } else {
                    positiveQtyReceipts.add(receiptQty);
                }
            }
        }

        ImReceiptItemPostingAccessExt receiptAccess = new ImReceiptItemPostingAccessExt();
        double resolutionAdjustedQty = existingDocDetail.getResolutionAdjustedQty();

        ArrayList itemPosting = new ArrayList();
        ArrayList itemPostingInvoice = new ArrayList();

        // First, create the receipt item posting objects which correspond to negative quantities.
        // Since negative quantity receipts, by edict, cannot be split, the quantity to post is the
        // original received quantity.
        for (Iterator iter = negativeQtyReceipts.iterator(); iter.hasNext();) {
            ReceiptQty receiptQty = (ReceiptQty) iter.next();
            long receiptSeqNo = receiptAccess.getNextSeqNo();

            ImReceiptItemPostingRow receiptRow = new ImReceiptItemPostingRow(receiptSeqNo, Long
                    .parseLong(receiptQty.getReceiptId()), itemId, receiptQty.getQtyReceived(),
                    Double.MIN_VALUE);

            // Adjust the remaining resolution adjusted quantity. NOTE: For negative quantities,
            // this is _expected_ to be a positive increment.
            resolutionAdjustedQty -= receiptQty.getQtyReceived();

            itemPosting.add(receiptRow);
            itemPostingInvoice.add(new ImRcptItemPostingInvoiceRow(receiptSeqNo, docId, "M"));
        }

        // Next, create the receipt item posting objects corresponding to positive quantities. Since
        // such receipts may have been spreviously split and matched, the quantity to post is:
        // MIN(received quantity - matched quantity, resolution adjusted quantity)
        for (Iterator iter = positiveQtyReceipts.iterator(); iter.hasNext();) {
            ReceiptQty receiptQty = (ReceiptQty) iter.next();
            long receiptSeqNo = receiptAccess.getNextSeqNo();

            double qtyToPost = receiptQty.getQtyReceived() - getMatchedQty(receiptQty.getReceiptId(), itemId);
            if (qtyToPost >= resolutionAdjustedQty) {
                qtyToPost = resolutionAdjustedQty;
            }
            ImReceiptItemPostingRow receiptRow = new ImReceiptItemPostingRow(receiptSeqNo, Long
                    .parseLong(receiptQty.getReceiptId()), itemId, qtyToPost, Double.MIN_VALUE);

            // Adjust the remaining resolution adjusted quantity.
            resolutionAdjustedQty -= qtyToPost;

            itemPosting.add(receiptRow);
            itemPostingInvoice.add(new ImRcptItemPostingInvoiceRow(receiptSeqNo, docId, "M"));
        }

        ImRcptItemPostingInvoiceAccess rcptInvoiceAccess = new ImRcptItemPostingInvoiceAccess();
        receiptAccess.create((ImReceiptItemPostingRow[]) itemPosting
                .toArray(new ImReceiptItemPostingRow[itemPosting.size()]));
        rcptInvoiceAccess.create((ImRcptItemPostingInvoiceRow[]) itemPostingInvoice
                .toArray(new ImRcptItemPostingInvoiceRow[itemPostingInvoice.size()]));
    }

    private class ReceiptQty {
        private String receiptId;
        private double qtyReceived;
        private double matchedQty;

        ReceiptQty(String receiptId, double qtyReceived, double matchedQty) {
            this.receiptId = receiptId;
            this.qtyReceived = qtyReceived;
            this.matchedQty = matchedQty;
        }

        double getQtyReceived() {
            return qtyReceived;
        }

        String getReceiptId() {
            return receiptId;
        }

        double getMatchedQty() {
            return matchedQty;
        }
    }

    protected void updateReceiptsForMatched(ArrayList receiptIds, String itemId, String orderNo,
            String locationId) throws ReIMException {

        // Find out if the receipt was split to match the invoice. If
        // received_qty - matched_qty > 0,
        // the receipt was split and it's not yet completely matched.
    	if (receiptIds != null ) {
    		for (int i = 0; i < receiptIds.size(); i++) {
    			double receivedQty = getReceivedQty((String) receiptIds.get(i), itemId);
    			AOrderLocationBean orderLocBean = (AOrderLocationBean) ReIMBeanFactory
    			.getBean(ReIMBeanFactory.AOrderLocationBean);
    			double matchedQty = getMatchedQty((String) receiptIds.get(i), itemId);
    			if (matchedQty == 0.0) {
    				matchedQty = orderLocBean
    				.checkForEntryInImPartiallyMatchedReceipts(
    						(String) receiptIds.get(i), itemId);
    			}

    			if ((receivedQty - matchedQty) == 0) {
    				updateReceiptForMatched(orderNo, locationId, receiptIds);
    			}else{
    				updateReceiptItemsQtyMatched(orderNo, locationId);
    			}
    		}
    	}
    }

    private static double getReceivedQty(String receiptId, String itemId) throws ReIMException {
        return ServiceFactory.getReceiptService().getItemQtyReceived(receiptId, itemId);
    }

    private static double getMatchedQty(String receiptId, String itemId) throws ReIMException {
        return new ImReceiptItemPostingAccessExt().getTotalMatchedQty(receiptId, itemId);
    }

    protected static void updateReceiptForMatched(String orderNo, String locationId,
            ArrayList receiptIds) throws ReIMException {
        // Update INVC_MATCH_STATUS of SHIPMENT table to "M".
        Receipt[] updateReceiptAvail = new Receipt[receiptIds.size()];
        String[] totalReceipts = (String[]) receiptIds.toArray(new String[0]);
        AShipSkuBean shipSku = (AShipSkuBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipSkuBean);

        ImPartiallyMatchedReceiptsAccessExt receiptItemAccess = new ImPartiallyMatchedReceiptsAccessExt();
        ArrayList fullyMatchedReceipts = new ArrayList();

        for (int r = 0; r < totalReceipts.length; r++) {
            ReceiptItem[] receiptItems = shipSku.readReceiptItems(totalReceipts[r]);
            updateReceiptAvail[r] = new Receipt();
            updateReceiptAvail[r].setReceiptId(totalReceipts[r]);

            for (int i = 0; i < receiptItems.length; i++) {
                updateReceiptAvail[r].putReceiptItem(receiptItems[i].getItemId(), receiptItems[i]);
            }

            boolean fullyMatched = true;
    		for(ReceiptItem receiptItem : receiptItems) {
    			double matchedQty = DaoFactory.getImReceiptItemPostingAccessExt().getTotalMatchedQty(receiptItem.getReceiptId(), receiptItem.getItemId());
    			if(matchedQty != receiptItem.getQtyReceived()) {
    				fullyMatched = false;
    				break;
    			}
    		}
    		if(fullyMatched) {
    			fullyMatchedReceipts.add(updateReceiptAvail[r]);
    		}

        }
        AShipmentAPI api = (AShipmentAPI) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipmentAPI);
        // Update the status on only the fully matched receipts to matched. That
        // means
        // the value of INVC_MATCH_STATUS of SHIPMENT table is equal to "M"
        if (fullyMatchedReceipts != null && fullyMatchedReceipts.size() > 0) {
            api.updateReceiptInvcMatchedStatus((Receipt[]) fullyMatchedReceipts
                    .toArray(new Receipt[fullyMatchedReceipts.size()]), Receipt.MATCHED);
        }
        api.updateReceiptInvoiceQtyMatched(updateReceiptAvail, false);
    }

    /**
     * This method updates the receipt item matched quantity to reserve the amount used in the
     * discrepancy resolution. Then all receipt item matches are checked for the receipt, and if all
     * line quantities have been exhausted the receipt is set to matched.
     * 
     * For split receipt, or existing partial matches and split receipts, the receipt item match
     * amount is updated by the new resolution amount. For all other instances of quantity
     * resolution the full receipt amount for the current item is reserved.
     * 
     * @param qtyDiscId
     *            Quantity discrepancy id for the current resolutions
     * @param resolutions
     *            Current resolutions
     * @throws ReIMException
     */
    protected static List setReceiptItem(Resolution[] resolutions, Long qtyDiscId)
            throws RetekException {
        // set receipt item qty total on IM_PARTIALLY_MATCHED_RECEIPTS

        ImPartiallyMatchedReceiptsAccessExt receiptItemAccess = new ImPartiallyMatchedReceiptsAccessExt();

        ArrayList updates = new ArrayList();
        ArrayList trackingUpdates = new ArrayList();
        ArrayList creates = new ArrayList();
        HashMap nonSplitReceipts = new HashMap();
        String itemId = null;
        ArrayList matchedReceiptItems = new ArrayList();

        if (qtyDiscId != null) {
            ImQtyDiscrepancyReceiptAccessExt rcptAccess = new ImQtyDiscrepancyReceiptAccessExt();
            ImQtyDiscrepancyReceiptRow[] qtyDiscrepancyReceiptRows = rcptAccess
                    .readReceipts(qtyDiscId.longValue());

            int qtyDiscrepancyReceiptRowsLength = (qtyDiscrepancyReceiptRows == null) ? 0
                    : qtyDiscrepancyReceiptRows.length;

            for (int i = 0; i < qtyDiscrepancyReceiptRowsLength; i++) {
                ImQtyDiscrepancyReceiptRow receipt = qtyDiscrepancyReceiptRows[i];
                nonSplitReceipts.put(new Long(receipt.getReceiptId()), receipt);
            }

            int resolutionsLength = resolutions.length;

            for (int i = 0; i < resolutionsLength; i++) {
                ResolutionMerchandiseInvoice resolution = (ResolutionMerchandiseInvoice) resolutions[i];

                itemId = resolution.getDiscrepancyItemId();

                String action = resolution.getAction();

                // ****process match to receipt resolutions***//
                if (action.equals(ResolutionMerchandiseInvoice.MR)) {
                    ReceiptItem matchToReceiptItem = resolution.getMatchToReceiptItem();

                    // Determine whether the receipt item already exists on
                    // IM_PARTIALLY_MATCHED_RECEIPTS
                    ImPartiallyMatchedReceiptsRow receiptItemRow = receiptItemAccess.read(Long
                            .parseLong(matchToReceiptItem.getReceiptId()), matchToReceiptItem
                            .getItemId(), false);

                    if (receiptItemRow == null) {
                        receiptItemRow = new ImPartiallyMatchedReceiptsRow(Long
                                .parseLong(matchToReceiptItem.getReceiptId()), matchToReceiptItem
                                .getItemId());

                        // If this line is totally unmatched, then the available
                        // to match will equal
                        // the qty received
                        receiptItemRow.setQtyMatched(matchToReceiptItem.getAvailableToMatchQty());
                        creates.add(receiptItemRow);
                    } else {
                        // If this line is partially matched, then the sum of
                        // the existing matched
                        // qty and the available to match qty
                        // will equal the qty received in this case. The
                        // resolution of this
                        // discrepancy has used all of the available to match
                        // qty therefore the receipt line should be fully
                        // matched.
                        receiptItemRow.setQtyMatched(receiptItemRow.getQtyMatched()
                                + matchToReceiptItem.getAvailableToMatchQty());
                        updates.add(receiptItemRow);

                        receiptItemRow = new ImPartiallyMatchedReceiptsRow(receiptItemRow
                                .getShipment(), itemId);
                        receiptItemRow.setQtyMatched(matchToReceiptItem.getAvailableToMatchQty());
                        trackingUpdates.add(receiptItemRow);
                    }
                }

                // ****process split receipt resolutions***//
                // Only add matched amount if split receipts - put whole amount
                // for other types
                if (action.equals(ResolutionMerchandiseInvoice.SR)) {
                    ReceiptItem[] splitReceiptItems = resolution.getSplitReceiptItems();
                    int splitReceiptItemLength = splitReceiptItems.length;

                    for (int j = 0; j < splitReceiptItemLength; j++) {
                        ReceiptItem splitReceiptItem = splitReceiptItems[j];

                        // Determine whether the receipt item already exists on
                        // IM_PARTIALLY_MATCHED_RECEIPTS
                        ImPartiallyMatchedReceiptsRow receiptItemRow = receiptItemAccess.read(Long
                                .parseLong(splitReceiptItem.getReceiptId()), resolution
                                .getDiscrepancyItemId(), false);

                        // If it does not, the split receipt item will need to
                        // be inserted,
                        // otherwise updated.
                        if (receiptItemRow == null) {
                            receiptItemRow = new ImPartiallyMatchedReceiptsRow(Long
                                    .parseLong(splitReceiptItem.getReceiptId()), resolution
                                    .getDiscrepancyItemId());
                            receiptItemRow.setQtyMatched(splitReceiptItem.getQtyReceived());
                            creates.add(receiptItemRow);
                        } else {
                            Quantity receiptQty = new Quantity(splitReceiptItem.getQtyReceived());
                            receiptQty = receiptQty.add(receiptItemRow.getQtyMatched());
                            receiptItemRow.setQtyMatched(receiptQty.doubleValue());
                            updates.add(receiptItemRow);

                            receiptItemRow = new ImPartiallyMatchedReceiptsRow(receiptItemRow
                                    .getShipment(), itemId);
                            receiptItemRow.setQtyMatched(splitReceiptItem.getQtyReceived());
                            trackingUpdates.add(receiptItemRow);
                        }

                        nonSplitReceipts.remove(new Long(splitReceiptItem.getReceiptId()));
                    }
                }
            }

            // process the remaining non-split existing receipts associated with
            // the discrepancy
            for (Iterator i = nonSplitReceipts.values().iterator(); i.hasNext();) {
                ImQtyDiscrepancyReceiptRow receipt = (ImQtyDiscrepancyReceiptRow) i.next();

                ImPartiallyMatchedReceiptsRow receiptItemRow = receiptItemAccess.read(receipt
                        .getReceiptId(), itemId, false);

                if (receiptItemRow == null) {
                    receiptItemRow = new ImPartiallyMatchedReceiptsRow(receipt.getReceiptId(),
                            itemId);

                    AShipSkuBean shipSku = (AShipSkuBean) ReIMBeanFactory
                            .getBean(ReIMBeanFactory.AShipSkuBean);
                    ReceiptItem item = shipSku.readReceiptItem(Long
                            .toString(receipt.getReceiptId()), itemId);

                    // if the there is no shipsku record, then the item was not
                    // received as apart of
                    // this shipment and
                    // has no receipt qty. Therefore, no qty for this
                    // item/shipment should be
                    // matched
                    if (item != null) {
                        receiptItemRow.setQtyMatched(item.getQtyReceived());
                        creates.add(receiptItemRow);
                    }
                } else {
                    AShipSkuBean shipSku = (AShipSkuBean) ReIMBeanFactory
                            .getBean(ReIMBeanFactory.AShipSkuBean);
                    ReceiptItem item = shipSku.readReceiptItem(Long
                            .toString(receipt.getReceiptId()), itemId);

                    receiptItemRow.setQtyMatched(item.getQtyReceived());
                    updates.add(receiptItemRow);

                    receiptItemRow = new ImPartiallyMatchedReceiptsRow(receipt.getReceiptId(),
                            itemId);
                    receiptItemRow.setQtyMatched(item.getAvailableToMatchQty());
                    trackingUpdates.add(receiptItemRow);
                }
            }

            // create IM_PARTIALLY_MATCHED_RECEIPTS
            ImPartiallyMatchedReceiptsRow[] receiptRows = new ImPartiallyMatchedReceiptsRow[creates
                    .size()];
            receiptRows = (ImPartiallyMatchedReceiptsRow[]) creates.toArray(receiptRows);
            receiptItemAccess.create(receiptRows);

            // update IM_PARTIALLY_MATCHED_RECEIPTS for split receipts
            receiptRows = new ImPartiallyMatchedReceiptsRow[updates.size()];
            receiptRows = (ImPartiallyMatchedReceiptsRow[]) updates.toArray(receiptRows);
            receiptItemAccess.update(receiptRows);

            // Only track the amount actually matched this time, not the total
            // matched overall for
            // this receipt line
            receiptRows = new ImPartiallyMatchedReceiptsRow[trackingUpdates.size()];
            receiptRows = (ImPartiallyMatchedReceiptsRow[]) trackingUpdates.toArray(receiptRows);

            // Matched receipts
            if (creates.size() > 0) {
                matchedReceiptItems.addAll(creates);
            }
            if (updates.size() > 0) {
                matchedReceiptItems.addAll(updates);
            }

            // check all values in above table for the receipts
            // If all match the received qty on the receipts, then the receipt
            // should be set to
            // matched

            ArrayList matchedReceipts = new ArrayList();

            for (int i = 0; i < qtyDiscrepancyReceiptRowsLength; i++) {
                ImQtyDiscrepancyReceiptRow qtyDiscrepancyReceiptRow = qtyDiscrepancyReceiptRows[i];
                long receiptId = qtyDiscrepancyReceiptRow.getReceiptId();
                Receipt matchedReceipt = new Receipt();
                matchedReceipt.setReceiptId(Long.toString(receiptId));

                ImPartiallyMatchedReceiptsRow[] receiptItemsMatched = receiptItemAccess
                        .readReceiptItemsMatched(receiptId);
                AShipSkuBean shipSku = (AShipSkuBean) ReIMBeanFactory
                        .getBean(ReIMBeanFactory.AShipSkuBean);

                ReceiptItem[] receiptItems = shipSku.readReceiptItems(Long.toString(receiptId));

                HashMap receiptItemAmountsMap = new HashMap();

                int receiptItemLength = receiptItems.length;

                for (int k = 0; k < receiptItemLength; k++) {
                    ReceiptItem receiptItem = receiptItems[k];
                    receiptItemAmountsMap.put(receiptItem.getItemId(), new Double(receiptItem
                            .getQtyReceived()));
                }

                // Check size. If not all items are matched yet then the receipt
                // is not matched
                if (receiptItemsMatched == null || receiptItemLength != receiptItemsMatched.length) {
                    continue;
                }

                int matched = 0;

                for (int l = 0; l < receiptItemLength; l++) {
                    ImPartiallyMatchedReceiptsRow itemMatched = receiptItemsMatched[l];

                    double expected = ((Double) receiptItemAmountsMap.get(itemMatched.getItem()))
                            .doubleValue();

                    if (itemMatched.getQtyMatched() == expected) {
                        receiptItems[l].setAvailableToMatchQty(expected);
                        matchedReceipt.putReceiptItem(receiptItems[l].getItemId(), receiptItems[l]);
                        matched++;
                    }
                }

                if (matched == receiptItemLength) {
                    matchedReceipts.add(matchedReceipt);
                }
            }
            return matchedReceiptItems;
        } else {
            return null;
        }
    }

    /**
     * This method will retrieve all the saved variance resolutions for a particular document / item
     * / discrepancy type combination. This method will exclude resolutions that involve a reroute.
     * Also, this method does not populate any relevant comments that may exist.
     * 
     * @throws ReIMException
     */

    /**
     * This method will update the specified discrepancy's resolution amount. The specified
     * discrepancy ID will be the primary key for either the cost or quantity discrepancy table.
     * 
     * @throws ReIMException
     */
    public static void saveSelectedAmount(long discrepancyId, String discrepancyType,
            double selectedAmount) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            if (discrepancyType.equals(Resolution.TYPE_COST)) {
                ImCostDiscrepancyAccess access = new ImCostDiscrepancyAccess();
                ImCostDiscrepancyRow row = new ImCostDiscrepancyRow(discrepancyId);
                row.setResolutionCost(selectedAmount);
                access.update(row);
            } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                ImQtyDiscrepancyAccess access = new ImQtyDiscrepancyAccess();
                ImQtyDiscrepancyRow row = new ImQtyDiscrepancyRow(discrepancyId);
                row.setResolutionQty(selectedAmount);
                access.update(row);
            }
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw (e);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    /**
     * isFullResolutionRequired will determine if any of the resolutions specified contain actions
     * that require the discrepancy to be resolved to zero or within tolerance in order to save the
     * resolutions.
     * 
     * @return boolean
     * @param Resolution
     *            [] resolutions
     * @throws ReIMException
     */
    public static boolean isFullResolutionRequired(Resolution[] resolutions) throws ReIMException {
        try {
            boolean fullResolutionRequired = false;
            for (int i = 0; i < (resolutions != null ? resolutions.length : 0); i++) {
                if (ReasonCode.ACTIONS_NOT_ALLOWED_PARTIAL_RESOLUTIONS.containsKey(resolutions[i]
                        .getAction())) {
                    fullResolutionRequired = true;
                    break;
                }
            }
            return fullResolutionRequired;
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_save_variance_resolutions", Severity.ERROR, e,
                    VarianceResolutionService.class);
        }
    }

    public static ArrayList selectDiscrepenciesByItemCosts(String itemId, double orderCost,
            double invoiceCost,String orderNo) throws ReIMException {
        try {
            AOrderBean ordBean = (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);

            TransactionManagerFactory.getInstance().start();
            return ordBean.selectDiscrepenciesByItemCosts(itemId, orderCost, invoiceCost,orderNo);
        } catch (ReIMException re) {
            throw (re);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_select_discrepencies_by_item_costs",
                    Severity.ERROR, e, VarianceResolutionService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    private static double calculateCostQntyVariance(String type, String currencyCode,
            String invCNCostQnty, String recCNRCostQnty) throws ReIMException {
        // It is essential that Money or quantity be used for subtraction as we
        // need to maintain
        // the exact values. i.e we need to be able to evaluate to exactly 0.0
        // which may not happen
        // if exact precision is not maintained.

        if (type == null || invCNCostQnty == null || recCNRCostQnty == null) { return 0; }

        Money moneyCNInCost = ReIMMoney.parseCurrencyString(invCNCostQnty, currencyCode);

        if (type.equals(Document.CREDIT_MEMO_PRICE) || type.equals(Document.CREDIT_MEMO_QUANTITY)) { return moneyCNInCost
                .doubleValue(); }

        Money moneyCNRReCost = ReIMMoney.parseCurrencyString(recCNRCostQnty, currencyCode);

        // Regardless of the cost selection, the oustanding variance will always
        // be order cost minus
        // document cost.
        return (moneyCNRReCost.subtract(moneyCNInCost).doubleValue());
    }

    public double calculateSumResolutions(VarianceResolution[] resolutionList) {
        double reasonCodeAmount = 0;
        if (resolutionList != null && resolutionList.length > 0) {
            int resolutionListLength = resolutionList.length;
            for (int i = 0; i < resolutionListLength; i++) {
                if (!resolutionList[i].getAction().equals(ReasonCode.REROUTE_COST_DISCREPANCY)
                        && !resolutionList[i].getAction().equals(
                                ReasonCode.REROUTE_QUANTITY_DISCREPANCY)) {
                    reasonCodeAmount += resolutionList[i].getAdjustedAmount().doubleValue();
                }
            }
        }
        return reasonCodeAmount;
    }

    public Resolution[] getResolutionActionsForDocItemType(String docType, long docId,
            String itemId, String discrepancyType, String debitMemoReasonCode, String currencyCode)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            ArrayList resolutionList = new ArrayList();
            String commentDiscrepancyType;
            Comment[] comments;

            if (docType.equals(Document.MERCHANDISE_INVOICE)) {
                IImResolutionActionAccessExt access = DaoFactory.getImResolutionActionAccessExt();
                ImResolutionActionRow[] row = access.getResolutionActionsForDocItemType(docId,
                        itemId, discrepancyType, ResolutionMerchandiseInvoice.UNROLLED);

                if (row != null) {
                    for (int i = 0; i < row.length; i++) {
                        commentDiscrepancyType = null;
                        if (discrepancyType.equals(Resolution.TYPE_COST)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_COST;
                        } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_QUANTITY;
                        }
                        comments = ServiceFactory.getCommentService().getCommentsForDocItemReason(
                                commentDiscrepancyType, row[i].getDocId(), row[i].getItemId(),
                                row[i].getReasonCode());

                        resolutionList
                                .add(new ResolutionMerchandiseInvoice(discrepancyType, row[i]
                                        .getDocId(), row[i].getItemId(), row[i].getReasonCode(),
                                        ServiceFactory.getReasonCodesService().getReasonCodeDesc(
                                                row[i].getReasonCode()), row[i].getAction(),
                                        (row[i].isUnitCostNull() ? null : new Double(row[i]
                                                .getUnitCost())), (row[i].isQuantityNull() ? null
                                                : new Double(row[i].getQuantity())), null,
                                        // quantity discrepancy ID
                                        null, // reroute role ID
                                        currencyCode, comments, // comments
                                        row[i].getStatus(), Resolution.SAVED, null));
                    }
                }
            } else if (docType.equals(Document.CREDIT_NOTE)) {
                IImResolutionActionAccessExt access = DaoFactory.getImResolutionActionAccessExt();
                ImResolutionActionRow[] row = access.getResolutionActionsForDocItemType(docId,
                        itemId, discrepancyType, Resolution.UNROLLED);

                if (row != null) {
                    for (int i = 0; i < row.length; i++) {
                        commentDiscrepancyType = null;
                        if (discrepancyType.equals(Resolution.TYPE_COST)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_COST;
                        } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_QUANTITY;
                        }
                        comments = ServiceFactory.getCommentService().getCommentsForDocItemReason(
                                commentDiscrepancyType, row[i].getDocId(), row[i].getItemId(),
                                row[i].getReasonCode());

                        resolutionList
                                .add(new ResolutionCreditNote(discrepancyType, row[i].getDocId(),
                                        row[i].getItemId(), row[i].getReasonCode(), ServiceFactory
                                                .getReasonCodesService().getReasonCodeDesc(
                                                        row[i].getReasonCode()),
                                        row[i].getAction(), (row[i].isUnitCostNull() ? null
                                                : new Double(row[i].getUnitCost())), (row[i]
                                                .isQuantityNull() ? null : new Double(row[i]
                                                .getQuantity())), null,
                                        // quantity discrepancy ID
                                        null, // reroute role ID
                                        currencyCode, comments, // comments
                                        row[i].getStatus(), Resolution.SAVED, null));
                    }
                }
            } else // disputed credit memo
            {
                IImReversalResolutionActionAccessExt access = DaoFactory
                        .getImReversalResolutionActionAccessExt();
                ImReversalResolutionActionRow[] row = access
                        .getResolutionActionsForDocItemReasonCode(docId, itemId, discrepancyType,
                                debitMemoReasonCode, ResolutionMerchandiseInvoice.UNROLLED);

                if (row != null) {
                    for (int i = 0; i < row.length; i++) {
                        commentDiscrepancyType = null;
                        if (discrepancyType.equals(Resolution.TYPE_COST)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_COST;
                        } else if (discrepancyType.equals(Resolution.TYPE_QUANTITY)) {
                            commentDiscrepancyType = ReIMConstants.DISCREPANCY_TYPE_QUANTITY;
                        }
                        comments = ServiceFactory.getCommentService().getCommentsForDocItemReason(
                                commentDiscrepancyType, row[i].getDocId(), row[i].getItem(),
                                row[i].getReasonCode());

                        resolutionList.add(new ResolutionDisputedCreditMemo(discrepancyType, row[i]
                                .getDocId(), row[i].getItem(), row[i].getDebitReasonCode(), row[i]
                                .getReasonCode(), ServiceFactory.getReasonCodesService()
                                .getReasonCodeDesc(row[i].getReasonCode()),
                        // reasonCodeDesc
                                row[i].getAction(), new Double(row[i].getUnitCost()), new Double(
                                        row[i].getQuantity()), null,
                                // quantity discrepancy ID
                                null, // reroute role ID
                                currencyCode, comments, // comments
                                row[i].getStatus(), Resolution.SAVED));
                    }
                }
            }

            if (resolutionList != null && resolutionList.size() > 0) {
                return (Resolution[]) resolutionList.toArray(new Resolution[resolutionList.size()]);
            } else {
                return null;
            }
        } catch (ReIMException e) {
            TransactionManagerFactory.getInstance().rollback();
            throw (e);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public Resolution[] createResolutions(VarianceResolution[] varianceResolutions)
            throws ReIMException {
        if (varianceResolutions != null) {
            int varianceResolutionLength = varianceResolutions.length;
            Resolution[] resolutions = new Resolution[varianceResolutionLength];
            VarianceResolution varianceResolution;
            String docType = varianceResolutions[0].getDocType();

            for (int i = 0; i < varianceResolutionLength; i++) {
                Double adjustedCost = null;
                Double adjustedQuantity = null;
                Long rerouteBusinessRoleId = null;

                varianceResolution = varianceResolutions[i];

                if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                    adjustedCost = varianceResolution.getAdjustedAmount();
                } else {
                    // adjustedAmount is null if action is re-reroute
                    if (varianceResolution.getAdjustedAmount() != null) {
                        adjustedQuantity = new Double(varianceResolution.getAdjustedAmount()
                                .doubleValue());
                    }
                }

                if (varianceResolution.getRerouteBusinessRoleId() != null) {
                    rerouteBusinessRoleId = new Long(varianceResolution.getRerouteBusinessRoleId());
                }

                if (docType.equals(Document.MERCHANDISE_INVOICE)) {
                    if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        resolutions[i] = new ResolutionMerchandiseInvoice(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedCost, rerouteBusinessRoleId,
                                varianceResolution.getCurrencyCode(), varianceResolution
                                        .getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved());
                    } else {
                        resolutions[i] = new ResolutionMerchandiseInvoice(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedQuantity, varianceResolution
                                        .getQtyDiscrepancyId(), rerouteBusinessRoleId,
                                varianceResolution.getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved(), varianceResolution
                                        .getReceiptId());
                        // If this is a resolution for match to receipt, then
                        // the match to receipt attribute needs to be set.
                        if (varianceResolution.getAction() != null
                                && varianceResolution.getAction().equals(
                                        ResolutionMerchandiseInvoice.MR)) {
                            ((ResolutionMerchandiseInvoice) resolutions[i])
                                    .setMatchToReceiptItem(varianceResolution
                                            .getMatchToReceiptItem());
                        }

                        if (varianceResolution.getAction() != null
                                && varianceResolution.getAction().equals(
                                        ResolutionMerchandiseInvoice.SR)) {
                            ((ResolutionMerchandiseInvoice) resolutions[i])
                                    .setSplitReceiptItems(varianceResolution.getReceiptItems());
                        }
                    }
                } else if (docType.equals(Document.CREDIT_NOTE)) {
                    if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        resolutions[i] = new ResolutionCreditNote(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedCost, null, varianceResolution
                                        .getCurrencyCode(), varianceResolution.getComments(),
                                varianceResolution.getStatus(), varianceResolution
                                        .getResolutionSaved());
                    } else {
                        resolutions[i] = new ResolutionCreditNote(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution.getReasonCode(),
                                varianceResolution.getReasonCodeDesc(), varianceResolution
                                        .getAction(), adjustedQuantity, varianceResolution
                                        .getQtyDiscrepancyId(), null, varianceResolution
                                        .getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved(), null);
                    }
                }

                else // ResolutionDisputedCreditMemo
                {
                    if (varianceResolution.getDiscrepancyType().equals(Resolution.TYPE_COST)) {
                        resolutions[i] = new ResolutionDisputedCreditMemo(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution
                                        .getDebitMemoReasonCode(), varianceResolution
                                        .getReasonCode(), varianceResolution.getReasonCodeDesc(),
                                varianceResolution.getAction(), adjustedCost,
                                rerouteBusinessRoleId, varianceResolution.getCurrencyCode(),
                                varianceResolution.getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved());
                    } else {
                        resolutions[i] = new ResolutionDisputedCreditMemo(varianceResolution
                                .getDiscrepancyType(), varianceResolution.getDocId(),
                                varianceResolution.getItemId(), varianceResolution
                                        .getDebitMemoReasonCode(), varianceResolution
                                        .getReasonCode(), varianceResolution.getReasonCodeDesc(),
                                varianceResolution.getAction(), adjustedQuantity,
                                varianceResolution.getQtyDiscrepancyId(), rerouteBusinessRoleId,
                                varianceResolution.getComments(), varianceResolution.getStatus(),
                                varianceResolution.getResolutionSaved());
                    }

                }
            }
            return resolutions;
        }
        return null;
    }

    public VarianceResolution applyVarianceResolution(String docId, String docType, String itemId,
            String debitMemoReasonCode, String reasonCode, String reasonCodeDesc, String action,
            Double adjustedAmount, String adjustedAmountFormatted, String qtyDiscrepancyId,
            String rerouteBusinessRoleId, Comment[] comments, String receiptId)
            throws ReIMException {
        try {
            return new VarianceResolution(Resolution.TYPE_QUANTITY, new Long(docId).longValue(),
                    docType, itemId, debitMemoReasonCode, reasonCode, reasonCodeDesc, action,
                    adjustedAmount, adjustedAmountFormatted, new Long(qtyDiscrepancyId),
                    rerouteBusinessRoleId, comments, Resolution.UNROLLED, Resolution.NEW, receiptId);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_apply_resolution", Severity.ERROR, e,
                    VarianceResolutionService.class);
        }
    }

    public VarianceResolution applyVarianceResolution(String discrepancyType, String docId,
            String docType, String itemId, String debitMemoReasonCode, String reasonCode,
            String reasonCodeDesc, String action, Double adjustedAmount,
            String adjustedAmountFormatted, String rerouteBusinessRoleId, Comment[] comments,
            String currencyCode, String status, String resolutionSaved) throws ReIMException {
        try {
            return new VarianceResolution(discrepancyType, new Long(docId).longValue(), docType,
                    itemId, debitMemoReasonCode, reasonCode, reasonCodeDesc, action,
                    adjustedAmount, adjustedAmountFormatted, rerouteBusinessRoleId, comments,
                    currencyCode, status, resolutionSaved);
        } catch (Exception e) {
            throw new ReIMException("error.unable_to_apply_resolution", Severity.ERROR, e,
                    VarianceResolutionService.class);
        }
    }

    public double calculateCreditNoteOutstandingQuantityVarianceByApplyAmount(
            double currentOutstandingQtyVariance, double applyAmount) throws ReIMException {
        return currentOutstandingQtyVariance - applyAmount;
    }

    public double calculateCreditNoteOustandingQuantityVarianceByVarianceResolutions(
            double quantityVariance, VarianceResolution[] varianceResolutions) throws ReIMException {
        double allVarianceTotal = 0;

        if (varianceResolutions != null) {

            for (int i = 0; i < varianceResolutions.length; i++) {
                allVarianceTotal += varianceResolutions[i].getAdjustedAmount().doubleValue();
            }
        }

        return quantityVariance - allVarianceTotal;
    }
    
    private void persistSuccessfulDetailLevelMatches(
			ImInvoiceDetailRow existingDocDetail, List receiptIds)
    throws ReIMException {

    	Match match = new Match();
    	DocumentItemInvoice documentItemInvoice = new DocumentItemInvoice();
    	documentItemInvoice.setDocument(new Document(existingDocDetail
    			.getDocId()));
    	documentItemInvoice.setItem(new Item(existingDocDetail.getItem()));
    	DocumentItemInvoice[] invoiceItems = new DocumentItemInvoice[] { documentItemInvoice };
    	InvoiceLineLevel invoiceGroup = new InvoiceLineLevel();
    	invoiceGroup.setInvoiceItem(documentItemInvoice);

    	if(receiptIds != null && receiptIds.size()>0)
    	{
    		ReceiptItem[] receiptItems = new ReceiptItem[receiptIds.size()];
    		for (int i = 0; i < receiptIds.size(); i++) {
    			ReceiptItem receiptItem = new ReceiptItem();
    			receiptItem.setReceipt(new Receipt((String) receiptIds.get(i)));
    			receiptItem.setItemId(existingDocDetail.getItem());
    			receiptItems[i] = receiptItem;
    		}
    		ReceiptDetailSummaryLevel receiptGroup = new ReceiptDetailSummaryLevel(
    				receiptItems);
    		match.setReceiptGroup(receiptGroup);
    	}


    	match.setInvoiceGroup(invoiceGroup);

    	MatchHistoryService.persistSuccessfulDetailLevelMatches(
    			new Match[] { match }, false);
    }
}
