package com.retek.reim.db;

import java.sql.Connection;

import oracle.jdbc.OraclePreparedStatement;

import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import oracle.retail.reim.data.TransactionManagerFactory;

/**
 * This class extends the ImReceiptItemPostingStageAccess class for accessing
 * IM_RECEIPT_ITEM_POSTING_STAGE.
 */

/**
 * -- Modification History
 * 
 * Date     Reference  Developer     Description
 * ======== ========== ============= ==============================================
 * BRN V1.3  17-Apr-2014	BNaik IMS 188581: This data script would move the records from Im_receipt_item_posting to 
 *        Im_receipt_item_posting_stage if the invoice is posted. If the first invoice was posted then any subsequent invoice that 
 *        matches with remaining quantity of the receipt is not getting staged. When the 2nd invoice is posted it deleted from Posting table
 *        but did not insert into the Staging table.
 * 	
*/
public class ImReceiptItemPostingStageAccessExt extends ImReceiptItemPostingStageAccess {
	   /*  private static final String INSERT_POSTED_RECORDS = "INSERT INTO IM_RECEIPT_ITEM_POSTING_STAGE"
    + " (SEQ_NO, RECEIPT_ID, ITEM_ID, QTY_POSTED, CREATE_DATE)"
    + " SELECT  SEQ_NO, RECEIPT_ID, ITEM_ID, QTY_POSTED, ?"
    + " FROM IM_RECEIPT_ITEM_POSTING WHERE QTY_POSTED IS NOT NULL"
    + " AND SEQ_NO NOT IN (SELECT SEQ_NO FROM IM_RECEIPT_ITEM_POSTING_STAGE)"
    + "	AND (RECEIPT_ID,ITEM_ID)  NOT IN ( SELECT A.RECEIPT_ID,A.ITEM_ID "
    + " FROM ( SELECT ISTG.RECEIPT_ID, ISTG.ITEM_ID, SUM(ISTG.QTY_POSTED) SUMMED_QTY "
    + " FROM IM_RECEIPT_ITEM_POSTING_STAGE ISTG, v_im_shipsku SK WHERE "
    + " SK.SHIPMENT = ISTG.RECEIPT_ID AND SK.ITEM = ISTG.ITEM_ID "
    + " GROUP BY ISTG.RECEIPT_ID, ISTG.ITEM_ID) A, v_im_shipsku SS "
    + " WHERE SS.SHIPMENT = A.RECEIPT_ID AND SS.ITEM = A.ITEM_ID AND "
    + " SS.QTY_RECEIVED = A.SUMMED_QTY )"; */


private static final String INSERT_POSTED_RECORDS = "INSERT INTO IM_RECEIPT_ITEM_POSTING_STAGE"
    + " (SEQ_NO, RECEIPT_ID, ITEM_ID, QTY_POSTED, CREATE_DATE)  SELECT /*+ index( b, PK_IM_RECEIPT_ITEM_POSTING) */ \n" + 
    "          b.seq_no, b.receipt_id, b.item_id, b.qty_posted, ?  \n" + 
    "     FROM im_receipt_item_posting b\n" + 
    "    WHERE b.qty_posted IS NOT NULL\n" + 
    "      AND NOT EXISTS (SELECT /*+ dynamic_sampling(c,6) nl_aj */ 1 \n" + 
    "                           FROM im_receipt_item_posting_stage c\n" + 
    "                            where b.seq_no = c.seq_no )\n" + 
    "      AND NOT EXISTS ( \n" + 
    "             SELECT   1\n" + 
    "               FROM (SELECT  /*+ dynamic_sampling(istg,6) */ istg.receipt_id, istg.item_id,\n" + 
    "                              SUM (istg.qty_posted) summed_qty\n" + 
    "                         FROM im_receipt_item_posting_stage istg,\n" + 
    "                              v_im_shipsku sk\n" + 
    "                        WHERE sk.shipment = istg.receipt_id\n" + 
    "                          AND sk.item = istg.item_id\n" + 
    "                     GROUP BY istg.receipt_id, istg.item_id) a,\n" + 
    "                    v_im_shipsku ss\n" + 
    "              WHERE ss.shipment = a.receipt_id\n" + 
    "                AND ss.item = a.item_id\n" + 
    "                AND ss.qty_received = a.summed_qty\n" + 
    "                AND b.receipt_id = a.receipt_id\n" + 
    "                AND b.item_id = a.item_id )" ;  // BRN V1.3 updated

    /**
     * insert This method selects all posted receipt items and adds them to the receip item staging
     * table.
     * 
     * @param vdate
     * @throws ReIMException
     */
    public void insert(ReIMDate vdate) throws ReIMException {
        OraclePreparedStatement stmt = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn
                    .prepareStatement(ImReceiptItemPostingStageAccessExt.INSERT_POSTED_RECORDS);
            stmt.setDate(1, vdate.getSQL_Date());
            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new ReIMException("error.cannot_insert_receipt_item_posting_stage",
                    Severity.ERROR, ex, this);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception ex) {
                throw new ReIMException("error.cannot_insert_receipt_item_posting_stage",
                        Severity.ERROR, ex, this);
            }
        }
    }
}
