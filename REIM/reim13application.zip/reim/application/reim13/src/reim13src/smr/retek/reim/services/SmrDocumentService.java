package smr.retek.reim.services;

import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.ReimProperties;
import oracle.retail.reim.utils.Severity;
import smr.retek.reim.db.SmrImDocHeadAccessExt;

import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.document.DocumentItemInvoice;
import com.retek.reim.db.IImResolutionActionAccessExt;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.db.ImResolutionActionAccessExt;
import com.retek.reim.db.ImResolutionActionRow;
import com.retek.reim.merch.utils.ReIMException;

/**
 * @see oracle.retail.reim.services.impl.DocumentService
 */
public class SmrDocumentService {
	
    public static ImDocHeadRow getDocumentByVendor(String vendorType, String vendorId, String extDocId)
            throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();

            SmrImDocHeadAccessExt access = new SmrImDocHeadAccessExt();
            return access.readDocByVendor(vendorType, vendorId, extDocId);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.DocumentService.unknown_ext_doc_id_by_vendor",
                    Severity.ERROR, ex, SmrDocumentService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

//    public String validUpc(String upc, Long upcSupplement) throws ReIMException {

	 public static String validUpc(String upc, Long upcSupplement)
	         throws ReIMException {
	     try {
	         TransactionManagerFactory.getInstance().start();
	
	         SmrImDocHeadAccessExt access = new SmrImDocHeadAccessExt();
	         return access.validUpc(upc, upcSupplement);
	     } catch (ReIMException e) {
	         throw (e);
	     } catch (Exception ex) {
	         throw new ReIMException("error.DocumentService.unknown_ext_doc_id_by_vendor",
	                 Severity.ERROR, ex, SmrDocumentService.class);
	     } finally {
	         TransactionManagerFactory.getInstance().end();
	     }
	 }
 
	 /*
	  * BRN SplitReceipt Fix - we need to insert records in IM_RESOLUTION_ACTION for item "split receipt detail match"
	  * Because if the item is split receipt from the Quantity Variance Resolution screen then record is 
	  * created in IM_RESOLUTION_ACTION
	  */
	 public void persistResolutionForSplitReceipt(ReceiptItem receiptItem, DocumentItemInvoice invoiceItem) throws ReIMException {
	    
		 try{
				TransactionManagerFactory.getInstance().start();
				IImResolutionActionAccessExt resolutionActionAccessExt;
				double excessQty;
				
				if(receiptItem.isPartiallyMatched())
					excessQty = receiptItem.getQtyMatched() - receiptItem.getAvailableToMatchQty();
				else
					excessQty = receiptItem.getQtyMatched();
				
				
				if(excessQty > 0){
					
					resolutionActionAccessExt = new ImResolutionActionAccessExt(); 
					ImResolutionActionRow imResolutionActionRow = new ImResolutionActionRow(invoiceItem.getDocId(), invoiceItem.getItemId(), 
							ReimProperties.SPLIT_RECEIPT_REASON_CODE, ReasonCode.SPLIT_RECEIPT, excessQty,  Double.MIN_VALUE,
							Double.MIN_VALUE, Resolution.UNROLLED, Long.parseLong(receiptItem.getReceiptId()));
								 	
				 	resolutionActionAccessExt.create(imResolutionActionRow);				
				}				
		 	
	        } catch (ReIMException e) {
	            TransactionManagerFactory.getInstance().rollback();
	            throw e;
	        } catch (Exception e) {
	            TransactionManagerFactory.getInstance().rollback();
	            throw new ReIMException("error.cannot_persist_matched_groups", Severity.ERROR, e,
	            		SmrDocumentService.class);
	        } finally {
	            TransactionManagerFactory.getInstance().end();
	        }

	 }
	 
     public static String getReceiptDates(Long orderNumber) {
    	return null;
     }

}
