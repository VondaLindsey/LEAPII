package smr.retek.reim.ui.ediRejectDocList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import smr.retek.reim.services.SmrServiceFactory;

import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;

public class SmrEdiRejectMassCorrectionDeleteAction extends ReIMSecureAction {
	
    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm actionForm,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        SmrEdiRejectMassCorrectionForm form = (SmrEdiRejectMassCorrectionForm) actionForm;
        try {
     
        	if (form.getOperationRadio().equals(SmrEdiRejectMassCorrectionForm.OPERATION_DELETE)) {
        		if (!SmrServiceFactory.getSmrEdiRejectService().massDeleteRejects(form.getSupplierLOV(), form.getPoLOV(), form.getInvoiceLOV(), ReIMUserContext.getUsername())) {
        			saveErrors(request, errors, "alert.unable_to_delete");
        			return mapping.findForward("self");
        		}
        	}
            return mapping.findForward("success");
        }

        catch (ReIMException e) {
            saveErrors(request, errors, e);
            return (mapping.findForward("failure"));
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.EdiRejectMassCorrectionDeleteAction_doPerform", Severity.ERROR, e,
                    this);
            saveErrors(request, errors, exception);
            return (mapping.findForward("failure"));
        }
    }
    
}
