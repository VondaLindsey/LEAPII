package smr.retek.reim.business;

import com.retek.reim.business.EdiRejectReasons;

public class SmrEdiRejectReasons extends EdiRejectReasons {
    public static final String HELD = "HELD";
    
    public static final String ERROR_COLUMN_NONE = "NONE";
    
    /* SMR OLR ENH31 Inserted - START */
    public static final String ERROR_PO = "10";
    public static final String ERROR_TERM_CODE = "11";
    public static final String ERROR_INV_NO = "12";
    public static final String ERROR_INV_DATE = "13";
    public static final String ERROR_SHIP_DATE = "14";
    public static final String ERROR_VENDOR_DIFF = "15";
    public static final String ERROR_TOT_NOT_EQU_EXT = "16"; //
    public static final String ERROR_TOT_AMT_ZERO = "17";
    public static final String ERROR_STORE = "18"; //
    public static final String ERROR_SKU = "19"; //
    public static final String ERROR_UPC = "20"; //

    public static final String ERROR_VENDOR_ID = "21";
    public static final String ERROR_TRAN_NO = "22";
    public static final String ERROR_DOC_TYPE = "23";
    public static final String ERROR_VENDOR_DOC_NO_NULL = "24";
    public static final String ERROR_VENDOR_DOC_NO_ZERO = "25";
    public static final String ERROR_VENDOR_DOC_NO = "26";
    public static final String ERROR_GROUP = "27";
    public static final String ERROR_VENDOR_TYPE = "28";
    public static final String ERROR_VENDOR_DOC_DATE = "29";
    public static final String ERROR_LOC = "30";

    public static final String ERROR_LOC_TYPE = "31";
    public static final String ERROR_DUE_DATE = "32";
    public static final String ERROR_CUR_CODE = "33";
    public static final String ERROR_EXCH_RATE = "34";
    public static final String ERROR_TOT_COST = "35";
    public static final String ERROR_TOT_COST_ZERO = "36";
    public static final String ERROR_TOT_COSTSIGN = "37";
    public static final String ERROR_TOT_TAX_AMT = "38";
    public static final String ERROR_TOT_TAXAMT_IND = "39";
    public static final String ERROR_TOT_QTY = "40";

    public static final String ERROR_TOT_QTY_IND = "41";    
    public static final String ERROR_TOT_DISC = "42";
    public static final String ERROR_TOT_DISC_IND = "43";
    public static final String ERROR_PAID_IND = "44";
    public static final String ERROR_MULTI_LOC_IND = "45"; //
    public static final String ERROR_DEAL_ID = "46";
    public static final String ERROR_RTV_IND = "47";
    public static final String ERROR_CROSS_REF_NO = "48";
    public static final String ERROR_NO_DOC_HEAD = "49";
    public static final String ERROR_MERCH_TYPE_RTV = "50";
    
    public static final String ERROR_VENDOR_NOT_SUPP = "51";
    public static final String ERROR_ORDER_NULL = "52";
    public static final String ERROR_DUP_ORDER_RTV = "53";
    public static final String ERROR_DUE_DATE_NULL = "54";
    public static final String ERROR_CURR_CODE = "55";
    public static final String ERROR_CURR_NOT_MATCH = "56";
    public static final String ERROR_FREIGHT_TYPE = "57";
    public static final String ERROR_MULTI_LOC_Y = "58";
    public static final String ERROR_MERCH_TYPE = "59";
    public static final String ERROR_DETAIL_REQUIRED = "60";
    
    public static final String ERROR_COST_MATCH_THEAD = "61";
    public static final String ERROR_TOT_QTY_WHOLE = "62";
    public static final String ERROR_TOT_QTY_NOT_MATCH = "63";
    public static final String ERROR_EXT_DOC_ID_EXIST = "64";
    public static final String ERROR_INV_LEL_SDC = "65";
    public static final String ERROR_INV_LEL_ST = "66";
    public static final String ERROR_RTV_SUPP_EXIST = "67";
    public static final String ERROR_ORD_LOC_EXIST = "68";
    public static final String ERROR_HD_TAX_AMT_NOT_MATCH = "69";
    public static final String ERROR_TOT_TAX_AMT_NOT_MATCH = "70";
    
    public static final String ERROR_DUP_VPN = "71";
    public static final String ERROR_PRI_REJ_FILE = "72";
    public static final String ERROR_NON_MERCH_REC = "73";
    public static final String ERROR_NEG_TOT_COST = "74";
    public static final String ERROR_NON_MERCH_NO_TDETL = "75";
    public static final String ERROR_CRD_NOT_ASSO = "76";
    public static final String ERROR_NEG_CRD_NOT_DOC = "77";
    public static final String ERROR_ZERO_CRD_NOT_DOC = "78";
    public static final String ERROR_DET_MEMO_NEG = "79";
    public static final String ERROR_NO_TAX_DETL = "80";
    
    public static final String ERROR_NON_MERCH_TAX_CODE = "81";
    public static final String ERROR_TAX_CODE = "82";
    public static final String ERROR_TAX_MATCH_SYS = "83";
    public static final String ERROR_ALLO_TAX_CODE = "84";
    
    public static final String ERROR_DUP_INVOICE = "85";
    public static final String ERROR_DUP_ITEM = "86";
    public static final String INVALID_ORDER_NO_FOR_SUPPLIER = "87";
    public static final String INVALID_ORDER_NO_FOR_LOCATION = "88";
    public static final String ERROR_VENDOR_DOC_DUP = "89";
    
    public static final String ERROR_NO_ERROR = "99";
    /* SMR OLR ENH31 Inserted - END */

}
