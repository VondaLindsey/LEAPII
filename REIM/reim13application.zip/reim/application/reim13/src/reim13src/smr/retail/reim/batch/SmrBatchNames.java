package smr.retail.reim.batch;

/**
 * This is a constant class used to hold the names of the batch jobs for bean lookup and command
 * line validation.
 * 
 * @author OLR
 * 
 */
public final class SmrBatchNames {
	public static final String SMRAUTORESOLVE = "SmrAutoResolveBatch";
	public static final String SMREDIUPLOAD = "SmrEdiUploadBatch";
    
    private SmrBatchNames() {
    }
}
