package smr.retek.reim.data.dao;

import java.util.Map;

import smr.retek.reim.business.SmrAutoResolutionCandidate;

public interface ISmrAutoResolutionDao {

	Map<String, SmrAutoResolutionCandidate> getAutoResolutionCandidates();
}
