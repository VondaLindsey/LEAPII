package smr.retail.reim.data.dao;

import java.util.List;

import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;

import com.retek.reim.batch.ediupinv.EdiTransactionHeader;

public interface ISmrEdiRejectDocumentDao {

	public List<EdiTransactionHeader> readByDocuments(String[] documentIdList);
	
	public void insertSmrEdiRejectRecord(SmrEdiReportRecord smrEdiRejectRecord); // SMR OLR ENH31 Inserted
	
}
