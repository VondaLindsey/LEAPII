package smr.retail.reim.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retek.reim.merch.utils.ReIMException;

import smr.retail.reim.data.dao.ISmrCostResDao;
import smr.retail.reim.services.ISmrCostResService;

@Service
public class SmrCostResService implements ISmrCostResService {
	
	ISmrCostResDao smrCostResDao;
	
	@Autowired
	public void setSmrCostResDao(ISmrCostResDao smrCostResDao) {
		this.smrCostResDao = smrCostResDao;
	}

	public boolean isRcaAllowed(long orderNo, long location, String item, double unitCost)
			throws ReIMException {
		return smrCostResDao.isRcaAllowed(orderNo, location, item, unitCost);
	}

}
