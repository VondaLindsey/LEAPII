package smr.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.business.Supplier;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.Order;
import com.retek.reim.business.Term;
import com.retek.reim.business.EdiRejectDocument;
import com.retek.reim.business.document.Document;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.OrderService;

public class SmrImEDIRejectDocHeadAccessExt {

	public static Order[] selectDistinctOrders(String supplier, String orderNo, String invoiceId) throws ReIMException {
	    OraclePreparedStatement stmt = null;
	    ResultSet rs = null;
	    try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
			StringBuffer query = new StringBuffer("SELECT DISTINCT DH.ORDER_NO, O.SUPPLIER, SS.SUP_NAME FROM IM_EDI_REJECT_DOC_HEAD DH, ORDHEAD O, SUPS SS WHERE DH.VENDOR_TYPE = 'SUPP' AND O.ORDER_NO = DH.ORDER_NO AND SS.SUPPLIER = O.SUPPLIER");
			if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
	        stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
	        rs = stmt.executeQuery();
	        ArrayList<Order> orderList = new ArrayList<Order>();
	        Order order;
	        while (rs.next()) {
	        	com.retek.reim.business.vendor.Supplier supp = new com.retek.reim.business.vendor.Supplier(rs.getString("SUPPLIER"));
	        	supp.setVendorName(rs.getString("SUP_NAME"));
	            order = new Order(rs.getString("ORDER_NO"), supp);
	            orderList.add(order);
	        }
	        if (orderList.size() > 0) {
	            return (Order[]) orderList.toArray(new Order[orderList.size()]);
	        } else {
	            return null;
	        }
	    } catch (Exception exception) {
	        throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	
	            if (stmt != null) {
	                stmt.close();
	            }
	        } catch (SQLException exception) {
	            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	        }
	    }
	}

	
	public static Term[] selectDistinctTerms(String supplier, String orderNo, String invoiceId, String termsId) throws ReIMException {
	    OraclePreparedStatement stmt = null;
	    ResultSet rs = null;
	    try {
	        Connection conn = TransactionManagerFactory.getInstance().getConnection();
			StringBuffer query = new StringBuffer("SELECT DISTINCT T.TERMS, T.TERMS_CODE, T.TERMS_DESC FROM TERMS T, IM_EDI_REJECT_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP' AND T.TERMS = DH.TERMS");
			if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
			if (termsId != null && !termsId.equals("")) query.append("   AND DH.TERMS = ?");
	        stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
			if (termsId != null && !termsId.equals("")) stmt.setString(ind++,termsId);
			
			rs = stmt.executeQuery();
	        ArrayList<Term> termsList = new ArrayList<Term>();
	        Term term;
	        while (rs.next()) {
	            term = new Term(rs.getString("TERMS_CODE"));
	            term.setTermId(rs.getString("TERMS"));
	            term.setTermDescription(rs.getString("TERMS_DESC"));
	            termsList.add(term);
	        }
	        if (termsList.size() > 0) {
	            return (Term[]) termsList.toArray(new Term[termsList.size()]);
	        } else {
	            return null;
	        }
	    } catch (Exception exception) {
	        throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	
	            if (stmt != null) {
	                stmt.close();
	            }
	        } catch (SQLException exception) {
	            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	        }
	    }
	}


    public static Supplier[] selectDistinctSupplierSitesFilter(String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException {
    	OraclePreparedStatement stmt = null;
    	ResultSet rs = null;
    	try {
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
    		StringBuffer query1 = new StringBuffer("SELECT SS.SUPPLIER, SS.SUP_NAME FROM SUPS SS, IM_EDI_REJECT_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP' AND SS.SUPPLIER = DH.VENDOR AND SS.SUPPLIER_PARENT IS NOT NULL");
    		StringBuffer query2 = new StringBuffer(" UNION SELECT SS.SUPPLIER, SS.SUP_NAME FROM SUPS SS, IM_EDI_REJECT_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP' AND SS.SUPPLIER_PARENT = DH.VENDOR");
    		int offset = 0;
    		if (supplierSiteIdFromUser != null && !supplierSiteIdFromUser.equals("")) {
    			query1.append("   AND DH.VENDOR = ?");
    			query2.append("   AND DH.VENDOR = ?");
    			offset++;
    		}
    		if (orderNo != null && !orderNo.equals("")) {
    			query1.append("   AND DH.ORDER_NO = ?");
    			query2.append("   AND DH.ORDER_NO = ?");
    			offset++;
    		}
    		if (invoiceId != null && !invoiceId.equals("")) {
    			query1.append("   AND DH.EXT_DOC_ID = ?");
    			query2.append("   AND DH.EXT_DOC_ID = ?");
    			offset++;
    		}
    		stmt = (OraclePreparedStatement) conn.prepareStatement(query1.toString() + query2.toString());
    		int ind = 1;
    		if (supplierSiteIdFromUser != null && !supplierSiteIdFromUser.equals("")) {
    			stmt.setString(ind, supplierSiteIdFromUser);
    			stmt.setString(offset + ind++, supplierSiteIdFromUser);
    		}
    		if (orderNo != null && !orderNo.equals("")) {
    			stmt.setString(ind, orderNo);
    			stmt.setString(offset + ind++, orderNo);
    		}
    		if (invoiceId != null && !invoiceId.equals("")) {
    			stmt.setString(ind, invoiceId);
    			stmt.setString(offset + ind++, invoiceId);
    		}
    		rs = stmt.executeQuery();
    		ArrayList<Supplier> supplierList = new ArrayList<Supplier>();
    		Supplier supplier;
    		while (rs.next()) {
    			supplier = new Supplier(new Long(rs.getString("SUPPLIER")));
    			supplier.setVendorName(rs.getString("SUP_NAME"));
    			supplierList.add(supplier);
    		}
    		if (supplierList.size() > 0) {
    			return (Supplier[]) supplierList.toArray(new Supplier[supplierList.size()]);
    		} else {
    			return null;
    		}
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    	} finally {
    		try {
    			if (rs != null) {
    				rs.close();
    			}

    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    		}
    	}
    }

	
    public static Supplier[] selectDistinctSupplierSites(String supplierId, String orderNo, String invoiceId) throws ReIMException {
    	// supplierId can be either a supplier or a supplierSite
    	// It can come from the filter LOV, or could be typed in by the user as OldSupplierId.
    	// If both are provided, and they do not match, we can not even get here.
    	// If supplierId is null, none of them was provided.
    	OraclePreparedStatement stmt = null;
    	ResultSet rs = null;
    	try {
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
    		// Called from the oldSupplierSiteId LOV. We can ignore supplierSiteIdFromUser because it is either empty, or the same as supplierSiteIdFromFilter
    		// Also, supplierSiteIdFromFilter is always a supplierSiteId
    		StringBuffer query = new StringBuffer("SELECT DISTINCT SS.SUPPLIER, SS.SUP_NAME FROM SUPS SS, IM_EDI_REJECT_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP' AND DH.VENDOR = SS.SUPPLIER");
    		if (supplierId != null && !supplierId.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
    		if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
    		if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
    		stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
    		int ind = 1;
    		if (supplierId != null && !supplierId.equals("")) {
    			stmt.setString(ind++, supplierId);
    			stmt.setString(ind++, supplierId);
    		}
    		if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
    		if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
    		rs = stmt.executeQuery();
    		ArrayList<Supplier> supplierList = new ArrayList<Supplier>();
    		Supplier supplier;
    		while (rs.next()) {
    			supplier = new Supplier(new Long(rs.getString("SUPPLIER")));
    			supplier.setVendorName(rs.getString("SUP_NAME"));
    			supplierList.add(supplier);
    		}
    		if (supplierList.size() > 0) {
    			return (Supplier[]) supplierList.toArray(new Supplier[supplierList.size()]);
    		} else {
    			return null;
    		}
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    	} finally {
    		try {
    			if (rs != null) {
    				rs.close();
    			}

    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    		}
    	}
    }
	
	public static Document[] selectDistinctInvoices(String supplier, String orderNo, String invoiceId) throws ReIMException {
		OraclePreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			Connection conn = TransactionManagerFactory.getInstance().getConnection();
			StringBuffer query = new StringBuffer("SELECT DISTINCT DH.EXT_DOC_ID, DH.ORDER_NO, trunc(doc_date) DOC_DATE FROM IM_EDI_REJECT_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP'");
			if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
			query.append( " ORDER BY DH.EXT_DOC_ID ASC");
			stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
			rs = stmt.executeQuery();
			ArrayList<Document> docList = new ArrayList<Document>();
			Document doc;
			while (rs.next()) {
				doc = new Document();
				doc.setExtDocId(rs.getString("EXT_DOC_ID"));
				doc.setOrderNo(rs.getString("ORDER_NO"));
				doc.setDocDate(new ReIMDate(rs.getDate("DOC_DATE")));

				docList.add(doc);
			}
			if (docList.size() > 0) {
				return (Document[]) docList.toArray(new Document[docList.size()]);
			} else {
				return null;
			}
		} catch (Exception exception) {
			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stmt != null) {
					stmt.close();
				}
			} catch (SQLException exception) {
				throw new ReIMException("error.sql_error", Severity.ERROR, exception);
			}
		}
	}

    public static Document[] selectToDistinctInvoices(String supplier, String orderNo, String invoiceId, String invoiceIdToFilter) throws ReIMException {
            OraclePreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                    Connection conn = TransactionManagerFactory.getInstance().getConnection();
                    StringBuffer query = new StringBuffer("SELECT DISTINCT DH.EXT_DOC_ID, DH.ORDER_NO, trunc(doc_date) DOC_DATE FROM IM_EDI_REJECT_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP'");
                    if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
                    if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
                    if (invoiceIdToFilter != null && !invoiceIdToFilter.equals("")) query.append("   AND DH.EXT_DOC_ID > ?");
                    query.append( " ORDER BY DH.EXT_DOC_ID ASC");
                    stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
                    int ind = 1;
                    if (supplier != null && !supplier.equals("")) {
                            stmt.setString(ind++, supplier);
                            stmt.setString(ind++, supplier);
                    }
                    if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
                    if (invoiceIdToFilter != null && !invoiceIdToFilter.equals("")) stmt.setString(ind++, invoiceIdToFilter);
                    rs = stmt.executeQuery();
                    ArrayList<Document> docList = new ArrayList<Document>();
                    Document doc;
                    while (rs.next()) {
                            doc = new Document();
                            doc.setExtDocId(rs.getString("EXT_DOC_ID"));
                            doc.setOrderNo(rs.getString("ORDER_NO"));

                            docList.add(doc);
                    }
                    if (docList.size() > 0) {
                            return (Document[]) docList.toArray(new Document[docList.size()]);
                    } else {
                            return null;
                    }
            } catch (Exception exception) {
                    throw new ReIMException("error.sql_error", Severity.ERROR, exception);
            } finally {
                    try {
                            if (rs != null) {
                                    rs.close();
                            }

                            if (stmt != null) {
                                    stmt.close();
                            }
                    } catch (SQLException exception) {
                            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
                    }
            }
    }
    
    public static String[] getDocIds(String supplier, String orderNo, String invoiceId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            StringBuffer query = new StringBuffer("SELECT DISTINCT DOC_ID FROM IM_EDI_REJECT_DOC_HEAD WHERE VENDOR_TYPE = 'SUPP'");
			if (supplier != null && !supplier.equals("")) query.append("   AND VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND EXT_DOC_ID = ?");
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
            rs = stmt.executeQuery();
            ArrayList list = new ArrayList();
            String docId = null;
            while (rs.next()) {
                docId = new String();
                docId = rs.getString(1);
                list.add(docId);
            }
            if (list.size() > 0) {
                return (String[]) list.toArray(new String[list.size()]);
            } else {
                return null;
            }
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variables: supplierId: " + supplier + ", orderNo: " + orderNo + ", invoiceId: " + invoiceId;
            throw new ReIMException("error.sql_error", Severity.ERROR, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex);
            }
        }
    }

    public void replace(String supplier, String orderNo, String invoiceId, String oldDueDate, String newDueDate, String oldSupplierId, String newSupplierId,
    		String oldInvoiceId, String newInvoiceId, String appendInvoice, String oldTermsId, String newTermsId, String oldOrderNo, 
                String newOrderNo, String newDocDate)
    throws ReIMException {
    	OraclePreparedStatement stmt = null;
    	try {
               // Anil Potukuchi
               // Scenario 1 when the user enters PO and the append value then
               // update EVERY invoice for a specific PO
               // append the ext_doc_id with the value passed in 
               
                // Scenario 2 when the user enters PO and the append value 
                // and also enter invoice from and invoice to fields then
                // update EVERY invoice for a specific PO
                // append the ext_doc_id's with the value passed in plus append the  
                 
                Connection conn = TransactionManagerFactory.getInstance().getConnection();
    	        StringBuffer query = new StringBuffer("");
                
                if ( supplier.length() == 0 && orderNo != null && invoiceId.length() == 0 && oldDueDate.length() == 0  && newDueDate.length() == 0
                        && oldSupplierId.length() == 0 && newSupplierId == null && oldInvoiceId.length() == 0 && newInvoiceId == null && appendInvoice != null
                        && oldTermsId.length() == 0  && newTermsId == null && oldOrderNo.length() == 0 &&  newOrderNo == null) {
                        query.append("UPDATE IM_EDI_REJECT_DOC_HEAD SET UPDATE_ID = ? ");
                        query.append(" , EXT_DOC_ID = EXT_DOC_ID || ?  ");
                        query.append(" WHERE VENDOR_TYPE = 'SUPP' ");
                        query.append("  AND ORDER_NO = ? ");
                        stmt = (OraclePreparedStatement) conn.prepareStatement( query.toString());
                        stmt.setString(1, ReIMUserContext.getUsername());
                        stmt.setString(2, appendInvoice );  
                        stmt.setString(3, orderNo );  
                      
                  } else if ( supplier.length() == 0 && orderNo != null && invoiceId.length() ==0  && oldDueDate.length() == 0 && newDueDate.length() == 0
                        && oldSupplierId.length() == 0 && newSupplierId == null && oldInvoiceId != null && newInvoiceId != null && appendInvoice != null
                        && oldTermsId.length() == 0 && newTermsId == null && oldOrderNo.length() == 0 &&  newOrderNo == null) {
                      query.append("UPDATE IM_EDI_REJECT_DOC_HEAD SET UPDATE_ID = ? ");
                      query.append(" ,EXT_DOC_ID = EXT_DOC_ID || ?  ");
                      query.append(" WHERE VENDOR_TYPE = 'SUPP' ");
                      query.append("  AND ORDER_NO = ? ");
                      query.append("  AND EXT_DOC_ID >= ? ");
                      query.append("  AND EXT_DOC_ID <= ? ");
                      stmt = (OraclePreparedStatement) conn.prepareStatement( query.toString());
                      stmt.setString(1, ReIMUserContext.getUsername());
                      stmt.setString(2, appendInvoice );
                      stmt.setString(3, orderNo );
                      stmt.setString(4, oldInvoiceId );  
                      stmt.setString(5, newInvoiceId );  
                  
                   } else {
                
               
  
    		StringBuffer updHead = new StringBuffer("UPDATE IM_EDI_REJECT_DOC_HEAD SET UPDATE_ID = ?");
    		StringBuffer upd = new StringBuffer("");
    		StringBuffer where = new StringBuffer(" WHERE VENDOR_TYPE = 'SUPP'");
    		int updInd = 0;

			if (oldDueDate != null && !oldDueDate.equals("") && newDueDate != null && !newDueDate.equals("")) {
				upd.append(", DUE_DATE = ?");
				updInd++;
				where.append("  AND DUE_DATE = ?");
			}
            if (appendInvoice != null && appendInvoice.length() != 0 ) {
                 upd.append(", EXT_DOC_ID  = EXT_DOC_ID || ? ");
                 updInd++;
                         
            }
            if (newDocDate != null && newDocDate.length() != 0 ) {
                upd.append(", DOC_DATE  =  ? ");
                updInd++;
            }

			if (oldSupplierId != null && !oldSupplierId.equals("") && newSupplierId != null && !newSupplierId.equals("")) {
				upd.append(", VENDOR = ?");
				updInd++;
				where.append("  AND VENDOR = ?");
			}
			if (oldInvoiceId != null && !oldInvoiceId.equals("") && newInvoiceId != null && !newInvoiceId.equals("")) {
				upd.append(", EXT_DOC_ID = ?");
				updInd++;
				where.append("  AND EXT_DOC_ID = ?");
			}
                        
  			if (oldTermsId != null && !oldTermsId.equals("") && newTermsId != null && !newTermsId.equals("")) {
				upd.append(", TERMS = ?");
				updInd++;
				where.append("  AND TERMS = ?");
			}

			if (oldOrderNo != null && !oldOrderNo.equals("") && newOrderNo != null && !newOrderNo.equals("")) {
				upd.append(", ORDER_NO = ?");
				updInd++;
				where.append("  AND ORDER_NO = ?");
			}
			
			if (updInd == 0) return; // None of the fields would get updated, just get out, job done
			
			if (supplier != null && !supplier.equals("")) where.append("  AND VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) where.append("  AND ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) where.append("  AND EXT_DOC_ID = ?");
			
		    stmt = (OraclePreparedStatement) conn.prepareStatement(updHead.toString() + upd.toString() + where.toString());
			int ind = 1;

			stmt.setString(ind, ReIMUserContext.getUsername());
			
			if (oldDueDate != null && !oldDueDate.equals("") && newDueDate != null && !newDueDate.equals("")) {
				stmt.setString(updInd + ind++, oldDueDate);
				stmt.setString(updInd + ind++, newDueDate);
				
			}
             if (appendInvoice != null && appendInvoice.length() != 0 ) {
                 stmt.setString(updInd + ind++, appendInvoice);
                 stmt.setString(ind, appendInvoice);
             }
             if ( newDocDate != null &&!newDocDate.equals("") ) {
                     stmt.setString(updInd + ind++, newDocDate);
                     stmt.setDate(updInd + ind++, new ReIMDate(newDocDate).getSQL_Date() );
             }
            
			if (oldSupplierId != null && !oldSupplierId.equals("") && newSupplierId != null && !newSupplierId.equals("")) {
				stmt.setString(updInd + ind++, oldSupplierId);
				stmt.setString(updInd + ind++, newSupplierId);
			}

			if (oldInvoiceId != null && !oldInvoiceId.equals("") && newInvoiceId != null && !newInvoiceId.equals("")) {
				
				stmt.setString(updInd + ind++, oldInvoiceId);
				stmt.setString(updInd + ind++, newInvoiceId + appendInvoice);
			}

			if (oldTermsId != null && !oldTermsId.equals("") && newTermsId != null && !newTermsId.equals("")) {
				
				stmt.setString(updInd + ind++, oldTermsId);
				stmt.setString(updInd + ind++, newTermsId);
			}

			if (oldOrderNo != null && !oldOrderNo.equals("") && newOrderNo != null && !newOrderNo.equals("")) {
				
				stmt.setString(updInd + ind++, oldOrderNo);
				stmt.setString(updInd + ind++, newOrderNo);
			}

			if (supplier != null && !supplier.equals("")) {
				stmt.setString(updInd + ind++, supplier);
				stmt.setString(updInd + ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals(""))  {
              //  stmt.setString(ind++, orderNo);
                  stmt.setString(updInd + ind++, orderNo);
            }
//			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(updInd + ind++, invoiceId);
			if (invoiceId != null && !invoiceId.equals("")) {
                stmt.setString(updInd + ind++, invoiceId);
//                 ind++;
//                   stmt.setString(ind, invoiceId) ;
            }
           }// end of else
                
    		stmt.executeUpdate();
                
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    	} finally {
    		try {
    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    		}
    	}
    }
     
  // Anil P
  // to validate true duplicates
   public static boolean checkTrueDuplicates(String extDocId, String orderNo, Double totalCost, String vendor) throws ReIMException {
       OraclePreparedStatement stmt = null;
       ResultSet rs = null;
       try {
           Connection conn = TransactionManagerFactory.getInstance().getConnection();
                   StringBuffer query = new StringBuffer("select 'x'\n" + 
                   "   from im_doc_head\n" + 
                   " where TRIM(EXT_DOC_ID) = ? \n" + 
                   "   and ORDER_NO = ? \n" + 
                   "   and status != 'DELETE' \n" + 
                   "   and ( supplier_site_id = ? " +
                   "          or vendor = ? )\n" + 
                   "   and TOTAL_COST = ? " ); 
//                   " UNION   select 'x'\n" + 
//                   "   from IM_EDI_REJECT_DOC_HEAD\n" + 
//                   " where EXT_DOC_ID = ? \n" + 
//                   "   and ORDER_NO = ? \n" + 
//                   "   and vendor = ? \n" + 
//                   "   and TOTAL_COST = ? " );
                   
           stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
           
           
           stmt.setString(1, extDocId);
           stmt.setInt(2, Integer.valueOf(orderNo));
           stmt.setInt(3, Integer.valueOf(vendor));
           stmt.setInt(4, Integer.valueOf(vendor));
           stmt.setDouble(5, totalCost);
           
//           stmt.setString(6, extDocId);
//           stmt.setInt(7, Integer.valueOf(orderNo));
//           stmt.setInt(8, Integer.valueOf(vendor));
//          stmt.setDouble(9, totalCost);
  
           rs = stmt.executeQuery();

           if (rs.next()) {
                return true;
            } else {
                return false;
            }
 
       } catch (Exception exception) {
           throw new ReIMException("error.sql_error", Severity.ERROR, exception);
       } finally {
           try {
               if (rs != null) {
                   rs.close();
               }
   
               if (stmt != null) {
                   stmt.close();
               }
           } catch (SQLException exception) {
               throw new ReIMException("error.sql_error", Severity.ERROR, exception);
           }
       }
   }
   
      public static boolean validateOrder ( String orderNo ) throws ReIMException {
             AOrderBean orderBean = (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);
             
             try {
                 TransactionManagerFactory.getInstance().start();
                 if (orderBean.selectSupplier(orderNo) == null) {
                     return false;
                 } else {
                     return true ;
                 }
         }
         catch (ReIMException e) {
                     throw (e);
                 } catch (Exception ex) {
                     throw new ReIMException("error.OrderService.unknown_validate_order",
                             Severity.ERROR, ex, OrderService.class);
                 } finally {
                     TransactionManagerFactory.getInstance().end();
                 }
     }
   
    public static boolean softDuplicates(String extDocId, String orderNo, Double totalCost, String vendor) throws ReIMException { 
   
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
                    StringBuffer query = new StringBuffer(" select order_no, total_cost\n" + 
                    "   from im_doc_head\n" + 
                    " where TRIM(EXT_DOC_ID) = ? \n" + 
                    "   and status != 'DELETE' \n" + 
                    "   and ( supplier_site_id = ? " +
                    "          or vendor = ? )\n" ); 
//                    "union\n" + 
//                    "select order_no, total_cost\n" + 
//                    "   from IM_EDI_REJECT_DOC_HEAD\n" + 
//                    " where EXT_DOC_ID = ? \n" + 
//                    "   and vendor = ? ");
 
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            
            stmt.setString(1, extDocId);
            stmt.setInt(2, Integer.valueOf(vendor));
            stmt.setInt(3, Integer.valueOf(vendor));
            
//            stmt.setString(4, extDocId);
//            stmt.setInt(5, Integer.valueOf(vendor));
                    
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                
                    return false;
             }
            
            return true;
           
        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
    
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception);
            }
        }
    }  

    
}
