package smr.retek.reim.batch.ediupinv;

import com.retek.reim.batch.BatchUtils;
import com.retek.reim.merch.utils.ReIMDate;

// SMR OLR ENH31 Created
public class SmrEdiReportRecord {

    private String vendor;
    private String extDocId;
    private String batchId;
    private String errorCode;
    private String sku;
    private String upc;
    private ReIMDate upldTimeStamp;
    private double totalCost;
    private double totalQty;
    private boolean errorInd;
    
    public static final int LEN_VENDOR_ID = 20;
    public static final int LEN_EXT_DOC_ID = 20;
    public static final int BATCH_ID = 12;
    public static final int LEN_ERROR_CODE = 2;
    public static final int LEN_SKU = 25;
    public static final int LEN_UPC = 25;
    public static final int LEN_DATE = 14;
    public static final int LEN_COST = 20;
    public static final int LEN_QTY = 12;

    public static final boolean PAD = true;
    public static final boolean NOPAD = false;
    
    public SmrEdiReportRecord() {
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getExtDocId() {
        return extDocId;
    }

    public void setExtDocId(String extDocId) {
        this.extDocId = extDocId;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }
    
    public ReIMDate getUpldTimeStamp() {
        return upldTimeStamp;
    }
    
    public void setUpldTimeStamp(ReIMDate upldTimeStamp) {
        this.upldTimeStamp = upldTimeStamp;
    }
    
    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }
        
    public double getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(Double totalQty) {
        this.totalQty = totalQty;
    }
    
    public String createFlatRecord() {
        String record = "";

        record += BatchUtils.createFlatField(vendor, LEN_VENDOR_ID, NOPAD);
        record += BatchUtils.createFlatField(extDocId, LEN_EXT_DOC_ID, NOPAD);
        record += BatchUtils.createFlatField(batchId, BATCH_ID, NOPAD);
        record += BatchUtils.createFlatField(errorCode, LEN_ERROR_CODE, NOPAD);
        record += BatchUtils.createFlatField(sku, LEN_SKU, NOPAD);
        record += BatchUtils.createFlatField(upc, LEN_UPC, NOPAD);
        /*
        record += BatchUtils.createFlatField(upldTimeStamp.getBatchDateFormat(), LEN_DATE, PAD);
        record += BatchUtils.createFlatField(new Double(totalCost), LEN_COST, PAD);
        record += BatchUtils.createFlatField(new Double(totalQty), LEN_QTY, PAD);
        */

        return record;
    }

    public void setErrorInd(boolean errorInd) {
        this.errorInd = errorInd;
    }

    public boolean isErrorInd() {
        return errorInd;
    }
}
