package smr.retek.reim.ui.invoiceMaintenance;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.services.impl.EdiRejectService;
import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import smr.retail.reim.business.SmrMerchandiseDocument;
import smr.retek.reim.services.SmrServiceFactory;

import com.retek.reim.business.EdiDocumentValidationValues;
import com.retek.reim.business.UserRole;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;

public class SmrInvoiceMassCorrectionDeleteAction extends ReIMSecureAction {
	
	   protected boolean getPermission() {
	        if (ReIMUserContext.getUserRole().getInvoiceDelete().equalsIgnoreCase(UserRole.YES)) {
	            return true;
	        } else {
	            return false;
	        }
	    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm actionForm,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        SmrInvoiceMassCorrectionForm form = (SmrInvoiceMassCorrectionForm) actionForm;
        EdiDocumentValidationValues ediDocumentValidationValues = new EdiDocumentValidationValues();

        try {
      
        	SmrMerchandiseDocument smrMerchandiseDocument = mapBusinessObject(form);
        	
            // Implement the mass change and re-validate the affected rejected documents
            ediDocumentValidationValues = SmrServiceFactory.getSmrInvoiceMassCorrectionService().replaceElementAndRevalidate(smrMerchandiseDocument);
            
            if (ediDocumentValidationValues.getMessageCode() == EdiRejectService.UNABLE_TO_REPLACE_DOCUMENTS_LOCKED) {
                saveErrors(request, errors, "alert.unable_to_delete_documents_tables_locked");
                return mapping.findForward("self");
            } else if (ediDocumentValidationValues.getMessageCode() == EdiRejectService.NO_DOCUMENTS_WERE_AFFECTED) {
                saveErrors(request, errors, "alert.unable_to_delete_documents_none_affected");
                return mapping.findForward("self");
            } else {
                errors.add("alert.invoices_deleted",
                        new ActionError("alert.invoices_deleted", String.valueOf(ediDocumentValidationValues.getValidDocumentCount()) )  );
                saveErrors(request, errors);
                return mapping.findForward("success");
            }
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return (mapping.findForward("failure"));
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.SmrInvoiceMassCorrectionDeleteAction_doPerform", Severity.ERROR, e,
                    this);
            saveErrors(request, errors, exception);
            return (mapping.findForward("failure"));
        }
    }
    
 private SmrMerchandiseDocument mapBusinessObject(SmrInvoiceMassCorrectionForm form){
    	
    	SmrMerchandiseDocument smrMerchandiseDocument = new SmrMerchandiseDocument();
    	
    	smrMerchandiseDocument.setSupplierId(form.getSupplierLOV());
    	smrMerchandiseDocument.setOrderNo(form.getPoLOV());
    	smrMerchandiseDocument.setInvoiceId(form.getInvoiceLOV());
    	
    	smrMerchandiseDocument.setOldItem(form.getOldItemLOV());
    	smrMerchandiseDocument.setNewItem(form.getNewItemLOV());
    	smrMerchandiseDocument.setOldSupplierSiteId(form.getOldSupplierLOV());
    	smrMerchandiseDocument.setNewSupplierSiteId(form.getNewSupplierLOV());
    	
    	smrMerchandiseDocument.setFromInvoiceId(form.getOldInvoiceLOV());
    	smrMerchandiseDocument.setToInvoiceLOV(form.getToInvoiceLOV());
    	smrMerchandiseDocument.setAppendInvoice(form.getAppendInvoice());
    	
    	smrMerchandiseDocument.setOldTermsId(form.getOldTermsLOV());
    	smrMerchandiseDocument.setNewTermsId(form.getNewTermsLOV());
    	
    	smrMerchandiseDocument.setOldOrderNo(form.getOldPOLOV());
    	smrMerchandiseDocument.setNewOrderNo(form.getNewPOLOV());
    	
    	smrMerchandiseDocument.setOldInvoiceDate(form.getOldInvoiceDate());
    	smrMerchandiseDocument.setNewInvoiceDate(form.getNewInvoiceDate());
    	smrMerchandiseDocument.setOldDueDate(form.getOldDueDate());
    	smrMerchandiseDocument.setNewDueDate(form.getNewDueDate());

    	smrMerchandiseDocument.setOperationRadio(form.getOperationRadio());
    	smrMerchandiseDocument.setUserId(ReIMUserContext.getUsername());
    	
    	return smrMerchandiseDocument;
    	
    }
    
}
