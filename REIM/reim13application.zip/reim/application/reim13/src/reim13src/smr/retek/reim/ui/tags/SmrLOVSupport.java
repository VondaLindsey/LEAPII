package smr.retek.reim.ui.tags;

	/**
	 * Called by lov_popup.jsp to create the IKeyValue[] list by calling setters and the select
	 * function of the bean.  If a value is selected in the popup it modifies what is returned
	 * to the jsp.
	 */
import javax.servlet.http.HttpServletRequest;

import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;
import smr.retek.reim.services.SmrItemSupplierService;
import smr.retek.reim.services.SmrServiceFactory;

import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.ui.discrepancyResolution.PriceReviewListForm;
import com.retek.reim.ui.lov.IKeyValue;
import com.retek.reim.ui.tags.LOVSupport;

/**
 * This class is the main driver for new custom LOV popup dialogs. It is responsible for returning the valid values behind
 * each custom LOV type.
 * 
 * Version   Author      Ref     Description
 * 1.01      Simon Mann  ENH505  Modified previous custom class to add the new LOV smrReasonCode
 * 
 * @author Various
 *
 */
	public class SmrLOVSupport extends LOVSupport {
	    public static IKeyValue[] getList(boolean lookupOnly, HttpServletRequest request)
	            throws ReIMException {
	        IKeyValue[] list = null;
	        try {
	        	TransactionManagerFactory.getInstance().start();

	            String type = request.getParameter("type");
	            
	           
	            //EDI Invoice Mass Correction LOV values
	            if (type.equals("smrEdiInvoice")) {
	            	list = SmrLOVSupport.getSmrEdiOrderSupplierInvoice(lookupOnly,request);
	            }
	            else if (type.equals("smrToEdiInvoice")) { // Anil P added this code
	            	list = SmrLOVSupport.getSmrEdiOrderSupplierInvoice(lookupOnly,request);
	            }
	            else if (type.equals("smrEdiItems")) {
	            	list = SmrLOVSupport.getSmrEdiItems(lookupOnly,request);
	            }
	            else if (type.equals("smrItems")) {
	            	list = SmrLOVSupport.getSmrItems(lookupOnly,request);
	            }
	            else if (type.equals("smrEdiSupplierFilter")) {
	            	list = SmrLOVSupport.getSmrEdiSuppliersFilter(lookupOnly, request);
	            }
	            else if (type.equals("smrEdiSupplier")) {
	            	list = SmrLOVSupport.getSmrEdiSuppliers(lookupOnly, request);
	            }
	            else if (type.equals("smrEdiTerms")) {
	            	list = SmrLOVSupport.getSmrEdiTerms(lookupOnly, request);
	            }
	            else if (type.equals("smrEdiOrder")) {
	            	list = SmrLOVSupport.getSmrEdiOrder(lookupOnly, request);
	            }

	            // Invoice Mass Correction LOV values
	            else if (type.equals("smrInvoice")) {
	            	list = SmrLOVSupport.getSmrInvoiceOrderSupplierInvoice(lookupOnly,request);
	            }
	            else if (type.equals("smrToInvoice")) { // Anil P added this code
	            	list = SmrLOVSupport.getSmrInvoiceOrderSupplierInvoice(lookupOnly,request);
	            }
	            else if (type.equals("smrInvoiceItems")) {
	            	list = SmrLOVSupport.getSmrInvoiceItems(lookupOnly,request);
	            }
	            else if (type.equals("smrPOItems")) {
	            	list = SmrLOVSupport.getSmrPOItems(lookupOnly,request);
	            }
	            else if (type.equals("smrInvoiceSupplierFilter")) {
	            	list = SmrLOVSupport.getSmrInvoiceSuppliersFilter(lookupOnly, request);
	            }
	            else if (type.equals("smrInvoiceSupplierSite")) {
	            	list = SmrLOVSupport.getSmrInvoiceSupplierSites(lookupOnly, request);
	            }
	            else if (type.equals("smrNewSupplierSite")) {
	            	list = SmrLOVSupport.getSmrNewSupplierSites(lookupOnly, request);
	            }
	            else if (type.equals("smrInvoiceTerms")) {
	            	list = SmrLOVSupport.getSmrInvoiceTerms(lookupOnly, request);
	            }
	            else if (type.equals("smrInvoiceOrder")) {
	            	list = SmrLOVSupport.getSmrInvoiceOrders(lookupOnly, request);
	            }
	            else if (type.equals("smrSupplierOrders")) {
	            	list = SmrLOVSupport.getSmrSupplierOrders(lookupOnly, request);
	            } else if (type.equals("smrReasonCode")) {
	            	// ENH 505 - New reason code to restrict the list of available reason codes for cost resolution.
	            	list = SmrLOVSupport.getSmrReasonCodes(lookupOnly, request);
	            }
	            
	            else {
	            	return LOVSupport.getList(lookupOnly, request);
	            }
	        } catch (ReIMException e) {
	            TransactionManagerFactory.getInstance().rollback();
	            throw e;
	        } catch (Exception e) {
	            TransactionManagerFactory.getInstance().rollback();
	            throw new ReIMException("error.sql_error", Severity.ERROR, e, LOVSupport.class);
	        } finally {
	            TransactionManagerFactory.getInstance().end();
	        }
	        return list;
	    }

	    private static String getId(HttpServletRequest request) {
	        String id = request.getParameter("id");
	        if (id == null || id.length() == 0) {
	            id = "";
	        }
	        return id.trim();
	    }

	    private static String getDesc(HttpServletRequest request) {
	        String desc = request.getParameter("desc");
	        if (desc == null || desc.length() == 0 || desc.equals("undefined")) {
	            desc = "";
	        }
	        return desc.trim();
	    }

	    protected static IKeyValue[] getSmrEdiOrderSupplierInvoice(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	        String supplierId = request.getParameter("supplierLOV");
	        String orderNo = request.getParameter("poLOV");
	        String invoiceId = request.getParameter("invoiceLOV");
	        
	        String type = request.getParameter("type");
	        String oldinvoiceId = request.getParameter("oldInvoiceLOV");

	        if (type.equals("smrToEdiInvoice")) {
	        // call select service for any invoice greater than previous value
	             if (lookupOnly) {
	                 list = SmrServiceFactory.getSmrEdiRejectService().selectToInvoices(supplierId, orderNo, invoiceId, id, oldinvoiceId);
	             }
	              else {
	                   list = SmrServiceFactory.getSmrEdiRejectService().selectToInvoices(supplierId, orderNo, invoiceId, null, oldinvoiceId);
	             }
	           
	        } else {
		        if (lookupOnly) {
		        	list = SmrServiceFactory.getSmrEdiRejectService().selectInvoices(supplierId, orderNo, invoiceId, id);
		        }
		        else {
		        	list = SmrServiceFactory.getSmrEdiRejectService().selectInvoices(supplierId, orderNo, invoiceId, null);
		        }
	        }
	        return list;
	        
	    }

	    protected static IKeyValue[] getSmrEdiItems(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrEdiRejectService().selectSmrEdiItems(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrEdiRejectService().selectSmrEdiItems(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }

	    protected static IKeyValue[] getSmrItems(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	String desc = SmrLOVSupport.getDesc(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrItemSupplierService.selectItems(supplierId, orderNo, invoiceId, id, desc);
	    	}
	    	else {
	    		list = SmrItemSupplierService.selectItems(supplierId, orderNo, invoiceId, null, desc);
	    	}
	    	return list;
	    }    
	    
	    protected static IKeyValue[] getSmrEdiTerms(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiTerms(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiTerms(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }

	    protected static IKeyValue[] getSmrEdiOrder(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiOrders(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiOrders(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }
	    
	    protected static IKeyValue[] getSmrEdiSuppliersFilter(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	        String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	// We are not interested in the previous value of the LOV
	        if (lookupOnly) {
	            list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiSupplierSitesFilter(orderNo, invoiceId, id);
	        }
	        else {
	            list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiSupplierSitesFilter(orderNo, invoiceId, null);
	        }
	        return list;
	    }
	    
	    protected static IKeyValue[] getSmrEdiSuppliers(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	        String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	// We are not interested in the previous value of the LOV
	        if (lookupOnly) {
	            list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiSupplierSites(supplierId, orderNo, invoiceId, id);
	        }
	        else {
	            list = SmrServiceFactory.getSmrEdiRejectService().getSmrEdiSupplierSites(supplierId, orderNo, invoiceId, null);
	        }
	        return list;
	    }
	    
	    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	    
	    protected static IKeyValue[] getSmrInvoiceOrderSupplierInvoice(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	        String supplierId = request.getParameter("supplierLOV");
	        String orderNo = request.getParameter("poLOV");
	        String invoiceId = request.getParameter("invoiceLOV");
                
	        if (lookupOnly) {
	            //list = SmrServiceFactory.getSmrEdiRejectService().selectInvoices(supplierId, orderNo, invoiceId, id);
	        	list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().selectInvoices(supplierId, orderNo, invoiceId, id );
	        }
	        else {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().selectInvoices(supplierId, orderNo, invoiceId, null);
	        }
	        return list;
	    }

	    protected static IKeyValue[] getSmrInvoiceItems(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().selectSmrInvoiceItems(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().selectSmrInvoiceItems(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }

	    protected static IKeyValue[] getSmrPOItems(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	String desc = SmrLOVSupport.getDesc(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrItemSupplierService.selectItems(supplierId, orderNo, invoiceId, id, desc);
	    	}
	    	else {
	    		list = SmrItemSupplierService.selectItems(supplierId, orderNo, invoiceId, null, desc);
	    	}
	    	return list;
	    }    
	    
	    protected static IKeyValue[] getSmrInvoiceTerms(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceTerms(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceTerms(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }

	    protected static IKeyValue[] getSmrInvoiceOrders(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceOrders(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceOrders(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }
	    
	    protected static IKeyValue[] getSmrSupplierOrders(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	    	String id = SmrLOVSupport.getId(request);
	    	IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	    	String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	if (lookupOnly) {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceOrders(supplierId, orderNo, invoiceId, id);
	    	}
	    	else {
	    		list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceOrders(supplierId, orderNo, invoiceId, null);
	    	}
	    	return list;
	    }
	    
	    protected static IKeyValue[] getSmrInvoiceSuppliersFilter(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	        String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	// We are not interested in the previous value of the LOV
	        if (lookupOnly) {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceSupplierSitesFilter(orderNo, invoiceId, id);
	        }
	        else {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceSupplierSitesFilter(orderNo, invoiceId, null);
	        }
	        return list;
	    }
	    
	    protected static IKeyValue[] getSmrInvoiceSupplierSites(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	        String orderNo = request.getParameter("poLOV");
	    	String invoiceId = request.getParameter("invoiceLOV");
	    	// We are not interested in the previous value of the LOV
	        if (lookupOnly) {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceSupplierSites(supplierId, orderNo, invoiceId, id);
	        }
	        else {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getSmrInvoiceSupplierSites(supplierId, orderNo, invoiceId, null);
	        }
	        return list;
	    }
	    
	    protected static IKeyValue[] getSmrNewSupplierSites(boolean lookupOnly, HttpServletRequest request) throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;
	    	String supplierId = request.getParameter("supplierLOV");
	        String orderNo = request.getParameter("poLOV");	    	
	    	// We are not interested in the previous value of the LOV
	        if (lookupOnly) {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getDistinctSupplierSites(supplierId, orderNo, id);
	        }
	        else {
	            list = SmrServiceFactory.getSmrInvoiceMassCorrectionService().getDistinctSupplierSites(supplierId, orderNo, null);
	        }
	        return list;
	    }
	    
	    /**
	     * ENH505 - New custom LOV popup for restricting the list of available reason codes. This is 
	     * primarily required for cost resolution. 
	     * 
	     * @param lookupOnly
	     * @param request the request sent from the web page for initiating the LOV popup.
	     * @return the list of valid reason codes available to the user.
	     * @throws Exception thrown if any exceptions whatsoever are generated.
	     */
	    protected static IKeyValue[] getSmrReasonCodes(boolean lookupOnly, HttpServletRequest request)
	            throws ReIMException {
	        String id = SmrLOVSupport.getId(request);
	        IKeyValue[] list = null;

	        long businessRoleId = ReIMUserContext.getUserRole().getBusinessRoleId();
	        String reasonCodeType = request.getParameter("reasonCodeType");
	        String documentType = request.getParameter("documentType");
	        String varianceSign = request.getParameter("varianceSign");
	        String selectedCostQuantity = request.getParameter("selectedCost");
	        if (selectedCostQuantity == null) {
	            selectedCostQuantity = request.getParameter("selectedQuantity");
	        }
	        String receiptsExist = request.getParameter("receiptsExist");
	        
	        String orderNoString = request.getParameter("orderId");
	        String locationString = request.getParameter("location");
	        String item = request.getParameter("selectedItem");
	        String unitCostString = request.getParameter("docCost");
	        
	        boolean selectedCostQuantityIsOther;
	        if (selectedCostQuantity != null
	                && (selectedCostQuantity.equals(PriceReviewListForm.OTHER_COST) || selectedCostQuantity
	                        .equals(ReIMConstants.OTHER_QUANTITY))) {
	            selectedCostQuantityIsOther = true;
	        } else {
	            selectedCostQuantityIsOther = false;
	        }

	        if (receiptsExist == null) {
	            receiptsExist = ReIMConstants.NO;
	        }

	        if (lookupOnly) {
	            list = SmrServiceFactory.getSmrReasonCodesService().getReasonCodes(businessRoleId, id,
	                    reasonCodeType, documentType, varianceSign, selectedCostQuantityIsOther,
	                    receiptsExist, selectedCostQuantity, orderNoString, locationString, item, unitCostString);
	        } else {
	            list = SmrServiceFactory.getSmrReasonCodesService().getReasonCodes(businessRoleId, null,
	                    reasonCodeType, documentType, varianceSign, selectedCostQuantityIsOther,
	                    receiptsExist, selectedCostQuantity, orderNoString, locationString, item, unitCostString);
	        }
	        return list;
	    }
	    
	}
