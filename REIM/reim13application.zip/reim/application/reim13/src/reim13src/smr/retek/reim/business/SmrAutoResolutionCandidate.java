package smr.retek.reim.business;

import oracle.retail.reim.business.DiscrepancyType;

import com.retek.reim.business.Location;
import com.retek.reim.ui.discrepancyResolution.PriceReview;
import com.retek.reim.ui.discrepancyResolution.QuantityReview;

public class SmrAutoResolutionCandidate {
	protected static final String FAVOR_OF_SUP = "SUP";
	protected static final String FAVOR_OF_SMR = "SMR";
	protected String docId;
	protected String orderId;
	protected String inFavorOf;
	protected Location location;
	protected DiscrepancyType discrepancyType;
	protected String reasonCodeId;
	protected String action;
        protected double variance;
	
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public DiscrepancyType getDiscrepancyType() {
		return discrepancyType;
	}
	public void setDiscrepancyType(DiscrepancyType discrepancyType) {
		this.discrepancyType = discrepancyType;
	}
	public String getReasonCodeId() {
		return reasonCodeId;
	}
	public void setReasonCodeId(String reasonCodeId) {
		this.reasonCodeId = reasonCodeId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}		
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public boolean isInFavorOfSMR() {
		return this.inFavorOf == null ? false : FAVOR_OF_SMR.equals(this.inFavorOf);
	}
	public boolean isInFavorOfSupplier() {
		return this.inFavorOf == null ? false : FAVOR_OF_SUP.equals(this.inFavorOf);
	}
	public String getKey() {
		return this.docId + "~" + this.orderId + "~" + this.location.getLocationId() + "~" + this.location.getLocationType(); 
	}
	
	public static String getKey(PriceReview review) {
		return review.getDocId() + "~" + review.getOrderId() + "~" + review.getLocation().getLocationId() + "~" + review.getLocation().getLocationType(); 
	}
	
	public static String getKey(QuantityReview review) {
		return review.getDocId() + "~" + review.getOrderId() + "~" + review.getLocation().getLocationId() + "~" + review.getLocation().getLocationType(); 
	}

    public void setVariance(double variance) {
        this.variance = variance;
    }

    public double getVariance() {
        return variance;
    }
}
