package smr.retek.reim.batch.ediupinv.threading;

import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.Severity;
import EDU.oswego.cs.dl.util.concurrent.LinkedQueue;

import com.retek.merch.utils.Utility;
import com.retek.reim.batch.BatchUtils;
import com.retek.reim.batch.ReIMBatch;
import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EdiDocBulk;
import com.retek.reim.batch.ediupinv.EdiFileHeader;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.batch.ediupinv.EdiUploadProperties;
import com.retek.reim.batch.ediupinv.EdiValidateFile;
import com.retek.reim.batch.ediupinv.threading.EdiTransactionUploadReporter;
import smr.retek.reim.batch.ediupinv.threading.SmrEdiBackground;
import smr.retek.reim.batch.ediupinv.threading.SmrEdiProducer;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.threads.Background;
import com.retek.reim.merch.utils.threads.EndOfQueue;
import com.retek.reim.services.ServiceFactory;

public class SmrEdiUpload extends ReIMBatch implements EDIConstants {
    private static String inputFileName = "";
    private static int exitStatus = BatchUtils.SUCCESS;
    public static final String EDI_UPLOAD_USAGE = "smrreimediinvupload username/password inputfile outputfile smrrejectfile"; // SMR OLR ENH31 Inserted

    public static int main(String[] args) {
        EdiFileHeader ediFileHeader = null;
        SmrEdiUpload ediUpload = new SmrEdiUpload();

        try {
            ediFileHeader = ediUpload.init(args);
        } catch (Exception e) {
            Logger.error(SmrEdiUpload.class, e);
            SmrEdiUpload.exitStatus = BatchUtils.FAILED_INIT;
        }

        // When INIT fails then ediFileHeader = null, so no processing should be done.
        if (SmrEdiUpload.exitStatus != BatchUtils.FAILED_INIT) {
            try {
            	SmrEdiUpload.exitStatus = ediUpload.runEdiUpload(args, ediFileHeader);
            } catch (Exception e) {
                Logger.error(SmrEdiUpload.class, e);
                SmrEdiUpload.exitStatus = BatchUtils.FAILED_PROCESS;
            }
        }

        ediUpload.wrapup();
        return SmrEdiUpload.exitStatus;
    }

    private int runEdiUpload(String[] args, EdiFileHeader ediFileHeader) throws ReIMException,
            InterruptedException {
        EdiTransactionUploadReporter uploadReporter = null;
        EdiDocBulk ediDocBulk = new EdiDocBulk();
        int uploadStatus = BatchUtils.SUCCESS;

        if (EdiUploadProperties.MULTITHREADED) {
            uploadReporter = doMultiThreadedEdiUpload(args, ediFileHeader, ediDocBulk);
        } else {
            uploadReporter = doSingleThreadedEdiUpload(args, ediFileHeader, ediDocBulk);
        }

        if (!uploadReporter.hasSuccessfullyTerminated()) {
            uploadStatus = BatchUtils.FAILED_PROCESS;
        } else {
            if (uploadReporter.isTransactionsRejectedToDatabase()
                    && uploadReporter.isTransactionsRejectedToFile()) {
                uploadStatus = BatchUtils.SUCCESS_WITH_REJECTS_TO_DB_AND_FILE;
            } else if (uploadReporter.isTransactionsRejectedToDatabase()) {
                uploadStatus = BatchUtils.SUCCESS_WITH_REJECTS_TO_DB;
            } else if (uploadReporter.isTransactionsRejectedToFile()) {
                uploadStatus = BatchUtils.SUCCESS_WITH_REJECTS_TO_FILE;
            }

            // flush out the remaining documents
            if (ediDocBulk.getDocHead().size() > 0) {
                ServiceFactory.getEdiDocumentService().insertEdiDocuments(ediDocBulk, false);
            }
        }

        return uploadStatus;
    }

    
    private EdiTransactionUploadReporter doSingleThreadedEdiUpload(String[] args,
            EdiFileHeader ediFileHeader, EdiDocBulk ediDocBulk) throws ReIMException {

        Logger.info(this, "Single-threaded EDI upload");

        LinkedQueue backgroundQueue = new LinkedQueue();
        // Background background = new SmrEdiBackground(backgroundQueue, args[2], ediFileHeader);
        Background background = new SmrEdiBackground(backgroundQueue, args[2], args[3], ediFileHeader);
        new Thread(background).start();
        SmrEdiTransactionReader reader = new SmrEdiTransactionReader(args, ediDocBulk, backgroundQueue);

        // Discard FHEAD
        reader.discardEdiFileLine();

        EdiTransactionHeader ediTransactionHeader = null;

        while (true) {
            ediTransactionHeader = reader.getNextTransaction();
            if (ediTransactionHeader != null) {
                ediTransactionHeader.run();
            } else {
                break;
            }
        }

        try {
            backgroundQueue.put(new EndOfQueue());
        } catch (InterruptedException e) {
            throw new ReIMException("batch.unexpected_threading_error", Severity.ERROR, e,
                    background);
        }
        return reader;
    }

    private EdiTransactionUploadReporter doMultiThreadedEdiUpload(String[] args,
            EdiFileHeader ediFileHeader, EdiDocBulk ediDocBulk) throws ReIMException,
            InterruptedException {

        Logger.info(this, "Multi-threaded EDI upload");

        SmrEdiProducer producer = new SmrEdiProducer(ediFileHeader, args, ediDocBulk);
        new Thread(producer).start();

        boolean done = true;
        while (done) {
            Thread.sleep(1000);
            done = !producer.isTerminated();
        }
        return producer;
    }

    private EdiFileHeader init(String[] args) throws ReIMException {
        EdiFileHeader ediFileHeader = new EdiFileHeader();
        // SMR OLR ENH31 Removed
        /*if (args.length < 3) { throw new ReIMException("error.batch.usage", Severity.FATAL, this,
                new String[] { EDI_UPLOAD_USAGE}); } // SMR OLR ENH31 Inserted*/ 
        
        if (args.length < 4) { throw new ReIMException("error.batch.usage", Severity.FATAL, this,
                new String[] { EDI_UPLOAD_USAGE}); } // SMR OLR ENH31 Inserted

        BatchUtils.start(SmrEdiUpload.class, args);
        inputFileName = args[1];
        try {
            ediFileHeader = EdiValidateFile.validateFileFormat(inputFileName);
        } catch (ReIMException e) {
            // copy the input file to the reject file cause it's ALL invalid.
            if (!BatchUtils.copyFile(inputFileName, args[2])) {
                // returns false if something went wrong
                throw new ReIMException("error.batch.unable_to_write_to_file", Severity.FATAL,
                        this, new String[] { args[2]});
            }

            throw e;
        }
        return ediFileHeader;
    }

    private void wrapup() {
        BatchUtils.finish(SmrEdiUpload.class, SmrEdiUpload.exitStatus);
    }
}