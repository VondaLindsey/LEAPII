package smr.retail.reim.batch.jobs;

import oracle.retail.reim.batch.ABatchProcess;
import oracle.retail.reim.batch.BatchResults;
import oracle.retail.reim.batch.IBatchResults;

import org.springframework.stereotype.Component;

import smr.retail.reim.batch.SmrBatchNames;
import smr.retek.reim.batch.ediupinv.threading.SmrEdiUpload;

@Component(SmrBatchNames.SMREDIUPLOAD)
public class SmrEdiUploadBatch extends ABatchProcess {

    @Override
    public IBatchResults performBatch() {
        int exitCode = SmrEdiUpload.main(getArguments().toArray());
        return new BatchResults(exitCode);
    }

}

