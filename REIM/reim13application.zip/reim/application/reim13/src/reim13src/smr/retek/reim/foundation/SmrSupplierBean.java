package smr.retek.reim.foundation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.merch.utils.ReIMException;


public class SmrSupplierBean {
	
	public boolean isSupplierInvoiceAtSDCLevel(String supplier) throws ReIMException {
		OraclePreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			Connection conn = TransactionManagerFactory.getInstance().getConnection();

			StringBuffer query = new StringBuffer("SELECT SUPPLIER FROM SMR_SDC_LEVEL_INVC WHERE SUPPLIER = ?");
			query.append("UNION SELECT SDL.SUPPLIER FROM SMR_SDC_LEVEL_INVC SDL, SUPS SS WHERE SS.SUPPLIER_PARENT = SDL.SUPPLIER AND SS.SUPPLIER = ?");
			stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			stmt.setString(1, supplier);
			stmt.setString(2, supplier);
	            
			rs = stmt.executeQuery();

			return rs.next();

		} catch (Exception e) {
			throw new ReIMException("error.smr_supplier_bean.get_invoice_level", Severity.ERROR, e, this);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception e) {
				throw new com.retek.reim.merch.utils.ReIMException(
	                        "error.smr_supplier_bean.get_invoice_level", Severity.ERROR, e, this);
			}
		}
	}
}
