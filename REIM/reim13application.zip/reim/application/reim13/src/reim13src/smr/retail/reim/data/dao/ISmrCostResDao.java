package smr.retail.reim.data.dao;

import com.retek.reim.merch.utils.ReIMException;

/**
 * DAO Interface to access the SMR_REIM_COST_RES_SQL package.
 * 
 * V1.1 Initial Version
 * 
 * @author Simon Mann
 *
 */
public interface ISmrCostResDao {
	
	/**
	 * Call the datastore in order to determine if an RCA is allowed for the provided parameters
	 * 
	 * @param order_no the order number to execute the RCA against
	 * @param location the location of the shipment to execute the RCA against
	 * @param item the item number against the shipment
	 * @param unitCost the unit cost for which the RCA is attempted to be called for.
	 * @return True if an RCA is allowed, otherwise false.
	 * 
	 * @throws ReIMException Thrown if unable to retrieve a result.
	 */
	public boolean isRcaAllowed(final long orderNo, final long location, final String item, final double unitCost) 
			throws ReIMException;
	
}
