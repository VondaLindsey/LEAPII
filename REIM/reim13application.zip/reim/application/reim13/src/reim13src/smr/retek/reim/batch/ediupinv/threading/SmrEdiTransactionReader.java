package smr.retek.reim.batch.ediupinv.threading;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.services.impl.EdiDocumentService;
import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.Severity;
import smr.retek.reim.batch.ediupinv.SmrEdiTransactionHeader;
import EDU.oswego.cs.dl.util.concurrent.LinkedQueue;

import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EDIHeaderTax;
import com.retek.reim.batch.ediupinv.EdiDetailAllowance;
import com.retek.reim.batch.ediupinv.EdiDocBulk;
import com.retek.reim.batch.ediupinv.EdiNonMerchDetail;
import com.retek.reim.batch.ediupinv.EdiRecord;
import com.retek.reim.batch.ediupinv.EdiTransactionDetail;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.batch.ediupinv.EdiTransactionTail;
import com.retek.reim.batch.ediupinv.EdiUploadProperties;
import com.retek.reim.batch.ediupinv.threading.EdiTransactionUploadReporter;
import com.retek.reim.db.ImDocHeadAccessExt;
import com.retek.reim.merch.utils.ReIMException;

public class SmrEdiTransactionReader implements EDIConstants, EdiTransactionUploadReporter {
    private BufferedReader bufferedReader = null;
    private String inputFileName = "";
    private long transactionLinesCounter = 0L;
    private long totalLinesCounter = 0L;
    private EdiRecord ediRecord = new EdiRecord();
    private boolean transactionsRejectedToFile = false;
    private boolean transactionsRejectedToDatabase = false;
    private String[] ediUploadArgs = null;
    private EdiDocBulk ediDocBulk = null;
    private LinkedQueue backgroundQueue = null;

    private static final int FILE_BUFFER_SIZE = 65536; // larger than default
    private boolean hasSuccessfulTermination = true;

    public SmrEdiTransactionReader(String[] args, EdiDocBulk ediDocBulk, LinkedQueue backgroundQueue)
            throws ReIMException {
        this.inputFileName = args[1];
        this.ediDocBulk = ediDocBulk;
        this.backgroundQueue = backgroundQueue;
        this.ediUploadArgs = args;

        File inputFileHandle = new File(inputFileName);
        try {
            bufferedReader = new BufferedReader(new FileReader(inputFileHandle), FILE_BUFFER_SIZE);
        } catch (FileNotFoundException e) {
            String key = "error.batch.file_not_found";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, inputFileName};
            Logger.errorKey(SmrEdiTransactionReader.class, key, parameters);
            throw new ReIMException(key, Severity.FATAL, this, parameters);
        }
        ediDocBulk = EdiDocumentService.initEdiDocBulk(ediDocBulk);
        
    }

    public EdiTransactionHeader getNextTransaction() throws ReIMException {
        EdiTransactionHeader ediTransactionHeader = null;
        ArrayList<EdiTransactionDetail> ediTransactionDetailArray = null;
        ArrayList<EdiNonMerchDetail> ediNonMerchDetailArray = null;
        ArrayList<EDIHeaderTax> ediTaxDetailArray = null;

        getLine();

        TransactionLoop: while (true) {
            if (ediRecord.getRecordDescriptor().equals(FTAIL)) {
                break TransactionLoop;
            }

            // Reset detail counter
            transactionLinesCounter = 0L;

            ediTransactionHeader = new SmrEdiTransactionHeader(ediRecord, backgroundQueue, ediUploadArgs, ediDocBulk);
            
            ediTransactionHeader.setUploadReporter(this);
            ediTransactionDetailArray = new ArrayList<EdiTransactionDetail>();
            ediNonMerchDetailArray = new ArrayList<EdiNonMerchDetail>();

            // added for tax
            ediTaxDetailArray = new ArrayList<EDIHeaderTax>();

            getLine();

            TransactionDetailLoop: while (true) {
                if (ediRecord.getRecordDescriptor().equals(TTAIL)) {
                    EdiTransactionTail ediTransactionTail = new EdiTransactionTail(ediRecord,
                            transactionLinesCounter);

                    ediTransactionHeader.setEdiTransactionTail(ediTransactionTail);

                    if (!ediTransactionTail.isTransactionValid()) {
                        ediTransactionHeader.setTransactionValid(false);
                    }

                    break TransactionLoop;
                }

                DetailLoop: while (true) {
                    if (!ediRecord.getRecordDescriptor().equals(TDETL)) {
                        break DetailLoop;
                    }

                    // Increment detail counter
                    transactionLinesCounter++;

                    EdiTransactionDetail ediTransactionDetail = new EdiTransactionDetail(ediRecord,
                            ediTransactionHeader);

                    if (!ediTransactionDetail.isTransactionValid()) {
                        ediTransactionHeader.setTransactionValid(false);
                    }

                    ArrayList<EdiDetailAllowance> ediDetailAllowanceArray = new ArrayList<EdiDetailAllowance>();

                    AllowanceLoop: while (true) {
                        getLine();

                        if (!ediRecord.getRecordDescriptor().equals(TALLW)) {
                            break AllowanceLoop;
                        }

                        // Increment detail counter
                        transactionLinesCounter++;

                        EdiDetailAllowance ediDetailAllowance = new EdiDetailAllowance(ediRecord);

                        if (!ediDetailAllowance.isTransactionValid()) {
                            ediTransactionHeader.setTransactionValid(false);
                        }

                        ediDetailAllowanceArray.add(ediDetailAllowance);
                    } // end AllowanceLoop

                    if (ediDetailAllowanceArray.size() > 0) {
                        ediTransactionDetail
                                .setEdiDetailAllowanceList((EdiDetailAllowance[]) ediDetailAllowanceArray
                                        .toArray(new EdiDetailAllowance[ediDetailAllowanceArray
                                                .size()]));
                    }

                    ediTransactionDetailArray.add(ediTransactionDetail);
                } // end TDETL processing

                if (ediRecord.getRecordDescriptor().equals(TNMRC)) {
                    // Increment detail counter
                    transactionLinesCounter++;

                    EdiNonMerchDetail ediNonMerchDetail = new EdiNonMerchDetail(ediRecord);
                    if (!ediNonMerchDetail.isTransactionValid()) {
                        ediTransactionHeader.setTransactionValid(false);
                    }

                    ediNonMerchDetailArray.add(ediNonMerchDetail);

                    getLine();
                }

                // added for the TTAXS records.
                if (ediRecord.getRecordDescriptor().equals(TTAXS)) {
                    // Increment detail counter
                    transactionLinesCounter++;

                    EDIHeaderTax ediTaxDetail = new EDIHeaderTax(ediRecord);

                    if (!ediTaxDetail.isTransactionValid()) {
                        ediTransactionHeader.setTransactionValid(false);
                    }

                    ediTaxDetailArray.add(ediTaxDetail);

                    getLine();
                }
            } // end Detail Loop
        } // end TransactionLoop

        // add list of transaction detail records to the header transaction
        if (ediTransactionDetailArray != null && ediTransactionDetailArray.size() > 0) {
            ediTransactionHeader
                    .setEdiTransactionDetailList((EdiTransactionDetail[]) ediTransactionDetailArray
                            .toArray(new EdiTransactionDetail[ediTransactionDetailArray.size()]));
        }

        // add list of non-merchandise detail records to the header transaction
        if (ediNonMerchDetailArray != null && ediNonMerchDetailArray.size() > 0) {
            ediTransactionHeader
                    .setEdiNonMerchDetailList((EdiNonMerchDetail[]) ediNonMerchDetailArray
                            .toArray(new EdiNonMerchDetail[ediNonMerchDetailArray.size()]));
        }

        // add list of tax detail records to the header transaction
        if (ediTaxDetailArray != null && ediTaxDetailArray.size() > 0) {
            ediTransactionHeader.setEDIHeaderTaxList((EDIHeaderTax[]) ediTaxDetailArray
                    .toArray(new EDIHeaderTax[ediTaxDetailArray.size()]));
        }

        return ediTransactionHeader;
    }

    /**
     * Reads one line from the input and creates an upload record. If the file is being validated
     * (initial sweep) then it will also validate line numbering and record descriptor.
     */
    private void getLine() throws ReIMException {
        try {
            String line = bufferedReader.readLine();
            if (line == null) {
                String key = "error.batch.file_incomplete";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                        String.valueOf(totalLinesCounter)};
                Logger.errorKey(SmrEdiTransactionReader.class, key, parameters);
                throw new ReIMException(key, Severity.FATAL, this, parameters);
            }

            totalLinesCounter++;
            ediRecord.reset(line);
        } catch (IOException e) {
            String key = "error.batch.file_io";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, inputFileName};
            Logger.errorKey(SmrEdiTransactionReader.class, key, parameters);
            throw new ReIMException(key, Severity.FATAL, e, this, parameters);
        }
    }

    public void discardEdiFileLine() throws ReIMException {
        try {
            bufferedReader.readLine();
        } catch (IOException e) {
            String key = "error.batch.file_io";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, inputFileName};
            Logger.errorKey(SmrEdiTransactionReader.class, key, parameters);
            throw new ReIMException(key, Severity.FATAL, e, this, parameters);
        }
    }

    public boolean hasSuccessfullyTerminated() {
        return this.hasSuccessfulTermination;
    }

    public void setSuccessfulTermination(boolean b) {
        this.hasSuccessfulTermination = b;
    }

    public boolean isTransactionsRejectedToDatabase() {
        return this.transactionsRejectedToDatabase;
    }

    public void setTransactionsRejectedToDatabase(boolean transactionsRejectedToDatabase) {
        this.transactionsRejectedToDatabase = transactionsRejectedToDatabase;
        this.transactionsRejectedToFile = !transactionsRejectedToDatabase;
    }

    public boolean isTransactionsRejectedToFile() {
        return this.transactionsRejectedToFile;
    }

    public void setTransactionsRejectedToFile(boolean transactionsRejectedToFile) {
        this.transactionsRejectedToFile = transactionsRejectedToFile;
        this.transactionsRejectedToDatabase = !transactionsRejectedToFile;
    }
}