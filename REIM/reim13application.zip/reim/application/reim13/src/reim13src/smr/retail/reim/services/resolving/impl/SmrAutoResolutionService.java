package smr.retail.reim.services.resolving.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.retail.reim.business.DiscrepancyType;
import oracle.retail.reim.services.IDocumentService;
import oracle.retail.reim.services.IVarianceResolutionService;
import oracle.retail.reim.services.impl.VarianceResolutionService;
import oracle.retail.reim.services.ui.discrepancyResolution.IDiscrepancyResolutionUIService;
import oracle.retail.reim.services.ui.discrepancyResolution.IPriceReviewListUIService;
import oracle.retail.reim.services.ui.discrepancyResolution.IQuantityReviewListUIService;
import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.Severity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import com.retek.reim.batch.BatchUtils;
import com.retek.reim.business.DiscrepancyCostReview;
import com.retek.reim.business.ReasonCode;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.ReceiptItem;
import com.retek.reim.business.Resolution;
import com.retek.reim.business.ResolutionMerchandiseInvoice;
import com.retek.reim.business.document.Document;
import com.retek.reim.db.ImReasonCodesRow;
import com.retek.reim.foundation.AShipSkuBean;
import com.retek.reim.locking.LockingData;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMMoney;
import com.retek.reim.merch.utils.ReIMQuantity;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ClassService;
import com.retek.reim.services.DepartmentService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.discrepancyResolution.PriceReview;
import com.retek.reim.ui.discrepancyResolution.PriceReviewDetail;
import com.retek.reim.ui.discrepancyResolution.PriceReviewListForm;
import com.retek.reim.ui.discrepancyResolution.QuantityReview;
import com.retek.reim.ui.discrepancyResolution.QuantityReviewDetail;
import com.retek.reim.ui.discrepancyResolution.QuantityReviewListForm;
import com.retek.reim.ui.discrepancyResolution.QuantityReviewReceiptQuantities;
import com.retek.reim.ui.discrepancyResolution.VarianceResolution;
import com.retek.reim.ui.lov.LOV;
import java.sql.CallableStatement;
import java.sql.Connection;
import oracle.jdbc.OracleConnection;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.DatasourceProperties;
import java.sql.SQLException;

import java.sql.Types;
import smr.retail.reim.services.resolving.ISmrAutoResolutionService;
import smr.retek.reim.business.SmrAutoResolutionCandidate;
import smr.retek.reim.data.dao.ISmrAutoResolutionDao;

@Service
public class SmrAutoResolutionService implements ISmrAutoResolutionService{
	
	private IPriceReviewListUIService priceReviewListUIService;
	private IQuantityReviewListUIService quantityReviewListUIService;
	private ISmrAutoResolutionDao smrAutoResolutionDao;
	private IDocumentService documentService;
	private IDiscrepancyResolutionUIService discrepancyResolutionUIService;
	private IVarianceResolutionService varianceResolutionService;
    private String dateStr;

    public Map<String, SmrAutoResolutionCandidate> getAutoResolutionCandidates() {
    	return smrAutoResolutionDao.getAutoResolutionCandidates();
    }
	
	public int processResolutionCandidates(Map<String, SmrAutoResolutionCandidate> resolutionCandidates) throws Exception {
		int processStatus = BatchUtils.SUCCESS;
		// populate price and quantity review list headers
		PriceReviewListForm priceReviewForm = new PriceReviewListForm();
        populatePriceReviewList(priceReviewForm);
        QuantityReviewListForm quantityReviewForm = new QuantityReviewListForm();
        populateQuantityReviewList(quantityReviewForm);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 	   //get current date time with Date()
 	   Date date = new Date();
// 	   String dateStr;
 	   System.out.println("dateFormat.format(date) " + dateFormat.format(date));
 	   dateStr = dateFormat.format(date);

        // build maps of cost and quantity discrepancies by invoice as this if cost and quantity discrepancies exist special handling is required.
        String key;
        Map<String, List<PriceReview>> costReviewMap = new HashMap<String, List<PriceReview>>();
        List<PriceReview> costlist;
        for (PriceReview review : priceReviewForm.getPriceReviewList()) {
        	if (!review.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
        		Logger.warn(this, "Document: " + review.getDocId() + " is not a merchandise invoice will not attempt to auto resolve.");
        		continue;
        	}
        	key = SmrAutoResolutionCandidate.getKey(review);
        	costlist = costReviewMap.get(key);
        	if (costlist == null) {
        		costlist = new ArrayList<PriceReview>();
        		costReviewMap.put(key, costlist);
        	}
        	costlist.add(review);
        }
        Map<String, List<QuantityReview>> qtyReviewMap = new HashMap<String, List<QuantityReview>>();
        List<QuantityReview> qtylist;
        for (QuantityReview review : quantityReviewForm.getQuantityReviewList()) {
        	if (!review.getDocumentType().equals(Document.MERCHANDISE_INVOICE)) {
        		Logger.warn(this, "Document: " + review.getDocId() + " is not a merchandise invoice will not attempt to auto resolve.");
        		continue;
        	}
        	key = SmrAutoResolutionCandidate.getKey(review);
        	qtylist = qtyReviewMap.get(key);
        	if (qtylist == null) {
        		qtylist = new ArrayList<QuantityReview>();
        		qtyReviewMap.put(key, qtylist);
        	}
        	qtylist.add(review);
        }        
        
        String currentUserId = ReIMUserContext.getUsername();
        String lockedDocId;
        
        SmrAutoResolutionCandidate candidate;
        List<PriceReview> priceReviews;
        List<QuantityReview> quantityReviews;
        int candidateStatus;
        for (String candidateKey : resolutionCandidates.keySet()) {
        	candidate = resolutionCandidates.get(candidateKey);
        	priceReviews = costReviewMap.get(candidateKey);
        	quantityReviews = qtyReviewMap.get(candidateKey);
        	if (priceReviews != null && quantityReviews != null) {
        		//Should not occur as the resolution candidate search should have excluded these cases
        		Logger.debug(this, "Skipping " + candidateKey + " as both cost and quantity discrepencies exist.");
        		continue;
        	}
        	lockedDocId = candidate.getDocId();
            if (!ServiceFactory.getTableRecordLockingService().lockTableRecordGroupForUserIncludeBatch(LockingData.DOC_HEAD_LOCK_TABLE, currentUserId, new long[]{Long.parseLong(lockedDocId)})) {
            	Logger.error(this, "Document locked by another user will be processed next run ~ " + candidate.getKey() + " ~ " + currentUserId);
            	processStatus = processStatus < BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG || processStatus != BatchUtils.SUCCESS ? processStatus : BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG;
            }
        	candidateStatus = applyResolution(candidate, priceReviewForm, quantityReviewForm, priceReviews, quantityReviews);
        	processStatus = processStatus < candidateStatus || processStatus != BatchUtils.SUCCESS ? processStatus : candidateStatus;
        }
        updateCostQty();
        return processStatus;
	}
	
	private int applyResolution(SmrAutoResolutionCandidate candidate, PriceReviewListForm priceReviewForm, QuantityReviewListForm quantityReviewForm, List<PriceReview> priceReviews, List<QuantityReview> quantityReviews) throws Exception {
		int processStatus = BatchUtils.SUCCESS;
		Logger.debug(this, "Attempting to apply resolution to candidate " + candidate.getKey());
		//Check that if discrepancy type corresponds to correct list
		if (candidate.getDiscrepancyType().equals(DiscrepancyType.COST) && quantityReviews != null) {
			throw new ReIMException("Cost based resolution candidate should not relate to a quantity review list. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this);
		}
		if (candidate.getDiscrepancyType().equals(DiscrepancyType.QTY) && priceReviews != null) {
			throw new ReIMException("Quantity based resolution candidate should not relate to a cost review list. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this);
		}
		//Look up ResolutionAction object
		LOV[] reasonCodes = ServiceFactory.getReasonCodesService().getReasonCodes(candidate.getAction(), candidate.getReasonCodeId());
		if (reasonCodes == null || reasonCodes.length != 1) {
			throw new ReIMException("Expected only one reason code, check SMR_IM_TOLERANCE is correctly configured.", Severity.ERROR, this);
		}
		
		String currentUserId = ReIMUserContext.getUsername();
		boolean locked;
				
		if (priceReviews != null) {
			for (PriceReview priceReview : priceReviews) {				
				loadPriceReviewDetails(priceReviewForm, priceReview);
				for (PriceReviewDetail reviewDetail : priceReviewForm.getPriceReviewDetail()) {
					String[] receipts = (String[])(priceReviewForm.getReceipts() != null ? priceReviewForm.getReceipts().toArray() : null);
					locked = getLocks(currentUserId, String.valueOf(priceReview.getDocId()), receipts);
					if (locked) {
						applyResolution(candidate, reasonCodes[0], priceReviewForm, priceReview, reviewDetail);
					} else {
						processStatus = processStatus < BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG || processStatus != BatchUtils.SUCCESS ? processStatus : BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG;
					}
					releaseLocks(currentUserId, String.valueOf(priceReview.getDocId()), receipts);
				}
			}
		}
        if (quantityReviews != null) {
			for (QuantityReview quantityReview : quantityReviews) {
				loadQuantityReviewDetails(quantityReviewForm, quantityReview);
				for (QuantityReviewDetail reviewDetail : quantityReviewForm.getQuantityReviewDetail()) {
					locked = getLocks(currentUserId, quantityReview.getDocId(), quantityReviewForm.getFilteredReceipts());
					if (locked) {
					    applyResolution(candidate, reasonCodes[0], quantityReviewForm, quantityReview, reviewDetail);
					} else {
						processStatus = processStatus < BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG || processStatus != BatchUtils.SUCCESS ? processStatus : BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG;
					}
					releaseLocks(currentUserId, quantityReview.getDocId(), quantityReviewForm.getFilteredReceipts());
				}
			}
		}
		return processStatus;
	}
	
	private boolean getLocks(String currentUserId, String invoiceId, String[] receiptIds) throws Exception {		
		if (invoiceId != null) {
			if (!ServiceFactory.getTableRecordLockingService().lockTableRecordGroupForUserIncludeBatch(LockingData.DOC_HEAD_LOCK_TABLE, currentUserId, new long[]{Long.parseLong(invoiceId)})) {
				Logger.error(this, "Document locked by another user will be processed next run ~ " + invoiceId + " ~ " + currentUserId);
				return false;
			}
		}
		if (receiptIds != null && receiptIds.length > 0) {
			long[] receiptIdsLong = new long[receiptIds.length];
			String receiptString = "(";
            for (int i = 0; i < receiptIds.length; i++) {
                receiptIdsLong[i] = Long.parseLong(receiptIds[i]);
                receiptString = receiptIds[i] + ",";
            }
            receiptString = receiptString.substring(0, receiptString.length() - 2) + ")";
            if(!ServiceFactory.getTableRecordLockingService().lockTableRecordGroupForUserIncludeBatch(LockingData.RECEIPT_LOCK_TABLE, currentUserId, receiptIdsLong)) {
            	Logger.error(this, "One or more receipts were locked by another user will be processed next run ~ " + receiptString + " ~ " + currentUserId);
            }
		}
		return true;
	}
	
	private void releaseLocks(String currentUserId, String invoiceId, String[] receiptIds) throws ReIMException {
		if (invoiceId != null) {
			ServiceFactory.getTableRecordLockingService().releaseLockOnRecordGroupForUserIncludeBatch(LockingData.DOC_HEAD_LOCK_TABLE, currentUserId, new long[]{Long.parseLong(invoiceId)});
		}
        if (receiptIds != null && receiptIds.length > 0) {
            long[] receiptIdsLong = new long[receiptIds.length];
            for (int i = 0; i < receiptIds.length; i++) {
                receiptIdsLong[i] = Long.parseLong(receiptIds[i]);
            }
            ServiceFactory.getTableRecordLockingService().releaseLockOnRecordGroupForUserIncludeBatch(LockingData.RECEIPT_LOCK_TABLE, currentUserId, receiptIdsLong);
        }
	}
	
	private void applyResolution(SmrAutoResolutionCandidate candidate, LOV reasonCode, PriceReviewListForm priceReviewForm, PriceReview priceReview, PriceReviewDetail reviewDetail) throws Exception {
		Logger.debug(this, "Attempting to apply resolution " + reasonCode.getId() + "~" +reasonCode.getDescription()+ "~" +reasonCode.getDescription2()+ "~ to " + candidate.getKey() + "~" + reviewDetail.getItem());
            
	    String orderNo = candidate.getOrderId();
	    String docId = candidate.getDocId();
	    String loc = candidate.getLocation().getLocationId();
	    String item = reviewDetail.getItem();
        String favorOf;
        BigDecimal ii = new BigDecimal(0);
	    double i = 0.00;
	                 
	    ii =  new BigDecimal(ServiceFactory.getDiscrepancyService().getCostDisc(docId, orderNo, loc, reviewDetail.getItem())) ;
	    if (ii.doubleValue() < 0.00 ) {
//	        candidate.setInFavorOf("SMR"); 
	        favorOf = "SMR";
	    } else {
//	        candidate.setInFavorOf("SUP"); 
	        favorOf = "SUP";
	    }
	    System.out.println(" COst  " + ii.doubleValue() + " favor " + favorOf + candidate.getReasonCodeId() + " "  + candidate.getAction() + " varia " + Math.abs(candidate.getVariance()) );
	    if (!candidate.getInFavorOf().equalsIgnoreCase(favorOf) ) {
	    	candidate.setInFavorOf(favorOf); 
//		    ImReasonCodesRow[] row = ServiceFactory.getDiscrepancyService().getReasonAction(favorOf,"N", i);
	    	 if (candidate.getAction().equalsIgnoreCase("RCA") ) {
	    	     candidate.setAction("CBC");
	    	     candidate.setReasonCodeId("1002");
	    	 } else if (candidate.getAction().equalsIgnoreCase("CBC") ) {
	    	     candidate.setAction("RCA");
	    	     candidate.setReasonCodeId("1001");
	    	 }
		    Logger.debug(this, "in AutoresolutionService applyresolution Cost" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
		    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + ii.doubleValue());

//	            candidate.setAction(row[0].getAction());
//	            candidate.setReasonCodeId(row[0].getReasonCodeId());
	    }
	    if (Math.abs(candidate.getVariance()) <= 2.00 ) {
	        candidate.setAction("RCA");
	        candidate.setReasonCodeId("1001");
	    } 
	    System.out.println( "in AutoresolutionService applyresolution Cost" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + ii.doubleValue());

	    Logger.debug(this,"in AutoresolutionService applyresolution Cost" + candidate.getAction() + " reason " + candidate.getReasonCodeId() );
            
//	    if (Math.abs(candidate.getVariance()) < 2.00 ) {
//	        candidate.setAction("RCA");
//	        candidate.setReasonCodeId("1001");
//	    }  else if ((Math.abs(candidate.getVariance()) > 2.00 && Math.abs(candidate.getVariance()) <= 50.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SMR")){
//	       candidate.setAction("RCA");
//	        candidate.setReasonCodeId("1001");
//	    }  else if ((Math.abs(candidate.getVariance()) > 2.00 && Math.abs(candidate.getVariance()) <= 15.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SUP")){
//	        candidate.setAction("CBC");
//	        candidate.setReasonCodeId("1002");
//	    }  

//           if (Math.abs(i) < 2.00 ) {
//               candidate.setAction("RCA");
//               candidate.setReasonCodeId("1001");
//           }  else if ((Math.abs(i) >= 2.00 && Math.abs(i) <= 50.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SMR")){
//               candidate.setAction("RCA");
//               candidate.setReasonCodeId("1001");
//           }  else if ((Math.abs(i) >= 2.00 && Math.abs(i) <= 15.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SUP")){
//               candidate.setAction("CBC");
//               candidate.setReasonCodeId("1002");
//          }  
//	    System.out.println("original candidate.getAction() " + candidate.getAction() + " value of i " + i + " candidate.getVariance() " + candidate.getVariance() );
	    
    LOV[] reasonCodes = ServiceFactory.getReasonCodesService().getReasonCodes(candidate.getAction(), candidate.getReasonCodeId());
	    reasonCode = reasonCodes[0];
            
//	      i =  ServiceFactory.getDiscrepancyService().getCostDisc(docId, orderNo, loc, reviewDetail.getItem()) ;
	    
//	      if ( i < 0) {
//	        candidate.setAction("RCA");
//	        reasonCode = ServiceFactory.getReasonCodesService().getReasonCodes(candidate.getAction(), candidate.getReasonCodeId())[0];
//	      }
		//Check if reason requires if comments (on description 3 of LOV object) if so then fail now
		if ("Y".equals(reasonCode.getDescription3())) {
			throw new ReIMException("Reasons which require comments cannot be used to auto resolve discrepancies. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this);
		}
		//Mimic the user selecting an item in the Price Discrepancy Detail List screen  (price_review_list_detail.jsp)
		priceReviewForm.setSelectedItem(reviewDetail.getItem());
		priceReviewForm.setSelectedDebitMemoReasonCode(reviewDetail.getDebitMemoReasonCode());
        if (priceReviewForm.getRefDocId() != null && priceReviewForm.getRefDocId().equals(priceReviewForm.getDocId())) {
            priceReviewForm.setDocId(documentService.getDocumentIdFromExternalId(priceReviewForm.getExternalDocId()));
        }
        priceReviewCostSelectionLoad(priceReviewForm);
        
        //Mimic the user selecting which is the valid cost in the resolution screen (price_review_cost_selection.jsp)
        priceReviewForm.setSelectedCost(getSelectedCost(candidate));
        
        //Mimic user clicking the next button or first detail resolution screen (price_review_cost_selection.jsp)
        priceReviewCorrectCostSelection(priceReviewForm);
        
        //Now need to mimic the user setting up the resolution action and other values on the main resolution screen (price_review_variance_resolution.jsp)
		priceReviewForm.setReasonCodeLOV(reasonCode.getId());
		priceReviewForm.setReasonCodeLOVAction(reasonCode.getDescription2());
		priceReviewForm.setReasonCodeLOVActionDesc(reasonCode.getDescription4());
		priceReviewForm.setCommentRequired("N");
		priceReviewForm.setHintComment(reasonCode.getDescription5());
		priceReviewForm.setCommentsExist("N");
		priceReviewForm.setCostRoleLOV(null);
		priceReviewForm.setCostRoleLOVDesc(null);
		priceReviewForm.setApplyAmount(String.valueOf(priceReviewForm.getOutstandingCostVariance()));		
		Logger.debug(this, "Applied amount : " + priceReviewForm.getApplyAmount());
		
		//Now mimic the user clicking the apply button, this just applies values set above to form in such  
		//a way ready for save (price_review_variance_resolution.jsp)
		doCostResolutionApplyToForm(priceReviewForm);
		
		//Now mimic the user clicking the save button (price_review_variance_resolution.jsp)
        doCostResolutionSave(priceReviewForm);        
	}

	private void priceReviewCorrectCostSelection(PriceReviewListForm priceReviewForm) throws ReIMException {
		//Sets up the form ready to start applying resolutions (extracted from PriceReviewCostSelectionNextAction)
		priceReviewForm.resetVarianceResolutions();
        Resolution[] varianceResolutions = varianceResolutionService.getResolutionActionsForDocItemType(priceReviewForm.getDocumentType(),
                        Long.parseLong(priceReviewForm.getDocId()),
                        priceReviewForm.getSelectedItem(), ReasonCode.COST_DISCREPANCY,
                        priceReviewForm.getSelectedDebitMemoReasonCode(),
                        priceReviewForm.getCurrency());
        priceReviewForm.setResolutionDetails(discrepancyResolutionUIService.createVarianceResolutions(varianceResolutions));
        priceReviewListUIService.setVarianceValues(priceReviewForm);
	}

	private void doCostResolutionApplyToForm(PriceReviewListForm priceReviewForm) throws ReIMException {
		//Now apply value (extracted from PriceReviewVarianceResolutionApplyAction)
		VarianceResolution[] previousResolutionList = priceReviewForm.getResolutionDetails();
        Double applyAmount = new Double(ReIMMoney.parseCurrencyString(priceReviewForm.getApplyAmount(),
                                priceReviewForm.getCurrency()).doubleValue());           
        String applyAmountFormatted = varianceResolutionService.formatAmount(
                    applyAmount.doubleValue(), Resolution.TYPE_COST,
                    priceReviewForm.getCurrency());
        
        int previousResolutionListLength = (previousResolutionList != null ? previousResolutionList.length : 0);
        ArrayList newResolutionList = new ArrayList();

        for (int i = 0; i < previousResolutionListLength; i++) {
            newResolutionList.add(previousResolutionList[i]);
        }

        VarianceResolution varianceResolution = new VarianceResolution(Resolution.TYPE_COST,
                new Long(priceReviewForm.getDocId()).longValue(), priceReviewForm
                        .getDocumentType(), priceReviewForm.getSelectedItem(),
                        priceReviewForm.getSelectedDebitMemoReasonCode(), priceReviewForm
                        .getReasonCodeLOV(), priceReviewForm.getReasonCodeLOVDesc(),
                        priceReviewForm.getReasonCodeLOVAction(), applyAmount,
                applyAmountFormatted, priceReviewForm.getCostRoleLOV(),
                null, priceReviewForm
                        .getCurrency(), Resolution.UNROLLED, Resolution.NEW);

        newResolutionList.add(varianceResolution);

        priceReviewForm.setResolutionDetails((VarianceResolution[]) newResolutionList.toArray(new VarianceResolution[newResolutionList.size()]));
        priceReviewForm.resetVarianceApplyFields();
        priceReviewListUIService.setVarianceValues(priceReviewForm);
        Logger.debug(this, "Updated outstanding variance: " + priceReviewForm.getOutstandingCostVariance());
	}
	
	private void doCostResolutionSave(PriceReviewListForm priceReviewListForm) throws Exception {
		//Now save resolutions applied (extracted from PriceReviewVarianceResolutionSaveAction)
            String rerouteBusinessRoleId = discrepancyResolutionUIService.rerouteActionExists(priceReviewListForm.getResolutionDetails());
            boolean rerouteExists = (rerouteBusinessRoleId != null ? true : false);
            Resolution[] resolutions = discrepancyResolutionUIService.createResolutions(priceReviewListForm.getResolutionDetails());

            Document fullDocument = varianceResolutionService.getDocument(resolutions);
            String currencyCode = priceReviewListForm.getCurrency();

            double outstandingVariance = priceReviewListUIService.calculateOutstandingVariance(priceReviewListForm);

            boolean withinTolerance = false;
            if (priceReviewListForm.getVarianceResolutionLevel().equals(PriceReviewListForm.RESOLUTION_TO_ZERO)) {
                // It is expected that for disputed credit memos,
                // withinTolerance will be true only
                // if the variance is resolved exactly to zero.
                if (outstandingVariance != 0) {
                    if (!rerouteExists) {
                        throw new ReIMException("error.variance_not_to_zero", Severity.ERROR, this);
                    }
                    withinTolerance = false;
                } else {
                    withinTolerance = true;
                }
            } else {
                // It is expected that for merchandise invoices, withinTolerance
                // will be true only
                // if the variance is resolved to within the appropriate
                // tolerance.
                double adjustedOrderOtherCost = ReIMMoney.parseCurrencyString(
                        priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue();
                double adjustedDocumentCost = ReIMMoney.parseCurrencyString(
                        priceReviewListForm.getDocCost(), currencyCode).doubleValue();
                double resolutionAmounts = priceReviewListUIService.calculateSumResolutions(
                        priceReviewListForm);

                if (priceReviewListForm.getSelectedCost().equals(PriceReviewListForm.ORDER_COST)) {
                    // Order cost was correct. Adjust the document cost.
                    adjustedDocumentCost = adjustedDocumentCost + resolutionAmounts;
                } else if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.INVOICE_COST)) {
                    // Document cost was correct. Adjust the order cost.
                    // Since variance here is calculated as order - invoice we
                    // want to subtract the resolution amounts
                    // Thus if the variance was negative (order cost < invoice)
                    // the resolutions
                    // will be added to the order because the resolutions have
                    // negative amount,
                    // if it is postive it will be subtracted. This way we can
                    // truely check variance within tolerance.

                    adjustedOrderOtherCost = adjustedOrderOtherCost - resolutionAmounts;
                } else // other cost was specified.
                {
                    // Other cost was specified. Adjust the document cost and
                    // order cost.
                    adjustedDocumentCost = adjustedDocumentCost + resolutionAmounts;
                    adjustedOrderOtherCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getOtherCost(), currencyCode).doubleValue();
                }

                if (fullDocument != null) {
                    withinTolerance = varianceResolutionService.isCostVarianceWithinTolerance(
                            outstandingVariance, adjustedDocumentCost, adjustedOrderOtherCost,
                            priceReviewListForm.getSelectedItem(), fullDocument);
                }
                if (!withinTolerance) {
                    if (VarianceResolutionService.isFullResolutionRequired(resolutions)) {
                        throw new ReIMException("error.unable_to_save_resolution", Severity.ERROR, this);
                    } else if ((priceReviewListForm.getSaveAction().equals(
                            PriceReviewListForm.SAVE_ACTION_APPLY_ALL) && !rerouteExists)
                            || (priceReviewListForm.getResolutionDetails() != null
                                    && priceReviewListForm.getResolutionDetails().length != 1

                            && rerouteExists))  {
                    	throw new ReIMException("error.resolution_apply_all_within_tolerance_required", Severity.ERROR, this);
                    } else {
                        if (!rerouteExists) {
                            // If none of the actions include a reroute, display
                            // a message to the user that
                            // the discrepancy is only partially resolved
                        	throw new ReIMException("error.variance_not_within_tolerance", Severity.ERROR, this);
                        }
                    }
                } else if (rerouteExists) {
                    // Don't allow rereoute if discrepancy has already been
                    // fully resolved.
                	throw new ReIMException("error.no_reroute_when_variance_zero", Severity.ERROR, this);
                }
            }

            if (priceReviewListForm.getResolutionDetails() != null) {
                double resolutionCost;
                Double currentOrderCost = null;

                if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.CREDIT_MEMO_COST)) {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getDocCost(), currencyCode).doubleValue();
                } else if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.ORDER_COST)) {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue();
                    currentOrderCost = new Double(ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue());
                } else if (priceReviewListForm.getSelectedCost().equals(
                        PriceReviewListForm.INVOICE_COST)) {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getDocCost(), currencyCode).doubleValue();
                    currentOrderCost = new Double(ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue());
                } else // other cost
                {
                    resolutionCost = ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getOtherCost(), currencyCode).doubleValue();
                    currentOrderCost = new Double(ReIMMoney.parseCurrencyString(
                            priceReviewListForm.getCurrentOrdCost(), currencyCode).doubleValue());
                }

                if (priceReviewListForm.getReceipts() == null
                        || priceReviewListForm.getReceipts().size() == 0) {
                    Receipt[] receipts = ServiceFactory.getReceiptService()
                            .selectReceiptsFromInvoiceOrder(priceReviewListForm.getOrderId(),
                                    priceReviewListForm.getLocation(), false);
                    ArrayList receiptIds = new ArrayList(receipts.length);
                    for (int i = 0; i < receipts.length; i++) {
                        receiptIds.add(receipts[i].getReceiptId());
                    }
                    priceReviewListForm.setReceipts(receiptIds);
                }

                varianceResolutionService.saveSelectedResolutionsAndAmount(
                        resolutions,
                        fullDocument,
                        withinTolerance,
                        Long.parseLong(priceReviewListForm.getSelectedCostDiscrepancyId()),
                        Resolution.TYPE_COST,
                        resolutionCost,
                        priceReviewListForm.getSaveAction().equals(

                        PriceReviewListForm.SAVE_ACTION_APPLY_ALL),
                        currentOrderCost,
                        new Double(ReIMMoney.parseCurrencyString(priceReviewListForm.getDocCost(), currencyCode).doubleValue()),
                        outstandingVariance,
                        priceReviewListForm.getReceipts(), false);
                priceReviewListForm.setReceipts(null);
            }
 	}
	
	private String getSelectedCost(SmrAutoResolutionCandidate candidate) throws ReIMException {
		//Works out which cost should be selected to corresponds to the resolution reason.
		if (candidate.getAction().equals(ResolutionMerchandiseInvoice.RCA)) {
        	return PriceReviewListForm.INVOICE_COST;
        } else if (candidate.getAction().equals(ResolutionMerchandiseInvoice.CBC)) {
        	if (candidate.isInFavorOfSupplier()) {
        		return PriceReviewListForm.ORDER_COST;
        	} else {
        		throw new ReIMException("Cost resolution action " + candidate.getAction() + " only supports cost discrepancy in favour of supplier. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this); 
        	}
        } else {
        	throw new ReIMException("Cost resolution action " + candidate.getAction() + " is not supported. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this);
        }
	}
	
	private void priceReviewCostSelectionLoad(PriceReviewListForm priceReviewListForm) throws ReIMException {
		// Mimics server behaviour when user clicks next on cost selection screen 
		// (extracted from PriceReviewCostSelectionLoadUIService.priceReviewCostSelectionLoad which is what the PriceReviewCostSelectionLoadAction calls).
        String item = priceReviewListForm.getSelectedItem();
        for (int i = 0; i < priceReviewListForm.getPriceReviewDetail().length; i++) {
            if (item.equals(priceReviewListForm.getPriceReviewDetail()[i].getItem())) {
                priceReviewListForm
                        .setSelectedItemDesc(priceReviewListForm.getPriceReviewDetail()[i]
                                .getItemDesc());
                priceReviewListForm.setCurrentOrdCost(String.valueOf(priceReviewListForm.getPriceReviewDetail()[i].getCurrentOrderCost().toString()));
                priceReviewListForm.setDocCost(String.valueOf(priceReviewListForm.getPriceReviewDetail()[i].getDocumentCost()));
                priceReviewListForm.setResolutionCost(priceReviewListForm.getPriceReviewDetail()[i].getResolutionCostFormatted());
                priceReviewListForm.setSelectedDebitMemoReasonCode(priceReviewListForm.getPriceReviewDetail()[i].getDebitMemoReasonCode());
                priceReviewListForm.setSelectedCostDiscrepancyId(String.valueOf(priceReviewListForm.getPriceReviewDetail()[i].getCostDiscrepancyId()));
                break;
            }
        }
        
        if (priceReviewListForm.getResolutionCost() == null
             // Change Code # 137493 per IMS Ticket Syed Qadri : The code should be checking for zero otherwise it aborts.
                //|| Double.parseDouble(priceReviewListForm.getResolutionCost()) == 0 
                || priceReviewListForm.getResolutionCost().equals("0.00")
                || priceReviewListForm.getResolutionCost().length() == 0
                || priceReviewListForm.getResolutionCost().equals(priceReviewListForm.getCurrentOrdCost())) {
            priceReviewListForm.setSelectedCost(PriceReviewListForm.ORDER_COST);
            priceReviewListForm.setOtherCost(null);
        } else if (priceReviewListForm.getResolutionCost().equals(priceReviewListForm.getDocCost())) {
            priceReviewListForm.setSelectedCost(PriceReviewListForm.INVOICE_COST);
            priceReviewListForm.setOtherCost(null);
        } else {
           // throw new ReIMException("The error is now " + priceReviewListForm.getResolutionCost() + "Auto resolution can only handle selected costs of either ORDER or INVOICE.", Severity.ERROR, this);
             throw new ReIMException("Auto resolution can only handle selected costs of either ORDER or INVOICE.", Severity.ERROR, this);
        }
	}
	
	private void applyResolution(SmrAutoResolutionCandidate candidate, LOV reasonCode, QuantityReviewListForm quantityReviewForm, QuantityReview quantityReview, QuantityReviewDetail reviewDetail) throws Exception {
		Logger.debug(this, "Would attempt to apply " + reasonCode.getId() + "~" +reasonCode.getDescription()+ "~" +reasonCode.getDescription2()+ " to " + candidate.getKey() + "~" + reviewDetail.getItem());

            String orderNo = candidate.getOrderId();
	        String docId = candidate.getDocId();
            String loc = candidate.getLocation().getLocationId();
            String item = reviewDetail.getItem();
            double i = 0.00;
            String favorOf;
	                 
	    i =  ServiceFactory.getDiscrepancyService().getQtyDisc(docId, orderNo, loc, reviewDetail.getItem()) ;
	    if (i < 0.00 ) {
//	        candidate.setInFavorOf("SMR"); 
	        favorOf = "SMR";
	    } else {
//	        candidate.setInFavorOf("SUP"); 
	        favorOf = "SUP";
	    }
	    System.out.println( "in AutoresolutionService applyresolution Qty" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf +  " oldfavor " + candidate.getInFavorOf() + " i " + i );
	    if (!candidate.getInFavorOf().equalsIgnoreCase(favorOf) ) {
	    	candidate.setInFavorOf(favorOf); 
//		    ImReasonCodesRow[] row = ServiceFactory.getDiscrepancyService().getReasonAction(favorOf,"Y", i);
	            
            if (candidate.getAction().equalsIgnoreCase("CBQ") ) {
            	if (favorOf.equalsIgnoreCase("SMR")) {
                    candidate.setAction("SR");
                    candidate.setReasonCodeId("1004");
             	} else {
                    candidate.setAction("RUA");
                    candidate.setReasonCodeId("1005");
             	}
            } else if (candidate.getAction().equalsIgnoreCase("RUA") ) {
                candidate.setAction("CBQ");
                candidate.setReasonCodeId("1003");
            } else if (candidate.getAction().equalsIgnoreCase("SR") ) {
            	if (favorOf.equalsIgnoreCase("SUP")) {
                   candidate.setAction("CBQ");
                   candidate.setReasonCodeId("1003");
            	}
            }
		    
		    Logger.debug(this,"in AutoresolutionService applyresolution Qty" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
	    	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + i );

//	        candidate.setAction(row[0].getAction());
//	        candidate.setReasonCodeId(row[0].getReasonCodeId());	    	
	    }
        if (Math.abs(candidate.getVariance()) <= 2.00 ) {
            candidate.setAction("RUA");
            candidate.setReasonCodeId("1005");
        } 
	    Logger.debug(this,"in AutoresolutionService applyresolution Qty" + candidate.getAction() + " reason " + candidate.getReasonCodeId() );
	    System.out.println( "After in AutoresolutionService applyresolution Qty" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + i );

//            if (Math.abs(candidate.getVariance()) < 2.00 ) {
//                candidate.setAction("RUA");
//               candidate.setReasonCodeId("1005");
//           }  else if ((Math.abs(candidate.getVariance()) > 2.00 && Math.abs(candidate.getVariance()) <= 50.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SMR")){
//               candidate.setAction("SR");
//               candidate.setReasonCodeId("1004");
//           }  else if ((Math.abs(candidate.getVariance()) > 2.00 && Math.abs(candidate.getVariance()) <= 15.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SUP")){
//                candidate.setAction("CBQ");
//               candidate.setReasonCodeId("1003");
//           }  else if ((Math.abs(candidate.getVariance()) > 2.00 && Math.abs(candidate.getVariance()) <= 50.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SUP")){
//               candidate.setAction("CBQ");
//               candidate.setReasonCodeId("1003");
//           }

//             if (Math.abs(i) < 2.00 ) {
//                  candidate.setAction("RUA");
//                  candidate.setReasonCodeId("1005");
//             }  else if ((Math.abs(i) > 2.00 && Math.abs(i) <= 50.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SMR")){
//                  candidate.setAction("SR");
//                  candidate.setReasonCodeId("1004");
//             }  else if ((Math.abs(i) > 2.00 && Math.abs(i) <= 15.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SUP")){
//                  candidate.setAction("CBQ");
//                  candidate.setReasonCodeId("1003");
//             }  else if ((Math.abs(i) > 2.00 && Math.abs(i) <= 50.00 ) && candidate.getInFavorOf().equalsIgnoreCase("SUP")){
//                  candidate.setAction("CBQ");
//                  candidate.setReasonCodeId("1003");
//             }
            
	    LOV[] reasonCodes = ServiceFactory.getReasonCodesService().getReasonCodes(candidate.getAction(), candidate.getReasonCodeId());
	    reasonCode = reasonCodes[0];
            

		//Check if reason requires if comments (on description 3 of LOV object) if so then fail now
		if ("Y".equals(reasonCode.getDescription3())) {
			throw new ReIMException("Reasons which require comments cannot be used to auto resolve discrepancies. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this);
		}
		//Mimic user selecting an item from the discrepency detail list (quantity_review_list_detail.jsp)
		quantityReviewForm.setItem(reviewDetail.getItem());
		quantityReviewForm.setReceiptQuantity(reviewDetail.getReceiptQuantity());
		quantityReviewForm.setDocumentQuantity(reviewDetail.getDocumentQuantity());
		quantityReviewForm.setQtyDiscrepancyId(reviewDetail.getQtyDiscrepancyId());
        if (quantityReviewForm.getRefDocId() != null && quantityReviewForm.getRefDocId().equals(quantityReviewForm.getDocId())) {
            quantityReviewForm.setDocId(ServiceFactory.getDocumentService().getDocumentIdFromExternalId(quantityReviewForm.getExternalDocId()));
        }        
        quantityReviewQuantitySelectionLoad(quantityReviewForm);
        
        //Mimic user selecting the valid quantity source (quantity_review_qty_selection.jsp)
        quantityReviewForm.setSelectedQuantity(getSelectedQuantity(candidate));
        
        //Mimic use clicking next (quantity_review_qty_selection.jsp)
        quantityReviewCorrectQtySelection(quantityReviewForm);
        
        //Now need to mimic the user setting up the resolution action and other values on the main resolution screen (quantity_review_variance_resolution.jsp)
//        quantityReviewForm.setReasonCodeLOV(reasonCode.getId());
        quantityReviewForm.setReasonCodeLOV(candidate.getReasonCodeId() );
//        quantityReviewForm.setReasonCodeLOVAction(reasonCode.getDescription2());
        quantityReviewForm.setReasonCodeLOVAction(candidate.getAction());
        quantityReviewForm.setReasonCodeLOVActionDesc(reasonCode.getDescription4());
        quantityReviewForm.setCommentRequired("N");
        quantityReviewForm.setHintComment(reasonCode.getDescription5());
        quantityReviewForm.setCommentsExist("N");      
        if (candidate.getAction().equals(ResolutionMerchandiseInvoice.RUA)) {
        	//If there are multiple receipts do not attempt to process the row throw exception (these case should have been filtered out by the driving cursor)
//        	if (quantityReviewForm.getFilteredReceipts() == null || quantityReviewForm.getFilteredReceipts().length != 1) {
//        		throw new ReIMException("Multiple receipts relate to this discrepancy will not attempt to resolve using action " + candidate.getAction(), Severity.ERROR, this);
//        	}
           	System.out.println( "1st CONDITION AutoresolutionService applyresolution Qty" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
    	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + i );

        	quantityReviewForm.setApplyAmount(String.valueOf(quantityReviewForm.getOutstandingQuantityVariance()));
        	quantityReviewForm.setSelectedReceipt(quantityReviewForm.getFilteredReceipts()[0]);
        } else if (candidate.getAction().equals(ResolutionMerchandiseInvoice.SR) ) {
        	if (quantityReviewForm.getFilteredReceipts() == null || quantityReviewForm.getFilteredReceipts().length != 1) {
        		throw new ReIMException("Multiple receipts relate to this discrepancy will not attempt to resolve using action " + candidate.getAction(), Severity.ERROR, this);
        	}
        	System.out.println( "BEFORE SR AutoresolutionService applyresolution Qty" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
    	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + i );
        	quantityReviewSplitReceipt(quantityReviewForm);
        } else {
        	System.out.println( "ELSE CONDITION AutoresolutionService applyresolution Qty" + candidate.getReasonCodeId() + " action " + candidate.getAction() + " docId " + docId
    	    		+ " item " + item + " order " + orderNo + " loc " + loc + " favor " + favorOf + " i " + i );
        	quantityReviewForm.setApplyAmount(String.valueOf(quantityReviewForm.getOutstandingQuantityVariance()));
        }		
		Logger.debug(this, "Applied amount : " + quantityReviewForm.getApplyAmount());
        
		//Now mimic the user clicking the apply button, this just applies values set above to form in such  
		//a way ready for save (quantity_review_variance_resolution.jsp)				
        doQuantityResolutionApply(quantityReviewForm);
		
       //Now mimic the user clicking the save button (quantity_review_variance_resolution.jsp)
		doQuantityResolutionSave(quantityReviewForm);
	}

	private void doQuantityResolutionApply(QuantityReviewListForm quantityReviewForm) throws ReIMException {
		//Extracted from the QuantityReviewVarianceResolutionApplyAction. Note that apply had to different flow for handling Split Receipt
		//resolutions, we have replicated the first flow when we setup the split receipt so only need to consider the final application logic for this case
		VarianceResolution[] previousResolutionList = quantityReviewForm.getResolutionDetails();

        Double applyAmount = null;
		String applyAmountFormatted = null;
		
		//BRN-SplitReceipt Fix-START:
		if (quantityReviewForm.getReasonCodeLOVAction().equals(ResolutionMerchandiseInvoice.SR)) {			
			applyAmount = new Double(quantityReviewForm.getSplitReceiptItem().getQtyMatched());
			applyAmountFormatted = varianceResolutionService.formatAmount(applyAmount.doubleValue(), Resolution.TYPE_QUANTITY, null);			
		
		}else{		
			applyAmount = new Double(ReIMQuantity.parseNumberString(quantityReviewForm.getApplyAmount()).doubleValue());				
			applyAmountFormatted = varianceResolutionService.formatAmount(applyAmount.doubleValue(), Resolution.TYPE_QUANTITY, null);
		}
		//BRN-SplitReceipt Fix-END:
		
		if (quantityReviewForm.getReasonCodeLOVAction().equals(ReasonCode.RECEIVER_UNIT_ADJUSTMENT)) {
			if (quantityReviewForm.getSelectedReceipt() == null || quantityReviewForm.getSelectedReceipt().length() == 0) {
				throw new ReIMException("alert.please_enter_receipt", Severity.ERROR, this);
			}
			double currentQty = varianceResolutionService.getReceiverAdjustmentCurrentQty(quantityReviewForm.getSelectedReceipt(), quantityReviewForm.getItem()).doubleValue();
			if ((currentQty - applyAmount.doubleValue()) < 0) {
				throw new ReIMException("error.receipt_adjustment_to_negative_number", Severity.ERROR, this);
			}

			double otherAdjustedQty = 0;
			VarianceResolution[] appliedResoutions = quantityReviewForm.getResolutionDetails();
			if (appliedResoutions != null) {
				// Search through all of the applied resolutions. If any
				// resolutions exist for
				// either split receipt or
				// receiver unit adjustment and for the specific receipt
				// this action is working
				// with, then the actual
				// quantity available needs to consider these existing
				// pending adjustments.
				// Note: given this is inside the batch only a single resolution should be created as such this logic would not be hit.
				for (int i = 0; i < appliedResoutions.length; i++) {

            if (appliedResoutions[i].getReceiptId() == null ) {
                 appliedResoutions[i].setReceiptId(quantityReviewForm.getSelectedReceipt());
            }
					if ((appliedResoutions[i].getAction().equals(ReasonCode.SPLIT_RECEIPT) 
							|| appliedResoutions[i].getAction().equals(ReasonCode.RECEIVER_UNIT_ADJUSTMENT))
//							&& (appliedResoutions[i].getReceiptId().equals(quantityReviewForm.getSelectedReceipt()) 
//									|| appliedResoutions[i].getReceiptItems()[0].getReceiptId().equals(quantityReviewForm.getSelectedReceipt()))
                                                                        ) {
						otherAdjustedQty = otherAdjustedQty + appliedResoutions[i].getAdjustedAmount().doubleValue();
					}
				}
			}

			// Return an error if the receiver unit adjustment is attempting
			// to adjust the
			// receipt's quantity to be
			// less than what has already been allocated for this
			// resolution.
			if (currentQty - applyAmount.doubleValue() - otherAdjustedQty < 0) {
				throw new ReIMException("error.receipt_adjustment_to_negative_number", Severity.ERROR, this);
			}
		}

		if (quantityReviewForm.checkDupReasonCodes()) {
			throw new ReIMException("error.duplicate_reason_code", Severity.ERROR, this);
		}

		int previousResolutionListLength = (previousResolutionList != null ? previousResolutionList.length : 0);
		ArrayList newResolutionList = new ArrayList();

		for (int i = 0; i < previousResolutionListLength; i++) {
			newResolutionList.add(previousResolutionList[i]);
		}

		// create the variance resolution
		VarianceResolution varianceResolution = quantityReviewListUIService.applyQuantityVarianceResolution(quantityReviewForm,	applyAmount, applyAmountFormatted, null);

		if (quantityReviewForm.getReasonCodeLOVAction().equals(ResolutionMerchandiseInvoice.SR)) {
			varianceResolution.setReceiptItems(new ReceiptItem[] { quantityReviewForm.getSplitReceiptItem() });
		}

		// add it to any existing resolutions
		newResolutionList.add(varianceResolution);

		quantityReviewForm.setResolutionDetails((VarianceResolution[]) newResolutionList.toArray(new VarianceResolution[newResolutionList.size()]));
		quantityReviewForm.resetVarianceApplyFields();

		quantityReviewListUIService.setVarianceValues(quantityReviewForm);
		quantityReviewForm.setVarianceIsZeroOrReroute(discrepancyResolutionUIService.rerouteActionExists(quantityReviewForm.getResolutionDetails()) != null);
		
		Logger.debug(this, "Updated outstanding variance: " + quantityReviewForm.getOutstandingQuantityVariance());
	}

	private void quantityReviewSplitReceipt(QuantityReviewListForm quantityReviewForm) throws ReIMException {
		//Mimic the first branch of logic when a user attempts to apply a Split Receipt resolution reason to a discrepancy
		//Pulled from behaviour of split_receipt.jsp and related actions; SplitReceiptAction and SplitReceiptOk action. 
		AShipSkuBean shipSkuBean = (AShipSkuBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AShipSkuBean);
		Map available = shipSkuBean.getItemQuantityAvailable(quantityReviewForm.getFilteredReceipts(), quantityReviewForm.getItem());
		String receiptId = quantityReviewForm.getFilteredReceipts()[0];
		
		//BRN-SplitReceipt Fix-START
		//logic as if went to Split Receipt screen and its okay action
		double appliedSplitQty = quantityReviewForm.getOutstandingQuantityVariance();
		double availableQty = (Double) available.get(receiptId);
		double receiptQty = Double.parseDouble(quantityReviewForm.getReceiptQuantity());
		double matchedQty = receiptQty - appliedSplitQty;  
		
		//If there was no previous split receipt, then the availableQty retrieved will be same as receivedQty.
		//therefore, the availableQty will be assigned same value as outstandingQty
		if (receiptQty == availableQty){
			availableQty = receiptQty - matchedQty;
		}
		//BRN-SplitReceipt Fix-END

		if (appliedSplitQty <= 0) {
			throw new ReIMException("alert.amount_not_positive_whole", Severity.ERROR, this);
		}
		if (appliedSplitQty > availableQty) {
			throw new ReIMException("error.split_greater_than_available", Severity.ERROR, this);
		}     
		double adjustmentsToQtyAvailable = 0.0;

		VarianceResolution[] appliedResoutions = quantityReviewForm.getResolutionDetails();
		if (appliedResoutions != null) {
		    // Search through all of the applied resolutions. If any resolutions exist
		    // for either split receipt or
		    // receiver unit adjustment and for the specific receipt this action is
		    // working with, then the actual
		    // quantity available needs to consider these existing pending adjustments.
		    for (int i = 0; i < appliedResoutions.length; i++) {
		        if (appliedResoutions[i].getAction().equals(ReasonCode.RECEIVER_UNIT_ADJUSTMENT)
		                && appliedResoutions[i].getResolutionSaved().equals("N")
		                && (appliedResoutions[i].getReceiptId().equals(receiptId) 
		                		|| (appliedResoutions[i].getReceiptItems() != null && appliedResoutions[i].getReceiptItems()[0].getReceiptId().equals(receiptId)))) {
		            adjustmentsToQtyAvailable = adjustmentsToQtyAvailable + appliedResoutions[i].getAdjustedAmount().doubleValue();

		        }
		    }
		}
		// Return an error if the split receipt is attempting to allocate to use a
		// quantity on the receipt
		// which is greater than the quantity available after considering possible
		// quantity adjustments.
		//BRN-SplitReceipt Fix-START
		if ( appliedSplitQty > (availableQty - adjustmentsToQtyAvailable)) {
			throw new ReIMException("error.split_receipt_greater_than_avail_others_applied" + ReIMQuantity.getQuantityString((availableQty - adjustmentsToQtyAvailable)), Severity.ERROR, this);
		}
		//BRN-SplitReceipt Fix-END
		
		ReceiptItem item = new ReceiptItem();
		item.setItemId(quantityReviewForm.getItem());
		item.setReceiptId(receiptId);
		//BRN-SplitReceipt Fix-START
		item.setQtyMatched(matchedQty- adjustmentsToQtyAvailable);
		item.setQtyReceived(matchedQty - adjustmentsToQtyAvailable);
		//BRN-SplitReceipt Fix-END

		quantityReviewForm.setApplyAmount(String.valueOf(appliedSplitQty));
		quantityReviewForm.setSplitReceiptItem(item);
	}

	private void quantityReviewCorrectQtySelection(QuantityReviewListForm quantityReviewForm) throws ReIMException {
		// Extracted from QuantityReviewVarianceResolutionApplyAction
        if (quantityReviewForm.getSelectedQuantity().equalsIgnoreCase(ReIMConstants.OTHER_QUANTITY)) {
               throw new ReIMException("This batch program should not be dealing with OTHER_QUANTITIES", Severity.ERROR, this);
        	// throw new ReIMException(" Error : " + ReIMConstants.OTHER_QUANTITY + "This batch program should not be dealing with OTHER_QUANTITIES", Severity.ERROR, this);
        }

        quantityReviewForm.resetVarianceResolutions();

        Resolution[] varianceResolutions = varianceResolutionService
                .getResolutionActionsForDocItemType(quantityReviewForm.getDocumentType(),
                        Long.parseLong(quantityReviewForm.getDocId()),
                        quantityReviewForm.getItem(), ReasonCode.QUANTITY_DISCREPANCY,
                        quantityReviewForm.getSelectedDebitMemoReasonCode(), null);

        quantityReviewForm.setResolutionDetails(discrepancyResolutionUIService
                .createVarianceResolutions(varianceResolutions));

        quantityReviewListUIService.setVarianceValues(quantityReviewForm);
        quantityReviewListUIService.filterReceipts(quantityReviewForm);
	}
	
	private void doQuantityResolutionSave(QuantityReviewListForm quantityReviewListForm) throws ReIMException {
		//Pulled from QuantityReviewVarianceResolutionSaveAction
		
        String rerouteBusinessRoleId = discrepancyResolutionUIService.rerouteActionExists(quantityReviewListForm.getResolutionDetails());
        boolean rerouteExists = (rerouteBusinessRoleId != null ? true : false);

        Resolution[] resolutions = discrepancyResolutionUIService.createResolutions(quantityReviewListForm.getResolutionDetails());

        Document fullDocument = varianceResolutionService.getDocument(resolutions);
        //BRN-SplitReceipt Fix-START: 
        //If it is a split receipt, then there is no outstanding variance on the invoice item.
        double outstandingVariance = 0;
        
        if(!resolutions[0].getAction().equals(ResolutionMerchandiseInvoice.SR)){        	        	
        	outstandingVariance = quantityReviewListUIService.calculateOutstandingVariance(quantityReviewListForm);
        }
        //BRN-SplitReceipt Fix-END:

        //Checking that resolution is to zero otherwise something has gone wrong
        if (outstandingVariance != 0) {
        	throw new ReIMException("error.variance_not_to_zero", Severity.ERROR, this);
        }

        if (quantityReviewListForm.getResolutionDetails() != null) {
            double resolutionQuantity;

            if (quantityReviewListForm.getSelectedQuantity().equals(QuantityReviewListForm.CREDIT_MEMO_QUANTITY)) {
                throw new ReIMException("This batch program should not be dealing with CREDIT_MEMO_QUANTITIES", Severity.ERROR, this);
            } else if (quantityReviewListForm.getSelectedQuantity().equals(ReIMConstants.RECEIPT_QUANTITY)) {
                String receiptQuantity = "0";
                if (quantityReviewListForm.getReceiptQuantity() != null) {
                    receiptQuantity = quantityReviewListForm.getReceiptQuantity();
                }
                resolutionQuantity = ReIMQuantity.parseNumberString(receiptQuantity).doubleValue();
            } else if (quantityReviewListForm.getSelectedQuantity().equals(
                    ReIMConstants.INVOICE_QUANTITY)) {
                resolutionQuantity = ReIMQuantity.parseNumberString(quantityReviewListForm.getDocumentQuantity()).doubleValue();
            } else { // other quantity
                throw new ReIMException("This batch program should not be dealing with OTHER_QUANTITIES", Severity.ERROR, this);
                //throw new ReIMException("Error INVOICE_QUANTITY : " + ReIMConstants.INVOICE_QUANTITY + "Resolution qty " + resolutionQuantity + "Receipt Qty " + receiptQuantity + "This batch program should not be dealing with OTHER_QUANTITIES", Severity.ERROR, this);
            }

            // collect all receipts used for resolutions
            ArrayList receipts = new ArrayList();
            String[] receiptIDs = quantityReviewListForm.getReceipts();

            for (int i = 0; i < receiptIDs.length; i++) {
                receipts.add(receiptIDs[i]);
            }

            varianceResolutionService.saveSelectedResolutionsAndAmount(resolutions,
                    fullDocument, true,
                    quantityReviewListForm.getQtyDiscrepancyId(), Resolution.TYPE_QUANTITY,
                    resolutionQuantity, false, null, null, outstandingVariance, receipts,
                    false);
        }
	}
	
	private String getSelectedQuantity(SmrAutoResolutionCandidate candidate) throws ReIMException {
		//Works out which quantity should be selected to corresponds to the resolution reason.
		if (candidate.getAction().equals(ResolutionMerchandiseInvoice.CBQ)) {
        	return ReIMConstants.RECEIPT_QUANTITY;
        } else if (candidate.getAction().equals(ResolutionMerchandiseInvoice.RUA)) {
        	return ReIMConstants.INVOICE_QUANTITY;
        } else if (candidate.getAction().equals(ResolutionMerchandiseInvoice.SR)) {
        	if (candidate.isInFavorOfSMR()) {
        		return ReIMConstants.INVOICE_QUANTITY;
        	} else {
        		throw new ReIMException("Quantity resolution action " + candidate.getAction() + " only supports quantity discrepancy in favour of supplier. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this); 
        	}
        } else {
        	throw new ReIMException("Quantity resolution action " + candidate.getAction() + " is not supported. Please check that SMR_IM_TOLERANCE is validly configured.", Severity.ERROR, this);
        }
	}	
	
	private String formatQuantity(double value) throws ReIMException {
        return ReIMQuantity.getQuantityString(value);
    }
	
	private void quantityReviewQuantitySelectionLoad(QuantityReviewListForm quantityReviewListForm) throws ReIMException {
		//Extracted from quantityReviewListUIService.loadQuantityReviewQtySelection(quantityReviewForm) which is called by the QuantityReviewDetailLoadAction
		double totalReceiptQuantity=0.0;
        String item = quantityReviewListForm.getItem(); 
        for (int i = 0; i < quantityReviewListForm.getQuantityReviewDetail().length; i++) {
            if (item.equals(quantityReviewListForm.getQuantityReviewDetail()[i].getItem())) {
                quantityReviewListForm.setItemDesc(quantityReviewListForm.getQuantityReviewDetail()[i].getItemDesc());
                quantityReviewListForm.setReceiptQuantity(quantityReviewListForm.getQuantityReviewDetail()[i].getReceiptQuantity()); 
                if (quantityReviewListForm.getReceiptQuantity() != null 
                		&& !ReIMConstants.EMPTY_STRING.equals(quantityReviewListForm.getReceiptQuantity())) {
                    totalReceiptQuantity=totalReceiptQuantity+(ReIMQuantity.parseNumberString((quantityReviewListForm.getQuantityReviewDetail()[i].getReceiptQuantity()))).doubleValue();
                }
                quantityReviewListForm.setReceiptQuantityTotal(formatQuantity(totalReceiptQuantity));              
                if (quantityReviewListForm.getReceiptQuantity() == null 
                		|| quantityReviewListForm.getReceiptQuantity().equals(
                				ReIMConstants.EMPTY_STRING)) {
                    // a small attempt at I18N use ReIMQuantity that accounts for locale
                    quantityReviewListForm.setReceiptQuantity(ReIMQuantity.getQuantityString(0.0));                    
                }
                quantityReviewListForm.setDocumentQuantity(quantityReviewListForm.getQuantityReviewDetail()[i].getDocumentQuantity());
                quantityReviewListForm.setResolutionQuantity(quantityReviewListForm.getQuantityReviewDetail()[i].getResolutionQuantityFormatted());
                quantityReviewListForm.setSelectedDebitMemoReasonCode(quantityReviewListForm.getQuantityReviewDetail()[i].getDebitMemoReasonCode());
                quantityReviewListForm.setQtyDiscrepancyId(quantityReviewListForm.getQuantityReviewDetail()[i].getQtyDiscrepancyId());
                // break;
            }
        }

        QuantityReviewReceiptQuantities[] quantityReviewReceiptQuantities = ServiceFactory
                .getQuantityReviewService().getReceiptQuantities(quantityReviewListForm.getQtyDiscrepancyId(), item);

        quantityReviewListForm.setQuantityReviewReceiptQuantities(quantityReviewReceiptQuantities);

        // Change Code # per IMS Ticket 137233 Syed Qadri : The code should be checking for zero otherwise it aborts.
        if (quantityReviewListForm.getResolutionQuantity() == null
                //|| Double.parseDouble(quantityReviewListForm.getResolutionQuantity()) == 0
                || quantityReviewListForm.getResolutionQuantity().equals("0")
                || quantityReviewListForm.getResolutionQuantity().length() == 0
                || quantityReviewListForm.getResolutionQuantity().equals(quantityReviewListForm.getReceiptQuantity())) {
            quantityReviewListForm.setSelectedQuantity(ReIMConstants.RECEIPT_QUANTITY);
            quantityReviewListForm.setOtherQuantity(null);
        } else if (quantityReviewListForm.getResolutionQuantity().equals(quantityReviewListForm.getDocumentQuantity())) {
            quantityReviewListForm.setSelectedQuantity(ReIMConstants.INVOICE_QUANTITY);
            quantityReviewListForm.setOtherQuantity(null);
        } else {
                throw new ReIMException("This batch program should not be dealing with OTHER_QUANTITIES", Severity.ERROR, this);
        	//throw new ReIMException("In here get resolution is : " + quantityReviewListForm.getResolutionQuantity() + "get Document Qty " + quantityReviewListForm.getDocumentQuantity()+ "This batch program should not be dealing with OTHER_QUANTITIES", Severity.ERROR, this);
        }
  	}
	
	private void populatePriceReviewList(PriceReviewListForm priceReviewForm) throws ReIMException {
		//Extracted from the PriceReviewListLoadAction
		DiscrepancyCostReview[] costReviewList = ServiceFactory.getPriceReviewService().getCostReviewList();
        priceReviewForm.setPriceReviewList(priceReviewListUIService.convertToPriceReview(costReviewList));
        Logger.debug(this, "Price review list size: " + priceReviewForm.getPriceReviewList().length);
	}
	
    private void populateQuantityReviewList(QuantityReviewListForm quantityReviewForm) throws ReIMException {
    	//Extracted from the QuantityReviewListLoadAction
    	quantityReviewListUIService.setQuantityReviewList(quantityReviewForm);
    	Logger.debug(this, "quantity review list size: " + quantityReviewForm.getQuantityReviewList().length);
	}        
    
    private void loadPriceReviewDetails(PriceReviewListForm priceReviewForm, PriceReview priceReview) throws ReIMException {
    	Logger.debug(this, "Loading price review details: " + priceReview.getDocId());
    	// Code below extracted from logic in PriceReviewDetailLoadAction the locking logic was removed as invoice is already locked by batch	
    	// Mimic user selecting document in list screen (price_review_list.jsp)
    	priceReviewForm.setDocId(Long.toString(priceReview.getDocId()));
    	priceReviewForm.setOrderId(priceReview.getOrderId());
    	priceReviewForm.setLocation(priceReview.getLocation().getLocationId());
    	priceReviewForm.setLocationName(priceReview.getLocation().getEncodedLocationName());
    	priceReviewForm.setDepartment(priceReview.getDepartment());
    	priceReviewForm.setClassId(priceReview.getClassId());
    	priceReviewForm.setSupplier(priceReview.getSupplier());
    	priceReviewForm.setSupplierName(priceReview.getEncodedSupplierName());
    	priceReviewForm.setResolveByDate(priceReview.getResolveByDate());
    	priceReviewForm.setCurrency(priceReview.getCurrency());
    	priceReviewForm.setDocumentType(priceReview.getDocumentType());
    	priceReviewForm.setRoutingDate(priceReview.getRouteDate());
    	priceReviewForm.setCashDiscount(priceReview.getCashDiscount());
    	priceReviewForm.setBusinessRoleId(priceReview.getReviewerGroup());
    	
    	//Extracted from PriceReviewDetailLoadAction    
    	//already checked that is for a merchandise invoice
    	String docId = priceReviewForm.getDocId();
        String deptId = priceReviewForm.getDepartment();
        String deptName = DepartmentService.getDeptName(deptId);
        priceReviewForm.setDeptName(deptName);

        String classId = priceReviewForm.getClassId();
        String className = ClassService.getClassName(classId, deptId);
        priceReviewForm.setClassName(className);

        String orderId = priceReviewForm.getOrderId();
        String locationId = priceReviewForm.getLocation();
        String resolveByDate = priceReviewForm.getResolveByDate();
        String routingDate = priceReviewForm.getRoutingDate();
        String cashDiscount = priceReviewForm.getCashDiscount();
        
        priceReviewForm.setExternalDocId(ServiceFactory.getDocumentService().getExtDocId(docId));

        PriceReviewDetail[] priceReviewDetail = null;
        if (orderId == null || orderId.equals(ReIMConstants.EMPTY_STRING)) { 
        	throw new ReIMException("Code.REJRES.INVALID_ORDER_NO", Severity.DEBUG, this); 
        }

        priceReviewDetail = priceReviewListUIService.convertToPriceReviewDetail(
                ServiceFactory.getPriceReviewService().getPriceReviewDetail(orderId, docId,
                        locationId, deptId, classId, resolveByDate, routingDate,
                        cashDiscount, priceReviewForm.getBusinessRoleId()));
        priceReviewForm.setPriceReviewDetail(priceReviewDetail);
        Logger.debug(this, "Number of detail values loaded: " + priceReviewForm.getPriceReviewDetail().length);
    }
    
    private void loadQuantityReviewDetails(QuantityReviewListForm quantityReviewForm, QuantityReview quantityReview) throws ReIMException {
    	Logger.debug(this, "Loading quantity review details: " + quantityReview.getDocId());
    	//Mimic the user selecting a document from the list (quantity_review_list.jsp)
    	quantityReviewForm.setHashCode(quantityReview.hashCode());
    	quantityReviewForm.setDocId(quantityReview.getDocId());
    	//Extracted from QuantityReviewDetailLoadAction
    	quantityReviewListUIService.setQuantityReviewListHeaderAndDetailInfo(quantityReviewForm, ReIMUserContext.getUserRole());
    	Logger.debug(this, "Number of detail values loaded: " + quantityReviewForm.getQuantityReviewDetail().length);
    }    

    
    public void updateCostQty()
             throws ReIMException {
         CallableStatement cstmt = null;
         try {
             Connection conn = TransactionManagerFactory.getInstance().getConnection();
             cstmt = conn
                     .prepareCall("{?=call SMR_REIM_AUTORESOLVE.UPDATE_ORDER_SKU_PRICES(?)}");

             // for lookup
             cstmt.registerOutParameter(1, java.sql.Types.INTEGER ); // return
             // value
             cstmt.registerOutParameter(2, java.sql.Types.VARCHAR); // error
             // message
              cstmt.executeQuery(); 

             int returnValue = cstmt.getInt(1);
             String errorMsg = cstmt.getString(2);
             
             if (returnValue == 1) {
                 throw new SQLException(errorMsg);
             }

         } catch (Exception exception) {
             throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR,
                     exception, this);
         } finally {
             try {
                 if (cstmt != null) {
                     cstmt.close();
                 }
             } catch (Exception exception) {
                 throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR,
                         exception, this);
             }
         }
     }
     
	@Required
	@Autowired
	public void setPriceReviewListUIService(IPriceReviewListUIService priceReviewListUIService) {
		this.priceReviewListUIService = priceReviewListUIService;
	}
	
	@Required
	@Autowired
	public void setQuantityReviewListUIService(IQuantityReviewListUIService quantityReviewListUIService) {
        this.quantityReviewListUIService = quantityReviewListUIService;
    }
	
    @Required
    @Autowired
    public void setSmrAutoResolutionDao(ISmrAutoResolutionDao smrAutoResolutionDao) {
        this.smrAutoResolutionDao = smrAutoResolutionDao;
    }      
    
    @Required
    @Autowired
    public void setDocumentService(IDocumentService documentService) {
        this.documentService = documentService;
    }
    
    @Required
    @Autowired
    public void setDiscrepancyResolutionUIService(IDiscrepancyResolutionUIService discrepancyResolutionUIService) {
        this.discrepancyResolutionUIService = discrepancyResolutionUIService;
    }

    @Required
    @Autowired
    public void setVarianceResolutionService(IVarianceResolutionService varianceResolutionService) {
        this.varianceResolutionService = varianceResolutionService;
    }
}
