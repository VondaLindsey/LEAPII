package smr.retek.reim.services;

import oracle.retail.reim.data.TransactionManagerFactory;

import com.retek.reim.foundation.rms12.ItemBean;
import com.retek.reim.foundation.rms12.OrderBean;
import com.retek.reim.foundation.rms12.SupplierBean;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.ui.lov.IKeyValue;
import com.retek.reim.ui.lov.ItemLOV;

public class SmrItemSupplierService {

	public static IKeyValue[] selectItems(String supplierId, String orderNo, String invoiceId, String itemId, String partialDescription) throws ReIMException {
        try {
            TransactionManagerFactory.getInstance().start();
            // If the supplier passed in is a supplierSiteId, we need to translate it to a supplier
            if (supplierId != null && !supplierId.equals("")) {
            	String supplierParent = new SupplierBean().getSupplierParent(supplierId);
            	supplierId = (supplierParent != null && !supplierParent.equals("")) ? supplierParent : supplierId;
            }
            else {
                // If there was no supplier, but orderNo is passed in, find the supplier from the order
            	if (orderNo != null && !orderNo.equals("")) {
            		supplierId = new OrderBean().selectSupplier(orderNo);
                	String supplierParent = new SupplierBean().getSupplierParent(supplierId);
                	supplierId = (supplierParent != null && !supplierParent.equals("")) ? supplierParent : supplierId;
                	orderNo = null;		// this lets selectItemsForOrder find all items that appear on any order from the supplier
            	}
            	// We do not handle the situation when only the invoceId is passed in, because we can only translate it using the reject table, 
            	// where the data is known to be incorrect. If it becomes a requirement, get the supplier from im_edi_reject_doc_head, keeping
            	// in mind that one invoiceId may map to more than one supplier.
            }
            
            // If the user did not provide a partial description, with put 'whatever' in it
            if (partialDescription == null || partialDescription.length() == 0) {
                partialDescription = "%";
            }
            ItemLOV[] items = new ItemBean().selectItemsForOrder(itemId, partialDescription, supplierId, orderNo, "true");

            return items;
        } catch (ReIMException e) {
            throw (e);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }
}
