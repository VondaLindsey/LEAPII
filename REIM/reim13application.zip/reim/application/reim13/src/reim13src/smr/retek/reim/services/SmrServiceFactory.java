package smr.retek.reim.services;

import oracle.retail.reim.services.InjectedFactory;

import org.springframework.beans.factory.annotation.Autowired;

import com.retek.reim.services.IReasonCodesService;

import smr.retail.reim.services.ISmrEdiRejectService;
import smr.retail.reim.services.ISmrReasonCodesService;
import smr.retail.reim.services.impl.SmrEdiRejectService;
import smr.retail.reim.services.ISmrInvoiceMassCorrectionService;
import smr.retail.reim.services.impl.SmrInvoiceMassCorrectionService;


@InjectedFactory
public class SmrServiceFactory {

    private static ISmrEdiRejectService smrEdiRejectService;
    private static ISmrInvoiceMassCorrectionService smrInvoiceMassCorrectionService;
    private static ISmrReasonCodesService smrReasonCodesService;

    public static ISmrEdiRejectService getSmrEdiRejectService() {
        if (smrEdiRejectService == null) {
            smrEdiRejectService = new SmrEdiRejectService();
        }

        return smrEdiRejectService;
    }

    /**
     * Inject this service with the legacy service, which delegates to the new service where
     * applicable.
     * 
     * @param ediRejectService
     *            the original service
     */
    @Autowired
    public void setSmrEdiRejectService(ISmrEdiRejectService smrEdiRejectServiceParam) {
        SmrServiceFactory.smrEdiRejectService = smrEdiRejectServiceParam;
    }

    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
    public static ISmrInvoiceMassCorrectionService getSmrInvoiceMassCorrectionService() {
        if (smrInvoiceMassCorrectionService == null) {
            smrInvoiceMassCorrectionService = new SmrInvoiceMassCorrectionService();
        }

        return smrInvoiceMassCorrectionService;
    }

    /**
     * Inject this service with the legacy service, which delegates to the new service where
     * applicable.
     * 
     * @param invoiceMassCorrectionService
     *            the original service
     */
    @Autowired
    public void setSmrInvoiceMassCorrectionService(ISmrInvoiceMassCorrectionService smrInvoiceMassCorrectionServiceParam) {
        SmrServiceFactory.smrInvoiceMassCorrectionService = smrInvoiceMassCorrectionServiceParam;
    }
    
    @Autowired
    public void setSmrReasonCodeService(ISmrReasonCodesService smrReasonCodesService) {
    	SmrServiceFactory.smrReasonCodesService = smrReasonCodesService;
    }
    
    public static ISmrReasonCodesService getSmrReasonCodesService() {
    	return SmrServiceFactory.smrReasonCodesService;
    }
    
}
