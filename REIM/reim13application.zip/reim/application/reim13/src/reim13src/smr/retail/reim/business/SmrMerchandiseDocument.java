package smr.retail.reim.business;


public class SmrMerchandiseDocument {

    private String supplierId;
    private String orderNo;
    private String invoiceId;
    private String operationRadio;
    private String oldInvoiceDate;
    private String newInvoiceDate;
    private String oldDueDate;
    private String newDueDate;
    private String oldItem;
    private String newItem;
    private String oldSupplierSiteId;
    private String newSupplierSiteId;

    private String fromInvoiceId;
    private String toInvoiceLOV;
    private String appendInvoice;
    
    private String oldTermsId;
    private String newTermsId;
    private String oldOrderNo;
    private String newOrderNo;
    private String userId;


    public SmrMerchandiseDocument() {
    	
    }

    	public SmrMerchandiseDocument(String supplierId, String orderNo,
			String invoiceId, String operationRadio, String oldInvoiceDate,
			String newInvoiceDate, String oldDueDate, String newDueDate,
			String oldItem, String newItem, String oldSupplierSiteId,
			String newSupplierSiteId, String fromInvoiceId,
			String toInvoiceLOV, String appendInvoice, String oldTermsId,
			String newTermsId, String oldOrderNo, String newOrderNo,
			String userId) {
		super();
		this.supplierId = supplierId;
		this.orderNo = orderNo;
		this.invoiceId = invoiceId;
		this.operationRadio = operationRadio;
		this.oldInvoiceDate = oldInvoiceDate;
		this.newInvoiceDate = newInvoiceDate;
		this.oldDueDate = oldDueDate;
		this.newDueDate = newDueDate;
		this.oldItem = oldItem;
		this.newItem = newItem;
		this.oldSupplierSiteId = oldSupplierSiteId;
		this.newSupplierSiteId = newSupplierSiteId;
		this.fromInvoiceId = fromInvoiceId;
		this.toInvoiceLOV = toInvoiceLOV;
		this.appendInvoice = appendInvoice;
		this.oldTermsId = oldTermsId;
		this.newTermsId = newTermsId;
		this.oldOrderNo = oldOrderNo;
		this.newOrderNo = newOrderNo;
		this.userId = userId;
	}
    	
    public boolean validateUpdateInvoiceHead(){

    	boolean anyUpdateInvHead = false;
    	
         if (this.operationRadio != null && !this.operationRadio.equals("")) {
         	anyUpdateInvHead = true;
         }
         else  if (this.oldInvoiceDate != null && !this.oldInvoiceDate.equals("") && this.newInvoiceDate != null && !this.newInvoiceDate.equals("")) {
          	anyUpdateInvHead = true;
          }
         else  if (this.oldDueDate != null && !this.oldDueDate.equals("") && this.newDueDate != null && !this.newDueDate.equals("")) {
         	anyUpdateInvHead = true;
         }
         else if (this.oldSupplierSiteId != null && !this.oldSupplierSiteId.equals("") && this.newSupplierSiteId != null && !this.newSupplierSiteId.equals("")) {
         	anyUpdateInvHead = true;
         }
         //user can replace the values as long as appendInvoice value is entered. From and To are optional.
         else if (this.appendInvoice != null && !this.appendInvoice.equals("") ) {
         	anyUpdateInvHead = true;
         }
         else if (this.oldTermsId != null && !this.oldTermsId.equals("") && this.newTermsId != null && !this.newTermsId.equals("")) {         	
         	anyUpdateInvHead = true;
         }
         else if (this.oldOrderNo != null && !this.oldOrderNo.equals("") && this.newOrderNo != null && !this.newOrderNo.equals("")) {
         	anyUpdateInvHead = true;
         }
    
    	return anyUpdateInvHead;    	
    }
    
    public boolean validateUpdateInvoiceItem(){
    	boolean anyUpdateInvItem = false;
    	
	   	 if (this.oldItem != null && !this.oldItem.equals("") && this.newItem != null && !this.newItem.equals("")) {
	     	anyUpdateInvItem = true;
	   	 } 
   	 
    	return anyUpdateInvItem;
    }
    
    public boolean validateUpdateInvoiceTerms(){
    	boolean termsUpdateInvHead = false;
    	
    	if (this.oldTermsId != null && !this.oldTermsId.equals("") && this.newTermsId != null && !this.newTermsId.equals("")) {
         	termsUpdateInvHead = true;         	
         }
    	
    	return termsUpdateInvHead;
    }

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getOrderNo() {
		return orderNo;
	}


	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getOperationRadio() {
		return operationRadio;
	}


	public void setOperationRadio(String operationRadio) {
		this.operationRadio = operationRadio;
	}

	public String getOldInvoiceDate() {
		return oldInvoiceDate;
	}

	public void setOldInvoiceDate(String oldInvoiceDate) {
		this.oldInvoiceDate = oldInvoiceDate;
	}

	public String getNewInvoiceDate() {
		return newInvoiceDate;
	}

	public void setNewInvoiceDate(String newInvoiceDate) {
		this.newInvoiceDate = newInvoiceDate;
	}

	public String getOldDueDate() {
		return oldDueDate;
	}

	public void setOldDueDate(String oldDueDate) {
		this.oldDueDate = oldDueDate;
	}

	public String getNewDueDate() {
		return newDueDate;
	}

	public void setNewDueDate(String newDueDate) {
		this.newDueDate = newDueDate;
	}

	public String getOldItem() {
		return oldItem;
	}

	public void setOldItem(String oldItem) {
		this.oldItem = oldItem;
	}

	public String getNewItem() {
		return newItem;
	}

	public void setNewItem(String newItem) {
		this.newItem = newItem;
	}

	public String getOldSupplierSiteId() {
		return oldSupplierSiteId;
	}

	public void setOldSupplierSiteId(String oldSupplierSiteId) {
		this.oldSupplierSiteId = oldSupplierSiteId;
	}

	public String getNewSupplierSiteId() {
		return newSupplierSiteId;
	}

	public void setNewSupplierSiteId(String newSupplierSiteId) {
		this.newSupplierSiteId = newSupplierSiteId;
	}

	public String getFromInvoiceId() {
		return fromInvoiceId;
	}

	public void setFromInvoiceId(String fromInvoiceId) {
		this.fromInvoiceId = fromInvoiceId;
	}

	public String getToInvoiceLOV() {
		return toInvoiceLOV;
	}

	public void setToInvoiceLOV(String toInvoiceLOV) {
		this.toInvoiceLOV = toInvoiceLOV;
	}

	public String getAppendInvoice() {
		return appendInvoice;
	}

	public void setAppendInvoice(String appendInvoice) {
		this.appendInvoice = appendInvoice;
	}

	public String getOldTermsId() {
		return oldTermsId;
	}

	public void setOldTermsId(String oldTermsId) {
		this.oldTermsId = oldTermsId;
	}

	public String getNewTermsId() {
		return newTermsId;
	}

	public void setNewTermsId(String newTermsId) {
		this.newTermsId = newTermsId;
	}

	public String getOldOrderNo() {
		return oldOrderNo;
	}

	public void setOldOrderNo(String oldOrderNo) {
		this.oldOrderNo = oldOrderNo;
	}

	public String getNewOrderNo() {
		return newOrderNo;
	}

	public void setNewOrderNo(String newOrderNo) {
		this.newOrderNo = newOrderNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
     
}
