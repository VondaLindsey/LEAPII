package smr.retek.reim.batch.ediupinv;

import static oracle.retail.reim.business.EdiValidationResult.FAILURE_REJECT_FILE;
import static oracle.retail.reim.business.EdiValidationResult.FAILURE_REJECT_TABLES;
import static oracle.retail.reim.business.EdiValidationResult.VALIDATION_SUCCESS;

import java.util.HashSet;
import java.util.Set;

import oracle.retail.reim.business.EdiItemSource;
import oracle.retail.reim.business.EdiValidationResult;
import oracle.retail.reim.business.Vendor;
import oracle.retail.reim.business.VendorType;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Affirm;
import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.NumberUtils;
import oracle.retail.reim.utils.PatternMatchingUtils;
import oracle.retail.reim.utils.ReimProperties;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.StringUtils;

import smr.retek.reim.business.SmrEdiRejectReasons;
import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;
import smr.retek.reim.services.SmrDocumentService;
import smr.retek.reim.services.SmrServiceFactory;
import smr.retek.reim.services.SmrSupplierService;
import smr.retek.reim.ui.ediRejectDocList.SmrEdiRejectMassCorrectionForm;
import EDU.oswego.cs.dl.util.concurrent.Puttable;

import com.ibm.icu.math.BigDecimal;
import com.retek.merch.utils.ApplicationContext;
import com.retek.merch.utils.RetekException;
import com.retek.merch.utils.UserContext;
import com.retek.reim.batch.BatchUtils;
import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EDIHeaderTax;
import com.retek.reim.batch.ediupinv.EdiDetailAllowance;
import com.retek.reim.batch.ediupinv.EdiDocBulk;
import com.retek.reim.batch.ediupinv.EdiNonMerchDetail;
import com.retek.reim.batch.ediupinv.EdiRecord;
import com.retek.reim.batch.ediupinv.EdiTransactionDetail;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.batch.ediupinv.EdiTransactionTail;
import com.retek.reim.batch.ediupinv.EdiUploadProperties;
import com.retek.reim.batch.ediupinv.threading.EdiTransactionUploadReporter;
import com.retek.reim.business.EdiRejectDocument;
import com.retek.reim.business.EdiRejectReasons;
import com.retek.reim.business.Location;
import com.retek.reim.business.ReIMSystemOptions;
import com.retek.reim.business.Receipt;
import com.retek.reim.business.SupplierGroup;
import com.retek.reim.business.Term;
import com.retek.reim.business.document.Document;
import com.retek.reim.business.document.DocumentItem;
import com.retek.reim.business.document.NonMerchandiseDocument;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.foundation.rms12.PartnerBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.EdiTransactionHeaderValidationService;
import com.retek.reim.services.LocationService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.services.UIFieldValidationService;

import smr.retek.reim.db.SmrImDocHeadAccessExt;

/* THIS FILE HAS BEEN COPIED FROM EdiTransactionHeader AND A FEW LINES MODIFIED */

/**
 * Holds an entire EDI transaction consisting of a transaction header (THEAD), an array of details
 * (TDETL), an array of non-merch records (TNMRC), and a transaction tail (TTAIL). Additionally,
 * each detail record may contain an array of allowance records (TALLW).
 * <p>
 * A transaction is the unit of work used by the EDI upload batch program and also by the EDI reject
 * gui interface. Transactions are also referred to as documents in ReIM.
 */
@SuppressWarnings("deprecation")
public class SmrEdiTransactionHeader extends EdiTransactionHeader implements EDIConstants, Runnable {
    private String recordDescriptor;
    private long lineID;
    private long transactionNumber = 0;
    private String documentType;
    private String vendorDocumentNumber;
    private String vendorType;
    private String vendorID = null;
    private String supplierSiteID = null;
    private String fileVendorID = null;
    private boolean supplierSiteEnabled = false;
    private ReIMDate vendorDocumentDate;
    private Long orderNumber = null;
    private Long location = null;
    private String locationType;
    private String terms;
    private Double termsDiscountPercentage = null;
    private ReIMDate dueDate;
    private String paymentMethod;
    private String currencyCode;
    private Double exchangeRate = null;
    private BigDecimal totalCost = new BigDecimal(0);
    private BigDecimal totalQuantity = new BigDecimal(0);
    private BigDecimal totalDiscount = new BigDecimal(0);
    private BigDecimal totalTaxAmount = new BigDecimal(0);
    private String freightType;
    private String manuallyPaidInd;
    private String multiLocation;
    private String merchType;
    private Long dealId = null;
    private String dealApprovalInd;
    private String rtvInd;

    private String customDocumentReference1;
    private String customDocumentReference2;
    private String customDocumentReference3;
    private String customDocumentReference4;
    private Long crossReferenceDocumentNumber = null;
    private String originalRecord;
    private Long documentId = null;
    // boolean to indicate whether the edi file has supplier site or supplier
    private boolean fileSupplierSiteInd;
    // EdiDownload variables
    private String invoiceNumber;
    private boolean isEdiDownload = false;

    // Each transaction can have multiple details and/or non-merch details
    private EdiNonMerchDetail[] ediNonMerchDetailList = null;
    private EdiTransactionDetail[] ediTransactionDetailList = null;
    private EDIHeaderTax[] ediTaxDetailList = null;

    private BigDecimal detailControlTotalCostSum = new BigDecimal(0);
    private BigDecimal detailControlTotalQuantitySum = new BigDecimal(0);

    private BigDecimal totalTaxAmountFromDetails = new BigDecimal(0);
    private BigDecimal totalTaxAmountFromTTAXS = new BigDecimal(0);

    private EdiTransactionTail ediTransactionTail = null;

    private boolean transactionValid = true;

    private String errorCode = null;

    private String invoiceNumberRegularExpression = null;

    private String errorColumnId = null;
    private String rejectReason = null;
    private Long rejectedDocDetailId = null;

    private final Puttable backgroundQueue;
    private String[] ediUploadArgs = null;
    private EdiDocBulk ediDocBulk = null;
    private String groupId = null;

    private final String SUPPLIER_NEW = "S";

    public final String CREDIT_NOTE_REQUEST_PRICE = "CNRC";
    public final String CREDIT_NOTE_REQUEST_QUANTITY = "CNRQ";
    public final String DEBIT_MEMO_PRICE = "DBMC"; // Price changed to cost
    public final String DEBIT_MEMO_QUANTITY = "DBMQ";

    private EdiTransactionUploadReporter uploadReporter = null;
    Object[] termValidationResults = new Object[3];
    private SmrEdiReportRecord smrEdiReportRecord = null; // SMR OLR ENH31 Inserted
    private boolean smrEdiOnlyReportHardEdits = false;     // SMR OLR ENH31 Inserted
     private Long upcSupp = null;
    // SPring autowired service.
    // private IEdiDocumentService ediDocumentService;

    /**
     * Default constructor. Creates a transaction header with default values.
     */
    public SmrEdiTransactionHeader() {
        backgroundQueue = null;
    }

    /**
     * Constructor used by the EDI reject user interface. Creates a transaction (document) which is
     * to be sent through validation again.
     *
     * @param documentId
     *            distinct ID created by the system
     * @param documentType
     *            type of document (merch, non-merch, credit note, etc.)
     * @param vendorDocumentNumber
     *            document number sent by the vendor. Vendor document numbers must be distinct per
     *            vendor.
     * @param vendorType
     *            either supplier or partner
     * @param vendorID
     *            distinct ID for this vendor in the ReIM system
     * @param vendorDocumentDate
     *            date this document was created
     * @param orderNumber
     *            merchandising system order number for this
     * @param location
     *            ReIM location number identifier
     * @param locationType
     *            either 'S'tore or 'W'arehouse
     * @param terms
     *            payment terms for the document
     * @param termsDiscountPercentage
     *            percentage of the total cost which may be deducted if payed within the terms due
     *            date
     * @param dueDate
     *            date that payment is expected
     * @param paymentMethod
     *            manner in which payment will be made
     * @param currencyCode
     *            currency in which this document is written
     * @param exchangeRate
     *            percentage multiplier used when currencyCode is not the base currency
     * @param totalCost
     *            sum of all costs on this document
     * @param totalQuantity
     *            sum of quantities on this document
     * @param totalDiscount
     *            discount applied to this document
     * @param freightType
     *            method of shippment
     * @param manuallyPaidInd
     *            Y/N indicator specifying if this document has been paid
     * @param multiLocation
     *            Y/N indicator specifying if this invoice is for many locations
     * @param customDocumentReference1
     *            used for client customization
     * @param customDocumentReference2
     *            used for client customization
     * @param customDocumentReference3
     *            used for client customization
     * @param customDocumentReference4
     *            used for client customization
     * @param crossReferenceDocumentNumber
     *            if this document is a credit note, this indicates the document it is crediting
     * @param ediNonMerchDetailList
     *            array of non-merchandise details
     * @param ediTransactionDetailList
     *            array of transaction details which may contain an array of allowances
     * @throws ReIMException
     */
    public SmrEdiTransactionHeader(Long documentId, String documentType, String vendorDocumentNumber,
            String vendorType, String vendorID, ReIMDate vendorDocumentDate, Long orderNumber,
            Long location, String locationType, String terms, Double termsDiscountPercentage,
            ReIMDate dueDate, String paymentMethod, String currencyCode, Double exchangeRate,
            double totalCost, double totalQuantity, double totalDiscount, String freightType,
            String paidInd, String multiLocation, String merchType, Long dealId,
            String dealApprovalInd, String rtvInd, String customDocumentReference1,
            String customDocumentReference2, String customDocumentReference3,
            String customDocumentReference4, Long crossReferenceDocumentNumber,
            EdiNonMerchDetail[] ediNonMerchDetailList,
            EdiTransactionDetail[] ediTransactionDetailList, long newGroupId) {
        this.documentId = documentId;
        this.documentType = documentType;
        this.vendorDocumentNumber = vendorDocumentNumber;
        this.vendorType = vendorType;
        this.vendorID = vendorID;
        this.vendorDocumentDate = vendorDocumentDate;
        this.orderNumber = orderNumber;
        this.location = location;
        this.locationType = locationType;
        this.terms = terms;
        this.termsDiscountPercentage = termsDiscountPercentage;
        this.dueDate = dueDate;
        this.paymentMethod = paymentMethod;
        this.currencyCode = currencyCode;
        this.exchangeRate = exchangeRate;
        this.totalCost = new BigDecimal(totalCost);
        this.totalCost = this.totalCost.setScale(4, BigDecimal.ROUND_HALF_UP);
        this.totalQuantity = new BigDecimal(totalQuantity);
        if (!this.totalQuantity.toString().equals(this.totalQuantity.toBigInteger().toString())) {
            this.totalQuantity = this.totalQuantity.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
        }
        this.totalDiscount = new BigDecimal(totalDiscount);
        this.totalDiscount = this.totalDiscount.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
        this.freightType = freightType;
        this.manuallyPaidInd = paidInd;
        this.multiLocation = multiLocation;
        this.merchType = merchType;
        this.dealId = dealId;
        this.rtvInd = rtvInd;
        this.dealApprovalInd = dealApprovalInd;
        this.customDocumentReference1 = customDocumentReference1;
        this.customDocumentReference2 = customDocumentReference2;
        this.customDocumentReference3 = customDocumentReference3;
        this.customDocumentReference4 = customDocumentReference4;
        this.crossReferenceDocumentNumber = crossReferenceDocumentNumber;
        this.ediNonMerchDetailList = ediNonMerchDetailList;
        this.ediTransactionDetailList = ediTransactionDetailList;
        backgroundQueue = null;
        if (newGroupId == Long.MIN_VALUE) {
            this.groupId = null;
        } else {
            this.groupId = String.valueOf(groupId);
        }

    }

    public SmrEdiTransactionHeader(Long documentId, String documentType, String vendorDocumentNumber,
            String vendorType, String vendorID, ReIMDate vendorDocumentDate, Long orderNumber,
            Long location, String locationType, String terms, Double termsDiscountPercentage,
            ReIMDate dueDate, String paymentMethod, String currencyCode, Double exchangeRate,
            double totalCost, double totalQuantity, double totalDiscount, String freightType,
            String paidInd, String multiLocation, String merchType, Long dealId,
            String dealApprovalInd, String rtvInd, String customDocumentReference1,
            String customDocumentReference2, String customDocumentReference3,
            String customDocumentReference4, Long crossReferenceDocumentNumber,
            EdiNonMerchDetail[] ediNonMerchDetailList,
            EdiTransactionDetail[] ediTransactionDetailList, long newGroupId, String supplierSiteID) {

        this(documentId, documentType, vendorDocumentNumber, vendorType, vendorID,
                vendorDocumentDate, orderNumber, location, locationType, terms,
                termsDiscountPercentage, dueDate, paymentMethod, currencyCode, exchangeRate,
                totalCost, totalQuantity, totalDiscount, freightType, paidInd, multiLocation,
                merchType, dealId, dealApprovalInd, rtvInd, customDocumentReference1,
                customDocumentReference2, customDocumentReference3, customDocumentReference4,
                crossReferenceDocumentNumber, ediNonMerchDetailList, ediTransactionDetailList,
                newGroupId);

        this.supplierSiteID = supplierSiteID;

    }

    /**
     * Constructor used by the EDI upload program. Receives a record created from one line of the
     * EDI flat file. Parses the string contained in the record into the object variables and
     * validates the data types. Any validation errors will result in this transaction being written
     * to the error file.
     *
     * @param ediRecord
     *            object created when EDI upload program reads one line from the EDI file
     * @param transactionCounter
     *            number indicating which transaction this is expected to be, used for validation
     * @throws ReIMException
     */
    // SMR OLR ENH31 Removed
    /*public SmrEdiTransactionHeader(EdiRecord ediRecord, Puttable b, String[] args,
            EdiDocBulk ediDocBulk) throws ReIMException {*/
    // SMR OLR ENH31 Inserted
    @SuppressWarnings("unused")
	public SmrEdiTransactionHeader(EdiRecord ediRecord, Puttable b, String[] args,
                EdiDocBulk ediDocBulk) throws ReIMException {
        // Local strings to hold data until parsing of numbers
        String transactionNumberString;
        String vendorDocumentDateString;
        String orderNumberString;
        String locationString;
        String dueDateString;
        String exchangeRateString;
        String totalCostString;
        String totalTaxAmountString;
        String totalQuantityString;
        String totalDiscountString;
        String crossReferenceDocumentNumberString;
        String dealIdString;
        String totalCostSignInd, totalTaxAmountSignInd, totalQtySignInd, totalDiscountSignInd;
        short errInd = 0;
        // Fetch values from record
        this.recordDescriptor = ediRecord.getRecordDescriptor();
        this.lineID = ediRecord.getLineID();

        // Parse the rest of the record
        transactionNumberString = ediRecord.takeFromRecord(LEN_TRANSACTION_NUMBER).trim();
        this.documentType = ediRecord.takeFromRecord(LEN_DOCUMENT_TYPE).trim();
        if (this.documentType.equals(DEBIT_MEMO_PRICE)) {
            this.documentType = Document.DEBIT_MEMO_PRICE;
        } else if (this.documentType.equals(DEBIT_MEMO_QUANTITY)) {
            this.documentType = Document.DEBIT_MEMO_QUANTITY;
        } else if (this.documentType.equals(CREDIT_NOTE_REQUEST_PRICE)) {
            this.documentType = Document.CREDIT_NOTE_REQUEST_PRICE;
        } else if (this.documentType.equals(CREDIT_NOTE_REQUEST_QUANTITY)) {
            this.documentType = Document.CREDIT_NOTE_REQUEST_QUANTITY;
        }
        this.vendorDocumentNumber = ediRecord.takeFromRecord(LEN_VENDOR_DOCUMENT_NUMBER).trim()
                .toUpperCase(UserContext.getLocale());
        this.groupId = ediRecord.takeFromRecord(LEN_GROUP_ID).trim().toUpperCase(
                UserContext.getLocale());
        this.vendorType = ediRecord.takeFromRecord(LEN_VENDOR_TYPE).trim();
        // the compilant with RMS data
        if (this.vendorType.equals(SUPPLIER_NEW)) {
            this.vendorType = Vendor.SUPPLIER;
        }

        // Strip the leading zeros before inserting the vendor ID.
        String tempVendorId = ediRecord.takeFromRecord(LEN_VENDOR_ID).trim();

        vendorDocumentDateString = ediRecord.takeFromRecord(LEN_DATE).trim();
        orderNumberString = ediRecord.takeFromRecord(LEN_ORDER_NUMBER).trim();
        locationString = ediRecord.takeFromRecord(LEN_LOCATION).trim();
        this.locationType = ediRecord.takeFromRecord(LEN_LOCATION_TYPE).trim();
        this.terms = ediRecord.takeFromRecord(LEN_TERMS).trim();
        dueDateString = ediRecord.takeFromRecord(LEN_DATE).trim();
        this.paymentMethod = ediRecord.takeFromRecord(LEN_PAYMENT_METHOD).trim();
        this.currencyCode = ediRecord.takeFromRecord(LEN_CURRENCY_CODE).trim();
        exchangeRateString = ediRecord.takeFromRecord(LEN_EXCHANGE_RATE).trim();
        totalCostSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalCostString = ediRecord.takeFromRecord(LEN_COST).trim();

        totalTaxAmountSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalTaxAmountString = ediRecord.takeFromRecord(LEN_TAX_AMOUNT).trim();

        totalQtySignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalQuantityString = ediRecord.takeFromRecord(LEN_QUANTITY).trim();
        totalDiscountSignInd = ediRecord.takeFromRecord(LEN_IND).trim();
        totalDiscountString = ediRecord.takeFromRecord(LEN_TOTAL_DISCOUNT).trim();
        this.freightType = ediRecord.takeFromRecord(LEN_FREIGHT_TYPE).trim();
        this.manuallyPaidInd = ediRecord.takeFromRecord(LEN_IND).trim();
        this.multiLocation = ediRecord.takeFromRecord(LEN_IND).trim();
        this.merchType = ediRecord.takeFromRecord(LEN_IND).trim();
        dealIdString = ediRecord.takeFromRecord(LEN_DEAL_ID).trim();
        this.dealApprovalInd = ediRecord.takeFromRecord(LEN_IND).trim();
        this.rtvInd = ediRecord.takeFromRecord(LEN_IND).trim();
        this.customDocumentReference1 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        this.customDocumentReference2 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        this.customDocumentReference3 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        this.customDocumentReference4 = ediRecord.takeFromRecord(LEN_CUSTOM_DOCUMENT_REFERENCE)
                .trim();
        crossReferenceDocumentNumberString = ediRecord.takeFromRecord(
                LEN_CROSS_REFERENCE_DOCUMENT_NUMBER).trim();

        this.originalRecord = ediRecord.getOriginalRecord();

        backgroundQueue = b;
        ediUploadArgs = args;
        this.ediDocBulk = ediDocBulk;
//        Object[] termValidationResults = new Object[3];

        invoiceNumberRegularExpression = ReimProperties.DOCUMENT_NUMBER_VALIDATION_REGEXPR;

        // Pre-validation transformation to handle RMS 10 style consignment
        // indication
        if (nullSafeEquals(merchType, ReIMConstants.YES)) {
            this.merchType = ReIMConstants.MERCH_TYPE_CONSIGNMENT;
        } else if (nullSafeEquals(merchType, ReIMConstants.NO)) {
            this.merchType = null;
        }

        // Validation
        // Anil P
        // Header Hardedit validations are
        // Invalid PO Number code 10
        // Invalid Loc       code 18
        // Invalid Supplier for PO 15
        // Invalid supplier site

       /*  Code         DESC 
         10           Invalid PO Number
         11           Invalid Terms code
         12           Invoice No. Blank
         13           Invoice Date Invalid
         14           Ship Date Invalid
         15           EDI Vendor Diff in PO File
         16           Tot Inv. Not Equal to Extended Items
         17           Tot Inv. Amt Equal to Zero
         18           Invalid Store Number
         19           Invalid SKU
         20           Invalid UPC
         99           Invoice Accepted
*/

      // Check for TrueDuplicates
       fileVendorID=tempVendorId; 
     if (totalCostString.length() == 0) {
  	 errInd = 1;
      String key = "error.batch.field_not_null";
      String field = ReIMI18NUtility.getMessage("batch.field.total_cost");
      String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
              String.valueOf(this.lineID)};
      Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
      this.transactionValid = false;
      smrEdiOnlyReportHardEdits = true;
      createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
  } else {
      try {
      	 Long number1 = new Long(totalCostString);
          this.setTotalCost(BatchUtils.getDouble(totalCostString, PRECISION4));
          if ( number1 == 0
                  && !this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
          	  errInd = 1;
              String key = "error.batch.field_not_zero";
              String field = ReIMI18NUtility.getMessage("batch.field.total_cost");
              String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                      String.valueOf(this.lineID)};
              Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
              this.transactionValid = false;
              smrEdiOnlyReportHardEdits = true;
              createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
          }
      } catch (ReIMException e) {
      	errInd = 1;
          String key = "error.batch.invalid_number_format";
          String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalCostString,
                  String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                  this.vendorDocumentNumber};
          Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
          this.transactionValid = false;
          smrEdiOnlyReportHardEdits = true;
          createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
      }
  }       
     if (totalQuantityString.length() > 0) {
         try {
            Long number = new Long(totalQuantityString);
            this.setTotalQuantity(BatchUtils.getDouble(totalQuantityString, PRECISION4));
         }catch (NumberFormatException nfe) {
      	   errInd = 1;
             String key = "error.batch.invalid_number_format";
             String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalQuantityString,
                     String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                     this.vendorDocumentNumber};
             Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
             this.transactionValid = false;
             smrEdiOnlyReportHardEdits = true;
             createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
         }
     } 
 
//
//       if ( SmrServiceFactory.getSmrEdiRejectService().rejectTrueDuplicates (this.vendorDocumentNumber, 
//                                                                             orderNumberString, 
//                                                                              BatchUtils.getDouble(totalCostString, PRECISION4) , 
//                                                                              tempVendorId)  ) {
//                Logger.errorKey(SmrEdiTransactionHeader.class,
//                           "error.batch.vendor_doc_duplicate", new String[] {
//                           EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID), tempVendorId, this.vendorDocumentNumber,
//                           orderNumberString, totalCostString });                                                                              
//               this.transactionValid = false;
//               smrEdiOnlyReportHardEdits = true;
//               createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUP_INVOICE, null, null);
//       } // End Mod Anil
      
             if (this.terms.length() == 0) {
            	 this.terms= "D";
             }
             termValidationResults = EdiTransactionHeaderValidationService.validateTerm(this.terms);
             if (!((Boolean) termValidationResults[0]).booleanValue()) {
                 String key = ReIMI18NUtility.getMessage("label.terms");
                     Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
                             new String[] { key, this.terms, String.valueOf(this.lineID),
                         String.valueOf(this.orderNumber + ""),
                         String.valueOf(this.vendorDocumentNumber + ""), String.valueOf(this.terms)});
                  this.transactionValid = false;
                  smrEdiOnlyReportHardEdits = true;
                  createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TERM_CODE, null, null);
              }
      
        String fieldName = null;
        SupplierGroup supplierGroup = null;
        // Order Number
        if (orderNumberString.length() > 0) {
            try {
                this.orderNumber = new Long(orderNumberString);
                // Anil P added the following code
                long vendorId = Long.parseLong(tempVendorId);
                this.vendorID = Long.toString(vendorId);

            } catch (NumberFormatException nfe) {
            	errInd = 1;
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, orderNumberString,
                        String.valueOf(this.lineID), tempVendorId,
                        this.vendorDocumentNumber};
                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
                smrEdiOnlyReportHardEdits = true;
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PO, null, null);
            }
            if (errInd == 0) {
                if (! SmrServiceFactory.getSmrEdiRejectService().validateOrder( orderNumberString ) ) {
                	errInd = 1;
                    String key = "error.invalid_order_number";
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, vendorID,
                                  String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                                  this.vendorDocumentNumber};
                    Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                    this.transactionValid = false;
                    smrEdiOnlyReportHardEdits = true;
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PO, null, null);
            } // End Mod Anil	
            	System.out.println(" before  ServiceFactory.getOrderService().validateOrder( orderNumber, vendorID");
                  if (! ServiceFactory.getOrderService().validateOrder( orderNumber, vendorID ) && errInd != 1 ) {
                    	errInd = 1;
                        String key = "error.batch.vendor_different_than_in_order";
                        String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, vendorID,
                                  String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                                  this.vendorDocumentNumber};
                        Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                        this.transactionValid = false;
                        smrEdiOnlyReportHardEdits = true;
                        createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_DIFF, null, null);
                  } // End Mod Anil
            }
        }
 
//      Vendor ID
        try {
        	long vendorId = Long.parseLong(tempVendorId);
        	this.vendorID = Long.toString(vendorId);
        	boolean isSupplierSiteIndOn = false;
        	String supplierParent = null;

        	isSupplierSiteIndOn = ServiceFactory.getSystemOptionsService().getSystemOptions()
        	.isSupplierSiteInd();
        	if (vendorType.equalsIgnoreCase(Document.SUPPLIER) && isSupplierSiteIndOn) {
        		supplierParent = ServiceFactory.getVendorService().getSupplierParent(this.vendorID);
        		this.supplierSiteID = this.vendorID;
        		this.vendorID = supplierParent;
                        if( vendorID == null) {
                            this.vendorID = this.supplierSiteID;
                        }

//        		if( vendorID == null)
//        		{
//                            String key = "error.batch.invalid_field";
//        	            String field = ReIMI18NUtility.getMessage("batch.field.vendor_id");
//        	            String[] parameters = new String[] { field, tempVendorId,
//        	                    String.valueOf(this.lineID),String.valueOf(this.orderNumber),this.vendorDocumentNumber};
//        	            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//
//        			this.transactionValid = false;
//        		        this.vendorID = this.supplierSiteID;
//        			createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_ID, null, null);
//        		}

        	}

        }
        catch (Exception e) {

        	this.vendorID=null;
        	errInd = 1;
        	String key = "error.batch.invalid_number_format";
        	String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, tempVendorId,
        			String.valueOf(this.lineID),String.valueOf(this.orderNumber),
        			this.vendorDocumentNumber};
        	Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
        	this.transactionValid = false;
        	smrEdiOnlyReportHardEdits = true;
        	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_ID, null, null);
        }
 
        // No validation for Transaction Number at this point - should
        // have been taken care of during inital file sweep.
        try {
            this.transactionNumber = Long.parseLong(transactionNumberString);
        } catch (Exception e) {
            // this would have been caught in the initial file sweep, but just
            // to be safe....
        	this.transactionNumber++;
//            String key = "error.batch.invalid_number_format";
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, transactionNumberString,
//                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                    this.vendorDocumentNumber};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TRAN_NO, null, null);
        }

        // Document Type
        if (this.documentType.length() == 0) {
        	this.documentType = "MRCHI";
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.document_type");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                    this.vendorDocumentNumber};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DOC_TYPE, null, null);
        }

        // Vendor Document Number
        if (this.vendorDocumentNumber.length() == 0) {
        	errInd = 1;
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_NO, null, null);
        }

        // vendor document number must not have leading zero's
        else if (!validNoLeadingZeroString(this.vendorDocumentNumber)) {
        	errInd = 1;
            String key = "error.batch.no_leading_zero";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    this.vendorDocumentNumber, String.valueOf(this.lineID)};
            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_NO, null, null);
        }

        /*
         * Vendor document number will be validated against the regular expression defined in
         * reim.properties. If the property is not specified system will validate for alpha-numeric
         * characters.
         */
        else if (!validateWithPatternString(this.vendorDocumentNumber,
                invoiceNumberRegularExpression)) {
        	errInd = 1;
            String key = "error.batch.alpha_numeric_special_characters_defined_only";
            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
            String allowedCharacters = invoiceNumberRegularExpression != null ? invoiceNumberRegularExpression
                    : PatternMatchingUtils.ALPHA_NUMERIC_CHARACTERS;
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field, allowedCharacters,
                    this.vendorDocumentNumber, String.valueOf(this.lineID)};
            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_NO, null, null);
        }
        // groupId or batchId
        if (StringUtils.isNotBlank(groupId)) {
            try {
                 Long groupIdLong = new Long(groupId);
            } catch (NumberFormatException nfe) {
            	groupId = "999999999";
//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, groupId,
//                        String.valueOf(this.lineID)};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_GROUP, null, null);
            }
        }
        // Vendor Type
        if (this.vendorType.length() == 0) {
        	 this.vendorType = Vendor.SUPPLIER;
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.vendor_type");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                    this.vendorDocumentNumber};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_TYPE, null, null);
        }

        // Vendor Document Date
        if (vendorDocumentDateString.length() == 0) {
            this.vendorDocumentDate = ServiceFactory.getPeriodService().getVDate();
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.vendor_document_date");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                    this.vendorDocumentNumber};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            smrEdiOnlyReportHardEdits = true;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_DATE, null, null);
        } else {
            try {
                this.vendorDocumentDate = BatchUtils.getDate(vendorDocumentDateString);
            } catch (ReIMException e) {
                this.vendorDocumentDate = ServiceFactory.getPeriodService().getVDate();
//                String key = "error.batch.invalid_date_format";
//                String[] parameters = new String[] { String.valueOf(LEN_DATE),
//                        vendorDocumentDateString, String.valueOf(this.lineID),
//                        String.valueOf(this.orderNumber), this.vendorDocumentNumber};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                smrEdiOnlyReportHardEdits = true;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_DATE, null, null);
            }
        }

        // Location
        if (locationString.length() == 0) {
        	errInd = 1;
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("label.location");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                    this.vendorDocumentNumber};
            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_STORE, null, null);
        } else {
            try {
                this.location = new Long(locationString);
                boolean isValidLoc = false;
              // Anil  Added Check valid location here
              
                if (this.location == 901) {
                	isValidLoc = LocationService.validWarehouse(this.location);
                } else {
                	isValidLoc = LocationService.validStore(this.location);
                }
                if (isValidLoc == false) {
                	errInd = 1;
                    String key = "error.batch.invalid_number_format";
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, locationString,
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                            this.vendorDocumentNumber};
                    Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                    this.transactionValid = false;
                    smrEdiOnlyReportHardEdits = true;
                    createSmrEdiReportRecord( SmrEdiRejectReasons.ERROR_STORE, null, null);                        
                }
                // End Check validation code

            } catch (NumberFormatException nfe) {
            	errInd = 1;
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, locationString,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
                        this.vendorDocumentNumber};
                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                this.transactionValid = false;
                smrEdiOnlyReportHardEdits = true;
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_STORE, null, null);
            }

//            if (this.locationType.length() == 0) {
//                String key = "error.batch.location_type_not_null_when_location_not_null";
//                String[] parameters = new String[] { String.valueOf(this.lineID),
//                        String.valueOf(this.orderNumber), this.vendorDocumentNumber};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                smrEdiOnlyReportHardEdits = true;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_LOC_TYPE, null, null);
//            }
        }

        // Terms
        // No file format validation needed at this point.

        // Due Date is same as Ship date
        if (dueDateString.length() > 0) {
            try {
                this.dueDate = BatchUtils.getDate(dueDateString);
            } catch (ReIMException e) {
                this.dueDate = ServiceFactory.getPeriodService().getVDate();
//                String key = "error.batch.invalid_date_format";
//                String[] parameters = new String[] { String.valueOf(LEN_DATE), dueDateString,
//                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                        this.vendorDocumentNumber};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                smrEdiOnlyReportHardEdits = true;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_SHIP_DATE, null, null);
            }
        }

        // Payment Method
        // No file format validation needed at this point.

        // Currency Code
        if (this.currencyCode.length() == 0) {
        	this.currencyCode = ServiceFactory.getCurrencyService().getCurrencyCodeByOrderNo(
                    this.orderNumber.longValue());
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.currency_code");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                    this.vendorDocumentNumber};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_CUR_CODE, null, null);
        }

        // Exchange Rate
        if (exchangeRateString.length() > 0) {
            try {
                this.exchangeRate = new Double(BatchUtils.getDouble(exchangeRateString, PRECISION4));
            } catch (ReIMException e) {
                if (this.orderNumber == null) {
                    this.exchangeRate = new Double(ServiceFactory.getDocumentService().getExchangeRate(
                            null, this.currencyCode, this.vendorDocumentDate));
                } else {
                    AOrderBean orderBean = (AOrderBean) ReIMBeanFactory
                            .getBean(ReIMBeanFactory.AOrderBean);
                    this.exchangeRate = orderBean.getExchangeRate(this.orderNumber.toString());
                }
//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, exchangeRateString,
//                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                        this.vendorDocumentNumber};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_EXCH_RATE, null, null);
            }
        } else // get exchange rate from order if one is provided, otherwise
        // get from currency_rates
        {
            if (this.orderNumber == null) {
                this.exchangeRate = new Double(ServiceFactory.getDocumentService().getExchangeRate(
                        null, this.currencyCode, this.vendorDocumentDate));
            } else {
                AOrderBean orderBean = (AOrderBean) ReIMBeanFactory
                        .getBean(ReIMBeanFactory.AOrderBean);
                this.exchangeRate = orderBean.getExchangeRate(this.orderNumber.toString());
//                this.exchangeRate = new Double(ServiceFactory.getDocumentService().getExchangeRate(
//                        this.orderNumber.toString(), this.currencyCode, this.vendorDocumentDate));
            }
        }

        // Total Cost
//        if (totalCostString.length() == 0) {
//        	 errInd = 1;
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.total_cost");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            smrEdiOnlyReportHardEdits = true;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
//        } else {
//            try {
//            	 Long number = new Long(totalCostString);
//                this.setTotalCost(BatchUtils.getDouble(totalCostString, PRECISION4));
//                if (this.totalCost.doubleValue() == 0
//                        && !this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
//                	errInd = 1;
//                    String key = "error.batch.field_not_zero";
//                    String field = ReIMI18NUtility.getMessage("batch.field.total_cost");
//                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                            String.valueOf(this.lineID)};
//                    Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                    this.transactionValid = false;
//                    smrEdiOnlyReportHardEdits = true;
//                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
//                }
//            } catch (ReIMException e) {
//            	errInd = 1;
//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalCostString,
//                        String.valueOf(this.lineID), String.valueOf(this.orderNumber),
//                        this.vendorDocumentNumber};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                smrEdiOnlyReportHardEdits = true;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_AMT_ZERO, null, null);
//            }
//        }
        // Total CostSign Indicator
        if (totalCostSignInd.length() == 0) {
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            totalCostSignInd= EDIConstants.PLUS_SIGN;
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_COSTSIGN, null, null);
        } else if (!totalCostSignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalCostSignInd.equals(EDIConstants.MINUS_SIGN)) {
//            String key = "error.batch.invalid_field";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { field, totalCostSignInd,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            totalCostSignInd= EDIConstants.PLUS_SIGN;
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_COSTSIGN, null, null);
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.NEGATIVE_SIGN
        else if (totalCostSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalCost = this.totalCost.negate();
        }

        // Total Tax Amount
        if (totalTaxAmountString.length() == 0) {
            this.totalTaxAmount = new BigDecimal(0);
            this.transactionValid = true;
        } else {
            try {
                this.setTotalTaxAmount(BatchUtils.getDouble(totalTaxAmountString, PRECISION4));
            } catch (ReIMException e) {
            	totalTaxAmountString = "0";
                this.setTotalTaxAmount(BatchUtils.getDouble(totalTaxAmountString, PRECISION4));
//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalTaxAmountString,
//                        String.valueOf(this.lineID)};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_TAX_AMT, null, null);
            }
        }

        // Total TaxAmountSign Indicator
        if (totalTaxAmountSignInd.length() == 0) {
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            totalTaxAmountSignInd= EDIConstants.PLUS_SIGN;
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_TAXAMT_IND, null, null);
        } else if (!totalTaxAmountSignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalTaxAmountSignInd.equals(EDIConstants.MINUS_SIGN)) {
//            String key = "error.batch.invalid_field";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { field, totalCostSignInd,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            totalTaxAmountSignInd= EDIConstants.PLUS_SIGN;
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_TAXAMT_IND, null, null);
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.NEGATIVE_SIGN
        else if (totalTaxAmountSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalTaxAmount = this.totalTaxAmount.negate();
        }

   //     SupplierGroup supplierGroup = null;
        if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
            // Total Quantity: if it is null and total header quantity indicator
            // is checked, invalid
            try {
                Long.parseLong(this.vendorID);
                supplierGroup = ServiceFactory.getSupplierGroupService().getSupplierGroup(
                        this.vendorID);
            } catch (NumberFormatException e) {
                supplierGroup = null;
            }
        }

        boolean totalHeaderQtyReqInd = supplierGroup != null ? supplierGroup
                .isTotalHeaderQuantityRequired() : ReimProperties.DOCUMENT_HEADER_QUANTITY_REQUIRED;

        double totalQty = 0;
        try {
            if (totalQuantityString.length() != 0) {
            	Long number = new Long(totalQuantityString);
                totalQty = BatchUtils.getDouble(totalQuantityString, PRECISION4);
            }
        } catch (ReIMException e) {
        	errInd = 1;
            String key = "error.batch.invalid_number_format";
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalQuantityString,
                    String.valueOf(this.lineID)};
            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_QTY, null, null);
        }
        if ((totalQuantityString.length() == 0 || (totalQty == 0)) && totalHeaderQtyReqInd
                && (!this.documentType.equals(Document.NON_MERCHANDISE_INVOICE))) {
        	errInd = 1;
            String key = "error.batch.field_not_null";
            String field = ReIMI18NUtility.getMessage("batch.field.total_quantity");
            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
                    String.valueOf(this.lineID)};
            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            this.transactionValid = false;
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_QTY, null, null);
        } else {
            this.setTotalQuantity(totalQty);
        }
        // Total Qty Sign Indicator
        if (totalQtySignInd.length() == 0) {
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_QTY_IND, null, null);
            totalQtySignInd=EDIConstants.PLUS_SIGN;
        } else if (!totalQtySignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalQtySignInd.equals(EDIConstants.MINUS_SIGN)) {
//            String key = "error.batch.invalid_field";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { field, totalQtySignInd,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
            totalQtySignInd=EDIConstants.PLUS_SIGN;
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_QTY_IND, null, null);
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.MINUS_SIGN
        else if (totalQtySignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalQuantity = this.totalQuantity.negate();
        }

        // Total Discount
        if (totalDiscountString.length() == 0) {
        	totalDiscountString = "0";
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.total_discount");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_DISC, null, null);
        } else {
            try {
                this.setTotalDiscount(BatchUtils.getDouble(totalDiscountString, PRECISION4));
            } catch (ReIMException e) {
            	totalDiscountString = "0";
            	this.setTotalDiscount(BatchUtils.getDouble(totalDiscountString, PRECISION4));

//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, totalDiscountString,
//                        String.valueOf(this.lineID)};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_DISC, null, null);
            }
        }

        // Total Discount Sign Indicator
        if (totalDiscountSignInd.length() == 0) {
        	totalDiscountSignInd = EDIConstants.PLUS_SIGN;
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_DISC_IND, null, null);
        } else if (!totalDiscountSignInd.equals(EDIConstants.PLUS_SIGN)
                && !totalDiscountSignInd.equals(EDIConstants.MINUS_SIGN)) {
        	totalDiscountSignInd = EDIConstants.PLUS_SIGN;
//            String key = "error.batch.invalid_field";
//            String field = ReIMI18NUtility.getMessage("batch.field.sign_indicator");
//            String[] parameters = new String[] { field, totalDiscountSignInd,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_DISC_IND, null, null);
        }
        // We are not going to store the sign indicator, so negate the amount if
        // it is EDIConstants.NEGATIVE_SIGN
        else if (totalDiscountSignInd.equals(EDIConstants.MINUS_SIGN)) {
            this.totalDiscount = this.totalDiscount.negate();
        }

        // Freight Type
        // No file format validation needed at this point.

        // Paid Indicator
        if (this.manuallyPaidInd.length() == 0) {
        	this.manuallyPaidInd = "N";
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.paid_ind");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PAID_IND, null, null);
        }

        // multiLocation indicator
        if (this.multiLocation.length() == 0) {
        	this.multiLocation = "N";
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.multi_loc");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_MULTI_LOC_IND, null, null);
        }

        // deal id
        if (dealIdString.length() > 0) {
            try {
                this.dealId = new Long(dealIdString);
            } catch (NumberFormatException nfe) {
            	this.dealId = null;
//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, dealIdString,
//                        String.valueOf(this.lineID)};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DEAL_ID, null, null);
            }
        }
//
        // rtv ind
        if (this.rtvInd.length() == 0) {
        	this.rtvInd = "N";
//            String key = "error.batch.field_not_null";
//            String field = ReIMI18NUtility.getMessage("batch.field.rtv_ind");
//            String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, field,
//                    String.valueOf(this.lineID)};
//            Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//            this.transactionValid = false;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_RTV_IND, null, null);
        }

        // Custom Document Reference 1
        // No file format validation needed at this point.

        // Custom Document Reference 2
        // No file format validation needed at this point.

        // Custom Document Reference 3
        // No file format validation needed at this point.

        // Custom Document Reference 4
        // No file format validation needed at this point.

        // Cross Reference Document Number
        if (crossReferenceDocumentNumberString.length() > 0) {
            try {
                Long number = new Long(crossReferenceDocumentNumberString);
                if (number.longValue() > 0) {
                    this.crossReferenceDocumentNumber = number;
                }

            } catch (NumberFormatException nfe) {
            	 this.crossReferenceDocumentNumber = null;
//                String key = "error.batch.invalid_number_format";
//                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
//                        crossReferenceDocumentNumberString, String.valueOf(this.lineID)};
//                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
//                this.transactionValid = false;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_CROSS_REF_NO, null, null);
            }

            try {
                long crossRefNum = Long.parseLong(crossReferenceDocumentNumberString);
                TransactionManagerFactory.getInstance().start();
                if (DaoFactory.getImDocHeadAccessExt().read(crossRefNum) == null) {
                    String key = "error.batch.no_doc_head_records_for_the_given_cross_ref_doc_num";
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME,
                            crossReferenceDocumentNumberString, String.valueOf(this.lineID),
                            String.valueOf(this.vendorDocumentNumber)};
                    Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                    this.errorColumnId = "ERROR_NO_DOC_HEAD";
                    this.rejectReason = "ERROR_NO_DOC_HEAD";
                    this.transactionValid = false;
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NO_DOC_HEAD, null, null);
                }
            } finally {
                TransactionManagerFactory.getInstance().end();
            }
        }
        
        if (errInd == 0) {
            if ( SmrServiceFactory.getSmrEdiRejectService().rejectTrueDuplicates (this.vendorDocumentNumber, 
                                                                                  orderNumberString, 
                                                                                  BatchUtils.getDouble(totalCostString, PRECISION4) , 
                                                                                  tempVendorId)  ) 
                            {Logger.errorKey(SmrEdiTransactionHeader.class,
                                   "error.batch.vendor_doc_duplicate", new String[] {
                                   EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID), tempVendorId, this.vendorDocumentNumber,
                                   orderNumberString, totalCostString });                                                                              
                                   this.transactionValid = false;
                                   smrEdiOnlyReportHardEdits = true;
                                   createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUP_INVOICE, null, null);
            } // End Mod Anil

        }
        // set this for the possibility of a rejection - the value
        // is truly invalid, but will be used for processing only.
        // when the insert/update happens, a real value will be created.
        this.documentId = Long.valueOf(this.transactionNumber);
        
        
    }

    /**
     * Method used to write this transaction as a flat record for the reject file.
     *
     * @return all object variables concatenated into one string
     */
    public String createFlatRecord() {
        String record = "";

        record += BatchUtils.createFlatField(recordDescriptor, LEN_RECORD_DESCRIPTOR, NOPAD);
        record += BatchUtils.createFlatField(Long.valueOf(lineID), LEN_LINE_ID, PAD);
        record += BatchUtils.createFlatField(Long.valueOf(transactionNumber), LEN_TRANSACTION_NUMBER,
                PAD);
        if (isEdiDownload) {
            if (documentType.equals(Document.DEBIT_MEMO_PRICE)) {
                documentType = DEBIT_MEMO_PRICE;
            } else if (documentType.equals(Document.DEBIT_MEMO_QUANTITY)) {
                documentType = DEBIT_MEMO_QUANTITY;
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)) {
                documentType = CREDIT_NOTE_REQUEST_PRICE;
            } else if (documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                documentType = CREDIT_NOTE_REQUEST_QUANTITY;
            }
        }

        record += BatchUtils.createFlatField(documentType, LEN_DOCUMENT_TYPE, NOPAD);
        record += BatchUtils.createFlatField(vendorDocumentNumber + "", LEN_VENDOR_DOCUMENT_NUMBER,
                NOPAD);
        record += BatchUtils.createFlatField(groupId + "", LEN_GROUP_ID, NOPAD);
        if (isEdiDownload)
            record += BatchUtils.createFlatField(invoiceNumber, LEN_INVOICE_NUMBER, NOPAD);
        if (!isEdiDownload)
            record += BatchUtils.createFlatField(vendorType, LEN_VENDOR_TYPE, NOPAD);
        record += BatchUtils.createFlatField(vendorID, LEN_VENDOR_ID, NOPAD);
        record += BatchUtils.createFlatField(vendorDocumentDate.getBatchDateFormat(), LEN_DATE,
                NOPAD);
        record += BatchUtils.createFlatField(orderNumber, LEN_ORDER_NUMBER, NOPAD);
        record += BatchUtils.createFlatField(location, LEN_LOCATION, NOPAD);
        record += BatchUtils.createFlatField(locationType, LEN_LOCATION_TYPE, NOPAD);
        record += BatchUtils.createFlatField(terms, LEN_TERMS, NOPAD);
        record += BatchUtils.createFlatField(dueDate.getBatchDateFormat(), LEN_DATE, NOPAD);
        if (!isEdiDownload)
            record += BatchUtils.createFlatField(paymentMethod, LEN_PAYMENT_METHOD, NOPAD);
        record += BatchUtils.createFlatField(currencyCode, LEN_CURRENCY_CODE, NOPAD);
        record += BatchUtils.createFlatField(exchangeRate, LEN_EXCHANGE_RATE, PAD);
        record += BatchUtils.createFlatField(totalCost.doubleValue() > 0 ? EDIConstants.PLUS_SIGN
                : EDIConstants.MINUS_SIGN, LEN_IND, NOPAD);

        long totCost = Long.parseLong(totalCost.toString().substring(0,
                totalCost.toString().indexOf("."))
                + totalCost.toString().substring(totalCost.toString().indexOf(".") + 1));
        if (totCost < 0) {
            totCost *= -1;
        }

        record += BatchUtils.createFlatField(new BigDecimal(totCost), LEN_COST, PAD);

        record += BatchUtils
                .createFlatField(totalTaxAmount.doubleValue() > 0 ? EDIConstants.PLUS_SIGN
                        : EDIConstants.MINUS_SIGN, LEN_IND, NOPAD);
        record += BatchUtils.createFlatField(new Double(Math.abs(totalTaxAmount.doubleValue())),
                LEN_COST, PAD);
        record += BatchUtils.createFlatField(
                totalQuantity.doubleValue() > 0 ? EDIConstants.PLUS_SIGN : EDIConstants.MINUS_SIGN,
                LEN_IND, NOPAD);
        record += BatchUtils.createFlatField(new Double(Math.abs(totalQuantity.doubleValue())),
                LEN_QUANTITY, PAD);
        if (!isEdiDownload) {
            record += BatchUtils.createFlatField(
                    totalDiscount.doubleValue() > 0 ? EDIConstants.PLUS_SIGN
                            : EDIConstants.MINUS_SIGN, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(new Double(Math.abs(totalDiscount.doubleValue())),
                    LEN_TOTAL_DISCOUNT, PAD);
            record += BatchUtils.createFlatField(freightType, LEN_FREIGHT_TYPE, NOPAD);
            record += BatchUtils.createFlatField(manuallyPaidInd, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(multiLocation, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(merchType, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(dealId, LEN_DEAL_ID, PAD);
            record += BatchUtils.createFlatField(dealApprovalInd, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(rtvInd, LEN_IND, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference1,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference2,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference3,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(customDocumentReference4,
                    LEN_CUSTOM_DOCUMENT_REFERENCE, NOPAD);
            record += BatchUtils.createFlatField(crossReferenceDocumentNumber,
                    LEN_CROSS_REFERENCE_DOCUMENT_NUMBER, NOPAD);
        }

        return record;
    }

    /**
     * Method used to write the original transaction data with new line number and transaction
     * number. This is so that the reject file is numbered correctly and will pass validation.
     *
     * @return original transaction line with new line and transaction numbers
     */
    public String renumberedRecord(long lineNumber, long tranNumber) {
        return (this.recordDescriptor
                + BatchUtils.createFlatField(Long.valueOf(lineNumber), LEN_LINE_ID, PAD)
                + BatchUtils.createFlatField(Long.valueOf(tranNumber), LEN_TRANSACTION_NUMBER, PAD) + originalRecord
                .substring(LEN_RECORD_DESCRIPTOR + LEN_LINE_ID + LEN_TRANSACTION_NUMBER));
    }

    public void run() {
        try {
            BatchUtils.start(SmrEdiTransactionHeader.class, ediUploadArgs);
            Logger.info(SmrEdiTransactionHeader.class, "transaction: " + this.transactionNumber);
            TransactionManagerFactory.getInstance().start();
            modifyDueDate();	// ENH31
            validateForUpload(true);
        } catch (ReIMException e) {
            uploadReporter.setSuccessfulTermination(false);

            try {
                backgroundQueue.put(this);
                TransactionManagerFactory.getInstance().rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } catch (Throwable t) {
            uploadReporter.setSuccessfulTermination(false);

            try {
                backgroundQueue.put(this);
                TransactionManagerFactory.getInstance().rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            t.printStackTrace();
        } finally {
            try {
                TransactionManagerFactory.getInstance().end();
            } catch (Exception e) {
                uploadReporter.setSuccessfulTermination(false);
                Logger.error(SmrEdiTransactionHeader.class, e);
                try {
                    backgroundQueue.put(this);
                } catch (Exception ex) {
                    Logger.error(SmrEdiTransactionHeader.class, ex);
                }
            }
        }
    }


    public EdiValidationResult validateForRetry(boolean allowDateBeforePostDatedDocDays, String operationRadio)	// ENH31
            throws ReIMException {
        EdiValidationResult validateForRetryResult = VALIDATION_SUCCESS;

        if (this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
            validateForRetryResult = validateMerchandiseInvoiceDocument(false,
                    allowDateBeforePostDatedDocDays);
        } else {
            // should *never* get here, but we know how things can go....
            throw new ReIMException("error.edi.retry.doc_type_must_be_merch", Severity.FATAL, this);
        }
        if (operationRadio == null || operationRadio == "" || operationRadio.length() == 0 ) {
            operationRadio = "release";
        }
        if (validateForRetryResult.isSuccess()) {
        	if (operationRadio.equals(SmrEdiRejectMassCorrectionForm.OPERATION_RELEASE)) {		// ENH31
        		// add this to the good tables.....
        		if (isMultiLocation()) {
        			ServiceFactory.getParentInvoiceService().insertForMultiLocationInvoices(this);
        		} else {
        			ediDocBulk = new EdiDocBulk();
        			ediDocBulk.setMaxDocumentCount(1);
        			ServiceFactory.getEdiDocumentService().createEdiDocuments(this, ediDocBulk,
        					true);
        		}

        		// and remove the rejects that are now good...
        		ServiceFactory.getEdiRejectService().deleteRejects(
        				new String[] { String.valueOf(this.documentId)});
        	}	// ENH31
        	else if (operationRadio.equals(SmrEdiRejectMassCorrectionForm.OPERATION_HOLD)) {	// ENH31 Added
        		SmrServiceFactory.getSmrEdiRejectService().updateRejectHeadRejectReason(this.documentId.longValue(), SmrEdiRejectReasons.ERROR_COLUMN_NONE, SmrEdiRejectReasons.HELD);
        	}	// ENH31 Added End
                else {
                    // Nothing selected from the screen so don't do anything
                }
        } else {
            // otherwise, create a reject document
            EdiRejectDocument ediRejectDocument = EdiTransactionHeaderValidationService
                    .createEdiRejectDocAndDetails(this, this.errorColumnId, this.rejectReason,
                            this.rejectedDocDetailId);

            // Update the existing records.
            ServiceFactory.getEdiRejectService().updateForEdiRejectDocHeadAndDocDetail(
                    ediRejectDocument);
        }

        return validateForRetryResult;
    }

    public void validateForUpload(boolean checkForFileRejections) throws ReIMException {
        String fieldName = null;
        EdiValidationResult validationForUploadResult = VALIDATION_SUCCESS;
        
               
        if (!this.isTransactionValid()) {
            validationForUploadResult = FAILURE_REJECT_FILE;
        }

        if (validationForUploadResult.isSuccess()
                && !EDI_DOCUMENT_TYPES.contains(this.documentType)) {
        	this.documentType = "MRCHI";
//            fieldName = ReIMI18NUtility.getMessage("label.document_type");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.documentType, String.valueOf(this.lineID)});
//            validationForUploadResult = FAILURE_REJECT_FILE;
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DOC_TYPE, null, null);
        }

        // validate the vendor information
        if (validationForUploadResult.isSuccess() && !VendorType.isValidCode(this.vendorType)) {
            fieldName = ReIMI18NUtility.getMessage("label.vendor_type");
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.vendorType, String.valueOf(this.lineID)});
            this.errorColumnId = "ERROR_VENDOR_TYPE";
            this.rejectReason = "ERROR_VENDOR_TYPE";
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_TYPE, null, null);
            validationForUploadResult = FAILURE_REJECT_TABLES;
        }

        if (validationForUploadResult.isSuccess()) {
            // validate the doc/transaction based on the doc type..
            // validate merch invoices
            if (this.documentType.equals(Document.MERCHANDISE_INVOICE)) {
                validationForUploadResult = validateMerchandiseInvoiceDocument(
                        checkForFileRejections, false);
                validationForUploadResult = redirectValidation(validationForUploadResult);
            }
            // validate non merch invoices
            else if (this.documentType.equals(Document.NON_MERCHANDISE_INVOICE)) {
                validationForUploadResult = validateNonMerchandiseInvoiceDocument(checkForFileRejections);
            }
            // validate credit notes
            else if (this.documentType.equals(Document.CREDIT_NOTE)) {
                validationForUploadResult = validateCreditNoteDocument(checkForFileRejections);

                validationForUploadResult = redirectValidation(validationForUploadResult);
            }
            // validate debit memo (cost or quantity)
            else if (this.documentType.equals(Document.DEBIT_MEMO_PRICE)
                    || this.documentType.equals(Document.DEBIT_MEMO_QUANTITY)) {
                validationForUploadResult = validateDebitMemoDocument(checkForFileRejections);

                validationForUploadResult = redirectValidation(validationForUploadResult);
            }
            // validate credit memo cost
            else if (this.documentType.equals(Document.CREDIT_MEMO_PRICE)) {
                validationForUploadResult = validateCreditMemoCostDocument(checkForFileRejections);

                validationForUploadResult = redirectValidation(validationForUploadResult);
            }
            // validate crdit note requests (cost or quantity)
            else if (this.documentType.equals(Document.CREDIT_NOTE_REQUEST_PRICE)
                    || this.documentType.equals(Document.CREDIT_NOTE_REQUEST_QUANTITY)) {
                validationForUploadResult = validateCreditNoteRequestDocument(checkForFileRejections);

                validationForUploadResult = redirectValidation(validationForUploadResult);
            }
        }

        // whenever we are dealing with vendor other than a supplier, any
        // rejection must go to the reject file.
        if (validationForUploadResult.isFailure() && !this.vendorType.equals(Vendor.SUPPLIER)) {
            this.errorColumnId = "ERROR_VENDOR_NOT_SUPP";
            this.rejectReason = "ERROR_VENDOR_NOT_SUPP";
        	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_NOT_SUPP, null, null);
        	validationForUploadResult = FAILURE_REJECT_TABLES;

        }// whenever merch type is 'C' or rtv_ind is yes, any rejection must
        // go to the reject file.
        else if (validationForUploadResult.isFailure()
                && (nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT) || (this.rtvInd
                        .equals(ReIMConstants.YES)))) {
            this.errorColumnId = "ERROR_MERCH_TYPE_RTV";
            this.rejectReason = "ERROR_MERCH_TYPE_RTV";
        	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_MERCH_TYPE_RTV, null, null);
        	validationForUploadResult = FAILURE_REJECT_TABLES;

        }

        /* SMR OLR ENH31 Inserted - START */
        if (smrEdiReportRecord == null){
        	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NO_ERROR, null, null);
        }
//        System.out.println(" validationForUploadResult.getRejection().isFileBound() " + validationForUploadResult.getRejection().isFileBound() );
//        System.out.println(" validationForUploadResult.getRejection().isTablesBound() " + validationForUploadResult.getRejection().isTablesBound() );
//        if ( !(validationForUploadResult.isFailure() && ( validationForUploadResult.getRejection().isFileBound()   ))) {
//        	//If only reporting hard edits, override soft edit failure on report record with NO ERROR status
//        	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NO_ERROR, null, null);
//        }
		try {
			backgroundQueue.put(smrEdiReportRecord);
		} catch (Throwable e) {
			// create a ReIMException, which logs the error, and then
			// nothing more to do
			throw new ReIMException("error.batch.unexpected_threading_error",
					Severity.FATAL, this);
		}
        /* SMR OLR ENH31 Inserted - END */
        
        // Anil  This is where call happens 
        // check the return value from validating and act accordingly
        // if we need to reject back to file, add this to the background queue
        
        if (validationForUploadResult.isFailure()
                && validationForUploadResult.getRejection().isFileBound()) {
            try {
                backgroundQueue.put(this);
            } catch (Throwable e) {
                // create a ReIMException, which logs the error, and then
                // nothing more to do
                throw new ReIMException("error.batch.unexpected_threading_error", Severity.FATAL,
                        this);
            }

            uploadReporter.setTransactionsRejectedToFile(true);
        }
        // if we need to reject to the db, create the necessary object and pass
        // into service
        else if (validationForUploadResult.isFailure()
                && validationForUploadResult.getRejection().isTablesBound() ) {
            // create a reject document
            EdiRejectDocument ediRejectDocument = EdiTransactionHeaderValidationService
                    .createEdiRejectDocAndDetails(this, this.errorColumnId, this.rejectReason,
                            this.rejectedDocDetailId);

            // Insert into the rejected document tables
            ServiceFactory.getEdiRejectService().insertForEdiRejectDocuments(ediRejectDocument);

            uploadReporter.setTransactionsRejectedToDatabase(true);
        }
        // otherwise, this is completely valid and we can pass it into the
        // service for insertion

        else {
            if (this.multiLocation.equalsIgnoreCase(ReIMConstants.YES)) {
                if (!ServiceFactory.getParentInvoiceService().checkForDuplicateExtDocId(
                        this.vendorDocumentNumber, this.vendorID)) {
                    ServiceFactory.getParentInvoiceService().insertForMultiLocationInvoices(this);
                } else // found duplicate vendor document number
                {
                    fieldName = ReIMI18NUtility.getMessage("batch.field.vendor_document_number");
                    Logger.errorKey(SmrEdiTransactionHeader.class,
                            "error.batch.vendor_doc_number_duplicate", new String[] {
                                    EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentNumber,
                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                    String.valueOf(this.vendorDocumentNumber + "")});
                                    this.errorColumnId = "ERROR_VENDOR_DOC_DUP";
                                    this.rejectReason = "ERROR_VENDOR_DOC_DUP";
                            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_DOC_DUP, null, null);
                            
                    // need to reject back to reject file.
                    try {
                        backgroundQueue.put(this);
                    } catch (Throwable e) {
                        // create a ReIMException, which logs the error, and
                        // then nothing more to do
                        throw new ReIMException("error.batch.unexpected_threading_error",
                                Severity.FATAL, this);
                    }

                    uploadReporter.setTransactionsRejectedToFile(true);
                }
            } else {
                ServiceFactory.getEdiDocumentService().createEdiDocuments(this, ediDocBulk,
                            false);
            }
        }
    
        return;
    }

    private EdiValidationResult redirectValidation(EdiValidationResult result) throws ReIMException {
        if (result.isFailure() && result.getRejection().isTablesBound()) {
            for (int i = 0; i < ediTransactionDetailList.length; i++) {
                EdiTransactionDetail detail = ediTransactionDetailList[i];
                if (!detail.getItem().equals("") && detail.isItemPassedFromFile()
                        && !ServiceFactory.getItemService().isValidItem(detail.getItem())) {
                    result = FAILURE_REJECT_FILE;
                    break;
                }
            }
        }
        return result;
    }

    public EdiValidationResult validateMerchandiseInvoiceDocument(boolean checkForFileRejections,
            boolean allowDateBeforePostDatedDocDays) throws ReIMException {
        // merch docs must come from a supplier and only a supplier
        if (checkForFileRejections) {
            if (!this.vendorType.equals(Vendor.SUPPLIER)) {
                Logger.errorKey(SmrEdiTransactionHeader.class,
                        "error.batch.invalid_merch_doc_partner", new String[] { String
                                .valueOf(this.lineID)});
                this.errorColumnId = "ERROR_VENDOR_NOT_SUPP";
                this.rejectReason = "ERROR_VENDOR_NOT_SUPP";
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_NOT_SUPP, null, null);
                return FAILURE_REJECT_TABLES;
            }
        }
        // Do general file rejection validation
        if (checkForFileRejections) {
            EdiValidationResult validationResult = this.validateForFileRejection();
            if (validationResult.isFailure()) return validationResult;
        }
        // do general document validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections,
                allowDateBeforePostDatedDocDays);

    }

    public EdiValidationResult validateNonMerchandiseInvoiceDocument(boolean checkForFileRejections)
            throws ReIMException {

        /**
         * If the location is �-999999999� then the default location is fetched from the properties.
         */
        if (this.location != null && this.location.longValue() == EdiUploadProperties.NO_LOCATION) {
            this.location = EdiUploadProperties.DEFAULT_LOCATION;
            if (LocationService.validStore(this.location))
                this.locationType = Location.STORE;
            else if (LocationService.validWarehouse(this.location))
                this.locationType = Location.WAREHOUSE;
        }

        // non merch docs must have TNMRC records associated with them
        if (this.ediNonMerchDetailList == null || this.ediNonMerchDetailList.length == 0) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.non_merch_records_must_exist_for_non_merch_invoice",
                    new String[] { String.valueOf(this.lineID)});
            this.errorColumnId = "ERROR_NON_MERCH_REC";
            this.rejectReason = "ERROR_NON_MERCH_REC";
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NON_MERCH_REC, null, null);
            return FAILURE_REJECT_TABLES;
        }

        // Do general file rejection validation
        if (checkForFileRejections) {
            EdiValidationResult fileRejectionValidationResult = validateForFileRejection();
            if (fileRejectionValidationResult.isFailure()) { return fileRejectionValidationResult; }
        }

        // non merch docs must have a total qty of zero (0)
        if (this.totalQuantity.doubleValue() != 0) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.non_merch_doc_must_have_total_qty_zero", new String[] { String
                            .valueOf(this.lineID)});
            this.errorColumnId = "ERROR_NEG_TOT_COST";
            this.rejectReason = "ERROR_NEG_TOT_COST";
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NEG_TOT_COST  , null, null);
            return FAILURE_REJECT_TABLES;
        }

        // non merch docs cannot have any TDETL records
        if (this.ediTransactionDetailList != null && this.ediTransactionDetailList.length != 0) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.non_merch_doc_cannot_have_detail_records", new String[] { String
                            .valueOf(this.lineID)});
            this.errorColumnId = "ERROR_NON_MERCH_NO_TDETL";
            this.rejectReason = "ERROR_NON_MERCH_NO_TDETL";
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NON_MERCH_NO_TDETL, null, null);
            return FAILURE_REJECT_TABLES;
        }

        // do general document validation
        EdiValidationResult nonFileRejectValidationResult = this
                .validateWithPrimaryRejectionToTables(checkForFileRejections, false);

        // non merch docs can only be good (inserted into the 'valid' document
        // tables...
        if (nonFileRejectValidationResult.isFailure()) {
            return nonFileRejectValidationResult;
        }
        // or they get rejected to file.
        else {
            return VALIDATION_SUCCESS;
        }
    }

    public EdiValidationResult validateCreditNoteDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only an initial upload will get here.

        EdiValidationResult creditNoteValidationResult = VALIDATION_SUCCESS;

        // Credit notes not associated with supplier, manufacturer, distributor,
        // or wholesaler must
        // not have detail information
        String vendorType = this.vendorType;
        if (!vendorType.equals(Vendor.SUPPLIER) && !vendorType.equals(Vendor.MERCH_SUPP_LEV_1)
                && !vendorType.equals(Vendor.MERCH_SUPP_LEV_2)
                && !vendorType.equals(Vendor.MERCH_SUPP_LEV_3)) {
            if (this.ediTransactionDetailList.length > 0) {
                Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.no_detail_information",
                        new String[] { EDI_UPLOAD_PROGRAM_NAME, vendorType,
                                String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                String.valueOf(this.vendorDocumentNumber + "")});
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_CRD_NOT_ASSO, null, null);
                this.errorColumnId = "ERROR_CRD_NOT_ASSO";
                this.rejectReason = "ERROR_CRD_NOT_ASSO";
                return FAILURE_REJECT_TABLES;
            }
        }

        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // credit note documents must have a negative total cost value
        if (this.totalCost.doubleValue() >= 0) {
            Logger
                    .errorKey(SmrEdiTransactionHeader.class,
                            "error.batch.credit_note_doc_total_cost_must_be_negative",
                            new String[] { String.valueOf(this.lineID),
                                    String.valueOf(this.vendorDocumentNumber)});
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NEG_CRD_NOT_DOC, null, null);
            this.errorColumnId = "ERROR_NEG_CRD_NOT_DOC";
            this.rejectReason = "ERROR_NEG_CRD_NOT_DOC";
            return FAILURE_REJECT_TABLES;
        }

        // credit note documents that have details must not have
        // any allowances and thus a total allowance of zero
        if (this.ediTransactionDetailList != null && this.ediTransactionDetailList.length > 0) {
            int listLength = this.ediTransactionDetailList.length;

            for (int i = 0; i < listLength; i++) {
                if (this.ediTransactionDetailList[i].getTotalAllowance() != 0
                        || (this.ediTransactionDetailList[i].getEdiDetailAllowanceList() != null && this.ediTransactionDetailList[i]
                                .getEdiDetailAllowanceList().length != 0)) {
                    Logger
                            .errorKey(
                                    SmrEdiTransactionHeader.class,
                                    "error.batch.credit_note_doc_total_allowance_must_be_zero_with_no_tallw_recs",
                                    new String[] { EDI_UPLOAD_PROGRAM_NAME,
                                            String.valueOf(this.lineID),
                                            String.valueOf(this.orderNumber + ""),
                                            String.valueOf(this.vendorDocumentNumber + "")});
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_ZERO_CRD_NOT_DOC, null, null);
                    this.errorColumnId = "ERROR_ZERO_CRD_NOT_DOC";
                    this.rejectReason = "ERROR_ZERO_CRD_NOT_DOC";
                    return FAILURE_REJECT_TABLES;
                }
            }
        }

        // non merch records associated with a credit note need to have a
        // negative amt value
        if (this.ediNonMerchDetailList != null && this.ediNonMerchDetailList.length > 0) {
            int listLength = this.ediNonMerchDetailList.length;

            for (int i = 0; i < listLength; i++) {
                EdiValidationResult validationResult = this.ediNonMerchDetailList[i]
                        .validateForCreditNote();
                if (validationResult.isFailure()) { return validationResult; }
            }
        }

        // do general document validation
        creditNoteValidationResult = this.validateWithPrimaryRejectionToTables(
                checkForFileRejections, false);

        // credit notes can only be good (inserted into the 'valid' document
        // tables)...
        if (creditNoteValidationResult.isFailure()) {
            return FAILURE_REJECT_FILE;
        }
        // or they get rejected to file.
        else {
            return VALIDATION_SUCCESS;
        }
    }

    public EdiValidationResult validateCreditNoteRequestDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only
        // an initial upload will get here.
        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // do general document(table) validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections, false);
    }

    public EdiValidationResult validateDebitMemoDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only
        // an initial upload will get here.
        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // must have a negative total cost value
        if (this.totalCost.doubleValue() >= 0) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.debit_memo_doc_total_cost_must_be_negative", new String[] {
                            EDI_UPLOAD_PROGRAM_NAME, this.totalCost.toString(),
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DET_MEMO_NEG, null, null);
            this.errorColumnId = "ERROR_DET_MEMO_NEG";
            this.rejectReason = "ERROR_DET_MEMO_NEG";
            return FAILURE_REJECT_TABLES;
        }

        // do general document(table) validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections, false);
    }

    public EdiValidationResult validateCreditMemoCostDocument(boolean checkForFileRejections)
            throws ReIMException {
        // it is never expected that this code will be hit when doing a 'retry'.
        // Only
        // an initial upload will get here.
        // Do general file rejection validation
        if (checkForFileRejections && this.validateForFileRejection().isFailure()) { return FAILURE_REJECT_FILE; }

        // do general document(table) validation
        return this.validateWithPrimaryRejectionToTables(checkForFileRejections, false);
    }

    public EdiValidationResult validateForFileRejection() throws ReIMException {
        SupplierGroup supplierGroup = null;
        // String vendorId = null;

        if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
            // Total Quantity: if it is null and total header quantity indicator
            // is checked, invalid
            try {
                Long.parseLong(this.vendorID);
                supplierGroup = ServiceFactory.getSupplierGroupService().getSupplierGroup(
                        this.vendorID);
            } catch (NumberFormatException e) {
                supplierGroup = null;
            }
        }

        setSupplierSiteEnabled(ServiceFactory.getSystemOptionsService().getSystemOptions()
                .isSupplierSiteInd());
        String fieldName = "";
        ReIMSystemOptions systemOptions = ServiceFactory.getReIMSystemOptionsService().select();
        // validate Order no.
        // If the vendor is a supplier, and the document type is not
        // non-merchandise invoice, order number must be provided
        if (this.vendorType.equals(Vendor.SUPPLIER) && this.orderNumber == null
                && (!this.documentType.equals(Document.NON_MERCHANDISE_INVOICE))) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.order_no_required_for_merch_inv", new String[] {
                            EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID)});

            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PO, null, null);
            this.errorColumnId = "ERROR_PO";
            this.rejectReason = "ERROR_PO";
  
            return FAILURE_REJECT_TABLES;
        }

        // reject to file if order/RTV order number exists and vendor type is
        // NOT a supplier
        if (!this.vendorType.equals(Vendor.SUPPLIER) && this.orderNumber != null) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.order_no_must_be_null_when_not_a_supplier", new String[] {
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});

            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUP_ORDER_RTV, null, null);
            this.errorColumnId = "ERROR_DUP_ORDER_RTV";
            this.rejectReason = "ERROR_DUP_ORDER_RTV";
            return FAILURE_REJECT_TABLES;
        }

        if (!this.locationType.equals(Location.WAREHOUSE)
                && !this.locationType.equals(Location.STORE)) {
            String field = ReIMI18NUtility.getMessage("batch.field.location_type");
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    field, String.valueOf(this.location), String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber + "")});
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_LOC_TYPE, null, null);
            this.errorColumnId = "ERROR_LOC_TYPE";
            this.rejectReason = "ERROR_LOC_TYPE";
            return FAILURE_REJECT_TABLES;
        }

        if (this.dueDate != null && this.dueDate.before(this.vendorDocumentDate)) {
            this.dueDate = ServiceFactory.getPeriodService().getVDate();
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.due_date_invalid",
//                    new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentDate.toString(),
//                            this.dueDate.toString(), String.valueOf(this.lineID),
//                            String.valueOf(this.orderNumber + ""),
//                            String.valueOf(this.vendorDocumentNumber + "")});
//            
//            this.errorColumnId = "ERROR_DUE_DATE_NULL";
//            this.rejectReason = "ERROR_DUE_DATE_NULL";
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUE_DATE_NULL, null, null);
//            return FAILURE_REJECT_TABLES;
        }

        if (!ServiceFactory.getCurrencyService().validateCurrency(this.currencyCode)) {
        	this.currencyCode = ServiceFactory.getCurrencyService().getCurrencyCodeByOrderNo(
                    this.orderNumber.longValue());
//            fieldName = ReIMI18NUtility.getMessage("label.currency_code");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.currencyCode, String.valueOf(this.lineID),
//                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber + "")});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_CURR_CODE, null, null);
//            this.errorColumnId = "ERROR_CURR_CODE";
//            this.rejectReason = "ERROR_CURR_CODE";
//            return FAILURE_REJECT_TABLES;
        }

        // verify that the invoice currency matches the order's currency
        // if an order is given
        // now defensive as CurrencyService.getCurrencyCodeByOrder can
        // return a null if the order number is invalid but we still
        // want to import the it
        if (this.orderNumber != null) {
            String curr = "";
            if (this.rtvInd.equals("Y")) {
                String vendorId = ServiceFactory.getRtvService().getVendorFromOrder(
                        this.orderNumber.toString());
                curr = ServiceFactory.getCurrencyService().getCurrencyCodeByVendor(this.vendorType,
                        vendorId);
            } else {
                curr = ServiceFactory.getCurrencyService().getCurrencyCodeByOrderNo(
                        this.orderNumber.longValue());
            }

            if (curr != null) // is the order # valid?
            {
                if (this.orderNumber != null && !curr.equals(this.currencyCode)) {
                	this.currencyCode = curr;
//                    Logger.errorKey(SmrEdiTransactionHeader.class,
//                            "error.batch.invoice_currency_code_not_match_order", new String[] {
//                                    this.currencyCode, this.orderNumber.toString(),
//                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
//                                    String.valueOf(this.vendorDocumentNumber + "")});
//
//                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_CURR_NOT_MATCH , null, null);
//                    
//                    this.errorColumnId = "ERROR_CURR_NOT_MATCH";
//                    this.rejectReason = "ERROR_CURR_NOT_MATCH";
//                    return FAILURE_REJECT_TABLES;

                }
            }
        }

        if (this.freightType != null
                && !this.freightType.equals(ReIMConstants.EMPTY_STRING)
                && !ServiceFactory.getCodeDetailService().checkValidCode(this.freightType,
                        Document.FREIGHT_TYPES_CODE))
            if (!ServiceFactory.getCodeDetailService().checkValidCode(this.freightType,
                    Document.FREIGHT_TYPES_CODE)) {
            	this.freightType = null;
//                fieldName = ReIMI18NUtility.getMessage("label.freight_type");
//                Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
//                        new String[] { fieldName, this.freightType, String.valueOf(this.lineID),
//                    String.valueOf(this.orderNumber + ""),
//                    String.valueOf(this.vendorDocumentNumber)});
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_FREIGHT_TYPE , null, null);
//                this.errorColumnId = "ERROR_FREIGHT_TYPE";
//                this.rejectReason = "ERROR_FREIGHT_TYPE";
//                return FAILURE_REJECT_TABLES;
            }

        if (!EDIConstants.YES_NO_INDICATORS.contains(manuallyPaidInd)) {
        	this.manuallyPaidInd = "N";
//            fieldName = ReIMI18NUtility.getMessage("batch.field.paid_ind");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.manuallyPaidInd, String.valueOf(this.lineID),
//                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber)});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PAID_IND , null, null);
//            this.errorColumnId = "ERROR_PAID_IND";
//            this.rejectReason = "ERROR_PAID_IND";
//       
//            return FAILURE_REJECT_TABLES;
        }

        if (!EDIConstants.YES_NO_INDICATORS.contains(multiLocation)) {
        	this.multiLocation = "N";
//            fieldName = ReIMI18NUtility.getMessage("batch.field.multi_loc");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.multiLocation, String.valueOf(this.lineID),
//                    String.valueOf(this.orderNumber + ""), String.valueOf(this.vendorDocumentNumber)});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_MULTI_LOC_IND , null, null);
//            this.errorColumnId = "ERROR_MULTI_LOC_IND";
//            this.rejectReason = "ERROR_MULTI_LOC_IND";
//       
//            return FAILURE_REJECT_TABLES;
        }

        if (this.multiLocation.equals(ReIMConstants.YES)
                && (nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT))) {
        	this.multiLocation = "N";
//            fieldName = ReIMI18NUtility.getMessage("batch.field.multi_loc");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.multiLocation, String.valueOf(this.lineID)});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_MULTI_LOC_Y , null, null);
//            this.errorColumnId = "ERROR_MULTI_LOC_Y";
//            this.rejectReason = "ERROR_MULTI_LOC_Y";
//       
//            return FAILURE_REJECT_TABLES;
        }

        if (!EDIConstants.EDI_MERCH_TYPES.contains(merchType)
                && (merchType != null && merchType.length() != 0)) {
        	this.merchType = "MRCHI";
//            fieldName = ReIMI18NUtility.getMessage("batch.field.merch_type");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.merchType, String.valueOf(this.lineID)});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_MERCH_TYPE , null, null);
//            this.errorColumnId = "ERROR_MERCH_TYPE";
//            this.rejectReason = "ERROR_MERCH_TYPE";
//       
//            return FAILURE_REJECT_TABLES;
        }

        if (!EDIConstants.YES_NO_INDICATORS.contains(rtvInd)) {
        	this.rtvInd = "N";
//            fieldName = ReIMI18NUtility.getMessage("batch.field.rtv_ind");
//            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
//                    fieldName, this.rtvInd, String.valueOf(this.lineID)});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_RTV_IND , null, null);
//            this.errorColumnId = "ERROR_RTV_IND";
//            this.rejectReason = "ERROR_RTV_IND";
//       
//            return FAILURE_REJECT_TABLES;
        }

        // validate non merch detail
        if (this.ediNonMerchDetailList != null && this.ediNonMerchDetailList.length != 0) {
            int listLength = ediNonMerchDetailList.length;

            for (int i = 0; i < listLength; i++) {
                Set<Tax> ediNonMerchTaxes = ediNonMerchDetailList[i].getEdiNonMerchTaxes();

//                if (ediNonMerchDetailList[i].validateWithPrimaryRejectionToFile(this).isFailure())
//                {
//                	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PRI_REJ_FILE , null, null);
//                        
//                       this.errorColumnId = "ERROR_PRI_REJ_FILE";
//                       this.rejectReason = "ERROR_PRI_REJ_FILE";
//                       return FAILURE_REJECT_TABLES;
//                }

                this.setDetailControlTotalCostSum(this.detailControlTotalCostSum.add(
                        new BigDecimal(ediNonMerchDetailList[i].getNonMerchandiseAmount()))
                        .doubleValue());
                // getting multiple taxes for the document
                for (Tax ediNonMerchTax : ediNonMerchTaxes) {

                    this.setTotalTaxAmountFromDetails(this.totalTaxAmountFromDetails
                            .add(
                                    new BigDecimal((ediNonMerchDetailList[i]
                                            .getNonMerchandiseAmount() * ediNonMerchTax
                                            .getTaxRate()) / 100.0)).doubleValue());
                }

            }
        }

        // validate tax detail
        if (this.ediTaxDetailList != null && this.ediTaxDetailList.length != 0) {
            int listLength = ediTaxDetailList.length;

            for (int i = 0; i < listLength; i++) {

                this.setTotalTaxAmountFromTTAXS(this.totalTaxAmountFromTTAXS.add(
                        new BigDecimal((ediTaxDetailList[i].getTaxBasis() * ediTaxDetailList[i]
                                .getTaxRate()) / 100.0)).doubleValue());

            }
        }

        if (this.vendorType.equals(Vendor.SUPPLIER)) {
            // if dealing with a supplier, the vendorID has to be completely
            // numeric
            try {
                Long.parseLong(this.vendorID);
            } catch (NumberFormatException e) {
                String key = "error.batch.invalid_number_format";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorID,
                        String.valueOf(this.lineID)};
                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR;
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_ID , null, null);
                smrEdiOnlyReportHardEdits = true;
                return FAILURE_REJECT_TABLES;
            }
        }

        // If the vendor is different than the one in the order, reject the
        // invoice.
        /*
         * Should be un-commented when the supplier site fix if forward ported from 13.0.2
         */
        if (this.orderNumber != null) {

            /*
             * vendorId corresponding to the order would be supplier in SupplierSite OFF and
             * supplier site in SupplierSite ON.
             */
            String orderVendor = null;
            if (!this.rtvInd.equalsIgnoreCase(Affirm.YES_IND)) {
                orderVendor = ServiceFactory.getOrderService().getVendorFromOrder(
                        this.orderNumber.toString());
                fieldName = ReIMI18NUtility.getMessage("label.order_number");
            } else if (this.rtvInd.equalsIgnoreCase(Affirm.YES_IND)) {
                orderVendor = ServiceFactory.getRtvService().getVendorFromOrder(
                        this.orderNumber.toString());
                fieldName = ReIMI18NUtility.getMessage("label.rtv_order_no");
            }
            Logger.info(SmrEdiTransactionHeader.class, "orderNumber " + orderNumber + " orderVendor " + orderVendor + " rtvInd " + rtvInd);
            System.out.println( "orderNumber " + orderNumber + " orderVendor " + orderVendor + " rtvInd " + rtvInd);

            if(orderVendor == null){
                Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                        fieldName, this.orderNumber.toString(), String.valueOf(this.lineID),
                        String.valueOf(this.orderNumber), this.vendorDocumentNumber});
                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ORDER_NO;
                this.rejectReason = EdiRejectReasons.INVALID_ORDER_NO;
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_ORDER_NULL , null, null);
                this.transactionValid = false;
                return FAILURE_REJECT_TABLES;
            }

            boolean vendorSameGroup = false;

            if (isSupplierSiteEnabled()) {

                //in case this.vendorID represents supplier parent supplierParentForDocVendor will be null
                String supplierParentForDocVendor = ServiceFactory.getVendorService().getSupplierParent(
                        this.vendorID);
                String supplierParentForOrderVendor = ServiceFactory.getVendorService()
                        .getSupplierParent(orderVendor);
                Logger.info(SmrEdiTransactionHeader.class, "supplierParentForOrderVendor " + supplierParentForOrderVendor + " supplierParentForDocVendor " + supplierParentForDocVendor);                        
                System.out.println( "supplierParentForOrderVendor " + supplierParentForOrderVendor + " supplierParentForDocVendor " + supplierParentForDocVendor);
    
                if(!StringUtils.isBlank(supplierParentForDocVendor)) {
                    //document provides supplier site
                    if(this.vendorID.equalsIgnoreCase(orderVendor)) {
                        vendorSameGroup = true;
                        setFileSupplierSiteInd(true);
                        setSupplierSiteID(orderVendor);

                    } else if(supplierParentForDocVendor.equalsIgnoreCase(supplierParentForOrderVendor)){
                        vendorSameGroup = true;
                        setFileSupplierSiteInd(true);
                        setSupplierSiteID(this.vendorID);
                    }
                } else {
                    //document provides supplier parent
                    if(this.vendorID.equalsIgnoreCase(supplierParentForOrderVendor)) {
                        vendorSameGroup = true;
                        setFileSupplierSiteInd(false);
                        setSupplierSiteID(orderVendor);
                    }
                }
            } else {
                if (this.vendorID.equalsIgnoreCase(orderVendor)) {
                    vendorSameGroup = true;
                }
            }
            Logger.info(SmrEdiTransactionHeader.class, "isSupplierSiteEnabled() " + isSupplierSiteEnabled() + " orderVendor " + orderVendor + " vendorSameGroup " + vendorSameGroup);
            System.out.println( "isSupplierSiteEnabled() " + isSupplierSiteEnabled() + " orderVendor " + orderVendor + " vendorSameGroup " + vendorSameGroup);

            if (!vendorSameGroup && supplierGroup != null && supplierGroup.getSuppliers() != null) {
                for (String supplier : supplierGroup.getSupplierIds()) {
                    if (supplier != null && supplier.equalsIgnoreCase(orderVendor)) {
                        vendorSameGroup = true;
                        break;
                    }
                }
            }

            if (!vendorSameGroup) {
                String key = "error.batch.vendor_different_than_in_order";
                String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorID,
                        String.valueOf(this.lineID), String.valueOf(this.orderNumber.toString()),
                        this.vendorDocumentNumber};
                Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR_FOR_ORDER;
                this.transactionValid = false;
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_DIFF , null, null);
                smrEdiOnlyReportHardEdits = true;
                return FAILURE_REJECT_FILE;
            }
        }
        boolean totalHeaderQtyReqInd = supplierGroup != null ? supplierGroup
                .isTotalHeaderQuantityRequired() : ReimProperties.DOCUMENT_HEADER_QUANTITY_REQUIRED;

        if (ediTransactionDetailList != null && this.ediTransactionDetailList.length != 0) {
            Set<String> itemSet = new HashSet<String>();
            int listLength = this.ediTransactionDetailList.length;

            boolean isItemSupplied = false;

            BigDecimal originalUnitCost = new BigDecimal(0);
            BigDecimal originalDocumentQuantity = new BigDecimal(0);

            for (int i = 0; i < listLength; i++) {
            	
            	  if ( ediTransactionDetailList[i].getItem().length() != 0) {
            	      if (!ServiceFactory.getItemService().isValidItem(ediTransactionDetailList[i].getItem())) {
            	         Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_item",
            	                 new String[] { EDI_UPLOAD_PROGRAM_NAME, ediTransactionDetailList[i].getItem(),
            	                         String.valueOf(this.lineID)});
            	                 
            	         this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
            	         this.rejectReason = EdiRejectReasons.INVALID_UPC;
            	         this.transactionValid = false;
            	         smrEdiOnlyReportHardEdits = true;
            	         createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_SKU, null, ediTransactionDetailList[i].getItem() );
            	         return FAILURE_REJECT_FILE;
            	     }
            	  }
            	
                if (!ediTransactionDetailList[i].getItem().equals("")) isItemSupplied = true;
                EdiValidationResult validationResult = ediTransactionDetailList[i]
                        .validateWithPrimaryRejectionToFile(this.vendorType, this.vendorID,
                                this.location, this.documentType, this);
//                if (validationResult.isFailure()) {
//                    this.errorColumnId = "ERROR_PRI_REJ_FILE";
//                    this.rejectReason = "ERROR_PRI_REJ_FILE";
//                	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_PRI_REJ_FILE , null, null);
//                	return validationResult;
//                }

                // Check for duplicate items for the document. If the item is
                // duplicated, then this
                // item is invalid. If the item is not duplicated, add it to the
                // hashset for future
                // item duplication checks.
                String itemId = ediTransactionDetailList[i].getItem();
                if (this.getMerchType() == null || this.getMerchType().equals("")
                        || !nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {

                    if (itemId != null && !itemId.equals("")) {
                        if (isItemSupplied && itemSet.contains(itemId)) {
//                            Logger
//                                    .errorKey(SmrEdiTransactionHeader.class,
//                                            "error.batch.duplicate_item", new String[] {
//                                                    EDI_UPLOAD_PROGRAM_NAME,
//                                                    ediTransactionDetailList[i].getItem(),
//                                                    String.valueOf(ediTransactionDetailList[i]
//                                                            .getLineID())});
//
//                            // createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_SKU, ediTransactionDetailList[i].getItem(), null);
//                             this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
//                             this.rejectReason = EdiRejectReasons.INVALID_UPC_DUPLICATE;
//                             createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUP_ITEM, ediTransactionDetailList[i].getItem(), null);
//                             return FAILURE_REJECT_TABLES;
                        } else {
                            itemSet.add(ediTransactionDetailList[i].getItem());
                        }
                    }
                }

                // Maintain the sum of costs and quantities for comparison with
                // the control total for the entire document.
                originalUnitCost = new BigDecimal(ediTransactionDetailList[i].getOriginalUnitCost());
                originalUnitCost = originalUnitCost.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
                originalDocumentQuantity = new BigDecimal(ediTransactionDetailList[i]
                        .getOriginalDocumentQuantity());
                originalDocumentQuantity = originalDocumentQuantity.setScale(PRECISION4,
                        BigDecimal.ROUND_HALF_UP);
                this.setDetailControlTotalCostSum(this.detailControlTotalCostSum.add(
                        originalUnitCost.multiply(originalDocumentQuantity)).doubleValue());
                this.setDetailControlTotalQuantitySum(this.detailControlTotalQuantitySum.add(
                        originalDocumentQuantity).doubleValue());

                for (Tax ediItemTax : ediTransactionDetailList[i].getEdiItemTaxes()) {
                    this.setTotalTaxAmountFromDetails(this.totalTaxAmountFromDetails.add(
                            (new BigDecimal(ediTransactionDetailList[i]
                                    .getOriginalDocumentQuantity()
                                    * ediTransactionDetailList[i].getOriginalUnitCost()
                                    * ediItemTax.getTaxRate() / 100.0))).doubleValue());
                }

                // go through allowance inside the detail
                if (this.ediTransactionDetailList[i].getEdiDetailAllowanceList() != null
                        && this.ediTransactionDetailList[i].getEdiDetailAllowanceList().length != 0) {
                    EdiDetailAllowance[] allowanceList = this.ediTransactionDetailList[i]
                            .getEdiDetailAllowanceList();

                    for (int j = 0; j < allowanceList.length; j++) {
                        Set<Tax> allowanceTaxes = allowanceList[j].getEdiItemAllowanceTaxes();
                        for (Tax edItemAllowanceTax : allowanceTaxes) {
                            this
                                    .setTotalTaxAmountFromDetails(this.totalTaxAmountFromDetails
                                            .add(
                                                    new BigDecimal(
                                                            (allowanceList[j].getAllowanceAmount() * edItemAllowanceTax
                                                                    .getTaxRate()) / 100.0))
                                            .doubleValue());
                        }

                    }

                }

            } // end loop through transaction details
        } else {
            // Details required for zero dollar merchandise invoices
            if (this.documentType.equals(Document.MERCHANDISE_INVOICE)
                    && this.totalCost.doubleValue() == 0) {
                fieldName = "error.batch.zero_dollar_invoice_details_required";
                Logger.errorKey(SmrEdiTransactionHeader.class, fieldName, new String[] {
                        EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID)});

                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DETAIL_REQUIRED, null, null);
                this.errorColumnId = "ERROR_DETAIL_REQUIRED";
                this.rejectReason = "ERROR_DETAIL_REQUIRED";
                this.transactionValid = false;
                return FAILURE_REJECT_TABLES;
            }
        }
        // Moved areValuesWithinTolerance method to NumberUtils class
        // verify the sum of costs from TDETL and TNMRC match with THEAD
        if (!NumberUtils.areValuesWithinTolerance(this.totalCost, this.detailControlTotalCostSum,
                systemOptions.getCalcTolerance(), systemOptions.getCalcToleranceInd())) {
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.total_costs_not_match",
                    new String[] { String.valueOf(this.totalCost),
                            String.valueOf(this.detailControlTotalCostSum),
                            String.valueOf(this.lineID),
                            String.valueOf(this.orderNumber),
                            String.valueOf(this.vendorDocumentNumber)});
//            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_COST_MATCH_THEAD, null, null);
            smrEdiOnlyReportHardEdits = true;
            this.errorColumnId = "ERROR_TOT_NOT_EQU_EXT";
            this.rejectReason = "ERROR_TOT_NOT_EQU_EXT";
             createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_NOT_EQU_EXT, null, null );
            return FAILURE_REJECT_FILE;
            
     //       this.transactionValid = false;
    //        return FAILURE_REJECT_TABLES;
        }

        // Verify if the Total Quantity is a whole number or not
        if (ReIMUserContext.getQuantityDecimalsAllowed() == 0
                && !this.totalQuantity.toString().equals(
                        this.totalQuantity.toBigInteger().toString())) {
            fieldName = ReIMI18NUtility.getMessage("batch.field.total_quantity");
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.quantity_eaches",
                    new String[] { fieldName, this.totalQuantity.toString(),
                            String.valueOf(this.lineID), fieldName});
            smrEdiOnlyReportHardEdits = true;
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_QTY_WHOLE, null, null);
            this.errorColumnId = "ERROR_TOT_QTY_WHOLE";
            this.rejectReason = "ERROR_TOT_QTY_WHOLE";
            return FAILURE_REJECT_TABLES;
        }

        if (totalHeaderQtyReqInd
                && !NumberUtils.areValuesWithinTolerance(this.totalQuantity,
                        this.detailControlTotalQuantitySum, systemOptions.getCalcTolerance(),
                        systemOptions.getCalcToleranceInd())) {
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.total_qtys_not_match",
                    new String[] { String.valueOf(this.totalQuantity),
                            String.valueOf(this.detailControlTotalQuantitySum),
                            String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                            String.valueOf(this.vendorDocumentNumber + "")});

            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_QTY_NOT_MATCH, null, null);
            this.errorColumnId = "ERROR_TOT_QTY_NOT_MATCH";
            this.rejectReason = "ERROR_TOT_QTY_NOT_MATCH";
            return FAILURE_REJECT_TABLES;
        }

        // The below checks don't follow the file-rejection/table-rejection
        // break up completely....
        // These checks go both ways - the possibility of rejecting to tables at
        // this point is needed
        // to completely validate possible file-rejection stuff....

        Vendor vendor = ServiceFactory.getVendorService().getVendor(this.vendorType, this.vendorID);

        if (vendor.getVendorId() != null && vendor.getVendorId().equals(this.vendorID)) {
            String vendorDocNumber=null;
            String extDoc =ServiceFactory.getDocumentService().getDocumentIdPrefix(this.documentType);
            if (extDoc != null) {
                vendorDocNumber=(extDoc + this.vendorDocumentNumber);
            } else {
                vendorDocNumber= this.vendorDocumentNumber;
            }

            // Anil P
            // Soft Edit duplicates Check
             if (! SmrServiceFactory.getSmrEdiRejectService().softDuplicates (this.vendorDocumentNumber, 
                                                                              this.orderNumber.toString(), 
                                                                              this.totalCost.doubleValue() , 
                                                                              this.vendorID )  ) {
                                                                                    
                      Logger.errorKey(SmrEdiTransactionHeader.class,
                                 "error.batch.vendor_doc_duplicate", new String[] {
                                 EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID), this.vendorID, this.vendorDocumentNumber,
                                 this.orderNumber.toString(), this.totalCost.toString()});                                                                              
    
                     createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_EXT_DOC_ID_EXIST, null, null);
                     this.errorColumnId = "ERROR_EXT_DOC_ID_EXIST";
                     this.rejectReason = "ERROR_EXT_DOC_ID_EXIST";
                     return FAILURE_REJECT_TABLES;
             } // End Mod Anil

            // ENH31 Start
            ImDocHeadRow headRow = SmrDocumentService.getDocumentByVendor(this.vendorID, vendorDocNumber, this.documentType);
            if (headRow != null && vendorDocNumber.equalsIgnoreCase(headRow.getExtDocId())) {
            	// it looks like the ext_doc_id (invoice id) already exists
              	if (this.orderNumber.longValue() == headRow.getOrderNo() && this.totalCost.equals(new BigDecimal(headRow.getTotalCost()))) {
              		// it looks like even the invoice total match, which makes it a real duplicate
              		Logger.errorKey(SmrEdiTransactionHeader.class,
              				"error.batch.vendor_doc_duplicate", new String[] {
              				EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID), this.vendorID, this.vendorDocumentNumber,
              				this.orderNumber.toString(), this.totalCost.toString()});
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUP_INVOICE, null, null);
            	    this.errorColumnId = "ERROR_DUP_INVOICE";
            	    this.rejectReason = "ERROR_DUP_INVOICE";
            	    smrEdiOnlyReportHardEdits = true;
                    // Anil P
                    // Hard Edit for True Duplicate
                    return FAILURE_REJECT_TABLES;
            	}
            	else {
            		// the invoice id is duplicate, but the total is different, which means rejection to table
              		Logger.errorKey(SmrEdiTransactionHeader.class,
              				"error.batch.vendor_doc_number_duplicate", new String[] {
              				EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentNumber,
              				String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
              				String.valueOf(this.vendorDocumentNumber + "")});
                    this.errorColumnId = "EXT_DOC_ID";
                    this.rejectReason = "ERROR_EXT_DOC_ID_EXIST";
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_EXT_DOC_ID_EXIST, null, null);
            	    return FAILURE_REJECT_TABLES;
            	}
            }
            else {
            	this.vendorDocumentNumber = this.vendorDocumentNumber.toUpperCase(UserContext
                    .getLocale());
            }
            boolean sdcLevelInvoice = isSupplierInvoiceAtSDCLevel(this.vendorID);
            if (sdcLevelInvoice) {
            	if (!this.locationType.equals(Location.WAREHOUSE)) {
            		Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invoice_level_not_SDC", new String[] {EDI_UPLOAD_PROGRAM_NAME,
            			String.valueOf(this.location), String.valueOf(this.lineID)});
            		    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_LEL_SDC, null, null);
                            // Anil P This is Hard edit if the invoice location does not match
                             this.errorColumnId = "ERROR_INV_LEL_SDC";
                             this.rejectReason = "ERROR_INV_LEL_SDC";
                             smrEdiOnlyReportHardEdits = true;
                            return FAILURE_REJECT_TABLES;
            	}
            }
            else {
            	if (!this.locationType.equals(Location.STORE)) {
            		Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invoice_level_not_store", new String[] {EDI_UPLOAD_PROGRAM_NAME,
            			String.valueOf(this.location), String.valueOf(this.lineID)});
            		    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_INV_LEL_ST, null, null);
               	            // Anil P This is Hard edit if the invoice location does not match
               	             this.errorColumnId = "ERROR_INV_LEL_ST";
               	             this.rejectReason = "ERROR_INV_LEL_ST";
               	             smrEdiOnlyReportHardEdits = true;
                            return FAILURE_REJECT_TABLES;
            	}
            }
            // ENH31 End
        }
        // the vendor number passed in is not valid for the system, this
        // trasaction will be
        // rejected to the database to allow the user to enter the correct
        // vendor number.
        // This means that the vendor document number has not been validated yet
        // - this will be
        // taken care of by the 'retry' logic before it actually does the retry.
        else {
            fieldName = ReIMI18NUtility.getMessage("batch.field.vendor_id");
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field", new String[] {
                    fieldName, this.vendorID, String.valueOf(this.lineID),
                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                    String.valueOf(this.vendorDocumentNumber + "")});

            if (this.vendorType.equals(Vendor.SUPPLIER)) {
                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR;

                return FAILURE_REJECT_TABLES;
            } else {
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_NOT_SUPP, null, null);
                return FAILURE_REJECT_TABLES;
            }
        }

        /*
         * Code is commented to fix the integration defect 75. Order Number received in the EDI file
         * can be null for the non-merchandise invoice sent from RMS. So, there is a possibility of
         * NullPointerException. Moreover, vendorId populated using the commented statement is used
         * only inside the next 'if' block and hence moving the statement inside the 'if' block
         * which has the check for (orderNumber != null). vendorId =
         * ServiceFactory.getOrderService().getVendorFromOrder(this.orderNumber.toString());
         */

        // If (RTV) order number is not null and RTV flag is 'Y', validate it
        // for the vendor
        if (this.orderNumber != null && this.rtvInd.equals(ReIMConstants.YES)) {
            // vendorId =
            // ServiceFactory.getOrderService().getVendorFromOrder(this.orderNumber.toString());
            // if
            // (!ServiceFactory.getRtvService().validateRtvOrderCheckingLinkedSuppliers(
            // this.orderNumber, vendorId)) {
            /*
             * Once the fix is done in RMS, this.vendorID will always have supplier_parent value.
             * validateRtvOrderCheckingLinkedSuppliers method checks whether matching record exist
             * in RTV_HEAD table for RTV_ORDER_NO and SUPPLIER_PARENT which is not true in case of
             * supplier site indicator ON environment.
             *
             * For example in the supplier site environment RTV_HEAD table (Supplier will be the
             * supplier site) @@@@@@@@@@@@@@@@@@@@@@@ @ RTV_ORDER_NO/SUPPLIER@ @ 1560006/2900
             *
             * @@@@@@@@@@@@@@@@@@@@@@@@
             *
             * this.VendorID is 8000 (supplier parent). validateRtvOrderCheckingLinkedSuppliers will
             * check for the entry (1560006/8000) (RTV_ORDER_NO/SUPPLIER) in RTV_HEAD table and
             * hence the validation fails.
             */
            if (!ServiceFactory.getRtvService().validateRtvOrderCheckingLinkedSuppliers(
                    this.orderNumber, this.vendorID)) {
                fieldName = ReIMI18NUtility.getMessage("label.rtv_order_no");
                Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
                        new String[] { fieldName, this.orderNumber.toString(),
                                String.valueOf(this.lineID)});

                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_RTV_SUPP_EXIST, null, null);
                this.errorColumnId = "ERROR_RTV_SUPP_EXIST";
                this.rejectReason = "ERROR_RTV_SUPP_EXIST";
                return FAILURE_REJECT_TABLES;
            }

            // validate location. Order/Location combination must exist on
            // ordloc
            if (!ServiceFactory.getRtvService().validateOrderLoc(this.location, this.orderNumber)) {
                fieldName = ReIMI18NUtility.getMessage("label.order_location");
                String locType = null;
                if (this.locationType.equals(Location.STORE))
                    locType = ReIMI18NUtility.getMessage("label.store");
                else
                    locType = ReIMI18NUtility.getMessage("label.warehouse");
                Logger.errorKey(SmrEdiTransactionHeader.class,
                        "error.batch.invalid_rtv_order_location", new String[] {
                                EDI_UPLOAD_PROGRAM_NAME, locType, this.location.toString(),
                                this.orderNumber.toString(), String.valueOf(this.lineID)});


                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_ORD_LOC_EXIST, null, null);
                this.errorColumnId = "ERROR_ORD_LOC_EXIST";
                this.rejectReason = "ERROR_ORD_LOC_EXIST";
                return FAILURE_REJECT_TABLES;
            }
        } // end if (orderNumber != null)

        // }

        // ********************************************************************************
        // Thead.Total TAx Amount = total tax from TDETL + total tax from TNMRC
        // + total tax from TALLW
        // Thead.Total TAX Amount = sum(TTAXS.TAX rate * TTAXS.cost at this TAX
        // code)
        // ********************************************************************************
        totalTaxAmount.setScale(4, BigDecimal.ROUND_HALF_UP);
        totalTaxAmountFromTTAXS.setScale(4, BigDecimal.ROUND_HALF_UP);
        if (!NumberUtils.areValuesWithinTolerance(totalTaxAmount, totalTaxAmountFromTTAXS,
                systemOptions.getCalcTolerance(), systemOptions.getCalcToleranceInd())
                && systemOptions.isProcessTaxes()) {
            Logger.errorKey(SmrEdiTransactionHeader.class,
                    "error.batch.header_tax_amount_does_not_match_tax_breakdown");
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_HD_TAX_AMT_NOT_MATCH, null, null);
            this.errorColumnId = "ERROR_HD_TAX_AMT_NOT_MATCH";
            this.rejectReason = "ERROR_HD_TAX_AMT_NOT_MATCH";
            return FAILURE_REJECT_TABLES;
        }

        this.totalTaxAmount = this.totalTaxAmount.setScale(4, BigDecimal.ROUND_HALF_UP);

        if (!NumberUtils.areValuesWithinTolerance(this.totalTaxAmount,
                this.totalTaxAmountFromDetails, systemOptions.getCalcTolerance(), systemOptions
                        .getCalcToleranceInd())) {
            Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.total_tax_amount_not_match");
            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_TAX_AMT_NOT_MATCH, null, null);
            this.errorColumnId = "ERROR_TOT_TAX_AMT_NOT_MATCH";
            this.rejectReason = "ERROR_TOT_TAX_AMT_NOT_MATCH";
            return FAILURE_REJECT_TABLES;
        }

        return VALIDATION_SUCCESS;
    }

    public EdiValidationResult validateTaxWithPrimaryRejectionToFile() throws ReIMException {

        // ***********************************************************************************
        // validate if system_option.tax = on && not import doc && TTAXS = null
        // --> reject to file
        // ***********************************************************************************
        try {
            EdiValidationResult ediValidationResult = null;
            BigDecimal totalCostIncTaxes = this.totalCost.add(this.totalTaxAmount);
            long locTaxRegion = -1L;

            if (this.vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
                locTaxRegion = DaoFactory.getLocationBean().getTaxRegion(
                        String.valueOf(this.location));

                long supplierTaxRegion = -1L;

                supplierTaxRegion = DaoFactory.getSupplierBean().getTaxRegion(this.vendorID);

                if ((locTaxRegion == supplierTaxRegion)
                        && ReIMSystemOptions.getInstance().isProcessTaxes()) {
                    if (this.ediTaxDetailList == null || this.ediTaxDetailList.length == 0) {
                        Logger.errorKey(SmrEdiTransactionHeader.class,
                                "error.batch.tax_detail_is_required");
                        createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NO_TAX_DETL, null, null);
                        this.errorColumnId = "ERROR_NO_TAX_DETL";
                        this.rejectReason = "ERROR_NO_TAX_DETL";
                        return FAILURE_REJECT_TABLES;
                    }
                }
            } else {
                locTaxRegion = DaoFactory.getLocationBean().getTaxRegion(
                        String.valueOf(this.location));
                long partnerTaxRegion = -1L;

                PartnerBean partnerBean = new PartnerBean();
                partnerTaxRegion = partnerBean.getPartnerTaxRegion(this.vendorID);
                if ((locTaxRegion == partnerTaxRegion)
                        && ReIMSystemOptions.getInstance().isProcessTaxes()) {
                    if (this.ediTaxDetailList == null || this.ediTaxDetailList.length == 0) {
                        Logger.errorKey(SmrEdiTransactionHeader.class,
                                "error.batch.tax_detail_is_required");
                        createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NO_TAX_DETL, null, null);
                        this.errorColumnId = "ERROR_NO_TAX_DETL";
                        this.rejectReason = "ERROR_NO_TAX_DETL";
                        return FAILURE_REJECT_TABLES;
                    }
                }
            }

            NonMerchandiseDocument[] nonMerchandiseDocs = null;
            Tax[] taxes = null;
            DocumentItem[] docItems = null;

            if (this.ediNonMerchDetailList != null && this.ediNonMerchDetailList.length > 0) {
                int nonMerchListLength = this.ediNonMerchDetailList.length;
                nonMerchandiseDocs = new NonMerchandiseDocument[nonMerchListLength];
                for (int k = 0; k < nonMerchListLength; k++) {
                    ediValidationResult = this.ediNonMerchDetailList[k]
                            .validateTaxWithPrimaryRejectionToFile(this);
                    if (ediValidationResult.isFailure()) {
                    	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_NON_MERCH_TAX_CODE, null, null);
                        this.errorColumnId = "ERROR_NON_MERCH_TAX_CODE";
                        this.rejectReason = "ERROR_NON_MERCH_TAX_CODE";
                    	return FAILURE_REJECT_TABLES;
                    }
                    NonMerchandiseDocument nonMerchDoc = new NonMerchandiseDocument();
                    nonMerchDoc.setNonMerchCode(this.ediNonMerchDetailList[k]
                            .getNonMerchandiseCode());
                    double nonMerchAmount = this.ediNonMerchDetailList[k].getNonMerchandiseAmount();
                    nonMerchDoc.setNonMerchAmt(nonMerchAmount);
                    Set<Tax> ediNonMerchTaxes = this.ediNonMerchDetailList[k].getEdiNonMerchTaxes();
                    for (Tax ediNonMerchTax : ediNonMerchTaxes) {
                        nonMerchDoc.addNonMerchTax(new Tax(ediNonMerchTax.getTaxCode(),
                                ediNonMerchTax.getTaxRate(), nonMerchAmount));
                        ediNonMerchTax.setTaxBasis(nonMerchAmount);
                    }
                    nonMerchandiseDocs[k] = nonMerchDoc;
                }
            }

            if (this.ediTaxDetailList != null && this.ediTaxDetailList.length > 0) {
                int taxsLength = this.ediTaxDetailList.length;
                taxes = new Tax[taxsLength];

                for (int m = 0; m < taxsLength; m++) {
                    ediValidationResult = this.ediTaxDetailList[m]
                            .validateTaxWithPrimaryRejectionToFile(this);
                    if (ediValidationResult.isFailure()) {
                    	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TAX_CODE, null, null);
                        this.errorColumnId = "ERROR_TAX_CODE";
                        this.rejectReason = "ERROR_TAX_CODE";
                    	return FAILURE_REJECT_TABLES;
                    }
                    Tax tax = new Tax(this.ediTaxDetailList[m].getTaxCode(),
                            this.ediTaxDetailList[m].getTaxRate());
                    tax.setTaxBasis(this.ediTaxDetailList[m].getTaxBasis());
                    taxes[m] = tax;
                }

            }
            if (this.ediTransactionDetailList != null && this.ediTransactionDetailList.length > 0) {
                int detailLength = this.ediTransactionDetailList.length;
                docItems = new DocumentItem[detailLength];
                for (int n = 0; n < detailLength; n++) {
                    DocumentItem docItem = new DocumentItem();
                    docItem.setUnitCost(this.ediTransactionDetailList[n].getOriginalUnitCost());
                    docItem.setQty(this.ediTransactionDetailList[n].getOriginalDocumentQuantity());
                    Set<Tax> ediItemTaxes = this.ediTransactionDetailList[n].getEdiItemTaxes();
                    docItem.setTaxes(ediItemTaxes);
                    // /
                    docItems[n] = docItem;
                }
            }
            int orderNo = 0;
            if (this.orderNumber != null) {
                orderNo = this.orderNumber.intValue();
            }
            long locId = 0;
            if (this.location != null) {
                locId = this.location.longValue();
            }
            if (ReIMSystemOptions.getInstance().isProcessTaxes()
                    && vendorType.equalsIgnoreCase(Document.SUPPLIER)) {
                ServiceFactory.getTaxService().validateTaxTotals(this.totalCost.doubleValue(),
                        this.totalTaxAmount.doubleValue(), totalCostIncTaxes.doubleValue(),
                        nonMerchandiseDocs, taxes, orderNo, locId, docItems, this.vendorID, false,
                        this.documentType, vendorType);
            }
            if (this.ediTransactionDetailList != null) {
                for (EdiTransactionDetail ediTransactionDetail : this.ediTransactionDetailList) {
                    ediValidationResult = ediTransactionDetail
                            .validateTaxWithPrimaryRejectionToFile(vendorType, this.vendorID,
                                    location, documentType, this);
                    if (ediValidationResult.isFailure()) {
                    	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TAX_MATCH_SYS, null, null);
                        this.errorColumnId = "ERROR_TAX_MATCH_SYS";
                        this.rejectReason = "ERROR_TAX_MATCH_SYS";
                    	return FAILURE_REJECT_TABLES;
                    }
                    EdiDetailAllowance[] ediDetailAllowances = ediTransactionDetail
                            .getEdiDetailAllowanceList();
                    if (ediDetailAllowances != null) {
                        for (EdiDetailAllowance ediDetailAllowance : ediDetailAllowances) {
                            ediValidationResult = ediDetailAllowance
                                    .validateTaxWithPrimaryRejectionToFile(this);
                            if (ediValidationResult.isFailure()) {
                            	createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_ALLO_TAX_CODE, null, null);
                                this.errorColumnId = "ERROR_ALLO_TAX_CODE";
                                this.rejectReason = "ERROR_ALLO_TAX_CODE";
                            	return FAILURE_REJECT_TABLES;
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            return FAILURE_REJECT_FILE;
        }
        return VALIDATION_SUCCESS;

    }

    // this method is actually conducting table reject transaction validation.
    @SuppressWarnings("rawtypes")
	public EdiValidationResult validateWithPrimaryRejectionToTables(boolean checkForFileRejections,
            boolean allowDateBeforePostDatedDocDays) throws ReIMException {
        String fieldName = null;
        String defaultVendorTerms = null;
        String vendorId = null;
        
        int postDatedDocDays = EdiTransactionHeaderValidationService.getPostDatedDocDays();

        ReIMDate vDate = new ReIMDate();
        if (ApplicationContext.isBatchApplication()) {
            vDate = ServiceFactory.getPeriodService().getVDate();
        } else {
            vDate = ServiceFactory.getPeriodService().getScreenVDate();
        }
        ReIMDate validMinDate = new ReIMDate(vDate.addDays(-postDatedDocDays, vDate));

        // this validation happens in the validateForFileRejection method (call
        // to
        // VendorService.getVendor() and Long.parseLong(this.vendorID) ), but
        // needs
        // to happen here as well for 'retrying' a document through the gui.
        if (this.vendorType.equals(Vendor.SUPPLIER)) {
            try {
                Long.parseLong(this.vendorID);
            } catch (NumberFormatException e) {
                if (checkForFileRejections) {
                    String key = "error.batch.invalid_number_format";
                    String[] parameters = new String[] { EDI_UPLOAD_PROGRAM_NAME, this.vendorID,
                            String.valueOf(this.lineID)};
                    Logger.errorKey(SmrEdiTransactionHeader.class, key, parameters);
                }
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_ID, null, null);
                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_VENDOR;
                smrEdiOnlyReportHardEdits = true;
                return FAILURE_REJECT_TABLES;
            }

            // ENH31 Start
            String vendorDocNumber=null;
            String extDoc =ServiceFactory.getDocumentService().getDocumentIdPrefix(this.documentType);
            if (extDoc != null) {
                vendorDocNumber=(extDoc + this.vendorDocumentNumber);
            } else {
                vendorDocNumber= this.vendorDocumentNumber;
            }
            ImDocHeadRow headRow = SmrDocumentService.getDocumentByVendor(this.vendorID, vendorDocNumber, this.documentType);
            if (headRow != null && vendorDocNumber.equalsIgnoreCase(headRow.getExtDocId())) {
              	Logger.errorKey(SmrEdiTransactionHeader.class,
              			"error.batch.vendor_doc_number_duplicate", new String[] {
              			EDI_UPLOAD_PROGRAM_NAME, this.vendorDocumentNumber,
              			String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
              			String.valueOf(this.vendorDocumentNumber + "")});
                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                this.rejectReason = EdiRejectReasons.INVALID_DUP_VENDOR_DOC_NUMBER;
                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUP_VPN, null, null);
                return FAILURE_REJECT_TABLES;
            }
            else {
            	this.vendorDocumentNumber = this.vendorDocumentNumber.toUpperCase(UserContext
                    .getLocale());
            }
            // ENH31 End

            if (this.orderNumber != null) {
                // vendorId =
                // ServiceFactory.getOrderService().getVendorFromOrder(
                // this.orderNumber.toString());
                // ValidateVendorId returns default terms which are required for
                // all
                // vendors and this value is saved for defaulting purposes
                if (isSupplierSiteEnabled() && StringUtils.isNotBlank(this.supplierSiteID)) {
                    defaultVendorTerms = ServiceFactory.getVendorService().getVendor(
                            this.vendorType, this.supplierSiteID).getVendorTerms();
                } else {
                    defaultVendorTerms = ServiceFactory.getVendorService().getVendor(
                            this.vendorType, this.vendorID).getVendorTerms();
                }

                if (defaultVendorTerms == null) {
                    if (checkForFileRejections) {
                        fieldName = ReIMI18NUtility.getMessage("batch.field.vendor_id");
                        Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
                                new String[] { fieldName, this.vendorID,
                                        String.valueOf(this.lineID), String.valueOf(this.lineID),
                                        String.valueOf(this.orderNumber + ""),
                                        String.valueOf(this.vendorDocumentNumber + "")});
                    }

                    this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VENDOR;
                    this.rejectReason = EdiRejectReasons.INVALID_VENDOR;
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_VENDOR_ID, null, null);
                    smrEdiOnlyReportHardEdits = true;
                    return FAILURE_REJECT_TABLES;
                }
            }
        }
        /*
         * Validate terms. If terms are not specified, they should be defaulted from the vendor.
         * Valid terms must exist from the merchandising application All fields required by us and
         * not required in file upload need to be defaulted in before we begin business validation.
         * If not edi reject records will not be valid.
         */
        if (this.terms == null || this.terms.trim().length() == 0) {
            this.terms = defaultVendorTerms;
        }

        // validTerm will validate the term ID and also get the default terms
        // percentage.
        // Since this is hard edit commneted out the code below
        if (this.terms.length() == 0) {
            this.terms= "D";
        }
        termValidationResults = EdiTransactionHeaderValidationService.validateTerm(this.terms);
        if (!((Boolean) termValidationResults[0]).booleanValue()) {
            if (checkForFileRejections) {
                fieldName = ReIMI18NUtility.getMessage("label.terms");
                Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
                        new String[] { fieldName, this.terms, String.valueOf(this.lineID),
                    String.valueOf(this.orderNumber + ""),
                    String.valueOf(this.vendorDocumentNumber + "")});
            }

            this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_TERMS;
            this.rejectReason = EdiRejectReasons.INVALID_TERMS;

            return FAILURE_REJECT_TABLES;
        }

        // [1] is the defualt term discount percentage
        this.termsDiscountPercentage = (Double) termValidationResults[1];

        // check vendor document date: (vDate - postDatedDocDays) <
        // vendorDocumentdate < vDate
        if (!EdiTransactionHeaderValidationService.validateVendorDocumentDate(
                this.vendorDocumentDate, vDate, validMinDate)) {
            boolean invDateEarlier = ServiceFactory.getInvoiceMaintenanceService()
                    .checkInvoiceDateBeforePostDatedDocDays(this.vendorDocumentDate, vDate);
            if (!(allowDateBeforePostDatedDocDays && invDateEarlier)) {
                this.vendorDocumentDate = ServiceFactory.getPeriodService().getVDate();
//                if (checkForFileRejections) {
//                    Logger
//                            .errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_doc_date",
//                                    new String[] { EDI_UPLOAD_PROGRAM_NAME,
//                                            String.valueOf(validMinDate), String.valueOf(vDate),
//                                            String.valueOf(this.vendorDocumentDate)});
//                }
//
//                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_DOC_DATE;
//                this.rejectReason = EdiRejectReasons.INVALID_DATE;
//                createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_DUE_DATE, null, null);
//                return FAILURE_REJECT_TABLES;
            }
        }
        if (! SmrServiceFactory.getSmrEdiRejectService().softDuplicates (this.vendorDocumentNumber, 
                this.orderNumber.toString(), 
                this.totalCost.doubleValue() , 
                this.vendorID )  ) {
                      
                 Logger.errorKey(SmrEdiTransactionHeader.class,
                                      "error.batch.vendor_doc_duplicate", new String[] {
                                      EDI_UPLOAD_PROGRAM_NAME, String.valueOf(this.lineID), this.vendorID, this.vendorDocumentNumber,
                                      this.orderNumber.toString(), this.totalCost.toString()});                                                                              

                                      createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_EXT_DOC_ID_EXIST, null, null);
                                      this.errorColumnId = "ERROR_EXT_DOC_ID_EXIST";
                                      this.rejectReason = "ERROR_EXT_DOC_ID_EXIST";
                                       return FAILURE_REJECT_TABLES;
         } // End Mod Anil

        if (this.dueDate == null) {
            try {
                this.dueDate = new ReIMDate(ServiceFactory.getTermsService().calculateTermsDueDate(
                        this.vendorDocumentDate.toString(), this.terms, vDate));
            } catch (RetekException e) {
                throw new ReIMException("error.cannot_compute_due_date", Severity.FATAL, this);
            }
        }

        String supplierDefaultInd = null;
        try {
            supplierDefaultInd = DaoFactory.getSupplierBean()
                    .getSupplierFinalDestInd(this.vendorID);
        } catch (Exception e) {
            throw new ReIMException(e);
        }

//        // check that the loc/loc type combo is valid....
//        if (this.locationType.equals(Location.STORE)) {
//            if (LocationService.validStore(this.location) == false) {
//                if (checkForFileRejections) {
//                    String key = ReIMI18NUtility.getMessage("batch.field.store");
//                    Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
//                            new String[] { key, String.valueOf(this.location),
//                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
//                                    String.valueOf(this.vendorDocumentNumber + "")});
//                }
//
//                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_LOCATION;
//                this.rejectReason = EdiRejectReasons.INVALID_LOCATION;
//               // throw new ReIMException("Code.REJRES.INVALID_LOCATION", Severity.FATAL, this);
//                // Anil P COmmented out below line and added above line
//               return FAILURE_REJECT_FILE;
//            }
//        } else if (this.locationType.equals(Location.WAREHOUSE)) {
//            if (LocationService.validWarehouse(this.location) == false) {
//                if (checkForFileRejections) {
//                    String key = ReIMI18NUtility.getMessage("batch.field.warehouse");
//                    Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
//                            new String[] { key, String.valueOf(this.location),
//                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
//                                    String.valueOf(this.vendorDocumentNumber + "")});
//                }
//
//                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_LOCATION;
//                this.rejectReason = EdiRejectReasons.INVALID_LOCATION;
//                // throw new ReIMException("Code.REJRES.INVALID_LOCATION", Severity.FATAL, this);
//                // Anil P COmmented out below line and added above line
//                return FAILURE_REJECT_FILE;
//            }
//        }

        // If order number is not null, validate it for the vendor
        if (this.orderNumber != null
                && (this.rtvInd == null || this.rtvInd.equals(ReIMConstants.NO))) {
            vendorId = ServiceFactory.getOrderService().getVendorFromOrder(
                    this.orderNumber.toString());
            // order number exists but is not valid for the supplier or the
            // supplier's linked suppliers
            if (vendorId == null
                    || !ServiceFactory.getOrderService().validateOrderCheckingLinkedSuppliers(
                            this.orderNumber, vendorId)) {
                if (checkForFileRejections) {
                    fieldName = ReIMI18NUtility.getMessage("label.order_number");
                    Logger.errorKey(SmrEdiTransactionHeader.class, "error.batch.invalid_field",
                            new String[] { fieldName, this.orderNumber.toString(),
                                    String.valueOf(this.lineID), String.valueOf(this.orderNumber + ""),
                                    String.valueOf(this.vendorDocumentNumber + "")});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ORDER_NO;
                this.rejectReason = EdiRejectReasons.INVALID_ORDER_NO_FOR_SUPPLIER;
                createSmrEdiReportRecord(SmrEdiRejectReasons.INVALID_ORDER_NO_FOR_SUPPLIER, null, null);
                return FAILURE_REJECT_TABLES;
            }

            // validate location. Order/Location combination must exist on
            // ordloc
            if (!nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT)
                    && "N".equalsIgnoreCase(supplierDefaultInd)
                    && !ServiceFactory.getOrderService().validateOrderLoc(this.locationType,
                            this.location, this.orderNumber)) {
                if (checkForFileRejections) {
                    fieldName = ReIMI18NUtility.getMessage("label.order_location");
                    String locType = null;
                    if (this.locationType.equals(Location.STORE))
                        locType = ReIMI18NUtility.getMessage("label.store");
                    else
                        locType = ReIMI18NUtility.getMessage("label.warehouse");
                    Logger.errorKey(SmrEdiTransactionHeader.class,
                            "error.batch.invalid_order_location", new String[] {
                                    EDI_UPLOAD_PROGRAM_NAME, locType, this.location.toString(),
                                    this.orderNumber.toString(), String.valueOf(this.lineID)});
                }

                this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_LOCATION;
                this.rejectReason = EdiRejectReasons.INVALID_ORDER_NO_FOR_LOCATION;
                createSmrEdiReportRecord(SmrEdiRejectReasons.INVALID_ORDER_NO_FOR_LOCATION, null, null);
                return FAILURE_REJECT_TABLES;
            }
        } // end if (orderNumber != null)

        // Exchange Rate - no business-level validation at this point.
        // Control total cost - no business-level validation at this point.
        // Control total quantity - no business-level validation at this point.
        // Total discount - no business-level validation at this point.
        // Custom Document Reference 1 - no business-level validation at this
        // point.
        // Custom Document Reference 2 - no business-level validation at this
        // point.
        // Custom Document Reference 3 - no business-level validation at this
        // point.
        // Custom Document Reference 4 - no business-level validation at this
        // point.

        // Anil Potukuchi OLR MOD
        // Added the following Code
        // Check for Valid Item or Valid UPC
        // Invoice total cost matches extended cost ( original qty * unit cost)

         if (ediTransactionDetailList != null && ediTransactionDetailList.length != 0) {
          //   Set<String> itemSet2 = new HashSet<String>();
             int listLength2 = ediTransactionDetailList.length;
             double invExtendedCost = 0;
              BigDecimal invExtendedCost2 = new BigDecimal(0);
//////             this.totalCost = new BigDecimal(totalCost);
////             this.totalCost = this.totalCost.setScale(4, BigDecimal.ROUND_HALF_UP);
//             
             for (int i = 0; i < listLength2; i++) {
                 // Validate Item
                  
//                 if ( ediTransactionDetailList[i].getItem().length() != 0) {
//                     if (!ServiceFactory.getItemService().isValidItem(ediTransactionDetailList[i].getItem())) {
//                        Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_item",
//                                new String[] { EDI_UPLOAD_PROGRAM_NAME, ediTransactionDetailList[i].getItem(),
//                                        String.valueOf(this.lineID)});
//                                
//                        this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
//                        this.rejectReason = EdiRejectReasons.INVALID_UPC;
//                        this.transactionValid = false;
//                        smrEdiOnlyReportHardEdits = true;
//                        createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_SKU, null, ediTransactionDetailList[i].getItem() );
//                        return FAILURE_REJECT_FILE;
//                    }
//                 }
                 // Validate UPC
                 
                  if ( ediTransactionDetailList[i].getUpc().length() != 0) {
                        if (this.upcSupp == null) {
                              this.upcSupp = new Long(0);
                        }
                
//                      if (ServiceFactory.getItemService().validUpc(ediTransactionDetailList[i].getUpc(), this.upcSupp) == null ) {
System.out.println("ediTransactionDetailList[i].getUpc() in EdiTransactionHeader " + ediTransactionDetailList[i].getUpc()); 
                    if (SmrDocumentService.validUpc(ediTransactionDetailList[i].getUpc(), this.upcSupp) == null ) {
                                  Logger.errorKey(EdiTransactionDetail.class, "error.batch.invalid_upc",
                                 new String[] { EDI_UPLOAD_PROGRAM_NAME, ediTransactionDetailList[i].getUpc(),
                                         String.valueOf(this.lineID)});
                                 
                         this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
                         this.rejectReason = EdiRejectReasons.INVALID_UPC;
                         this.transactionValid = false;
                         smrEdiOnlyReportHardEdits = true;
                         createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_UPC, null, ediTransactionDetailList[i].getUpc() );
                         return FAILURE_REJECT_FILE;
                     }
                }
                 // Calculate Extended Cost
                 invExtendedCost =  invExtendedCost + (ediTransactionDetailList[i].getOriginalDocumentQuantity() * ediTransactionDetailList[i].getOriginalUnitCost() ) ;
                 
             } // end of loop
              invExtendedCost2 = new BigDecimal(invExtendedCost);
             //System.out.println(" this.totalCost.doubleValue() != invExtendedCost " +  totalCost  + " " + invExtendedCost2.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP) ); 
//             if ( this.totalCost  != invExtendedCost2.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP) ) {
//                 smrEdiOnlyReportHardEdits = true;
//                 this.transactionValid = false;
//                 this.errorColumnId = "ERROR_TOT_NOT_EQU_EXT";
//                 this.rejectReason = "ERROR_TOT_NOT_EQU_EXT";
//                 createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_TOT_NOT_EQU_EXT, null, null );
//                 return FAILURE_REJECT_FILE;
//             }
//             
         }// // Anil Potukuchi OLR MOD

        if (ediTransactionDetailList != null && ediTransactionDetailList.length != 0) {
            Set<String> itemSet = new HashSet<String>();
            int listLength = ediTransactionDetailList.length;

            for (int i = 0; i < listLength; i++) {
            
                if (ediTransactionDetailList[i].validateWithPrimaryRejectionToTables(this,
                        checkForFileRejections).isFailure()) {
                    // the errorColumnId, rejectReason and rejectedDocDetailId
                    // were set in the detail,
                    // so we can just return here.
                    // Anil
                    System.out.println(" before the ERROR " + ediTransactionDetailList[i].getUpc()); 
                    createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_UPC, null, ediTransactionDetailList[i].getUpc() );
                    this.errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
                    this.rejectReason = EdiRejectReasons.INVALID_UPC;
                    smrEdiOnlyReportHardEdits = true;
                    return FAILURE_REJECT_FILE;
                }

                // Check for duplicate items for the document. If the item is
                // duplicated, then this
                // item is invalid. If the item is not duplicated, add it to the
                // hashset for future
                // item duplication checks.
                if (this.merchType == null || this.merchType.equals("")
                        || !nullSafeEquals(merchType, ReIMConstants.MERCH_TYPE_CONSIGNMENT)) {

                    String itemToCheck = ediTransactionDetailList[i].getItem();
                    EdiItemSource itemSource = ediTransactionDetailList[i].getEdiItemSource();
                    if (itemSet.contains(itemToCheck)) {

                        String errorMsg = "";
                        String errorReason = "";
                        String errorColumnId = "";

                        if (itemSource.equals(EdiItemSource.UPC)) {
                            System.out.println(" before the ERROR 22222" + ediTransactionDetailList[i].getUpc()); 
                            errorMsg = "error.batch.duplicate_upc";
                            errorReason = EdiRejectReasons.INVALID_UPC_DUPLICATE;
                            errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_ITEM;
                            smrEdiOnlyReportHardEdits = true;
                            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_UPC, null, ediTransactionDetailList[i].getUpc());
                        } else { // VPN
//                            errorMsg = "error.batch.duplicate_vpn";
//                            errorReason = EdiRejectReasons.INVALID_VPN_DUPLICATE;
//                            errorColumnId = EdiRejectReasons.ERROR_COLUMN_ID_VPN;
//                            smrEdiOnlyReportHardEdits = true;
//                            createSmrEdiReportRecord(SmrEdiRejectReasons.ERROR_SKU, null, null);
                        }
                     if (errorReason != "") {
                        if (checkForFileRejections) {
                            Logger.errorKey(SmrEdiTransactionHeader.class, errorMsg, new String[] {
                                    EDI_UPLOAD_PROGRAM_NAME, ediTransactionDetailList[i].getUpc(),
                                    String.valueOf(ediTransactionDetailList[i].getLineID())});

                        }

                        this.errorColumnId = errorColumnId;
                        this.rejectReason = errorReason;
                        this.rejectedDocDetailId = ediTransactionDetailList[i].getDocDetailId();
                        return FAILURE_REJECT_FILE;
                     }
                    } else {
                        itemSet.add(ediTransactionDetailList[i].getItem());
                    }
                }

                else {
                    if (!itemSet.contains(ediTransactionDetailList[i].getItem()))
                        itemSet.add(ediTransactionDetailList[i].getItem());
                }

            }
            EdiTransactionDetail.setItemSet(new HashSet());
        }

        if (checkForFileRejections) {
            EdiValidationResult taxValidationResult = validateTaxWithPrimaryRejectionToFile();
            if (taxValidationResult.isFailure()) { return FAILURE_REJECT_FILE; }
        }
        return VALIDATION_SUCCESS;
    }

    private boolean validateWithPatternString(String validateString, String pattern) {
        return PatternMatchingUtils.matches(
                pattern == null ? PatternMatchingUtils.ALPHA_NUMERIC_PATTERN : pattern,
                validateString, true);
    }

    private boolean validNoLeadingZeroString(String s) {
        if (s.charAt(0) == '0') {
            if (UIFieldValidationService.isLeadingZeroInvoiceNumberAllowed())
                return true;
            else
                return false;
        } else {
            return true;
        }
    }

    // ENH31 Start
    private void modifyDueDate() throws ReIMException {
    	// Get the earliest of all receiptDate of the unmatched or partially matched receipts
    	Receipt[] receipts = ServiceFactory.getReceiptService().selectReceiptsFromInvoiceOrder(this.orderNumber.toString(), this.location.toString(), false);
    	ReIMDate earliestReceiptDate = null;
    	for (Receipt receipt : receipts) {
    		String status = receipt.getInvoiceMatchStatus();
    		ReIMDate receiptDate = receipt.getReceiptDate();
    		if (receiptDate != null && (Receipt.UNMATCHED.equals(status) || Receipt.PARTIALLY_MATCHED.equals(status))) {
    			if (earliestReceiptDate == null) {
    				earliestReceiptDate = receiptDate;
    			}
    			else {
    				earliestReceiptDate = (earliestReceiptDate.after(receiptDate)) ? receiptDate : earliestReceiptDate;
    			}
    		}
    	}

    	// Get the invoice date and the term days
    	ReIMDate invoiceDate = new ReIMDate(this.vendorDocumentDate);

    	String termsId = this.terms;
    	if (termsId == null) {
    		termsId = ServiceFactory.getVendorService().selectTermsIdFromVendor(this.vendorID, this.vendorType);
    	}
    	Term term = ServiceFactory.getTermsService().getTerms(termsId);
    	int termDays = 0;
    	if (term != null)
    	    termDays = term.getDuedays();

    	// Add the term days to both the receiptDate and the invoiceDate and find out which one is later
    	if (earliestReceiptDate != null && invoiceDate != null){
    	    earliestReceiptDate.addDays(termDays);
    	    invoiceDate.addDays(termDays);
    	    ReIMDate laterDate = (invoiceDate.after(earliestReceiptDate)) ? invoiceDate : earliestReceiptDate;

    	    // If due date is null, then it becomes the later of receiptDate and invoiceDate. If not null, then it is the later of dueDate, receiptDate and invoiceDate
        	if (this.dueDate == null) {
        		this.dueDate = laterDate;
        	}
        	else {
        		this.dueDate = (dueDate.after(laterDate)) ? dueDate : laterDate;
        	}
    	}
    }

    private boolean isSupplierInvoiceAtSDCLevel(String vendorId) throws ReIMException {
    	return new SmrSupplierService().isSupplierInvoiceAtSDCLevel(vendorId);
    }

// Anil P Copy original Vendor
    private SmrEdiReportRecord createSmrEdiReportRecord(String errorCode, String sku, String upc)
    throws ReIMException{
    	smrEdiReportRecord = new SmrEdiReportRecord();
//    	smrEdiReportRecord.setVendor(supplierSiteID);
       if (fileVendorID != null ) {
        smrEdiReportRecord.setVendor(Long.toString(Long.parseLong(fileVendorID)) );
       } else if (vendorID != null && fileVendorID == null) {
           smrEdiReportRecord.setVendor(vendorID );
       }
       if (smrEdiOnlyReportHardEdits) {
           smrEdiReportRecord.setErrorInd(true);
           smrEdiOnlyReportHardEdits = false;
       } else {
           smrEdiReportRecord.setErrorInd(false);
       }
    	smrEdiReportRecord.setExtDocId(vendorDocumentNumber);
    	smrEdiReportRecord.setBatchId(customDocumentReference1);
    	smrEdiReportRecord.setErrorCode(errorCode);
    	smrEdiReportRecord.setSku(sku);
    	smrEdiReportRecord.setUpc(upc);
    	ReIMDate vDate = new ReIMDate();
        if (ApplicationContext.isBatchApplication()) {
            vDate = ServiceFactory.getPeriodService().getVDate();
        } else {
            vDate = ServiceFactory.getPeriodService().getScreenVDate();
        }
    	smrEdiReportRecord.setUpldTimeStamp(vDate);
    	smrEdiReportRecord.setTotalCost(totalCost.doubleValue());
    	smrEdiReportRecord.setTotalQty(totalQuantity.doubleValue());

    	return this.smrEdiReportRecord;
    }
    // ENH31 End

    /*
     * This method checks whether the vendor line corresponds to a supplier or a supplier site. This
     * scenario happens only in Supplier Site ON. If the vendor line is supplier, corresponding
     * supplier site has to be fetched and set for supplierSite. If the vendor line is supplier
     * site, corresponding supplier parent has to be fetched and set for vendor.
     */
/*    protected void checkVendorOrSupplierSite(String vendorId) throws ReIMException {
        String vendorFromOrder = ServiceFactory.getVendorService().getSupplierParent(vendorId);

    }*/

    public long getLineID() {
        return lineID;
    }

    public String getRecordDescriptor() {
        return recordDescriptor;
    }

    public long getTransactionNumber() {
        return transactionNumber;
    }

    public double getTotalCost() {
        return totalCost.doubleValue();
    }

    public double getTotalQuantity() {
        return totalQuantity.doubleValue();
    }

    public Long getCrossReferenceDocumentNumber() {
        return crossReferenceDocumentNumber;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public String getCustomDocumentReference1() {
        return customDocumentReference1;
    }

    public String getCustomDocumentReference2() {
        return customDocumentReference2;
    }

    public String getCustomDocumentReference3() {
        return customDocumentReference3;
    }

    public String getCustomDocumentReference4() {
        return customDocumentReference4;
    }

    public String getDocumentType() {
        return documentType;
    }

    public ReIMDate getDueDate() {
        return dueDate;
    }

    public Double getExchangeRate() {
        return exchangeRate;
    }

    public String getFreightType() {
        return freightType;
    }

    public String getManuallyPaidInd() {
        return manuallyPaidInd;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getTerms() {
        return terms;
    }

    public Double getTermsDiscountPercentage() {
        return termsDiscountPercentage;
    }

    public double getTotalDiscount() {
        return totalDiscount.doubleValue();
    }

    public ReIMDate getVendorDocumentDate() {
        return vendorDocumentDate;
    }

    public String getVendorDocumentNumber() {
        return vendorDocumentNumber;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getVendorType() {
        return vendorType;
    }

    public Long getLocation() {
        return location;
    }

    public String getLocationType() {
        return locationType;
    }

    public Long getOrderNumber() {
        return orderNumber;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public EdiNonMerchDetail[] getEdiNonMerchDetailList() {
        return ediNonMerchDetailList;
    }

    public EdiTransactionDetail[] getEdiTransactionDetailList() {
        return ediTransactionDetailList;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setTotalCost(double controlTotalCost) {
        this.totalCost = new BigDecimal(controlTotalCost);
        this.totalCost = this.totalCost.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
    }

    public void setTotalQuantity(double controlTotalQuantity) {
        this.totalQuantity = new BigDecimal(controlTotalQuantity);
        if (!this.totalQuantity.toString().equals(this.totalQuantity.toBigInteger().toString())) {
            this.totalQuantity = this.totalQuantity.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
        }
    }

    public void setCrossReferenceDocumentNumber(Long crossReferenceDocumentNumber) {
        this.crossReferenceDocumentNumber = crossReferenceDocumentNumber;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public void setCustomDocumentReference1(String customDocumentReference1) {
        this.customDocumentReference1 = customDocumentReference1;
    }

    public void setCustomDocumentReference2(String customDocumentReference2) {
        this.customDocumentReference2 = customDocumentReference2;
    }

    public void setCustomDocumentReference3(String customDocumentReference3) {
        this.customDocumentReference3 = customDocumentReference3;
    }

    public void setCustomDocumentReference4(String customDocumentReference4) {
        this.customDocumentReference4 = customDocumentReference4;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void setDueDate(ReIMDate dueDate) {
        this.dueDate = dueDate;
    }

    public void setExchangeRate(Double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public void setFreightType(String freightTerms) {
        this.freightType = freightTerms;
    }

    public void setManuallyPaidInd(String manuallyPaidInd) {
        this.manuallyPaidInd = manuallyPaidInd;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public void setTermsDiscountPercentage(Double termsDiscountPercentage) {
        this.termsDiscountPercentage = termsDiscountPercentage;
    }

    public void setTotalDiscount(double totalDiscount) {
        this.totalDiscount = new BigDecimal(totalDiscount);
        this.totalDiscount = this.totalDiscount.setScale(PRECISION4, BigDecimal.ROUND_HALF_UP);
    }

    public void setVendorDocumentDate(ReIMDate vendorDocumentDate) {
        this.vendorDocumentDate = vendorDocumentDate;
    }

    public void setVendorDocumentNumber(String vendorDocumentNumber) {
        this.vendorDocumentNumber = vendorDocumentNumber;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public void setVendorType(String vendorType) {
        this.vendorType = vendorType;
    }

    public void setLocation(Long location) {
        this.location = location;
    }

    public void setLocationType(String locationType) {
        this.locationType = locationType;
    }

    public void setOrderNumber(Long orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setLineID(long lineID) {
        this.lineID = lineID;
    }

    public void setRecordDescriptor(String recordDescriptor) {
        this.recordDescriptor = recordDescriptor;
    }

    public void setTransactionNumber(long transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public void setEdiNonMerchDetailList(EdiNonMerchDetail[] ediNonMerchDetailList) {
        this.ediNonMerchDetailList = ediNonMerchDetailList;
    }

    public void setEdiTransactionDetailList(EdiTransactionDetail[] ediTransactionDetailList) {
        this.ediTransactionDetailList = ediTransactionDetailList;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public double getDetailControlTotalCostSum() {
        return detailControlTotalCostSum.doubleValue();
    }

    public double getDetailControlTotalQuantitySum() {
        return detailControlTotalQuantitySum.doubleValue();
    }

    public void setDetailControlTotalCostSum(double detailControlTotalCostSum) {
        this.detailControlTotalCostSum = new BigDecimal(detailControlTotalCostSum);
        this.detailControlTotalCostSum = this.detailControlTotalCostSum.setScale(4,
                BigDecimal.ROUND_HALF_UP);
    }

    public void setDetailControlTotalQuantitySum(double detailControlTotalQuantitySum) {
        this.detailControlTotalQuantitySum = new BigDecimal(detailControlTotalQuantitySum);
        this.detailControlTotalQuantitySum = this.detailControlTotalQuantitySum.setScale(
                PRECISION4, BigDecimal.ROUND_HALF_UP);
    }

    public void setOrignalRecord(String record) {
        this.originalRecord = record;
    }

    public String getOriginalRecord() {
        return originalRecord;
    }

    public boolean isTransactionValid() {
        return transactionValid;
    }

    public void setTransactionValid(boolean transactionValid) {
        this.transactionValid = transactionValid;
    }

    public EdiTransactionTail getEdiTransactionTail() {
        return ediTransactionTail;
    }

    public void setEdiTransactionTail(EdiTransactionTail ediTransactionTail) {
        this.ediTransactionTail = ediTransactionTail;
    }

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public String getMultiLocation() {
        return multiLocation;
    }

    public void setMultiLocation(String multiLocation) {
        this.multiLocation = multiLocation;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public boolean getIsEdiDownload() {
        return isEdiDownload;
    }

    public void setIsEdiDownload(boolean isEdiDownload) {
        this.isEdiDownload = isEdiDownload;
    }

    public String getErrorColumnId() {
        return errorColumnId;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setErrorColumnId(String errorColumnId) {
        this.errorColumnId = errorColumnId;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public Long getRejectedDocDetailId() {
        return rejectedDocDetailId;
    }

    public void setRejectedDocDetailId(Long rejectedDocDetailId) {
        this.rejectedDocDetailId = rejectedDocDetailId;
    }

    public String getMerchType() {
        return this.merchType;
    }

    public Long getDealId() {
        return this.dealId;
    }

    public String getRtvInd() {
        return this.rtvInd;
    }

    public void setMerchType(String merchType) {
        this.merchType = merchType;
    }

    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    public void setRtvInd(String rtvInd) {
        this.rtvInd = rtvInd;
    }

    public String getDealApprovalInd() {
        return this.dealApprovalInd;
    }

    public void setDealApprovalInd(String dealApprovalInd) {
        this.dealApprovalInd = dealApprovalInd;
    }

    public double getTotalTaxAmount() {
        return this.totalTaxAmount.doubleValue();
    }

    public void setTotalTaxAmount(double totalTaxAmount) {
        this.totalTaxAmount = new BigDecimal(totalTaxAmount);
        this.totalTaxAmount = this.totalTaxAmount.setScale(4, BigDecimal.ROUND_HALF_UP);
    }

    public EDIHeaderTax[] getEDIHeaderTaxList() {
        return this.ediTaxDetailList;
    }

    public void setEDIHeaderTaxList(EDIHeaderTax[] details) {
        this.ediTaxDetailList = details;
    }

    public double getTotalTaxAmountFromDetails() {
        return this.totalTaxAmountFromDetails.doubleValue();
    }

    public void setTotalTaxAmountFromDetails(double totalTaxAmountFromDetails) {
        this.totalTaxAmountFromDetails = new BigDecimal(totalTaxAmountFromDetails);
        this.totalTaxAmountFromDetails = this.totalTaxAmountFromDetails.setScale(4,
                BigDecimal.ROUND_HALF_UP);
    }

    public double getTotalTaxAmountFromTTAXS() {
        return this.totalTaxAmountFromTTAXS.doubleValue();
    }

    public void setTotalTaxAmountFromTTAXS(double totalTaxAmountFromTTAXS) {
        this.totalTaxAmountFromTTAXS = new BigDecimal(totalTaxAmountFromTTAXS);
        this.totalTaxAmountFromTTAXS = this.totalTaxAmountFromTTAXS.setScale(4,
                BigDecimal.ROUND_HALF_UP);
    }

    private boolean nullSafeEquals(Object obj1, Object obj2) {
        if (obj1 == null || obj2 == null) { return obj1 == obj2; }
        return obj1.equals(obj2);
    }

    public void setUploadReporter(EdiTransactionUploadReporter uploadReporter) {
        this.uploadReporter = uploadReporter;
    }

    private boolean isMultiLocation() {
        return this.multiLocation.equalsIgnoreCase(ReIMConstants.YES);
    }

    public String getSupplierSiteID() {
        return supplierSiteID;
    }

    public void setSupplierSiteID(String supplierSiteID) {
        this.supplierSiteID = supplierSiteID;
    }

    public boolean isSupplierSiteEnabled() {
        return supplierSiteEnabled;
    }

    public void setSupplierSiteEnabled(boolean supplierSiteEnabled) {
        this.supplierSiteEnabled = supplierSiteEnabled;
    }

    public boolean isFileSupplierSiteInd() {
        return fileSupplierSiteInd;
    }

    public void setFileSupplierSiteInd(boolean fileSupplierSiteInd) {
        this.fileSupplierSiteInd = fileSupplierSiteInd;
    }

    // Dmitry: Batches are configured with Spring, so presumably Autowired
    // should work
    // private IEdiDocumentService getEdiDocumentService() {
    // return ediDocumentService;
    // }
    //
    // @Autowired
    // public void setEdiDocumentService(IEdiDocumentService ediDocumentService) {
    // this.ediDocumentService = ediDocumentService;
    // }

}