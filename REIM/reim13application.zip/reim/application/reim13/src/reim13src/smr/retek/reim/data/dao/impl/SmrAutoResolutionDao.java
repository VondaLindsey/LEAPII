package smr.retek.reim.data.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.retail.reim.business.DiscrepancyType;
import oracle.retail.reim.utils.SqlCriteriaBuilder;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.retek.reim.business.Location;

import smr.retek.reim.business.SmrAutoResolutionCandidate;
import smr.retek.reim.data.dao.ISmrAutoResolutionDao;

@Repository
public class SmrAutoResolutionDao extends SimpleJdbcDaoSupport implements ISmrAutoResolutionDao {
	
//	private static final String SELECT_AUTO_RESOLUTION_CANDIDATES = "    SELECT doc.doc_id, \n" +
//			"           doc.order_no, \n" +
//			"           doc.location, \n" +
//			"           doc.loc_type, \n" +
//			"--           doc.cost_variance, \n" +
//			"--           doc.qty_variance, \n" +
//			"           case when doc.qty_variance is null then 'COST' else 'QTY' end variance_type, \n" +
//			"--           doc.positive_cost_variances, \n" +
//			"--           doc.negative_cost_variances, \n" +
//			"--           doc.total_cost_variances, \n" +
//			"--           doc.positive_qty_variances, \n" +
//			"--           doc.negative_qty_variances, \n" +
//			"--           doc.total_qty_variances, \n" +
//			"--           doc.items_with_mult_rcpts, \n" +
//			"--           doc.items_with_no_rcpts, \n" +
//			"           MIN(tol.in_favor_of)    KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS in_favor_of, \n" +
//			"           MIN(tol.reason_code_id) KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS reason_code_id, \n" +
//			"           MIN(rc.action)          KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS action \n" +
//			"         FROM (SELECT dh.doc_id, \n" +
//			"                      dh.order_no, \n" +
//			"                      dh.location, \n" +
//			"                      dh.loc_type, \n" +
//			"                      dh.total_cost, \n" +
//			"                      cd.cost_variance, -- Only need individual variances to check if present \n" +
//			"                      qd.qty_variance,  -- therefore no need to convert currency \n" +
//			"                      cd.positive_cost_variances, \n" +
//			"                      cd.negative_cost_variances, \n" +
//			"                      cd.total_cost_variances, \n" +
//			"                      qd.positive_qty_variances, \n" +
//			"                      qd.negative_qty_variances, \n" +
//			"                      qd.total_qty_variances, \n" +
//			"                      qd.items_with_mult_rcpts, \n" +
//			"                      qd.items_with_no_rcpts, \n" +
//			"                      NVL(cd.cost_variance, 0) + NVL(qd.qty_variance, 0)                                   AS total_variance_invoice, \n" +
//			"                      smr_im_inline_currency_convert(  NVL(cd.cost_variance, 0) + NVL(qd.qty_variance,  0), \n" +
//			"                                                       dh.currency_code, \n" +
//			"                                                       dh.exchange_rate) AS total_variance_primary \n" +
//			"                   FROM im_doc_head dh \n" +
//			"                        LEFT  JOIN (SELECT cd.doc_id, cd.order_no, cd.location, cd.loc_type, \n" +
//			"                                           SUM(case when (cd.doc_unit_cost - ol.unit_cost) > 0 then 1 else 0 end) AS positive_cost_variances, \n" +
//			"                                           SUM(case when (cd.doc_unit_cost - ol.unit_cost) > 0 then 0 else 1 end) AS negative_cost_variances, \n" +
//			"                                           SUM(1) AS total_cost_variances, \n" +
//			"                                           SUM(id.invoice_qty * (cd.doc_unit_cost - ol.unit_cost)) AS cost_variance \n" +
//			"                                        FROM im_cost_discrepancy          cd \n" +
//			"                                             INNER JOIN im_invoice_detail id  ON id.doc_id   = cd.doc_id \n" +
//			"                                                                             AND id.item     = cd.item \n" +
//			"                                             INNER JOIN ordloc            ol  ON ol.order_no = cd.order_no \n" +
//			"                                                                             AND ol.item     = cd.item \n" +
//			"                                         GROUP BY cd.doc_id, cd.order_no, cd.location, cd.loc_type \n" +
//			"                                   ) cd  ON cd.doc_id = dh.doc_id \n" +
//			"                        LEFT  JOIN (SELECT qd.doc_id, qd.order_no, qd.location, qd.loc_type, \n" +
//			"                                           SUM(case when nvl(r.num_receipts, -1) > 1 then 1 else 0 end) AS items_with_mult_rcpts, \n" +
//			"                                           SUM(case when nvl(r.num_receipts, -1) = 0 then 1 else 0 end) AS items_with_no_rcpts, \n" +
//			"                                           SUM(case when (qd.qty_invoiced - nvl(r.qty_received, 0)) > 0 then 1 else 0 end) AS positive_qty_variances, \n" +
//			"                                           SUM(case when (qd.qty_invoiced - nvl(r.qty_received, 0)) > 0 then 0 else 1 end) AS negative_qty_variances, \n" +
//			"                                           SUM(1) AS total_qty_variances, \n" +
//			"                                           SUM((qd.qty_invoiced - nvl(r.qty_received, 0)) * ol.unit_cost)  AS qty_variance \n" +
//			"                                        FROM im_qty_discrepancy           qd \n" +
//			"                                             INNER JOIN ordloc            ol  ON ol.order_no = qd.order_no \n" +
//			"                                                                             AND ol.item     = qd.item \n" +
//			"                                             LEFT  JOIN (SELECT s.order_no, \n" +
//			"                                                                s.to_loc, \n" +
//			"                                                                s.to_loc_type, \n" +
//			"                                                                ss.item, \n" +
//			"                                                                sum(ss.qty_received - nvl(pmr.qty_matched, nvl(ss.qty_matched, 0))) AS qty_received, \n" +
//			"                                                                count(distinct s.shipment)            AS num_receipts \n" +
//			"                                                           FROM shipment s \n" +
//			"                                                                INNER JOIN shipsku ss ON s.shipment = ss.shipment and nvl(s.status_code, 'U') <> 'M' \n" +
//			"                                                           LEFT OUTER JOIN im_partially_matched_receipts pmr ON s.shipment = pmr.shipment and ss.item = pmr.item \n" +
//			"                                                           GROUP BY s.order_no, s.to_loc, s.to_loc_type, ss.item \n" +
//			"                                                        ) r   ON r.order_no  = qd.order_no \n" +
//			"                                                             and r.to_loc  = qd.location \n" +
//			"                                                             and r.to_loc_type = qd.loc_type \n" +
//			"                                                             and r.item = qd.item \n" +
//			"                                        GROUP BY qd.doc_id, qd.order_no, qd.location, qd.loc_type \n" +
//			"                                   ) qd  ON qd.doc_id = dh.doc_id and qd.order_no = dh.order_no and qd.location = dh.location and qd.loc_type = dh.loc_type \n" +
//			"                   WHERE   dh.type   = 'MRCHI' \n" +
//			"                       AND dh.status = 'URMTCH' \n" +
//                        "                       AND SMR_REIM_AUTORESOLVE_VALID (dh.order_no, dh.location) = 'TRUE' "+
//			"                       AND dh.hold_status != 'H' \n" +
//			"                       AND (    cd.cost_variance IS NOT NULL -- Should not be necessary, after base AutoMatch the only \n" +
//			"                             OR qd.qty_variance  IS NOT NULL -- URMTCH status Invoices should have either a Cost or Qty \n" +
//			"                           )                                 -- Variance but it's in here to avoid catching any others \n" +
//			"                       AND NOT (    cd.cost_variance IS NOT NULL     -- If we have both cost and qty variance, then we will \n" +
//			"                                AND qd.qty_variance  IS NOT NULL     -- leave it for manual resolution (one must be null) \n" +
//			"                               ) \n" +
//			"              )                           doc \n" +
//			"              INNER JOIN smr_im_tolerance tol  ON ABS(doc.total_variance_primary)  > tol.min_variance_exc \n" +
//			"                                              AND ABS(doc.total_variance_primary) <= tol.max_variance_inc \n" +
//			"                                              AND (   tol.pct_variance = 0 \n" +
//			"                                                   OR ABS(doc.total_variance_invoice / doc.total_cost) <= tol.pct_variance / 100 \n" +
//			"                                                  ) \n" +
//			"                                              AND CASE WHEN doc.total_variance_primary < 0 \n" +
//			"                                                    THEN 'SMR' \n" +
//			"                                                    ELSE 'SUP' \n" +
//			"                                                  END = tol.in_favor_of \n" +
//			"                                              AND CASE WHEN doc.qty_variance IS NULL \n" +
//			"                                                    THEN 'N' \n" +
//			"                                                    ELSE 'Y' \n" +
//			"                                                  END = tol.qty_var \n" +
//			"                                              \n" +
//			"              INNER JOIN im_reason_codes rc  ON rc.reason_code_id = tol.reason_code_id \n" +
//			"                                            -- Filter invoices where the action can not be applied to all of invoices discrepancies \n" +
//			"                                            -- checks below are dependent upon invoices with both cost and qty discrepancies already being filtered out \n" +
//			"                                            AND (NOT (rc.action  = 'CBC' and (tol.in_favor_of = 'SMR' or nvl(doc.positive_cost_variances, 0) <> (nvl(doc.total_cost_variances, 0) + nvl(doc.total_qty_variances, 0))))) \n" +
//			"                                            AND (NOT (rc.action  = 'CBQ' and (tol.in_favor_of = 'SMR' or nvl(doc.positive_qty_variances,  0) <> (nvl(doc.total_cost_variances, 0) + nvl(doc.total_qty_variances, 0))))) \n" +
//			"                                            AND (NOT (rc.action  = 'SR'  and (tol.in_favor_of = 'SUP' or nvl(doc.negative_qty_variances,  0) <> (nvl(doc.total_cost_variances, 0) + nvl(doc.total_qty_variances, 0)) or doc.items_with_mult_rcpts > 0))) \n" +
//			"                                            AND (NOT (rc.action  = 'RUA' and doc.items_with_mult_rcpts > 0)) \n" +
//			"                                            AND (NOT (rc.action <> 'CBQ' and (not doc.qty_variance is null) and doc.items_with_no_rcpts > 0)) \n" +
//			"        GROUP BY doc.doc_id, \n" +
//			"                 doc.order_no, \n" +
//			"                 doc.location, \n" +
//			"                 doc.loc_type, \n" +
//			"                 doc.cost_variance, \n" +
//			"                 doc.qty_variance, \n" +
//			"                 doc.positive_cost_variances, \n" +
//			"                 doc.negative_cost_variances, \n" +
//			"                 doc.total_cost_variances, \n" +
//			"                 doc.positive_qty_variances, \n" +
//			"                 doc.negative_qty_variances, \n" +
//			"                 doc.total_qty_variances, \n" +
//			"                 doc.items_with_mult_rcpts, \n" +
//			"                 doc.items_with_no_rcpts";



 private static final String SELECT_AUTO_RESOLUTION_CANDIDATES2 = "  with c1 as (\n" + 
 "                     SELECT dh.doc_id,  \n" + 
 "                                  dh.order_no,  \n" + 
 "                                  dh.location,  \n" + 
 "                                  dh.loc_type,  \n" + 
 "                                  dh.total_cost,  \n" + 
 "                                  cd.cost_variance, \n" + 
 "                                  qd.qty_variance,  \n" + 
 "                                  cd.positive_cost_variances,  \n" + 
 "                                  cd.negative_cost_variances,  \n" + 
 "                                  cd.total_cost_variances,  \n" + 
 "                                  qd.positive_qty_variances,  \n" + 
 "                                  qd.negative_qty_variances,  \n" + 
 "                                  qd.total_qty_variances,  \n" + 
 "                                  qd.items_with_mult_rcpts,  \n" + 
 "                                  qd.items_with_no_rcpts,  \n" + 
 "                                  NVL(cd.cost_variance, 0) + NVL(qd.qty_variance, 0)                                   AS total_variance_invoice,  \n" + 
 "                                  smr_im_inline_currency_convert(  NVL(cd.cost_variance, 0) + NVL(qd.qty_variance,  0),  \n" + 
 "                                                                   dh.currency_code,  \n" + 
 "                                                                   dh.exchange_rate) AS total_variance_primary  \n" + 
 "                               FROM im_doc_head dh , \n" + 
 "                                    (SELECT cd.doc_id, cd.order_no, cd.location, cd.loc_type,  \n" + 
 "                                                       SUM(case when nvl(r.num_receipts, -1) > 1 then 1 else 0 end) AS items_with_mult_rcpts,  \n" + 
 "                                                       SUM(case when nvl(r.num_receipts, -1) = 0 then 1 else 0 end) AS items_with_no_rcpts,  \n" + 
 "                                                       SUM(case when (cd.doc_unit_cost - nvl(r.unit_cost, 0)) > 0 then 1 else 0 end) AS positive_cost_variances,  \n" + 
 "                                                       SUM(case when (cd.doc_unit_cost - nvl(r.unit_cost, 0)) > 0 then 0 else 1 end) AS negative_cost_variances,  \n" + 
 "                                                       SUM(1) AS total_cost_variances,  \n" + 
 "                                                       SUM((cd.doc_unit_cost - nvl(r.unit_cost, 0)) * r.qty_received)  AS cost_variance  \n" + 
 "                                                    FROM im_cost_discrepancy  cd,\n" + 
 "                                                         (SELECT /*+ use_nl (s,ss)*/ s.order_no,  \n" + 
 "                                                                            s.to_loc,  \n" + 
 "                                                                            s.bill_to_loc,\n" + 
 "                                                                            S.BILL_TO_LOC_TYPE,\n" + 
 "                                                                            s.to_loc_type,  \n" + 
 "                                                                            ss.item,  \n" + 
 "                                                                            ss.unit_cost,\n" + 
 "                                                                            sum(ss.qty_received - nvl(ss.qty_matched, 0)) AS qty_received,  \n" + 
 "                                                                            count(distinct s.shipment) AS num_receipts  \n" + 
 "                                                                       FROM shipment s ,\n" + 
 "                                                                            shipsku ss ,\n" + 
 "                                                                            im_cost_discrepancy cd2\n" + 
 "                                                             WHERE s.shipment = ss.shipment \n" + 
 "                                                               and nvl(s.status_code, 'U') <> 'M' \n" + 
 "                                                               and cd2.order_no = s.order_no\n" + 
 "                                                               and cd2.location = s.bill_to_loc\n" + 
  "                                                               and ss.item = cd2.item\n" + 
 "                                                          GROUP BY s.order_no, s.to_loc, s.bill_to_loc, S.BILL_TO_LOC_TYPE, s.to_loc_type, ss.item , ss.unit_cost \n" + 
 "                                                         ) r  \n" + 
 "                                                    WHERE r.bill_to_loc = cd.location \n" + 
 "                                                      and r.order_no  = cd.order_no  \n" + 
 "                                                       and r.item = cd.item \n" + 
 "                                                       and not exists (select 1 from ordloc ol\n" + 
 "                                                                         where ol.order_no = cd.order_no\n" + 
 "                                                                            and ol.item = cd.item\n" + 
 "                                                                            and cd.doc_unit_cost = ol.unit_cost)    " +
 "                                                GROUP BY cd.doc_id, cd.order_no, cd.location, cd.loc_type  \n" + 
 "                                        ) cd,\n" + 
 "                                    (SELECT qd.doc_id, qd.order_no, qd.location, qd.loc_type, qd.item, \n" + 
 "                                                       SUM(case when nvl(r.num_receipts, -1) > 1 then 1 else 0 end) AS items_with_mult_rcpts,  \n" + 
 "                                                       SUM(case when nvl(r.num_receipts, -1) = 0 then 1 else 0 end) AS items_with_no_rcpts,  \n" + 
 "                                                       SUM(case when (qd.qty_invoiced - nvl(r.qty_received, 0)) > 0 then 1 else 0 end) AS positive_qty_variances,  \n" + 
 "                                                       SUM(case when (qd.qty_invoiced - nvl(r.qty_received, 0)) > 0 then 0 else 1 end) AS negative_qty_variances,  \n" + 
 "                                                       SUM(1) AS total_qty_variances,  \n" + 
 "                                                       (SUM((qd.qty_invoiced - nvl(r.qty_received, 0)) * r.unit_cost) ) AS qty_variance  \n" + 
 "                                                  FROM im_qty_discrepancy  qd,\n" + 
 "                                                         (SELECT /*+ use_nl (s,ss)*/ s.order_no,  \n" + 
 "                                                                            s.to_loc,  \n" + 
 "                                                                            s.bill_to_loc,\n" + 
 "                                                                            S.BILL_TO_LOC_TYPE,\n" + 
 "                                                                            s.to_loc_type,  \n" + 
 "                                                                            ss.item,  \n" + 
 "                                                                            ss.unit_cost,\n" + 
 "                                                                            sum(ss.qty_received - nvl(ss.qty_matched, 0)) AS qty_received,  \n" + 
 "                                                                            count(distinct s.shipment)            AS num_receipts  \n" + 
 "                                                                       FROM shipment s ,\n" + 
 "                                                                            shipsku ss ,\n" + 
 "                                                                            im_qty_discrepancy iqd2\n" + 
 "                                                             WHERE s.shipment = ss.shipment \n" + 
 "                                                               and nvl(s.status_code, 'U') <> 'M' \n" + 
 "                                                               and iqd2.order_no = s.order_no\n" + 
 "                                                               and iqd2.location = s.bill_to_loc\n" + 
 "                                                               and ss.item = iqd2.item\n" + 
 "                                                         GROUP BY s.order_no, s.to_loc, s.bill_to_loc, S.BILL_TO_LOC_TYPE, s.to_loc_type, ss.item , ss.unit_cost \n" + 
 "                                                         ) r  \n" + 
 "                                                    WHERE r.bill_to_loc = qd.location \n" + 
 "                                                      and r.order_no  = qd.order_no  \n" + 
 "                                                      and r.item = qd.item \n" + 
 "                                                      and not exists (SELECT 1 \n" + 
 "                                                                        FROM  shipsku ssk,\n" + 
 "                                                                              shipment shp\n" + 
 "                                                                        WHERE shp.shipment = ssk.shipment\n" + 
 "                                                                          AND qd.item = ssk.item\n" + 
 "                                                                          AND shp.order_no = qd.order_no\n" + 
 "                                                                          AND shp.bill_to_loc = qd.location\n" + 
 "                                                                     GROUP BY qd.qty_discrepancy_id,\n" + 
 "                                                                              qd.order_no,\n" + 
 "                                                                              qd.item,\n" + 
 "                                                                              qd.location,\n" + 
 "                                                                              qd.qty_invoiced \n" + 
 "                                                             HAVING qd.qty_invoiced - SUM(ssk.qty_received) = 0)  " +
 "                                                GROUP BY qd.doc_id, qd.order_no,qd.item, qd.location, qd.loc_type  \n" + 
 "                                        ) qd \n" + 
 "                               WHERE   dh.type   = 'MRCHI'  \n" + 
 "                                   AND dh.status = 'URMTCH'  \n" + 
 "                                   AND SMR_REIM_AUTORESOLVE_VALID (dh.order_no, dh.location) = 'TRUE' \n" + 
 "                                   AND dh.hold_status != 'H'  \n" + 
 "                                   AND cd.doc_id(+) = dh.doc_id  \n" + 
 "                                   AND qd.doc_id(+) = dh.doc_id \n" + 
 "                                   and qd.location(+) = dh.location \n" + 
 "                                   AND CD.LOCATION(+) = DH.LOCATION \n" + 
 "                                   AND (    cd.cost_variance IS NOT NULL -- Should not be necessary, after base AutoMatch the only  \n" + 
 "                                         OR qd.qty_variance  IS NOT NULL -- URMTCH status Invoices should have either a Cost or Qty  \n" + 
 "                                       )                                 -- Variance but it's in here to avoid catching any others  \n" + 
 "                                   AND NOT (    cd.cost_variance IS NOT NULL     -- If we have both cost and qty variance, then we will  \n" + 
 "                                            AND qd.qty_variance  IS NOT NULL     -- leave it for manual resolution (one must be null)  \n" + 
 "                                           )  )\n" + 
 "                SELECT c1.doc_id,  \n" + 
 "                       c1.order_no,  \n" + 
 "                       c1.location,  \n" + 
 "                       c1.loc_type,  \n" + 
 "                       c1.qty_variance,\n" + 
 "                       c1.cost_variance,\n" + 
 "                       case when c1.qty_variance is null then 'COST' else 'QTY' end variance_type,  \n" + 
 "                       MIN(tol.in_favor_of)    KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS in_favor_of,  \n" + 
 "                       MIN(tol.reason_code_id) KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS reason_code_id ,  \n" + 
 "                       MIN(rc.action)          KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS action  \n" + 
 "                     FROM c1,\n" + 
 "                          smr_im_tolerance tol ,\n" + 
 "                          im_reason_codes rc\n" + 
 "                    where   ABS(c1.total_variance_primary)  > tol.min_variance_exc  \n" + 
 "                      AND ABS(c1.total_variance_primary) <= tol.max_variance_inc  \n" + 
 "                      AND (   tol.pct_variance = 0  \n" + 
 "                                   OR ABS(c1.total_variance_invoice / c1.total_cost) <= tol.pct_variance / 100  \n" + 
 "                            )  \n" + 
 "                       AND CASE WHEN c1.total_variance_primary < 0  \n" + 
 "                                      THEN 'SMR'  \n" + 
 "                                          ELSE 'SUP'  \n" + 
 "                       END = tol.in_favor_of  \n" + 
 "                       AND CASE WHEN c1.qty_variance IS NULL  \n" + 
 "                                                   THEN 'N'  \n" + 
 "                                                       ELSE 'Y'  \n" + 
 "                       END = tol.qty_var      \n" + 
 "                                    AND rc.reason_code_id = tol.reason_code_id  \n" + 
 "                                    AND (NOT (rc.action  = 'CBC' and (tol.in_favor_of = 'SMR' or nvl(c1.positive_cost_variances, 0) <> (nvl(c1.total_cost_variances, 0) + nvl(c1.total_qty_variances, 0)))))  \n" + 
 "                                    AND (NOT (rc.action  = 'CBQ' and (tol.in_favor_of = 'SMR' or nvl(c1.positive_qty_variances,  0) <> (nvl(c1.total_cost_variances, 0) + nvl(c1.total_qty_variances, 0)))))  \n" + 
 "                                    AND (NOT (rc.action  = 'SR'  and (tol.in_favor_of = 'SUP' or abs(nvl(c1.negative_qty_variances,  0)) <> (nvl(c1.total_cost_variances, 0) + nvl(c1.total_qty_variances, 0)) or c1.items_with_mult_rcpts > 0)))  \n" + 
 "                                    AND (NOT (rc.action  = 'RUA' and c1.items_with_mult_rcpts > 0))  \n" + 
 "                                    AND (NOT (rc.action <> 'CBQ' and (not c1.qty_variance is null) and c1.items_with_no_rcpts > 0))         \n" + 
 "                    GROUP BY c1.doc_id,  \n" + 
 "                             c1.order_no,  \n" + 
 "                             c1.location,  \n" + 
 "                             c1.loc_type,  \n" + 
 "                             c1.cost_variance,  \n" + 
 "                             c1.qty_variance,  \n" + 
 "                             c1.positive_cost_variances,  \n" + 
 "                             c1.negative_cost_variances,  \n" + 
 "                             c1.total_cost_variances,  \n" + 
 "                             c1.positive_qty_variances,  \n" + 
 "                             c1.negative_qty_variances,  \n" + 
 "                             c1.total_qty_variances,  \n" + 
 "                             c1.items_with_mult_rcpts,  \n" + 
 "                             c1.items_with_no_rcpts\n ";
 
 
 
    private static final String SELECT_AUTO_RESOLUTION_CANDIDATES1 = " with c1 as ( select doc_id,    \n" + 
    "                                   order_no,    \n" + 
    "                                   location,    \n" + 
    "                                   loc_type,    \n" + 
    "                                   total_cost,\n" + 
    "                                   sum(cost_variance) cost_variance,\n" + 
    "                                   sum(qty_variance) qty_variance,\n" + 
    "                                   positive_cost_variances,    \n" + 
    "                                   negative_cost_variances,    \n" + 
    "                                   total_cost_variances,    \n" + 
    "                                   sum(positive_qty_variances) positive_qty_variances,    \n" + 
    "                                   sum(negative_qty_variances) negative_qty_variances,    \n" + 
    "                                   total_qty_variances,    \n" + 
    "                                   items_with_mult_rcpts,    \n" + 
    "                                   items_with_no_rcpts,  \n" + 
    "                                   sum(total_variance_invoice) total_variance_invoice,\n" + 
    "                                   sum(total_variance_primary) total_variance_primary\n" + 
    "                            from (  SELECT dh.doc_id,    \n" + 
    "                                           dh.order_no,    \n" + 
    "                                           dh.location,    \n" + 
    "                                           dh.loc_type,    \n" + 
    "                                           dh.total_cost,    \n" + 
    "                                           cd.cost_variance,   \n" + 
    "                                           qd.qty_variance,    \n" + 
    "                                           cd.positive_cost_variances,    \n" + 
    "                                           cd.negative_cost_variances,    \n" + 
    "                                           cd.total_cost_variances,    \n" + 
    "                                           qd.positive_qty_variances,    \n" + 
    "                                           qd.negative_qty_variances,    \n" + 
    "                                           qd.total_qty_variances,    \n" + 
    "                                           qd.items_with_mult_rcpts,    \n" + 
    "                                           qd.items_with_no_rcpts,    \n" + 
    "                                           NVL(cd.cost_variance, 0) + NVL(qd.qty_variance, 0) AS total_variance_invoice,    \n" + 
    "                                           smr_im_inline_currency_convert(  NVL(cd.cost_variance, 0) + NVL(qd.qty_variance,  0),    \n" + 
    "                                                                            dh.currency_code,    \n" + 
    "                                                                            dh.exchange_rate) AS total_variance_primary    \n" + 
    "                                      FROM im_doc_head dh ,   \n" + 
    "                                          (SELECT cd.doc_id, cd.order_no, cd.location, cd.loc_type,    \n" + 
    "                                                  SUM(case when nvl(r.num_receipts, -1) > 1 then 1 else 0 end) AS items_with_mult_rcpts,    \n" + 
    "                                                  SUM(case when nvl(r.num_receipts, -1) = 0 then 1 else 0 end) AS items_with_no_rcpts,    \n" + 
    "                                                  SUM(case when (cd.doc_unit_cost - nvl(r.unit_cost, 0)) > 0 then 1 else 0 end) AS positive_cost_variances,    \n" + 
    "                                                  SUM(case when (cd.doc_unit_cost - nvl(r.unit_cost, 0)) > 0 then 0 else 1 end) AS negative_cost_variances,    \n" + 
    "                                                  SUM(1) AS total_cost_variances,    \n" + 
    "                                                  SUM((cd.doc_unit_cost - nvl(r.unit_cost, 0)) * r.qty_received)  AS cost_variance    \n" + 
    "                                             FROM im_cost_discrepancy  cd,  \n" + 
    "                                                  (SELECT /*+ use_nl (s,ss)*/ s.order_no,    \n" + 
    "                                                                              s.to_loc,    \n" + 
    "                                                                              s.bill_to_loc,  \n" + 
    "                                                                              S.BILL_TO_LOC_TYPE,  \n" + 
    "                                                                              s.to_loc_type,    \n" + 
    "                                                                              ss.item,    \n" + 
    "                                                                              ss.unit_cost,  \n" + 
    "                                                                              sum(ss.qty_received - nvl(ss.qty_matched, 0)) AS qty_received,    \n" + 
    "                                                                              count(distinct s.shipment) AS num_receipts    \n" + 
    "                                                                         FROM shipment s ,  \n" + 
    "                                                                              shipsku ss ,  \n" + 
    "                                                                              im_cost_discrepancy cd2  \n" + 
    "                                                                        WHERE s.shipment = ss.shipment   \n" + 
    "                                                                          and nvl(s.status_code, 'U') <> 'M'   \n" + 
    "                                                                          and cd2.order_no = s.order_no  \n" + 
    "                                                                          and cd2.location = s.bill_to_loc  \n" + 
    "                                                                          and ss.item = cd2.item  \n" + 
    "                                                                     GROUP BY s.order_no, s.to_loc, s.bill_to_loc, \n" + 
    "                                                                              S.BILL_TO_LOC_TYPE, s.to_loc_type, ss.item , ss.unit_cost  ) r    \n" + 
    "                                           WHERE r.bill_to_loc = cd.location   \n" + 
    "                                             and r.order_no  = cd.order_no    \n" + 
    "                                             and r.item = cd.item   \n" + 
    "                                             and not exists (select 1 from ordloc ol  \n" + 
    "                                                              where ol.order_no = cd.order_no  \n" + 
    "                                                                and ol.item = cd.item  \n" + 
    "                                                                and cd.doc_unit_cost = ol.unit_cost)     \n" + 
    "                                    GROUP BY cd.doc_id, cd.order_no, cd.location, cd.loc_type   ) cd,  \n" + 
    "                                     (SELECT qd.doc_id, qd.order_no, qd.location, qd.loc_type, qd.item,   \n" + 
    "                                             SUM(case when nvl(r.num_receipts, -1) > 1 then 1 else 0 end) AS items_with_mult_rcpts,    \n" + 
    "                                             SUM(case when nvl(r.num_receipts, -1) = 0 then 1 else 0 end) AS items_with_no_rcpts,    \n" + 
    "                                             SUM(case when (qd.qty_invoiced - nvl(r.qty_received, 0)) > 0 then 1 else 0 end) AS positive_qty_variances,    \n" + 
    "                                             SUM(case when (qd.qty_invoiced - nvl(r.qty_received, 0)) > 0 then 0 else 1 end) AS negative_qty_variances,    \n" + 
    "                                             SUM(1) AS total_qty_variances,    \n" + 
    "                                             (SUM((qd.qty_invoiced - nvl(r.qty_received, 0)) * r.unit_cost) ) AS qty_variance    \n" + 
    "                                        FROM im_qty_discrepancy  qd,  \n" + 
    "                                             (SELECT /*+ use_nl (s,ss)*/\n" + 
    "                                                      s.order_no,    \n" + 
    "                                                      s.to_loc,    \n" + 
    "                                                      s.bill_to_loc,  \n" + 
    "                                                      S.BILL_TO_LOC_TYPE,  \n" + 
    "                                                      s.to_loc_type,    \n" + 
    "                                                      ss.item,    \n" + 
    "                                                      ss.unit_cost,  \n" + 
    "                                                      sum(ss.qty_received - nvl(ss.qty_matched, 0)) AS qty_received,    \n" + 
    "                                                      count(distinct s.shipment)  AS num_receipts    \n" + 
    "                                                 FROM shipment s ,  \n" + 
    "                                                      shipsku ss ,  \n" + 
    "                                                      im_qty_discrepancy iqd2  \n" + 
    "                                                WHERE s.shipment = ss.shipment   \n" + 
    "                                                  and nvl(s.status_code, 'U') <> 'M'   \n" + 
    "                                                  and iqd2.order_no = s.order_no  \n" + 
    "                                                  and iqd2.location = s.bill_to_loc  \n" + 
    "                                                  and ss.item = iqd2.item  \n" + 
    "                                             GROUP BY s.order_no, s.to_loc, s.bill_to_loc, S.BILL_TO_LOC_TYPE, \n" + 
    "                                                      s.to_loc_type, ss.item , ss.unit_cost    ) r    \n" + 
    "                                          WHERE r.bill_to_loc = qd.location   \n" + 
    "                                            and r.order_no  = qd.order_no    \n" + 
    "                                            and r.item = qd.item   \n" + 
    "                                            and not exists (SELECT 1   \n" + 
    "                                                              FROM  shipsku ssk,  \n" + 
    "                                                                    shipment shp  \n" + 
    "                                                              WHERE shp.shipment = ssk.shipment  \n" + 
    "                                                                AND qd.item = ssk.item  \n" + 
    "                                                                AND shp.order_no = qd.order_no  \n" + 
    "                                                                AND shp.bill_to_loc = qd.location  \n" + 
    "                                                              GROUP BY qd.qty_discrepancy_id,  \n" + 
    "                                                                       qd.order_no,  \n" + 
    "                                                                       qd.item,  \n" + 
    "                                                                       qd.location,  \n" + 
    "                                                                       qd.qty_invoiced   \n" + 
    "                                                              HAVING qd.qty_invoiced - SUM(ssk.qty_received) = 0)   \n" + 
    "                                        GROUP BY qd.doc_id, qd.order_no,qd.item, qd.location, qd.loc_type  ) qd   \n" + 
    "                                WHERE   dh.type   = 'MRCHI'    \n" + 
    "                                    AND dh.status = 'URMTCH'    \n" + 
    "                                    AND dh.hold_status != 'H' \n" + 
    "                                    AND cd.doc_id(+) = dh.doc_id    \n" + 
    "                                    AND qd.doc_id(+) = dh.doc_id   \n" + 
    "                                    and qd.location(+) = dh.location   \n" + 
    "                                    AND CD.LOCATION(+) = DH.LOCATION   \n" + 
    "                                    AND (    cd.cost_variance IS NOT NULL -- Should not be necessary, after base AutoMatch the only    \n" + 
    "                                          OR qd.qty_variance  IS NOT NULL -- URMTCH status Invoices should have either a Cost or Qty    \n" + 
    "                                        )                                 -- Variance but it's in here to avoid catching any others    \n" + 
    "                                    AND NOT (    cd.cost_variance IS NOT NULL     -- If we have both cost and qty variance, then we will    \n" + 
    "                                             AND qd.qty_variance  IS NOT NULL     -- leave it for manual resolution (one must be null)    \n" + 
    "                                            ) \n" + 
    "                                 )  group by doc_id,    \n" + 
    "                                   order_no,    \n" + 
    "                                   location,    \n" + 
    "                                   loc_type,    \n" + 
    "                                   total_cost,\n" + 
    "                                   positive_cost_variances,    \n" + 
    "                                   negative_cost_variances,    \n" + 
    "                                   total_cost_variances,    \n" + 
    "                                   total_qty_variances,    \n" + 
    "                                   items_with_mult_rcpts,    \n" + 
    "                                   items_with_no_rcpts ) \n" + 
    "                 SELECT c1.doc_id,    \n" + 
    "                        c1.order_no,    \n" + 
    "                        c1.location,    \n" + 
    "                        c1.loc_type,    \n" + 
    "                        c1.qty_variance,  \n" + 
    "                        c1.cost_variance,  \n" + 
    "                        case when c1.qty_variance is null then 'COST' else 'QTY' end variance_type,    \n" + 
    "                        MIN(tol.in_favor_of)    KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS in_favor_of,    \n" + 
    "                        MIN(tol.reason_code_id) KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS reason_code_id ,    \n" + 
    "                        MIN(rc.action)          KEEP (DENSE_RANK FIRST ORDER BY tol.rank) AS action    \n" + 
    "                   FROM c1,  \n" + 
    "                        smr_im_tolerance tol ,  \n" + 
    "                        im_reason_codes rc  \n" + 
    "                  where ABS(c1.total_variance_primary)  > tol.min_variance_exc \n" + 
    "                    AND SMR_REIM_AUTORESOLVE_VALID (c1.doc_id, c1.order_no, c1.location, c1.cost_variance, c1.qty_variance) = 'TRUE'      \n" + 
    "                    AND ABS(c1.total_variance_primary) <= tol.max_variance_inc    \n" + 
    "                    AND (   tol.pct_variance = 0    \n" + 
    "                                OR ABS(c1.total_variance_invoice / c1.total_cost) <= tol.pct_variance / 100    \n" + 
    "                         )    \n" + 
    "                    AND CASE WHEN c1.total_variance_primary < 0 THEN \n" + 
    "                             'SMR'    \n" + 
    "                          ELSE \n" + 
    "                             'SUP'    \n" + 
    "                        END = tol.in_favor_of    \n" + 
    "                    AND CASE WHEN c1.qty_variance IS NULL    \n" + 
    "                                               THEN 'N'    \n" + 
    "                                                 ELSE 'Y'    \n" + 
    "                        END = tol.qty_var        \n" + 
    "                    AND rc.reason_code_id = tol.reason_code_id    \n" + 
    "                    AND (NOT (rc.action  = 'CBC' and (tol.in_favor_of = 'SMR' or nvl(c1.positive_cost_variances, 0) <> (nvl(c1.total_cost_variances, 0) + nvl(c1.total_qty_variances, 0)))))    \n" + 
    "                    AND (NOT (rc.action  = 'CBQ' and (tol.in_favor_of = 'SMR' or nvl(c1.positive_qty_variances,  0) <> (nvl(c1.total_cost_variances, 0) + nvl(c1.total_qty_variances, 0)))))    \n" + 
    "                    AND (NOT (rc.action  = 'SR'  and (tol.in_favor_of = 'SUP' or abs(nvl(c1.negative_qty_variances,  0)) <> (nvl(c1.total_cost_variances, 0) + nvl(c1.total_qty_variances, 0)) or c1.items_with_mult_rcpts > 0)))    \n" + 
    "                    AND (NOT (rc.action  = 'RUA' and c1.items_with_mult_rcpts > 0))    \n" + 
    "                    AND (NOT (rc.action <> 'CBQ' and (not c1.qty_variance is null) and c1.items_with_no_rcpts > 0))           \n" + 
    "                   GROUP BY c1.doc_id,    \n" + 
    "                            c1.order_no,    \n" + 
    "                            c1.location,    \n" + 
    "                            c1.loc_type,    \n" + 
    "                            c1.cost_variance,    \n" + 
    "                            c1.qty_variance,    \n" + 
    "                            c1.positive_cost_variances,    \n" + 
    "                            c1.negative_cost_variances,    \n" + 
    "                            c1.total_cost_variances,    \n" + 
    "                            c1.positive_qty_variances,    \n" + 
    "                            c1.negative_qty_variances,    \n" + 
    "                            c1.total_qty_variances,    \n" + 
    "                            c1.items_with_mult_rcpts,    \n" + 
    "                            c1.items_with_no_rcpts  ";
    
    private static final String SELECT_AUTO_RESOLUTION_CANDIDATES = " SELECT doc_id, \n" + 
    "       order_no, \n" + 
    "       LOCATION, \n" + 
    "       loc_type, \n" + 
    "       qty_variance,\n" + 
    "       cost_variance, \n" + 
    "       variance_type, \n" + 
    "       in_favor_of, \n" + 
    "       reason_code_id, \n" + 
    "       action\n" + 
    "  FROM v_smr_auto_resolve_candidate order by action, order_no, location ";

	public Map<String, SmrAutoResolutionCandidate> getAutoResolutionCandidates() {
		SqlCriteriaBuilder crit = new SqlCriteriaBuilder(SELECT_AUTO_RESOLUTION_CANDIDATES);
		Map<String, SmrAutoResolutionCandidate> map = new HashMap<String, SmrAutoResolutionCandidate>();
		List<SmrAutoResolutionCandidate> list = getSimpleJdbcTemplate().query(crit.toString(),
                new ParameterizedRowMapper<SmrAutoResolutionCandidate>() {
                    public SmrAutoResolutionCandidate mapRow(ResultSet rs, int rowNum) throws SQLException {

                        SmrAutoResolutionCandidate candidate = new SmrAutoResolutionCandidate();

                        candidate.setDocId(rs.getString("DOC_ID"));
                        candidate.setOrderId(rs.getString("ORDER_NO"));
                        Location location = new Location();
                        location.setLocationId(rs.getString("LOCATION"));
                        location.setLocationType(rs.getString("LOC_TYPE"));
                        candidate.setLocation(location);
                        candidate.setInFavorOf(rs.getString("IN_FAVOR_OF"));
                        candidate.setDiscrepancyType(DiscrepancyType.fromString(rs.getString("VARIANCE_TYPE")));
                        if ( rs.getString("VARIANCE_TYPE").equalsIgnoreCase("QTY") )  {
                            candidate.setVariance(rs.getDouble("QTY_VARIANCE"));
                        } else {
                            candidate.setVariance(rs.getDouble("COST_VARIANCE"));
                        }
                        candidate.setAction(rs.getString("ACTION"));
                        candidate.setReasonCodeId(rs.getString("REASON_CODE_ID"));         
                       

                        return candidate;

                    }
                }, crit.getParameterValuesAsArray());
		for (SmrAutoResolutionCandidate candidate : list) {
			map.put(candidate.getKey(), candidate);
		}
		return map;
	}

}
