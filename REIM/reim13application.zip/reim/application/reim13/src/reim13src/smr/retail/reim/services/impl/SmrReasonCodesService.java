package smr.retail.reim.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Logger;
import oracle.retail.reim.utils.Severity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import smr.retail.reim.services.ISmrCostResService;
import smr.retail.reim.services.ISmrReasonCodesService;

import com.retek.reim.business.ReasonCode;
import com.retek.reim.db.DaoFactory;
import com.retek.reim.db.IImReasonCodesAccessExt;
import com.retek.reim.db.ImReasonCodesRow;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMI18NUtility;
import com.retek.reim.services.ReasonCodesService;
import com.retek.reim.ui.lov.DepartmentLOV;
import com.retek.reim.ui.lov.LOV;

/**
 * Custom version of the ReasonCodesService.
 * 
 * Primarily customized for ENH505.
 * 
 * Version   Issue   Author   Comments
 * 1.01      ENH505  S. Mann  Initial version
 * 1.02      ENH505  S. Mann  Created a clone of the "action List Map" in order so that in the event records
 *                            are removed, they are not removed from the original hashmap.
 * 
 * @author Simon Mann
 *
 */
@Service
public class SmrReasonCodesService extends ReasonCodesService implements
		ISmrReasonCodesService {

	ISmrCostResService smrCostResService;
	
	public LOV[] getReasonCodes(long businessRoleId, String id, String reasonCodeType,
            String documentType, String varianceSign, boolean selectedCostQuantityIsOther,
            String receiptsExist, String selectedCostQuantity, String orderNo, 
            String location, String item, String unitCost) throws ReIMException {
		
		try {
            TransactionManagerFactory.getInstance().start();
            IImReasonCodesAccessExt access = DaoFactory.getImReasonCodesAccessExt();
            Map<String, String> actionListMap= getActionListMap(reasonCodeType,documentType,varianceSign,selectedCostQuantityIsOther,selectedCostQuantity,receiptsExist);
            
            // 1.02 Copy the actionListMap to a new HashMap. This is required
         	//      so that the original hash map does not have records removed from it.
            actionListMap = new HashMap<String, String>(actionListMap);
            
            
            // ENH505 - call new  function to filter out the list of reason codes.
            filterReasonCodes(actionListMap, orderNo, location, item, unitCost);
            
            ImReasonCodesRow[] row = access.getReasonCodes(businessRoleId, id, reasonCodeType,documentType,actionListMap);
            if (row != null) {
                ArrayList<DepartmentLOV> reasonCodeList = new ArrayList<DepartmentLOV>();
                for (int i = 0; i < row.length; i++) {
                    // Using Dept LOV because all LOV's are same.
                    reasonCodeList.add(new DepartmentLOV(row[i].getReasonCodeId(), row[i]
                            .getReasonCodeDesc(), ReIMI18NUtility.getMessage("code.REASCODEACTION."
                            + row[i].getAction()), (row[i].getCommentRequiredInd()
                            .equalsIgnoreCase(ReIMConstants.YES) ? ReIMI18NUtility
                            .getWidget("label.yes") : ReIMI18NUtility.getWidget("label.no")),
                            row[i].getAction(), (row[i].getHintComment() != null ? row[i]
                                    .getHintComment() : "")));
                }
                return (LOV[]) reasonCodeList.toArray(new DepartmentLOV[reasonCodeList.size()]);
            } else
                return null;
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.cannot_get_reason_codes", Severity.ERROR, e,
                    ReasonCodesService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

	
	/**
	 * Filter the provided map to remove any reason codes which should not be
	 * provided to the user.
	 * 
	 * @param actionListMap
	 * @throws ReIMException 
	 */
	private void filterReasonCodes(Map<String, String> actionListMap, String orderNoString, String locationString, String item, 
			String unitCostString) throws ReIMException {
		
		Logger.debug(this, "Filtering list of reason codes for orderNo: " + orderNoString +", location: " + locationString
				+ ", item: " + item + ", unitCost: " + unitCostString);
		
		if (orderNoString == null || orderNoString.length() == 0 ||  locationString == null || locationString.length() == 0
				|| item == null || item.length() == 0 || unitCostString == null || unitCostString.length() == 0) {
			Logger.debug(this, "One or more paramters in filterReasonCodes is null. Not filtering.");
			return;
		}
		
		// Convert the provided strings into numbers
		long orderNo;
		long location;
		double unitCost;
		
		try {
			orderNo = Long.valueOf(orderNoString).longValue();
		} catch (NumberFormatException e) {
			Object[] messageData = {"orderNoString", orderNoString};
			throw new ReIMException("SMR.error.convertToNumber",Severity.ERROR,this, messageData);
		}
		
		try {
			location = Long.valueOf(locationString).longValue();
		} catch (NumberFormatException e) {
			Object[] messageData = {"locationString", locationString};
			throw new ReIMException("SMR.error.convertToNumber", Severity.ERROR, this, messageData);
		}
		
		try {
			unitCost = Double.valueOf(unitCostString).doubleValue();
		} catch (NumberFormatException e) {
			Object[] messageData = {"unitCostString", unitCostString};
			throw new ReIMException("SMR.error.convertToNumber", Severity.ERROR, this, messageData);
		}
		
		
		// Execute the filters
		if (actionListMap.containsKey(ReasonCode.RECEIVER_COST_ADJUSTMENT_ORDER_RECEIPT_ONLY)) {
			Logger.debug(this, "ActionListMap did contain key ReasonCode.RECEIVER_COST_ADJUSTMENT_ORDER_RECEIPT_ONLY");
			
			
			
			if (!smrCostResService.isRcaAllowed(orderNo, location, item, unitCost)) {
				Logger.debug(this, "RCA is not allowed. Removing from LOV");
				actionListMap.remove(ReasonCode.RECEIVER_COST_ADJUSTMENT_ORDER_RECEIPT_ONLY);
				actionListMap.remove(ReasonCode.RECEIVER_COST_ADJUSTMENT_ORDER_RECEIPT_SUPPLIER_COST);
			} else {
				Logger.debug(this, "No reason to remove RCA from LOV");
			}
		}
	}
	
	
	@Autowired
	public void setSmrCostResService(ISmrCostResService smrCostResService) {
		this.smrCostResService = smrCostResService;
	}


}
