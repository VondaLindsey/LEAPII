package smr.retail.reim.services;

import org.springframework.transaction.annotation.Transactional;

import smr.retail.reim.business.SmrMerchandiseDocument;
import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;

import com.retek.reim.business.EdiDocumentValidationValues;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.ui.lov.IKeyValue;

@Transactional
public interface ISmrInvoiceMassCorrectionService {
	
	public IKeyValue[] selectInvoices(String supplierId, String orderNo, String invoiceIdFromFilter, String invoiceIdFromUser) throws ReIMException;

	public IKeyValue[] selectSmrInvoiceItems(String supplierId, String orderNo, String invoiceId, String itemId) throws ReIMException;
	
	public IKeyValue[] getSmrInvoiceTerms(String supplierId, String orderNo, String invoiceId, String termsId) throws ReIMException;

	public IKeyValue[] getSmrInvoiceOrders(String supplierId, String orderNoFromFilter, String invoiceId, String orderNoFromUser) throws ReIMException;

	public IKeyValue[] getSmrInvoiceSupplierSitesFilter(String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException;

	public IKeyValue[] getSmrInvoiceSupplierSites(String supplierSiteIdFromFilter, String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException;
	
	public IKeyValue[] getDistinctSupplierSites(String supplierSiteIdFromFilter, String orderNo, String supplierSiteIdFromUser) throws ReIMException;
        
    public EdiDocumentValidationValues replaceElementAndRevalidate(SmrMerchandiseDocument smrMerchandiseDocument) throws ReIMException;

    public String[] getDocIds(String supplierId, String orderNo, String invoiceId, String fromInvoiceId, String toInvoiceLOV) throws ReIMException;
    
//    public boolean massDeleteRejects(String supplierId, String orderNo, String invoiceId, String userId) throws ReIMException;
    
    public boolean rejectTrueDuplicates(String extDocId, String orderNo, Double totalCost, String vendor)  throws ReIMException ;
    
    public boolean softDuplicates(String extDocId, String orderNo, Double totalCost, String vendor)  throws ReIMException ;
   
    public void updateRejectHeadRejectReason(long docId, String errorColumnId, String rejectReason) throws ReIMException;

    public void insertSmrInvoiceRejectRecord(SmrEdiReportRecord smrEdiRejectRecord) throws ReIMException; // SMR OLR ENH31 Inserted
}
