package smr.retek.reim.batch.ediupinv.threading;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import EDU.oswego.cs.dl.util.concurrent.Takable;

import com.retek.reim.batch.BatchUtils;
import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EdiDetailAllowance;
import com.retek.reim.batch.ediupinv.EdiFileHeader;
import com.retek.reim.batch.ediupinv.EdiNonMerchDetail;
import com.retek.reim.batch.ediupinv.EdiTransactionDetail;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.batch.ediupinv.EDIHeaderTax;
import com.retek.reim.merch.utils.ReIMException;
import oracle.retail.reim.utils.Severity;
import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;
import smr.retek.reim.services.SmrServiceFactory;

import com.retek.reim.merch.utils.threads.Background;

//SMR OLR ENH31 Created
public class SmrEdiBackground extends Background implements EDIConstants {
    String rejectFileName = "";
    String smrRejectFileName = "";
    BufferedWriter bufferedWriter = null;
    BufferedWriter smrBufferedWriter = null;
    long lineId = 2;
    long tranNumber = 1;
    private static int FILE_BUFFER_SIZE = 65536;

    public SmrEdiBackground(Takable bq, String rejectFile, String smrRejectFile, EdiFileHeader fileHeader)
            throws ReIMException {
        super(bq);
        rejectFileName = rejectFile;
        smrRejectFileName = smrRejectFile;
        // write to base reject file
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(rejectFileName), FILE_BUFFER_SIZE);
        } catch (IOException e) {
            throw new ReIMException("error.batch.unable_to_open_file", Severity.FATAL, e, this,
                    new String[] { EDI_UPLOAD_PROGRAM_NAME, rejectFileName});
        }
        
        // write to smr reject file
        try {
        	smrBufferedWriter = new BufferedWriter(new FileWriter(smrRejectFileName), FILE_BUFFER_SIZE);
        } catch (IOException e) {
            throw new ReIMException("error.batch.unable_to_open_file", Severity.FATAL, e, this,
                    new String[] { EDI_UPLOAD_PROGRAM_NAME, smrRejectFileName});
        }

        BatchUtils.writeToFile(bufferedWriter, fileHeader.createFlatRecord(), rejectFileName);
    }

    public void backgroundTask(Object o) throws ReIMException {
        // if SmrEdiRejectRecord passed in
    	if (o instanceof SmrEdiReportRecord){
            SmrEdiReportRecord record = (SmrEdiReportRecord) o;
  	        SmrServiceFactory.getSmrEdiRejectService().insertSmrEdiRejectRecord(record);
            if (! record.isErrorInd()) {
                record.setErrorCode("99");    
            }
    		BatchUtils.writeToFile(smrBufferedWriter, record.createFlatRecord(),smrRejectFileName);
    	} else { // do base logic
        EdiTransactionHeader tranHead = (EdiTransactionHeader) o;
        long tranLineNumber = 0;

        // todo: (dave) make this automatic in the tran head object
        if (bufferedWriter != null) {
            BatchUtils.writeToFile(bufferedWriter, tranHead.renumberedRecord(lineId++, tranNumber),
                    rejectFileName);

            EdiNonMerchDetail[] ediRejectedTranNonMerchDetail = tranHead.getEdiNonMerchDetailList();

            // write the TNMRC records for this tran
            if (ediRejectedTranNonMerchDetail != null) {
                int ediRejectTranNonMerchDetailLength = ediRejectedTranNonMerchDetail.length;

                for (int i = 0; i < ediRejectTranNonMerchDetailLength; i++, tranLineNumber++) {
                    BatchUtils.writeToFile(bufferedWriter, ediRejectedTranNonMerchDetail[i]
                            .renumberedRecord(lineId++, tranNumber), rejectFileName);
                }
            }

            // write to TTAXS records for this tran
            EDIHeaderTax[] ediRejectedTranTaxDetail = tranHead.getEDIHeaderTaxList();

            if (ediRejectedTranTaxDetail != null) {
                int ediRejectedTranTaxDetailLength = ediRejectedTranTaxDetail.length;

                for (int i = 0; i < ediRejectedTranTaxDetailLength; i++, tranLineNumber++) {
                    BatchUtils.writeToFile(bufferedWriter, ediRejectedTranTaxDetail[i]
                            .renumberedRecord(lineId++, tranNumber), rejectFileName);
                }
            }

            EdiTransactionDetail[] ediRejectedTranTransactionDetail = tranHead
                    .getEdiTransactionDetailList();

            // write the TDETL records for the tran
            if (ediRejectedTranTransactionDetail != null) {
                int ediRejectedTranTransactionDetailLength = ediRejectedTranTransactionDetail.length;

                for (int i = 0; i < ediRejectedTranTransactionDetailLength; i++, tranLineNumber++) {
                    BatchUtils.writeToFile(bufferedWriter, ediRejectedTranTransactionDetail[i]
                            .renumberedRecord(lineId++, tranNumber), rejectFileName);

                    EdiDetailAllowance[] ediDetailAllowance = ediRejectedTranTransactionDetail[i]
                            .getEdiDetailAllowanceList();

                    // write any allowance records for the detail
                    if (ediDetailAllowance != null) {
                        int ediDetailAllowanceLength = ediDetailAllowance.length;

                        for (int j = 0; j < ediDetailAllowanceLength; j++, tranLineNumber++) {
                            BatchUtils.writeToFile(bufferedWriter, ediDetailAllowance[j]
                                    .renumberedRecord(lineId++, tranNumber), rejectFileName);
                        }
                    }
                }
            }

            BatchUtils.writeToFile(bufferedWriter, tranHead.getEdiTransactionTail()
                    .renumberedRecord(lineId++, tranNumber++), rejectFileName);

        }
        }
    }

    public void backgroundFinalTask() throws ReIMException {
        String ftail = "FTAIL" + BatchUtils.zeroPad(Long.toString(lineId), LEN_LINE_ID)
                + BatchUtils.zeroPad(Long.toString(lineId - 2), LEN_NUMBER_OF_LINES);

        // write to base reject file
        try {
            if (bufferedWriter != null) {
                BatchUtils.writeToFile(bufferedWriter, ftail, rejectFileName);
                bufferedWriter.flush();
                bufferedWriter.close();
            }
        } catch (IOException e) {
            throw new ReIMException("error.batch.unable_to_write_to_file", Severity.FATAL, e,
                    this, new String[] { rejectFileName});
        }
        // write to smr reject file
        try {
            if (smrBufferedWriter != null) {
            	smrBufferedWriter.flush();
            	smrBufferedWriter.close();
            }
        } catch (IOException e) {
            throw new ReIMException("error.batch.unable_to_write_to_file", Severity.FATAL, e,
                    this, new String[] { smrRejectFileName});
        }
    }
}
