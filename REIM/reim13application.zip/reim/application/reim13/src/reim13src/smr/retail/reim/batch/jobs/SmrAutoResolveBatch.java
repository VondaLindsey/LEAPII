package smr.retail.reim.batch.jobs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import oracle.retail.reim.batch.ABatchProcess;
import oracle.retail.reim.batch.BatchResults;
import oracle.retail.reim.batch.IBatchResults;
import smr.retail.reim.batch.SmrBatchNames;
import smr.retail.reim.services.resolving.ISmrAutoResolutionService;
import smr.retek.reim.batch.autoresolve.SmrAutoResolve;

@Component(SmrBatchNames.SMRAUTORESOLVE)
public class SmrAutoResolveBatch extends ABatchProcess {
	
	private ISmrAutoResolutionService smrAutoResolutionService;
	
	private SmrAutoResolve autoResolve = new SmrAutoResolve();

	@Override
	public IBatchResults performBatch() {
		autoResolve.setSmrAutoResolutionService(smrAutoResolutionService);
        int exitCode = autoResolve.beginAutoResolving(getArguments().toArray());
        return new BatchResults(exitCode);
	}

    @Autowired
    public void setSmrAutoResolutionService(ISmrAutoResolutionService smrAutoResolutionService) {
        this.smrAutoResolutionService = smrAutoResolutionService;
    }   
}
