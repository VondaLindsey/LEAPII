package smr.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.driver.OracleStatement;
import oracle.retail.reim.business.Supplier;
import oracle.retail.reim.business.document.HoldStatus;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.DatasourceProperties;
import oracle.retail.reim.utils.Severity;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import smr.retail.reim.business.SmrMerchandiseDocument;
import smr.retek.reim.ui.invoiceMaintenance.SmrInvoiceMassCorrectionForm;

import com.retek.reim.business.Order;
import com.retek.reim.business.Term;
import com.retek.reim.business.document.Document;
import com.retek.reim.db.ImDocHeadRow;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ServiceFactory;

import java.sql.CallableStatement;
import java.sql.Statement;

import org.apache.commons.lang.StringUtils;

/**
* // BRN IMS 175253 Fix. 
* Modification History
* Version Date      Developer   Issue     Description
* ======= ========= =========== ========= ========================================================
* 1.2    	31-Oct-2013	BNaik  175253 - Receipts not released from deleted invoices
* 										
*/

public class SmrImDocHeadAccessExt extends com.retek.reim.db.ImDocHeadAccess {

    public void updateCostQty(String order_no, String location, String item_no) throws ReIMException {
        CallableStatement cstmt = null;

        try {
            TransactionManagerFactory.getInstance().start();
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            cstmt = conn.prepareCall("{?=call SMR_REIM_AUTORESOLVE.UPDATE_ORDER_SKU_PRICES(?,?,?,?)}");

            // for lookup
            cstmt.registerOutParameter(1, java.sql.Types.INTEGER ); // Return value
            cstmt.registerOutParameter(2, java.sql.Types.VARCHAR); // O_error_message
            cstmt.setLong(3, Long.valueOf(order_no)); // I_order_no
            cstmt.setLong(4, Long.valueOf(location)); // I_location
            cstmt.setString(5, item_no); // I_item_no
            cstmt.executeQuery();

            int returnValue = cstmt.getInt(1);
            String errorMsg = cstmt.getString(2);
                 
            if (returnValue == 1) {
                throw new SQLException(errorMsg);
            }

        } catch (Exception exception) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR,exception, this);
        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
                TransactionManagerFactory.getInstance().end();
            } catch (Exception exception) {
                TransactionManagerFactory.getInstance().rollback();
                throw new ReIMException("error.cannot_update_receipt_status", Severity.ERROR,exception, this);
            }
        }
    }

    public ImDocHeadRow readDocByVendor(String vendorType, String vendorId, String extDocId)
            throws ReIMException {

    	String where = "IM_DOC_HEAD.VENDOR_TYPE = '" + vendorType + "' AND IM_DOC_HEAD.VENDOR = '" + vendorId + "' AND IM_DOC_HEAD.EXT_DOC_ID = '" + extDocId + "' ";
        ImDocHeadRow[] headRows = read(where, null, null, null);

        if (headRows == null) return null;
        if (headRows.length > 1) {
        	throw new ReIMException("error.doc_head_failed_to_get_doc_id", Severity.ERROR, this);
        }
        return headRows[0];
    }

	public static Order[] selectDistinctOrders(String supplier, String orderNo, String invoiceId) throws ReIMException {
	    OraclePreparedStatement stmt = null;
	    ResultSet rs = null;
	    try {
	        Connection conn = TransactionManagerFactory.getInstance().getConnection();
			StringBuffer query = new StringBuffer("SELECT DISTINCT DH.ORDER_NO, O.SUPPLIER, O.CURRENCY_CODE FROM IM_DOC_HEAD DH, ORDHEAD O, SUPS SS WHERE DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"' ");

					query.append(" AND ( DH.STATUS= '" +Document.READY_FOR_MATCH +"' ");
					query.append(" OR DH.STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
					query.append(" OR DH.STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");

					query.append(" AND O.ORDER_NO = DH.ORDER_NO AND SS.SUPPLIER = O.SUPPLIER");

			if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
	        stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
	        rs = stmt.executeQuery();
	        ArrayList<Order> orderList = new ArrayList<Order>();
	        Order order;
	        while (rs.next()) {

	            order = new Order(rs.getString("ORDER_NO"), rs.getString("SUPPLIER"), rs.getString("CURRENCY_CODE") );
	            orderList.add(order);
	        }
	        if (orderList.size() > 0) {
	            return (Order[]) orderList.toArray(new Order[orderList.size()]);
	        } else {
	            return null;
	        }
	    } catch (Exception exception) {
	        throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }

	            if (stmt != null) {
	                stmt.close();
	            }
	        } catch (SQLException exception) {
	            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	        }
	    }
	}


	public static Term[] selectDistinctTerms(String supplier, String orderNo, String invoiceId, String termsId) throws ReIMException {
	    OraclePreparedStatement stmt = null;
	    ResultSet rs = null;
	    try {
	        Connection conn = TransactionManagerFactory.getInstance().getConnection();
			StringBuffer query = new StringBuffer("SELECT DISTINCT T.TERMS, T.TERMS_CODE, T.TERMS_DESC FROM TERMS T, IM_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP' AND T.TERMS = DH.TERMS ");
			query.append("  AND DH.STATUS = '" +Document.READY_FOR_MATCH +"' AND  DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"'");

			if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
			if (termsId != null && !termsId.equals("")) query.append("   AND DH.TERMS = ?");
	        stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
			if (termsId != null && !termsId.equals("")) stmt.setString(ind++,termsId);

			rs = stmt.executeQuery();
	        ArrayList<Term> termsList = new ArrayList<Term>();
	        Term term;
	        while (rs.next()) {
	            term = new Term(rs.getString("TERMS_CODE"));
	            term.setTermId(rs.getString("TERMS"));
	            term.setTermDescription(rs.getString("TERMS_DESC"));
	            termsList.add(term);
	        }
	        if (termsList.size() > 0) {
	            return (Term[]) termsList.toArray(new Term[termsList.size()]);
	        } else {
	            return null;
	        }
	    } catch (Exception exception) {
	        throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	    } finally {
	        try {
	            if (rs != null) {
	                rs.close();
	            }

	            if (stmt != null) {
	                stmt.close();
	            }
	        } catch (SQLException exception) {
	            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
	        }
	    }
	}


    public static Supplier[] selectDistinctSupplierSitesFilter(String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException {
    	OraclePreparedStatement stmt = null;
    	ResultSet rs = null;
    	try {
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
    		StringBuffer query1 = new StringBuffer("SELECT SS.SUPPLIER, SS.SUP_NAME FROM SUPS SS, IM_DOC_HEAD DH  WHERE DH.VENDOR_TYPE = 'SUPP'  AND DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"' ");

					query1.append(" AND ( DH.STATUS= '" +Document.READY_FOR_MATCH +"' ");
					query1.append(" OR DH.STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
					query1.append(" OR DH.STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");

    				query1.append(" AND SS.SUPPLIER_PARENT = DH.VENDOR ");

    		StringBuffer query2 = new StringBuffer(" UNION  SELECT SS2.SUPPLIER SUPPLIER, SS2.SUP_NAME  FROM SUPS SS1, SUPS SS2, IM_DOC_HEAD DH  WHERE DH.VENDOR_TYPE = 'SUPP'  AND DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"' ");

					query2.append(" AND ( DH.STATUS= '" +Document.READY_FOR_MATCH +"' ");
					query2.append(" OR DH.STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
					query2.append(" OR DH.STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");

    				query2.append(" AND SS1.SUPPLIER_PARENT = SS2.SUPPLIER AND SS1.SUPPLIER_PARENT = DH.VENDOR ");

    		int offset = 0;
    		if (supplierSiteIdFromUser != null && !supplierSiteIdFromUser.equals("")) {
    			query1.append("   AND SS.SUPPLIER = ?");
    			query2.append("   AND SS1.SUPPLIER_PARENT = ?");
    			offset++;
    		}
    		if (orderNo != null && !orderNo.equals("")) {
    			query1.append("   AND DH.ORDER_NO = ?");
    			query2.append("   AND DH.ORDER_NO = ?");
    			offset++;
    		}
    		if (invoiceId != null && !invoiceId.equals("")) {
    			query1.append("   AND DH.EXT_DOC_ID = ?");
    			query2.append("   AND DH.EXT_DOC_ID = ?");
    			offset++;
    		}
    		query2.append("   ORDER BY SUP_NAME ");

    		stmt = (OraclePreparedStatement) conn.prepareStatement(query1.toString() + query2.toString());
    		int ind = 1;
    		if (supplierSiteIdFromUser != null && !supplierSiteIdFromUser.equals("")) {
    			stmt.setString(ind, supplierSiteIdFromUser);
    			stmt.setString(offset + ind++, supplierSiteIdFromUser);
    		}
    		if (orderNo != null && !orderNo.equals("")) {
    			stmt.setString(ind, orderNo);
    			stmt.setString(offset + ind++, orderNo);
    		}
    		if (invoiceId != null && !invoiceId.equals("")) {
    			stmt.setString(ind, invoiceId);
    			stmt.setString(offset + ind++, invoiceId);
    		}
    		rs = stmt.executeQuery();
    		ArrayList<Supplier> supplierList = new ArrayList<Supplier>();
    		Supplier supplier;
    		while (rs.next()) {
    			supplier = new Supplier(new Long(rs.getString("SUPPLIER")));
    			supplier.setVendorName(rs.getString("SUP_NAME"));
    			supplierList.add(supplier);
    		}
    		if (supplierList.size() > 0) {
    			return (Supplier[]) supplierList.toArray(new Supplier[supplierList.size()]);
    		} else {
    			return null;
    		}
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    	} finally {
    		try {
    			if (rs != null) {
    				rs.close();
    			}

    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    		}
    	}
    }


    public static Supplier[] selectInvoiceSupplierSites(String supplierId, String orderNo, String invoiceId) throws ReIMException {
    	// supplierId can be either a supplier or a supplierSite
    	// It can come from the filter LOV, or could be typed in by the user as OldSupplierId.
    	// If both are provided, and they do not match, we can not even get here.
    	// If supplierId is null, none of them was provided.
    	OraclePreparedStatement stmt = null;
    	ResultSet rs = null;
    	try {
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
    		// Called from the oldSupplierSiteId LOV. We can ignore supplierSiteIdFromUser because it is either empty, or the same as supplierSiteIdFromFilter
    		// Also, supplierSiteIdFromFilter is always a supplierSiteId
    		StringBuffer query = new StringBuffer("SELECT DISTINCT SS.SUPPLIER, SS.SUP_NAME FROM SUPS SS, IM_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP' AND DH.VENDOR = SS.SUPPLIER_PARENT AND DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"' ");

    		//query.append(" AND DH.STATUS = '" +Document.READY_FOR_MATCH +"' AND  DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"'");
			query.append(" AND ( DH.STATUS= '" +Document.READY_FOR_MATCH +"' ");
			query.append(" OR DH.STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
			query.append(" OR DH.STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");

    		if (supplierId != null && !supplierId.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
    		if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
    		if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
    		stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
    		int ind = 1;
    		if (supplierId != null && !supplierId.equals("")) {
    			stmt.setString(ind++, supplierId);
    			stmt.setString(ind++, supplierId);
    		}
    		if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
    		if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
    		rs = stmt.executeQuery();
    		ArrayList<Supplier> supplierList = new ArrayList<Supplier>();
    		Supplier supplier;
    		while (rs.next()) {
    			supplier = new Supplier(new Long(rs.getString("SUPPLIER")));
    			supplier.setVendorName(rs.getString("SUP_NAME"));
    			supplierList.add(supplier);
    		}
    		if (supplierList.size() > 0) {
    			return (Supplier[]) supplierList.toArray(new Supplier[supplierList.size()]);
    		} else {
    			return null;
    		}
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    	} finally {
    		try {
    			if (rs != null) {
    				rs.close();
    			}

    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    		}
    	}
    }

    public static Supplier[] selectDistinctSupplierSites(String supplierId, String orderNo ) throws ReIMException {

    	OraclePreparedStatement stmt = null;
    	ResultSet rs = null;
    	try {
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();

    		StringBuffer query = new StringBuffer("SELECT distinct A.SUPPLIER SUPPLIERSITE, A.SUP_NAME SITENAME  from SUPS A, SUPS B, TERMS T , IM_SUPPLIER_OPTIONS S, ORDHEAD O  ");
    			query.append(" WHERE A.TERMS=T.TERMS AND T.ENABLED_FLAG='Y' AND B.SUPPLIER=S.SUPPLIER  ");
    			query.append(" AND A.SUPPLIER_PARENT IS NOT NULL AND A.SUPPLIER_PARENT = B.SUPPLIER AND O.SUPPLIER = A.SUPPLIER ");

    		if (supplierId != null && !supplierId.equals("")) query.append("  AND (A.SUPPLIER=? OR B.SUPPLIER=?) ");
    		if (orderNo != null && !orderNo.equals("")) query.append("   AND O.ORDER_NO = ?");
    		query.append(" order by SITENAME ");

    		stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
    		int ind = 1;
    		if (supplierId != null && !supplierId.equals("")) {
    			stmt.setString(ind++, supplierId);
    			stmt.setString(ind++, supplierId);
    		}
    		if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
    		rs = stmt.executeQuery();
    		ArrayList<Supplier> supplierList = new ArrayList<Supplier>();
    		Supplier supplier;
    		while (rs.next()) {
    			supplier = new Supplier(new Long(rs.getString("SUPPLIERSITE")));
    			supplier.setVendorName(rs.getString("SITENAME"));
    			supplierList.add(supplier);
    		}
    		if (supplierList.size() > 0) {
    			return (Supplier[]) supplierList.toArray(new Supplier[supplierList.size()]);
    		} else {
    			return null;
    		}
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    	} finally {
    		try {
    			if (rs != null) {
    				rs.close();
    			}

    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
    		}
    	}
    }

	public static Document[] selectDistinctInvoices(String supplier, String orderNo, String invoiceId) throws ReIMException {
		OraclePreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			Connection conn = TransactionManagerFactory.getInstance().getConnection();
			StringBuffer query = new StringBuffer("SELECT DISTINCT DH.EXT_DOC_ID, DH.ORDER_NO FROM IM_DOC_HEAD DH WHERE DH.VENDOR_TYPE = 'SUPP'");

			//query.append(" AND DH.STATUS = '" +Document.READY_FOR_MATCH +"' AND  DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"'");
			query.append(" AND ( STATUS= '" +Document.READY_FOR_MATCH +"' ");
			query.append(" OR STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
			query.append(" OR STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");
			query.append(" AND  DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"'");

			if (supplier != null && !supplier.equals("")) query.append("   AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND DH.ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND DH.EXT_DOC_ID = ?");
			query.append("  ORDER BY DH.EXT_DOC_ID ASC ");

			stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
			rs = stmt.executeQuery();
			ArrayList<Document> docList = new ArrayList<Document>();
			Document doc;
			while (rs.next()) {
				doc = new Document();
				doc.setExtDocId(rs.getString("EXT_DOC_ID"));
				doc.setOrderNo(rs.getString("ORDER_NO"));

				docList.add(doc);
			}
			if (docList.size() > 0) {
				return (Document[]) docList.toArray(new Document[docList.size()]);
			} else {
				return null;
			}
		} catch (Exception exception) {
			throw new ReIMException("error.sql_error", Severity.ERROR, exception);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stmt != null) {
					stmt.close();
				}
			} catch (SQLException exception) {
				throw new ReIMException("error.sql_error", Severity.ERROR, exception);
			}
		}
	}

	public Map<String, String> getInvoiceDateTerms(String[] docIdStrings) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        Map<String, String> invoiceDateTermsMap = new HashMap<String, String>(docIdStrings.length);
        String schemaOwner = DatasourceProperties.schemaOwner;
        
        try {
            StringBuffer query = new StringBuffer("SELECT DISTINCT DOC_ID, DOC_DATE, TERMS FROM IM_DOC_HEAD " +
            		" WHERE VENDOR_TYPE = 'SUPP' and DOC_ID IN ( SELECT * FROM TABLE(CAST(? AS "
                            + schemaOwner.toUpperCase() +".NUMBERLIST_TBL))) ");
            
            
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            
            ARRAY array = null;
            
            if (docIdStrings != null && docIdStrings.length > 0){
				ArrayDescriptor ad = ArrayDescriptor.createDescriptor(schemaOwner.toUpperCase()+".NUMBERLIST_TBL",conn);
				array = new ARRAY(ad,conn,docIdStrings);
			}
					
			((OraclePreparedStatement)stmt).setARRAY(1, array);
            rs = stmt.executeQuery();
        
            while (rs.next()) {
            	StringBuffer dateTerm = new StringBuffer(new ReIMDate(rs.getDate(2)).getDateString());
            	dateTerm.append('_');
            	dateTerm.append(rs.getString(3));
            	invoiceDateTermsMap.put(rs.getString(1), dateTerm.toString());                
            }
            
            if (invoiceDateTermsMap.size() > 0) {
                return invoiceDateTermsMap;
            } else {
                return null;
            }
        } catch (SQLException ex) {            
            throw new ReIMException("error.sql_error", Severity.ERROR, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex);
            }
        }
    }
	
	public Map<String, String> getInvoiceDateTerms(String whereCondition) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        Map<String, String> invoiceDateTermsMap = new HashMap<String, String>();
        
        try {
            StringBuffer query = new StringBuffer("SELECT DISTINCT DOC_ID, DOC_DATE, TERMS FROM IM_DOC_HEAD ");
            
            if (StringUtils.isNotEmpty(whereCondition)){
            	query.append(whereCondition);
			}
			
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
            rs = stmt.executeQuery();
        
            while (rs.next()) {
            	StringBuffer dateTerm = new StringBuffer(new ReIMDate(rs.getDate(2)).getDateString());
            	dateTerm.append('_');
            	dateTerm.append(rs.getString(3));
            	invoiceDateTermsMap.put(rs.getString(1), dateTerm.toString());                
            }
            
            if (invoiceDateTermsMap.size() > 0) {
                return invoiceDateTermsMap;
            } else {
                return null;
            }
        } catch (SQLException ex) {            
            throw new ReIMException("error.sql_error", Severity.ERROR, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex);
            }
        }
    }

 //   public static String[] getDocIds(String supplier, String orderNo, String invoiceId) throws ReIMException {
    public static String[] getDocIds(String supplier, String orderNo, String invoiceId, String fromInvoiceId, String toInvoiceId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            StringBuffer query = new StringBuffer("SELECT DISTINCT DOC_ID FROM IM_DOC_HEAD WHERE VENDOR_TYPE = 'SUPP'");

			query.append(" AND ( STATUS= '" +Document.READY_FOR_MATCH +"' ");
			query.append(" OR STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
			query.append(" OR STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");

			if (supplier != null && !supplier.equals("")) query.append("   AND VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) query.append("   AND ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) query.append("   AND EXT_DOC_ID = ?");
			
			if (fromInvoiceId != null && !fromInvoiceId.equals("") && toInvoiceId != null && !toInvoiceId.equals("")){
				query.append("  AND EXT_DOC_ID >= '");
				query.append(fromInvoiceId);
				query.append("' ");
				query.append("  AND EXT_DOC_ID <= '");
				query.append(toInvoiceId);
				query.append("' ");
			}
			
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
            rs = stmt.executeQuery();
            ArrayList list = new ArrayList();
            String docId = null;
            while (rs.next()) {
                docId = new String();
                docId = rs.getString(1);
                list.add(docId);
            }
            if (list.size() > 0) {
                return (String[]) list.toArray(new String[list.size()]);
            } else {
                return null;
            }
        } catch (SQLException ex) {
            String exMsg = "" + "Bind variables: supplierId: " + supplier + ", orderNo: " + orderNo + ", invoiceId: " + invoiceId;
            throw new ReIMException("error.sql_error", Severity.ERROR, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set",
                        Severity.ERROR, ex);
            }
        }
    }

    public void updateDueDates(HashMap<String, String> invoiceDueDatesMap) throws ReIMException {
    	
    	OraclePreparedStatement pstmt = null;
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    	String newDueDate;
    	String userId;
    	try {
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
    		
    		pstmt = (OraclePreparedStatement) conn.prepareStatement("UPDATE IM_DOC_HEAD "
                    + " SET DUE_DATE  = to_date(?, 'YYYYMMDD') " + " , LAST_UPDATE_ID = ?"
                    + "  WHERE DOC_ID = ?");

    		userId = ReIMUserContext.getUsername();
    		
    		for (String docID : invoiceDueDatesMap.keySet()) {
    			newDueDate = formatter.format(new ReIMDate(invoiceDueDatesMap.get(docID)));
                pstmt.setString(1, newDueDate);
                pstmt.setString(2, userId);                
                pstmt.setString(3, docID);

                pstmt.addBatch();
            }

            pstmt.executeBatch();
    		
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    	} finally {
    		try {
    			if (pstmt != null) {
    				pstmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    		}
    	}
        
    }
    
    public String[] replace(SmrMerchandiseDocument smrMerchandiseDocument)
    throws ReIMException {
    	OraclePreparedStatement stmt = null;
    	ResultSet rs = null;
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    	boolean updateHoldReleaseStatus = false;
    	boolean updateDeleteStatus = false;
    	boolean updateMassEditStatus = false;

    	try {
    		
    		String supplier = smrMerchandiseDocument.getSupplierId();
			String orderNo = smrMerchandiseDocument.getOrderNo();
			String invoiceId = smrMerchandiseDocument.getInvoiceId();
			String operationRadio = smrMerchandiseDocument.getOperationRadio();
			String oldInvoiceDate = smrMerchandiseDocument.getOldInvoiceDate();
			String newInvoiceDate = smrMerchandiseDocument.getNewInvoiceDate();
			String oldDueDate = smrMerchandiseDocument.getOldDueDate();
			String newDueDate = smrMerchandiseDocument.getNewDueDate();
			String oldSupplierSiteId = smrMerchandiseDocument.getOldSupplierSiteId();
			String newSupplierSiteId = smrMerchandiseDocument.getNewSupplierSiteId();
			String fromInvoiceId = smrMerchandiseDocument.getFromInvoiceId();
			String toInvoiceId = smrMerchandiseDocument.getToInvoiceLOV();
			String appendInvoice = smrMerchandiseDocument.getAppendInvoice();
			String oldTermsId = smrMerchandiseDocument.getOldTermsId();
			String newTermsId = smrMerchandiseDocument.getNewTermsId();
			String oldOrderNo = smrMerchandiseDocument.getOldOrderNo();
			String newOrderNo  = smrMerchandiseDocument.getNewOrderNo();
    		
            StringBuffer selectHead = new StringBuffer("SELECT DISTINCT DH.DOC_ID from IM_DOC_HEAD DH ");
            
			StringBuffer updHead = new StringBuffer("UPDATE IM_DOC_HEAD DH SET DH.LAST_UPDATE_ID = '");
			updHead.append(ReIMUserContext.getUsername());
			updHead.append("' ");

			StringBuffer upd = new StringBuffer("");
			StringBuffer where = new StringBuffer(" WHERE DH.VENDOR_TYPE = 'SUPP'");
				where.append(" AND  DH.TYPE = '" +Document.MERCHANDISE_INVOICE +"' ");

			StringBuffer whereUnresolved = new StringBuffer(" AND DH.STATUS IN ( '" +Document.UNRESOLVED_MATCH+"' )");
				whereUnresolved.append(" AND EXISTS (SELECT 'X' FROM IM_INVOICE_DETAIL DT WHERE DT.DOC_ID = DH.DOC_ID AND DT.STATUS='MTCH') ");
				whereUnresolved.append(" AND EXISTS (SELECT 'X' FROM IM_RECEIPT_ITEM_POSTING RIP, IM_RCPT_ITEM_POSTING_INVOICE RIPI WHERE RIP.SEQ_NO = RIPI.SEQ_NO AND RIPI.DOC_ID = DH.DOC_ID) ");
        		
			String deleteStatus = new String(" AND DH.STATUS NOT IN ( '" +Document.POSTED  +"' , '"+ Document.MULTI_UNRESOLVED + "', '"  + Document.MATCHED + "' , '"  +  Document.DELETE + "' )" +
					"	AND NOT EXISTS (SELECT 'X' FROM IM_RESOLUTION_ACTION RA WHERE RA.DOC_ID = DH.DOC_ID) ");
			
			String massEditStatus = new String(" AND DH.STATUS NOT IN ( '" +Document.POSTED  +"' ," + "'" + Document.MATCHED + "' , "  + "'" + Document.DELETE + "' )" );

			StringBuffer holdReleaseStatus = new StringBuffer(" AND ( DH.STATUS= '" +Document.READY_FOR_MATCH +"' ");
				holdReleaseStatus.append(" OR DH.STATUS= '" +Document.UNRESOLVED_MATCH+"' ");
				holdReleaseStatus.append(" OR DH.STATUS= '" +Document.MULTI_UNRESOLVED+"' ) ");

			if (operationRadio != null && !operationRadio.equals("") ) {

				if (operationRadio.equals(SmrInvoiceMassCorrectionForm.OPERATION_DELETE)){
					
					updateDeleteStatus = true;
					upd.append(", DH.STATUS = '");
					upd.append(Document.DELETE);
					upd.append("' ");					

	            }else if(operationRadio.equals(SmrInvoiceMassCorrectionForm.OPERATION_HOLD)){
	            	updateHoldReleaseStatus = true;
					upd.append(", DH.HOLD_STATUS = '");
					upd.append(HoldStatus.HELD.getCode());
					upd.append("' ");

	            }else if(operationRadio.equals(SmrInvoiceMassCorrectionForm.OPERATION_RELEASE)){
	            	updateHoldReleaseStatus = true;
	            	upd.append(", DH.HOLD_STATUS =  '");
					upd.append(HoldStatus.RELEASED.getCode());
					upd.append("' ");
	            }
			} else {
				
				updateMassEditStatus = true;
			}

			if (oldInvoiceDate != null && !oldInvoiceDate.equals("") && newInvoiceDate != null && !newInvoiceDate.equals("")) {

				newInvoiceDate = formatter.format(new ReIMDate(newInvoiceDate));
				upd.append(" , DH.DOC_DATE = to_date('").append(newInvoiceDate).append("', 'YYYYMMDD')");
				oldInvoiceDate = formatter.format(new ReIMDate(oldInvoiceDate));
				where.append(" AND DH.DOC_DATE = to_date('").append(oldInvoiceDate).append("', 'YYYYMMDD')");
			}
			
			if (oldDueDate != null && !oldDueDate.equals("") && newDueDate != null && !newDueDate.equals("")) {

				newDueDate = formatter.format(new ReIMDate(newDueDate));
				upd.append(" , DH.DUE_DATE = to_date('").append(newDueDate).append("', 'YYYYMMDD')");
				oldDueDate = formatter.format(new ReIMDate(oldDueDate));
				where.append(" AND DH.DUE_DATE = to_date('").append(oldDueDate).append("', 'YYYYMMDD')");
			}

			if (oldSupplierSiteId != null && !oldSupplierSiteId.equals("") && newSupplierSiteId != null && !newSupplierSiteId.equals("")) {
				upd.append(", DH.SUPPLIER_SITE_ID =  '");
				upd.append(newSupplierSiteId);
				upd.append("' ");
				where.append("  AND DH.SUPPLIER_SITE_ID = '");
				where.append(oldSupplierSiteId);
				where.append("' ");
			}


			//Only the appendInvoice is entered. It means to append all the invoices
		     if ( (fromInvoiceId == null || fromInvoiceId.equals("")) && (toInvoiceId == null || toInvoiceId.equals(""))
		    		 && ( appendInvoice != null && !appendInvoice.equals(""))  ) {

		    	 upd.append(" , DH.EXT_DOC_ID = DH.EXT_DOC_ID || '");
		    	 upd.append(appendInvoice);
		    	 upd.append("' ");

           }else  if ( (fromInvoiceId != null && !fromInvoiceId.equals("")) && (toInvoiceId != null && !toInvoiceId.equals(""))
		    		 && ( appendInvoice != null && !appendInvoice.equals(""))  )
           {
        	   upd.append(" , DH.EXT_DOC_ID = DH.EXT_DOC_ID || '");
        	   upd.append(appendInvoice);
        	   upd.append("' ");
        	   where.append("  AND DH.EXT_DOC_ID >= '");
        	   where.append(fromInvoiceId);
        	   where.append("' ");
        	   where.append("  AND DH.EXT_DOC_ID <= '");
        	   where.append(toInvoiceId);
        	   where.append("' ");
            }else  if ( (fromInvoiceId != null && !fromInvoiceId.equals("")) && (toInvoiceId != null && !toInvoiceId.equals(""))
		    		 && ( appendInvoice == null || appendInvoice.equals(""))  )
            {         	   
         	   where.append("  AND DH.EXT_DOC_ID >= '");
         	   where.append(fromInvoiceId);
         	   where.append("' ");
         	   where.append("  AND DH.EXT_DOC_ID <= '");
         	   where.append(toInvoiceId);
         	   where.append("' ");
             }

			if (oldTermsId != null && !oldTermsId.equals("") && newTermsId != null && !newTermsId.equals("")) {
				upd.append(", DH.TERMS = '");
        	    upd.append(newTermsId);
        	    upd.append("' ");
				where.append("  AND DH.TERMS = '");
	        	where.append(oldTermsId);
	        	where.append("' ");
			}

			if (oldOrderNo != null && !oldOrderNo.equals("") && newOrderNo != null && !newOrderNo.equals("")) {
				upd.append(", DH.ORDER_NO = ");
				upd.append(newOrderNo);
				where.append("  AND DH.ORDER_NO = ");
				where.append(oldOrderNo);
			}

			if (supplier != null && !supplier.equals("")){
				where.append("  AND DH.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = '");
				where.append(supplier);
				where.append("' ");
				where.append(" UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = '");
				where.append(supplier);
				where.append("' ) ");
			}

			if (orderNo != null && !orderNo.equals("")){
				where.append("  AND DH.ORDER_NO = ");
				where.append(orderNo);
			}

			if (invoiceId != null && !invoiceId.equals("")){
				where.append("  AND DH.EXT_DOC_ID = '");
				where.append(invoiceId);
				where.append("' ");
			}

			if (updateHoldReleaseStatus) {
				where.append(holdReleaseStatus);
				
			} else if(updateDeleteStatus) {
				where.append(deleteStatus);
			
			}else {
				where.append(massEditStatus);
			}

			Connection conn = TransactionManagerFactory.getInstance().getConnection();
			
			stmt = (OraclePreparedStatement) conn.prepareStatement(selectHead.toString() + where.toString());
			rs = stmt.executeQuery();
			
			ArrayList list = new ArrayList();
            String docId = null;
            while (rs.next()) {
                docId = new String();
                docId = rs.getString(1);
                list.add(docId);
            }
            
            // If the unresolved invoices are to be deleted then the corresponding discrepancies and the perfect matched items need to be reversed.
        	if (operationRadio.equals(SmrInvoiceMassCorrectionForm.OPERATION_DELETE)){
				
        		ArrayList<Document> unresolvedDocs = new ArrayList<Document>();
        		Document doc = null;
        		
        		stmt = (OraclePreparedStatement) conn.prepareStatement(selectHead.toString() + where.toString() + whereUnresolved.toString());
    			rs = stmt.executeQuery();
    			
    			while (rs.next()) {
    				    doc = new Document(rs.getLong(1));    	                
    				    doc.setDetailsExist(true);
    				    unresolvedDocs.add(doc);
    	        }
    			
                Document[] deleteDiscrepancyArray = (Document[]) unresolvedDocs
                        .toArray(new Document[unresolvedDocs.size()]);
                long[] docIds = new long[deleteDiscrepancyArray.length];
                for (int i = 0; i < deleteDiscrepancyArray.length; i++) {
                    docIds[i] = deleteDiscrepancyArray[i].getDocId();
                }
                
                ServiceFactory.getDiscrepancyService()
                        .deleteQtyAndCostDiscrepanciesByDocId(docIds);

                // Remove any im_rcpt_item_posting_invoice,
                // im_receipt_item_posting records
                // Update or delete from im_partially_matched_receipts
                ServiceFactory.getReceiptTrackingService().removeInvoiceFromReceipt(
                        deleteDiscrepancyArray);                  
        	}
            
			stmt = (OraclePreparedStatement) conn.prepareStatement(updHead.toString() + upd.toString() + where.toString());
			stmt.executeUpdate();
			
			if (list.size() > 0) {
                return (String[]) list.toArray(new String[list.size()]);
            } else {
                return null;
            }
            
            
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    	} finally {
    		try {
    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    		}
    	}
    }

  // to validate true duplicates
   public static boolean checkTrueDuplicates(String extDocId, String orderNo, Double totalCost, String vendor) throws ReIMException {
       OraclePreparedStatement stmt = null;
       ResultSet rs = null;
       try {
           Connection conn = TransactionManagerFactory.getInstance().getConnection();
                   StringBuffer query = new StringBuffer("select 'x'\n" +
                   "   from im_doc_head\n" +
                   " where EXT_DOC_ID = ? \n" +
                   "   and ORDER_NO = ? \n" +
                   "   and VENDOR = ? \n" +
                   "   and TOTAL_COST = ? " +
                   " UNION   select 'x'\n" +
                   "   from IM_DOC_HEAD\n" +
                   " where EXT_DOC_ID = ? \n" +
                   "   and ORDER_NO = ? \n" +
                   "   and vendor = ? \n" +
                   "   and TOTAL_COST = ? " );

           stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());

           stmt.setString(1, extDocId);
           stmt.setString(2, orderNo);
           stmt.setString(3, vendor);
           stmt.setDouble(4, totalCost);

           stmt.setString(5, extDocId);
           stmt.setString(6, orderNo);
           stmt.setString(7, vendor);
           stmt.setDouble(8, totalCost);

           rs = stmt.executeQuery();

           if (rs.next()) {
                return true;
            } else {
                return false;
            }

       } catch (Exception exception) {
           throw new ReIMException("error.sql_error", Severity.ERROR, exception);
       } finally {
           try {
               if (rs != null) {
                   rs.close();
               }

               if (stmt != null) {
                   stmt.close();
               }
           } catch (SQLException exception) {
               throw new ReIMException("error.sql_error", Severity.ERROR, exception);
           }
       }
   }

    public static boolean softDuplicates(String extDocId, String orderNo, Double totalCost, String vendor) throws ReIMException {

        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
                    StringBuffer query = new StringBuffer(" select order_no, total_cost\n" +
                    "   from im_doc_head\n" +
                    " where trim(EXT_DOC_ID) = ? \n" +
                    "   and VENDOR = ? \n" +
                    "union\n" +
                    "select order_no, total_cost\n" +
                    "   from IM_DOC_HEAD\n" +
                    " where EXT_DOC_ID = ? \n" +
                    "   and vendor = ? ");

            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());

            stmt.setString(1, extDocId);
            stmt.setString(2, vendor);

            stmt.setString(3, extDocId);
            stmt.setString(4, vendor);

            rs = stmt.executeQuery();

            if (rs.next()) {

                if ( rs.getString("ORDER_NO").equalsIgnoreCase(orderNo) && rs.getDouble("TOTAL_COST") == totalCost ) {
                    return true;
                } else {
                    return false;
                }

             }

           return true;

        } catch (Exception exception) {
            throw new ReIMException("error.sql_error", Severity.ERROR, exception);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException exception) {
                throw new ReIMException("error.sql_error", Severity.ERROR, exception);
            }
        }
    }

    private static final String GET_ITEM_FROM_UPC = "SELECT ITEM_PARENT, ITEM, ITEM_LEVEL, TRAN_LEVEL FROM ITEM_MASTER"
            + " WHERE ITEM_LEVEL >= TRAN_LEVEL" ;

    public String validUpc(String upc, Long upcSupplement) throws ReIMException {
        Statement stmt = null;
        String item = null;
        StringBuffer selectUpc = new StringBuffer(GET_ITEM_FROM_UPC); 

        ResultSet rs = null;

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
                        stmt = conn.createStatement();
 
            selectUpc.append(" and item = '" + upc + "'");    
            selectUpc.append(" or item =  '0" + upc + "'"); 
            rs = stmt.executeQuery(selectUpc.toString());

            if (rs.next()) {
                if (rs.getInt("ITEM_LEVEL") == rs.getInt("TRAN_LEVEL")) {
                    item = rs.getString("ITEM");
                } else {
                    item = rs.getString("ITEM_PARENT");
                }
            }
            return item;
        } catch (Exception exception) {
            throw new ReIMException("error.item_bean.valid_upc", Severity.ERROR, exception, this,
                    new String[] { upc});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }

            } catch (SQLException exception) {
                throw new ReIMException("error.item_bean.valid_upc", Severity.ERROR, exception,
                        this, new String[] { upc});
            }
        }
    }


}

