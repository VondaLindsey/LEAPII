package smr.retail.reim.data.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.retail.reim.business.EdiRejectDocumentTaxSearchCriteria;
import oracle.retail.reim.business.document.DocId;
import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.business.tax.TaxRule;
import oracle.retail.reim.data.DataAccessException;
import oracle.retail.reim.data.dao.IEdiRejectDocumentTaxDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import smr.retail.reim.data.dao.ISmrEdiRejectDocumentDao;
import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;
import smr.retek.reim.batch.ediupinv.SmrEdiTransactionHeader;

import com.retek.reim.batch.ediupinv.EDIHeaderTax;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.business.document.Document;
import com.retek.reim.db.ImEDIRejectDocHeadAccessExt;
import com.retek.reim.db.ImEDIRejectDocHeadRow;
import com.retek.reim.foundation.AOrderBean;
import com.retek.reim.foundation.ASupplierBean;
import com.retek.reim.merch.utils.ReIMBeanFactory;
import com.retek.reim.merch.utils.ReIMConstants;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.services.ServiceFactory;

@Repository
public class SmrEdiRejectDocumentDao extends SimpleJdbcDaoSupport implements ISmrEdiRejectDocumentDao {

    private IEdiRejectDocumentTaxDao ediRejectDocumentTaxDao;
    /* SMR OLR ENH31 Inserted - START */
    private static final String INSERT_INTO_SMR_EDI_REJECT = "INSERT INTO SMR_IM_EDI_REJECT " +
	"(VENDOR, EXT_DOC_ID, BATCH_ID, ERROR_CODE, SKU, UPC, UPLD_TIMESTAMP, TOTAL_COST, TOTAL_QTY) "+
	"values (:VENDOR, :EXT_DOC_ID, :BATCH_ID, :ERROR_CODE, :SKU, :UPC, :UPLD_TIMESTAMP, :TOTAL_COST, :TOTAL_QTY)";
    /* SMR OLR ENH31 Inserted - END */
    
    public List<EdiTransactionHeader> readByDocuments(String[] documentIdList) {
        try {
            ImEDIRejectDocHeadRow[] docHeadRow = new ImEDIRejectDocHeadAccessExt().readByDocuments(documentIdList);   
                        
            boolean supplierSiteInd = ServiceFactory.getSystemOptionsService().getSystemOptions().isSupplierSiteInd();            
            AOrderBean orderBean = (AOrderBean) ReIMBeanFactory.getBean(ReIMBeanFactory.AOrderBean);
            ASupplierBean supplierBean = (ASupplierBean) ReIMBeanFactory.getBean(ReIMBeanFactory.ASupplierBean);
            String supplier = null;
            String supplierParent = null;
            String supplierSite = null;
            

            // Build searchCriteria for tax dao
            List<DocId> docIds = new ArrayList<DocId>();
            for (int i = 0; i < documentIdList.length; i++) {
                docIds.add(new DocId(Integer.valueOf(documentIdList[i]).intValue()));
            }

            EdiRejectDocumentTaxSearchCriteria searchCriteria = new EdiRejectDocumentTaxSearchCriteria(
                    docIds);
            List<Document> taxDocuments = getEdiRejectDocumentTaxDao().findDocumentTaxes(
                    searchCriteria);

            // Result document collection as List<EdiTransactionHeader
            List<EdiTransactionHeader> ediTransactionHeadList = new ArrayList<EdiTransactionHeader>();            
            for (int i = 0; i < docHeadRow.length; i++) {
            	if (supplierSiteInd) {
            		supplier = 	orderBean.selectVendor(Integer.toString(docHeadRow[i].getOrderNo()));
            		supplierParent = supplierBean.getSupplierParent(supplier);
            		if (supplierParent != null) {
            			supplierSite = supplier;
            		}
            		else {
            			supplierSite = null;
            		}
            	}
                // Create EdiTransactionHeader document from row data
            	SmrEdiTransactionHeader transactionHeader = new SmrEdiTransactionHeader(new Long(
                        docHeadRow[i].getDocId()), docHeadRow[i].getType(), docHeadRow[i]
                        .getExtDocId(), docHeadRow[i].getVendorType(), docHeadRow[i].getVendor(),
                        new ReIMDate(docHeadRow[i].getDocDate()), new Long(docHeadRow[i]
                                .getOrderNo()), new Long(docHeadRow[i].getLocation()),
                        docHeadRow[i].getLocType(), docHeadRow[i].getTerms(), new Double(
                                docHeadRow[i].getTermsDscntPct()),
                        ((docHeadRow[i].getDueDate() == null) ? null : new ReIMDate(docHeadRow[i]
                                .getDueDate())), docHeadRow[i].getPaymentMethod(), docHeadRow[i]
                                .getCurrencyCode(), new Double(docHeadRow[i].getExchangeRate()),
                        docHeadRow[i].getTotalCost(), docHeadRow[i].getTotalQty(), docHeadRow[i]
                                .getTotalDiscount(), docHeadRow[i].getFreightType(), docHeadRow[i]
                                .getPaidInd(), docHeadRow[i].getMultiLoc(), ReIMConstants.NO, null,
                        null, ReIMConstants.NO, docHeadRow[i].getCustomDocRef1(), docHeadRow[i]
                                .getCustomDocRef2(), docHeadRow[i].getCustomDocRef3(),
                        docHeadRow[i].getCustomDocRef4(), null, // cross reference document number
                        null, // non merchandise cost list
                        null, // detail list
                        docHeadRow[i].getGroupId(),
                        supplierSite);                           	
            	
                // Append tax data to EdiTransactionHeader document
                List<EDIHeaderTax> ediTaxDetailsList = new ArrayList<EDIHeaderTax>();
                double totalTaxAmount = 0.0;
                for (Document taxDocument : taxDocuments) {
                  
                    if (taxDocument.getDocId() == docHeadRow[i].getDocId()) {
                        for (Tax tax : taxDocument.getTaxes()) {
                            EDIHeaderTax ediTaxDetails = new EDIHeaderTax();
                            ediTaxDetails
                                    .setTaxRule(new TaxRule(tax.getTaxCode(), tax.getTaxRate()));
                            ediTaxDetails.setTaxBasis(tax.getTaxBasis());
                            totalTaxAmount = totalTaxAmount + tax.getTaxBasis() * tax.getTaxRate() / 100;
                            ediTaxDetailsList.add(ediTaxDetails);
                        }
                    }
                }

                transactionHeader.setEDIHeaderTaxList((EDIHeaderTax[]) ediTaxDetailsList
                        .toArray(new EDIHeaderTax[0]));
               transactionHeader.setTotalTaxAmount(totalTaxAmount);
                ediTransactionHeadList.add(transactionHeader);
            }

            return ediTransactionHeadList;
        } catch (Exception e) {
            throw new DataAccessException(e);
        }
    }
    
    public IEdiRejectDocumentTaxDao getEdiRejectDocumentTaxDao() {
        return ediRejectDocumentTaxDao;
    }

    @Autowired
    public void setEdiRejectDocumentTaxDao(IEdiRejectDocumentTaxDao ediRejectDocumentTaxDao) {
        this.ediRejectDocumentTaxDao = ediRejectDocumentTaxDao;
    }
	
    /* SMR OLR ENH31 Inserted - START */
    public void insertSmrEdiRejectRecord(SmrEdiReportRecord smrEdiRejectRecord) {
    	Map<String, Object> params = new HashMap<String, Object>();

        Integer count = 0;
        params.put("VENDOR", smrEdiRejectRecord.getVendor());
        params.put("EXT_DOC_ID", smrEdiRejectRecord.getExtDocId());
        params.put("BATCH_ID", smrEdiRejectRecord.getBatchId());
        params.put("ERROR_CODE", smrEdiRejectRecord.getErrorCode());
        params.put("SKU", smrEdiRejectRecord.getSku());
        params.put("UPC", smrEdiRejectRecord.getUpc());
        params.put("UPLD_TIMESTAMP", smrEdiRejectRecord.getUpldTimeStamp());
        params.put("TOTAL_COST", smrEdiRejectRecord.getTotalCost());
        params.put("TOTAL_QTY", smrEdiRejectRecord.getTotalQty());

        count += getSimpleJdbcTemplate().update(INSERT_INTO_SMR_EDI_REJECT, params);

	}
    /* SMR OLR ENH31 Inserted - END */
}
