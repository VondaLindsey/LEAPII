package smr.retail.reim.services;

import org.springframework.transaction.annotation.Transactional;

import com.retek.reim.merch.utils.ReIMException;

@Transactional
public interface ISmrCostResService {

	/**
	 * Determines whether or not an RCA should be allowed to be executed for the provided parameters
	 * 
	 * @param orderNo
	 * @param location
	 * @param item
	 * @param unitCost
	 * @return true if allowed, otherwise false.
	 * @throws ReIMException Thrown if any exceptions are encountered which can be handled by the application.
	 */
	public boolean isRcaAllowed(final long orderNo, final long location, final String item, final double unitCost) 
			throws ReIMException;
}
