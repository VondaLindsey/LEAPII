package smr.retek.reim.ui.invoiceMaintenance;

import org.apache.struts.action.ActionForm;

public class SmrInvoiceMassCorrectionForm extends ActionForm {
	
	public static String OPERATION_RELEASE = "release";
	public static String OPERATION_HOLD = "hold";
	public static String OPERATION_DELETE = "delete";
	
	private String supplierLOV = null;
    private String supplierLOVDesc = null;
	
    private String poLOV = null;
    private String poLOVDesc = null;
    
    private String invoiceLOV = null;
    private String invoiceLOVDesc = null;
    
    private String operationRadio = null;
    
    private String oldDueDate = null;
    private String newDueDate = null;
    
    private String oldInvoiceDate = null;
    private String newInvoiceDate = null;
    
    private String oldItemLOV = null;
    private String newItemLOV = null;
    
    private String oldSupplierLOV = null;
    private String newSupplierLOV = null;
    
    private String oldInvoiceLOV = null;
    private String toInvoiceLOV = null;
    private String appendInvoice = null;
    
    private String oldTermsLOV = null;
    private String newTermsLOV = null;

    private String oldPOLOV = null;
    private String newPOLOV = null;
    
    public SmrInvoiceMassCorrectionForm() {
    	super();
    }

    public void resetMassCorrectionVariables() {
    	
    	this.supplierLOV = null;
    	this.supplierLOVDesc = null;
    	
    	this.poLOV = null;
        this.poLOVDesc = null;
        
        this.invoiceLOV = null;
        this.invoiceLOVDesc = null;
        
        this.operationRadio = null;
        
        this.oldDueDate = null;
        this.newDueDate = null;
        
        this.oldInvoiceDate = null;
        this.newInvoiceDate = null;
        
        this.oldItemLOV = null;
        this.newItemLOV = null;
        
        this.oldSupplierLOV = null;
        this.newSupplierLOV = null;
        
        this.oldInvoiceLOV = null;
        this.toInvoiceLOV = null;
        this.appendInvoice = null;
        
        this.oldTermsLOV = null;
        this.newTermsLOV = null;
        
        this.oldPOLOV = null;
        this.newPOLOV = null;
        
    }

    public String getSupplierLOV() {
        return supplierLOV;
    }
    
    public void setSupplierLOV(String vendorLOV) {
        this.supplierLOV = vendorLOV;
    }
    
    public String getSupplierLOVDesc() {
        return supplierLOVDesc;
    }

    public void setSupplierLOVDesc(String supplierLOVDesc) {
        this.supplierLOVDesc = supplierLOVDesc;
    }

    public String getPoLOV() {
    	return this.poLOV;
    }
    
    public void setPoLOV(String poLOV) {
    	this.poLOV = poLOV;
    }
    
    public String getPoLOVDesc() {
    	return this.poLOVDesc;
    }

    public void setPoLOVDesc(String poLOVDesc) {
    	this.poLOVDesc = poLOVDesc;
    }

    public String getInvoiceLOV() {
    	return this.invoiceLOV;
    }
    
    public void setInvoiceLOV(String invoiceLOV) {
    	this.invoiceLOV = invoiceLOV;
    }
    
    public String getInvoiceLOVDesc() {
    	return this.invoiceLOVDesc;
    }

    public void setInvoiceLOVDesc(String invoiceLOVDesc) {
    	this.invoiceLOVDesc = invoiceLOVDesc;
    }

	public String getOperationRadio() {
		return operationRadio;
	}

	public void setOperationRadio(String operationRadio) {
		this.operationRadio = operationRadio;
	}

	public String getOldDueDate() {
		return oldDueDate;
	}

	public void setOldDueDate(String oldDueDate) {
		this.oldDueDate = oldDueDate;
	}

	public String getNewDueDate() {
		return newDueDate;
	}

	public void setNewDueDate(String newDueDate) {
		this.newDueDate = newDueDate;
	}
	
	public String getOldInvoiceDate() {
		return oldInvoiceDate;
	}

	public void setOldInvoiceDate(String oldInvoiceDate) {
		this.oldInvoiceDate = oldInvoiceDate;
	}

	public String getNewInvoiceDate() {
		return newInvoiceDate;
	}

	public void setNewInvoiceDate(String newInvoiceDate) {
		this.newInvoiceDate = newInvoiceDate;
	}

	public String getOldItemLOV() {
		return oldItemLOV;
	}

	public void setOldItemLOV(String oldItemLOV) {
		this.oldItemLOV = oldItemLOV;
	}

	public String getNewItemLOV() {
		return newItemLOV;
	}

	public void setNewItemLOV(String newItemLOV) {
		this.newItemLOV = newItemLOV;
	}

	public String getOldSupplierLOV() {
		return oldSupplierLOV;
	}

	public void setOldSupplierLOV(String oldSupplierLOV) {
		this.oldSupplierLOV = oldSupplierLOV;
	}

	public String getNewSupplierLOV() {
		return newSupplierLOV;
	}

	public void setNewSupplierLOV(String newSupplierLOV) {
		this.newSupplierLOV = newSupplierLOV;
	}

	public String getOldInvoiceLOV() {
		return oldInvoiceLOV;
	}

	public void setOldInvoiceLOV(String oldInvoiceLOV) {
		this.oldInvoiceLOV = oldInvoiceLOV;
	}
	
	public String getToInvoiceLOV() {
		return toInvoiceLOV;
	}

	public void setToInvoiceLOV(String toInvoiceLOV) {
		this.toInvoiceLOV = toInvoiceLOV;
	}
	
    public String getAppendInvoice() {
	        return appendInvoice;
	}
	
	public void setAppendInvoice(String appendInvoice) {
	        this.appendInvoice = appendInvoice;
	}

	public String getOldTermsLOV() {
		return oldTermsLOV;
	}

	public void setOldTermsLOV(String oldTermsLOV) {
		this.oldTermsLOV = oldTermsLOV;
	}

	public String getNewTermsLOV() {
		return newTermsLOV;
	}

	public void setNewTermsLOV(String newTermsLOV) {
		this.newTermsLOV = newTermsLOV;
	}

	public String getOldPOLOV() {
		return oldPOLOV;
	}

	public void setOldPOLOV(String oldPOLOV) {
		this.oldPOLOV = oldPOLOV;
	}

	public String getNewPOLOV() {
		return newPOLOV;
	}

	public void setNewPOLOV(String newPOLOV) {
		this.newPOLOV = newPOLOV;
	}
	
}
