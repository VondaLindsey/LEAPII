package smr.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.Item;
import com.retek.reim.business.document.Document;
import com.retek.reim.db.ImInvoiceDetailAccess;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;

public class SmrImInvoiceDetailAccessExt extends ImInvoiceDetailAccess {
	
    public static Item[] getDistinctItems(String supplierId, String orderNo, String invoiceId, String itemId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        StringBuffer query = new StringBuffer("SELECT DISTINCT ITM.ITEM, ITM.ITEM_DESC FROM IM_DOC_HEAD HEAD, IM_INVOICE_DETAIL DETAIL, ITEM_MASTER ITM WHERE HEAD.DOC_ID = DETAIL.DOC_ID AND HEAD.VENDOR_TYPE = 'SUPP' AND ITM.ITEM = DETAIL.ITEM ");
        query.append(" AND HEAD.STATUS = '" +Document.READY_FOR_MATCH +"' AND  HEAD.TYPE = '" +Document.MERCHANDISE_INVOICE +"'");
        
        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (supplierId != null && !supplierId.equals("")) query.append("   AND HEAD.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
            if (orderNo != null && !orderNo.equals("")) query.append("   AND HEAD.ORDER_NO = ?");
            if (invoiceId != null && !invoiceId.equals("")) query.append("   AND HEAD.EXT_DOC_ID = ?");
            if (itemId != null && !itemId.equals("")) query.append("   AND DETAIL.ITEM = ?");
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
            if (supplierId != null && !supplierId.equals("")) {
            	stmt.setString(ind++, supplierId);
            	stmt.setString(ind++, supplierId);
            }
            if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
            if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
            if (itemId != null && !itemId.equals("")) stmt.setString(ind++, itemId);
            
            rs = stmt.executeQuery();
            ArrayList itemList = new ArrayList();
            Item item = null;
            while (rs.next()) {
                item = new Item();
                item.setItemId(rs.getString("ITEM"));
                item.setItemName(rs.getString("ITEM_DESC"));
                itemList.add(item);
            }
            if (itemList.size() > 0) {
                return (Item[]) itemList.toArray(new Item[itemList.size()]);
            } else {
                return null;
            }

        } catch (SQLException ex) {
            String exMsg = "Bind variables: supplierId: " + supplierId + ", orderNo: " + orderNo + ", invoiceId: " + invoiceId;
            throw new ReIMException("SMR.query_error", Severity.ERROR, ex, null, new String[] { exMsg});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set", Severity.ERROR, ex, (Object) null);
            }
        }
    }
    
    
    public int replace(String supplier, String orderNo, String invoiceId, String oldItem, String newItem, int updatedInvoicesCount)
    throws ReIMException {
    	
    	OraclePreparedStatement stmt = null;
    	try {
    		
    			StringBuffer updatePart = new StringBuffer("UPDATE IM_INVOICE_DETAIL SET ITEM = ?, LAST_UPDATE_ID = ? WHERE ITEM = ? AND DOC_ID IN (");
    			
    			StringBuffer selectPart = new StringBuffer("SELECT DOC_ID FROM IM_DOC_HEAD HEAD WHERE HEAD.VENDOR_TYPE = 'SUPP'");
    			selectPart.append(" AND HEAD.STATUS = '" +Document.READY_FOR_MATCH +"' AND  HEAD.TYPE = '" +Document.MERCHANDISE_INVOICE +"'");
	    		
				if (supplier != null && !supplier.equals("")) selectPart.append("   AND HEAD.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
				if (orderNo != null && !orderNo.equals("")) selectPart.append("   AND HEAD.ORDER_NO = ?");
				if (invoiceId != null && !invoiceId.equals("")) selectPart.append("   AND HEAD.EXT_DOC_ID = ?");
				
				String endPart = new String(")");
				
	    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
	    		stmt = (OraclePreparedStatement) conn.prepareStatement(updatePart.toString() + selectPart.toString() + endPart);
	    		
				int ind = 1;
	    		stmt.setString(ind++, newItem);
	    		stmt.setString(ind++, ReIMUserContext.getUsername());
	    		stmt.setString(ind++, oldItem);
				if (supplier != null && !supplier.equals("")) {
					stmt.setString(ind++, supplier);
					stmt.setString(ind++, supplier);
				}
				if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
				if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
	
				updatedInvoicesCount = stmt.executeUpdate();
				
				return updatedInvoicesCount;
    	    		
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    	} finally {
    		try {
    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    		}
    	}
    }
    public void updateSubItem(long docId,
                              String invItem, String rcptItem) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            TransactionManagerFactory.getInstance().start();
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement("UPDATE IM_INVOICE_DETAIL "
                    + " SET ITEM = ?,  " + " LAST_UPDATE_ID = ?,  "
                    + " LAST_UPDATE_DATETIME = ?  " 
                    + "  WHERE  DOC_ID = ?  "
                    + "    AND ITEM =  ? " 
                    + "    AND NOT EXISTS (SELECT 1 "
                    + "                       FROM IM_INVOICE_DETAIL"
                    +  "                     WHERE DOC_ID = ? "
                    +  "                       AND ITEM = ? )");

    //            stmt.setDouble(1, costVarianceWithinTolerance);
              stmt.setString(1, rcptItem );
              stmt.setString(2, ReIMUserContext.getUsername());
              stmt.setTimestamp(3, new ReIMDate().getTimestamp());
              stmt.setLong(4, docId);
              stmt.setString(5, invItem);
              stmt.setLong(6, docId);
              stmt.setString(7, rcptItem);

            stmt.executeUpdate();
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) stmt.close();
                TransactionManagerFactory.getInstance().end();
            } catch (SQLException e) {
                TransactionManagerFactory.getInstance().rollback();
                throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                        Severity.ERROR, e, this);
            }
        }
    }
    public void updShipQty(long docId, String receiptId,
                              String invItem, String rcptItem) throws ReIMException {
        OraclePreparedStatement stmt = null;

        try {
            TransactionManagerFactory.getInstance().start();
            Connection conn = TransactionManagerFactory.getInstance().getConnection();

            stmt = (OraclePreparedStatement) conn.prepareStatement("update shipsku\n" + 
            "   set qty_matched = (select case when ss.qty_matched is null then\n" + 
            "                                      null\n" + 
            "                                  when (IID.RESOLUTION_ADJUSTED_QTY <> SS.QTY_MATCHED \n" + 
            "                                          and ss.qty_received = ss.qty_matched) then\n" + 
            "                                       ss.qty_expected - ss.qty_received\n" + 
            "                                  when (IID.RESOLUTION_ADJUSTED_QTY = SS.QTY_MATCHED \n" + 
            "                                          and ss.qty_received = ss.qty_matched) then\n" + 
            "                                       ss.qty_expected - ss.qty_received\n" + 
            "                             end\n" + 
            "                        from shipsku ss,\n" + 
            "                             im_invoice_detail iid\n" + 
            "                        where ss.shipment = ? \n" + 
            "                           and iid.item = ss.item\n" + 
            "                           and iid.doc_id = ? \n" + 
            "                           and ss.item = ? )\n" + 
            " where shipment = ? \n" + 
            "   and item = ? ");

    //            stmt.setDouble(1, costVarianceWithinTolerance);
              stmt.setString(1, receiptId );
              stmt.setLong(2, docId);
               stmt.setString(3, rcptItem );
              stmt.setString(4, receiptId);
              stmt.setString(5, rcptItem);

            stmt.executeUpdate();
        } catch (Exception e) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                    Severity.ERROR, e, this);
        } finally {
            try {
                if (stmt != null) stmt.close();
                TransactionManagerFactory.getInstance().end();
            } catch (SQLException e) {
                TransactionManagerFactory.getInstance().rollback();
                throw new ReIMException("error.cannot_update_cost_variance_within_tolerance",
                        Severity.ERROR, e, this);
            }
        }
    }

}
