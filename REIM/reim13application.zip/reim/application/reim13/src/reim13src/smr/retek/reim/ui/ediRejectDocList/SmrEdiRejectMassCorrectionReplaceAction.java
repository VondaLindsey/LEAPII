package smr.retek.reim.ui.ediRejectDocList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.retail.reim.utils.Severity;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import smr.retail.reim.services.ISmrEdiRejectService;
import smr.retek.reim.services.SmrServiceFactory;

import com.retek.reim.business.EdiDocumentValidationValues;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.EdiRejectService;

public class SmrEdiRejectMassCorrectionReplaceAction extends ReIMSecureAction {
	
    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm actionForm,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        SmrEdiRejectMassCorrectionForm form = (SmrEdiRejectMassCorrectionForm) actionForm;
        EdiDocumentValidationValues ediDocumentValidationValues = new EdiDocumentValidationValues();

        try {
            String oldValue = null;
            String newValue = null;
            String newItemSupplement = null; 
            // Implement the mass change and re-validate the affected rejected documents
             
            ediDocumentValidationValues = SmrServiceFactory.getSmrEdiRejectService().replaceElementAndRevalidate(form.getSupplierLOV(), form.getPoLOV(), form.getInvoiceLOV(),
            		form.getOperationRadio(), form.getOldDueDate(), form.getNewDueDate(), form.getOldItemLOV(), form.getNewItemLOV(), form.getOldSupplierLOV(), form.getNewSupplierLOV(),
            		form.getOldInvoiceLOV(), form.getToInvoiceLOV(), form.getAppendInvoice(),  form.getOldTermsLOV(), form.getNewTermsLOV(), form.getOldPOLOV(), form.getNewPOLOV(),
            		form.getNewDocDate() , ReIMUserContext.getUsername());
            if (ediDocumentValidationValues.getMessageCode() == EdiRejectService.UNABLE_TO_REPLACE_DOCUMENTS_LOCKED) {
                saveErrors(request, errors, "alert.unable_to_replace_documents_tables_locked");
                return mapping.findForward("self");
            } else if (ediDocumentValidationValues.getMessageCode() == EdiRejectService.NO_DOCUMENTS_WERE_AFFECTED) {
                saveErrors(request, errors, "alert.unable_to_replace_documents_none_affected");
                return mapping.findForward("self");
            } else {
                errors.add("alert.edi_documents_updated_and_revalidated",
                        new ActionError("alert.edi_documents_updated_and_revalidated", String
                                .valueOf(ediDocumentValidationValues.getValidDocumentCount()),
                                String.valueOf(ediDocumentValidationValues
                                        .getRejectToTableDocumentCount())));
                saveErrors(request, errors);
                return mapping.findForward("success");
            }
        } catch (ReIMException e) {
            saveErrors(request, errors, e);
            return (mapping.findForward("failure"));
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.EdiRejectMassCorrectionReplaceAction_doPerform", Severity.ERROR, e,
                    this);
            saveErrors(request, errors, exception);
            return (mapping.findForward("failure"));
        }
    }

}

