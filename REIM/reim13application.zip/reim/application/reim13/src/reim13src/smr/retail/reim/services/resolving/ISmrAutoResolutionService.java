package smr.retail.reim.services.resolving;

import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import smr.retek.reim.business.SmrAutoResolutionCandidate;

@Transactional
public interface ISmrAutoResolutionService {
	
	public Map<String, SmrAutoResolutionCandidate> getAutoResolutionCandidates();
	
	public int processResolutionCandidates(Map<String, SmrAutoResolutionCandidate> resolutionCandidates)  throws Exception ;
	
}
