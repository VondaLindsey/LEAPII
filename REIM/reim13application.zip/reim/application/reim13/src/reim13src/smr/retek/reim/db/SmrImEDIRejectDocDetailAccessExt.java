package smr.retek.reim.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.OraclePreparedStatement;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;

import com.retek.reim.business.Item;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;

public class SmrImEDIRejectDocDetailAccessExt {

    public static Item[] getDistinctItems(String supplierId, String orderNo, String invoiceId, String itemId) throws ReIMException {
        OraclePreparedStatement stmt = null;
        ResultSet rs = null;
        StringBuffer query = new StringBuffer("SELECT DISTINCT ITM.ITEM, ITM.ITEM_DESC FROM IM_EDI_REJECT_DOC_HEAD HEAD, IM_EDI_REJECT_DOC_DETAIL DETAIL, ITEM_MASTER ITM WHERE HEAD.DOC_ID = DETAIL.DOC_ID AND HEAD.VENDOR_TYPE = 'SUPP' AND ITM.ITEM = DETAIL.ITEM");

        try {
            Connection conn = TransactionManagerFactory.getInstance().getConnection();
            if (supplierId != null && !supplierId.equals("")) query.append("   AND HEAD.VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
            if (orderNo != null && !orderNo.equals("")) query.append("   AND HEAD.ORDER_NO = ?");
            if (invoiceId != null && !invoiceId.equals("")) query.append("   AND HEAD.EXT_DOC_ID = ?");
            if (itemId != null && !itemId.equals("")) query.append("   AND DETAIL.ITEM = ?");
            stmt = (OraclePreparedStatement) conn.prepareStatement(query.toString());
			int ind = 1;
            if (supplierId != null && !supplierId.equals("")) {
            	stmt.setString(ind++, supplierId);
            	stmt.setString(ind++, supplierId);
            }
            if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
            if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);
            if (itemId != null && !itemId.equals("")) stmt.setString(ind++, itemId);
            
            rs = stmt.executeQuery();
            ArrayList itemList = new ArrayList();
            Item item = null;
            while (rs.next()) {
                item = new Item();
                item.setItemId(rs.getString("ITEM"));
                item.setItemName(rs.getString("ITEM_DESC"));
                itemList.add(item);
            }
            if (itemList.size() > 0) {
                return (Item[]) itemList.toArray(new Item[itemList.size()]);
            } else {
                return null;
            }

        } catch (SQLException ex) {
            String exMsg = "Bind variables: supplierId: " + supplierId + ", orderNo: " + orderNo + ", invoiceId: " + invoiceId;
            throw new ReIMException("SMR.query_error", Severity.ERROR, ex, null, new String[] { exMsg});
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                throw new ReIMException("DALGen.cannot_close_statement_or_result_set", Severity.ERROR, ex, (Object) null);
            }
        }
    }
    
    
    public void replace(String supplier, String orderNo, String invoiceId, String oldItem, String newItem)
    throws ReIMException {
    	if (oldItem == null || oldItem.equals("")) return;
    	OraclePreparedStatement stmt = null;
    	try {
    		StringBuffer update = new StringBuffer("UPDATE IM_EDI_REJECT_DOC_DETAIL SET ITEM = ?, UPDATE_ID = ? WHERE ITEM = ? AND DOC_ID IN (");
    		update.append("SELECT DOC_ID FROM IM_EDI_REJECT_DOC_HEAD WHERE VENDOR_TYPE = 'SUPP'");
			if (supplier != null && !supplier.equals("")) update.append("   AND VENDOR IN (SELECT SUPPLIER FROM SUPS WHERE SUPPLIER = ? UNION SELECT SUPPLIER_PARENT FROM SUPS WHERE SUPPLIER = ?)");
			if (orderNo != null && !orderNo.equals("")) update.append("   AND ORDER_NO = ?");
			if (invoiceId != null && !invoiceId.equals("")) update.append("   AND EXT_DOC_ID = ?");
			update.append(")");
    		Connection conn = TransactionManagerFactory.getInstance().getConnection();
    		stmt = (OraclePreparedStatement) conn.prepareStatement(update.toString());
			int ind = 1;
    		stmt.setString(ind++, newItem);
    		stmt.setString(ind++, ReIMUserContext.getUsername());
    		stmt.setString(ind++, oldItem);
			if (supplier != null && !supplier.equals("")) {
				stmt.setString(ind++, supplier);
				stmt.setString(ind++, supplier);
			}
			if (orderNo != null && !orderNo.equals("")) stmt.setString(ind++, orderNo);
			if (invoiceId != null && !invoiceId.equals("")) stmt.setString(ind++, invoiceId);

    		stmt.executeUpdate();
    	} catch (Exception exception) {
    		throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    	} finally {
    		try {
    			if (stmt != null) {
    				stmt.close();
    			}
    		} catch (SQLException exception) {
    			throw new ReIMException("error.sql_error", Severity.ERROR, exception, this);
    		}
    	}
    }

}
