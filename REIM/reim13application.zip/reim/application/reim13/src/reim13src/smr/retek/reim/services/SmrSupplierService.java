package smr.retek.reim.services;

import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.utils.Severity;
import smr.retek.reim.foundation.SmrSupplierBean;

import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.services.SupplierService;

public class SmrSupplierService extends SupplierService {
    public boolean isSupplierInvoiceAtSDCLevel(String supplier) throws ReIMException {
        try {
            SmrSupplierBean supplierBean = new SmrSupplierBean();

            TransactionManagerFactory.getInstance().start();

            return supplierBean.isSupplierInvoiceAtSDCLevel(supplier);
        } catch (ReIMException e) {
            throw (e);
        } catch (Exception ex) {
            throw new ReIMException("error.SupplierService.invoiceLevel", Severity.ERROR, ex,
                    SupplierService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }


}
