package smr.retek.reim.ui.invoiceMaintenance;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;

public class SmrInvoiceMassCorrectionRefreshAction extends ReIMSecureAction {
    protected boolean getPermission() {
        return true;
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws ReIMException {
        ActionErrors errors = new ActionErrors();

        {
            return mapping.findForward("success");
        }
    }
}