package smr.retek.reim.ui.invoiceMaintenance;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.retek.reim.business.UserRole;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMSecureAction;
import oracle.retail.reim.utils.Severity;
import com.retek.reim.merch.utils.ReIMUserContext;

public class SmrInvoiceMassCorrectionAction extends ReIMSecureAction {
    protected boolean getPermission() {
        if (ReIMUserContext.getUserRole().getInvoiceEntry().equalsIgnoreCase(UserRole.EDIT)) {
            return true;
        } else {
            return false;
        }
    }

    public ActionForward doPerform(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) {
        ActionErrors errors = new ActionErrors();
        SmrInvoiceMassCorrectionForm invoiceMassCorrectionForm = (SmrInvoiceMassCorrectionForm) form;
                        
        try {
        	invoiceMassCorrectionForm.resetMassCorrectionVariables();
            return mapping.findForward("success");
        } catch (Exception e) {
            ReIMException exception = new ReIMException(
                    "error.SmrInvoiceMassCorrectionReplaceAction_doPerform", Severity.ERROR, e, this);
            saveErrors(request, errors, exception);
            return (mapping.findForward("failure"));
        }
    }
}
