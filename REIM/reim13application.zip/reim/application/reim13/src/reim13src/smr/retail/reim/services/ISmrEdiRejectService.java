package smr.retail.reim.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;

import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.business.EdiDocumentValidationValues;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.ui.lov.IKeyValue;

@Transactional
public interface ISmrEdiRejectService {
	
	public IKeyValue[] selectInvoices(String supplierId, String orderNo, String invoiceIdFromFilter, String invoiceIdFromUser) throws ReIMException;
        
        public IKeyValue[] selectToInvoices(String supplierId, String orderNo, String invoiceIdFromFilter, String invoiceIdFromUser, String invoiceIdToFilter) throws ReIMException;
    
	public IKeyValue[] selectSmrEdiItems(String supplierId, String orderNo, String invoiceId, String itemId) throws ReIMException;
	
	public IKeyValue[] getSmrEdiTerms(String supplierId, String orderNo, String invoiceId, String termsId) throws ReIMException;

	public IKeyValue[] getSmrEdiOrders(String supplierId, String orderNoFromFilter, String invoiceId, String orderNoFromUser) throws ReIMException;

	public IKeyValue[] getSmrEdiSupplierSitesFilter(String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException;

	public IKeyValue[] getSmrEdiSupplierSites(String supplierSiteIdFromFilter, String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException;
        
    public EdiDocumentValidationValues replaceElementAndRevalidate(String supplierId, String orderNo, String invoiceId,
    		String operationRadio, String oldDueDate, String newDueDate, String oldItem, String newItem, String oldSupplierId, String newSupplierId,
    		String oldInvoiceId, String newInvoiceId,String appendInvoice, String oldTermsId, String newTermsId, String oldOrderNo, String newOrderNo,
    		String newdocDate, String userId) throws ReIMException;

    public String[] getDocIds(String supplierId, String orderNo, String invoiceId) throws ReIMException;
    
    public void replaceElement(String supplierId, String orderNo, String invoiceId,
    		String oldDueDate, String newDueDate, String oldItem, String newItem, String oldSupplierId, String newSupplierId,
    		String oldInvoiceId, String newInvoiceId, String appendInvoice, String oldTermsId, String newTermsId, String oldOrderNo,
                String newOrderNo, String newDocDate) throws ReIMException;

    public List<EdiTransactionHeader> buildEdiDocumentsFromRejected(String[] documentIdList) throws ReIMException;
    
    public boolean massDeleteRejects(String supplierId, String orderNo, String invoiceId, String userId) throws ReIMException;
    
    public boolean rejectTrueDuplicates(String extDocId, String orderNo, Double totalCost, String vendor)  throws ReIMException ;
    
    public boolean validateOrder(String orderNo)  throws ReIMException ;
    
    public boolean softDuplicates(String extDocId, String orderNo, Double totalCost, String vendor)  throws ReIMException ;
   
    public void updateRejectHeadRejectReason(long docId, String errorColumnId, String rejectReason) throws ReIMException;

    public void insertSmrEdiRejectRecord(SmrEdiReportRecord smrEdiRejectRecord) throws ReIMException; // SMR OLR ENH31 Inserted
}
