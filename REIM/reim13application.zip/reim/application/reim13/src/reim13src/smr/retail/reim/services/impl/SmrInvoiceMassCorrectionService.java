package smr.retail.reim.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import oracle.retail.reim.business.Supplier;

import oracle.retail.reim.business.tax.Tax;
import oracle.retail.reim.data.TransactionManagerFactory;
import oracle.retail.reim.data.dao.IEdiRejectDocumentDao;
import oracle.retail.reim.services.impl.EdiRejectService;
import oracle.retail.reim.utils.Severity;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import smr.retail.reim.business.SmrMerchandiseDocument;
import smr.retail.reim.data.dao.ISmrEdiRejectDocumentDao;
import smr.retail.reim.services.ISmrInvoiceMassCorrectionService;
import smr.retek.reim.batch.ediupinv.SmrEdiReportRecord;
import smr.retek.reim.db.SmrImDocHeadAccessExt;
import smr.retek.reim.db.SmrImInvoiceDetailAccessExt;

import com.retek.reim.business.EdiDocumentValidationValues;
import com.retek.reim.business.Item;
import com.retek.reim.business.Order;
import com.retek.reim.business.Term;
import com.retek.reim.business.document.Document;
import com.retek.reim.db.ImEDIRejectDocHeadRow;
import com.retek.reim.locking.LockingData;
import com.retek.reim.locking.LockingUtils;
import com.retek.reim.merch.utils.ReIMDate;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.ReIMUserContext;
import com.retek.reim.services.ITermsService;
import com.retek.reim.services.ServiceFactory;
import com.retek.reim.ui.lov.DocumentLOV;
import com.retek.reim.ui.lov.IKeyValue;
import com.retek.reim.ui.lov.ItemLOV;
import com.retek.reim.ui.lov.OrderLOV;
import com.retek.reim.ui.lov.SupplierSiteLOV;
import com.retek.reim.ui.lov.TermLOV;

@Service
public class SmrInvoiceMassCorrectionService implements ISmrInvoiceMassCorrectionService {

	private oracle.retail.reim.services.IEdiRejectService ediRejectService;
	private ISmrEdiRejectDocumentDao smrEdiRejectDocumentDao;
    private IEdiRejectDocumentDao ediRejectDocumentDao;
    private ITermsService termsService;

	public IKeyValue[] selectInvoices(String supplierId, String orderNo, String invoiceIdFromFilter, String invoiceIdFromUser) throws ReIMException {
		try {
			if (invoiceIdFromFilter != null && !invoiceIdFromFilter.equals("") &&
				invoiceIdFromUser != null && !invoiceIdFromUser.equals("") && !invoiceIdFromFilter.equals(invoiceIdFromUser)) return null;
			String invoiceId = (invoiceIdFromFilter == null || "".equals(invoiceIdFromFilter)) ? invoiceIdFromUser : invoiceIdFromFilter;

			Document[] docs = SmrImDocHeadAccessExt.selectDistinctInvoices(supplierId, orderNo, invoiceId);
			if (docs != null) {
				ArrayList<DocumentLOV> lovList = new ArrayList<DocumentLOV>();
				for (Document doc : docs) {
					lovList.add(new DocumentLOV(doc.getExtDocId(), doc.getOrderNo()));
				}
				return lovList.toArray(new DocumentLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.selectInvoices", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}

	public IKeyValue[] selectSmrInvoiceItems(String supplierId, String orderNo, String invoiceId, String itemId) throws ReIMException {
		try {
			Item[] items = SmrImInvoiceDetailAccessExt.getDistinctItems(supplierId, orderNo, invoiceId, itemId);
			if (items != null) {
				ArrayList<ItemLOV> lovList = new ArrayList<ItemLOV>();
				if (items != null) {
					for (Item item : items) {
						lovList.add(new ItemLOV(item.getItemId(), item.getItemName()));
					}
				}
				return lovList.toArray(new ItemLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.getSmrEdiItems", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}

	public IKeyValue[] getSmrInvoiceTerms(String supplierId, String orderNo, String invoiceId, String termsId) throws ReIMException {
		try {
			Term[] terms = SmrImDocHeadAccessExt.selectDistinctTerms(supplierId, orderNo, invoiceId, termsId);
			if (terms != null) {
				ArrayList<TermLOV> lovList = new ArrayList<TermLOV>();
				if (terms != null) {
					for (Term term : terms) {
						lovList.add(new TermLOV(term.getTermId(), term.getCode(), term.getTermDescription()));
					}
				}
				return lovList.toArray(new TermLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.getSmrEdiTerms", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}

	public IKeyValue[] getSmrInvoiceOrders(String supplierId, String orderNoFromFilter, String invoiceId, String orderNoFromUser) throws ReIMException {
		try {
			if (orderNoFromFilter != null && !orderNoFromFilter.equals("") &&
					orderNoFromUser != null && !orderNoFromUser.equals("") && !orderNoFromFilter.equals(orderNoFromUser)) return null;
			String orderNo = (orderNoFromFilter == null || "".equals(orderNoFromFilter)) ? orderNoFromUser : orderNoFromFilter;

			Order[] orders = SmrImDocHeadAccessExt.selectDistinctOrders(supplierId, orderNo, invoiceId);
			if (orders != null) {
				ArrayList<OrderLOV> lovList = new ArrayList<OrderLOV>();
				if (orders != null) {
					for (Order order : orders) {
						lovList.add(new OrderLOV(order.getOrderNo(), order.getSupplierId(), order.getOrderCurrency()));
					}
				}
				return lovList.toArray(new OrderLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.getSmrEdiOrders", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}


	public IKeyValue[] getSmrInvoiceSupplierSitesFilter(String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException {
		try {
			Supplier[] suppliers = SmrImDocHeadAccessExt.selectDistinctSupplierSitesFilter(orderNo, invoiceId, supplierSiteIdFromUser);
			if (suppliers != null) {
				ArrayList<SupplierSiteLOV> lovList = new ArrayList<SupplierSiteLOV>();
				if (suppliers != null) {
					for (Supplier supplier : suppliers) {
						lovList.add(new SupplierSiteLOV(supplier.getVendorId(), supplier.getVendorName()));
					}
				}
				return lovList.toArray(new SupplierSiteLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.getSmrEdiSupplierSites", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}

	public IKeyValue[] getSmrInvoiceSupplierSites(String supplierSiteIdFromFilter, String orderNo, String invoiceId, String supplierSiteIdFromUser) throws ReIMException {
		try {
			if (supplierSiteIdFromFilter != null && !supplierSiteIdFromFilter.equals("") &&
					supplierSiteIdFromUser != null && !supplierSiteIdFromUser.equals("") && !supplierSiteIdFromFilter.equals(supplierSiteIdFromUser)) return null;
			String supplierId = (supplierSiteIdFromFilter == null || "".equals(supplierSiteIdFromFilter)) ? supplierSiteIdFromUser : supplierSiteIdFromFilter;
			Supplier[] suppliers = SmrImDocHeadAccessExt.selectInvoiceSupplierSites(supplierId, orderNo, invoiceId);
			if (suppliers != null) {
				ArrayList<SupplierSiteLOV> lovList = new ArrayList<SupplierSiteLOV>();
				if (suppliers != null) {
					for (Supplier supplier : suppliers) {
						lovList.add(new SupplierSiteLOV(supplier.getVendorId(), supplier.getVendorName()));
					}
				}
				return lovList.toArray(new SupplierSiteLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.getSmrEdiSupplierSites", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}

	public IKeyValue[] getDistinctSupplierSites(String supplierSiteIdFromFilter, String orderNo, String supplierSiteIdFromUser) throws ReIMException {
		try {
			if (supplierSiteIdFromFilter != null && !supplierSiteIdFromFilter.equals("") &&
					supplierSiteIdFromUser != null && !supplierSiteIdFromUser.equals("") && !supplierSiteIdFromFilter.equals(supplierSiteIdFromUser)) return null;
			String supplierId = (supplierSiteIdFromFilter == null || "".equals(supplierSiteIdFromFilter)) ? supplierSiteIdFromUser : supplierSiteIdFromFilter;
			Supplier[] suppliers = SmrImDocHeadAccessExt.selectDistinctSupplierSites(supplierId, orderNo);
			if (suppliers != null) {
				ArrayList<SupplierSiteLOV> lovList = new ArrayList<SupplierSiteLOV>();
				if (suppliers != null) {
					for (Supplier supplier : suppliers) {
						lovList.add(new SupplierSiteLOV(supplier.getVendorId(), supplier.getVendorName()));
					}
				}
				return lovList.toArray(new SupplierSiteLOV[lovList.size()]);
			} else {
				return null;
			}
		} catch (Exception ex) {
			throw new ReIMException("error.SmrEdiRejectService.getSmrEdiSupplierSites", Severity.ERROR, ex,
					EdiRejectService.class);
		}
	}

    public EdiDocumentValidationValues replaceElementAndRevalidate(SmrMerchandiseDocument smrMerchandiseDocument) throws ReIMException {

    	EdiDocumentValidationValues ediDocumentValidationValues = new EdiDocumentValidationValues();
    	int  updatedInvoicesCount = 0;      
        String existingUserId;

        try {
            TransactionManagerFactory.getInstance().start();
            String[] docIdStrings = getDocIds(smrMerchandiseDocument.getSupplierId(), smrMerchandiseDocument.getOrderNo(), 
            		smrMerchandiseDocument.getInvoiceId(), smrMerchandiseDocument.getFromInvoiceId(), smrMerchandiseDocument.getToInvoiceLOV());

            if (docIdStrings != null) {
                Long[] docIdLongs = new Long[docIdStrings.length];
                long[] docIds = new long[docIdStrings.length];
                for (int i=0 ; i<docIdStrings.length ; i++) {
                	docIdLongs[i] = new Long(docIdStrings[i]);
                	docIds[i] = docIdLongs[i].longValue();
                }
                for (Long docId : docIdLongs) {
                    // Lock all of the affected documents
                	existingUserId = getDocLockUserId(docId);

                    if (existingUserId != null && !existingUserId.equalsIgnoreCase(smrMerchandiseDocument.getUserId())) {
                        ediDocumentValidationValues.setAllDocumentsValid(false);
                        ediDocumentValidationValues.setValidDocumentCount(0);
                        ediDocumentValidationValues
                                .setMessageCode(EdiRejectService.UNABLE_TO_REPLACE_DOCUMENTS_LOCKED);
                        return ediDocumentValidationValues;
                    }
                }

                //for (Long docId : docIdLongs) {
                lockDocHead(docIds, smrMerchandiseDocument.getUserId());
                //}
                
                
                if (smrMerchandiseDocument.validateUpdateInvoiceHead()){
                	SmrImDocHeadAccessExt  smrImDocHeadAccessExt = new SmrImDocHeadAccessExt();
                	
                	String[] docIdsUpdated = smrImDocHeadAccessExt.replace(smrMerchandiseDocument); 
                	                	
                	if(docIdsUpdated != null){
                		updatedInvoicesCount = docIdsUpdated.length;
                	
                		String newDueDate = smrMerchandiseDocument.getNewDueDate();
                		String newInvoiceDate = smrMerchandiseDocument.getNewInvoiceDate();
                		//If the Due Date is entered then Due Date calculation logic is not required, it is already replaced in above lines.
            			//Due Date needs to be calculated when either newInvoiceDae is entered OR newTerms is entered OR both are entered                		
                		if ((newDueDate == null || newDueDate.equals("")) && ( (newInvoiceDate != null && !newInvoiceDate.equals("")) ||
                				smrMerchandiseDocument.validateUpdateInvoiceTerms() )){
                			                			
                			
                			//Map<String, String> invoiceTermsMap = new HashMap<String, String>(docIdStrings.length);
                			HashMap<String, String> invoiceDueDatesMap = new HashMap<String, String>();

	                		//If the new invoice date is provided in the mass correction then the due date will be calculated based on new invoice date and new terms.
            				//Else, the invoice date is retrieved from database for each invoice.
                			Map<String, String> invoiceDateTermMap = smrImDocHeadAccessExt.getInvoiceDateTerms(docIdsUpdated);	                        
                			//invoiceTermsMap = smrImDocHeadAccessExt.getInvoiceTerms(docIdStrings);
                			                		
	                		ReIMDate vDate = ServiceFactory.getPeriodService().getScreenVDate();
	                		String dueDate = vDate.getDateString(); //Just for initialization
	                		//If both newTermsID and newInvoiceDate are entered then it is not required to calculate due date for all invoices
	                		// because same due date would apply to all invoices.
	                		
	                		String dateTerm;
	                		String termsID;
	                		String docDate;
	                		
	                		for (int i = 0; i < docIdsUpdated.length; i++) {
	                			dateTerm = invoiceDateTermMap.get(docIdsUpdated[i]);
	                			docDate = dateTerm.substring(0, dateTerm.indexOf('_'));
	                			termsID = dateTerm.substring(dateTerm.indexOf('_')+1);
	                			
	                			dueDate = ServiceFactory.getTermsService().calculateTermsDueDate(docDate, termsID, vDate);
	                			invoiceDueDatesMap.put(docIdsUpdated[i], dueDate);
							}
	                		
	                		if(invoiceDueDatesMap.size() > 0)
	                			smrImDocHeadAccessExt.updateDueDates(invoiceDueDatesMap);
                		}
                    
                	} 
                		

                	if(updatedInvoicesCount > 0 && smrMerchandiseDocument.validateUpdateInvoiceItem()){
                		  int updatedItemInvoicesCount = new SmrImInvoiceDetailAccessExt().replace(smrMerchandiseDocument.getSupplierId(), smrMerchandiseDocument.getOrderNo(), 
                				  smrMerchandiseDocument.getInvoiceId(), smrMerchandiseDocument.getOldItem(), smrMerchandiseDocument.getNewItem(), updatedInvoicesCount);
                	}

                }

                // Release lock on all of the affected documents
                releaseDocHeadLock(docIds, smrMerchandiseDocument.getUserId());

                // set values in the ediDocumentValidationValues object
                ediDocumentValidationValues.setValidDocumentCount(updatedInvoicesCount);
                if (updatedInvoicesCount == 0) { ediDocumentValidationValues.setMessageCode(EdiRejectService.NO_DOCUMENTS_WERE_AFFECTED); }
            	else{ ediDocumentValidationValues.setMessageCode(EdiRejectService.DOCUMENTS_WERE_REVALIDATED); }

                return ediDocumentValidationValues;

            } else {

                ediDocumentValidationValues.setAllDocumentsValid(false);
                ediDocumentValidationValues.setValidDocumentCount(0);
                ediDocumentValidationValues.setMessageCode(EdiRejectService.NO_DOCUMENTS_WERE_AFFECTED);
                return ediDocumentValidationValues;

            }
        } catch (ReIMException exception) {
            TransactionManagerFactory.getInstance().rollback();
            throw exception;
        } catch (Exception ex) {
            TransactionManagerFactory.getInstance().rollback();
            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, ex,
                    EdiRejectService.class);
        } finally {
            TransactionManagerFactory.getInstance().end();
        }
    }

    public String[] getDocIds(String supplierId, String orderNo, String invoiceId, String fromInvoiceId, String toInvoiceLOV) throws ReIMException {
    	try {
    		return SmrImDocHeadAccessExt.getDocIds(supplierId, orderNo, invoiceId, fromInvoiceId, toInvoiceLOV);
    	} catch (Exception ex) {
    		throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, ex,
    				EdiRejectService.class, new String[] { supplierId, orderNo, invoiceId});
    	}
    }

//    public boolean massDeleteRejects(String supplierId, String orderNo, String invoiceId, String userId) throws ReIMException {
//
//        try {
//            String[] docIds = getDocIds(supplierId, orderNo, invoiceId);
//            if (docIds != null) {
//                for (String docId2 : docIds) {
//                    long docId = Long.parseLong(docId2);
//                    // This will delete any expired locks on the lock table.
//                    LockingUtils.isUserAuthorized(LockingData.EDI_REJECT_DOC_LOCK_TABLE, userId,
//                            docId);
//                    if (getInvoiceRejectService().getDocLockUserId(docId) != null
//                            && !getInvoiceRejectService().getDocLockUserId(docId).equalsIgnoreCase(userId)) { return false; }
//                }
//
//                long[] doc_ids = new long[docIds.length];
//
//                for (int i = 0; i < docIds.length; i++) {
//                    doc_ids[i] = Long.parseLong(docIds[i]);
//                }
//
//                getInvoiceRejectService().lockEdiRejectDoc(doc_ids, userId);
//                getInvoiceRejectService().deleteRejects(docIds);
//                getInvoiceRejectService().releaseEdiRejectDocLock(doc_ids, userId);
//
//                return true;
//            } else {
//                return false;
//            }
//        } catch (Exception ex) {
//            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, ex,
//                    EdiRejectService.class);
//        }
//    }

    public boolean rejectTrueDuplicates(String extDocId, String orderNo, Double totalCost, String vendor)  throws ReIMException {

        try {
                if ( SmrImDocHeadAccessExt.checkTrueDuplicates(extDocId, orderNo, totalCost, vendor) ) {
                    return true;
                } else {
                    return false;
                }

        } catch (Exception ex) {
            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, ex,
                    EdiRejectService.class);
        }
    }

    public boolean softDuplicates(String extDocId, String orderNo, Double totalCost, String vendor)  throws ReIMException {

        try {
                if ( SmrImDocHeadAccessExt.softDuplicates(extDocId, orderNo, totalCost, vendor) ) {
                    return true;
                } else {
                    return false;
                }

        } catch (Exception ex) {
            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, ex,
                    EdiRejectService.class);
        }
    }

    private String getDocLockUserId(long docId) throws ReIMException {
        try {
            return ServiceFactory.getTableRecordLockingService().getUserIdLockingRecordOnTable(
                    LockingData.DOC_HEAD_LOCK_TABLE, docId);

        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, e,
                    EdiRejectService.class);
        }
    }

    private void lockDocHead(long[] docIds, String userId) throws ReIMException {
        try {

        	ServiceFactory.getTableRecordLockingService().lockTableRecordGroupForUser(
        			LockingData.DOC_HEAD_LOCK_TABLE, userId, docIds);

//            return ServiceFactory.getTableRecordLockingService().lockTableRecordForUser(
//                    LockingData.DOC_HEAD_LOCK_TABLE, userId, docId);

        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR, e,
                    EdiRejectService.class);
        }
    }

    private void releaseDocHeadLock(long[] docIds, String userId) throws ReIMException {
        try {
            ServiceFactory.getTableRecordLockingService().releaseLockOnRecordGroupForUser(
                    LockingData.DOC_HEAD_LOCK_TABLE, userId, docIds);
        } catch (ReIMException e) {
            throw e;
        } catch (Exception e) {
            throw new ReIMException("error.SmrInvoiceMassCorrectionService",
                    Severity.ERROR, e, EdiRejectService.class);
        }
    }

    public void updateRejectHeadRejectReason(long docId, String errorColumnId, String rejectReason)
            throws ReIMException {

        try {
            ImEDIRejectDocHeadRow ediRejectDocHeadRow = new ImEDIRejectDocHeadRow();

            ediRejectDocHeadRow.setDocId(docId);
            ediRejectDocHeadRow.setErrorColumnId(errorColumnId);
            ediRejectDocHeadRow.setRejectReasonCode(rejectReason);
            ediRejectDocHeadRow.setUpdateId(ReIMUserContext.getUsername());

            getInvoiceRejectDocumentDao().update(ediRejectDocHeadRow, new HashSet<Tax>());
        } catch (Exception ex) {
            throw new ReIMException("error.SmrInvoiceMassCorrectionService", Severity.ERROR,
                    ex, EdiRejectService.class);
        }
    }

    public oracle.retail.reim.services.IEdiRejectService getInvoiceRejectService() {
    	return this.ediRejectService;
    }

    public IEdiRejectDocumentDao getInvoiceRejectDocumentDao() {
        return ediRejectDocumentDao;
    }

    @Autowired
    @Required
    public void setInvoiceRejectDocumentDao(IEdiRejectDocumentDao ediRejectDocumentDao) {
        this.ediRejectDocumentDao = ediRejectDocumentDao;
    }

    @Required
    @Autowired
    public void setEdiRejectService (oracle.retail.reim.services.IEdiRejectService ediRejectService) {
    	this.ediRejectService = ediRejectService;
    }

    public ISmrEdiRejectDocumentDao getSmrInvoiceRejectDocumentDao() {
    	return this.smrEdiRejectDocumentDao;
    }

    @Required
    @Autowired
    public void setInvoiceRejectDocumentDao (ISmrEdiRejectDocumentDao ediRejectDocumentDao) {
    	this.smrEdiRejectDocumentDao = ediRejectDocumentDao;
    }
    
    public ITermsService getTermsService() {
        if (termsService == null) termsService = ServiceFactory.getTermsService();
        return termsService;
    }

    public void setTermsService(ITermsService termsService) {
        this.termsService = termsService;
    }

    public void insertSmrInvoiceRejectRecord(SmrEdiReportRecord smrEdiRejectRecord) {
    	this.smrEdiRejectDocumentDao.insertSmrEdiRejectRecord(smrEdiRejectRecord);
    }

}
