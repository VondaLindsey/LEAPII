package smr.retail.reim.data.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import oracle.retail.reim.utils.Severity;

import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.retek.reim.merch.utils.ReIMException;

import smr.retail.reim.data.dao.ISmrCostResDao;


/**
 * DAO Implementation to access the SMR_REIM_COST_RES_SQL package.
 * 
 * V1.1 Initial Version
 * 
 * @author Simon Mann
 *
 */
@Repository
public class SmrCostResDao extends SimpleJdbcDaoSupport implements
		ISmrCostResDao  {

	private final static String RESULT_PARAM = "Result";
	private final static String ERROR_MSG_PARAM = "Error";
	private final static String RCA_ALLOWED_PARAM = "RcaAllowed";
	
	private final static String callableStatement = "{? = call smr_reim_cost_res_sql.rca_allowed(?, ?, ?, ?, ?, ?)}";
	
	/**
	 * This is a wrapper for SMR_REIM_COST_RES_SQL.RCA_ALLOWED.
	 */
	public boolean isRcaAllowed(final long orderNo, final long location, final String item, final double unitCost) 
			throws ReIMException {
		List<SqlParameter> rcaParameters = new ArrayList<SqlParameter>();
		rcaParameters.add(new SqlOutParameter(RESULT_PARAM, Types.NUMERIC));
		rcaParameters.add(new SqlOutParameter(ERROR_MSG_PARAM, Types.VARCHAR));
		rcaParameters.add(new SqlOutParameter(RCA_ALLOWED_PARAM, Types.NUMERIC));
		rcaParameters.add(new SqlParameter(Types.NUMERIC));
		rcaParameters.add(new SqlParameter(Types.NUMERIC));
		rcaParameters.add(new SqlParameter(Types.VARCHAR));
		rcaParameters.add(new SqlParameter(Types.NUMERIC));
		
		CallableStatementCreator cs = new CallableStatementCreator() {
			public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall(callableStatement);
                cs.registerOutParameter(1, Types.INTEGER);
                cs.registerOutParameter(2, Types.VARCHAR);
  		        cs.registerOutParameter(3, Types.INTEGER);
  		        cs.setLong(4,  orderNo);
  		        cs.setLong(5, location);
  		        cs.setString(6,  item);
  		        cs.setDouble(7, unitCost);
                return cs;
            }
		};
		
		@SuppressWarnings("rawtypes")
		Map results = getJdbcTemplate().call(cs,  rcaParameters);
		
		if (((Integer) results.get(RESULT_PARAM)).intValue() == 0)  {
			String msg = (String) results.get(ERROR_MSG_PARAM);
			Object[] errorParams = {msg, orderNo, location, item, unitCost};
			throw new ReIMException("SMR.error.rcaallowed", Severity.ERROR, this, errorParams);
		}
		
		if (((Integer) results.get(RCA_ALLOWED_PARAM)).intValue() == 0) {
			return false;
		}
		return true;
	}
	
	
}

