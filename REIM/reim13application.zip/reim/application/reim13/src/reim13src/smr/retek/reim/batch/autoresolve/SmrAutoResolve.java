package smr.retek.reim.batch.autoresolve;

import java.util.Map;

import oracle.retail.reim.utils.Logger;

import org.springframework.beans.factory.annotation.Required;

import smr.retail.reim.services.resolving.ISmrAutoResolutionService;
import smr.retek.reim.business.SmrAutoResolutionCandidate;

import com.retek.reim.batch.BatchUtils;
import com.retek.reim.batch.automatch.AutoMatchProducer;

public class SmrAutoResolve {

	private ISmrAutoResolutionService smrAutoResolutionService;
	
	public int beginAutoResolving(String[] args) {
		int processStatus = BatchUtils.FAILED_PROCESS;
		try {
			BatchUtils.start(SmrAutoResolve.class, args);

			processStatus = doAutoResolving();

			if (AutoMatchProducer.isErrorsLogged()) {
				processStatus = BatchUtils.SUCCESS_WITH_ERRORS_TO_LOG;
			}
		} catch (Exception e) {
			Logger.error(this, e);
		}
		BatchUtils.finish(SmrAutoResolve.class, processStatus);
		return processStatus;		
	}
	
	public int doAutoResolving() {
		int processStatus = BatchUtils.SUCCESS;
	    //Get the auto resolution candidates map
        Map<String, SmrAutoResolutionCandidate> resolutionCandidates = smrAutoResolutionService.getAutoResolutionCandidates();
        
        if (resolutionCandidates != null && resolutionCandidates.size() > 0) {
        	try {
        		processStatus = smrAutoResolutionService.processResolutionCandidates(resolutionCandidates);
        	} catch (Exception e) {
        		Logger.error(this, e);
        		processStatus = BatchUtils.FAILED_PROCESS;
        	}
        } else {
        	Logger.info(this, "No candidates for auto resolution.");
        }                
		return processStatus;
	}  
    
    @Required
    public void setSmrAutoResolutionService(ISmrAutoResolutionService smrAutoResolutionService) {
        this.smrAutoResolutionService = smrAutoResolutionService;
    }	
}
