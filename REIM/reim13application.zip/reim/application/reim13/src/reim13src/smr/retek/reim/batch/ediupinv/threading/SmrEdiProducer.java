package smr.retek.reim.batch.ediupinv.threading;

import smr.retek.reim.batch.ediupinv.threading.SmrEdiTransactionReader;
import EDU.oswego.cs.dl.util.concurrent.LinkedQueue;

import com.retek.reim.batch.ediupinv.EDIConstants;
import com.retek.reim.batch.ediupinv.EdiDocBulk;
import com.retek.reim.batch.ediupinv.EdiFileHeader;
import com.retek.reim.batch.ediupinv.EdiTransactionHeader;
import com.retek.reim.batch.ediupinv.threading.EdiTransactionUploadReporter;
import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.merch.utils.threads.Consumer;
import com.retek.reim.merch.utils.threads.Producer;

/**
 * 
 * This concrete implementation of Producer is used for the Edi Invoice Upload program.
 * 
 * @see Producer
 */

public class SmrEdiProducer extends Producer implements EDIConstants, EdiTransactionUploadReporter {
    private SmrEdiTransactionReader reader = null;

    public SmrEdiProducer(EdiFileHeader fileHeader, String[] args, EdiDocBulk ediDocBulk)
            throws ReIMException {
        super();

        backgroundQueue = new LinkedQueue();

        reader = new SmrEdiTransactionReader(args, ediDocBulk, backgroundQueue);

        c = new Consumer(queue, backgroundQueue, this);
        b = new SmrEdiBackground(backgroundQueue, args[2], args[3], fileHeader);
    }

    /**
     * This method creates the queue to be used by the consumer. The queue is filled with
     * EdiTransactionHeader objects.
     * 
     * @throws ReIMException
     */
    public void createQueue() throws ReIMException {
        try {
            // Discard FHEAD
            reader.discardEdiFileLine();

            while (true) {
                EdiTransactionHeader e = reader.getNextTransaction();
                if (e != null) {
                    queue.put(e);
                } else {
                    break;
                }
            }
        } catch (ReIMException e) {
        	setSuccessfulTermination(false);
            throw (e);
        } catch (InterruptedException e) {
        	setSuccessfulTermination(false);
            e.printStackTrace();
        }
    }

    public boolean isTransactionsRejectedToDatabase() {
        return reader.isTransactionsRejectedToDatabase();
    }

    public boolean isTransactionsRejectedToFile() {
        return reader.isTransactionsRejectedToFile();
    }

    public void setTransactionsRejectedToDatabase(boolean transactionRejectedToDatabase) {
        reader.setTransactionsRejectedToDatabase(transactionRejectedToDatabase);
        reader.setTransactionsRejectedToFile(!transactionRejectedToDatabase);
    }

    public void setTransactionsRejectedToFile(boolean transactionRejectedToFile) {
        reader.setTransactionsRejectedToFile(transactionRejectedToFile);
        reader.setTransactionsRejectedToDatabase(!transactionRejectedToFile);
    }

    public void setSuccessfulTermination(boolean b) {
        reader.setSuccessfulTermination(b);
    }

    public boolean hasSuccessfullyTerminated() {
        return reader.hasSuccessfullyTerminated();
    }
}
