package smr.retail.reim.services;

import com.retek.reim.merch.utils.ReIMException;
import com.retek.reim.services.IReasonCodesService;
import com.retek.reim.ui.lov.LOV;

public interface ISmrReasonCodesService extends IReasonCodesService {

	/**
	 * Returns a list of reason codes.
	 * 
	 * @param businessRoleId the role of the currently logged on business user.
	 * @param id the id the user has entered into the ID field of the LOV, if any. 
	 * @param reasonCodeType the type of reason code. Null if not specific.
	 * @param documentType The type of document being resolved.
	 * @param varianceSign Whether or not the variance is positive or negative. Will be either ReIMConstants.POSITIVE, or ReIMConstants.NEGATIVE.
	 * @param selectedCostQuantityIsOther true if the selected cost which is correct is other then the invoice, order cost, or a credit memo cost.
	 * @param receiptsExist whether or not receipts already exist
	 * @param selectedCostQuantity which cost, or quantity is selected to be correct.
	 * @param orderNo the order number for which the user is attempting to resolve for the discrepancy
	 * @param location the location for which the user is attempting to resolve for the discrepancy.
	 * @param item The item which the user is attempting to resolve for the discrepancy.
	 * @param unitCost The unit cost to which the user is attempting to resolve for the discrepancy.
	 * @return An array of LOV objects which will equate to the valid reason codes available for the user to select.
	 * @throws ReIMException thrown if any exception handlable by the application is captured.
	 */
	public LOV[] getReasonCodes(long businessRoleId, String id,
			String reasonCodeType, String documentType, String varianceSign,
			boolean selectedCostQuantityIsOther, String receiptsExist,
			String selectedCostQuantity, String orderNo, String location, String item, String unitCost) throws ReIMException;
}
