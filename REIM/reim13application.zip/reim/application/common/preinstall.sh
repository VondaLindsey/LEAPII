#!/bin/sh

# Pre-install script for OAS J2EE application installs
# This is a generic pre-install script for an app install for any product

# This script will be called by install.sh using a CWD of one directory up from the
# 'common'.

STARTDIR=`pwd`
MYDIR=`dirname $0`
if [ ! -f ./install.sh ] ; then
  # $0 can resolve to different paths depending on the platform when
  # this script is sourced by a different script in a different directory
  # Correct MYDIR so that it is the directory that contains install.sh
  cd ${MYDIR}/..
  MYDIR=`pwd`
fi

PREOK=0 ; export PREOK

ORETAIL_APPSERVER=oas
export ORETAIL_APPSERVER

ORACLE_HOSTNAME=`hostname`
export ORACLE_HOSTNAME

# attempt to read HTTP port out of ORACLE_HOME
if [ -f "$ORACLE_HOME/Apache/Apache/conf/httpd.conf" ] ; then
    ORACLE_HTTP_PORT=`\
        cat "$ORACLE_HOME/Apache/Apache/conf/httpd.conf" \
          | egrep '^Listen ' \
          | head -n1 \
          | sed 's/Listen //g' \
          | sed 's/ //g'`
    if [ -z "$ORACLE_HTTP_PORT" ] ; then
        ORACLE_HTTP_PORT=`\
            cat "$ORACLE_HOME/Apache/Apache/conf/httpd.conf" \
              | egrep '^Port ' \
              | sed 's/Port //g' \
              | sed 's/ //g'`
    fi
    if [ -z "$ORACLE_HTTP_PORT" ] ; then
        ORACLE_HTTP_PORT='[httpPort]'
    fi
else
    ORACLE_HTTP_PORT='[httpPort]'
fi
export ORACLE_HTTP_PORT

# attempt to read OPMN request port out of ORACLE_HOME
if [ -f "$ORACLE_HOME/opmn/conf/opmn.xml" ] ; then
    ORACLE_OPMN_REQ_PORT=`\
        grep request < "$ORACLE_HOME/opmn/conf/opmn.xml" \
            | grep '<port ' \
            | sed 's/.*request="//g' \
            | sed 's/".*//g'`
    CHECK_OPMN=`echo $ORACLE_OPMN_REQ_PORT | sed 's/[0-9]//g'` 
    if [ -z "$ORACLE_OPMN_REQ_PORT" -o ! -z "$CHECK_OPMN" ] ; then
        # Parsed OPMN request port is either blank or contains non-numeric characters.
        # there must have been a problem in parsing the value, so set the installer default
        # to the [opmnPort] string for the user to manually modify.
        ORACLE_OPMN_REQ_PORT='[opmnPort]'
    fi
else
    ORACLE_OPMN_REQ_PORT='[opmnPort]'
fi
export ORACLE_OPMN_REQ_PORT

if [ -z "$ORACLE_HOME" ] ; then
    echo "You must set ORACLE_HOME to point to your OracleAS installation"
    PREOK=1 ; export PREOK
elif [ ! -d "$ORACLE_HOME/j2ee/home" ] ; then
    echo "ORACLE_HOME is not set to an Oracle Application Server installation. Installation cannot proceed."
    PREOK=1 ; export PREOK
fi


if [ -z "$JAVA_HOME" ] ; then
    echo "You must set JAVA_HOME to a 1.4.2 or later JDK"
    PREOK=1 ; export PREOK
fi

if [ ! -d "$ORACLE_HOME/jdk" ] ; then
    DEPLOYMENT_TYPE=standalone
else
    DEPLOYMENT_TYPE=enterprise
fi
export DEPLOYMENT_TYPE

if [ -d "$ORACLE_HOME/ant" ] ; then
    ANT_HOME=$ORACLE_HOME/ant
    export ANT_HOME
fi

# set library path for use of the Oracle thick client in the installer
# set all vars for all supported platforms
if [ -d "$ORACLE_HOME/lib32" ] ; then
    LD_LIBRARY_PATH=$ORACLE_HOME/lib32:$LD_LIBRARY_PATH
    SHLIB_PATH=$ORACLE_HOME/lib32:$SHLIB_PATH
    LIBPATH=$ORACLE_HOME/lib32:$LIBPATH
else
    LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
    SHLIB_PATH=$ORACLE_HOME/lib:$SHLIB_PATH
    LIBPATH=$ORACLE_HOME/lib:$LIBPATH
fi
export LD_LIBRARY_PATH SHLIB_PATH LIBPATH

ANT_EXTENSION_LIB=${MYDIR}/ant-ext

if [ -z "$CLASSPATH" ]
then
    CLASSPATH=$ANT_EXTENSION_LIB/ant-contrib.jar
else
    CLASSPATH=$CLASSPATH:$ANT_EXTENSION_LIB/ant-contrib.jar
fi
CLASSPATH=$CLASSPATH:$ANT_EXTENSION_LIB/bsf.jar
CLASSPATH=$CLASSPATH:$ANT_EXTENSION_LIB/js.jar
CLASSPATH=$CLASSPATH:$ANT_EXTENSION_LIB/platform-build-util.jar
CLASSPATH=$CLASSPATH:$ANT_EXTENSION_LIB/xmltask-v1.13.jar

if [ -d "${ORACLE_HOME}/adfp" ] ; then
    # WebCenter Ant tasks
    CLASSPATH=$CLASSPATH:$ORACLE_HOME/adfp/utilities:$CLASSPATH
    CLASSPATH=$CLASSPATH:$ORACLE_HOME/adfp/utilities/ant-adfp-classes.jar:$CLASSPATH
    CLASSPATH=$CLASSPATH:$ORACLE_HOME/adfp/lib/portlet-client-deploy.jar:$CLASSPATH
fi

export CLASSPATH

###
# hibernate check left here for backwards compatibility with 12.0
# From now on, all external library files that are required 
# separately should be verified in a product-specific checkdeps.sh script
###
if [ $PREOK = 0 ] ; then
    if [ -d ${MYDIR}/hibernate ] ; then
        if [ -f ${MYDIR}/hibernate/hibernate2.jar ] ; then
            echo ""
            echo "hibernate2.jar detected. Verifying that it is the correct version..."
            $JAVA_HOME/bin/java com.retek.platform.build.util.JarUtil -x hibernate/hibernate2.jar 2905204960
            if [ $? != 0 ] ; then
                echo "The hibernate2.jar file provided is the wrong version. You must provide hibernate2.jar from"
                echo "the Hibernate 2.1.8 distribution"
                PREOK=1 ; export PREOK
                fi
        else
            echo "hibernate2.jar not found. Please extract the hibernate2.jar file from the Hibernate 2.1.8"
            echo "distribution and copy it into the ${MYDIR}/hibernate directory."
            PREOK=1 ; export PREOK
        fi
    fi
fi

# override java.io.tmpdir to avoid collisions under /var/tmp by third-party
# code
if [ -z "$ANT_OPTS" ]
then
    ANT_OPTS="-Djava.io.tmpdir=${MYDIR}/javatmp"
else
    ANT_OPTS="${ANT_OPTS} -Djava.io.tmpdir=${MYDIR}/javatmp"
fi
export ANT_OPTS
rm -rf ${MYDIR}/javatmp
mkdir ${MYDIR}/javatmp

if [ "$PREOK" = "0" ] ; then
    #Do OCM Integration if it's there in the build package
    if [ -d ${STARTDIR}/common/ocm-integration ]
    then
      cd ${STARTDIR}/common/ocm-integration
      if [ -f ./integrate.sh ]
      then
        export OCMDIR=../../..
        export PRODUCTDIR=../..
        . ./integrate.sh
      fi
    fi

    echo ""
    echo "This Oracle Retail product will be installed to the following ORACLE_HOME:"
    echo "${ORACLE_HOME}"
    echo ""
    echo "Press enter to continue"
    read ignore
    echo ""
    echo "Launching installer..."
fi

cd $STARTDIR

