#!/bin/sh

# Post-install script for OAS J2EE application installs
# This is a generic post-install script for an app install for any product

# This script will be called by install.sh using a CWD of one directory up from 
# 'common'.

STARTDIR=`pwd`
MYDIR=`dirname $0`
if [ ! -f ./install.sh ] ; then
  # $0 can resolve to different paths depending on the platform when
  # this script is sourced by a different script in a different directory
  # Correct MYDIR so that it is the directory that contains install.sh
  cd ${MYDIR}/..
  MYDIR=`pwd`
fi

POSTOK=0 ; export POSTOK

# The app installer might have generated a run-next-installer.sh
# script. For example, this can be used to call the Retail OCM 
# installer as a post-install activity.
if [ -f "${MYDIR}/common/run-next-installer.sh" ] ; then
  chmod u+x "${MYDIR}/common/run-next-installer.sh"
  mv "${MYDIR}/common/run-next-installer.sh" "${MYDIR}/common/run-once.sh"
  if [ -x "${MYDIR}/common/run-once.sh" ] ; then
    "${MYDIR}/common/run-once.sh"
    rm -f "${MYDIR}/common/run-once.sh"
  fi
fi

cd $STARTDIR

