#!/bin/ksh

# install.sh - generic Oracle Retail installer startup script

# Force a standard locale for the installer to avoid strange issues
# when there is a system default with a different value
LC_CTYPE=en_US.ISO8859-1

STARTDIR=`pwd`
MYDIR=`dirname $0`
cd $MYDIR
MYDIR=`pwd`

# set user-provided input mode in ORETAIL_INSTALLER_MODE
# There are conditions under which this might be modified
# later. For example, if user tries to run in swing mode
# but does not have the DISPLAY variable set, the installer
# will automatically switch over to text mode.
ORETAIL_INSTALLER_MODE=$1
if [ -z "$ORETAIL_INSTALLER_MODE" ] ; then
    # default to 'swing' (GUI)
    ORETAIL_INSTALLER_MODE=swing
fi
export ORETAIL_INSTALLER_MODE

ANT_HOME=${MYDIR}/ant
export ANT_HOME
ANT_INSTALL_HOME=${MYDIR}/antinstall

if [ -z "$JAVA_HOME" ] ; then
    if [ ! -d "$ORACLE_HOME/jdk" ] ; then
        echo "You must set JAVA_HOME";
        exit 1;
    else
        # If there is an ORACLE_HOME and it contains a JDK, use that JDK.
        # The preinstall.sh script might override this again before the installer
        # is launched
        JAVA_HOME=$ORACLE_HOME/jdk
        export JAVA_HOME
    fi
fi

PATH=$JAVA_HOME/bin:$PATH
export JAVA_HOME PATH
unset ACU_HOME
unset ACU_PATH

# AntInstaller jars
if [ -z "$CLASSPATH" ]
then
    CLASSPATH=$ANT_INSTALL_HOME/lib/ant-installer.jar
else
    CLASSPATH=$CLASSPATH:$ANT_INSTALL_HOME/lib/ant-installer.jar
fi
CLASSPATH=$CLASSPATH:$ANT_INSTALL_HOME/lib/jgoodies-edited-1_2_2.jar
CLASSPATH=$CLASSPATH:$ANT_INSTALL_HOME/lib/sysout.jar


# Oracle Retail resources
CLASSPATH=installer-resources:$CLASSPATH

if [ -f ${MYDIR}/common/checkdeps.sh ]
then
   chmod a+x ${MYDIR}/common/checkdeps.sh
   . ${MYDIR}/common/checkdeps.sh
   if [ $DEPSOK != 0 ]
   then
      echo "Dependency check failed"
      exit 1;
   fi
fi

if [ -f ${MYDIR}/common/preinstall.sh ]
then
   chmod a+x ${MYDIR}/common/preinstall.sh
   . ${MYDIR}/common/preinstall.sh
   if [ $PREOK != 0 ]
   then
      echo "Pre-install check failed"
      exit 1;
   fi
fi

if [ -x "${JAVA_HOME}/bin/java" ] ; then
    COMMAND=$JAVA_HOME/bin/java
elif [ -x "${JAVA_HOME}/jre/bin/java" ] ; then
    COMMAND=$JAVA_HOME/jre/bin/java
else
      echo "Cannot execute $JAVA_HOME/bin/java or $JAVA_HOME/bin/jre/java"
      exit 1;
fi

# Ant jars
ANT_LIB_JARS=`ls $ANT_HOME/lib/*.jar`
for j in  $ANT_LIB_JARS; do
    CLASSPATH=$CLASSPATH:$j
done

if [ ! -z "${CLASSPATH_END}" ] ; then
    CLASSPATH=$CLASSPATH:$CLASSPATH_END
fi

MYOS=`uname`
echo $MYOS | grep 'CYGWIN'
if [ "$?" -eq 0 ]; then
  CLASSPATH="$(cygpath -w -p ${CLASSPATH})"
fi

export CLASSPATH

if [ "$ORETAIL_INSTALLER_MODE" = "silent" ]
then
   unset DISPLAY
   ${ANT_HOME}/bin/ant -f common/prepare.xml prepare-silent
   ${ANT_HOME}/bin/ant -f build.xml -propertyfile ant.install.properties install
   returnvalue=$?
elif [ "$ORETAIL_INSTALLER_MODE" = "ant" ]
then
   # This is for installer debugging only. Not supported by Oracle as part of 
   # any end user installation process
   ${ANT_HOME}/bin/ant -f build.xml -propertyfile ant.install.properties $@
   returnvalue=$?
elif [ "$ORETAIL_INSTALLER_MODE" = "text" ]
then
   unset DISPLAY
   $COMMAND $ANT_OPTS -classpath $CLASSPATH org.tp23.antinstaller.runtime.ExecInstall text .
   returnvalue=$?
else
   if [ -z "$DISPLAY" ]
   then
      ORETAIL_INSTALLER_MODE=text
      export ORETAIL_INSTALLER_MODE
   else
     if [ `whence xdpyinfo` ]
       then
         xdpyinfo > /dev/null 2>&1
         if [ $? != 0 ]
           then
           echo "ERROR: \$DISPLAY not set to a valid X Windows host."
           echo "ERROR: Set your \$DISPLAY to a valid X Windows host or use text mode."
           echo "ERROR: Example: \"install.sh text\""
           exit 1
         fi
      fi
      ORETAIL_INSTALLER_MODE=swing
   fi

   $COMMAND $ANT_OPTS -classpath $CLASSPATH org.tp23.antinstaller.runtime.ExecInstall $ORETAIL_INSTALLER_MODE .
   returnvalue=$?
fi

if [ -f ${MYDIR}/common/postinstall.sh ]
then
   chmod a+x ${MYDIR}/common/postinstall.sh
   . ${MYDIR}/common/postinstall.sh
   if [ $POSTOK != 0 ]
   then
      echo "Post-install check failed"
      exit 1;
   fi
fi

exit $returnvalue

